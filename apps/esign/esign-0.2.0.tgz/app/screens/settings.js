// Settings: what every envelope carries (managed in Orchestra), whether the
// sender answers, the certificate that seals the signed PDFs, and what kind of
// signature this is.
import { A, C, act, ago, head, integrations, settings } from '../data.js';

const { el } = Orch;

export function render() {
  Orch.load('view', async () => {
    const s = await settings(true);
    if (!s._id) return el('p', { class: 'oc-state' }, 'Sign is not installed.');
    return el('div', { class: 'oc-stack oc-stack--loose' }, [head('Settings', 'What every envelope carries, and how it reaches the signers.'), form(s), legal()]);
  });
}

// What every envelope carries (your company, the signers' language, who sends
// the emails, the code check, days to sign, reminders, Telegram, the folder and
// the timestamp authority) is managed in Orchestra (Apps → Sign → Ajustes and
// Conexiones): typed, next to its connections. Here, what they are now, a way
// there, whether the sender answers, and the certificate.
function form(s) {
  const link = el('a', { class: 'oc-btn oc-btn--primary', target: '_blank', rel: 'noopener', hidden: true }, 'Open the settings in Orchestra');
  const where = el('p', { class: 'oc-help' }, 'In Orchestra: Apps → Sign → Ajustes.');
  if (Orch.manageUrl) Orch.manageUrl('settings').then((url) => { if (url) { link.href = url; link.hidden = false; where.hidden = true; } });
  const facts = [
    ['Company name', s.company_name || '— (not set yet)'],
    ['Signers read', s.language === 'es' ? 'Español' : 'English'],
    ['Time zone', s.timezone || 'Europe/Madrid'],
    ['Send through', C.senderOf(s) === 'resend' ? `Resend${s.resend_from ? ` (${s.resend_from})` : ''}` : 'Gmail'],
    ['Code to their email when they sign', s.require_code === 'no' ? 'no' : 'yes'],
    ['Days to sign', String(s.expire_days ?? 30)],
    ['Reminders on their own', s.remind_on === 'yes' ? `yes, every ${s.remind_days ?? 3} days` : 'no'],
    ['Telegram notices', s.notify_telegram ? 'yes' : 'no'],
    ['Folder in Files', s.files_folder || 'Signed'],
    ['Timestamp authority', s.tsa_url || 'none'],
  ];
  const st = C.senders(s);
  const look = el('button', { type: 'button', class: 'oc-btn oc-btn--sm' }, 'Look again');
  look.addEventListener('click', async () => { look.disabled = true; look.textContent = 'Looking…'; if (await act(A.check, { id: s._id })) setTimeout(render, 6000); });
  const cert = s.cert_subject
    ? el('dl', { class: 'es-facts' }, [el('div', [el('dt', 'Certificate'), el('dd', s.cert_subject)]), el('div', [el('dt', 'Valid until'), el('dd', s.cert_not_after || '—')]),
      el('div', [el('dt', 'SHA-256 fingerprint'), el('dd', { class: 'es-mono' }, s.cert_fingerprint || '—')])])
    : el('p', { class: s.cert_status === 'error' ? 'es-bad' : 'oc-help' }, s.cert_status === 'error' ? s.cert_note : 'Not made yet: it is made the first time Sign reads a file (New envelope).');
  return el('div', { class: 'oc-stack oc-stack--loose es-form' }, [
    el('section', { class: 'oc-card oc-stack' }, [el('h2', { class: 'oc-h2' }, 'What every envelope carries'),
      el('p', { class: 'oc-help' }, 'Managed in Orchestra, with the Gmail or Resend connection Sign sends through.'),
      el('ul', { class: 'oc-stack' }, facts.map(([k, v]) => el('li', [el('b', `${k}: `), v]))),
      el('div', { class: 'oc-row' }, [link]), where]),
    el('section', { class: 'oc-card oc-stack' }, [el('h2', { class: 'oc-h2' }, 'Emails'),
      el('p', { class: 'oc-help' }, ['Invitations, codes, reminders and the signed copy go from your own account, connected in ', integrations('Orchestra → Integrations'), '. Nothing goes out until you press Send.']),
      el('div', { class: 'oc-row es-look' }, [el('p', { class: st.ready ? 'es-said' : 'es-bad' }, st.say), look]),
      el('p', { class: 'oc-help' }, s.gmail_checked_at ? `Looked ${ago(s.gmail_checked_at)}.` : 'Not looked yet.')]),
    el('section', { class: 'oc-card oc-stack' }, [el('h2', { class: 'oc-h2' }, 'Signed PDFs'),
      el('p', { class: 'oc-help' }, 'Each signed PDF is sealed with this workspace\'s own certificate: a PDF reader shows the document was not changed since. It cannot say who the certificate belongs to, because no certificate authority vouches for it.'),
      cert]),
  ]);
}

const legal = () => el('section', { class: 'oc-card oc-stack es-legal' }, [
  el('h2', { class: 'oc-h2' }, 'What kind of signature this is'),
  el('p', ['A simple electronic signature: valid for most agreements under eIDAS (EU) and ESIGN/UETA (US), with evidence of who signed and when: ',
    'their email (and a code sent to it), their consent, the browser they used, and a sealed PDF with a certificate page.']),
  el('p', ['It is not an advanced or qualified signature (no certificate per signer), and some documents (wills, some family and property matters) ',
    'may need one, or paper. IP addresses are not recorded.']),
]);
