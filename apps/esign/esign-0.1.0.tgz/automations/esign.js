#!/usr/bin/env node
'use strict';
/**
 * Sign · the agent's tool. It reads envelopes and files, and prepares a
 * DRAFT; it never sends, reminds or voids: Send is a person's click in the
 * desk (the only door that emails a signer).
 *
 *   node esign.js files [--q words]                  the project's files that can be signed (from es_sources; refresh first if one is missing)
 *   node esign.js refresh                            ask for the files list again (it takes a few seconds)
 *   node esign.js list [--status Out|Draft|Completed|Declined|Void|Expired]
 *   node esign.js show <envelope id>                 the envelope, its signers and its last events
 *   node esign.js draft --file <file id> [--title "…"] [--order together|in_order] [--message "…"]
 *                       [--signer "Role|Name|email"]…   a Draft; the file is read in the background
 *   node esign.js link <envelope id>                 where the person opens it in the desk
 *
 * Prints one JSON line. With a role that is not in the document, the draft
 * keeps it and the desk says so; Send refuses until it is fixed.
 */
const L = require('./lib');
const C = require('./escore');

const arg = (a, k) => { const i = a.indexOf(k); return i >= 0 ? a[i + 1] : undefined; };
const many = (a, k) => a.reduce((acc, x, i) => (x === k && a[i + 1] !== undefined ? acc.concat(a[i + 1]) : acc), []);
const deskLink = (s, id) => (s.desk_url ? `${s.desk_url}#/env/${id}` : `(open Sign → envelope ${id})`);
const STATUSES = ['Draft', 'Out', 'Completed', 'Declined', 'Void', 'Expired'];

function envelopeView(e, s) {
  const signers = L.all("SELECT _id, ord, role, name, email, status, signed_at, declined_at, decline_reason FROM es_signers WHERE envelope_id = ? AND _deleted = 0 AND status <> 'Removed' ORDER BY ord, _id", e._id);
  return {
    id: e._id, title: e.title, status: e.status, file: e.file_name, read: e.prepare_status, read_note: e.prepare_note || undefined,
    order: e.order_mode, expires_on: e.expires_on || undefined, sent_at: e.sent_at || undefined, completed_at: e.completed_at || undefined,
    signed_pdf: e.final_file_id ? { file_id: e.final_file_id, name: e.final_name, sha256: e.final_sha256, seal: e.seal_level } : undefined,
    pdf_status: e.status === 'Completed' ? e.finish_status : undefined, send_note: e.send_note || undefined,
    signers: signers.map((x) => ({ id: x._id, role: x.role, name: x.name, email: x.email, status: x.status, signed_at: x.signed_at || undefined, declined: x.declined_at ? (x.decline_reason || 'yes') : undefined })),
    desk: deskLink(s, e._id),
  };
}

function main(a) {
  const cmd = a[0];
  const s = L.settings();
  if (cmd === 'files') {
    const words = String(arg(a, '--q') || '').toLowerCase();
    const rows = L.all('SELECT file_id, name, type, folder, modified_at FROM es_sources WHERE _deleted = 0 ORDER BY modified_at DESC LIMIT 200').filter((f) => !words || `${f.name} ${f.folder}`.toLowerCase().includes(words));
    return { ok: true, files: rows.slice(0, 50), listed_at: s.sources_at || null, hint: 'A file missing? run `esign.js refresh`, wait a few seconds, and list again.' };
  }
  if (cmd === 'refresh') {
    L.write([{ op: 'update', table: 'es_settings', id: s._id, data: { sources_asked_at: L.isoZ() } }]);
    return Object.assign({ ok: true }, L.kick('prepare', '--sources'));
  }
  if (cmd === 'list') {
    const st = arg(a, '--status');
    if (st && !STATUSES.includes(st)) return { ok: false, error: `--status is one of ${STATUSES.join(', ')}` };
    const rows = L.all(`SELECT * FROM es_envelopes WHERE _deleted = 0 AND status <> 'Discarded'${st ? ' AND status = ?' : ''} ORDER BY _id DESC LIMIT 50`, ...(st ? [st] : []));
    return { ok: true, envelopes: rows.map((e) => { const v = envelopeView(e, s); return { id: v.id, title: v.title, status: v.status, signers: v.signers.map((x) => `${x.name || '?'} (${x.role}): ${x.status}`), expires_on: v.expires_on }; }) };
  }
  if (cmd === 'show' || cmd === 'link') {
    const e = L.one('SELECT * FROM es_envelopes WHERE _id = ? AND _deleted = 0', Number(a[1]));
    if (!e) return { ok: false, error: `No envelope ${a[1]}` };
    if (cmd === 'link') return { ok: true, desk: deskLink(s, e._id) };
    const events = L.all('SELECT event, at, who, detail FROM es_events WHERE envelope_id = ? AND _deleted = 0 ORDER BY _id DESC LIMIT 15', e._id).reverse();
    return Object.assign({ ok: true }, envelopeView(e, s), { events });
  }
  if (cmd === 'draft') {
    const fileId = arg(a, '--file');
    const f = fileId && L.one('SELECT * FROM es_sources WHERE file_id = ? AND _deleted = 0', fileId);
    if (!f) return { ok: false, error: `No signable file ${fileId || ''} in this project's list: run \`esign.js files\` (or \`refresh\`).` };
    const order = arg(a, '--order') || 'together';
    if (!['together', 'in_order'].includes(order)) return { ok: false, error: '--order is together or in_order' };
    const signers = [];
    for (const spec of many(a, '--signer')) {
      const [role, name, email] = spec.split('|').map((x) => String(x || '').trim());
      if (!role || !name || !C.isEmail(email)) return { ok: false, error: `--signer "${spec}" must be "Role|Name|email"` };
      signers.push({ role: C.cleanRole(role), name: name.slice(0, 120), email: C.normEmail(email) });
    }
    const title = L.clean(arg(a, '--title') || String(f.name).replace(/\.[a-z0-9]+$/i, ''), 160);
    const [{ _id: id }] = L.write([{ op: 'insert', table: 'es_envelopes', data: { title, status: 'Draft', file_id: f.file_id, file_name: `${f.name}${f.name.toLowerCase().endsWith(`.${f.type}`) ? '' : `.${f.type}`}`, file_type: f.type,
      prepare_status: 'Waiting', prepare_asked_at: L.isoZ(), order_mode: order, message: L.clean(arg(a, '--message'), 1000), created_by: `agent:${process.env.ORCHESTRA_AGENT_ID || 'agent'}` } }]);
    if (signers.length) L.write(signers.map((x, i) => ({ op: 'insert', table: 'es_signers', data: Object.assign({ envelope_id: id, ord: i + 1, status: 'Waiting', code_tries: 0, reminders: 0 }, x) })));
    const kick = L.kick('prepare');
    return { ok: true, id, title, read: 'in the background, a few seconds', started: kick.started, desk: deskLink(s, id),
      tell_the_person: `The draft is ready to check: ${deskLink(s, id)}. Nothing is sent until you press Send there.` };
  }
  return { ok: false, error: 'commands: files, refresh, list, show <id>, draft --file <id> …, link <id>' };
}

if (require.main === module) {
  try { const r = L.done(main(process.argv.slice(2))); if (!r.ok) process.exitCode = 1; } catch (e) { L.done({ ok: false, error: e.message }); process.exitCode = 1; }
}
module.exports = { main };
