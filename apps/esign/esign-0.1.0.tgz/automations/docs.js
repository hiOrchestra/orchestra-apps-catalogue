'use strict';
/**
 * Sign · Send and keep the signers' pages up to date. A script, no agent.
 *
 *   send      a Draft whose Send was pressed (send_asked_at, not sent): checked
 *             (the sender can send; every role of the document has one signer
 *             with a name and an email; no signer left without a role; one
 *             email per envelope), then in ONE batch: Out, a token per signer
 *             (locked), who is invited now (everyone, or the first in order),
 *             the invitations (Approved: the person's Send is the OK), and the
 *             events "created" and "sent". A refusal leaves it a Draft and
 *             says why (send_note).
 *   turns     in order: when nobody is left at the current place, the next
 *             ones are invited.
 *   remind    a signer's Remind (remind_asked_at newer than the last), and,
 *             only with "Remind on their own" in Settings, one every N days
 *             (three at most): a reminder email.
 *   expire    Out past its day → Expired.
 *   voided    the event of a Void a person pressed (once).
 *   links     each signer's sealed page in es_links: '0' their state (rewritten
 *             only when it changed: its hash), 'd<i>' the document (once),
 *             'p<i>' the signed PDF (once it exists).
 *
 *   node docs.js [--auto|--daily] [--dry-run]
 */
const L = require('./lib');
const C = require('./escore');

const MAX_AUTO_REMINDERS = 3;

const live = (signers) => signers.filter((x) => x.status !== 'Removed');
const linkOf = (s, token) => `${s.public_url || ''}#/${token}`;
const dayWords = (s, day) => (day ? C.longDay(`${day}T12:00:00Z`, s.language, 'UTC') : '');

/** Why an envelope cannot go yet, or null. */
function refusal(s, e, signers) {
  const st = C.senders(s);
  if (!st.ready) return `Nothing was sent: ${st.say}`;
  if (e.prepare_status !== 'Ready') return 'Nothing was sent: the document has not been read yet.';
  const ss = live(signers);
  if (!ss.length) return 'Nothing was sent: add who signs.';
  const docRoles = (L.jsonOf(e.roles, []) || []).map((r) => C.roleKey(r.role));
  for (const x of ss) {
    if (!String(x.name || '').trim()) return `Nothing was sent: ${x.role || 'a signer'} has no name.`;
    if (!C.isEmail(x.email)) return `Nothing was sent: ${x.name || x.role} has no valid email.`;
    if (docRoles.length && !docRoles.includes(C.roleKey(x.role))) return `Nothing was sent: "${x.role}" is not in the document any more. Remove that signer, or read the file again.`;
  }
  for (const r of docRoles) if (!ss.some((x) => C.roleKey(x.role) === r)) return `Nothing was sent: nobody signs as "${(L.jsonOf(e.roles, []).find((y) => C.roleKey(y.role) === r) || {}).role}".`;
  const keys = ss.map((x) => C.roleKey(x.role));
  if (new Set(keys).size !== keys.length) return 'Nothing was sent: two signers have the same role.';
  const emails = ss.map((x) => C.normEmail(x.email));
  if (new Set(emails).size !== emails.length) return 'Nothing was sent: two signers have the same email. Each one signs from their own address.';
  return null;
}

/** Who is invited at the start: everyone, or the lowest place in order. */
function firstWave(e, ss) {
  if (e.order_mode !== 'in_order') return ss;
  const min = Math.min(...ss.map((x) => Number(x.ord) || 0));
  return ss.filter((x) => (Number(x.ord) || 0) === min);
}

function inviteEmail(s, e, x, by) {
  const m = C.mail('invite', s.language, { name: x.name, company: s.company_name, title: e.title, role: e.no_markers === 'yes' ? '' : x.role, message: e.message, link: linkOf(s, x.token), expires: dayWords(s, e.expires_on) });
  return { op: 'insert', table: 'es_emails', data: { envelope_id: e._id, signer_id: x._id, purpose: 'invite', to_email: C.normEmail(x.email), subject: m.subject, body: m.body, status: 'Approved', approved_by: by || '' } };
}

function send(s, out) {
  for (const e of L.all("SELECT * FROM es_envelopes WHERE _deleted = 0 AND status = 'Draft' AND send_asked_at IS NOT NULL AND sent_at IS NULL ORDER BY _id LIMIT 20")) {
    const signers = L.all('SELECT * FROM es_signers WHERE envelope_id = ? AND _deleted = 0 ORDER BY ord, _id', e._id);
    const why = refusal(s, e, signers);
    if (why) {
      try { L.write([{ op: 'update', table: 'es_envelopes', id: e._id, when: { status: 'Draft', send_asked_at: e.send_asked_at }, data: { send_asked_at: null, send_note: why } }]); } catch { /* moved */ }
      out.refused += 1;
      continue;
    }
    const ss = live(signers).map((x) => Object.assign({}, x, { token: C.newToken() }));
    const wave = new Set(firstWave(e, ss).map((x) => x._id));
    const expires = C.realDay(e.expires_on) && e.expires_on >= C.today(s.timezone) ? e.expires_on : C.addDays(C.today(s.timezone), Number(s.expire_days) || 30);
    const env = Object.assign({}, e, { expires_on: expires });
    const ops = [{ op: 'update', table: 'es_envelopes', id: e._id, when: { status: 'Draft', send_asked_at: e.send_asked_at }, data: { status: 'Out', sent_at: L.isoZ(), expires_on: expires, send_note: null } }];
    for (const x of ss) {
      ops.push({ op: 'update', table: 'es_signers', id: x._id, data: { token: x.token, locked: 'yes', email: C.normEmail(x.email), status: wave.has(x._id) ? 'Invited' : 'Waiting', invited_at: wave.has(x._id) ? L.isoZ() : null } });
      if (wave.has(x._id)) ops.push(inviteEmail(s, env, x, e.sent_by));
    }
    ops.push(...L.eventOps(e, [{ event: 'created', at: L.toDate(e._created_at) ? L.isoZ(L.toDate(e._created_at)) : L.isoZ(), who: e.created_by || '', detail: `${e.file_name || ''} · SHA-256 ${e.source_sha256 || ''}` },
      { event: 'sent', who: e.sent_by || '', detail: ss.map((x) => `${x.role}: ${x.name} <${C.normEmail(x.email)}>`).join('; ').slice(0, 1000) }]));
    try { L.write(ops); out.sent += 1; } catch (err) { out.errors.push(`envelope ${e._id}: ${err.message}`); }
    const removed = signers.filter((x) => x.status === 'Removed').map((x) => x._id);
    if (removed.length) L.softDelete('es_signers', removed);
  }
}

function turns(s, out) {
  for (const e of L.all("SELECT * FROM es_envelopes WHERE _deleted = 0 AND status = 'Out' AND order_mode = 'in_order'")) {
    const ss = live(L.all('SELECT * FROM es_signers WHERE envelope_id = ? AND _deleted = 0 ORDER BY ord, _id', e._id));
    const open = ss.filter((x) => !['Signed', 'Declined'].includes(x.status));
    if (!open.length || open.some((x) => ['Invited', 'Opened'].includes(x.status))) continue;
    const min = Math.min(...open.map((x) => Number(x.ord) || 0));
    const ops = [];
    for (const x of open.filter((y) => (Number(y.ord) || 0) === min && y.status === 'Waiting')) {
      ops.push({ op: 'update', table: 'es_signers', id: x._id, when: { status: 'Waiting' }, data: { status: 'Invited', invited_at: L.isoZ() } }, inviteEmail(s, e, x, 'their turn'));
    }
    if (!ops.length) continue;
    try { L.write(ops); out.turns += 1; } catch { /* another run took it */ }
  }
}

function remind(s, out, daily) {
  const rows = L.all(`SELECT x.*, e.title, e.expires_on, e.status AS env_status, e.no_markers FROM es_signers x JOIN es_envelopes e ON e._id = x.envelope_id
    WHERE x._deleted = 0 AND e._deleted = 0 AND e.status = 'Out' AND x.status IN ('Invited', 'Opened') AND COALESCE(x.token, '') <> ''`);
  for (const x of rows) {
    const asked = L.toDate(x.remind_asked_at);
    const last = L.toDate(x.last_reminder_at);
    const byHand = asked && (!last || asked > last);
    const since = last || L.toDate(x.invited_at);
    const auto = daily && s.remind_on === 'yes' && (Number(x.reminders) || 0) < MAX_AUTO_REMINDERS && since && (L.now() - since) >= (Number(s.remind_days) || 3) * 86400000 - 3600000;
    if (!byHand && !auto) continue;
    if (L.one("SELECT 1 AS y FROM es_emails WHERE _deleted = 0 AND signer_id = ? AND purpose = 'reminder' AND status IN ('Approved', 'Queued', 'Sending')", x._id)) continue;
    const m = C.mail('reminder', s.language, { name: x.name, company: s.company_name, title: x.title, link: linkOf(s, x.token), expires: dayWords(s, x.expires_on) });
    try {
      L.write([{ op: 'update', table: 'es_signers', id: x._id, data: { reminders: (Number(x.reminders) || 0) + 1, last_reminder_at: L.isoZ() } },
        { op: 'insert', table: 'es_emails', data: { envelope_id: x.envelope_id, signer_id: x._id, purpose: 'reminder', to_email: C.normEmail(x.email), subject: m.subject, body: m.body, status: byHand ? 'Approved' : 'Queued', approved_by: byHand ? 'Remind' : '' } }]);
      out.reminders += 1;
    } catch { /* moved on */ }
  }
}

/** A Void that a person pressed in the desk: its event, once (who and why are on the envelope). */
function voided(out) {
  for (const e of L.all(`SELECT * FROM es_envelopes e WHERE e._deleted = 0 AND e.status = 'Void' AND e.sent_at IS NOT NULL
    AND NOT EXISTS (SELECT 1 FROM es_events v WHERE v.envelope_id = e._id AND v._deleted = 0 AND v.event = 'voided')`)) {
    try { L.write(L.eventOps(e, [{ event: 'voided', who: e.voided_by || '', detail: e.void_reason || '' }])); out.voided += 1; } catch { /* another run wrote it */ }
  }
}

function expire(s, out) {
  const today = C.today(s.timezone);
  for (const e of L.all("SELECT * FROM es_envelopes WHERE _deleted = 0 AND status = 'Out' AND COALESCE(expires_on, '') <> '' AND expires_on < ?", today)) {
    try { L.write([{ op: 'update', table: 'es_envelopes', id: e._id, when: { status: 'Out' }, data: { status: 'Expired', expired_at: L.isoZ() } }, ...L.eventOps(e, [{ event: 'expired', detail: `Not signed by ${e.expires_on}` }])]); out.expired += 1; } catch { /* moved */ }
  }
}

/** The sealed rows of every signer whose page may have changed. */
async function links(s, out) {
  const envs = L.all(`SELECT * FROM es_envelopes WHERE _deleted = 0 AND sent_at IS NOT NULL AND status <> 'Draft'
    AND (status = 'Out' OR datetime(_updated_at) >= datetime(?, '-30 days') OR (status = 'Completed' AND finish_status <> 'Done'))`, L.sqlNow());
  for (const e of envs) {
    const signers = L.all('SELECT * FROM es_signers WHERE envelope_id = ? AND _deleted = 0 ORDER BY ord, _id', e._id);
    const have = new Map(L.all('SELECT signer_id, part, hash FROM es_links WHERE envelope_id = ? AND _deleted = 0', e._id).map((r) => [`${r.signer_id}:${r.part}`, r]));
    const docParts = L.all('SELECT part, body FROM es_docs WHERE envelope_id = ? AND _deleted = 0 ORDER BY part', e._id);
    const pdfParts = e.finish_status === 'Done' ? L.all('SELECT part, body FROM es_pdf WHERE envelope_id = ? AND _deleted = 0 ORDER BY part', e._id) : [];
    for (const me of signers.filter((x) => x.token)) {
      const ops = [];
      const put = async (part, value, hash) => {
        const old = have.get(`${me._id}:${part}`);
        if (old && old.hash === hash) return;
        const row = { envelope_id: e._id, signer_id: me._id, part, k: await C.linkKey(me.token, part), box: await C.seal(me.token, value), hash, built_at: L.sqlNow() };
        if (old) {
          const id = (L.one('SELECT _id FROM es_links WHERE signer_id = ? AND part = ? AND _deleted = 0', me._id, part) || {})._id;
          ops.push({ op: 'update', table: 'es_links', id, data: row });
        } else ops.push({ op: 'insert', table: 'es_links', data: row });
      };
      for (const p of docParts) await put(C.PART.doc(p.part), p.body, `doc:${e.source_sha256}:${p.part}:${L.sha256(p.body)}`);
      for (const p of pdfParts) await put(C.PART.pdf(p.part), p.body, `pdf:${e.final_sha256}:${p.part}`);
      const state = C.stateFor({ envelope: e, signers, me, settings: s, docParts: docParts.length, pdfParts: pdfParts.length || 0 });
      await put(C.PART.state, state, L.sha256(JSON.stringify(state)));
      if (!ops.length) continue;
      try { L.write(ops); out.links += ops.length; } catch (err) { out.errors.push(`links of signer ${me._id}: ${err.message}`); }
    }
  }
}

async function run(mode = '--auto', { dry = false } = {}) {
  const held = dry ? { release() {} } : L.lock('docs');
  if (!held) return { ok: true, mode, skipped: 'Another run is updating' };
  try {
    const s = L.settings();
    const out = { ok: true, mode, sent: 0, refused: 0, turns: 0, reminders: 0, expired: 0, voided: 0, links: 0, errors: [] };
    if (!s.public_url && !L.LOCAL) out.errors.push('Settings has no address for the signing page: install Sign again');
    if (dry) {
      return Object.assign(out, { dry: true, to_send: L.all("SELECT _id FROM es_envelopes WHERE _deleted = 0 AND status = 'Draft' AND send_asked_at IS NOT NULL AND sent_at IS NULL").map((x) => x._id) });
    }
    send(s, out);
    turns(s, out);
    remind(s, out, mode === '--daily');
    expire(s, out);
    voided(out);
    await links(L.settings(), out);
    if (!out.errors.length) delete out.errors;
    return out;
  } finally { held.release(); }
}

if (require.main === module) {
  const a = process.argv.slice(2);
  run(a.includes('--daily') ? '--daily' : '--auto', { dry: a.includes('--dry-run') })
    .then((r) => L.done(r), (e) => { L.done({ ok: false, error: e.message }); process.exitCode = 1; });
}
module.exports = { run, refusal, firstWave, links };
