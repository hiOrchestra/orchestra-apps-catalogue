'use strict';
/**
 * Sign · Send emails, in plain text, through the sender Settings chose: the
 * company's Gmail or its Resend (Composio integrations, connected in
 * Orchestra → Integrations). Appointments' send.js, for Sign's four kinds:
 *
 *   invite      Approved   a person's Send (or the signer's turn, in order)
 *   reminder    Approved   a person's Remind; Queued with "remind on their own"
 *   code        Queued     the signer asked for it on their page
 *   completed   Queued     everyone signed: their link to the signed PDF
 *
 * Each email is CLAIMED before the sender is called (→ Sending, atomic), so
 * none leaves twice. One left Sending (a run that died, a sender that did not
 * answer) is Failed and says it may have gone out: never retried blind. An
 * invitation, reminder or code whose envelope is no longer Out is Dropped. A
 * sent one adds its event (invited, reminded, code_sent) to the evidence.
 *
 * --check looks at which of Gmail and Resend is connected and notes it in
 * Settings (with no sender chosen yet, it picks the connected one); --auto
 * does it too when the last look is over six hours old or the From changed.
 *   node send.js [--auto|--check] [--dry-run]
 */
const L = require('./lib');
const C = require('./escore');
const G = require('./composio');

const STALE_MIN = 15;
const LOOK_EVERY_H = 6;
const NAME = { gmail: 'Gmail', resend: 'Resend' };
const WHERE_SENT = { gmail: 'Gmail\'s Sent folder', resend: 'Resend\'s Emails list' };
const EVENT = { invite: 'invited', reminder: 'reminded', code: 'code_sent' };

function readable(e, via = e.via || 'gmail') {
  const t = String(e.message || e);
  const who = NAME[via] || 'Gmail';
  if (e.noFrom) return 'Resend has no From address in Settings: nothing went out. Write one (Settings → Emails), then Send again.';
  if (e.notConnected) return `${who} is not connected: nothing went out. Connect it in Orchestra → Integrations (or choose the other sender in Settings), then Send again. (${t.slice(0, 160)})`;
  if (e.timeout) return `${who} did not answer in time, so it may or may not have gone out. Look in ${WHERE_SENT[via]} before sending again. (${t.slice(0, 160)})`;
  if (via === 'resend' && /not verified|verify your domain/i.test(t)) return `Resend refused the From address: its domain is not verified in your Resend account. Verify it in Resend → Domains, or change the From address in Settings, then Send again. (${t.slice(0, 160)})`;
  return `${who} did not take it: nothing went out. (${t.slice(0, 200)})`;
}

/** Which senders are connected, and what each says; noted in Settings. */
function check(s) {
  const now = L.sqlNow();
  const conn = G.connections();
  const data = { gmail_checked_at: now, resend_checked_at: now };
  if (conn.ok && !conn.has('gmail')) Object.assign(data, { gmail_status: 'not_connected', gmail_note: null });
  else {
    try { Object.assign(data, { gmail_status: 'ok', gmail_account: G.profile() || s.gmail_account || null, gmail_note: null }); } catch (e) {
      Object.assign(data, { gmail_status: e.notConnected ? 'not_connected' : 'error', gmail_note: String(e.message).slice(0, 200) });
    }
  }
  const from = C.normEmail(s.resend_from);
  if (conn.ok && !conn.has('resend')) Object.assign(data, { resend_status: 'not_connected', resend_note: null, resend_domains: null });
  else {
    try { Object.assign(data, { resend_status: 'ok', resend_note: null, resend_domains: JSON.stringify(G.resendDomains().verified) }); } catch (e) {
      if (e.notConnected) Object.assign(data, { resend_status: 'not_connected', resend_note: null, resend_domains: null });
      else {
        try { G.resendPing(); Object.assign(data, { resend_status: 'ok', resend_note: null, resend_domains: null }); } catch (e2) {
          Object.assign(data, { resend_status: e2.notConnected ? 'not_connected' : 'error', resend_note: String(e2.message).slice(0, 200), resend_domains: null });
        }
      }
    }
  }
  const verified = data.resend_domains ? JSON.parse(data.resend_domains) : null;
  Object.assign(data, { resend_checked_from: from,
    resend_from_status: !C.isEmail(from) || data.resend_status !== 'ok' ? null : !verified ? 'unknown' : verified.includes(C.domainOf(from)) ? 'verified' : 'unverified' });
  if (!s.sender) {
    const pick = data.gmail_status === 'ok' ? 'gmail' : data.resend_status === 'ok' ? 'resend' : null;
    if (pick) data.sender = pick;
  }
  L.write([{ op: 'update', table: 'es_settings', id: s._id, data }]);
  const st = C.senders(Object.assign({}, s, data));
  return { ok: true, mode: '--check', sender: st.sender, ready: st.ready, gmail: data.gmail_status, resend: data.resend_status, say: st.say };
}

/** Time for a look: never looked, asked for (Check again), over six hours ago, or the From address changed since. */
function lookDue(s) {
  const last = L.toDate(s.gmail_checked_at);
  if (!last) return true;
  const asked = L.toDate(s.check_asked_at);
  if (asked && asked > last) return true;
  if (C.senderOf(s) === 'resend' && C.normEmail(s.resend_from) !== (s.resend_checked_from || '')) return true;
  return L.now().getTime() - last.getTime() > LOOK_EVERY_H * 3600000;
}

function run(mode = '--auto', { dry = false } = {}) {
  if (mode === '--check') return check(L.settings());
  const waiting = L.one("SELECT COUNT(*) AS n FROM es_emails WHERE _deleted = 0 AND status IN ('Approved', 'Queued', 'Sending')").n;
  let looked;
  if (!dry && lookDue(L.settings())) looked = check(L.settings());
  if (!waiting) return Object.assign({ ok: true, mode, sent: 0 }, looked ? { looked: { gmail: looked.gmail, resend: looked.resend, ready: looked.ready } } : {});
  const held = dry ? { release() {} } : L.lock('send');
  if (!held) return { ok: true, mode, skipped: 'Another run is sending' };
  try {
    const s = L.settings();
    const via = C.senderOf(s);
    const out = { ok: true, mode, via, sent: 0, failed: 0, dropped: 0 };
    if (looked) out.looked = { gmail: looked.gmail, resend: looked.resend, ready: looked.ready };
    if (dry) return Object.assign(out, { dry: true, waiting: L.all("SELECT _id, purpose, to_email FROM es_emails WHERE _deleted = 0 AND status IN ('Queued', 'Approved')") });
    for (const m of L.all(`SELECT _id FROM es_emails WHERE _deleted = 0 AND status = 'Sending' AND datetime(lock_at) <= datetime(?, '-${STALE_MIN} minutes')`, L.sqlNow())) {
      try { L.write([{ op: 'update', table: 'es_emails', id: m._id, when: { status: 'Sending' }, data: { status: 'Failed', error: `The send did not finish, so it may or may not have gone out. Look in ${WHERE_SENT[via]} before sending again.` } }]); } catch { /* moved on */ }
    }
    const late = L.all(`SELECT m._id, m.status FROM es_emails m JOIN es_envelopes e ON e._id = m.envelope_id WHERE m._deleted = 0 AND m.status IN ('Queued', 'Approved')
      AND m.purpose IN ('invite', 'reminder', 'code') AND e.status <> 'Out'`);
    for (const m of late) {
      try { L.write([{ op: 'update', table: 'es_emails', id: m._id, when: { status: m.status }, data: { status: 'Dropped', error: 'Not sent: the envelope was no longer waiting for signatures' } }]); out.dropped += 1; } catch { /* moved on */ }
    }
    for (const m of L.all("SELECT * FROM es_emails WHERE _deleted = 0 AND status IN ('Approved', 'Queued') ORDER BY _id LIMIT 40")) {
      const from = m.status;
      if (!C.isEmail(m.to_email) || !String(m.subject || '').trim() || !String(m.body || '').trim()) {
        try { L.write([{ op: 'update', table: 'es_emails', id: m._id, when: { status: from }, data: { status: 'Failed', error: 'It has no valid address, subject or text: nothing went out.' } }]); } catch { /* moved */ }
        out.failed += 1;
        continue;
      }
      try { L.write([{ op: 'update', table: 'es_emails', id: m._id, when: { status: from }, data: { status: 'Sending', lock_at: L.sqlNow(), error: null } }]); } catch { continue; }
      let res;
      try { res = G.deliver(s, m); } catch (e) {
        L.write([{ op: 'update', table: 'es_emails', id: m._id, data: { status: 'Failed', error: readable(e, via).slice(0, 500) } }]);
        if (e.notConnected) {
          L.write([{ op: 'update', table: 'es_settings', id: s._id, data: via === 'resend' ? { resend_status: 'not_connected', resend_checked_at: L.sqlNow(), resend_note: String(e.message).slice(0, 200) }
            : { gmail_status: 'not_connected', gmail_checked_at: L.sqlNow(), gmail_note: String(e.message).slice(0, 200) } }]);
        }
        out.failed += 1;
        continue;
      }
      const ops = [{ op: 'update', table: 'es_emails', id: m._id, data: { status: 'Sent', sent_at: L.isoZ(), sent_via: via, message_id: res.id || null, error: null } }];
      const env = EVENT[m.purpose] && L.one('SELECT * FROM es_envelopes WHERE _id = ?', m.envelope_id);
      const who = m.signer_id && L.one('SELECT name, email FROM es_signers WHERE _id = ?', m.signer_id);
      if (env) ops.push(...L.eventOps(env, [{ event: EVENT[m.purpose], signer_id: m.signer_id, who: who ? `${who.name} <${who.email}>` : m.to_email, detail: `${NAME[via]} · ${m.to_email}` }]));
      try { L.write(ops); } catch { L.write([ops[0]]); }
      out.sent += 1;
    }
    return out;
  } finally { held.release(); }
}

if (require.main === module) {
  const argv = process.argv.slice(2);
  try { L.done(run(argv.find((a) => ['--auto', '--check'].includes(a)) || '--auto', { dry: argv.includes('--dry-run') })); } catch (e) { L.done({ ok: false, error: e.message }); process.exitCode = 1; }
}
module.exports = { run, readable, check, lookDue };
