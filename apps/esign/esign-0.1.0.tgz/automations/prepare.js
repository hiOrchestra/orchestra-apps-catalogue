'use strict';
/**
 * Sign · Read documents. Two jobs, both scripts, no agent:
 *
 *   sources   the project's files in Orchestra Files that can be signed (md,
 *             docx, html, txt) copied to es_sources, because a page cannot
 *             read the Files API. On "Refresh" (sources_asked_at after
 *             sources_at), and on every run that has an envelope to read.
 *   cert      the tenant's certificate, the first time (seal.js), as this
 *             workflow's agent: the key is readable by it alone.
 *   envelopes a Draft whose file waits to be read (prepare_status Waiting):
 *             claimed (→ Reading, atomic), downloaded, hashed (SHA-256),
 *             converted (convert.js), its markers' roles listed, and the
 *             model stored in pieces in es_docs. A signer row is added for
 *             each role that has none; a role that left the document leaves
 *             its row, which the desk flags and Send refuses. A read that
 *             died is Failed after 5 minutes, never retried on its own.
 *
 *   node prepare.js [--auto|--sources] [--dry-run]
 */
const fs = require('fs');
const os = require('os');
const path = require('path');
const L = require('./lib');
const C = require('./escore');
const { convert, FROM } = require('./convert');
const seal = require('./seal');

const SIGNABLE = Object.keys(FROM);
const STALE_MIN = 5;

function typeOf(f) { return String(f.type || f.ext || path.extname(f.filename || f.name || '').slice(1)).toLowerCase(); }

/** Files → es_sources: insert the new, update what changed, soft-delete what left. */
function sources(s, dry) {
  const r = L.filesList();
  if (!r.ok) {
    if (!dry) L.write([{ op: 'update', table: 'es_settings', id: s._id, data: { sources_at: L.sqlNow(), sources_note: `Files did not answer: ${String(r.why).slice(0, 200)}` } }]);
    return { ok: false, why: r.why };
  }
  const mine = r.files.filter((f) => SIGNABLE.includes(typeOf(f)) && (!f.project || f.project === L.PROJECT));
  const have = new Map(L.all('SELECT * FROM es_sources WHERE _deleted = 0').map((x) => [x.file_id, x]));
  const ops = [];
  const seen = new Set();
  for (const f of mine) {
    seen.add(f.id);
    const data = { file_id: f.id, name: L.clean(f.name, 200), type: typeOf(f), size: Number(f.size) || 0, folder: f.folder || '', modified_at: f.updatedAt || f.createdAt || '', seen_at: L.sqlNow() };
    const old = have.get(f.id);
    if (!old) ops.push({ op: 'insert', table: 'es_sources', data });
    else if (old.name !== data.name || old.modified_at !== data.modified_at || old.folder !== data.folder || Number(old.size) !== data.size) ops.push({ op: 'update', table: 'es_sources', id: old._id, data });
  }
  const gone = [...have.values()].filter((x) => !seen.has(x.file_id)).map((x) => x._id);
  if (dry) return { ok: true, files: mine.length, added: ops.filter((o) => o.op === 'insert').length, gone: gone.length };
  if (ops.length) L.write(ops);
  if (gone.length) L.softDelete('es_sources', gone);
  L.write([{ op: 'update', table: 'es_settings', id: s._id, data: { sources_at: L.sqlNow(), sources_note: null } }]);
  return { ok: true, files: mine.length, changed: ops.length, gone: gone.length };
}

/** Read one envelope's file into es_docs. */
function read(e) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'esign-read-'));
  try {
    const type = String(e.file_type || '').toLowerCase();
    const file = path.join(dir, `source.${type || 'md'}`);
    const got = L.fileDownload(e.file_id, file);
    if (!got.ok) throw new Error(got.notFound ? 'The file is not in Files any more (or this project cannot see it): choose another one.' : `Files did not give the file: ${got.why}`);
    const bytes = fs.readFileSync(file);
    if (!bytes.length) throw new Error('The file is empty.');
    const { doc, notes } = convert(file, type);
    if (!doc.blocks.length) throw new Error('The file has no text to sign.');
    const body = JSON.stringify(doc);
    const parts = C.chunks(body);
    const roles = C.rolesOf(doc);
    return { sha: L.sha256(bytes), parts, bytes: body.length, roles, notes };
  } finally { fs.rmSync(dir, { recursive: true, force: true }); }
}

function envelopes(dry) {
  const out = { read: 0, failed: 0 };
  for (const e of L.all(`SELECT _id FROM es_envelopes WHERE _deleted = 0 AND prepare_status = 'Reading' AND datetime(_updated_at) <= datetime(?, '-${STALE_MIN} minutes')`, L.sqlNow())) {
    try { L.write([{ op: 'update', table: 'es_envelopes', id: e._id, when: { prepare_status: 'Reading' }, data: { prepare_status: 'Failed', prepare_note: 'Reading the file did not finish. Read it again.' } }]); } catch { /* moved on */ }
  }
  const waiting = L.all("SELECT * FROM es_envelopes WHERE _deleted = 0 AND status = 'Draft' AND prepare_status = 'Waiting' ORDER BY _id LIMIT 10");
  if (dry) return Object.assign(out, { waiting: waiting.map((e) => e._id) });
  for (const e of waiting) {
    try { L.write([{ op: 'update', table: 'es_envelopes', id: e._id, when: { prepare_status: 'Waiting', prepare_asked_at: e.prepare_asked_at }, data: { prepare_status: 'Reading', prepare_note: null } }]); } catch { continue; }
    let r;
    try { r = read(e); } catch (err) {
      L.write([{ op: 'update', table: 'es_envelopes', id: e._id, data: { prepare_status: 'Failed', prepare_note: String(err.message).slice(0, 400) } }]);
      out.failed += 1;
      continue;
    }
    const old = L.all('SELECT _id FROM es_docs WHERE envelope_id = ? AND _deleted = 0', e._id).map((x) => x._id);
    if (old.length) L.softDelete('es_docs', old);
    const signers = L.all("SELECT * FROM es_signers WHERE envelope_id = ? AND _deleted = 0 AND status <> 'Removed' ORDER BY ord, _id", e._id);
    const known = new Set(signers.map((x) => C.roleKey(x.role)));
    const ops = r.parts.map((body, i) => ({ op: 'insert', table: 'es_docs', data: { envelope_id: e._id, part: i, body } }));
    let ord = signers.reduce((m, x) => Math.max(m, Number(x.ord) || 0), 0);
    for (const role of r.roles) {
      if (known.has(C.roleKey(role.role))) continue;
      ord += 1;
      ops.push({ op: 'insert', table: 'es_signers', data: { envelope_id: e._id, ord, role: role.role, name: '', email: '', status: 'Waiting', code_tries: 0, reminders: 0 } });
    }
    const title = e.title || String(e.file_name || '').replace(/\.[a-z0-9]+$/i, '').slice(0, 160);
    ops.push({ op: 'update', table: 'es_envelopes', id: e._id, when: { prepare_status: 'Reading' }, data: {
      prepare_status: 'Ready', prepared_at: L.sqlNow(), prepare_note: r.notes.length ? r.notes.join(' · ').slice(0, 600) : null, title,
      source_sha256: r.sha, doc_parts: r.parts.length, doc_bytes: r.bytes, roles: JSON.stringify(r.roles), no_markers: r.roles.length ? 'no' : 'yes' } });
    try { L.write(ops); out.read += 1; } catch (err) {
      L.write([{ op: 'update', table: 'es_envelopes', id: e._id, data: { prepare_status: 'Failed', prepare_note: `Saving the document failed: ${String(err.message).slice(0, 200)}` } }]);
      out.failed += 1;
    }
  }
  return out;
}

async function run(mode = '--auto', { dry = false } = {}) {
  const held = dry ? { release() {} } : L.lock('prepare');
  if (!held) return { ok: true, mode, skipped: 'Another run is reading' };
  try {
    let s = L.settings();
    const out = { ok: true, mode };
    // The certificate is made by the agent the scripts run as (its own Linux
    // user under orch-as), so only that agent can read the key: here, on the
    // first run, which the desk starts by listing the files.
    let has = null;
    try { has = seal.info(); } catch (e) { has = true; out.cert_error = e.message; }
    // Named after the company: made once Settings has its name, and made again
    // when the name changes while nothing has been sealed with it yet.
    const company = String(s.company_name || '').trim();
    const renamed = has && has.subject && company && !has.subject.startsWith(company)
      && !L.one("SELECT 1 AS x FROM es_envelopes WHERE _deleted = 0 AND COALESCE(final_sha256, '') <> ''");
    if (!dry && company && (!has || renamed)) {
      try { out.cert = (await seal.init({ force: !!renamed })).subject; } catch (e) {
        L.write([{ op: 'update', table: 'es_settings', id: s._id, data: { cert_status: 'error', cert_note: String(e.message).slice(0, 300) } }]);
        out.cert_error = e.message;
      }
      s = L.settings();
    }
    const asked = L.toDate(s.sources_asked_at);
    const at = L.toDate(s.sources_at);
    const waiting = L.one("SELECT COUNT(*) AS n FROM es_envelopes WHERE _deleted = 0 AND status = 'Draft' AND prepare_status = 'Waiting'").n;
    if (mode === '--sources' || !at || (asked && asked > at) || waiting) out.sources = sources(s, dry);
    // Envelopes created while this run read: taken now (a burst of New envelopes).
    for (let pass = 0; pass < 5; pass += 1) {
      const r = envelopes(dry);
      out.read = (out.read || 0) + r.read;
      out.failed = (out.failed || 0) + r.failed;
      if (r.waiting) out.waiting = r.waiting;
      if (dry || !r.read && !r.failed) break;
    }
    return out;
  } finally { held.release(); }
}

if (require.main === module) {
  const a = process.argv.slice(2);
  run(a.includes('--sources') ? '--sources' : '--auto', { dry: a.includes('--dry-run') }).then((r) => L.done(r), (e) => { L.done({ ok: false, error: e.message }); process.exitCode = 1; });
}
module.exports = { run, sources, read };
