'use strict';
/**
 * Sign · a file from Orchestra Files (md, docx, html, txt) as the document
 * model of escore.js. pandoc (in the instance image) reads the file into its
 * tree (`-t json`); this turns that tree into our short arrays, keeping only
 * what the renderer draws, and splits every run of text at its markers.
 *
 *   convert(file, type) → { doc: { v: 1, blocks }, notes: [...], images: n }
 *
 * Images come out of a docx with --extract-media and go in as data: URLs
 * (png, jpeg, gif, webp), each up to 300 KB and 1.5 MB in all; the rest are
 * dropped with a note. Footnotes go at the end, numbered. Anything pandoc
 * knows and the model does not (a raw block, a math formula) keeps its text.
 * pandoc's tree shape is the one of pandoc ≥ 2.10 (API 1.21+): the image's
 * 2.17 and the 3.x of a laptop both read here.
 */
const { execFileSync } = require('child_process');
const fs = require('fs');
const os = require('os');
const path = require('path');
const C = require('./escore');

const FROM = { md: 'gfm+pipe_tables+footnotes', markdown: 'gfm+pipe_tables+footnotes', docx: 'docx', html: 'html', htm: 'html', txt: 'markdown' };
const IMG_MAX = 300 * 1024;
const IMGS_MAX = 1536 * 1024;
const MIME = { png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', gif: 'image/gif', webp: 'image/webp' };

function pandoc(file, type, media) {
  const from = FROM[type];
  if (!from) throw Object.assign(new Error(`A .${type} file cannot be signed here: use a Markdown (.md), Word (.docx) or HTML file`), { unsupported: true });
  const args = ['-f', from, '-t', 'json', file];
  if (type === 'docx') args.splice(2, 0, `--extract-media=${media}`);
  try {
    return JSON.parse(execFileSync(process.env.ES_PANDOC || 'pandoc', args, { encoding: 'utf8', timeout: 60000, maxBuffer: 64 << 20 }));
  } catch (e) {
    if (e.code === 'ENOENT') throw new Error('pandoc is not installed on this instance');
    throw new Error(`pandoc could not read the file: ${String(e.stderr || e.message).trim().slice(0, 200)}`);
  }
}

/** pandoc's tree → our blocks. */
function normalize(ast, { media } = {}) {
  const notes = [];
  const footnotes = [];
  let imgBytes = 0;
  let images = 0;

  function image(target, alt) {
    const src = String(target || '');
    let data = null;
    let ext = '';
    if (/^data:image\/(png|jpeg|gif|webp);base64,/.test(src)) {
      data = Buffer.from(src.split(',')[1], 'base64');
      ext = src.slice(11, src.indexOf(';')).replace('jpeg', 'jpg');
    } else if (media && !/^[a-z][a-z0-9+.-]*:/i.test(src)) {
      // Only what pandoc extracted from the file itself, never a path the file names.
      const abs = path.resolve(media, src);
      ext = path.extname(abs).slice(1).toLowerCase();
      if (abs.startsWith(path.resolve(media) + path.sep) && fs.existsSync(abs)) { try { data = fs.readFileSync(abs); } catch { data = null; } }
    }
    const mime = MIME[ext];
    if (!data || !mime) { notes.push(`An image (${alt || src.slice(0, 40) || 'unnamed'}) was left out: only PNG, JPEG, GIF and WebP inside the file are kept`); return null; }
    if (data.length > IMG_MAX || imgBytes + data.length > IMGS_MAX) { notes.push(`An image (${alt || 'unnamed'}) was left out: images are kept up to 300 KB each and 1.5 MB in all`); return null; }
    imgBytes += data.length;
    images += 1;
    return `data:${mime};base64,${data.toString('base64')}`;
  }

  /** Plain text of inlines (alt texts, footnote markers). */
  const textOf = (list) => (list || []).map((x) => (x.t === 'Str' ? x.c : ['Space', 'SoftBreak', 'LineBreak'].includes(x.t) ? ' ' : Array.isArray(x.c) ? textOf(x.c.find(Array.isArray) || []) : '')).join('');

  /** Inlines, with adjacent text merged before splitting at markers (a docx may cut a marker into runs). */
  function inlines(list) {
    const out = [];
    let text = '';
    const flush = () => { if (text) { out.push(...C.splitMarkers(text)); text = ''; } };
    const push = (n) => { flush(); if (n !== null && n !== undefined) out.push(n); };
    for (const x of list || []) {
      switch (x.t) {
        case 'Str': text += x.c; break;
        case 'Space': case 'SoftBreak': text += ' '; break;
        case 'LineBreak': push(['br']); break;
        case 'Emph': push(['i', inlines(x.c)]); break;
        case 'Strong': push(['b', inlines(x.c)]); break;
        case 'Underline': push(['u', inlines(x.c)]); break;
        case 'Strikeout': push(['s', inlines(x.c)]); break;
        case 'Superscript': push(['sup', inlines(x.c)]); break;
        case 'Subscript': push(['sub', inlines(x.c)]); break;
        case 'SmallCaps': push(['sc', inlines(x.c)]); break;
        case 'Quoted': { const single = x.c[0].t === 'SingleQuote'; text += single ? '‘' : '“'; flush(); out.push(...inlines(x.c[1])); text += single ? '’' : '”'; break; }
        case 'Cite': flush(); out.push(...inlines(x.c[1])); break;
        case 'Code': push(['code', x.c[1]]); break;
        case 'Math': text += x.c[1]; break;
        case 'RawInline': break;
        case 'Link': { const href = x.c[2][0]; const kids = inlines(x.c[1]); push(C.SAFE_HREF.test(href) ? ['a', href, kids] : null); if (!C.SAFE_HREF.test(href)) out.push(...kids); break; }
        case 'Image': { const src = image(x.c[2][0], textOf(x.c[1])); push(src ? ['img', src, textOf(x.c[1]).slice(0, 200)] : null); break; }
        case 'Note': { footnotes.push(x.c); text += `[${footnotes.length}]`; break; }
        case 'Span': flush(); out.push(...inlines(x.c[1])); break;
        default: if (Array.isArray(x.c)) { const inner = x.c.find((y) => Array.isArray(y) && (y.length === 0 || (y[0] && y[0].t))); if (inner) { flush(); out.push(...inlines(inner)); } }
      }
    }
    flush();
    // Merge strings that ended up next to each other.
    return out.reduce((acc, n) => { if (typeof n === 'string' && typeof acc[acc.length - 1] === 'string') acc[acc.length - 1] += n; else acc.push(n); return acc; }, []).filter((n) => n !== '');
  }

  const ALIGN = { AlignLeft: 'l', AlignRight: 'r', AlignCenter: 'c', AlignDefault: 'l' };
  function table(c) {
    // Table attr caption colspecs head bodies foot (pandoc ≥ 2.10).
    const [, , colspecs, head, bodies, foot] = c;
    const aligns = colspecs.map((s) => ALIGN[(s[0] && s[0].t) || 'AlignDefault'] || 'l');
    const rowsOf = (rows) => rows.map((r) => r[1].map((cell) => blocks(cell[4])));
    const headRows = rowsOf(head[1] || []);
    const bodyRows = [];
    for (const b of bodies) bodyRows.push(...rowsOf(b[2] || []), ...rowsOf(b[3] || []));
    bodyRows.push(...rowsOf((foot && foot[1]) || []));
    return ['tbl', aligns, headRows, bodyRows];
  }

  function blocks(list) {
    const out = [];
    for (const b of list || []) {
      switch (b.t) {
        case 'Header': out.push(['h', b.c[0], inlines(b.c[2])]); break;
        case 'Para': case 'Plain': {
          const inl = inlines(b.c);
          if (inl.length === 1 && Array.isArray(inl[0]) && inl[0][0] === 'img') out.push(['img', inl[0][1], inl[0][2]]);
          else if (inl.length) out.push(['p', inl]);
          break;
        }
        case 'LineBlock': out.push(['p', b.c.flatMap((line, i) => (i ? [['br'], ...inlines(line)] : inlines(line)))]); break;
        case 'BulletList': out.push(['ul', b.c.map(blocks)]); break;
        case 'OrderedList': out.push(['ol', b.c[0][0], b.c[1].map(blocks)]); break;
        case 'DefinitionList': for (const [term, defs] of b.c) { out.push(['p', [['b', inlines(term)]]]); for (const d of defs) out.push(...blocks(d)); } break;
        case 'BlockQuote': out.push(['q', blocks(b.c)]); break;
        case 'HorizontalRule': out.push(['hr']); break;
        case 'CodeBlock': out.push(['pre', b.c[1]]); break;
        case 'Table': out.push(table(b.c)); break;
        case 'Div': out.push(...blocks(b.c[1])); break;
        case 'Figure': out.push(...blocks(b.c[2])); break;
        case 'RawBlock': break;
        default: break;
      }
    }
    return out;
  }

  const body = blocks(ast.blocks || []);
  if (footnotes.length) {
    body.push(['hr']);
    footnotes.forEach((note, i) => {
      const inner = blocks(note);
      const first = inner[0] && inner[0][0] === 'p' ? inner.shift() : ['p', []];
      body.push(['p', [`[${i + 1}] `, ...first[1]]], ...inner);
    });
  }
  return { doc: { v: 1, blocks: body }, notes: [...new Set(notes)], images };
}

/** A file on disk → { doc, notes, images }. */
function convert(file, type) {
  const media = fs.mkdtempSync(path.join(os.tmpdir(), 'esign-media-'));
  try {
    const t = String(type || path.extname(file).slice(1)).toLowerCase();
    const ast = pandoc(file, t, media);
    return normalize(ast, { media });
  } finally { fs.rmSync(media, { recursive: true, force: true }); }
}

module.exports = { convert, normalize, pandoc, FROM };
