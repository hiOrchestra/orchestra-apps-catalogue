'use strict';
/**
 * Sign · what the signers' pages sent (es_inbox), judged again here: a page
 * is not to be trusted, a `curl` can call the public action too. A script,
 * no agent. Each row is claimed (New → Done or Rejected, with its verdict);
 * the signer's `last_try` ({ visit, verdict, at }) is how their page learns
 * what happened to what it sent.
 *
 *   open      the first time a signer opens their link: Opened, an event.
 *   code      a six-digit code to their email (at most one a minute): only its
 *             hash is kept, with the time; the email goes on its own (Queued:
 *             they asked for it).
 *   sign      their turn, the envelope Out and not expired, the box ticked, a
 *             name, a signature (a PNG data URL, typed or drawn, ≤ 80 KB) and,
 *             when Settings ask for it, the code (15 minutes, 5 tries). Then
 *             Signed with what they gave and the events code_ok + signed; the
 *             last signature makes the envelope Completed (the PDF follows,
 *             finish.js).
 *   decline   their turn and a reason (optional): the envelope is Declined.
 *
 * The trap field filled, or a signature under 3 s on the page, is Rejected.
 * The PNG and the code leave the inbox row once read (the signer row keeps
 * the PNG; the code is never kept).
 *   node intake.js [--auto] [--dry-run]
 */
const crypto = require('crypto');
const L = require('./lib');
const C = require('./escore');

const PNG = /^data:image\/png;base64,[A-Za-z0-9+/=]+$/;
const PNG_MAX = 80000;
const CODE_EVERY_MS = 60000;

const tryOf = (row, verdict) => JSON.stringify({ visit: String(row.visit || '').slice(0, 64), verdict, at: L.isoZ() });

/** Whether this signer may act now: the envelope Out and not past its day, their status, their turn. */
function mayAct(s, e, me, signers) {
  if (e.status !== 'Out') return { ok: false, verdict: `envelope_${String(e.status || '').toLowerCase()}` };
  if (e.expires_on && e.expires_on < C.today(s.timezone)) return { ok: false, verdict: 'expired' };
  if (!['Invited', 'Opened'].includes(me.status)) return { ok: false, verdict: me.status === 'Signed' ? 'already_signed' : me.status === 'Declined' ? 'already_declined' : 'not_your_turn' };
  const st = C.stateFor({ envelope: e, signers, me, settings: s, docParts: 0 });
  return st.turn ? { ok: true } : { ok: false, verdict: 'not_your_turn' };
}

async function judge(s, row) {
  const reject = (verdict) => ({ status: 'Rejected', verdict });
  if (String(row.hp || '').trim()) return reject('trap');
  if (!C.TOKEN.test(String(row.token || ''))) return reject('no_link');
  const me = L.one('SELECT * FROM es_signers WHERE token = ? AND _deleted = 0', row.token);
  if (!me) return reject('no_link');
  const e = L.one('SELECT * FROM es_envelopes WHERE _id = ? AND _deleted = 0', me.envelope_id);
  if (!e) return reject('no_link');
  const signers = L.all("SELECT * FROM es_signers WHERE envelope_id = ? AND _deleted = 0 AND status <> 'Removed' ORDER BY ord, _id", e._id);
  const ev = { signer_id: me._id, who: `${me.name} <${me.email}>`, ua: L.clean(row.ua, 400), anon: L.clean(row.anon, 80) };
  const base = { signer: me, envelope: e };

  if (row.kind === 'open') {
    if (me.status !== 'Invited' || e.status !== 'Out') return Object.assign(base, { status: 'Done', verdict: 'seen' });
    return Object.assign(base, { status: 'Done', verdict: 'opened', ops: [
      { op: 'update', table: 'es_signers', id: me._id, when: { status: 'Invited' }, data: { status: 'Opened', opened_at: L.isoZ() } },
      ...L.eventOps(e, [Object.assign({ event: 'opened' }, ev)])] });
  }

  const may = mayAct(s, e, me, signers);
  if (!may.ok) return Object.assign(base, reject(may.verdict), { ops: [{ op: 'update', table: 'es_signers', id: me._id, data: { last_try: tryOf(row, may.verdict) } }] });

  if (row.kind === 'code') {
    if (s.require_code === 'no') return Object.assign(base, reject('no_code_needed'));
    const last = L.toDate(me.code_sent_at);
    if (last && L.now() - last < CODE_EVERY_MS) return Object.assign(base, reject('code_too_soon'), { ops: [{ op: 'update', table: 'es_signers', id: me._id, data: { last_try: tryOf(row, 'code_too_soon') } }] });
    const code = String(crypto.randomInt(0, 1000000)).padStart(6, '0');
    const m = C.mail('code', s.language, { name: me.name, title: e.title, code });
    return Object.assign(base, { status: 'Done', verdict: 'code_sent', ops: [
      { op: 'update', table: 'es_signers', id: me._id, data: { code_hash: await C.codeHash(me.token, code), code_sent_at: L.isoZ(), code_tries: 0, last_try: tryOf(row, 'code_sent') } },
      { op: 'insert', table: 'es_emails', data: { envelope_id: e._id, signer_id: me._id, purpose: 'code', to_email: C.normEmail(me.email), subject: m.subject, body: m.body, status: 'Queued' } }] });
  }

  if (row.kind === 'decline') {
    const reason = L.clean(row.reason, 500);
    return Object.assign(base, { status: 'Done', verdict: 'declined', declined: true, ops: [
      { op: 'update', table: 'es_signers', id: me._id, data: { status: 'Declined', declined_at: L.isoZ(), decline_reason: reason, ua: ev.ua, anon: ev.anon, last_try: tryOf(row, 'declined') } },
      { op: 'update', table: 'es_envelopes', id: e._id, when: { status: 'Out' }, data: { status: 'Declined', declined_at: L.isoZ() } },
      ...L.eventOps(e, [Object.assign({ event: 'declined', detail: reason }, ev)])] });
  }

  if (row.kind !== 'sign') return Object.assign(base, reject('unknown'));
  const fail = (verdict, extra = {}) => Object.assign(base, reject(verdict), { ops: [{ op: 'update', table: 'es_signers', id: me._id, data: Object.assign({ last_try: tryOf(row, verdict) }, extra) }] });
  if ((Number(row.ms) || 0) < 3000) return fail('too_fast');
  if (row.consent !== 'yes') return fail('no_consent');
  const name = L.clean(row.name, 120).replace(/\s+/g, ' ');
  if (name.length < 2) return fail('no_name');
  if (!['typed', 'drawn'].includes(row.sig_kind)) return fail('no_signature');
  if (!PNG.test(String(row.sig_png || '')) || String(row.sig_png).length > PNG_MAX) return fail('no_signature');
  const events = [];
  let codeOk = null;
  if (s.require_code !== 'no') {
    const tries = Number(me.code_tries) || 0;
    const sent = L.toDate(me.code_sent_at);
    if (!me.code_hash || !sent) return fail('no_code');
    if (tries >= C.CODE_TRIES) return fail('code_locked');
    if (L.now() - sent > C.CODE_MINUTES * 60000) return fail('code_expired');
    if (!C.CODE.test(String(row.code || '')) || await C.codeHash(me.token, row.code) !== me.code_hash) {
      return Object.assign(fail(tries + 1 >= C.CODE_TRIES ? 'code_locked' : 'code_wrong', { code_tries: tries + 1 }), { events: [Object.assign({ event: 'code_bad' }, ev)] });
    }
    codeOk = L.isoZ();
    events.push(Object.assign({ event: 'code_ok' }, ev));
  }
  events.push(Object.assign({ event: 'signed', detail: `${name} · ${row.sig_kind} · SHA-256 of the signature ${L.sha256(String(row.sig_png))}` }, ev));
  const othersDone = signers.filter((x) => x._id !== me._id).every((x) => x.status === 'Signed');
  const ops = [{ op: 'update', table: 'es_signers', id: me._id, when: { status: me.status }, data: {
    status: 'Signed', signed_at: L.isoZ(), signed_name: name, sig_kind: row.sig_kind, sig_png: row.sig_png, ua: ev.ua, anon: ev.anon,
    consent_at: L.isoZ(), code_ok_at: codeOk, code_hash: null, last_try: tryOf(row, 'signed') } }];
  if (othersDone) {
    events.push({ event: 'completed', detail: `${signers.length} signature${signers.length === 1 ? '' : 's'}` });
    ops.push({ op: 'update', table: 'es_envelopes', id: e._id, when: { status: 'Out' }, data: { status: 'Completed', completed_at: L.isoZ(), finish_status: 'Waiting', finish_note: null } });
  }
  ops.push(...L.eventOps(e, events));
  return Object.assign(base, { status: 'Done', verdict: 'signed', completed: othersDone, ops });
}

async function run(mode = '--auto', { dry = false } = {}) {
  const held = dry ? { release() {} } : L.lock('intake');
  if (!held) return { ok: true, mode, skipped: 'Another run is reading' };
  try {
    const s = L.settings();
    const out = { ok: true, mode, done: 0, rejected: 0, signed: 0, completed: 0, declined: 0 };
    const rows = L.all("SELECT * FROM es_inbox WHERE _deleted = 0 AND status = 'New' ORDER BY _id LIMIT 60");
    for (const row of rows) {
      const v = await judge(s, row);
      if (dry) { out[v.status === 'Done' ? 'done' : 'rejected'] += 1; continue; }
      const close = { op: 'update', table: 'es_inbox', id: row._id, when: { status: 'New' }, data: { status: v.status, verdict: v.verdict, signer_id: v.signer ? v.signer._id : null, processed_at: L.isoZ(), sig_png: '', code: '' } };
      let ops = [close, ...(v.ops || [])];
      if (v.events && v.envelope) ops.push(...L.eventOps(v.envelope, v.events));
      try { L.write(ops); } catch (err) {
        // Something moved meanwhile (another run, the envelope voided): close the row with what happened, nothing else.
        try { L.write([Object.assign({}, close, { data: Object.assign({}, close.data, { status: 'Rejected', verdict: 'changed_meanwhile' }) })]); } catch { /* taken */ }
        out.rejected += 1;
        continue;
      }
      out[v.status === 'Done' ? 'done' : 'rejected'] += 1;
      if (v.verdict === 'signed') out.signed += 1;
      if (v.completed) out.completed += 1;
      if (v.declined) out.declined += 1;
      if (v.verdict === 'signed' || v.declined) {
        const who = `${v.signer.name} (${v.signer.role})`;
        const text = v.declined ? `✋ ${who} declined to sign "${v.envelope.title}".${L.clean(row.reason, 200) ? ` "${L.clean(row.reason, 200)}"` : ''}`
          : v.completed ? `✅ Everyone signed "${v.envelope.title}". The signed PDF is on its way to Files.` : `✍️ ${who} signed "${v.envelope.title}".`;
        if (s.notify_telegram) L.telegram(s.notify_telegram, text);
      }
    }
    return out;
  } finally { held.release(); }
}

if (require.main === module) {
  const a = process.argv.slice(2);
  run('--auto', { dry: a.includes('--dry-run') }).then((r) => L.done(r), (e) => { L.done({ ok: false, error: e.message }); process.exitCode = 1; });
}
module.exports = { run, judge, mayAct };
