'use strict';
/**
 * Sign · the tenant's certificate and the seal on every signed PDF.
 *
 * The certificate is RSA 2048, self-signed, made here in JavaScript (pkijs,
 * WebCrypto): no openssl, no CA. CN = "<company> (Orchestra Sign)", ten years.
 * The private key lives in keys/ next to the scripts (0600; the folder 0700),
 * never in the database and never in the package. Settings shows its
 * subject, SHA-256 fingerprint and end.
 *
 * The seal is PAdES (ETSI.CAdES.detached, @libpdf/core): B-T with an RFC
 * 3161 timestamp from Settings' TSA (DigiCert by default), else B-B with a
 * note. A reader says the document was not changed since; it cannot say who
 * the certificate belongs to, because no CA vouches for it.
 *
 *   node seal.js --init [--force]   make the certificate if there is none (or a new one), and note it in Settings
 *   node seal.js --info             what is there
 */
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const L = require('./lib');

const KEYS = () => process.env.ES_KEYS || path.join(L.HOME, 'keys');
const KEY_FILE = () => path.join(KEYS(), 'key.p8');
const CERT_FILE = () => path.join(KEYS(), 'cert.der');
const YEARS = 10;
let V = null;
const vendor = () => { if (!V) { V = require('./vendor/libpdf.cjs'); V.pkijs.setEngine('node', new V.pkijs.CryptoEngine({ name: 'node', crypto: crypto.webcrypto })); } return V; };
const ALG = { name: 'RSASSA-PKCS1-v1_5', hash: 'SHA-256' };

/** What the certificate says: { subject, fingerprint, not_after } or null when there is none. */
function info() {
  if (!fs.existsSync(CERT_FILE()) || !fs.existsSync(KEY_FILE())) return null;
  try { fs.accessSync(KEY_FILE(), fs.constants.R_OK); } catch {
    throw Object.assign(new Error(`The certificate's key belongs to another agent than the one Sign's workflows run as now (${process.env.ORCHESTRA_AGENT_ID || 'this user'}). Install Sign again with the agent that made it, or remove ${KEYS()} to make a new certificate.`), { foreignKey: true });
  }
  const x = new crypto.X509Certificate(fs.readFileSync(CERT_FILE()));
  return { subject: (x.subject.match(/CN=([^\n]+)/) || [])[1] || x.subject, fingerprint: x.fingerprint256, not_after: new Date(x.validTo).toISOString().slice(0, 10) };
}

/** A new key and self-signed certificate for `company`. */
async function make(company) {
  const { pkijs, asn1js } = vendor();
  const subtle = crypto.webcrypto.subtle;
  const keys = await subtle.generateKey({ ...ALG, modulusLength: 2048, publicExponent: new Uint8Array([1, 0, 1]) }, true, ['sign', 'verify']);
  const cert = new pkijs.Certificate();
  cert.version = 2;
  const serial = crypto.randomBytes(16);
  serial[0] &= 0x7f;
  cert.serialNumber = new asn1js.Integer({ valueHex: serial.buffer.slice(serial.byteOffset, serial.byteOffset + 16) });
  const cn = `${String(company || 'Orchestra').replace(/[\r\n]/g, ' ').trim().slice(0, 40) || 'Orchestra'} (Orchestra Sign)`;
  for (const n of [cert.issuer, cert.subject]) n.typesAndValues.push(new pkijs.AttributeTypeAndValue({ type: '2.5.4.3', value: new asn1js.Utf8String({ value: cn }) }));
  const from = new Date();
  cert.notBefore.value = from;
  cert.notAfter.value = new Date(Date.UTC(from.getUTCFullYear() + YEARS, from.getUTCMonth(), from.getUTCDate()));
  const basic = new pkijs.BasicConstraints({ cA: false });
  cert.extensions = [
    new pkijs.Extension({ extnID: '2.5.29.19', critical: true, extnValue: basic.toSchema().toBER(false), parsedValue: basic }),
    // keyUsage: digitalSignature + nonRepudiation
    new pkijs.Extension({ extnID: '2.5.29.15', critical: true, extnValue: new asn1js.BitString({ valueHex: new Uint8Array([0xc0]).buffer, unusedBits: 6 }).toBER(false) }),
  ];
  await cert.subjectPublicKeyInfo.importKey(keys.publicKey);
  await cert.sign(keys.privateKey, 'SHA-256');
  const der = Buffer.from(cert.toSchema(true).toBER(false));
  const p8 = Buffer.from(await subtle.exportKey('pkcs8', keys.privateKey));
  // On an instance the installer made keys/ (the project's ACL lets this agent write in it); locally it is made here.
  if (!fs.existsSync(KEYS())) fs.mkdirSync(KEYS(), { recursive: true, mode: 0o700 });
  fs.writeFileSync(KEY_FILE(), p8, { mode: 0o600 });
  fs.writeFileSync(CERT_FILE(), der, { mode: 0o644 });
  return info();
}

/** Make the certificate unless there is one (or `force`), and note it in Settings. */
async function init({ force = false } = {}) {
  const s = L.settings();
  let c = force ? null : info();
  const made = !c;
  if (!c) c = await make(s.company_name);
  L.write([{ op: 'update', table: 'es_settings', id: s._id, data: { cert_status: 'ok', cert_subject: c.subject, cert_fingerprint: c.fingerprint, cert_not_after: c.not_after, cert_note: null } }]);
  return Object.assign({ ok: true, made }, c);
}

/**
 * Seal a PDF: { bytes, level: 'B-T'|'B-B', note }. Throws when there is no
 * certificate (the caller says so; nothing is sealed with a stand-in).
 */
async function sealPdf(bytes, { tsaUrl, reason, location } = {}) {
  const c = info();
  if (!c) throw Object.assign(new Error('There is no certificate to seal with: run node seal.js --init (Settings → Signed PDFs → Make the certificate)'), { noCert: true });
  const { PDF, CryptoKeySigner, HttpTimestampAuthority } = vendor();
  const key = await crypto.webcrypto.subtle.importKey('pkcs8', fs.readFileSync(KEY_FILE()), ALG, false, ['sign']);
  const signer = new CryptoKeySigner(key, new Uint8Array(fs.readFileSync(CERT_FILE())), 'RSA', 'RSASSA-PKCS1-v1_5');
  const opts = { signer, reason: reason || 'Signed with Orchestra Sign', location: location || undefined };
  const tsa = String(tsaUrl || '').trim();
  if (tsa && /^https?:\/\//i.test(tsa) && process.env.ES_NO_TSA !== '1') {
    try {
      const pdf = await PDF.load(bytes);
      const r = await pdf.sign(Object.assign({}, opts, { level: 'B-T', timestampAuthority: new HttpTimestampAuthority(tsa, { timeout: 20000 }) }));
      return { bytes: Buffer.from(r.bytes), level: 'B-T', note: null, warnings: r.warnings || [] };
    } catch (e) {
      const pdf = await PDF.load(bytes);
      const r = await pdf.sign(opts);
      return { bytes: Buffer.from(r.bytes), level: 'B-B', note: `Sealed without a timestamp: ${tsa} did not answer (${String(e.message).slice(0, 120)})`, warnings: r.warnings || [] };
    }
  }
  const pdf = await PDF.load(bytes);
  const r = await pdf.sign(opts);
  return { bytes: Buffer.from(r.bytes), level: 'B-B', note: tsa ? null : 'Sealed without a timestamp: no TSA in Settings', warnings: r.warnings || [] };
}

if (require.main === module) {
  const a = process.argv.slice(2);
  (async () => {
    if (a.includes('--info')) return L.done(Object.assign({ ok: true }, info() || { none: true }));
    return L.done(await init({ force: a.includes('--force') }));
  })().catch((e) => { L.done({ ok: false, error: e.message }); process.exitCode = 1; });
}

module.exports = { info, make, init, sealPdf, KEYS };
