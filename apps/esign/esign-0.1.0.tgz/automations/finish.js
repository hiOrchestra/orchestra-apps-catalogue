'use strict';
/**
 * Sign · the signed PDF, once everyone signed (Completed, finish_status
 * Waiting). A script, no agent:
 *
 *   1. the document (es_docs) drawn by the one renderer, every marker filled
 *      with what its signer gave (signature, initials, name, day), and the
 *      certificate page: the envelope, the source file and its SHA-256, each
 *      signer (how they verified their email, when, the browser, the
 *      signature), the events and the head of their chain;
 *   2. printed by the instance's Chromium (pdf.js);
 *   3. sealed with the tenant's certificate (seal.js: PAdES, B-T when the TSA
 *      answers);
 *   4. saved in Orchestra Files (Settings' folder, the envelope's project) and
 *      in pieces in es_pdf, for the signers' pages (docs.js seals them);
 *   5. an email to each signer with their link to download it (Queued: it
 *      closes what the person sent), the event "sealed", Telegram.
 *
 * It is claimed (Waiting → Working, atomic). A failure says why and waits for
 * Try again (finish_status Failed); a run that died is Failed after 10 min.
 *   node finish.js [--auto] [--dry-run]
 */
const fs = require('fs');
const path = require('path');
const L = require('./lib');
const C = require('./escore');
const { toPdf } = require('./pdf');
const { sealPdf, info, init } = require('./seal');

const STALE_MIN = 10;
const PDF_CHUNK = 54000; // base64 characters per es_pdf row

/** The whole HTML of the signed PDF. */
function html({ s, e, doc, signers, events, chain }) {
  const lang = C.langOf(s.language);
  const by = new Map(signers.map((x) => [C.roleKey(x.role), x]));
  const field = (kind, role) => {
    const x = by.get(C.roleKey(role));
    if (!x) return C.pending(kind, role, lang, false);
    return C.filled(kind, { name: x.signed_name || x.name, png: x.sig_png, day: C.longDay(x.signed_at, lang, s.timezone) });
  };
  const extra = e.no_markers === 'yes' ? C.signatureBlocks(signers.map((x) => ({ role: x.role })), lang) : [];
  const body = C.toHtml(C.tree(doc, { field, extra }));
  const cert = C.toHtml(C.certificate({ envelope: e, signers, events, cert: (info() || {}).subject || '', chain, lang }));
  const css = fs.readFileSync(path.join(__dirname, 'paper.css'), 'utf8');
  return `<!doctype html><html lang="${lang}"><head><meta charset="utf-8"><title>${C.toHtml(e.title || '')}</title>
<style>${css}
@page { size: A4; margin: 20mm 18mm; }
html, body { margin: 0; background: #fff; }
.es-paper { border: 0; padding: 0; }
.es-f { min-width: 0; }
</style></head><body><div class="es-paper">${body}</div>${cert}</body></html>`;
}

async function finishOne(s, e) {
  const doc = JSON.parse(L.all('SELECT body FROM es_docs WHERE envelope_id = ? AND _deleted = 0 ORDER BY part', e._id).map((r) => r.body).join(''));
  const signers = L.all("SELECT * FROM es_signers WHERE envelope_id = ? AND _deleted = 0 AND status = 'Signed' ORDER BY ord, _id", e._id);
  const events = L.all('SELECT event, at, who FROM es_events WHERE envelope_id = ? AND _deleted = 0 ORDER BY _id', e._id);
  const chain = L.verifyChain(e._id);
  if (!chain.ok) throw new Error(`The evidence of this envelope does not chain any more (event ${chain.broken_at || 'head'}): it was changed. Nothing was sealed.`);
  // The installer makes the certificate; one that is missing (a restored volume) is made now, so a signed envelope is never left unsealed.
  if (!info()) await init();
  const page = html({ s, e, doc, signers, events, chain: chain.head });
  const printed = await toPdf(page);
  const sealed = await sealPdf(printed, { tsaUrl: s.tsa_url, reason: `Signed by ${signers.map((x) => x.signed_name || x.name).join(', ')} with Orchestra Sign`.slice(0, 200), location: s.company_name || undefined });
  const sha = L.sha256(sealed.bytes);
  const name = `${String(e.title || 'Document').replace(/[\\/:*?"<>|]+/g, ' ').trim().slice(0, 90)} - signed`;
  const up = L.fileUpload({ name, type: 'pdf', bytes: sealed.bytes, folder: s.files_folder || 'Signed', description: `Signed with Orchestra Sign · envelope #${e._id} · SHA-256 ${sha}` });
  if (!up.ok) throw new Error(`Files did not take the signed PDF: ${up.why}`);
  return { sealed, sha, name, file: up.file };
}

async function run(mode = '--auto', { dry = false } = {}) {
  const held = dry ? { release() {} } : L.lock('finish');
  if (!held) return { ok: true, mode, skipped: 'Another run is finishing' };
  try {
    const s = L.settings();
    const out = { ok: true, mode, finished: 0, failed: 0 };
    for (const e of L.all(`SELECT _id FROM es_envelopes WHERE _deleted = 0 AND finish_status = 'Working' AND datetime(_updated_at) <= datetime(?, '-${STALE_MIN} minutes')`, L.sqlNow())) {
      try { L.write([{ op: 'update', table: 'es_envelopes', id: e._id, when: { finish_status: 'Working' }, data: { finish_status: 'Failed', finish_note: 'Making the signed PDF did not finish. Try again.' } }]); } catch { /* moved */ }
    }
    const waiting = L.all("SELECT * FROM es_envelopes WHERE _deleted = 0 AND status = 'Completed' AND finish_status = 'Waiting' ORDER BY _id LIMIT 5");
    if (dry) return Object.assign(out, { waiting: waiting.map((e) => e._id) });
    for (const e of waiting) {
      try { L.write([{ op: 'update', table: 'es_envelopes', id: e._id, when: { finish_status: 'Waiting' }, data: { finish_status: 'Working' } }]); } catch { continue; }
      let r;
      try { r = await finishOne(s, e); } catch (err) {
        L.write([{ op: 'update', table: 'es_envelopes', id: e._id, data: { finish_status: 'Failed', finish_note: String(err.message).slice(0, 500) } }]);
        out.failed += 1;
        if (s.notify_telegram) L.telegram(s.notify_telegram, `⚠️ The signed PDF of "${e.title}" could not be made: ${String(err.message).slice(0, 200)}`);
        continue;
      }
      const b64 = r.sealed.bytes.toString('base64');
      const parts = [];
      for (let i = 0; i < b64.length; i += PDF_CHUNK) parts.push(b64.slice(i, i + PDF_CHUNK));
      const old = L.all('SELECT _id FROM es_pdf WHERE envelope_id = ? AND _deleted = 0', e._id).map((x) => x._id);
      if (old.length) L.softDelete('es_pdf', old);
      L.write(parts.map((body, part) => ({ op: 'insert', table: 'es_pdf', data: { envelope_id: e._id, part, body } })));
      const fresh = L.one('SELECT * FROM es_envelopes WHERE _id = ?', e._id);
      const signers = L.all("SELECT * FROM es_signers WHERE envelope_id = ? AND _deleted = 0 AND status = 'Signed' ORDER BY ord, _id", e._id);
      const ops = [{ op: 'update', table: 'es_envelopes', id: e._id, when: { finish_status: 'Working' }, data: {
        finish_status: 'Done', finish_note: r.sealed.note, final_file_id: r.file.id, final_name: `${r.name}.pdf`, final_sha256: r.sha, final_size: r.sealed.bytes.length, final_parts: parts.length, seal_level: r.sealed.level } }];
      for (const x of signers) {
        const m = C.mail('completed', s.language, { name: x.signed_name || x.name, title: e.title, link: `${s.public_url || ''}#/${x.token}` });
        ops.push({ op: 'insert', table: 'es_emails', data: { envelope_id: e._id, signer_id: x._id, purpose: 'completed', to_email: C.normEmail(x.email), subject: m.subject, body: m.body, status: 'Queued' } });
      }
      ops.push(...L.eventOps(fresh, [{ event: 'sealed', detail: `PAdES ${r.sealed.level} · SHA-256 ${r.sha} · Files ${r.file.id}` }]));
      L.write(ops);
      out.finished += 1;
      if (s.notify_telegram) L.telegram(s.notify_telegram, `📄 "${e.title}" is signed and sealed: ${r.name}.pdf is in Files${s.files_folder ? ` (${s.files_folder})` : ''}.`);
    }
    return out;
  } finally { held.release(); }
}

if (require.main === module) {
  const a = process.argv.slice(2);
  run('--auto', { dry: a.includes('--dry-run') }).then((r) => L.done(r), (e) => { L.done({ ok: false, error: e.message }); process.exitCode = 1; });
}
module.exports = { run, html, finishOne };
