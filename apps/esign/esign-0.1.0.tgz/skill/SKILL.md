---
name: app-esign
version: 0.1.0
description: >-
  Work in the Sign app: documents from Files sent for electronic signature,
  who has signed, the signed PDFs and their evidence. Load it when someone
  says "send this contract for signature / manda esto a firmar", "get Ana to
  sign the NDA / que Ana firme el NDA", "who hasn't signed yet / quién falta
  por firmar", "is the contract signed / ¿ya firmaron el contrato?", "where is
  the signed PDF / dónde está el PDF firmado", "add signature fields / pon
  dónde firma cada uno", or asks about e-signatures, DocuSign or firmas
  electrónicas. Needs the Sign app installed in a project you work in.
metadata:
  openclaw:
    emoji: "✍️"
---
# Sign — documents to sign, and the signed PDFs

A document from Orchestra Files (Markdown, Word or HTML) goes to one or more
people for signature. Each signer gets their own link, confirms their email
with a code, types or draws their signature and agrees, or declines. When all
have signed, a sealed PDF (every signature in its place, plus a certificate
page with the evidence) is saved in Files and emailed to each signer. It is a
simple electronic signature (eIDAS SES, ESIGN/UETA), not an advanced or
qualified one.

```bash
ls -d ~/.openclaw/orchestra/projects/*/apps/esign      # the directory name under projects/ is the project id
P=<project>; T=~/.openclaw/orchestra/projects/$P/apps/esign/automations
orch-canvas url esign                                  # the desk, for the person
```

If nothing is listed, Sign is not installed in a project you work in: say so,
and do not collect signatures any other way.

## What you can do, and what you never do

| You can | With |
|---|---|
| List the files that can be signed | `node $T/esign.js files [--q words]` (`refresh` first if one is missing, then list again after a few seconds) |
| See envelopes and their state | `node $T/esign.js list [--status Out]`, `node $T/esign.js show <id>` (signers, the signed PDF, the last events) |
| Prepare a draft | `node $T/esign.js draft --file <file id> --title "…" --signer "Client|Ana Ruiz|ana@acme.com" [--signer …] [--order in_order] [--message "…"]` |
| Write the document itself | a Markdown file in Files (`files.create`), with markers where each person signs (below) |

**Never:** send an envelope, remind, void, or write to the `es_*` tables by
hand. Send is a person's click in the desk: it emails people outside the
workspace and fixes the document. After `draft`, give the person the desk
link it prints and say that nothing goes out until they press Send there.

## Markers: where each person signs

Write them in the document, in English or Spanish; the text after the colon
is the **role**, and each role is one signer:

| Marker | Shows |
|---|---|
| `{{sign:Client}}` / `{{firma:Cliente}}` | the signature |
| `{{initials:Client}}` / `{{iniciales:Cliente}}` | their initials |
| `{{name:Client}}` / `{{nombre:Cliente}}` | their full name |
| `{{date:Client}}` / `{{fecha:Cliente}}` | the day they signed |

A table works well for two parties:

```markdown
| | Lumen Studio | Client |
|---|---|---|
| Signature | {{sign:Lumen}} | {{sign:Client}} |
| Name | {{name:Lumen}} | {{name:Client}} |
| Date | {{date:Lumen}} | {{date:Client}} |
```

Without markers, a block with name, signature and date is added at the end
for each signer (roles "Signer 1", "Signer 2"…). With `draft`, the `--signer`
roles must be the markers' roles (any case); a role with nobody, or a signer
with a role that is not in the document, makes Send refuse with the reason.

## The model (tables `es_*`, read only for you)

| Table | One row per | Notes |
|---|---|---|
| `es_envelopes` | envelope | `title`, `status` Draft → Out → Completed, or Declined / Void / Expired; `file_name`, `source_sha256`; `order_mode` together / in_order; `expires_on`; once Completed: `finish_status` (Waiting → Done, or Failed with `finish_note`), `final_file_id` (the signed PDF in Files), `final_sha256` |
| `es_signers` | signer | `role`, `name`, `email`, `ord`, `status` Waiting → Invited → Opened → Signed, or Declined (`decline_reason`); `signed_at`, `code_ok_at` |
| `es_events` | event | the evidence, chained by hash: created, sent, invited, opened, code_sent, code_ok, signed, declined, completed, sealed, voided, expired, reminded |
| `es_sources`, `es_docs`, `es_pdf`, `es_links`, `es_inbox`, `es_emails` | files listed, the document, the signed PDF, the signers' sealed pages, what pages sent, emails | scripts only |

Answering "who hasn't signed": `esign.js list --status Out` (it names who
each one waits for). "Where is the signed PDF": `esign.js show <id>` →
`signed_pdf.file_id` is in Files (`files.get`), and every signer can download
it from their link.

## What is behind it

Three workflows, scripts only (no agent turn): **Sign · Read documents**
(lists Files, reads a new envelope's file), **Sign · Signatures** (what
signers did, the signed PDF, sending, the signers' pages, emails), **Sign ·
Daily round** (expiry; reminders only if Settings turn them on). Emails go
through the Gmail or Resend the person connected. The PDF is sealed with the
workspace's own certificate (PAdES, with a timestamp): a reader shows it was
not changed; it does not show who the certificate belongs to. IP addresses
are not recorded.
