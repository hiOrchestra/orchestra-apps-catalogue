// The signing form: the signer's full name, their signature (typed: their
// name drawn in a handwriting face; or drawn with signature_pad), the code
// from their email when Settings ask for it, and their consent. Nothing is
// "signed" until the scripts say so: the page sends one row (`act`), asks for
// it to be read (`process`), and looks until its state answers, then shows
// either the signed document or why not (a wrong code…), keeping what was
// written. Decline asks for an optional reason. On a busy platform a send
// retries on its own for about two minutes.
import { token, words, follow, redraw } from './app.js';

const C = self.EsCore;
const { el } = Orch;
const T0 = Date.now();
const WAITS = [3, 6, 12, 20, 30, 30, 30];
const sleep = (ms) => new Promise((r) => { setTimeout(r, ms); });
const BASE = (() => { const p = location.pathname; const i = p.indexOf('/canvas/a/'); return i < 0 ? '.' : `${p.slice(0, i)}/canvas/a/${p.slice(i + 10).split('/')[0]}`; })();
const visit = (self.crypto && crypto.randomUUID) ? crypto.randomUUID() : `${Date.now()}${Math.random()}`;
const PNG_MAX = 78000;
const HAND = '"Brush Script MT", "Segoe Script", "Snell Roundhand", "Bradley Hand", "URW Chancery L", cursive';
const mask = (email) => { const [u, d] = String(email || '').split('@'); return d ? `${u.slice(0, 2)}•••@${d}` : email; };

/** One row to the page's inbox, then ask for it to be read. Retries a passing failure; throws when it gives up. */
export async function send(row, { quiet = false, status } = {}) {
  const w = words();
  const params = Object.assign({ token, visit, hp: '', ms: Date.now() - T0 }, row);
  for (let i = 0; ; i += 1) {
    try { await Orch.action('act', params); break; } catch (e) {
      const passing = !e.status || e.status === 429 || e.status >= 500;
      if (quiet) return false;
      if (!passing || i >= WAITS.length) throw e;
      for (let s = WAITS[i]; s > 0; s -= 1) { if (status) status.textContent = w.retrying(s); await sleep(1000); }
    }
  }
  process();
  return true;
}
function process() {
  const body = new Blob([JSON.stringify({ params: {} })], { type: 'application/json' });
  try { if (navigator.sendBeacon && navigator.sendBeacon(`${BASE}/api/actions/process`, body)) return; } catch { /* plain call below */ }
  Orch.action('process', {}).catch(() => { /* the half-hourly check takes it */ });
}

export function signForm(st, { myPlaces }) {
  const w = words();
  const host = el('section', { class: 'sp-card sp-sign', id: 'sign' });
  const hp = el('input', { type: 'text', name: 'website', tabindex: '-1', autocomplete: 'off', class: 'sp-hp', 'aria-hidden': 'true' });
  const status = el('p', { class: 'sp-status', role: 'status', 'aria-live': 'polite' });
  const name = el('input', { class: 'oc-input', autocomplete: 'name', maxlength: '120', value: st.me.name || '' });

  // the signature: typed or drawn
  let mode = 'type';
  const typed = el('canvas', { class: 'sp-typed', width: '720', height: '180', 'aria-hidden': 'true' });
  const drawn = el('canvas', { class: 'sp-pad' });
  const pad = self.SignaturePad ? new self.SignaturePad(drawn, { penColor: '#1b1b1a', minWidth: 0.8, maxWidth: 2.6 }) : null;
  const paint = () => {
    const g = typed.getContext('2d');
    g.clearRect(0, 0, typed.width, typed.height);
    g.fillStyle = '#1b1b1a';
    let size = 76;
    const text = name.value.trim() || ' ';
    do { g.font = `${size}px ${HAND}`; size -= 4; } while (g.measureText(text).width > typed.width - 40 && size > 24);
    g.textBaseline = 'middle';
    g.fillText(text, 20, typed.height / 2 + 6);
  };
  name.addEventListener('input', paint);
  const fitPad = () => {
    const r = Math.max(window.devicePixelRatio || 1, 1);
    const data = pad && !pad.isEmpty() ? pad.toData() : null;
    drawn.width = drawn.offsetWidth * r;
    drawn.height = drawn.offsetHeight * r;
    drawn.getContext('2d').scale(r, r);
    if (pad) { pad.clear(); if (data) pad.fromData(data); }
  };
  const typeBox = el('div', { class: 'sp-sigbox' }, [typed, el('p', { class: 'sp-small sp-muted' }, w.typeHelp)]);
  const drawBox = el('div', { class: 'sp-sigbox', hidden: true }, [drawn, el('div', { class: 'sp-row' }, [el('p', { class: 'sp-small sp-muted' }, w.drawHelp),
    el('button', { type: 'button', class: 'sp-link', onClick: () => pad && pad.clear() }, w.clear)])]);
  const tab = (m, label) => el('button', { type: 'button', role: 'tab', class: 'sp-tab', 'aria-selected': String(m === mode), onClick: (ev) => {
    mode = m;
    for (const b of ev.currentTarget.parentNode.children) b.setAttribute('aria-selected', String(b === ev.currentTarget));
    typeBox.hidden = m !== 'type';
    drawBox.hidden = m !== 'draw';
    if (m === 'draw') requestAnimationFrame(fitPad);
  } }, label);

  // the code
  let code = null;
  let codeRow = null;
  if (st.require_code) {
    code = el('input', { class: 'oc-input sp-code', id: 'sp-code', inputmode: 'numeric', autocomplete: 'one-time-code', maxlength: '6', pattern: '[0-9]{6}', placeholder: '000000' });
    const ask = el('button', { type: 'button', class: 'oc-btn' }, st.me.code_sent_at ? w.codeAgain : w.codeSend);
    const said = el('p', { class: 'sp-small sp-muted' }, st.me.code_sent_at ? w.codeSent(mask(st.me.email)) : w.codeWhy);
    ask.addEventListener('click', async () => {
      ask.disabled = true;
      try { await send({ kind: 'code' }, { status: said }); } catch { said.textContent = w.failed; ask.disabled = false; return; }
      said.textContent = w.codeSent(mask(st.me.email));
      code.focus();
      for (let s = 60; s > 0; s -= 1) { ask.textContent = `${w.codeAgain} (${s})`; await sleep(1000); }
      ask.textContent = w.codeAgain;
      ask.disabled = false;
    });
    codeRow = el('div', { class: 'sp-stack' }, [el('label', { class: 'oc-label', for: 'sp-code' }, w.code), el('div', { class: 'sp-row sp-row--start' }, [code, ask]), said]);
  }

  const consent = el('input', { type: 'checkbox' });
  const go = el('button', { type: 'submit', class: 'oc-btn oc-btn--primary sp-big' }, w.sign);
  const form = el('form', { class: 'sp-stack', novalidate: true }, [
    el('label', { class: 'oc-field' }, [el('span', { class: 'oc-label' }, w.name), name]),
    el('div', { class: 'sp-stack' }, [el('span', { class: 'oc-label' }, w.how), el('div', { class: 'sp-tabs', role: 'tablist' }, [tab('type', w.type), tab('draw', w.draw)]), typeBox, drawBox]),
    codeRow,
    el('label', { class: 'sp-check' }, [consent, el('span', w.consent)]),
    hp, go, status,
    el('button', { type: 'button', class: 'sp-link', onClick: () => declineView() }, w.decline),
  ]);

  form.addEventListener('submit', async (ev) => {
    ev.preventDefault();
    const fullName = name.value.trim().replace(/\s+/g, ' ');
    if (fullName.length < 2) { status.textContent = w.needName; name.focus(); return; }
    if (mode === 'draw' && (!pad || pad.isEmpty())) { status.textContent = w.needSig; return; }
    if (code && !C.CODE.test(code.value.trim())) { status.textContent = w.needCode; code.focus(); return; }
    if (!consent.checked) { status.textContent = w.needConsent; return; }
    if (mode === 'type') paint();
    const png = shrink(mode === 'type' ? typed : drawn);
    if (!png) { status.textContent = w.needSig; return; }
    go.disabled = true;
    go.textContent = w.signing;
    status.textContent = '';
    try { await send({ kind: 'sign', name: fullName, code: code ? code.value.trim() : '', sig_kind: mode === 'type' ? 'typed' : 'drawn', sig_png: png, consent: 'yes', hp: hp.value || '' }, { status }); } catch {
      status.textContent = w.failed; go.disabled = false; go.textContent = w.sign; return;
    }
    status.textContent = w.checking;
    const now = await follow((x) => x.me.status === 'Signed' || (x.me.last_try && x.me.last_try.includes(visit) && !/code_sent/.test(x.me.last_try)));
    if (now && now.me.status === 'Signed') { redraw(now); window.scrollTo({ top: 0, behavior: 'smooth' }); return; }
    let verdict = '';
    try { const t = JSON.parse(now ? now.me.last_try : '{}'); if (t.visit === visit) verdict = t.verdict; } catch { /* none */ }
    status.textContent = (w.verdict[verdict]) || w.failed;
    go.disabled = false;
    go.textContent = w.sign;
  });

  function declineView() {
    const why = el('textarea', { class: 'oc-textarea', rows: '3', maxlength: '500' });
    const no = el('button', { type: 'submit', class: 'oc-btn' }, w.declineGo);
    const f = el('form', { class: 'sp-stack' }, [el('label', { class: 'oc-field' }, [el('span', { class: 'oc-label' }, w.declineWhy), why]),
      el('div', { class: 'sp-row sp-row--start' }, [no, el('button', { type: 'button', class: 'oc-btn oc-btn--ghost', onClick: () => Orch.mount(host, [el('h2', { class: 'sp-h2' }, w.signTitle), form]) }, w.keep)]), status]);
    f.addEventListener('submit', async (ev) => {
      ev.preventDefault();
      no.disabled = true;
      try { await send({ kind: 'decline', reason: why.value.trim() }, { status }); } catch { status.textContent = w.failed; no.disabled = false; return; }
      status.textContent = w.checking;
      const now = await follow((x) => x.me.status === 'Declined' || x.status !== 'Out');
      if (now) redraw(now); else { status.textContent = w.failed; no.disabled = false; }
    });
    Orch.mount(host, [el('h2', { class: 'sp-h2' }, w.decline), f]);
  }

  Orch.mount(host, [el('h2', { class: 'sp-h2' }, w.signTitle), el('p', { class: 'sp-small sp-muted' }, w.yourPlaces(myPlaces)), form]);
  requestAnimationFrame(paint);
  window.addEventListener('resize', () => { if (mode === 'draw') fitPad(); });
  return host;
}

/** The signature as a PNG data URL under the action's size: trimmed to the ink, scaled down until it fits. */
function shrink(canvas) {
  const g = canvas.getContext('2d');
  const { width, height } = canvas;
  const data = g.getImageData(0, 0, width, height).data;
  let x0 = width; let y0 = height; let x1 = -1; let y1 = -1;
  for (let y = 0; y < height; y += 1) for (let x = 0; x < width; x += 1) if (data[(y * width + x) * 4 + 3] > 8) { if (x < x0) x0 = x; if (x > x1) x1 = x; if (y < y0) y0 = y; if (y > y1) y1 = y; }
  if (x1 < 0) return null;
  const pad = 8;
  x0 = Math.max(0, x0 - pad); y0 = Math.max(0, y0 - pad); x1 = Math.min(width - 1, x1 + pad); y1 = Math.min(height - 1, y1 + pad);
  for (let scale = Math.min(1, 600 / (x1 - x0 + 1)); scale > 0.1; scale *= 0.75) {
    const out = document.createElement('canvas');
    out.width = Math.max(1, Math.round((x1 - x0 + 1) * scale));
    out.height = Math.max(1, Math.round((y1 - y0 + 1) * scale));
    out.getContext('2d').drawImage(canvas, x0, y0, x1 - x0 + 1, y1 - y0 + 1, 0, 0, out.width, out.height);
    const png = out.toDataURL('image/png');
    if (png.length <= PNG_MAX) return png;
  }
  return null;
}
