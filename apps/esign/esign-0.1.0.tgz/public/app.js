// The signer's page. #/<token> is the whole address: the page hashes it to
// find this signer's rows in the public view `sign_links` (their state '0',
// the document 'd<i>', the signed PDF 'p<i>') and opens them with it. Nothing
// is readable without the link, and the token never leaves the browser.
//
// What it shows follows the state the scripts sealed: the form when it is
// this signer's turn (sign.js), else what happened (signed, declined, not
// your turn, voided, expired), and the signed PDF once it exists. The first
// visit tells the sender it was opened (`act` kind open).
import './escore.js';
import { WORDS, guessLang } from './words.js';
import { signForm, send } from './sign.js';

const C = self.EsCore;
const { el } = Orch;
const sleep = (ms) => new Promise((r) => { setTimeout(r, ms); });
export const token = decodeURIComponent(location.hash.replace(/^#\/?/, '').split(/[/?&]/)[0] || '');
let w = WORDS[guessLang()];
export const words = () => w;

function show(...nodes) {
  Orch.mount('page', nodes);
  const h = document.querySelector('#page h1');
  if (h) h.focus({ preventScroll: true });
}
const card = (title, text, extra, tone) => el('section', { class: `sp-card${tone ? ` sp-card--${tone}` : ''}`, 'aria-live': 'polite' }, [title ? el('h2', { class: 'sp-h2' }, title) : null, text ? el('p', text) : null, extra || null]);
const stateCard = (title, text, extra) => el('section', { class: 'sp-card sp-state' }, [el('h1', { class: 'sp-title', tabindex: '-1' }, title), text ? el('p', text) : null, extra || null]);

/** This signer's state; null when the link opens nothing. Throws on a platform error. */
export async function fetchState() {
  const r = await Orch.db.view('sign_links', { filter: { k: await C.linkKey(token, C.PART.state) }, limit: 1 });
  const row = (r.rows || [])[0];
  return row ? C.open(token, row.box) : null;
}
/** Several sealed parts in one read: their values in order (null when one is missing). */
async function parts(names) {
  const keys = await Promise.all(names.map((n) => C.linkKey(token, n)));
  const out = new Map();
  for (let i = 0; i < keys.length; i += 40) {
    const r = await Orch.db.view('sign_links', { filter: { k: keys.slice(i, i + 40) }, limit: 40 });
    for (const row of r.rows || []) out.set(row.k, row.box);
  }
  const values = await Promise.all(keys.map((k) => (out.has(k) ? C.open(token, out.get(k)) : null)));
  return values.some((v) => v === null) ? null : values;
}

let docCache = null;
async function docOf(st) {
  if (docCache) return docCache;
  const list = await parts(Array.from({ length: st.doc.parts }, (_, i) => C.PART.doc(i)));
  if (!list) return null;
  try { docCache = JSON.parse(list.join('')); } catch { docCache = null; }
  return docCache;
}

export async function start() {
  if (!C.TOKEN.test(token)) { show(stateCard(w.badTitle, w.badText)); return; }
  show(el('section', { class: 'sp-card sp-state' }, el('p', w.loading)));
  let st;
  let doc;
  try {
    st = await fetchState();
    if (st) doc = await docOf(st);
  } catch (e) {
    if (e.reason === 'public-view-pending' || e.status === 403) show(stateCard(w.pendingTitle, w.pendingText));
    else if (e.status === 429) show(stateCard(w.busyTitle, w.busyText, again()));
    else show(stateCard(w.brokenTitle, w.brokenText, again()));
    return;
  }
  if (!st || !doc) { show(stateCard(w.goneTitle, w.goneText)); return; }
  draw(st, doc);
  opened(st);
}
const again = () => el('button', { type: 'button', class: 'oc-btn', onClick: () => start() }, w.again);

/** Tell the sender it was opened: once per browser, only while invited. */
function opened(st) {
  if (st.me.status !== 'Invited') return;
  const key = `sign:opened:${token}`;
  try { if (localStorage.getItem(key)) return; localStorage.setItem(key, '1'); } catch { /* private window: once per load */ }
  send({ kind: 'open' }, { quiet: true });
}

export function draw(st, doc) {
  w = WORDS[st.lang === 'es' ? 'es' : 'en'];
  document.documentElement.lang = st.lang;
  document.title = `${st.title}${st.company ? ` · ${st.company}` : ''}`;
  const day = (v) => C.longDay(v, st.lang, st.tz);
  const mine = C.roleKey(st.me.role);
  const by = new Map(st.signers.map((x) => [C.roleKey(x.role), x]));
  let myPlaces = 0;
  const field = (kind, role) => {
    const isMe = C.roleKey(role) === mine;
    if (isMe && st.me.status === 'Signed') return C.filled(kind, { name: st.me.signed_name, png: st.me.sig_png, day: day(st.me.signed_at) });
    if (isMe) { myPlaces += 1; return C.pending(kind, role, st.lang, true); }
    const x = by.get(C.roleKey(role));
    const n = C.pending(kind, role, st.lang, false);
    if (x && x.status === 'Signed') { n[1].class += ' es-f--done'; n[2] = [`✓ ${n[2][0]}`]; }
    return n;
  };
  const extra = st.no_markers ? C.signatureBlocks(st.signers.map((x) => ({ role: x.role })), st.lang) : [];
  const sheet = el('div', { class: 'es-paper sp-paper' }, [C.toDom(C.tree(doc, { field, extra }))]);
  show(
    el('div', { class: 'sp-bar' }, [
      el('h1', { class: 'sp-bar__title', tabindex: '-1' }, [el('span', { class: 'oc-eyebrow' }, w.from(st.company)), el('span', st.title)]),
      el('button', { type: 'button', class: 'oc-btn oc-btn--sm sp-print', onClick: () => window.print() }, w.print),
    ]),
    top(st, day),
    sheet,
    el('section', { class: 'sp-card sp-who' }, [
      el('h2', { class: 'sp-h2' }, w.signers),
      el('ul', { class: 'sp-list' }, st.signers.map((x) => el('li', [el('span', `${x.name}${x.mine ? ` (${w.you})` : ''}`), el('span', { class: 'sp-muted' }, ` · ${x.role} · ${w.st[x.status] || x.status}`)]))),
      el('p', { class: 'sp-small sp-muted' }, [`${w.ref(st.ref)} · ${w.sha}: `, el('span', { class: 'sp-mono' }, st.doc.sha256)]),
    ]),
    st.turn ? signForm(st, { myPlaces }) : null,
  );
}

/** What is happening, above the document: one sentence and, at the end, the download. */
function top(st, day) {
  if (st.status === 'Completed') {
    if (!st.pdf) return card(w.doneTitle, w.preparing, null, 'good');
    const dl = el('button', { type: 'button', class: 'oc-btn oc-btn--primary sp-big' }, w.download);
    dl.addEventListener('click', () => download(st, dl));
    return card(w.doneTitle, w.doneText, el('div', { class: 'sp-stack' }, [dl, el('p', { class: 'sp-small sp-muted' }, [`${st.pdf.name} · SHA-256 `, el('span', { class: 'sp-mono' }, st.pdf.sha256)])]), 'good');
  }
  if (st.status === 'Void') return card(null, w.voided, null, 'bad');
  if (st.status === 'Declined') return card(null, st.me.status === 'Declined' ? w.declinedText : w.otherDeclined, null, 'bad');
  if (st.status === 'Expired') return card(null, w.expiredText, null, 'bad');
  if (st.me.status === 'Signed') return card(w.signedTitle, w.signedText(day(st.me.signed_at)), null, 'good');
  if (!st.turn) {
    const before = st.signers.filter((x) => !x.mine && x.status !== 'Signed' && x.ord < (st.signers.find((y) => y.mine) || {}).ord).map((x) => x.name);
    return card(w.turnTitle, w.turnText(before.join(', ') || '…'));
  }
  // Their turn: say so before the document, and take them to the form under it.
  return card(w.readTitle, w.readText(st.expires_on ? day(`${st.expires_on}T12:00:00Z`) : ''), el('a', { class: 'oc-btn oc-btn--primary sp-big', href: '#sign', onClick: (ev) => {
    ev.preventDefault();
    const f = document.getElementById('sign');
    if (f) f.scrollIntoView({ behavior: 'smooth', block: 'start' });
  } }, w.goSign));
}

async function download(st, button) {
  button.disabled = true;
  const label = button.textContent;
  button.textContent = w.downloading;
  try {
    const list = await parts(Array.from({ length: st.pdf.parts }, (_, i) => C.PART.pdf(i)));
    if (!list) throw new Error('missing');
    const bin = atob(list.join(''));
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i += 1) bytes[i] = bin.charCodeAt(i);
    const url = URL.createObjectURL(new Blob([bytes], { type: 'application/pdf' }));
    const a = el('a', { href: url, download: st.pdf.name || 'signed.pdf' });
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 60000);
  } catch { Orch.toast(w.brokenText, { error: true }); }
  button.disabled = false;
  button.textContent = label;
}

/** Look again until the state changed (after an answer); then draw it. Returns the new state or null. */
export async function follow(isDone) {
  for (const s of [2, 3, 3, 4, 5, 6, 8, 10, 12]) {
    await sleep(s * 1000);
    try { const st = await fetchState(); if (st && isDone(st)) return st; } catch { /* keep waiting */ }
  }
  return null;
}
export const redraw = (st) => draw(st, docCache);

window.addEventListener('hashchange', () => location.reload());
start();
