SELECT k, box FROM es_links WHERE _deleted = 0
