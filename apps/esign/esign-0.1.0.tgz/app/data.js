// What the desk reads, the only things it writes, and what the screens share.
// Nothing is sent from here: Send only asks (send_asked_at), and the scripts
// check, seal and email (automations/docs.js). escore.js holds the rules the
// scripts and the signer's page share: the document model and its renderer.
import './escore.js';

export const C = self.EsCore;
const { el } = Orch;

export const T = { settings: 'es_settings', sources: 'es_sources', envelopes: 'es_envelopes', docs: 'es_docs', pdf: 'es_pdf', signers: 'es_signers', events: 'es_events', emails: 'es_emails', contacts: 'crm_contacts' };
export const V = { envelopes: 'envelopes', attention: 'attention' };
export const A = {
  refresh: 'refresh_files', create: 'create_envelope', readAgain: 'read_again', save: 'save_envelope', addSigner: 'add_signer', saveSigner: 'save_signer',
  removeSigner: 'remove_signer', send: 'send_envelope', discard: 'discard_envelope', void: 'void_envelope', remind: 'remind_signer', retryPdf: 'retry_pdf',
  retryEmail: 'retry_email', dropEmail: 'drop_email', settings: 'update_settings', company: 'name_company', check: 'check_senders', dismiss: 'dismiss_start',
};

// The app is served from the instance, not the portal: Integrations is the portal's page (the referrer), else Orchestra's address.
const PORTAL_ORIGIN = (() => {
  try {
    const o = document.referrer ? new URL(document.referrer).origin : '';
    if (/^https:\/\/([a-z0-9-]+\.)*(hiorchestra\.com|orchestra-portal[a-z0-9-]*\.up\.railway\.app)$/.test(o)) return o;
  } catch { /* no referrer */ }
  return 'https://hiorchestra.com';
})();
export const INTEGRATIONS = `${PORTAL_ORIGIN}/portal/integrations`;
export const FILES = `${PORTAL_ORIGIN}/portal/files`;
export const integrations = (text) => el('a', { href: INTEGRATIONS, target: '_top', rel: 'noopener' }, text);

/** Run a declared action, say how it went, and hand back its result (null on failure). */
export async function act(name, params, done) {
  try {
    const r = await Orch.action(name, params);
    if (done) Orch.toast(done);
    return r || {};
  } catch (e) {
    Orch.toast(e.status === 409 ? 'It changed in the meantime: look again.' : (e.message || 'That did not work.'), { error: true });
    return null;
  }
}

let cached = null;
export async function settings(fresh) {
  if (!cached || fresh) cached = (await Orch.db.list(T.settings, { sort: '_id:asc', limit: 1 })).rows[0] || {};
  return cached;
}

/** '2026-10-06 10:00:00' (UTC) or ISO, as a Date. */
export const when = (v) => C.when(v);
export const ago = (v) => { const d = when(v); return d ? Orch.fmt.ago(d.toISOString()) : ''; };
export function day(v) {
  const d = C.realDay(v);
  return d ? new Intl.DateTimeFormat(undefined, { day: 'numeric', month: 'short', year: 'numeric', timeZone: 'UTC' }).format(new Date(`${d}T00:00:00Z`)) : '—';
}
/** A moment in the reader's own time: "6 Oct 2026, 10:04". */
export function moment(v) {
  const d = when(v);
  return d ? new Intl.DateTimeFormat(undefined, { day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' }).format(d) : '—';
}

const TONE = { Completed: 'good', Signed: 'good', Out: 'accent', Invited: 'accent', Opened: 'accent', Declined: 'bad', Void: 'bad', Expired: 'warn', Failed: 'bad', Draft: '', Waiting: '' };
const SAID = { Out: 'Waiting', Invited: 'Invited', Opened: 'Opened', Waiting: 'Not yet', Void: 'Voided' };
export const stateLabel = (s) => SAID[s] || s || '—';
export const badge = (state, said) => el('span', { class: `oc-badge${TONE[state] ? ` oc-badge--${TONE[state]}` : ''}` }, said || stateLabel(state));

export async function copy(text, said) {
  try { await navigator.clipboard.writeText(text); Orch.toast(said || 'Copied.'); } catch { Orch.toast('Select it and copy it.', { error: true }); }
}

/** A dialog that closes when the screen changes. */
export function sheet(content, opts) {
  const d = Orch.dialog(content, opts);
  window.addEventListener('hashchange', () => { try { d.close(); } catch { /* already closed */ } }, { once: true });
  return d;
}

export const head = (title, lede, tools) => el('header', { class: 'es-head' }, [
  el('div', { class: 'es-head__title' }, [el('h1', { class: 'oc-h1 oc-h1--collection' }, title), lede ? el('p', { class: 'oc-lede' }, lede) : null]),
  tools ? el('div', { class: 'es-head__tools' }, tools) : null,
]);
export const input = (value, attrs) => el('input', Object.assign({ class: 'oc-input', value: value == null ? '' : String(value) }, attrs || {}));
export const area = (value, rows, attrs) => el('textarea', Object.assign({ class: 'oc-textarea', rows: String(rows || 3) }, attrs || {}), value == null ? '' : String(value));
export const field = (label, control, help) => el('label', { class: 'oc-field' }, [el('span', { class: 'oc-label' }, label), control, help ? el('span', { class: 'oc-help' }, help) : null]);
export const select = (value, options) => el('select', { class: 'oc-select' }, options.map(([v, label]) => el('option', { value: v, selected: String(v) === String(value) }, label)));

/** A thin row that opens something: a mono first column, the name, a sub-line, and badges on the right. */
export function row({ to, onClick, first, name, sub, right }) {
  const inner = [el('span', { class: 'es-row__first oc-value' }, first || ''), el('span', { class: 'es-row__name' }, [el('span', name || '—'), sub ? el('span', { class: 'es-row__sub' }, sub) : null]),
    el('span', { class: 'es-row__right' }, right || '')];
  return el('li', { class: 'es-row' }, to ? Orch.router.link(to, inner, { class: 'es-row__open' }) : el('button', { type: 'button', class: 'es-row__open', onClick }, inner));
}

/** The document of an envelope, as its model (null when it has not been read). */
export async function docOf(e) {
  if (!e || !Number(e.doc_parts)) return null;
  const parts = (await Orch.db.list(T.docs, { filter: { envelope_id: e._id }, sort: 'part:asc', limit: 200 })).rows || [];
  try { return JSON.parse(parts.map((p) => p.body).join('')); } catch { return null; }
}

/**
 * The sheet as the signers see it: each marker as "Signature · Client", or
 * filled when that signer already signed. `colour` gives each role its place
 * in the legend.
 */
export function paper(doc, e, signers, s) {
  const lang = C.langOf(s.language);
  const by = new Map(signers.map((x) => [C.roleKey(x.role), x]));
  const order = signers.map((x) => C.roleKey(x.role));
  const field = (kind, role) => {
    const x = by.get(C.roleKey(role));
    if (x && x.status === 'Signed') return C.filled(kind, { name: x.signed_name || x.name, png: x.sig_png, day: C.longDay(x.signed_at, lang, s.timezone) });
    const n = C.pending(kind, role, lang, false);
    n[1].class += ` es-f--r${(order.indexOf(C.roleKey(role)) % 6 + 6) % 6}`;
    return n;
  };
  const extra = e.no_markers === 'yes' ? C.signatureBlocks(signers.map((x) => ({ role: x.role })), lang) : [];
  return el('div', { class: 'es-paper' }, [C.toDom(C.tree(doc, { field, extra }))]);
}
