/**
 * Sign · what the desk, the signer's page and the scripts must agree on:
 * the document model and its markers, the one renderer (model → a neutral
 * tree → DOM in a page, HTML for the signed PDF), the signer's sealed link,
 * the certificate page, the emails' words, and who sends them. Pure
 * functions, no database, no DOM of its own. test/sync.js copies it to app/,
 * public/ and automations/.
 *
 * The document model is ours, not the file's HTML: the scripts turn pandoc's
 * tree into it (automations/convert.js), and the renderer only draws what it
 * knows. Blocks and inlines are short arrays:
 *   blocks   ['h', level, inl] · ['p', inl] · ['ul', [[blocks]]] · ['ol', start, [[blocks]]]
 *            ['q', blocks] · ['hr'] · ['pre', text] · ['img', src, alt]
 *            ['tbl', aligns, head: [[cell]], rows: [[cell]]], a cell is [blocks]
 *   inlines  'text' · ['b'|'i'|'u'|'s'|'sup'|'sub'|'sc', inl] · ['code', text]
 *            ['a', href, inl] · ['br'] · ['img', src, alt] · ['f', kind, role]  (a marker)
 *
 * The sealed link is Invoices' (apps/invoices/shared/invcore.js): a public
 * view cannot require a filter, so what it holds means nothing without the
 * link. k = SHA-256("es-k:"+token+":"+part) finds a row, the row is AES-GCM
 * sealed with SHA-256("es-e:"+token), and the token lives after the link's #.
 */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.EsCore = api;
}(typeof self !== 'undefined' ? self : this, () => {
  'use strict';

  const LANGS = ['en', 'es'];
  const EMAIL = /^[^\s@<>(),;:"]+@[^\s@<>(),;:"]+\.[A-Za-z]{2,}$/;
  const normEmail = (v) => String(v || '').trim().toLowerCase();
  const isEmail = (v) => EMAIL.test(normEmail(v)) && normEmail(v).length <= 200;
  const langOf = (v) => (v === 'es' ? 'es' : 'en');

  // ── markers ────────────────────────────────────────────────────────────
  // {{sign:Client}} / {{firma:Cliente}} and the rest, any case, spaces allowed
  // around the parts. The role is free text; two markers with the same role
  // (ignoring case and spaces) belong to the same signer.
  const KINDS = { sign: 'sign', signature: 'sign', firma: 'sign', initials: 'initials', iniciales: 'initials',
    name: 'name', nombre: 'name', date: 'date', fecha: 'date' };
  const MARKER = /\{\{\s*([A-Za-zñÑ]+)\s*:\s*([^{}\n]{1,40}?)\s*\}\}/g;
  const roleKey = (r) => String(r || '').trim().replace(/\s+/g, ' ').toLowerCase();
  const cleanRole = (r) => String(r || '').trim().replace(/\s+/g, ' ').slice(0, 40);

  /** A run of text split at its markers: strings and ['f', kind, role]. Unknown kinds stay text. */
  function splitMarkers(text) {
    const out = [];
    let at = 0;
    MARKER.lastIndex = 0;
    for (let m = MARKER.exec(text); m; m = MARKER.exec(text)) {
      const kind = KINDS[m[1].toLowerCase()];
      const role = cleanRole(m[2]);
      if (!kind || !role) continue;
      if (m.index > at) out.push(text.slice(at, m.index));
      out.push(['f', kind, role]);
      at = m.index + m[0].length;
    }
    if (at < text.length) out.push(text.slice(at));
    return out;
  }

  /** Every marker in a document, in order: [{ kind, role }]. */
  function fieldsOf(doc) {
    const out = [];
    const inl = (list) => { for (const x of list || []) { if (!Array.isArray(x)) continue; if (x[0] === 'f') out.push({ kind: x[1], role: x[2] }); else if (x[0] === 'a') inl(x[2]); else if (Array.isArray(x[1])) inl(x[1]); } };
    const blocks = (list) => {
      for (const b of list || []) {
        if (b[0] === 'h') inl(b[2]); else if (b[0] === 'p') inl(b[1]);
        else if (b[0] === 'ul') b[1].forEach(blocks); else if (b[0] === 'ol') b[2].forEach(blocks);
        else if (b[0] === 'q') blocks(b[1]);
        else if (b[0] === 'tbl') [...b[2], ...b[3]].forEach((row) => row.forEach(blocks));
      }
    };
    blocks(doc && doc.blocks);
    return out;
  }

  /** The roles a document asks to sign, in the order they first appear: [{ role, kinds: [...] }]. */
  function rolesOf(doc) {
    const by = new Map();
    for (const f of fieldsOf(doc)) {
      const k = roleKey(f.role);
      if (!by.has(k)) by.set(k, { role: f.role, kinds: [] });
      if (!by.get(k).kinds.includes(f.kind)) by.get(k).kinds.push(f.kind);
    }
    return [...by.values()];
  }

  // ── the renderer: model → tree ─────────────────────────────────────────
  // A tree node is a string (text) or [tag, attrs, children]. toDom and toHtml
  // are the only two ways out, and both escape every string: nothing from the
  // file is ever markup. Links keep only http(s)/mailto; images only data:
  // URLs of raster types.
  const SAFE_HREF = /^(https?:\/\/|mailto:)/i;
  const SAFE_IMG = /^data:image\/(png|jpeg|gif|webp);base64,[A-Za-z0-9+/=]+$/;
  const INLINE_TAG = { b: 'strong', i: 'em', u: 'u', s: 's', sup: 'sup', sub: 'sub', sc: 'span' };

  /**
   * The document as a tree. ctx.field(kind, role) draws a marker (a node);
   * ctx.extra are blocks appended at the end (the signature blocks of a
   * document without markers).
   */
  function tree(doc, ctx = {}) {
    const field = ctx.field || ((kind, role) => ['span', { class: 'es-f' }, [`[${kind}: ${role}]`]]);
    const inl = (list) => (list || []).map((x) => {
      if (typeof x === 'string') return x;
      switch (x[0]) {
        case 'f': return field(x[1], x[2]);
        case 'br': return ['br', {}, []];
        case 'code': return ['code', {}, [String(x[1] || '')]];
        case 'a': return SAFE_HREF.test(String(x[1] || '')) ? ['a', { href: x[1], rel: 'noopener noreferrer', target: '_blank' }, inl(x[2])] : ['span', {}, inl(x[2])];
        case 'img': return SAFE_IMG.test(String(x[1] || '')) ? ['img', { src: x[1], alt: String(x[2] || '') }, []] : null;
        default: return INLINE_TAG[x[0]] ? [INLINE_TAG[x[0]], x[0] === 'sc' ? { class: 'es-sc' } : {}, inl(x[1])] : null;
      }
    }).filter((n) => n !== null);
    const blocks = (list) => (list || []).map((b) => {
      switch (b[0]) {
        case 'h': return [`h${Math.min(Math.max(Number(b[1]) || 1, 1), 4)}`, {}, inl(b[2])];
        case 'p': return ['p', {}, inl(b[1])];
        case 'ul': return ['ul', {}, b[1].map((it) => ['li', {}, blocks(it)])];
        case 'ol': return ['ol', Number(b[1]) > 1 ? { start: String(b[1]) } : {}, b[2].map((it) => ['li', {}, blocks(it)])];
        case 'q': return ['blockquote', {}, blocks(b[1])];
        case 'hr': return ['hr', {}, []];
        case 'pre': return ['pre', {}, [String(b[1] || '')]];
        case 'img': return SAFE_IMG.test(String(b[1] || '')) ? ['p', { class: 'es-figure' }, [['img', { src: b[1], alt: String(b[2] || '') }, []]]] : null;
        case 'tbl': {
          const al = b[1] || [];
          const cell = (tag) => (c, i) => [tag, al[i] && al[i] !== 'l' ? { class: `es-al-${al[i]}` } : {}, blocks(c)];
          return ['div', { class: 'es-tbl' }, [['table', {}, [
            b[2].length ? ['thead', {}, b[2].map((r) => ['tr', {}, r.map(cell('th'))])] : null,
            ['tbody', {}, b[3].map((r) => ['tr', {}, r.map(cell('td'))])],
          ].filter(Boolean)]]];
        }
        default: return null;
      }
    }).filter((n) => n !== null);
    return ['div', { class: 'es-doc' }, [...blocks(doc && doc.blocks), ...blocks(ctx.extra)]];
  }

  /** The blocks added at the end of a document without markers: one per signer (name, signature, date). */
  function signatureBlocks(roles, lang) {
    const w = DOC_WORDS[langOf(lang)];
    return [['hr'], ['h', 3, [w.signatures]],
      ...roles.map((r) => ['p', [['b', [r.role]], ['br'], `${w.name}: `, ['f', 'name', r.role], ['br'], ['f', 'sign', r.role], ['br'], `${w.date}: `, ['f', 'date', r.role]]])];
  }

  const ESC = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' };
  const esc = (s) => String(s).replace(/[&<>"']/g, (c) => ESC[c]);
  const VOID = new Set(['br', 'hr', 'img']);
  const ATTR = /^(class|href|src|alt|start|rel|target|title|colspan|rowspan|style)$/;
  /** A tree as HTML text (the signed PDF). */
  function toHtml(n) {
    if (n === null || n === undefined) return '';
    if (typeof n === 'string') return esc(n);
    const [tag, attrs, kids] = n;
    const a = Object.entries(attrs || {}).filter(([k, v]) => ATTR.test(k) && v !== undefined && v !== null).map(([k, v]) => ` ${k}="${esc(v)}"`).join('');
    return VOID.has(tag) ? `<${tag}${a}>` : `<${tag}${a}>${(kids || []).map(toHtml).join('')}</${tag}>`;
  }
  /** A tree as DOM nodes (a page). */
  function toDom(n, doc = (typeof document !== 'undefined' ? document : null)) {
    if (n === null || n === undefined) return doc.createTextNode('');
    if (typeof n === 'string') return doc.createTextNode(n);
    const [tag, attrs, kids] = n;
    const e = doc.createElement(tag);
    for (const [k, v] of Object.entries(attrs || {})) if (ATTR.test(k) && k !== 'style' && v !== undefined && v !== null) e.setAttribute(k, String(v));
    for (const k of kids || []) e.appendChild(toDom(k, doc));
    return e;
  }

  // ── what a marker shows ────────────────────────────────────────────────
  const DOC_WORDS = {
    en: { signatures: 'Signatures', name: 'Name', date: 'Date', signHere: 'Sign here', initialsHere: 'Initials', nameHere: 'Your name', dateHere: 'Date',
      of: { sign: 'Signature', initials: 'Initials', name: 'Name', date: 'Date' } },
    es: { signatures: 'Firmas', name: 'Nombre', date: 'Fecha', signHere: 'Firma aquí', initialsHere: 'Iniciales', nameHere: 'Tu nombre', dateHere: 'Fecha',
      of: { sign: 'Firma', initials: 'Iniciales', name: 'Nombre', date: 'Fecha' } },
  };
  /** "A.P." from "Ana Pérez". */
  const initialsOf = (name) => String(name || '').trim().split(/\s+/).filter(Boolean).slice(0, 4).map((p) => `${p[0].toUpperCase()}.`).join('');
  /** A placeholder for a marker nobody filled yet: "Signature · Client". */
  const pending = (kind, role, lang, mine) => ['span', { class: `es-f es-f--${kind}${mine ? ' es-f--me' : ''}` },
    [mine ? DOC_WORDS[langOf(lang)][{ sign: 'signHere', initials: 'initialsHere', name: 'nameHere', date: 'dateHere' }[kind]] : `${DOC_WORDS[langOf(lang)].of[kind]} · ${role}`]];
  /**
   * A marker filled from what a signer gave: { name, png, day } (day as
   * already written for the page). Used for the signed PDF and, for the
   * signer's own fields, on their page once they signed.
   */
  function filled(kind, s) {
    if (kind === 'sign') return SAFE_IMG.test(String(s.png || '')) ? ['img', { class: 'es-sig', src: s.png, alt: s.name || '' }, []] : ['span', { class: 'es-typed' }, [s.name || '']];
    if (kind === 'initials') return ['span', { class: 'es-typed es-typed--initials' }, [initialsOf(s.name)]];
    if (kind === 'name') return ['span', { class: 'es-filled' }, [s.name || '']];
    return ['span', { class: 'es-filled' }, [s.day || '']];
  }

  // ── days and times ─────────────────────────────────────────────────────
  const localeOf = (lang) => (langOf(lang) === 'es' ? 'es-ES' : 'en-GB');
  /** '2026-10-06 10:00:00' (UTC, as rows are stamped) or ISO, as a Date (null when it is not one). */
  function when(v) {
    if (!v) return null;
    const s = String(v).trim();
    const d = new Date(/[zZ]|[+-]\d\d:?\d\d$/.test(s) ? s : `${s.replace(' ', 'T')}Z`);
    return Number.isNaN(d.getTime()) ? null : d;
  }
  const zoneOk = (tz) => { try { new Intl.DateTimeFormat('en', { timeZone: tz }); return true; } catch { return false; } };
  /** "6 October 2026" in a zone. */
  function longDay(v, lang, tz) {
    const d = when(v);
    if (!d) return '';
    return new Intl.DateTimeFormat(localeOf(lang), { day: 'numeric', month: 'long', year: 'numeric', timeZone: zoneOk(tz) ? tz : 'UTC' }).format(d);
  }
  /** "6 Oct 2026, 10:04:31 UTC": the certificate's times, always UTC. */
  function stampUtc(v, lang) {
    const d = when(v);
    if (!d) return '—';
    return `${new Intl.DateTimeFormat(localeOf(lang), { day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: false, timeZone: 'UTC' }).format(d)} UTC`;
  }
  /** 'YYYY-MM-DD' today in a zone. */
  function today(tz, at) {
    const d = at ? new Date(at) : new Date();
    const p = Object.fromEntries(new Intl.DateTimeFormat('en-CA', { year: 'numeric', month: '2-digit', day: '2-digit', timeZone: zoneOk(tz) ? tz : 'UTC' }).formatToParts(d).map((x) => [x.type, x.value]));
    return `${p.year}-${p.month}-${p.day}`;
  }
  function addDays(day, n) {
    const d = new Date(`${day}T00:00:00Z`);
    d.setUTCDate(d.getUTCDate() + Number(n || 0));
    return d.toISOString().slice(0, 10);
  }
  /** A real 'YYYY-MM-DD' or ''. */
  function realDay(v) {
    const s = String(v || '').slice(0, 10);
    if (!/^\d{4}-\d{2}-\d{2}$/.test(s)) return '';
    const d = new Date(`${s}T00:00:00Z`);
    return !Number.isNaN(d.getTime()) && d.toISOString().slice(0, 10) === s ? s : '';
  }

  // ── the sealed link ────────────────────────────────────────────────────
  const subtle = () => (globalThis.crypto && globalThis.crypto.subtle) || null;
  const enc = (s) => new TextEncoder().encode(s);
  const b64u = (bytes) => { let s = ''; const b = new Uint8Array(bytes); for (let i = 0; i < b.length; i += 0x8000) s += String.fromCharCode(...b.subarray(i, i + 0x8000)); return btoa(s).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, ''); };
  const unb64u = (s) => Uint8Array.from(atob(String(s).replace(/-/g, '+').replace(/_/g, '/') + '==='.slice((String(s).length + 3) % 4)), (c) => c.charCodeAt(0));
  const hex = (bytes) => [...new Uint8Array(bytes)].map((b) => b.toString(16).padStart(2, '0')).join('');
  const TOKEN = /^[A-Za-z0-9_-]{22,64}$/;
  /** The part names: '0' the signer's state, 'd<i>' the document, 'p<i>' the signed PDF. */
  const PART = { state: '0', doc: (i) => `d${i}`, pdf: (i) => `p${i}` };
  /** How much text one sealed row carries: it travels through a 128 KB argument as base64 with JSON around it. */
  const CHUNK = 55000;

  function newToken() { const b = new Uint8Array(16); globalThis.crypto.getRandomValues(b); return b64u(b); }
  async function sha256Hex(text) { return hex(await subtle().digest('SHA-256', typeof text === 'string' ? enc(text) : text)); }
  async function linkKey(token, part = PART.state) { return sha256Hex(`es-k:${token}:${part}`); }
  async function boxKey(token, use) {
    const raw = await subtle().digest('SHA-256', enc(`es-e:${token}`));
    return subtle().importKey('raw', raw, { name: 'AES-GCM' }, false, [use]);
  }
  /** A value sealed for its token: base64url(iv ‖ ciphertext+tag). */
  async function seal(token, value) {
    const iv = new Uint8Array(12);
    globalThis.crypto.getRandomValues(iv);
    const ct = await subtle().encrypt({ name: 'AES-GCM', iv }, await boxKey(token, 'encrypt'), enc(JSON.stringify(value)));
    const out = new Uint8Array(12 + ct.byteLength);
    out.set(iv, 0);
    out.set(new Uint8Array(ct), 12);
    return b64u(out);
  }
  /** The value back from its box, or null when the token does not open it. */
  async function open(token, box) {
    try {
      const all = unb64u(box);
      const pt = await subtle().decrypt({ name: 'AES-GCM', iv: all.slice(0, 12) }, await boxKey(token, 'decrypt'), all.slice(12));
      return JSON.parse(new TextDecoder().decode(pt));
    } catch { return null; }
  }
  /** A long text in pieces of at most n characters. */
  const chunks = (text, n = CHUNK) => { const s = String(text || ''); const out = []; for (let i = 0; i < s.length; i += n) out.push(s.slice(i, i + n)); return out.length ? out : ['']; };
  /** The email code's hash: the code alone is six digits, so the token salts it. */
  const codeHash = (token, code) => sha256Hex(`es-c:${token}:${String(code || '').replace(/\D/g, '')}`);
  const CODE = /^\d{6}$/;
  const CODE_MINUTES = 15;
  const CODE_TRIES = 5;

  // ── the signer's state (what the sealed row '0' holds) ─────────────────
  /**
   * What one signer's page needs, from the envelope, its signers (in order),
   * this signer and the settings. Only this signer's email; the others by
   * name and role. `turn`: whether this signer may sign now.
   */
  function stateFor({ envelope: e, signers, me, settings: s, docParts, pdfParts }) {
    const lang = langOf(s.language);
    const live = signers.filter((x) => x.status !== 'Removed');
    const firstOpen = live.filter((x) => !['Signed', 'Declined'].includes(x.status)).map((x) => Number(x.ord) || 0);
    const minOrd = firstOpen.length ? Math.min(...firstOpen) : 0;
    const turn = e.status === 'Out' && ['Invited', 'Opened'].includes(me.status) && (e.order_mode !== 'in_order' || (Number(me.ord) || 0) <= minOrd);
    return {
      v: 1, lang, company: s.company_name || '', title: e.title || '', ref: `${String(e._id).padStart(4, '0')}`,
      status: e.status, expires_on: e.expires_on || '', order_mode: e.order_mode || 'together', no_markers: e.no_markers === 'yes',
      require_code: s.require_code !== 'no', tz: s.timezone || 'UTC',
      me: { role: me.role, name: me.name, email: me.email, status: me.status, signed_at: me.signed_at || '', declined_at: me.declined_at || '',
        signed_name: me.signed_name || '', sig_png: me.status === 'Signed' ? me.sig_png || '' : '', code_sent_at: me.code_sent_at || '', last_try: me.last_try || '' },
      signers: live.map((x) => ({ role: x.role, name: x.name, ord: Number(x.ord) || 0, status: x.status, signed_at: x.signed_at || '', mine: x._id === me._id })),
      turn, doc: { parts: docParts, sha256: e.source_sha256 || '' },
      pdf: pdfParts ? { parts: pdfParts, name: e.final_name || '', sha256: e.final_sha256 || '', size: Number(e.final_size) || 0 } : null,
      declined_at: e.declined_at || '', void_at: e.void_at || '', completed_at: e.completed_at || '',
    };
  }

  // ── the certificate page ───────────────────────────────────────────────
  const CERT_WORDS = {
    en: { title: 'Certificate of completion', envelope: 'Envelope', document: 'Document', source: 'Source file', sha: 'SHA-256 of the source file',
      sent: 'Sent', completed: 'Completed', signers: 'Signers', signed: 'Signed', verified: 'Email verified', code: 'with a code sent to it at signing',
      link: 'by the link sent to it', agent: 'Browser', consent: 'Agreed to sign electronically', events: 'Events', seal: 'Sealed',
      sealText: (c) => `This PDF is sealed with the certificate "${c}". Any change after sealing breaks the seal. The times are the server's, in UTC.`,
      noIp: 'IP addresses are not recorded.', method: 'Signature', typed: 'typed', drawn: 'drawn', chain: 'Event chain (SHA-256 of the last event)' },
    es: { title: 'Certificado de finalización', envelope: 'Sobre', document: 'Documento', source: 'Archivo de origen', sha: 'SHA-256 del archivo de origen',
      sent: 'Enviado', completed: 'Completado', signers: 'Firmantes', signed: 'Firmó', verified: 'Email verificado', code: 'con un código enviado al firmar',
      link: 'por el link enviado a ese email', agent: 'Navegador', consent: 'Aceptó firmar electrónicamente', events: 'Eventos', seal: 'Sellado',
      sealText: (c) => `Este PDF está sellado con el certificado "${c}". Cualquier cambio posterior rompe el sello. Las horas son las del servidor, en UTC.`,
      noIp: 'No se registran direcciones IP.', method: 'Firma', typed: 'escrita', drawn: 'dibujada', chain: 'Cadena de eventos (SHA-256 del último evento)' },
  };
  const EVENT_WORDS = {
    en: { created: 'Created', sent: 'Sent for signature', invited: 'Invitation emailed', opened: 'Opened', code_sent: 'Code emailed', code_ok: 'Code entered',
      code_bad: 'Wrong code', signed: 'Signed', declined: 'Declined', completed: 'Completed', sealed: 'Sealed', voided: 'Voided', expired: 'Expired', reminded: 'Reminder emailed' },
    es: { created: 'Creado', sent: 'Enviado a firmar', invited: 'Invitación enviada', opened: 'Abierto', code_sent: 'Código enviado', code_ok: 'Código correcto',
      code_bad: 'Código incorrecto', signed: 'Firmado', declined: 'Rechazado', completed: 'Completado', sealed: 'Sellado', voided: 'Anulado', expired: 'Vencido', reminded: 'Recordatorio enviado' },
  };
  /**
   * The certificate page as a tree: { envelope, signers, events, cert, lang }.
   * events: [{ event, at, who }] in order; cert: the seal's subject.
   */
  function certificate({ envelope: e, signers, events, cert, chain, lang }) {
    const L = langOf(lang);
    const w = CERT_WORDS[L];
    const ew = EVENT_WORDS[L];
    const row = (k, v, cls) => ['tr', {}, [['th', {}, [k]], ['td', cls ? { class: cls } : {}, [v]]]];
    const signer = (s) => ['div', { class: 'es-cert__signer' }, [
      ['div', { class: 'es-cert__sig' }, [SAFE_IMG.test(String(s.sig_png || '')) ? ['img', { src: s.sig_png, alt: s.signed_name || s.name }, []] : ['span', { class: 'es-typed' }, [s.signed_name || '']]]],
      ['table', { class: 'es-cert__kv' }, [['tbody', {}, [
        row(s.role, `${s.signed_name || s.name} <${s.email}>`),
        row(w.signed, stampUtc(s.signed_at, L)),
        row(w.method, s.sig_kind === 'drawn' ? w.drawn : w.typed),
        row(w.verified, s.code_ok_at ? `${w.code} (${stampUtc(s.code_ok_at, L)})` : w.link),
        row(w.consent, stampUtc(s.consent_at || s.signed_at, L)),
        row(w.agent, String(s.ua || '—').slice(0, 160), 'es-cert__small'),
      ]]]],
    ]];
    return ['section', { class: 'es-cert' }, [
      ['h1', {}, [w.title]],
      ['table', { class: 'es-cert__kv' }, [['tbody', {}, [
        row(w.envelope, `#${String(e._id).padStart(4, '0')} · ${e.title || ''}`),
        row(w.source, e.file_name || '—'),
        row(w.sha, e.source_sha256 || '—', 'es-cert__mono'),
        row(w.sent, stampUtc(e.sent_at, L)),
        row(w.completed, stampUtc(e.completed_at, L)),
      ]]]],
      ['h2', {}, [w.signers]],
      ...signers.map(signer),
      ['h2', {}, [w.events]],
      ['table', { class: 'es-cert__events' }, [['tbody', {}, events.map((x) => ['tr', {}, [['td', { class: 'es-cert__mono' }, [stampUtc(x.at, L)]], ['td', {}, [ew[x.event] || x.event]], ['td', {}, [x.who || '']]]])]]],
      ['p', { class: 'es-cert__small' }, [`${w.chain}: `, ['span', { class: 'es-cert__mono' }, [chain || '—']]]],
      ['p', { class: 'es-cert__small' }, [w.sealText(cert || ''), ' ', w.noIp]],
    ]];
  }

  // ── the emails' words (the signers' language, Settings) ────────────────
  const MAIL = {
    en: {
      invite: (d) => ({ subject: `${d.company ? `${d.company}: ` : ''}please sign "${d.title}"`,
        body: [`Hello ${d.name},`, '', `${d.company || 'We'} sent you "${d.title}" to sign${d.role ? ` as ${d.role}` : ''}.`, d.message ? `\n${d.message}\n` : '',
          'Read and sign it here:', d.link, '', d.expires ? `The link works until ${d.expires}.` : '', 'Only you should use this link: please do not forward it.'].filter((x) => x !== '').join('\n') }),
      reminder: (d) => ({ subject: `Reminder: "${d.title}" is waiting for your signature`,
        body: [`Hello ${d.name},`, '', `"${d.title}" from ${d.company || 'us'} is still waiting for your signature.`, '', d.link, '', d.expires ? `The link works until ${d.expires}.` : ''].filter((x) => x !== '').join('\n') }),
      code: (d) => ({ subject: `${d.code} is your code to sign "${d.title}"`,
        body: [`Hello ${d.name},`, '', `Your code to sign "${d.title}" is:`, '', d.code, '', `It works for ${CODE_MINUTES} minutes. If you did not ask for it, ignore this email.`].join('\n') }),
      completed: (d) => ({ subject: `Signed: "${d.title}"`,
        body: [`Hello ${d.name},`, '', `Everyone signed "${d.title}". Download the signed PDF here:`, d.link, '', 'Keep a copy: it is your record of the agreement.'].join('\n') }),
    },
    es: {
      invite: (d) => ({ subject: `${d.company ? `${d.company}: ` : ''}firma "${d.title}"`,
        body: [`Hola ${d.name}:`, '', `${d.company || 'Te'} te ha enviado "${d.title}" para que lo firmes${d.role ? ` como ${d.role}` : ''}.`, d.message ? `\n${d.message}\n` : '',
          'Léelo y fírmalo aquí:', d.link, '', d.expires ? `El link funciona hasta el ${d.expires}.` : '', 'Este link es solo para ti: no lo reenvíes.'].filter((x) => x !== '').join('\n') }),
      reminder: (d) => ({ subject: `Recordatorio: "${d.title}" espera tu firma`,
        body: [`Hola ${d.name}:`, '', `"${d.title}"${d.company ? ` de ${d.company}` : ''} todavía espera tu firma.`, '', d.link, '', d.expires ? `El link funciona hasta el ${d.expires}.` : ''].filter((x) => x !== '').join('\n') }),
      code: (d) => ({ subject: `${d.code} es tu código para firmar "${d.title}"`,
        body: [`Hola ${d.name}:`, '', `Tu código para firmar "${d.title}" es:`, '', d.code, '', `Funciona durante ${CODE_MINUTES} minutos. Si no lo pediste, ignora este email.`].join('\n') }),
      completed: (d) => ({ subject: `Firmado: "${d.title}"`,
        body: [`Hola ${d.name}:`, '', `Todos firmaron "${d.title}". Descarga el PDF firmado aquí:`, d.link, '', 'Guarda una copia: es tu constancia del acuerdo.'].join('\n') }),
    },
  };
  /** An email's subject and body: purpose invite | reminder | code | completed. */
  const mail = (purpose, lang, d) => MAIL[langOf(lang)][purpose](d);

  // ── who sends the emails: Gmail or Resend (Appointments' rules) ────────
  const senderOf = (s) => (s && s.sender === 'resend' ? 'resend' : 'gmail');
  const domainOf = (address) => (String(address || '').trim().toLowerCase().split('@')[1] || '');
  function fromLine(name, address) {
    const n = String(name || '').replace(/[\r\n<>"\\]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 80);
    const a = normEmail(address);
    if (!n) return a;
    return /[,;:()@[\].]/.test(n) ? `"${n}" <${a}>` : `${n} <${a}>`;
  }
  function verifiedDomains(s) {
    if (!s || s.resend_domains === null || s.resend_domains === undefined || s.resend_domains === '') return null;
    try { const v = JSON.parse(s.resend_domains); return Array.isArray(v) ? v.map((d) => String(d).toLowerCase()) : null; } catch { return null; }
  }
  /** Why the chosen sender cannot send yet, in plain words; null when it can. */
  function senderProblem(s) {
    if (senderOf(s) === 'gmail') {
      if (s.gmail_status === 'ok') return null;
      if (s.gmail_status === 'error') return `Gmail did not answer the last check${s.gmail_note ? ` (${String(s.gmail_note).slice(0, 120)})` : ''}.`;
      return 'Gmail is not connected to this workspace.';
    }
    if (s.resend_status === 'error') return `Resend did not answer the last check${s.resend_note ? ` (${String(s.resend_note).slice(0, 120)})` : ''}.`;
    if (s.resend_status !== 'ok') return 'Resend is not connected to this workspace.';
    const from = normEmail(s.resend_from);
    if (!isEmail(from)) return 'Resend needs a From address: one on a domain verified in your Resend account.';
    const domains = verifiedDomains(s);
    if (domains && !domains.includes(domainOf(from))) return `${domainOf(from)} is not verified in your Resend account${domains.length ? ` (verified: ${domains.join(', ')})` : ''}. Verify it in Resend → Domains, or use an address on a verified domain.`;
    return null;
  }
  /** Where the emails stand: { sender, ready, say }. */
  function senders(s) {
    const sender = senderOf(s);
    const problem = senderProblem(s);
    const ready = !problem && !(sender === 'resend' && s.resend_from_status === 'unverified');
    let say;
    if (!s.gmail_status && !s.resend_status) say = 'Not checked yet which of Gmail or Resend is connected.';
    else if (s.gmail_status !== 'ok' && s.resend_status !== 'ok') say = 'Connect Gmail or Resend in Integrations to email the signers.';
    else if (ready && sender === 'gmail') say = `Emails go out through Gmail${s.gmail_account ? ` (${s.gmail_account})` : ''}.`;
    else if (ready) say = `Emails go out through Resend, from ${fromLine(s.resend_from_name || s.company_name, s.resend_from)}.`;
    else say = problem || 'Resend refused the From address: its domain is not verified.';
    return { sender, ready, say };
  }

  return {
    LANGS, isEmail, normEmail, langOf, KINDS, MARKER, roleKey, cleanRole, splitMarkers, fieldsOf, rolesOf,
    tree, signatureBlocks, toHtml, toDom, DOC_WORDS, initialsOf, pending, filled, SAFE_IMG, SAFE_HREF,
    when, longDay, stampUtc, today, addDays, realDay, zoneOk, localeOf,
    TOKEN, PART, CHUNK, newToken, sha256Hex, linkKey, seal, open, chunks, b64u, unb64u, codeHash, CODE, CODE_MINUTES, CODE_TRIES,
    stateFor, certificate, CERT_WORDS, EVENT_WORDS, mail, senderOf, domainOf, fromLine, senderProblem, senders,
  };
}));
