// The router and the bar. Envelopes is home: what waits for signatures, the
// drafts, what was signed, and what was declined, voided or expired. An
// envelope opens on its own page (/env/<id>): a draft as its editor, a sent
// one as the document with who signed beside it.
import { render as envelopes } from './screens/envelopes.js';
import { render as pick } from './screens/new.js';
import { render as envelope } from './screens/envelope.js';
import { render as settings } from './screens/settings.js';

const { el, router } = Orch;

router.define({
  '/': (p, path) => envelopes({ tab: 'waiting' }, path),
  '/list/:tab': envelopes,
  '/new': pick,
  '/env/:id': envelope,
  '/settings': settings,
}, () => Orch.mount('view', el('div', { class: 'oc-state' }, [
  el('p', 'There is no screen here.'), router.link('/', 'Go to the envelopes'),
]))).start();

Orch.mount('nav', [
  router.link('/', 'Envelopes', { class: 'oc-tab' }),
  router.link('/new', 'New', { class: 'oc-tab' }),
  router.link('/settings', 'Settings', { class: 'oc-tab' }),
]);
