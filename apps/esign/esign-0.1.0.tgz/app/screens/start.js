// Getting started: the two things an envelope cannot go out without, on the
// home screen, checked from the data each time (never ticked by hand). Gone
// once both are done, or dismissed. Everything else has a default in Settings.
import { A, C, act, field, input, integrations } from '../data.js';

const { el } = Orch;

export const companyDone = (s) => !!String(s.company_name || '').trim();
export const senderDone = (s) => C.senders(s).ready;

export function startCard(s, again) {
  if (s.onboarding_dismissed_at) return null;
  const steps = [
    { title: 'Your company', done: companyDone(s), body: company },
    { title: 'Who sends the emails', done: senderDone(s), body: sender },
  ];
  if (steps.every((x) => x.done)) return null;
  const open = steps.find((x) => !x.done);
  return el('section', { class: 'oc-card oc-card--pad0 es-start', 'aria-label': 'Getting started' }, [
    el('div', { class: 'es-start__head' }, [el('h2', { class: 'oc-h2' }, 'Getting started'), el('span', { class: 'oc-value oc-muted' }, `${steps.filter((x) => x.done).length} of ${steps.length}`)]),
    el('p', { class: 'oc-help es-start__lede' }, 'Two things before the first envelope goes out. The rest has a default you can change in Settings.'),
    el('ol', { class: 'es-steps' }, steps.map((x, i) => el('li', { class: `es-step${x.done ? ' es-step--done' : ''}` }, [
      el('div', { class: 'es-step__head' }, [el('span', { class: 'oc-value es-step__n' }, String(i + 1).padStart(2, '0')), el('span', { class: 'es-step__title' }, x.title),
        el('span', { class: `oc-badge${x.done ? ' oc-badge--good' : ''}` }, x.done ? 'Done' : 'To do')]),
      x === open ? el('div', { class: 'es-step__body' }, x.body(s, again)) : null,
    ]))),
  ]);
}

function company(s, again) {
  const name = input(s.company_name, { maxlength: '160', required: true, placeholder: 'Lumen Studio S.L.' });
  const lang = el('select', { class: 'oc-select' }, [['en', 'English'], ['es', 'Español']].map(([v, l]) => el('option', { value: v, selected: (s.language || 'en') === v }, l)));
  const save = el('button', { type: 'submit', class: 'oc-btn oc-btn--primary' }, 'Save and continue');
  const f = el('form', { class: 'oc-stack es-start__form' }, [
    el('p', { class: 'es-step__why' }, 'Signers read who is asking them to sign: your company\'s name is in every email and on their page. It also names the certificate that seals the signed PDFs.'),
    field('Company name', name), field('Signers read', lang, 'The language of their page and of the emails.'),
    el('div', { class: 'oc-row' }, save),
  ]);
  f.addEventListener('submit', async (e) => {
    e.preventDefault();
    if (!String(name.value).trim()) { name.focus(); return; }
    save.disabled = true;
    if (await act(A.company, { id: s._id, company_name: String(name.value).trim(), language: lang.value }, 'Saved.')) again();
    save.disabled = false;
  });
  return f;
}

function sender(s, again) {
  const st = C.senders(s);
  const look = el('button', { type: 'button', class: 'oc-btn oc-btn--primary' }, 'Look again');
  look.addEventListener('click', async () => {
    look.disabled = true;
    look.textContent = 'Looking…';
    if (await act(A.check, { id: s._id })) setTimeout(again, 6000);
  });
  return el('div', { class: 'oc-stack es-start__form' }, [
    el('p', { class: 'es-step__why' }, ['Invitations, codes and the signed copy go out from your own Gmail or Resend, connected in ', integrations('Orchestra → Integrations'),
      '. Nothing is sent until you press Send on an envelope.']),
    el('p', { class: 'es-said' }, st.say),
    el('div', { class: 'oc-row' }, [look, el('a', { class: 'oc-btn', href: '#/settings' }, 'Choose in Settings')]),
    el('button', { type: 'button', class: 'es-linkish', onClick: async () => { if (await act(A.dismiss, { id: s._id })) again(); } }, 'Hide this'),
  ]);
}
