// An envelope after Send: the document with the signatures given so far, and
// beside it who signs (their state, their link, Remind), the signed PDF once
// everyone signed (download, Files, its fingerprint), the emails, the
// evidence (every event, chained) and Void, which asks twice and says what
// goes with it. While a signed PDF is being made, the page looks again.
import { A, C, FILES, T, act, ago, badge, copy, day, moment, paper } from '../data.js';

const { el } = Orch;

export function sent({ e, signers, doc, s, again }) {
  const host = el('aside', { class: 'oc-stack es-side' }, [
    e.status === 'Completed' ? pdfSection(e, s, again) : null,
    el('section', { class: 'es-sidesec oc-stack' }, [el('h2', { class: 'oc-h2' }, 'Signers'), el('ul', { class: 'es-signers' }, signers.map((x) => signerItem(x, e, s, again)))]),
    facts(e),
  ]);
  const late = el('div', { class: 'oc-stack' });
  Promise.all([
    Orch.db.list(T.emails, { filter: { envelope_id: e._id }, sort: '_id:asc', limit: 100 }),
    Orch.db.list(T.events, { filter: { envelope_id: e._id }, sort: '_id:asc', limit: 300 }),
  ]).then(([m, ev]) => Orch.mount(late, [emails(m.rows || [], again), evidence(ev.rows || [], e), e.status === 'Out' ? voidBox(e, again) : null])).catch(() => {});
  host.appendChild(late);
  if (e.status === 'Completed' && e.finish_status !== 'Done' && e.finish_status !== 'Failed') setTimeout(() => { if (location.hash === `#/env/${e._id}`) again(); }, 5000);
  return el('div', { class: 'es-split' }, [el('div', { class: 'es-paperwrap' }, doc ? paper(doc, e, signers, s) : el('p', { class: 'oc-help' }, 'The document could not be shown.')), host]);
}

const linkOf = (s, x) => `${s.public_url || `${location.origin}${location.pathname.replace(/\/canvas\/a\/[^/]+\/?.*$/, '/canvas/a/sign/')}`}#/${x.token}`;

function signerItem(x, e, s, again) {
  const live = e.status === 'Out' && ['Invited', 'Opened'].includes(x.status);
  const when = x.status === 'Signed' ? `signed ${moment(x.signed_at)}` : x.status === 'Declined' ? `declined ${moment(x.declined_at)}`
    : x.status === 'Opened' ? `opened ${ago(x.opened_at)}` : x.status === 'Invited' ? `invited ${ago(x.invited_at)}` : e.order_mode === 'in_order' ? 'invited when it is their turn' : '';
  return el('li', { class: 'es-signeritem' }, [
    el('div', { class: 'es-signeritem__top' }, [el('span', { class: 'es-signeritem__name' }, [el('span', x.name), el('span', { class: 'oc-help' }, `${x.role} · ${x.email}`)]), badge(x.status)]),
    el('p', { class: 'oc-help' }, [when, x.reminders ? ` · ${x.reminders} reminder${x.reminders === 1 ? '' : 's'}` : '', x.code_ok_at ? ' · email verified with a code' : '']),
    x.decline_reason ? el('p', { class: 'es-quote' }, `"${x.decline_reason}"`) : null,
    x.token && e.status !== 'Void' ? el('div', { class: 'oc-row es-small' }, [
      el('button', { type: 'button', class: 'es-linkish', onClick: () => copy(linkOf(s, x), 'Their link is copied. It is theirs: it signs as them.') }, 'Copy their link'),
      live ? el('button', { type: 'button', class: 'es-linkish', onClick: async () => { if (await act(A.remind, { id: x._id }, `A reminder goes to ${x.email} in a moment.`)) again(); } }, 'Remind') : null,
    ]) : null,
  ]);
}

function facts(e) {
  const rows = [['Sent', moment(e.sent_at)], ['Sign by', day(e.expires_on)], ['Order', e.order_mode === 'in_order' ? 'In order' : 'Everyone at once'],
    ['File', e.file_name], ['SHA-256 of the file', e.source_sha256 || '—']];
  return el('section', { class: 'es-sidesec' }, el('dl', { class: 'es-facts' }, rows.map(([k, v]) => el('div', [el('dt', k), el('dd', { class: k.startsWith('SHA') ? 'es-mono' : '' }, v)]))));
}

function pdfSection(e, s, again) {
  if (e.finish_status === 'Failed') {
    return el('section', { class: 'es-sidesec oc-stack es-notice--bad' }, [el('h2', { class: 'oc-h2' }, 'Signed PDF'), el('p', { class: 'es-bad' }, e.finish_note || 'It could not be made.'),
      el('div', { class: 'oc-row' }, el('button', { type: 'button', class: 'oc-btn oc-btn--primary', onClick: async () => { if (await act(A.retryPdf, { id: e._id }, 'Trying again…')) again(); } }, 'Try again'))]);
  }
  if (e.finish_status !== 'Done') return el('section', { class: 'es-sidesec oc-stack' }, [el('h2', { class: 'oc-h2' }, 'Signed PDF'), el('p', { class: 'oc-help' }, 'Making it: the document with every signature and a certificate page, sealed and saved in Files. Under a minute.')]);
  const dl = el('button', { type: 'button', class: 'oc-btn oc-btn--primary' }, 'Download the signed PDF');
  dl.addEventListener('click', () => download(e, dl));
  return el('section', { class: 'es-sidesec oc-stack' }, [
    el('h2', { class: 'oc-h2' }, 'Signed PDF'),
    el('div', { class: 'oc-row' }, [dl, el('a', { class: 'oc-btn', href: FILES, target: '_top', rel: 'noopener' }, 'Open Files')]),
    el('p', { class: 'oc-help' }, `${e.final_name} · ${Math.max(1, Math.round((Number(e.final_size) || 0) / 1024))} KB · in Files${s.files_folder ? `, folder ${s.files_folder}` : ''}. Every signer can download it from their link too.`),
    el('dl', { class: 'es-facts' }, [
      el('div', [el('dt', 'Sealed'), el('dd', e.seal_level === 'B-T' ? 'PAdES with a timestamp' : 'PAdES, without a timestamp')]),
      el('div', [el('dt', 'Certificate'), el('dd', s.cert_subject || '—')]),
      el('div', [el('dt', 'SHA-256'), el('dd', { class: 'es-mono' }, e.final_sha256 || '—')]),
    ]),
    e.finish_note ? el('p', { class: 'oc-help' }, e.finish_note) : null,
  ]);
}

async function download(e, button) {
  button.disabled = true;
  try {
    const parts = ((await Orch.db.list(T.pdf, { filter: { envelope_id: e._id }, sort: 'part:asc', limit: 500 })).rows) || [];
    const bin = atob(parts.map((p) => p.body).join(''));
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i += 1) bytes[i] = bin.charCodeAt(i);
    const url = URL.createObjectURL(new Blob([bytes], { type: 'application/pdf' }));
    const a = el('a', { href: url, download: e.final_name || 'signed.pdf' });
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 30000);
  } catch { Orch.toast('It could not be downloaded here: open it in Files.', { error: true }); }
  button.disabled = false;
}

const PURPOSE = { invite: 'Invitation', reminder: 'Reminder', code: 'Code', completed: 'Signed copy' };
function emails(rows, again) {
  if (!rows.length) return null;
  return el('details', { class: 'es-sidesec es-details', open: rows.some((m) => m.status === 'Failed') }, [
    el('summary', `Emails (${rows.length})`),
    el('ul', { class: 'es-mini' }, rows.map((m) => el('li', [
      el('span', `${PURPOSE[m.purpose] || m.purpose} → ${m.to_email} · `), m.status === 'Failed' ? badge('Failed') : el('span', { class: 'oc-help' }, m.status === 'Sent' ? `sent ${ago(m.sent_at)}` : String(m.status || '').toLowerCase()),
      m.status === 'Failed' ? el('div', { class: 'oc-stack es-failed' }, [el('p', { class: 'es-bad' }, m.error || ''), el('div', { class: 'oc-row' }, [
        el('button', { type: 'button', class: 'oc-btn oc-btn--sm', onClick: async () => { if (await act(A.retryEmail, { id: m._id }, 'It goes out in a moment.')) again(); } }, 'Send again'),
        el('button', { type: 'button', class: 'oc-btn oc-btn--sm oc-btn--ghost', onClick: async () => { if (await act(A.dropEmail, { id: m._id }, 'Dropped.')) again(); } }, 'Drop')])]) : null,
    ]))),
  ]);
}

function evidence(rows, e) {
  if (!rows.length) return null;
  const W = C.EVENT_WORDS.en;
  return el('details', { class: 'es-sidesec es-details' }, [
    el('summary', `Evidence (${rows.length} events)`),
    el('p', { class: 'oc-help' }, 'Every event, with the server\'s time and the browser it came from. Each one carries the hash of the one before, so a changed or removed event breaks the chain; the signed PDF prints it.'),
    el('ol', { class: 'es-events' }, rows.map((x) => el('li', [el('span', { class: 'es-mono' }, moment(x.at)), el('span', W[x.event] || x.event), el('span', { class: 'oc-help' }, [x.who, x.ua ? ` · ${String(x.ua).slice(0, 80)}` : ''].filter(Boolean).join(''))]))),
    el('p', { class: 'oc-help' }, ['Last hash ', el('span', { class: 'es-mono' }, e.events_head || '—')]),
  ]);
}

function voidBox(e, again) {
  const box = el('div', { class: 'es-sidesec oc-stack' });
  const first = el('button', { type: 'button', class: 'es-linkish es-dangerlink' }, 'Void this envelope…');
  first.addEventListener('click', () => {
    const why = el('input', { class: 'oc-input', maxlength: '300', placeholder: 'Why (kept in the evidence). Optional.' });
    const ack = el('input', { type: 'checkbox' });
    const go = el('button', { type: 'button', class: 'oc-btn oc-btn--danger', disabled: true }, 'Void it');
    ack.addEventListener('change', () => { go.disabled = !ack.checked; });
    go.addEventListener('click', async () => { go.disabled = true; if (await act(A.void, { id: e._id, void_reason: String(why.value).trim() }, 'Voided.')) again(); go.disabled = false; });
    Orch.mount(box, el('div', { class: 'es-void oc-stack' }, [
      el('p', 'Voiding stops it for everyone: the links stop accepting signatures and say it was voided. Signatures already given stay in the evidence but there will be no signed PDF. It cannot be undone; to change the document, void it and send a new one.'),
      why, el('label', { class: 'es-check' }, [ack, el('span', 'I understand nobody can sign it after this')]),
      el('div', { class: 'oc-row' }, [go, el('button', { type: 'button', class: 'oc-btn oc-btn--ghost', onClick: () => Orch.mount(box, first) }, 'Keep it')]),
    ]));
  });
  box.appendChild(first);
  return box;
}
