// One envelope, on its own page: its head (back, title, state, one sentence
// on what is happening), then the document as the signers see it with a
// side panel: before Send, who signs and how (draft.js); after, who signed,
// the signed PDF, the evidence and Void (sent.js).
import { T, badge, docOf, settings } from '../data.js';
import { draft } from './draft.js';
import { sent } from './sent.js';

const { el, router } = Orch;

export function render({ id }) {
  Orch.load('view', async () => {
    const s = await settings(true);
    const e = await Orch.db.get(T.envelopes, Number(id));
    if (!e || e.status === 'Discarded') return el('div', { class: 'oc-state' }, [el('p', 'This envelope is not here.'), router.link('/', 'All envelopes')]);
    const signers = ((await Orch.db.list(T.signers, { filter: { envelope_id: e._id, status: { ne: 'Removed' } }, sort: 'ord:asc', limit: 50 })).rows) || [];
    const doc = await docOf(e);
    const again = () => render({ id });
    return el('div', { class: 'oc-stack oc-stack--loose' }, [
      el('header', { class: 'es-envhead' }, [
        router.link(e.status === 'Draft' ? '/list/draft' : '/', '← All envelopes', { class: 'es-back' }),
        el('div', { class: 'es-envhead__line' }, [
          el('div', { class: 'es-envhead__name' }, [el('h1', { class: 'oc-h1 es-envtitle' }, e.title || e.file_name || 'Untitled'), el('p', { class: 'oc-lede' }, sentence(e, signers))]),
          badge(e.status === 'Completed' && e.finish_status === 'Failed' ? 'Failed' : e.status, e.status === 'Completed' && e.finish_status === 'Failed' ? 'PDF failed' : undefined),
        ]),
      ]),
      e.status === 'Draft' ? draft({ e, signers, doc, s, again }) : sent({ e, signers, doc, s, again }),
    ]);
  });
}

function sentence(e, signers) {
  const n = signers.length;
  const signed = signers.filter((x) => x.status === 'Signed').length;
  const file = `${e.file_name || 'the file'}`;
  if (e.status === 'Draft') return e.prepare_status === 'Ready' ? `From ${file}. Say who signs, then Send: nothing goes out before.` : `From ${file}.`;
  if (e.status === 'Out') return `${signed} of ${n} signed. ${e.order_mode === 'in_order' ? 'In order: the next one is invited when the one before signs.' : 'Everyone was invited at once.'}`;
  if (e.status === 'Completed') return e.finish_status === 'Done' ? 'Everyone signed. The signed PDF is in Files and on each signer\'s link.' : e.finish_status === 'Failed' ? 'Everyone signed, but the signed PDF could not be made yet.' : 'Everyone signed. Making the signed PDF…';
  if (e.status === 'Declined') return 'A signer declined. Nobody else can sign it.';
  if (e.status === 'Void') return `Voided${e.void_reason ? `: ${e.void_reason}` : ''}. The links no longer accept signatures.`;
  return 'It passed its day before everyone signed. The links no longer accept signatures.';
}
