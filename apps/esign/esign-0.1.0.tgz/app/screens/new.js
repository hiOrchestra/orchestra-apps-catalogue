// New envelope: pick the document from Files. The list is the project's
// Markdown, Word and HTML files, copied by a script (a page cannot read
// Files): Refresh asks for it again and this screen looks until it changed.
// Picking one creates the draft and opens it; the file is read in the
// background (its markers, its SHA-256).
import { A, FILES, act, ago, field, head, input, settings, T } from '../data.js';

const { el, router } = Orch;
const KIND = { md: 'Markdown', markdown: 'Markdown', docx: 'Word', html: 'HTML', htm: 'HTML', txt: 'Text' };
const sleep = (ms) => new Promise((r) => { setTimeout(r, ms); });

export function render() {
  Orch.load('view', async () => {
    const s = await settings(true);
    if (!s._id) return el('p', { class: 'oc-state' }, 'Sign is not installed in this project.');
    const files = ((await Orch.db.list(T.sources, { sort: 'modified_at:desc', limit: 500 })).rows) || [];
    // Never listed (a new install): ask once, on the way in.
    if (!s.sources_at && !s.sources_asked_at) refresh(s, null);
    const q = input('', { type: 'search', placeholder: 'Search by name or folder', 'aria-label': 'Search files' });
    const list = el('ul', { class: 'es-rows es-files' });
    const draw = () => {
      const words = q.value.trim().toLowerCase();
      const shown = files.filter((f) => !words || `${f.name} ${f.folder}`.toLowerCase().includes(words));
      Orch.mount(list, shown.length ? shown.map((f) => el('li', { class: 'es-row' }, el('button', { type: 'button', class: 'es-row__open', onClick: () => create(f) }, [
        el('span', { class: 'es-row__first oc-value' }, KIND[f.type] || f.type),
        el('span', { class: 'es-row__name' }, [el('span', f.name), el('span', { class: 'es-row__sub' }, [f.folder, f.modified_at ? `changed ${ago(f.modified_at)}` : ''].filter(Boolean).join(' · '))]),
        el('span', { class: 'es-row__right oc-small' }, 'Use this →'),
      ]))) : el('li', { class: 'es-empty' }, files.length ? 'No file matches.' : 'No Markdown, Word or HTML file in this project yet.'));
    };
    q.addEventListener('input', draw);
    draw();
    const again = el('button', { type: 'button', class: 'oc-btn', onClick: () => refresh(s, again) }, 'Refresh');
    return el('div', { class: 'oc-stack oc-stack--loose' }, [
      head('New envelope', 'Pick the document to sign. It comes from Files, in this project.', [again]),
      el('section', { class: 'oc-card oc-stack es-hint' }, [
        el('p', ['Mark where each person signs, in the document itself: ', el('code', '{{sign:Client}}'), ', ', el('code', '{{name:Client}}'), ', ', el('code', '{{date:Client}}'), ', ',
          el('code', '{{initials:Client}}'), ' (or ', el('code', '{{firma:Cliente}}'), ', ', el('code', '{{nombre:…}}'), ', ', el('code', '{{fecha:…}}'), ', ', el('code', '{{iniciales:…}}'),
          '). Each role is one signer. Without markers, a signature block for each signer goes at the end.']),
        el('p', { class: 'oc-help' }, ['A file that is not here? Upload it to ', el('a', { href: FILES, target: '_top', rel: 'noopener' }, 'Files'), ' in this project, or ask the agent to write it, then Refresh. ',
          s.sources_at ? `Listed ${ago(s.sources_at)}.` : 'Listing the files…', s.sources_note ? ` ${s.sources_note}` : '']),
      ]),
      q, list,
    ]);
  });
}

async function refresh(s, button) {
  if (button) { button.disabled = true; button.textContent = 'Refreshing…'; }
  const before = s.sources_at || '';
  if (!await act(A.refresh, { id: s._id })) { if (button) { button.disabled = false; button.textContent = 'Refresh'; } return; }
  for (const wait of [2, 3, 4, 6, 8, 10]) {
    await sleep(wait * 1000);
    const now = await settings(true);
    if ((now.sources_at || '') !== before) { if (location.hash.startsWith('#/new')) render(); return; }
  }
  if (button) { button.disabled = false; button.textContent = 'Refresh'; }
  Orch.toast('The list did not come back yet. It runs in the background: try again in a minute.', { error: true });
}

async function create(f) {
  const title = input(String(f.name).replace(/\.[a-z0-9]+$/i, ''), { maxlength: '160', required: true });
  const go = el('button', { type: 'submit', class: 'oc-btn oc-btn--primary' }, 'Create the draft');
  const form = el('form', { class: 'oc-stack' }, [
    el('p', { class: 'oc-help' }, `${f.name}${f.folder ? ` · ${f.folder}` : ''}. Next you say who signs; nothing is sent until you press Send.`),
    field('Title', title, 'What signers read in the email and on their page.'),
    el('div', { class: 'oc-row' }, go),
  ]);
  const d = Orch.dialog(form, { title: 'New envelope' });
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    go.disabled = true;
    const name = /\.[a-z0-9]+$/i.test(f.name) ? f.name : `${f.name}.${f.type}`;
    const r = await act(A.create, { title: String(title.value).trim(), file_id: f.file_id, file_name: name, file_type: f.type, order_mode: 'together' });
    go.disabled = false;
    if (r && r._id) { d.close(); router.go(`/env/${r._id}`); }
  });
}
