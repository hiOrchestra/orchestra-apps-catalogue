// What every envelope carries: your company and the signers' language, who
// sends the emails (Gmail or Resend), how a signature is checked (a code to
// the signer's email), how long links work and reminders, and where the
// signed PDFs go and what seals them. One form, one Save; saving rewrites
// the signers' pages of envelopes already out (your new name shows there).
import { A, C, act, ago, field, head, input, integrations, select, settings } from '../data.js';

const { el } = Orch;

export function render() {
  Orch.load('view', async () => {
    const s = await settings(true);
    if (!s._id) return el('p', { class: 'oc-state' }, 'Sign is not installed in this project.');
    return el('div', { class: 'oc-stack oc-stack--loose' }, [head('Settings', 'What every envelope carries, and how it reaches the signers.'), form(s), legal()]);
  });
}

const ZONES = ['Europe/Madrid', 'Europe/London', 'Europe/Lisbon', 'Europe/Paris', 'Europe/Berlin', 'America/New_York', 'America/Chicago', 'America/Los_Angeles',
  'America/Mexico_City', 'America/Bogota', 'America/Lima', 'America/Santiago', 'America/Argentina/Buenos_Aires', 'America/Sao_Paulo', 'UTC'];

function form(s) {
  const c = {
    company_name: input(s.company_name, { maxlength: '160' }),
    language: select(s.language === 'es' ? 'es' : 'en', [['en', 'English'], ['es', 'Español']]),
    timezone: select(s.timezone || 'Europe/Madrid', [...new Set([s.timezone || 'Europe/Madrid', ...ZONES])].map((z) => [z, z])),
    sender: select(C.senderOf(s), [['gmail', 'Gmail'], ['resend', 'Resend']]),
    resend_from_name: input(s.resend_from_name, { maxlength: '80', placeholder: s.company_name || 'Your company' }),
    resend_from: input(s.resend_from, { type: 'email', maxlength: '120', placeholder: 'sign@yourcompany.com' }),
    resend_reply_to: input(s.resend_reply_to, { type: 'email', maxlength: '120', placeholder: 'Optional' }),
    require_code: select(s.require_code === 'no' ? 'no' : 'yes', [['yes', 'Yes: a code to their email when they sign'], ['no', 'No: the link is enough']]),
    expire_days: input(s.expire_days ?? 30, { type: 'number', min: '1', max: '365' }),
    remind_on: select(s.remind_on === 'yes' ? 'yes' : 'no', [['no', 'No: only when I press Remind'], ['yes', 'Yes, on their own']]),
    remind_days: input(s.remind_days ?? 3, { type: 'number', min: '1', max: '30' }),
    notify_telegram: input(s.notify_telegram, { maxlength: '40', placeholder: '@channel or chat id' }),
    files_folder: input(s.files_folder ?? 'Signed', { maxlength: '60' }),
    tsa_url: input(s.tsa_url, { type: 'url', maxlength: '200', placeholder: 'http://timestamp.digicert.com' }),
  };
  const st = C.senders(s);
  const resendBox = el('div', { class: 'oc-stack' }, [
    el('div', { class: 'es-two' }, [field('From name', c.resend_from_name, 'Empty: the company name.'), field('From address', c.resend_from, 'On a domain verified in Resend.')]),
    field('Reply-to', c.resend_reply_to)]);
  const showResend = () => { resendBox.hidden = c.sender.value !== 'resend'; };
  c.sender.addEventListener('change', showResend);
  showResend();
  const look = el('button', { type: 'button', class: 'oc-btn oc-btn--sm' }, 'Look again');
  look.addEventListener('click', async () => { look.disabled = true; look.textContent = 'Looking…'; if (await act(A.check, { id: s._id })) setTimeout(render, 6000); });
  const cert = s.cert_subject
    ? el('dl', { class: 'es-facts' }, [el('div', [el('dt', 'Certificate'), el('dd', s.cert_subject)]), el('div', [el('dt', 'Valid until'), el('dd', s.cert_not_after || '—')]),
      el('div', [el('dt', 'SHA-256 fingerprint'), el('dd', { class: 'es-mono' }, s.cert_fingerprint || '—')])])
    : el('p', { class: s.cert_status === 'error' ? 'es-bad' : 'oc-help' }, s.cert_status === 'error' ? s.cert_note : 'Not made yet: it is made the first time Sign reads a file (New envelope).');
  const save = el('button', { type: 'submit', class: 'oc-btn oc-btn--primary' }, 'Save');
  const f = el('form', { class: 'oc-stack oc-stack--loose es-form' }, [
    el('section', { class: 'oc-card oc-stack' }, [el('h2', { class: 'oc-h2' }, 'Your company'),
      field('Company name', c.company_name, 'In every email and on the signer\'s page.'),
      el('div', { class: 'es-two' }, [field('Signers read', c.language, 'Their page and the emails.'), field('Time zone', c.timezone, 'The day a signature is dated, and the last day to sign.')])]),
    el('section', { class: 'oc-card oc-stack' }, [el('h2', { class: 'oc-h2' }, 'Emails'),
      el('p', { class: 'oc-help' }, ['Invitations, codes, reminders and the signed copy go from your own account, connected in ', integrations('Orchestra → Integrations'), '. Nothing goes out until you press Send.']),
      field('Send through', c.sender), resendBox,
      el('div', { class: 'oc-row es-look' }, [el('p', { class: st.ready ? 'es-said' : 'es-bad' }, st.say), look]),
      el('p', { class: 'oc-help' }, s.gmail_checked_at ? `Looked ${ago(s.gmail_checked_at)}.` : 'Not looked yet.')]),
    el('section', { class: 'oc-card oc-stack' }, [el('h2', { class: 'oc-h2' }, 'Signing'),
      field('Check their email when they sign', c.require_code, 'A six-digit code sent to the signer as they sign proves they hold that inbox, even if the link was forwarded. Recommended.'),
      el('div', { class: 'es-two' }, [field('Days to sign', c.expire_days, 'For new envelopes. Each one can change it.'), field('Telegram', c.notify_telegram, 'Where you hear that someone signed or declined. Optional.')]),
      el('div', { class: 'es-two' }, [field('Reminders', c.remind_on, 'At most three, to whoever has not signed.'), field('Days between reminders', c.remind_days)])]),
    el('section', { class: 'oc-card oc-stack' }, [el('h2', { class: 'oc-h2' }, 'Signed PDFs'),
      el('div', { class: 'es-two' }, [field('Folder in Files', c.files_folder), field('Timestamp authority', c.tsa_url, 'RFC 3161. Proves when it was sealed. Empty: no timestamp.')]),
      el('p', { class: 'oc-help' }, 'Each signed PDF is sealed with this workspace\'s own certificate: a PDF reader shows the document was not changed since. It cannot say who the certificate belongs to, because no certificate authority vouches for it.'),
      cert]),
    el('div', { class: 'oc-row' }, save),
  ]);
  f.addEventListener('submit', async (e) => {
    e.preventDefault();
    const params = { id: s._id };
    for (const [k, node] of Object.entries(c)) params[k] = String(node.value).trim();
    for (const k of ['expire_days', 'remind_days']) params[k] = Math.max(1, Math.round(Number(params[k]) || 1));
    for (const k of ['resend_from', 'resend_reply_to']) { params[k] = C.normEmail(params[k]); if (params[k] && !C.isEmail(params[k])) { Orch.toast('An email address does not look right.', { error: true }); c[k].focus(); return; } }
    if (params.tsa_url && !/^https?:\/\//.test(params.tsa_url)) { Orch.toast('The timestamp authority must be an http(s) address.', { error: true }); return; }
    save.disabled = true;
    if (await act(A.settings, params, 'Saved.')) render();
    save.disabled = false;
  });
  return f;
}

const legal = () => el('section', { class: 'oc-card oc-stack es-legal' }, [
  el('h2', { class: 'oc-h2' }, 'What kind of signature this is'),
  el('p', ['A simple electronic signature: valid for most agreements under eIDAS (EU) and ESIGN/UETA (US), with evidence of who signed and when: ',
    'their email (and a code sent to it), their consent, the browser they used, and a sealed PDF with a certificate page.']),
  el('p', ['It is not an advanced or qualified signature (no certificate per signer), and some documents (wills, some family and property matters) ',
    'may need one, or paper. IP addresses are not recorded.']),
]);
