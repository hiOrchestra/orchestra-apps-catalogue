// Home: the envelopes, one tab per where they are. Waiting (sent, someone
// still has to sign) comes first; then drafts, completed, and the closed
// ones (declined, voided, expired). Above the lists, what waits for you:
// an email that did not go out, a signed PDF that could not be made, a file
// that could not be read. Getting started sits on top until the company and
// a sender are set.
import { A, V, act, ago, badge, day, head, row, settings } from '../data.js';
import { startCard } from './start.js';

const { el, router, fmt } = Orch;

const TABS = [['waiting', 'Waiting', 'No envelope is waiting for a signature.'], ['draft', 'Drafts', 'No drafts.'],
  ['completed', 'Completed', 'Nothing signed yet.'], ['closed', 'Declined, voided, expired', 'Nothing here.'], ['all', 'All', '']];

export function render({ tab = 'waiting' } = {}) {
  Orch.load('view', async () => {
    const s = await settings(true);
    if (!s._id) return el('p', { class: 'oc-state' }, 'Sign is not installed in this project.');
    const t = TABS.find((x) => x[0] === tab) || TABS[0];
    const [list, counts, attention] = await Promise.all([
      Orch.db.view(V.envelopes, { filter: t[0] === 'all' ? {} : { tab: t[0] }, sort: '_id:desc', limit: 300 }),
      Orch.db.view(V.envelopes, { limit: 500 }),
      Orch.db.view(V.attention, { sort: 'at:desc', limit: 20 }),
    ]);
    const n = (k) => (counts.rows || []).filter((r) => k === 'all' || r.tab === k).length;
    const rows = list.rows || [];
    const total = n('all');
    return el('div', { class: 'oc-stack oc-stack--loose' }, [
      head('Envelopes', 'Documents from Files sent for signature, and the signed PDFs.', [router.link('/new', 'New envelope', { class: 'oc-btn oc-btn--primary' })]),
      startCard(s, () => render({ tab })),
      needsYou(attention.rows || []),
      total ? el('nav', { class: 'oc-tabs', 'aria-label': 'Which ones' }, TABS.filter((x) => x[0] === t[0] || n(x[0]) || x[0] === 'waiting').map((x) => router.link(
        x[0] === 'waiting' ? '/' : `/list/${x[0]}`, [x[1], el('span', { class: 'oc-count' }, fmt.number(n(x[0])))], { class: 'oc-tab', 'aria-current': x === t ? 'page' : null }))) : null,
      rows.length ? el('ul', { class: 'es-rows' }, rows.map(envelopeRow))
        : total ? el('div', { class: 'oc-card oc-state' }, el('p', { class: 'oc-help' }, t[2] || 'Nothing here.'))
          : el('div', { class: 'oc-card oc-state' }, [el('p', { class: 'oc-state__title' }, 'Nothing sent for signature yet.'),
            el('p', { class: 'oc-help' }, 'Pick a contract, an NDA or a proposal from Files. Write {{sign:Client}} (or {{firma:Cliente}}) where each person signs; without markers, a signature block goes at the end.'),
            router.link('/new', 'New envelope', { class: 'oc-btn oc-btn--primary' })]),
    ]);
  });
}

const WHAT = { draft: 'Draft', waiting: 'Out', completed: 'Completed' };

export function envelopeRow(e) {
  const sub = e.status === 'Draft' ? [e.file_name, e.prepare_status === 'Failed' ? 'the file could not be read' : e.prepare_status !== 'Ready' ? 'reading the file…' : `${e.signers} to sign`]
    : e.status === 'Out' ? [`${e.signed} of ${e.signers} signed`, e.waiting_on ? `waiting for ${e.waiting_on}` : '', e.expires_on ? `until ${day(e.expires_on)}` : '']
      : e.status === 'Completed' ? [e.people, e.finish_status === 'Done' ? `signed ${ago(e.completed_at)}` : e.finish_status === 'Failed' ? 'the signed PDF could not be made' : 'making the signed PDF…']
        : [e.people, e.status === 'Declined' ? `declined ${ago(e.declined_at)}` : e.status === 'Void' ? `voided ${ago(e.void_at)}` : `expired ${day(e.expires_on)}`];
  return row({
    to: `/env/${e._id}`,
    first: `#${String(e._id).padStart(4, '0')}`,
    name: e.title || e.file_name || 'Untitled',
    sub: sub.filter(Boolean).join(' · '),
    right: badge(e.status === 'Completed' && e.finish_status === 'Failed' ? 'Failed' : (WHAT[e.tab] && e.status) || e.status, e.status === 'Completed' && e.finish_status === 'Failed' ? 'PDF failed' : undefined),
  });
}

function needsYou(items) {
  if (!items.length) return null;
  const say = { email: (x) => `The ${x.what} email to ${x.who} did not go out`, pdf: () => 'The signed PDF could not be made', read: () => 'The file could not be read' };
  return el('section', { class: 'oc-stack' }, [
    el('h2', { class: 'oc-h2' }, 'Waiting for you'),
    el('ul', { class: 'es-rows' }, items.map((x) => el('li', { class: 'es-row es-row--attn' }, [
      router.link(`/env/${x.envelope_id}`, [el('span', { class: 'es-row__first oc-value' }, `#${String(x.envelope_id).padStart(4, '0')}`),
        el('span', { class: 'es-row__name' }, [el('span', `${say[x.kind](x)} · ${x.title || ''}`), el('span', { class: 'es-row__sub' }, String(x.note || '').slice(0, 200))]),
        el('span', { class: 'es-row__right' }, badge('Failed'))], { class: 'es-row__open' }),
      x.kind === 'email' ? el('div', { class: 'es-row__tools' }, [
        el('button', { type: 'button', class: 'oc-btn oc-btn--sm', onClick: async () => { if (await act(A.retryEmail, { id: x.id }, 'It goes out in a moment.')) render(); } }, 'Send again'),
        el('button', { type: 'button', class: 'oc-btn oc-btn--sm oc-btn--ghost', onClick: async () => { if (await act(A.dropEmail, { id: x.id }, 'Dropped.')) render(); } }, 'Drop'),
      ]) : null,
    ]))),
  ]);
}

