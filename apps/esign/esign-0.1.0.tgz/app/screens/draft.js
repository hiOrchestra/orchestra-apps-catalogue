// An envelope before Send: the document with each role's places, and beside
// it who signs (one person per role), the order, a message for the email and
// the last day. Save keeps it; Send saves, then asks (the script checks, gives
// each signer their link and emails them) and this page looks until it went
// out or says why not. A file still being read is looked at every few seconds.
import { A, C, T, act, area, field, input, paper, select, sheet } from '../data.js';

const { el, router } = Orch;
const sleep = (ms) => new Promise((r) => { setTimeout(r, ms); });
const KIND = { sign: 'signature', initials: 'initials', name: 'name', date: 'date' };

export function draft({ e, signers, doc, s, again }) {
  if (e.prepare_status !== 'Ready') return reading(e, again);
  const roles = C.rolesOf(doc);
  const free = e.no_markers === 'yes';
  const inDoc = new Set(roles.map((r) => C.roleKey(r.role)));
  const rows = signers.map((x) => signerRow(x, roles, free, inDoc, again));
  const order = select(e.order_mode || 'together', [['together', 'Everyone at once'], ['in_order', 'In order: one after the other']]);
  // The place in order only means something in order.
  const showOrd = () => { for (const r of rows) r.ord.hidden = order.value !== 'in_order'; };
  order.addEventListener('change', showOrd);
  showOrd();
  const message = area(e.message, 3, { maxlength: '1000', placeholder: 'Optional: a line for the email, e.g. "Here is the contract we talked about."' });
  const expires = input(e.expires_on || '', { type: 'date', min: C.today(s.timezone) });
  const contacts = el('datalist', { id: 'es-contacts' });
  if (s.crm_available === 'yes') Orch.db.list(T.contacts, { filter: { email: { notnull: true } }, sort: 'name:asc', limit: 500 }).then((r) => Orch.mount(contacts, (r.rows || []).filter((c) => C.isEmail(c.email)).map((c) => el('option', { value: `${c.name || ''} <${c.email}>` })))).catch(() => {});
  const save = el('button', { type: 'button', class: 'oc-btn' }, 'Save');
  const send = el('button', { type: 'button', class: 'oc-btn oc-btn--primary' }, 'Send for signature');
  const store = async (quiet) => {
    for (const r of rows) if (!await r.save()) return false;
    const params = { id: e._id, order_mode: order.value, message: String(message.value).trim(), expires_on: expires.value || '' };
    if (!await act(A.save, params, quiet ? null : 'Saved.')) return false;
    return true;
  };
  save.addEventListener('click', async () => { save.disabled = true; if (await store(false)) again(); save.disabled = false; });
  send.addEventListener('click', () => confirmSend({ e, s, rows, store, again, send }));
  const add = free ? el('button', { type: 'button', class: 'oc-btn oc-btn--sm', onClick: async () => {
    if (await act(A.addSigner, { envelope_id: e._id, ord: signers.length + 1, role: `Signer ${signers.length + 1}`, name: '', email: '' })) again();
  } }, 'Add a signer') : null;
  const side = el('aside', { class: 'oc-stack es-side' }, [
    e.send_note ? el('div', { class: 'es-notice es-notice--bad', role: 'alert' }, el('p', e.send_note)) : null,
    e.prepare_note ? el('div', { class: 'es-notice' }, el('p', e.prepare_note)) : null,
    el('section', { class: 'es-sidesec oc-stack' }, [
      el('h2', { class: 'oc-h2' }, 'Who signs'),
      el('p', { class: 'oc-help' }, free ? 'The document has no markers: a block with name, signature and date goes at the end for each signer.'
        : `${roles.length} role${roles.length === 1 ? '' : 's'} in the document. One person signs each.`),
      ...rows.map((r) => r.node), add, contacts,
    ]),
    el('section', { class: 'es-sidesec oc-stack' }, [
      el('h2', { class: 'oc-h2' }, 'Sending'),
      field('Order', order, 'In order, each signer is emailed when the one before signed (top to bottom).'),
      field('Message', message, 'Goes in the invitation, above the link.'),
      field('Sign by', expires, `After this day the links stop accepting signatures. Empty: ${Number(s.expire_days) || 30} days after sending.`),
    ]),
    el('div', { class: 'es-sidesec oc-row es-actions' }, [send, save, el('span', { class: 'es-grow' }),
      el('button', { type: 'button', class: 'oc-btn oc-btn--ghost oc-btn--sm', onClick: () => discard(e) }, 'Discard')]),
    el('p', { class: 'oc-help es-sidesec' }, [`${e.file_name} · read ${e.prepared_at ? Orch.fmt.ago(C.when(e.prepared_at).toISOString()) : ''}. Changed it in Files? `,
      el('button', { type: 'button', class: 'es-linkish', onClick: async () => { if (await act(A.readAgain, { id: e._id, file_id: e.file_id, file_name: e.file_name, file_type: e.file_type }, 'Reading it again…')) again(); } }, 'Read it again'),
      e.file_type === 'docx' ? '. The signed PDF keeps the text and its structure, not Word\'s page layout.' : '.']),
  ]);
  return el('div', { class: 'es-split' }, [el('div', { class: 'es-paperwrap' }, paper(doc, e, signers, s)), side]);
}

function signerRow(x, roles, free, inDoc, again) {
  const role = roles.find((r) => C.roleKey(r.role) === C.roleKey(x.role));
  const name = input(x.name, { maxlength: '120', placeholder: 'Full name', autocomplete: 'off', 'aria-label': `${x.role}: full name` });
  const email = input(x.email, { type: 'email', maxlength: '200', placeholder: 'name@company.com', autocomplete: 'off', list: 'es-contacts', 'aria-label': `${x.role}: email` });
  const ord = input(x.ord || 1, { type: 'number', min: '1', max: '20', class: 'oc-input es-ord', 'aria-label': `Order of ${x.role}` });
  // A contact picked from the list fills both fields.
  email.addEventListener('change', () => { const m = String(email.value).match(/^(.*)<([^>]+)>\s*$/); if (m) { email.value = m[2].trim(); if (!name.value.trim()) name.value = m[1].trim(); } });
  const orphan = !free && !inDoc.has(C.roleKey(x.role));
  const node = el('div', { class: `es-signer${orphan ? ' es-signer--orphan' : ''}` }, [
    el('div', { class: 'es-signer__role' }, [el('span', { class: 'oc-label' }, x.role), role ? el('span', { class: 'oc-help' }, role.kinds.map((k) => KIND[k]).join(', ')) : null, el('span', { class: 'es-grow' }), ord]),
    orphan ? el('p', { class: 'es-bad' }, `"${x.role}" is not in the document any more.`) : null,
    el('div', { class: 'oc-stack oc-stack--tight' }, [name, email]),
    free || orphan ? el('button', { type: 'button', class: 'es-linkish es-small', onClick: async () => { if (await act(A.removeSigner, { id: x._id })) again(); } }, 'Remove') : null,
  ]);
  const save = async () => {
    const p = { id: x._id, name: String(name.value).trim(), email: C.normEmail(email.value), ord: Math.max(1, Math.round(Number(ord.value) || 1)) };
    if (p.name === (x.name || '') && p.email === (x.email || '') && p.ord === Number(x.ord)) return true;
    if (p.email && !C.isEmail(p.email)) { Orch.toast(`The email of ${x.role} does not look right.`, { error: true }); email.focus(); return false; }
    return !!await act(A.saveSigner, p);
  };
  return { node, save, name, email, ord };
}

function confirmSend({ e, s, rows, store, again, send }) {
  const missing = rows.find((r) => !String(r.name.value).trim() || !C.isEmail(r.email.value));
  if (!rows.length) { Orch.toast('Add who signs first.', { error: true }); return; }
  if (missing) { Orch.toast('Each signer needs a name and an email.', { error: true }); (String(missing.name.value).trim() ? missing.email : missing.name).focus(); return; }
  const st = C.senders(s);
  const go = el('button', { type: 'button', class: 'oc-btn oc-btn--primary' }, `Send to ${rows.length} ${rows.length === 1 ? 'person' : 'people'}`);
  const box = el('div', { class: 'oc-stack' }, [
    el('p', `Each signer gets an email with their own link${s.require_code !== 'no' ? ', and a code by email when they sign' : ''}. After this, the document cannot be changed.`),
    el('ul', { class: 'es-mini' }, rows.map((r) => el('li', `${r.name.value.trim()} <${C.normEmail(r.email.value)}>`))),
    el('p', { class: st.ready ? 'oc-help' : 'es-bad' }, st.say),
    el('div', { class: 'oc-row' }, [go, el('button', { type: 'button', class: 'oc-btn oc-btn--ghost', onClick: () => d.close() }, 'Not yet')]),
  ]);
  const d = sheet(box, { title: 'Send for signature?' });
  go.addEventListener('click', async () => {
    go.disabled = true;
    send.disabled = true;
    if (!await store(true) || !await act(A.send, { id: e._id })) { go.disabled = false; send.disabled = false; return; }
    go.textContent = 'Sending…';
    for (const wait of [2, 3, 3, 4, 5, 6, 8, 10]) {
      await sleep(wait * 1000);
      const now = await Orch.db.get(T.envelopes, e._id);
      if (now.status !== 'Draft' || now.send_note || !now.send_asked_at) break;
    }
    d.close();
    again();
  });
}

async function discard(e) {
  if (!await Orch.confirm('Discard this draft? Nothing was sent; the file stays in Files.', { yes: 'Discard' })) return;
  if (await act(A.discard, { id: e._id }, 'Discarded.')) router.go('/list/draft');
}

function reading(e, again) {
  if (e.prepare_status === 'Failed') {
    return el('div', { class: 'oc-card oc-stack es-reading' }, [el('p', { class: 'es-bad' }, e.prepare_note || 'The file could not be read.'),
      el('div', { class: 'oc-row' }, [el('button', { type: 'button', class: 'oc-btn oc-btn--primary', onClick: async () => { if (await act(A.readAgain, { id: e._id, file_id: e.file_id, file_name: e.file_name, file_type: e.file_type })) again(); } }, 'Read it again'),
        Orch.router.link('/new', 'Pick another file', { class: 'oc-btn' })])]);
  }
  setTimeout(() => { if (location.hash === `#/env/${e._id}`) again(); }, 3000);
  return el('div', { class: 'oc-card oc-state' }, [el('p', { class: 'oc-state__title' }, 'Reading the file…'), el('p', { class: 'oc-help' }, `${e.file_name}: finding its markers and keeping its fingerprint. A few seconds.`)]);
}

