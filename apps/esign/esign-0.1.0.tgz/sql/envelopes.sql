SELECT e._id, e.title, e.status, e.file_name, e.prepare_status, e.finish_status, e.sent_at, e.completed_at, e.expires_on, e.order_mode,
  e.declined_at, e.void_at, e.expired_at, e._created_at, e._updated_at,
  CASE WHEN e.status = 'Draft' THEN 'draft' WHEN e.status = 'Out' THEN 'waiting' WHEN e.status = 'Completed' THEN 'completed' ELSE 'closed' END AS tab,
  (SELECT COUNT(*) FROM es_signers x WHERE x.envelope_id = e._id AND x._deleted = 0 AND x.status <> 'Removed') AS signers,
  (SELECT COUNT(*) FROM es_signers x WHERE x.envelope_id = e._id AND x._deleted = 0 AND x.status = 'Signed') AS signed,
  (SELECT group_concat(COALESCE(NULLIF(x.name, ''), x.role), ', ') FROM es_signers x WHERE x.envelope_id = e._id AND x._deleted = 0 AND x.status IN ('Invited', 'Opened')) AS waiting_on,
  (SELECT group_concat(COALESCE(NULLIF(x.name, ''), x.role), ', ') FROM es_signers x WHERE x.envelope_id = e._id AND x._deleted = 0 AND x.status <> 'Removed') AS people
FROM es_envelopes e
WHERE e._deleted = 0 AND e.status <> 'Discarded'
