SELECT 'email' AS kind, m._id AS id, m.envelope_id, e.title, m.purpose AS what, m.to_email AS who, m.error AS note, m._updated_at AS at
FROM es_emails m JOIN es_envelopes e ON e._id = m.envelope_id
WHERE m._deleted = 0 AND m.status = 'Failed'
UNION ALL
SELECT 'pdf' AS kind, e._id AS id, e._id AS envelope_id, e.title, 'signed PDF' AS what, '' AS who, e.finish_note AS note, e._updated_at AS at
FROM es_envelopes e WHERE e._deleted = 0 AND e.status = 'Completed' AND e.finish_status = 'Failed'
UNION ALL
SELECT 'read' AS kind, e._id AS id, e._id AS envelope_id, e.title, 'reading the file' AS what, '' AS who, e.prepare_note AS note, e._updated_at AS at
FROM es_envelopes e WHERE e._deleted = 0 AND e.status = 'Draft' AND e.prepare_status = 'Failed'
