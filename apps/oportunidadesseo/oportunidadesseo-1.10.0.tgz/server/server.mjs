// .stack/node_modules/@hono/node-server/dist/index.mjs
import { createServer as createServerHTTP } from "http";
import { Http2ServerRequest as Http2ServerRequest2 } from "http2";
import { Http2ServerRequest } from "http2";
import { Readable } from "stream";
import crypto from "crypto";
var RequestError = class extends Error {
  constructor(message, options) {
    super(message, options);
    this.name = "RequestError";
  }
};
var toRequestError = (e) => {
  if (e instanceof RequestError) {
    return e;
  }
  return new RequestError(e.message, { cause: e });
};
var GlobalRequest = global.Request;
var Request2 = class extends GlobalRequest {
  constructor(input, options) {
    if (typeof input === "object" && getRequestCache in input) {
      input = input[getRequestCache]();
    }
    if (typeof options?.body?.getReader !== "undefined") {
      ;
      options.duplex ??= "half";
    }
    super(input, options);
  }
};
var wrapBodyStream = Symbol("wrapBodyStream");
var newRequestFromIncoming = (method, url, incoming, abortController) => {
  const headerRecord = [];
  const rawHeaders = incoming.rawHeaders;
  for (let i = 0; i < rawHeaders.length; i += 2) {
    const { [i]: key, [i + 1]: value } = rawHeaders;
    if (key.charCodeAt(0) !== /*:*/
    58) {
      headerRecord.push([key, value]);
    }
  }
  const init = {
    method,
    headers: headerRecord,
    signal: abortController.signal
  };
  if (method === "TRACE") {
    init.method = "GET";
    const req = new Request2(url, init);
    Object.defineProperty(req, "method", {
      get() {
        return "TRACE";
      }
    });
    return req;
  }
  if (!(method === "GET" || method === "HEAD")) {
    if ("rawBody" in incoming && incoming.rawBody instanceof Buffer) {
      init.body = new ReadableStream({
        start(controller) {
          controller.enqueue(incoming.rawBody);
          controller.close();
        }
      });
    } else if (incoming[wrapBodyStream]) {
      let reader;
      init.body = new ReadableStream({
        async pull(controller) {
          try {
            reader ||= Readable.toWeb(incoming).getReader();
            const { done, value } = await reader.read();
            if (done) {
              controller.close();
            } else {
              controller.enqueue(value);
            }
          } catch (error) {
            controller.error(error);
          }
        }
      });
    } else {
      init.body = Readable.toWeb(incoming);
    }
  }
  return new Request2(url, init);
};
var getRequestCache = Symbol("getRequestCache");
var requestCache = Symbol("requestCache");
var incomingKey = Symbol("incomingKey");
var urlKey = Symbol("urlKey");
var abortControllerKey = Symbol("abortControllerKey");
var getAbortController = Symbol("getAbortController");
var requestPrototype = {
  get method() {
    return this[incomingKey].method || "GET";
  },
  get url() {
    return this[urlKey];
  },
  [getAbortController]() {
    this[getRequestCache]();
    return this[abortControllerKey];
  },
  [getRequestCache]() {
    this[abortControllerKey] ||= new AbortController();
    return this[requestCache] ||= newRequestFromIncoming(
      this.method,
      this[urlKey],
      this[incomingKey],
      this[abortControllerKey]
    );
  }
};
[
  "body",
  "bodyUsed",
  "cache",
  "credentials",
  "destination",
  "headers",
  "integrity",
  "mode",
  "redirect",
  "referrer",
  "referrerPolicy",
  "signal",
  "keepalive"
].forEach((k) => {
  Object.defineProperty(requestPrototype, k, {
    get() {
      return this[getRequestCache]()[k];
    }
  });
});
["arrayBuffer", "blob", "clone", "formData", "json", "text"].forEach((k) => {
  Object.defineProperty(requestPrototype, k, {
    value: function() {
      return this[getRequestCache]()[k]();
    }
  });
});
Object.setPrototypeOf(requestPrototype, Request2.prototype);
var newRequest = (incoming, defaultHostname) => {
  const req = Object.create(requestPrototype);
  req[incomingKey] = incoming;
  const incomingUrl = incoming.url || "";
  if (incomingUrl[0] !== "/" && // short-circuit for performance. most requests are relative URL.
  (incomingUrl.startsWith("http://") || incomingUrl.startsWith("https://"))) {
    if (incoming instanceof Http2ServerRequest) {
      throw new RequestError("Absolute URL for :path is not allowed in HTTP/2");
    }
    try {
      const url2 = new URL(incomingUrl);
      req[urlKey] = url2.href;
    } catch (e) {
      throw new RequestError("Invalid absolute URL", { cause: e });
    }
    return req;
  }
  const host = (incoming instanceof Http2ServerRequest ? incoming.authority : incoming.headers.host) || defaultHostname;
  if (!host) {
    throw new RequestError("Missing host header");
  }
  let scheme;
  if (incoming instanceof Http2ServerRequest) {
    scheme = incoming.scheme;
    if (!(scheme === "http" || scheme === "https")) {
      throw new RequestError("Unsupported scheme");
    }
  } else {
    scheme = incoming.socket && incoming.socket.encrypted ? "https" : "http";
  }
  const url = new URL(`${scheme}://${host}${incomingUrl}`);
  if (url.hostname.length !== host.length && url.hostname !== host.replace(/:\d+$/, "")) {
    throw new RequestError("Invalid host header");
  }
  req[urlKey] = url.href;
  return req;
};
var responseCache = Symbol("responseCache");
var getResponseCache = Symbol("getResponseCache");
var cacheKey = Symbol("cache");
var GlobalResponse = global.Response;
var Response2 = class _Response {
  #body;
  #init;
  [getResponseCache]() {
    delete this[cacheKey];
    return this[responseCache] ||= new GlobalResponse(this.#body, this.#init);
  }
  constructor(body, init) {
    let headers;
    this.#body = body;
    if (init instanceof _Response) {
      const cachedGlobalResponse = init[responseCache];
      if (cachedGlobalResponse) {
        this.#init = cachedGlobalResponse;
        this[getResponseCache]();
        return;
      } else {
        this.#init = init.#init;
        headers = new Headers(init.#init.headers);
      }
    } else {
      this.#init = init;
    }
    if (typeof body === "string" || typeof body?.getReader !== "undefined" || body instanceof Blob || body instanceof Uint8Array) {
      headers ||= init?.headers || { "content-type": "text/plain; charset=UTF-8" };
      this[cacheKey] = [init?.status || 200, body, headers];
    }
  }
  get headers() {
    const cache = this[cacheKey];
    if (cache) {
      if (!(cache[2] instanceof Headers)) {
        cache[2] = new Headers(cache[2]);
      }
      return cache[2];
    }
    return this[getResponseCache]().headers;
  }
  get status() {
    return this[cacheKey]?.[0] ?? this[getResponseCache]().status;
  }
  get ok() {
    const status = this.status;
    return status >= 200 && status < 300;
  }
};
["body", "bodyUsed", "redirected", "statusText", "trailers", "type", "url"].forEach((k) => {
  Object.defineProperty(Response2.prototype, k, {
    get() {
      return this[getResponseCache]()[k];
    }
  });
});
["arrayBuffer", "blob", "clone", "formData", "json", "text"].forEach((k) => {
  Object.defineProperty(Response2.prototype, k, {
    value: function() {
      return this[getResponseCache]()[k]();
    }
  });
});
Object.setPrototypeOf(Response2, GlobalResponse);
Object.setPrototypeOf(Response2.prototype, GlobalResponse.prototype);
async function readWithoutBlocking(readPromise) {
  return Promise.race([readPromise, Promise.resolve().then(() => Promise.resolve(void 0))]);
}
function writeFromReadableStreamDefaultReader(reader, writable, currentReadPromise) {
  const handleError = () => {
  };
  writable.on("error", handleError);
  (currentReadPromise ?? reader.read()).then(flow, handleStreamError);
  return reader.closed.finally(() => {
    writable.off("error", handleError);
  });
  function handleStreamError(error) {
    if (error) {
      writable.destroy(error);
    }
  }
  function onDrain() {
    reader.read().then(flow, handleStreamError);
  }
  function flow({ done, value }) {
    try {
      if (done) {
        writable.end();
      } else if (!writable.write(value)) {
        writable.once("drain", onDrain);
      } else {
        return reader.read().then(flow, handleStreamError);
      }
    } catch (e) {
      handleStreamError(e);
    }
  }
}
function writeFromReadableStream(stream, writable) {
  if (stream.locked) {
    throw new TypeError("ReadableStream is locked.");
  } else if (writable.destroyed) {
    return;
  }
  return writeFromReadableStreamDefaultReader(stream.getReader(), writable);
}
var buildOutgoingHttpHeaders = (headers) => {
  const res = {};
  if (!(headers instanceof Headers)) {
    headers = new Headers(headers ?? void 0);
  }
  const cookies = [];
  for (const [k, v] of headers) {
    if (k === "set-cookie") {
      cookies.push(v);
    } else {
      res[k] = v;
    }
  }
  if (cookies.length > 0) {
    res["set-cookie"] = cookies;
  }
  res["content-type"] ??= "text/plain; charset=UTF-8";
  return res;
};
var X_ALREADY_SENT = "x-hono-already-sent";
var webFetch = global.fetch;
if (typeof global.crypto === "undefined") {
  global.crypto = crypto;
}
global.fetch = (info, init) => {
  init = {
    // Disable compression handling so people can return the result of a fetch
    // directly in the loader without messing with the Content-Encoding header.
    compress: false,
    ...init
  };
  return webFetch(info, init);
};
var outgoingEnded = Symbol("outgoingEnded");
var handleRequestError = () => new Response(null, {
  status: 400
});
var handleFetchError = (e) => new Response(null, {
  status: e instanceof Error && (e.name === "TimeoutError" || e.constructor.name === "TimeoutError") ? 504 : 500
});
var handleResponseError = (e, outgoing) => {
  const err = e instanceof Error ? e : new Error("unknown error", { cause: e });
  if (err.code === "ERR_STREAM_PREMATURE_CLOSE") {
    console.info("The user aborted a request.");
  } else {
    console.error(e);
    if (!outgoing.headersSent) {
      outgoing.writeHead(500, { "Content-Type": "text/plain" });
    }
    outgoing.end(`Error: ${err.message}`);
    outgoing.destroy(err);
  }
};
var flushHeaders = (outgoing) => {
  if ("flushHeaders" in outgoing && outgoing.writable) {
    outgoing.flushHeaders();
  }
};
var responseViaCache = async (res, outgoing) => {
  let [status, body, header] = res[cacheKey];
  if (header instanceof Headers) {
    header = buildOutgoingHttpHeaders(header);
  }
  if (typeof body === "string") {
    header["Content-Length"] = Buffer.byteLength(body);
  } else if (body instanceof Uint8Array) {
    header["Content-Length"] = body.byteLength;
  } else if (body instanceof Blob) {
    header["Content-Length"] = body.size;
  }
  outgoing.writeHead(status, header);
  if (typeof body === "string" || body instanceof Uint8Array) {
    outgoing.end(body);
  } else if (body instanceof Blob) {
    outgoing.end(new Uint8Array(await body.arrayBuffer()));
  } else {
    flushHeaders(outgoing);
    await writeFromReadableStream(body, outgoing)?.catch(
      (e) => handleResponseError(e, outgoing)
    );
  }
  ;
  outgoing[outgoingEnded]?.();
};
var responseViaResponseObject = async (res, outgoing, options = {}) => {
  if (res instanceof Promise) {
    if (options.errorHandler) {
      try {
        res = await res;
      } catch (err) {
        const errRes = await options.errorHandler(err);
        if (!errRes) {
          return;
        }
        res = errRes;
      }
    } else {
      res = await res.catch(handleFetchError);
    }
  }
  if (cacheKey in res) {
    return responseViaCache(res, outgoing);
  }
  const resHeaderRecord = buildOutgoingHttpHeaders(res.headers);
  if (res.body) {
    const reader = res.body.getReader();
    const values = [];
    let done = false;
    let currentReadPromise = void 0;
    if (resHeaderRecord["transfer-encoding"] !== "chunked") {
      let maxReadCount = 2;
      for (let i = 0; i < maxReadCount; i++) {
        currentReadPromise ||= reader.read();
        const chunk = await readWithoutBlocking(currentReadPromise).catch((e) => {
          console.error(e);
          done = true;
        });
        if (!chunk) {
          if (i === 1) {
            await new Promise((resolve) => setTimeout(resolve));
            maxReadCount = 3;
            continue;
          }
          break;
        }
        currentReadPromise = void 0;
        if (chunk.value) {
          values.push(chunk.value);
        }
        if (chunk.done) {
          done = true;
          break;
        }
      }
      if (done && !("content-length" in resHeaderRecord)) {
        resHeaderRecord["content-length"] = values.reduce((acc, value) => acc + value.length, 0);
      }
    }
    outgoing.writeHead(res.status, resHeaderRecord);
    values.forEach((value) => {
      ;
      outgoing.write(value);
    });
    if (done) {
      outgoing.end();
    } else {
      if (values.length === 0) {
        flushHeaders(outgoing);
      }
      await writeFromReadableStreamDefaultReader(reader, outgoing, currentReadPromise);
    }
  } else if (resHeaderRecord[X_ALREADY_SENT]) {
  } else {
    outgoing.writeHead(res.status, resHeaderRecord);
    outgoing.end();
  }
  ;
  outgoing[outgoingEnded]?.();
};
var getRequestListener = (fetchCallback, options = {}) => {
  const autoCleanupIncoming = options.autoCleanupIncoming ?? true;
  if (options.overrideGlobalObjects !== false && global.Request !== Request2) {
    Object.defineProperty(global, "Request", {
      value: Request2
    });
    Object.defineProperty(global, "Response", {
      value: Response2
    });
  }
  return async (incoming, outgoing) => {
    let res, req;
    try {
      req = newRequest(incoming, options.hostname);
      let incomingEnded = !autoCleanupIncoming || incoming.method === "GET" || incoming.method === "HEAD";
      if (!incomingEnded) {
        ;
        incoming[wrapBodyStream] = true;
        incoming.on("end", () => {
          incomingEnded = true;
        });
        if (incoming instanceof Http2ServerRequest2) {
          ;
          outgoing[outgoingEnded] = () => {
            if (!incomingEnded) {
              setTimeout(() => {
                if (!incomingEnded) {
                  setTimeout(() => {
                    incoming.destroy();
                    outgoing.destroy();
                  });
                }
              });
            }
          };
        }
      }
      outgoing.on("close", () => {
        const abortController = req[abortControllerKey];
        if (abortController) {
          if (incoming.errored) {
            req[abortControllerKey].abort(incoming.errored.toString());
          } else if (!outgoing.writableFinished) {
            req[abortControllerKey].abort("Client connection prematurely closed.");
          }
        }
        if (!incomingEnded) {
          setTimeout(() => {
            if (!incomingEnded) {
              setTimeout(() => {
                incoming.destroy();
              });
            }
          });
        }
      });
      res = fetchCallback(req, { incoming, outgoing });
      if (cacheKey in res) {
        return responseViaCache(res, outgoing);
      }
    } catch (e) {
      if (!res) {
        if (options.errorHandler) {
          res = await options.errorHandler(req ? e : toRequestError(e));
          if (!res) {
            return;
          }
        } else if (!req) {
          res = handleRequestError();
        } else {
          res = handleFetchError(e);
        }
      } else {
        return handleResponseError(e, outgoing);
      }
    }
    try {
      return await responseViaResponseObject(res, outgoing, options);
    } catch (e) {
      return handleResponseError(e, outgoing);
    }
  };
};
var createAdaptorServer = (options) => {
  const fetchCallback = options.fetch;
  const requestListener = getRequestListener(fetchCallback, {
    hostname: options.hostname,
    overrideGlobalObjects: options.overrideGlobalObjects,
    autoCleanupIncoming: options.autoCleanupIncoming
  });
  const createServer = options.createServer || createServerHTTP;
  const server = createServer(options.serverOptions || {}, requestListener);
  return server;
};
var serve = (options, listeningListener) => {
  const server = createAdaptorServer(options);
  server.listen(options?.port ?? 3e3, options.hostname, () => {
    const serverInfo = server.address();
    listeningListener && listeningListener(serverInfo);
  });
  return server;
};

// .stack/node_modules/hono/dist/compose.js
var compose = (middleware, onError, onNotFound) => {
  return (context2, next) => {
    let index = -1;
    return dispatch(0);
    async function dispatch(i) {
      if (i <= index) {
        throw new Error("next() called multiple times");
      }
      index = i;
      let res;
      let isError = false;
      let handler;
      if (middleware[i]) {
        handler = middleware[i][0][0];
        context2.req.routeIndex = i;
      } else {
        handler = i === middleware.length && next || void 0;
      }
      if (handler) {
        try {
          res = await handler(context2, () => dispatch(i + 1));
        } catch (err) {
          if (err instanceof Error && onError) {
            context2.error = err;
            res = await onError(err, context2);
            isError = true;
          } else {
            throw err;
          }
        }
      } else {
        if (context2.finalized === false && onNotFound) {
          res = await onNotFound(context2);
        }
      }
      if (res && (context2.finalized === false || isError)) {
        context2.res = res;
      }
      return context2;
    }
  };
};

// .stack/node_modules/hono/dist/request/constants.js
var GET_MATCH_RESULT = /* @__PURE__ */ Symbol();

// .stack/node_modules/hono/dist/utils/body.js
var parseBody = async (request, options = /* @__PURE__ */ Object.create(null)) => {
  const { all = false, dot = false } = options;
  const headers = request instanceof HonoRequest ? request.raw.headers : request.headers;
  const contentType = headers.get("Content-Type");
  if (contentType?.startsWith("multipart/form-data") || contentType?.startsWith("application/x-www-form-urlencoded")) {
    return parseFormData(request, { all, dot });
  }
  return {};
};
async function parseFormData(request, options) {
  const formData = await request.formData();
  if (formData) {
    return convertFormDataToBodyData(formData, options);
  }
  return {};
}
function convertFormDataToBodyData(formData, options) {
  const form = /* @__PURE__ */ Object.create(null);
  formData.forEach((value, key) => {
    const shouldParseAllValues = options.all || key.endsWith("[]");
    if (!shouldParseAllValues) {
      form[key] = value;
    } else {
      handleParsingAllValues(form, key, value);
    }
  });
  if (options.dot) {
    Object.entries(form).forEach(([key, value]) => {
      const shouldParseDotValues = key.includes(".");
      if (shouldParseDotValues) {
        handleParsingNestedValues(form, key, value);
        delete form[key];
      }
    });
  }
  return form;
}
var handleParsingAllValues = (form, key, value) => {
  if (form[key] !== void 0) {
    if (Array.isArray(form[key])) {
      ;
      form[key].push(value);
    } else {
      form[key] = [form[key], value];
    }
  } else {
    if (!key.endsWith("[]")) {
      form[key] = value;
    } else {
      form[key] = [value];
    }
  }
};
var handleParsingNestedValues = (form, key, value) => {
  let nestedForm = form;
  const keys = key.split(".");
  keys.forEach((key2, index) => {
    if (index === keys.length - 1) {
      nestedForm[key2] = value;
    } else {
      if (!nestedForm[key2] || typeof nestedForm[key2] !== "object" || Array.isArray(nestedForm[key2]) || nestedForm[key2] instanceof File) {
        nestedForm[key2] = /* @__PURE__ */ Object.create(null);
      }
      nestedForm = nestedForm[key2];
    }
  });
};

// .stack/node_modules/hono/dist/utils/url.js
var splitPath = (path) => {
  const paths = path.split("/");
  if (paths[0] === "") {
    paths.shift();
  }
  return paths;
};
var splitRoutingPath = (routePath) => {
  const { groups, path } = extractGroupsFromPath(routePath);
  const paths = splitPath(path);
  return replaceGroupMarks(paths, groups);
};
var extractGroupsFromPath = (path) => {
  const groups = [];
  path = path.replace(/\{[^}]+\}/g, (match2, index) => {
    const mark = `@${index}`;
    groups.push([mark, match2]);
    return mark;
  });
  return { groups, path };
};
var replaceGroupMarks = (paths, groups) => {
  for (let i = groups.length - 1; i >= 0; i--) {
    const [mark] = groups[i];
    for (let j = paths.length - 1; j >= 0; j--) {
      if (paths[j].includes(mark)) {
        paths[j] = paths[j].replace(mark, groups[i][1]);
        break;
      }
    }
  }
  return paths;
};
var patternCache = {};
var getPattern = (label, next) => {
  if (label === "*") {
    return "*";
  }
  const match2 = label.match(/^\:([^\{\}]+)(?:\{(.+)\})?$/);
  if (match2) {
    const cacheKey2 = `${label}#${next}`;
    if (!patternCache[cacheKey2]) {
      if (match2[2]) {
        patternCache[cacheKey2] = next && next[0] !== ":" && next[0] !== "*" ? [cacheKey2, match2[1], new RegExp(`^${match2[2]}(?=/${next})`)] : [label, match2[1], new RegExp(`^${match2[2]}$`)];
      } else {
        patternCache[cacheKey2] = [label, match2[1], true];
      }
    }
    return patternCache[cacheKey2];
  }
  return null;
};
var tryDecode = (str, decoder) => {
  try {
    return decoder(str);
  } catch {
    return str.replace(/(?:%[0-9A-Fa-f]{2})+/g, (match2) => {
      try {
        return decoder(match2);
      } catch {
        return match2;
      }
    });
  }
};
var tryDecodeURI = (str) => tryDecode(str, decodeURI);
var getPath = (request) => {
  const url = request.url;
  const start = url.indexOf("/", url.indexOf(":") + 4);
  let i = start;
  for (; i < url.length; i++) {
    const charCode = url.charCodeAt(i);
    if (charCode === 37) {
      const queryIndex = url.indexOf("?", i);
      const hashIndex = url.indexOf("#", i);
      const end = queryIndex === -1 ? hashIndex === -1 ? void 0 : hashIndex : hashIndex === -1 ? queryIndex : Math.min(queryIndex, hashIndex);
      const path = url.slice(start, end);
      return tryDecodeURI(path.includes("%25") ? path.replace(/%25/g, "%2525") : path);
    } else if (charCode === 63 || charCode === 35) {
      break;
    }
  }
  return url.slice(start, i);
};
var getPathNoStrict = (request) => {
  const result = getPath(request);
  return result.length > 1 && result.at(-1) === "/" ? result.slice(0, -1) : result;
};
var mergePath = (base, sub, ...rest) => {
  if (rest.length) {
    sub = mergePath(sub, ...rest);
  }
  return `${base?.[0] === "/" ? "" : "/"}${base}${sub === "/" ? "" : `${base?.at(-1) === "/" ? "" : "/"}${sub?.[0] === "/" ? sub.slice(1) : sub}`}`;
};
var checkOptionalParameter = (path) => {
  if (path.charCodeAt(path.length - 1) !== 63 || !path.includes(":")) {
    return null;
  }
  const segments = path.split("/");
  const results = [];
  let basePath = "";
  segments.forEach((segment) => {
    if (segment !== "" && !/\:/.test(segment)) {
      basePath += "/" + segment;
    } else if (/\:/.test(segment)) {
      if (/\?/.test(segment)) {
        if (results.length === 0 && basePath === "") {
          results.push("/");
        } else {
          results.push(basePath);
        }
        const optionalSegment = segment.replace("?", "");
        basePath += "/" + optionalSegment;
        results.push(basePath);
      } else {
        basePath += "/" + segment;
      }
    }
  });
  return results.filter((v, i, a) => a.indexOf(v) === i);
};
var _decodeURI = (value) => {
  if (!/[%+]/.test(value)) {
    return value;
  }
  if (value.indexOf("+") !== -1) {
    value = value.replace(/\+/g, " ");
  }
  return value.indexOf("%") !== -1 ? tryDecode(value, decodeURIComponent_) : value;
};
var _getQueryParam = (url, key, multiple) => {
  let encoded;
  if (!multiple && key && !/[%+]/.test(key)) {
    let keyIndex2 = url.indexOf("?", 8);
    if (keyIndex2 === -1) {
      return void 0;
    }
    if (!url.startsWith(key, keyIndex2 + 1)) {
      keyIndex2 = url.indexOf(`&${key}`, keyIndex2 + 1);
    }
    while (keyIndex2 !== -1) {
      const trailingKeyCode = url.charCodeAt(keyIndex2 + key.length + 1);
      if (trailingKeyCode === 61) {
        const valueIndex = keyIndex2 + key.length + 2;
        const endIndex = url.indexOf("&", valueIndex);
        return _decodeURI(url.slice(valueIndex, endIndex === -1 ? void 0 : endIndex));
      } else if (trailingKeyCode == 38 || isNaN(trailingKeyCode)) {
        return "";
      }
      keyIndex2 = url.indexOf(`&${key}`, keyIndex2 + 1);
    }
    encoded = /[%+]/.test(url);
    if (!encoded) {
      return void 0;
    }
  }
  const results = {};
  encoded ??= /[%+]/.test(url);
  let keyIndex = url.indexOf("?", 8);
  while (keyIndex !== -1) {
    const nextKeyIndex = url.indexOf("&", keyIndex + 1);
    let valueIndex = url.indexOf("=", keyIndex);
    if (valueIndex > nextKeyIndex && nextKeyIndex !== -1) {
      valueIndex = -1;
    }
    let name = url.slice(
      keyIndex + 1,
      valueIndex === -1 ? nextKeyIndex === -1 ? void 0 : nextKeyIndex : valueIndex
    );
    if (encoded) {
      name = _decodeURI(name);
    }
    keyIndex = nextKeyIndex;
    if (name === "") {
      continue;
    }
    let value;
    if (valueIndex === -1) {
      value = "";
    } else {
      value = url.slice(valueIndex + 1, nextKeyIndex === -1 ? void 0 : nextKeyIndex);
      if (encoded) {
        value = _decodeURI(value);
      }
    }
    if (multiple) {
      if (!(results[name] && Array.isArray(results[name]))) {
        results[name] = [];
      }
      ;
      results[name].push(value);
    } else {
      results[name] ??= value;
    }
  }
  return key ? results[key] : results;
};
var getQueryParam = _getQueryParam;
var getQueryParams = (url, key) => {
  return _getQueryParam(url, key, true);
};
var decodeURIComponent_ = decodeURIComponent;

// .stack/node_modules/hono/dist/request.js
var tryDecodeURIComponent = (str) => tryDecode(str, decodeURIComponent_);
var HonoRequest = class {
  /**
   * `.raw` can get the raw Request object.
   *
   * @see {@link https://hono.dev/docs/api/request#raw}
   *
   * @example
   * ```ts
   * // For Cloudflare Workers
   * app.post('/', async (c) => {
   *   const metadata = c.req.raw.cf?.hostMetadata?
   *   ...
   * })
   * ```
   */
  raw;
  #validatedData;
  // Short name of validatedData
  #matchResult;
  routeIndex = 0;
  /**
   * `.path` can get the pathname of the request.
   *
   * @see {@link https://hono.dev/docs/api/request#path}
   *
   * @example
   * ```ts
   * app.get('/about/me', (c) => {
   *   const pathname = c.req.path // `/about/me`
   * })
   * ```
   */
  path;
  bodyCache = {};
  constructor(request, path = "/", matchResult = [[]]) {
    this.raw = request;
    this.path = path;
    this.#matchResult = matchResult;
    this.#validatedData = {};
  }
  param(key) {
    return key ? this.#getDecodedParam(key) : this.#getAllDecodedParams();
  }
  #getDecodedParam(key) {
    const paramKey = this.#matchResult[0][this.routeIndex][1][key];
    const param = this.#getParamValue(paramKey);
    return param && /\%/.test(param) ? tryDecodeURIComponent(param) : param;
  }
  #getAllDecodedParams() {
    const decoded = {};
    const keys = Object.keys(this.#matchResult[0][this.routeIndex][1]);
    for (const key of keys) {
      const value = this.#getParamValue(this.#matchResult[0][this.routeIndex][1][key]);
      if (value !== void 0) {
        decoded[key] = /\%/.test(value) ? tryDecodeURIComponent(value) : value;
      }
    }
    return decoded;
  }
  #getParamValue(paramKey) {
    return this.#matchResult[1] ? this.#matchResult[1][paramKey] : paramKey;
  }
  query(key) {
    return getQueryParam(this.url, key);
  }
  queries(key) {
    return getQueryParams(this.url, key);
  }
  header(name) {
    if (name) {
      return this.raw.headers.get(name) ?? void 0;
    }
    const headerData = {};
    this.raw.headers.forEach((value, key) => {
      headerData[key] = value;
    });
    return headerData;
  }
  async parseBody(options) {
    return this.bodyCache.parsedBody ??= await parseBody(this, options);
  }
  #cachedBody = (key) => {
    const { bodyCache, raw: raw2 } = this;
    const cachedBody = bodyCache[key];
    if (cachedBody) {
      return cachedBody;
    }
    const anyCachedKey = Object.keys(bodyCache)[0];
    if (anyCachedKey) {
      return bodyCache[anyCachedKey].then((body) => {
        if (anyCachedKey === "json") {
          body = JSON.stringify(body);
        }
        return new Response(body)[key]();
      });
    }
    return bodyCache[key] = raw2[key]();
  };
  /**
   * `.json()` can parse Request body of type `application/json`
   *
   * @see {@link https://hono.dev/docs/api/request#json}
   *
   * @example
   * ```ts
   * app.post('/entry', async (c) => {
   *   const body = await c.req.json()
   * })
   * ```
   */
  json() {
    return this.#cachedBody("text").then((text) => JSON.parse(text));
  }
  /**
   * `.text()` can parse Request body of type `text/plain`
   *
   * @see {@link https://hono.dev/docs/api/request#text}
   *
   * @example
   * ```ts
   * app.post('/entry', async (c) => {
   *   const body = await c.req.text()
   * })
   * ```
   */
  text() {
    return this.#cachedBody("text");
  }
  /**
   * `.arrayBuffer()` parse Request body as an `ArrayBuffer`
   *
   * @see {@link https://hono.dev/docs/api/request#arraybuffer}
   *
   * @example
   * ```ts
   * app.post('/entry', async (c) => {
   *   const body = await c.req.arrayBuffer()
   * })
   * ```
   */
  arrayBuffer() {
    return this.#cachedBody("arrayBuffer");
  }
  /**
   * Parses the request body as a `Blob`.
   * @example
   * ```ts
   * app.post('/entry', async (c) => {
   *   const body = await c.req.blob();
   * });
   * ```
   * @see https://hono.dev/docs/api/request#blob
   */
  blob() {
    return this.#cachedBody("blob");
  }
  /**
   * Parses the request body as `FormData`.
   * @example
   * ```ts
   * app.post('/entry', async (c) => {
   *   const body = await c.req.formData();
   * });
   * ```
   * @see https://hono.dev/docs/api/request#formdata
   */
  formData() {
    return this.#cachedBody("formData");
  }
  /**
   * Adds validated data to the request.
   *
   * @param target - The target of the validation.
   * @param data - The validated data to add.
   */
  addValidatedData(target, data) {
    this.#validatedData[target] = data;
  }
  valid(target) {
    return this.#validatedData[target];
  }
  /**
   * `.url()` can get the request url strings.
   *
   * @see {@link https://hono.dev/docs/api/request#url}
   *
   * @example
   * ```ts
   * app.get('/about/me', (c) => {
   *   const url = c.req.url // `http://localhost:8787/about/me`
   *   ...
   * })
   * ```
   */
  get url() {
    return this.raw.url;
  }
  /**
   * `.method()` can get the method name of the request.
   *
   * @see {@link https://hono.dev/docs/api/request#method}
   *
   * @example
   * ```ts
   * app.get('/about/me', (c) => {
   *   const method = c.req.method // `GET`
   * })
   * ```
   */
  get method() {
    return this.raw.method;
  }
  get [GET_MATCH_RESULT]() {
    return this.#matchResult;
  }
  /**
   * `.matchedRoutes()` can return a matched route in the handler
   *
   * @deprecated
   *
   * Use matchedRoutes helper defined in "hono/route" instead.
   *
   * @see {@link https://hono.dev/docs/api/request#matchedroutes}
   *
   * @example
   * ```ts
   * app.use('*', async function logger(c, next) {
   *   await next()
   *   c.req.matchedRoutes.forEach(({ handler, method, path }, i) => {
   *     const name = handler.name || (handler.length < 2 ? '[handler]' : '[middleware]')
   *     console.log(
   *       method,
   *       ' ',
   *       path,
   *       ' '.repeat(Math.max(10 - path.length, 0)),
   *       name,
   *       i === c.req.routeIndex ? '<- respond from here' : ''
   *     )
   *   })
   * })
   * ```
   */
  get matchedRoutes() {
    return this.#matchResult[0].map(([[, route]]) => route);
  }
  /**
   * `routePath()` can retrieve the path registered within the handler
   *
   * @deprecated
   *
   * Use routePath helper defined in "hono/route" instead.
   *
   * @see {@link https://hono.dev/docs/api/request#routepath}
   *
   * @example
   * ```ts
   * app.get('/posts/:id', (c) => {
   *   return c.json({ path: c.req.routePath })
   * })
   * ```
   */
  get routePath() {
    return this.#matchResult[0].map(([[, route]]) => route)[this.routeIndex].path;
  }
};

// .stack/node_modules/hono/dist/utils/html.js
var HtmlEscapedCallbackPhase = {
  Stringify: 1,
  BeforeStream: 2,
  Stream: 3
};
var raw = (value, callbacks) => {
  const escapedString = new String(value);
  escapedString.isEscaped = true;
  escapedString.callbacks = callbacks;
  return escapedString;
};
var resolveCallback = async (str, phase, preserveCallbacks, context2, buffer) => {
  if (typeof str === "object" && !(str instanceof String)) {
    if (!(str instanceof Promise)) {
      str = str.toString();
    }
    if (str instanceof Promise) {
      str = await str;
    }
  }
  const callbacks = str.callbacks;
  if (!callbacks?.length) {
    return Promise.resolve(str);
  }
  if (buffer) {
    buffer[0] += str;
  } else {
    buffer = [str];
  }
  const resStr = Promise.all(callbacks.map((c) => c({ phase, buffer, context: context2 }))).then(
    (res) => Promise.all(
      res.filter(Boolean).map((str2) => resolveCallback(str2, phase, false, context2, buffer))
    ).then(() => buffer[0])
  );
  if (preserveCallbacks) {
    return raw(await resStr, callbacks);
  } else {
    return resStr;
  }
};

// .stack/node_modules/hono/dist/context.js
var TEXT_PLAIN = "text/plain; charset=UTF-8";
var setDefaultContentType = (contentType, headers) => {
  return {
    "Content-Type": contentType,
    ...headers
  };
};
var createResponseInstance = (body, init) => new Response(body, init);
var Context = class {
  #rawRequest;
  #req;
  /**
   * `.env` can get bindings (environment variables, secrets, KV namespaces, D1 database, R2 bucket etc.) in Cloudflare Workers.
   *
   * @see {@link https://hono.dev/docs/api/context#env}
   *
   * @example
   * ```ts
   * // Environment object for Cloudflare Workers
   * app.get('*', async c => {
   *   const counter = c.env.COUNTER
   * })
   * ```
   */
  env = {};
  #var;
  finalized = false;
  /**
   * `.error` can get the error object from the middleware if the Handler throws an error.
   *
   * @see {@link https://hono.dev/docs/api/context#error}
   *
   * @example
   * ```ts
   * app.use('*', async (c, next) => {
   *   await next()
   *   if (c.error) {
   *     // do something...
   *   }
   * })
   * ```
   */
  error;
  #status;
  #executionCtx;
  #res;
  #layout;
  #renderer;
  #notFoundHandler;
  #preparedHeaders;
  #matchResult;
  #path;
  /**
   * Creates an instance of the Context class.
   *
   * @param req - The Request object.
   * @param options - Optional configuration options for the context.
   */
  constructor(req, options) {
    this.#rawRequest = req;
    if (options) {
      this.#executionCtx = options.executionCtx;
      this.env = options.env;
      this.#notFoundHandler = options.notFoundHandler;
      this.#path = options.path;
      this.#matchResult = options.matchResult;
    }
  }
  /**
   * `.req` is the instance of {@link HonoRequest}.
   */
  get req() {
    this.#req ??= new HonoRequest(this.#rawRequest, this.#path, this.#matchResult);
    return this.#req;
  }
  /**
   * @see {@link https://hono.dev/docs/api/context#event}
   * The FetchEvent associated with the current request.
   *
   * @throws Will throw an error if the context does not have a FetchEvent.
   */
  get event() {
    if (this.#executionCtx && "respondWith" in this.#executionCtx) {
      return this.#executionCtx;
    } else {
      throw Error("This context has no FetchEvent");
    }
  }
  /**
   * @see {@link https://hono.dev/docs/api/context#executionctx}
   * The ExecutionContext associated with the current request.
   *
   * @throws Will throw an error if the context does not have an ExecutionContext.
   */
  get executionCtx() {
    if (this.#executionCtx) {
      return this.#executionCtx;
    } else {
      throw Error("This context has no ExecutionContext");
    }
  }
  /**
   * @see {@link https://hono.dev/docs/api/context#res}
   * The Response object for the current request.
   */
  get res() {
    return this.#res ||= createResponseInstance(null, {
      headers: this.#preparedHeaders ??= new Headers()
    });
  }
  /**
   * Sets the Response object for the current request.
   *
   * @param _res - The Response object to set.
   */
  set res(_res) {
    if (this.#res && _res) {
      _res = createResponseInstance(_res.body, _res);
      for (const [k, v] of this.#res.headers.entries()) {
        if (k === "content-type") {
          continue;
        }
        if (k === "set-cookie") {
          const cookies = this.#res.headers.getSetCookie();
          _res.headers.delete("set-cookie");
          for (const cookie of cookies) {
            _res.headers.append("set-cookie", cookie);
          }
        } else {
          _res.headers.set(k, v);
        }
      }
    }
    this.#res = _res;
    this.finalized = true;
  }
  /**
   * `.render()` can create a response within a layout.
   *
   * @see {@link https://hono.dev/docs/api/context#render-setrenderer}
   *
   * @example
   * ```ts
   * app.get('/', (c) => {
   *   return c.render('Hello!')
   * })
   * ```
   */
  render = (...args) => {
    this.#renderer ??= (content2) => this.html(content2);
    return this.#renderer(...args);
  };
  /**
   * Sets the layout for the response.
   *
   * @param layout - The layout to set.
   * @returns The layout function.
   */
  setLayout = (layout) => this.#layout = layout;
  /**
   * Gets the current layout for the response.
   *
   * @returns The current layout function.
   */
  getLayout = () => this.#layout;
  /**
   * `.setRenderer()` can set the layout in the custom middleware.
   *
   * @see {@link https://hono.dev/docs/api/context#render-setrenderer}
   *
   * @example
   * ```tsx
   * app.use('*', async (c, next) => {
   *   c.setRenderer((content) => {
   *     return c.html(
   *       <html>
   *         <body>
   *           <p>{content}</p>
   *         </body>
   *       </html>
   *     )
   *   })
   *   await next()
   * })
   * ```
   */
  setRenderer = (renderer) => {
    this.#renderer = renderer;
  };
  /**
   * `.header()` can set headers.
   *
   * @see {@link https://hono.dev/docs/api/context#header}
   *
   * @example
   * ```ts
   * app.get('/welcome', (c) => {
   *   // Set headers
   *   c.header('X-Message', 'Hello!')
   *   c.header('Content-Type', 'text/plain')
   *
   *   return c.body('Thank you for coming')
   * })
   * ```
   */
  header = (name, value, options) => {
    if (this.finalized) {
      this.#res = createResponseInstance(this.#res.body, this.#res);
    }
    const headers = this.#res ? this.#res.headers : this.#preparedHeaders ??= new Headers();
    if (value === void 0) {
      headers.delete(name);
    } else if (options?.append) {
      headers.append(name, value);
    } else {
      headers.set(name, value);
    }
  };
  status = (status) => {
    this.#status = status;
  };
  /**
   * `.set()` can set the value specified by the key.
   *
   * @see {@link https://hono.dev/docs/api/context#set-get}
   *
   * @example
   * ```ts
   * app.use('*', async (c, next) => {
   *   c.set('message', 'Hono is hot!!')
   *   await next()
   * })
   * ```
   */
  set = (key, value) => {
    this.#var ??= /* @__PURE__ */ new Map();
    this.#var.set(key, value);
  };
  /**
   * `.get()` can use the value specified by the key.
   *
   * @see {@link https://hono.dev/docs/api/context#set-get}
   *
   * @example
   * ```ts
   * app.get('/', (c) => {
   *   const message = c.get('message')
   *   return c.text(`The message is "${message}"`)
   * })
   * ```
   */
  get = (key) => {
    return this.#var ? this.#var.get(key) : void 0;
  };
  /**
   * `.var` can access the value of a variable.
   *
   * @see {@link https://hono.dev/docs/api/context#var}
   *
   * @example
   * ```ts
   * const result = c.var.client.oneMethod()
   * ```
   */
  // c.var.propName is a read-only
  get var() {
    if (!this.#var) {
      return {};
    }
    return Object.fromEntries(this.#var);
  }
  #newResponse(data, arg, headers) {
    const responseHeaders = this.#res ? new Headers(this.#res.headers) : this.#preparedHeaders ?? new Headers();
    if (typeof arg === "object" && "headers" in arg) {
      const argHeaders = arg.headers instanceof Headers ? arg.headers : new Headers(arg.headers);
      for (const [key, value] of argHeaders) {
        if (key.toLowerCase() === "set-cookie") {
          responseHeaders.append(key, value);
        } else {
          responseHeaders.set(key, value);
        }
      }
    }
    if (headers) {
      for (const [k, v] of Object.entries(headers)) {
        if (typeof v === "string") {
          responseHeaders.set(k, v);
        } else {
          responseHeaders.delete(k);
          for (const v2 of v) {
            responseHeaders.append(k, v2);
          }
        }
      }
    }
    const status = typeof arg === "number" ? arg : arg?.status ?? this.#status;
    return createResponseInstance(data, { status, headers: responseHeaders });
  }
  newResponse = (...args) => this.#newResponse(...args);
  /**
   * `.body()` can return the HTTP response.
   * You can set headers with `.header()` and set HTTP status code with `.status`.
   * This can also be set in `.text()`, `.json()` and so on.
   *
   * @see {@link https://hono.dev/docs/api/context#body}
   *
   * @example
   * ```ts
   * app.get('/welcome', (c) => {
   *   // Set headers
   *   c.header('X-Message', 'Hello!')
   *   c.header('Content-Type', 'text/plain')
   *   // Set HTTP status code
   *   c.status(201)
   *
   *   // Return the response body
   *   return c.body('Thank you for coming')
   * })
   * ```
   */
  body = (data, arg, headers) => this.#newResponse(data, arg, headers);
  #useFastPath() {
    return !this.#preparedHeaders && !this.#status && !this.finalized;
  }
  /**
   * `.text()` can render text as `Content-Type:text/plain`.
   *
   * @see {@link https://hono.dev/docs/api/context#text}
   *
   * @example
   * ```ts
   * app.get('/say', (c) => {
   *   return c.text('Hello!')
   * })
   * ```
   */
  text = (text, arg, headers) => {
    return this.#useFastPath() && !arg && !headers ? createResponseInstance(text) : this.#newResponse(
      text,
      arg,
      setDefaultContentType(TEXT_PLAIN, headers)
    );
  };
  /**
   * `.json()` can render JSON as `Content-Type:application/json`.
   *
   * @see {@link https://hono.dev/docs/api/context#json}
   *
   * @example
   * ```ts
   * app.get('/api', (c) => {
   *   return c.json({ message: 'Hello!' })
   * })
   * ```
   */
  json = (object, arg, headers) => {
    return this.#useFastPath() && !arg && !headers ? Response.json(object) : this.#newResponse(
      JSON.stringify(object),
      arg,
      setDefaultContentType("application/json", headers)
    );
  };
  html = (html, arg, headers) => {
    const res = (html2) => this.#newResponse(html2, arg, setDefaultContentType("text/html; charset=UTF-8", headers));
    return typeof html === "object" ? resolveCallback(html, HtmlEscapedCallbackPhase.Stringify, false, {}).then(res) : res(html);
  };
  /**
   * `.redirect()` can Redirect, default status code is 302.
   *
   * @see {@link https://hono.dev/docs/api/context#redirect}
   *
   * @example
   * ```ts
   * app.get('/redirect', (c) => {
   *   return c.redirect('/')
   * })
   * app.get('/redirect-permanently', (c) => {
   *   return c.redirect('/', 301)
   * })
   * ```
   */
  redirect = (location, status) => {
    const locationString = String(location);
    this.header(
      "Location",
      // Multibyes should be encoded
      // eslint-disable-next-line no-control-regex
      !/[^\x00-\xFF]/.test(locationString) ? locationString : encodeURI(locationString)
    );
    return this.newResponse(null, status ?? 302);
  };
  /**
   * `.notFound()` can return the Not Found Response.
   *
   * @see {@link https://hono.dev/docs/api/context#notfound}
   *
   * @example
   * ```ts
   * app.get('/notfound', (c) => {
   *   return c.notFound()
   * })
   * ```
   */
  notFound = () => {
    this.#notFoundHandler ??= () => createResponseInstance();
    return this.#notFoundHandler(this);
  };
};

// .stack/node_modules/hono/dist/router.js
var METHOD_NAME_ALL = "ALL";
var METHOD_NAME_ALL_LOWERCASE = "all";
var METHODS = ["get", "post", "put", "delete", "options", "patch"];
var MESSAGE_MATCHER_IS_ALREADY_BUILT = "Can not add a route since the matcher is already built.";
var UnsupportedPathError = class extends Error {
};

// .stack/node_modules/hono/dist/utils/constants.js
var COMPOSED_HANDLER = "__COMPOSED_HANDLER";

// .stack/node_modules/hono/dist/hono-base.js
var notFoundHandler = (c) => {
  return c.text("404 Not Found", 404);
};
var errorHandler = (err, c) => {
  if ("getResponse" in err) {
    const res = err.getResponse();
    return c.newResponse(res.body, res);
  }
  console.error(err);
  return c.text("Internal Server Error", 500);
};
var Hono = class _Hono {
  get;
  post;
  put;
  delete;
  options;
  patch;
  all;
  on;
  use;
  /*
    This class is like an abstract class and does not have a router.
    To use it, inherit the class and implement router in the constructor.
  */
  router;
  getPath;
  // Cannot use `#` because it requires visibility at JavaScript runtime.
  _basePath = "/";
  #path = "/";
  routes = [];
  constructor(options = {}) {
    const allMethods = [...METHODS, METHOD_NAME_ALL_LOWERCASE];
    allMethods.forEach((method) => {
      this[method] = (args1, ...args) => {
        if (typeof args1 === "string") {
          this.#path = args1;
        } else {
          this.#addRoute(method, this.#path, args1);
        }
        args.forEach((handler) => {
          this.#addRoute(method, this.#path, handler);
        });
        return this;
      };
    });
    this.on = (method, path, ...handlers) => {
      for (const p of [path].flat()) {
        this.#path = p;
        for (const m of [method].flat()) {
          handlers.map((handler) => {
            this.#addRoute(m.toUpperCase(), this.#path, handler);
          });
        }
      }
      return this;
    };
    this.use = (arg1, ...handlers) => {
      if (typeof arg1 === "string") {
        this.#path = arg1;
      } else {
        this.#path = "*";
        handlers.unshift(arg1);
      }
      handlers.forEach((handler) => {
        this.#addRoute(METHOD_NAME_ALL, this.#path, handler);
      });
      return this;
    };
    const { strict, ...optionsWithoutStrict } = options;
    Object.assign(this, optionsWithoutStrict);
    this.getPath = strict ?? true ? options.getPath ?? getPath : getPathNoStrict;
  }
  #clone() {
    const clone = new _Hono({
      router: this.router,
      getPath: this.getPath
    });
    clone.errorHandler = this.errorHandler;
    clone.#notFoundHandler = this.#notFoundHandler;
    clone.routes = this.routes;
    return clone;
  }
  #notFoundHandler = notFoundHandler;
  // Cannot use `#` because it requires visibility at JavaScript runtime.
  errorHandler = errorHandler;
  /**
   * `.route()` allows grouping other Hono instance in routes.
   *
   * @see {@link https://hono.dev/docs/api/routing#grouping}
   *
   * @param {string} path - base Path
   * @param {Hono} app - other Hono instance
   * @returns {Hono} routed Hono instance
   *
   * @example
   * ```ts
   * const app = new Hono()
   * const app2 = new Hono()
   *
   * app2.get("/user", (c) => c.text("user"))
   * app.route("/api", app2) // GET /api/user
   * ```
   */
  route(path, app) {
    const subApp = this.basePath(path);
    app.routes.map((r) => {
      let handler;
      if (app.errorHandler === errorHandler) {
        handler = r.handler;
      } else {
        handler = async (c, next) => (await compose([], app.errorHandler)(c, () => r.handler(c, next))).res;
        handler[COMPOSED_HANDLER] = r.handler;
      }
      subApp.#addRoute(r.method, r.path, handler);
    });
    return this;
  }
  /**
   * `.basePath()` allows base paths to be specified.
   *
   * @see {@link https://hono.dev/docs/api/routing#base-path}
   *
   * @param {string} path - base Path
   * @returns {Hono} changed Hono instance
   *
   * @example
   * ```ts
   * const api = new Hono().basePath('/api')
   * ```
   */
  basePath(path) {
    const subApp = this.#clone();
    subApp._basePath = mergePath(this._basePath, path);
    return subApp;
  }
  /**
   * `.onError()` handles an error and returns a customized Response.
   *
   * @see {@link https://hono.dev/docs/api/hono#error-handling}
   *
   * @param {ErrorHandler} handler - request Handler for error
   * @returns {Hono} changed Hono instance
   *
   * @example
   * ```ts
   * app.onError((err, c) => {
   *   console.error(`${err}`)
   *   return c.text('Custom Error Message', 500)
   * })
   * ```
   */
  onError = (handler) => {
    this.errorHandler = handler;
    return this;
  };
  /**
   * `.notFound()` allows you to customize a Not Found Response.
   *
   * @see {@link https://hono.dev/docs/api/hono#not-found}
   *
   * @param {NotFoundHandler} handler - request handler for not-found
   * @returns {Hono} changed Hono instance
   *
   * @example
   * ```ts
   * app.notFound((c) => {
   *   return c.text('Custom 404 Message', 404)
   * })
   * ```
   */
  notFound = (handler) => {
    this.#notFoundHandler = handler;
    return this;
  };
  /**
   * `.mount()` allows you to mount applications built with other frameworks into your Hono application.
   *
   * @see {@link https://hono.dev/docs/api/hono#mount}
   *
   * @param {string} path - base Path
   * @param {Function} applicationHandler - other Request Handler
   * @param {MountOptions} [options] - options of `.mount()`
   * @returns {Hono} mounted Hono instance
   *
   * @example
   * ```ts
   * import { Router as IttyRouter } from 'itty-router'
   * import { Hono } from 'hono'
   * // Create itty-router application
   * const ittyRouter = IttyRouter()
   * // GET /itty-router/hello
   * ittyRouter.get('/hello', () => new Response('Hello from itty-router'))
   *
   * const app = new Hono()
   * app.mount('/itty-router', ittyRouter.handle)
   * ```
   *
   * @example
   * ```ts
   * const app = new Hono()
   * // Send the request to another application without modification.
   * app.mount('/app', anotherApp, {
   *   replaceRequest: (req) => req,
   * })
   * ```
   */
  mount(path, applicationHandler, options) {
    let replaceRequest;
    let optionHandler;
    if (options) {
      if (typeof options === "function") {
        optionHandler = options;
      } else {
        optionHandler = options.optionHandler;
        if (options.replaceRequest === false) {
          replaceRequest = (request) => request;
        } else {
          replaceRequest = options.replaceRequest;
        }
      }
    }
    const getOptions = optionHandler ? (c) => {
      const options2 = optionHandler(c);
      return Array.isArray(options2) ? options2 : [options2];
    } : (c) => {
      let executionContext = void 0;
      try {
        executionContext = c.executionCtx;
      } catch {
      }
      return [c.env, executionContext];
    };
    replaceRequest ||= (() => {
      const mergedPath = mergePath(this._basePath, path);
      const pathPrefixLength = mergedPath === "/" ? 0 : mergedPath.length;
      return (request) => {
        const url = new URL(request.url);
        url.pathname = url.pathname.slice(pathPrefixLength) || "/";
        return new Request(url, request);
      };
    })();
    const handler = async (c, next) => {
      const res = await applicationHandler(replaceRequest(c.req.raw), ...getOptions(c));
      if (res) {
        return res;
      }
      await next();
    };
    this.#addRoute(METHOD_NAME_ALL, mergePath(path, "*"), handler);
    return this;
  }
  #addRoute(method, path, handler) {
    method = method.toUpperCase();
    path = mergePath(this._basePath, path);
    const r = { basePath: this._basePath, path, method, handler };
    this.router.add(method, path, [handler, r]);
    this.routes.push(r);
  }
  #handleError(err, c) {
    if (err instanceof Error) {
      return this.errorHandler(err, c);
    }
    throw err;
  }
  #dispatch(request, executionCtx, env, method) {
    if (method === "HEAD") {
      return (async () => new Response(null, await this.#dispatch(request, executionCtx, env, "GET")))();
    }
    const path = this.getPath(request, { env });
    const matchResult = this.router.match(method, path);
    const c = new Context(request, {
      path,
      matchResult,
      env,
      executionCtx,
      notFoundHandler: this.#notFoundHandler
    });
    if (matchResult[0].length === 1) {
      let res;
      try {
        res = matchResult[0][0][0][0](c, async () => {
          c.res = await this.#notFoundHandler(c);
        });
      } catch (err) {
        return this.#handleError(err, c);
      }
      return res instanceof Promise ? res.then(
        (resolved) => resolved || (c.finalized ? c.res : this.#notFoundHandler(c))
      ).catch((err) => this.#handleError(err, c)) : res ?? this.#notFoundHandler(c);
    }
    const composed = compose(matchResult[0], this.errorHandler, this.#notFoundHandler);
    return (async () => {
      try {
        const context2 = await composed(c);
        if (!context2.finalized) {
          throw new Error(
            "Context is not finalized. Did you forget to return a Response object or `await next()`?"
          );
        }
        return context2.res;
      } catch (err) {
        return this.#handleError(err, c);
      }
    })();
  }
  /**
   * `.fetch()` will be entry point of your app.
   *
   * @see {@link https://hono.dev/docs/api/hono#fetch}
   *
   * @param {Request} request - request Object of request
   * @param {Env} Env - env Object
   * @param {ExecutionContext} - context of execution
   * @returns {Response | Promise<Response>} response of request
   *
   */
  fetch = (request, ...rest) => {
    return this.#dispatch(request, rest[1], rest[0], request.method);
  };
  /**
   * `.request()` is a useful method for testing.
   * You can pass a URL or pathname to send a GET request.
   * app will return a Response object.
   * ```ts
   * test('GET /hello is ok', async () => {
   *   const res = await app.request('/hello')
   *   expect(res.status).toBe(200)
   * })
   * ```
   * @see https://hono.dev/docs/api/hono#request
   */
  request = (input, requestInit, Env, executionCtx) => {
    if (input instanceof Request) {
      return this.fetch(requestInit ? new Request(input, requestInit) : input, Env, executionCtx);
    }
    input = input.toString();
    return this.fetch(
      new Request(
        /^https?:\/\//.test(input) ? input : `http://localhost${mergePath("/", input)}`,
        requestInit
      ),
      Env,
      executionCtx
    );
  };
  /**
   * `.fire()` automatically adds a global fetch event listener.
   * This can be useful for environments that adhere to the Service Worker API, such as non-ES module Cloudflare Workers.
   * @deprecated
   * Use `fire` from `hono/service-worker` instead.
   * ```ts
   * import { Hono } from 'hono'
   * import { fire } from 'hono/service-worker'
   *
   * const app = new Hono()
   * // ...
   * fire(app)
   * ```
   * @see https://hono.dev/docs/api/hono#fire
   * @see https://developer.mozilla.org/en-US/docs/Web/API/Service_Worker_API
   * @see https://developers.cloudflare.com/workers/reference/migrate-to-module-workers/
   */
  fire = () => {
    addEventListener("fetch", (event) => {
      event.respondWith(this.#dispatch(event.request, event, void 0, event.request.method));
    });
  };
};

// .stack/node_modules/hono/dist/router/reg-exp-router/matcher.js
var emptyParam = [];
function match(method, path) {
  const matchers = this.buildAllMatchers();
  const match2 = ((method2, path2) => {
    const matcher = matchers[method2] || matchers[METHOD_NAME_ALL];
    const staticMatch = matcher[2][path2];
    if (staticMatch) {
      return staticMatch;
    }
    const match3 = path2.match(matcher[0]);
    if (!match3) {
      return [[], emptyParam];
    }
    const index = match3.indexOf("", 1);
    return [matcher[1][index], match3];
  });
  this.match = match2;
  return match2(method, path);
}

// .stack/node_modules/hono/dist/router/reg-exp-router/node.js
var LABEL_REG_EXP_STR = "[^/]+";
var ONLY_WILDCARD_REG_EXP_STR = ".*";
var TAIL_WILDCARD_REG_EXP_STR = "(?:|/.*)";
var PATH_ERROR = /* @__PURE__ */ Symbol();
var regExpMetaChars = new Set(".\\+*[^]$()");
function compareKey(a, b) {
  if (a.length === 1) {
    return b.length === 1 ? a < b ? -1 : 1 : -1;
  }
  if (b.length === 1) {
    return 1;
  }
  if (a === ONLY_WILDCARD_REG_EXP_STR || a === TAIL_WILDCARD_REG_EXP_STR) {
    return 1;
  } else if (b === ONLY_WILDCARD_REG_EXP_STR || b === TAIL_WILDCARD_REG_EXP_STR) {
    return -1;
  }
  if (a === LABEL_REG_EXP_STR) {
    return 1;
  } else if (b === LABEL_REG_EXP_STR) {
    return -1;
  }
  return a.length === b.length ? a < b ? -1 : 1 : b.length - a.length;
}
var Node = class _Node {
  #index;
  #varIndex;
  #children = /* @__PURE__ */ Object.create(null);
  insert(tokens2, index, paramMap, context2, pathErrorCheckOnly) {
    if (tokens2.length === 0) {
      if (this.#index !== void 0) {
        throw PATH_ERROR;
      }
      if (pathErrorCheckOnly) {
        return;
      }
      this.#index = index;
      return;
    }
    const [token, ...restTokens] = tokens2;
    const pattern = token === "*" ? restTokens.length === 0 ? ["", "", ONLY_WILDCARD_REG_EXP_STR] : ["", "", LABEL_REG_EXP_STR] : token === "/*" ? ["", "", TAIL_WILDCARD_REG_EXP_STR] : token.match(/^\:([^\{\}]+)(?:\{(.+)\})?$/);
    let node;
    if (pattern) {
      const name = pattern[1];
      let regexpStr = pattern[2] || LABEL_REG_EXP_STR;
      if (name && pattern[2]) {
        if (regexpStr === ".*") {
          throw PATH_ERROR;
        }
        regexpStr = regexpStr.replace(/^\((?!\?:)(?=[^)]+\)$)/, "(?:");
        if (/\((?!\?:)/.test(regexpStr)) {
          throw PATH_ERROR;
        }
      }
      node = this.#children[regexpStr];
      if (!node) {
        if (Object.keys(this.#children).some(
          (k) => k !== ONLY_WILDCARD_REG_EXP_STR && k !== TAIL_WILDCARD_REG_EXP_STR
        )) {
          throw PATH_ERROR;
        }
        if (pathErrorCheckOnly) {
          return;
        }
        node = this.#children[regexpStr] = new _Node();
        if (name !== "") {
          node.#varIndex = context2.varIndex++;
        }
      }
      if (!pathErrorCheckOnly && name !== "") {
        paramMap.push([name, node.#varIndex]);
      }
    } else {
      node = this.#children[token];
      if (!node) {
        if (Object.keys(this.#children).some(
          (k) => k.length > 1 && k !== ONLY_WILDCARD_REG_EXP_STR && k !== TAIL_WILDCARD_REG_EXP_STR
        )) {
          throw PATH_ERROR;
        }
        if (pathErrorCheckOnly) {
          return;
        }
        node = this.#children[token] = new _Node();
      }
    }
    node.insert(restTokens, index, paramMap, context2, pathErrorCheckOnly);
  }
  buildRegExpStr() {
    const childKeys = Object.keys(this.#children).sort(compareKey);
    const strList = childKeys.map((k) => {
      const c = this.#children[k];
      return (typeof c.#varIndex === "number" ? `(${k})@${c.#varIndex}` : regExpMetaChars.has(k) ? `\\${k}` : k) + c.buildRegExpStr();
    });
    if (typeof this.#index === "number") {
      strList.unshift(`#${this.#index}`);
    }
    if (strList.length === 0) {
      return "";
    }
    if (strList.length === 1) {
      return strList[0];
    }
    return "(?:" + strList.join("|") + ")";
  }
};

// .stack/node_modules/hono/dist/router/reg-exp-router/trie.js
var Trie = class {
  #context = { varIndex: 0 };
  #root = new Node();
  insert(path, index, pathErrorCheckOnly) {
    const paramAssoc = [];
    const groups = [];
    for (let i = 0; ; ) {
      let replaced = false;
      path = path.replace(/\{[^}]+\}/g, (m) => {
        const mark = `@\\${i}`;
        groups[i] = [mark, m];
        i++;
        replaced = true;
        return mark;
      });
      if (!replaced) {
        break;
      }
    }
    const tokens2 = path.match(/(?::[^\/]+)|(?:\/\*$)|./g) || [];
    for (let i = groups.length - 1; i >= 0; i--) {
      const [mark] = groups[i];
      for (let j = tokens2.length - 1; j >= 0; j--) {
        if (tokens2[j].indexOf(mark) !== -1) {
          tokens2[j] = tokens2[j].replace(mark, groups[i][1]);
          break;
        }
      }
    }
    this.#root.insert(tokens2, index, paramAssoc, this.#context, pathErrorCheckOnly);
    return paramAssoc;
  }
  buildRegExp() {
    let regexp = this.#root.buildRegExpStr();
    if (regexp === "") {
      return [/^$/, [], []];
    }
    let captureIndex = 0;
    const indexReplacementMap = [];
    const paramReplacementMap = [];
    regexp = regexp.replace(/#(\d+)|@(\d+)|\.\*\$/g, (_, handlerIndex, paramIndex) => {
      if (handlerIndex !== void 0) {
        indexReplacementMap[++captureIndex] = Number(handlerIndex);
        return "$()";
      }
      if (paramIndex !== void 0) {
        paramReplacementMap[Number(paramIndex)] = ++captureIndex;
        return "";
      }
      return "";
    });
    return [new RegExp(`^${regexp}`), indexReplacementMap, paramReplacementMap];
  }
};

// .stack/node_modules/hono/dist/router/reg-exp-router/router.js
var nullMatcher = [/^$/, [], /* @__PURE__ */ Object.create(null)];
var wildcardRegExpCache = /* @__PURE__ */ Object.create(null);
function buildWildcardRegExp(path) {
  return wildcardRegExpCache[path] ??= new RegExp(
    path === "*" ? "" : `^${path.replace(
      /\/\*$|([.\\+*[^\]$()])/g,
      (_, metaChar) => metaChar ? `\\${metaChar}` : "(?:|/.*)"
    )}$`
  );
}
function clearWildcardRegExpCache() {
  wildcardRegExpCache = /* @__PURE__ */ Object.create(null);
}
function buildMatcherFromPreprocessedRoutes(routes) {
  const trie = new Trie();
  const handlerData = [];
  if (routes.length === 0) {
    return nullMatcher;
  }
  const routesWithStaticPathFlag = routes.map(
    (route) => [!/\*|\/:/.test(route[0]), ...route]
  ).sort(
    ([isStaticA, pathA], [isStaticB, pathB]) => isStaticA ? 1 : isStaticB ? -1 : pathA.length - pathB.length
  );
  const staticMap = /* @__PURE__ */ Object.create(null);
  for (let i = 0, j = -1, len = routesWithStaticPathFlag.length; i < len; i++) {
    const [pathErrorCheckOnly, path, handlers] = routesWithStaticPathFlag[i];
    if (pathErrorCheckOnly) {
      staticMap[path] = [handlers.map(([h]) => [h, /* @__PURE__ */ Object.create(null)]), emptyParam];
    } else {
      j++;
    }
    let paramAssoc;
    try {
      paramAssoc = trie.insert(path, j, pathErrorCheckOnly);
    } catch (e) {
      throw e === PATH_ERROR ? new UnsupportedPathError(path) : e;
    }
    if (pathErrorCheckOnly) {
      continue;
    }
    handlerData[j] = handlers.map(([h, paramCount]) => {
      const paramIndexMap = /* @__PURE__ */ Object.create(null);
      paramCount -= 1;
      for (; paramCount >= 0; paramCount--) {
        const [key, value] = paramAssoc[paramCount];
        paramIndexMap[key] = value;
      }
      return [h, paramIndexMap];
    });
  }
  const [regexp, indexReplacementMap, paramReplacementMap] = trie.buildRegExp();
  for (let i = 0, len = handlerData.length; i < len; i++) {
    for (let j = 0, len2 = handlerData[i].length; j < len2; j++) {
      const map = handlerData[i][j]?.[1];
      if (!map) {
        continue;
      }
      const keys = Object.keys(map);
      for (let k = 0, len3 = keys.length; k < len3; k++) {
        map[keys[k]] = paramReplacementMap[map[keys[k]]];
      }
    }
  }
  const handlerMap = [];
  for (const i in indexReplacementMap) {
    handlerMap[i] = handlerData[indexReplacementMap[i]];
  }
  return [regexp, handlerMap, staticMap];
}
function findMiddleware(middleware, path) {
  if (!middleware) {
    return void 0;
  }
  for (const k of Object.keys(middleware).sort((a, b) => b.length - a.length)) {
    if (buildWildcardRegExp(k).test(path)) {
      return [...middleware[k]];
    }
  }
  return void 0;
}
var RegExpRouter = class {
  name = "RegExpRouter";
  #middleware;
  #routes;
  constructor() {
    this.#middleware = { [METHOD_NAME_ALL]: /* @__PURE__ */ Object.create(null) };
    this.#routes = { [METHOD_NAME_ALL]: /* @__PURE__ */ Object.create(null) };
  }
  add(method, path, handler) {
    const middleware = this.#middleware;
    const routes = this.#routes;
    if (!middleware || !routes) {
      throw new Error(MESSAGE_MATCHER_IS_ALREADY_BUILT);
    }
    if (!middleware[method]) {
      ;
      [middleware, routes].forEach((handlerMap) => {
        handlerMap[method] = /* @__PURE__ */ Object.create(null);
        Object.keys(handlerMap[METHOD_NAME_ALL]).forEach((p) => {
          handlerMap[method][p] = [...handlerMap[METHOD_NAME_ALL][p]];
        });
      });
    }
    if (path === "/*") {
      path = "*";
    }
    const paramCount = (path.match(/\/:/g) || []).length;
    if (/\*$/.test(path)) {
      const re = buildWildcardRegExp(path);
      if (method === METHOD_NAME_ALL) {
        Object.keys(middleware).forEach((m) => {
          middleware[m][path] ||= findMiddleware(middleware[m], path) || findMiddleware(middleware[METHOD_NAME_ALL], path) || [];
        });
      } else {
        middleware[method][path] ||= findMiddleware(middleware[method], path) || findMiddleware(middleware[METHOD_NAME_ALL], path) || [];
      }
      Object.keys(middleware).forEach((m) => {
        if (method === METHOD_NAME_ALL || method === m) {
          Object.keys(middleware[m]).forEach((p) => {
            re.test(p) && middleware[m][p].push([handler, paramCount]);
          });
        }
      });
      Object.keys(routes).forEach((m) => {
        if (method === METHOD_NAME_ALL || method === m) {
          Object.keys(routes[m]).forEach(
            (p) => re.test(p) && routes[m][p].push([handler, paramCount])
          );
        }
      });
      return;
    }
    const paths = checkOptionalParameter(path) || [path];
    for (let i = 0, len = paths.length; i < len; i++) {
      const path2 = paths[i];
      Object.keys(routes).forEach((m) => {
        if (method === METHOD_NAME_ALL || method === m) {
          routes[m][path2] ||= [
            ...findMiddleware(middleware[m], path2) || findMiddleware(middleware[METHOD_NAME_ALL], path2) || []
          ];
          routes[m][path2].push([handler, paramCount - len + i + 1]);
        }
      });
    }
  }
  match = match;
  buildAllMatchers() {
    const matchers = /* @__PURE__ */ Object.create(null);
    Object.keys(this.#routes).concat(Object.keys(this.#middleware)).forEach((method) => {
      matchers[method] ||= this.#buildMatcher(method);
    });
    this.#middleware = this.#routes = void 0;
    clearWildcardRegExpCache();
    return matchers;
  }
  #buildMatcher(method) {
    const routes = [];
    let hasOwnRoute = method === METHOD_NAME_ALL;
    [this.#middleware, this.#routes].forEach((r) => {
      const ownRoute = r[method] ? Object.keys(r[method]).map((path) => [path, r[method][path]]) : [];
      if (ownRoute.length !== 0) {
        hasOwnRoute ||= true;
        routes.push(...ownRoute);
      } else if (method !== METHOD_NAME_ALL) {
        routes.push(
          ...Object.keys(r[METHOD_NAME_ALL]).map((path) => [path, r[METHOD_NAME_ALL][path]])
        );
      }
    });
    if (!hasOwnRoute) {
      return null;
    } else {
      return buildMatcherFromPreprocessedRoutes(routes);
    }
  }
};

// .stack/node_modules/hono/dist/router/smart-router/router.js
var SmartRouter = class {
  name = "SmartRouter";
  #routers = [];
  #routes = [];
  constructor(init) {
    this.#routers = init.routers;
  }
  add(method, path, handler) {
    if (!this.#routes) {
      throw new Error(MESSAGE_MATCHER_IS_ALREADY_BUILT);
    }
    this.#routes.push([method, path, handler]);
  }
  match(method, path) {
    if (!this.#routes) {
      throw new Error("Fatal error");
    }
    const routers = this.#routers;
    const routes = this.#routes;
    const len = routers.length;
    let i = 0;
    let res;
    for (; i < len; i++) {
      const router = routers[i];
      try {
        for (let i2 = 0, len2 = routes.length; i2 < len2; i2++) {
          router.add(...routes[i2]);
        }
        res = router.match(method, path);
      } catch (e) {
        if (e instanceof UnsupportedPathError) {
          continue;
        }
        throw e;
      }
      this.match = router.match.bind(router);
      this.#routers = [router];
      this.#routes = void 0;
      break;
    }
    if (i === len) {
      throw new Error("Fatal error");
    }
    this.name = `SmartRouter + ${this.activeRouter.name}`;
    return res;
  }
  get activeRouter() {
    if (this.#routes || this.#routers.length !== 1) {
      throw new Error("No active router has been determined yet.");
    }
    return this.#routers[0];
  }
};

// .stack/node_modules/hono/dist/router/trie-router/node.js
var emptyParams = /* @__PURE__ */ Object.create(null);
var hasChildren = (children) => {
  for (const _ in children) {
    return true;
  }
  return false;
};
var Node2 = class _Node2 {
  #methods;
  #children;
  #patterns;
  #order = 0;
  #params = emptyParams;
  constructor(method, handler, children) {
    this.#children = children || /* @__PURE__ */ Object.create(null);
    this.#methods = [];
    if (method && handler) {
      const m = /* @__PURE__ */ Object.create(null);
      m[method] = { handler, possibleKeys: [], score: 0 };
      this.#methods = [m];
    }
    this.#patterns = [];
  }
  insert(method, path, handler) {
    this.#order = ++this.#order;
    let curNode = this;
    const parts = splitRoutingPath(path);
    const possibleKeys = [];
    for (let i = 0, len = parts.length; i < len; i++) {
      const p = parts[i];
      const nextP = parts[i + 1];
      const pattern = getPattern(p, nextP);
      const key = Array.isArray(pattern) ? pattern[0] : p;
      if (key in curNode.#children) {
        curNode = curNode.#children[key];
        if (pattern) {
          possibleKeys.push(pattern[1]);
        }
        continue;
      }
      curNode.#children[key] = new _Node2();
      if (pattern) {
        curNode.#patterns.push(pattern);
        possibleKeys.push(pattern[1]);
      }
      curNode = curNode.#children[key];
    }
    curNode.#methods.push({
      [method]: {
        handler,
        possibleKeys: possibleKeys.filter((v, i, a) => a.indexOf(v) === i),
        score: this.#order
      }
    });
    return curNode;
  }
  #pushHandlerSets(handlerSets, node, method, nodeParams, params) {
    for (let i = 0, len = node.#methods.length; i < len; i++) {
      const m = node.#methods[i];
      const handlerSet = m[method] || m[METHOD_NAME_ALL];
      const processedSet = {};
      if (handlerSet !== void 0) {
        handlerSet.params = /* @__PURE__ */ Object.create(null);
        handlerSets.push(handlerSet);
        if (nodeParams !== emptyParams || params && params !== emptyParams) {
          for (let i2 = 0, len2 = handlerSet.possibleKeys.length; i2 < len2; i2++) {
            const key = handlerSet.possibleKeys[i2];
            const processed = processedSet[handlerSet.score];
            handlerSet.params[key] = params?.[key] && !processed ? params[key] : nodeParams[key] ?? params?.[key];
            processedSet[handlerSet.score] = true;
          }
        }
      }
    }
  }
  search(method, path) {
    const handlerSets = [];
    this.#params = emptyParams;
    const curNode = this;
    let curNodes = [curNode];
    const parts = splitPath(path);
    const curNodesQueue = [];
    const len = parts.length;
    let partOffsets = null;
    for (let i = 0; i < len; i++) {
      const part = parts[i];
      const isLast = i === len - 1;
      const tempNodes = [];
      for (let j = 0, len2 = curNodes.length; j < len2; j++) {
        const node = curNodes[j];
        const nextNode = node.#children[part];
        if (nextNode) {
          nextNode.#params = node.#params;
          if (isLast) {
            if (nextNode.#children["*"]) {
              this.#pushHandlerSets(handlerSets, nextNode.#children["*"], method, node.#params);
            }
            this.#pushHandlerSets(handlerSets, nextNode, method, node.#params);
          } else {
            tempNodes.push(nextNode);
          }
        }
        for (let k = 0, len3 = node.#patterns.length; k < len3; k++) {
          const pattern = node.#patterns[k];
          const params = node.#params === emptyParams ? {} : { ...node.#params };
          if (pattern === "*") {
            const astNode = node.#children["*"];
            if (astNode) {
              this.#pushHandlerSets(handlerSets, astNode, method, node.#params);
              astNode.#params = params;
              tempNodes.push(astNode);
            }
            continue;
          }
          const [key, name, matcher] = pattern;
          if (!part && !(matcher instanceof RegExp)) {
            continue;
          }
          const child = node.#children[key];
          if (matcher instanceof RegExp) {
            if (partOffsets === null) {
              partOffsets = new Array(len);
              let offset = path[0] === "/" ? 1 : 0;
              for (let p = 0; p < len; p++) {
                partOffsets[p] = offset;
                offset += parts[p].length + 1;
              }
            }
            const restPathString = path.substring(partOffsets[i]);
            const m = matcher.exec(restPathString);
            if (m) {
              params[name] = m[0];
              this.#pushHandlerSets(handlerSets, child, method, node.#params, params);
              if (hasChildren(child.#children)) {
                child.#params = params;
                const componentCount = m[0].match(/\//)?.length ?? 0;
                const targetCurNodes = curNodesQueue[componentCount] ||= [];
                targetCurNodes.push(child);
              }
              continue;
            }
          }
          if (matcher === true || matcher.test(part)) {
            params[name] = part;
            if (isLast) {
              this.#pushHandlerSets(handlerSets, child, method, params, node.#params);
              if (child.#children["*"]) {
                this.#pushHandlerSets(
                  handlerSets,
                  child.#children["*"],
                  method,
                  params,
                  node.#params
                );
              }
            } else {
              child.#params = params;
              tempNodes.push(child);
            }
          }
        }
      }
      const shifted = curNodesQueue.shift();
      curNodes = shifted ? tempNodes.concat(shifted) : tempNodes;
    }
    if (handlerSets.length > 1) {
      handlerSets.sort((a, b) => {
        return a.score - b.score;
      });
    }
    return [handlerSets.map(({ handler, params }) => [handler, params])];
  }
};

// .stack/node_modules/hono/dist/router/trie-router/router.js
var TrieRouter = class {
  name = "TrieRouter";
  #node;
  constructor() {
    this.#node = new Node2();
  }
  add(method, path, handler) {
    const results = checkOptionalParameter(path);
    if (results) {
      for (let i = 0, len = results.length; i < len; i++) {
        this.#node.insert(method, results[i], handler);
      }
      return;
    }
    this.#node.insert(method, path, handler);
  }
  match(method, path) {
    return this.#node.search(method, path);
  }
};

// .stack/node_modules/hono/dist/hono.js
var Hono2 = class extends Hono {
  /**
   * Creates an instance of the Hono class.
   *
   * @param options - Optional configuration options for the Hono instance.
   */
  constructor(options = {}) {
    super(options);
    this.router = options.router ?? new SmartRouter({
      routers: [new RegExpRouter(), new TrieRouter()]
    });
  }
};

// server/services/ayuda.mjs
var UNA_FRASE = {
  radar: "Counts of what there is: goals, almost-there keywords, gaps, Search Console queries, and what the settings say.",
  oportunidad_detalle: "One goal: its state, position, actions and next step; brief: true adds the brief to write from.",
  puntuar: "Recalculates a goal's score and priority.",
  datos_ahrefs: "Optional: a goal's figures and top 10 from Ahrefs, with a key of the company's own.",
  datos_ejemplo: "Fills a goal that has nothing real with an example, with no figures, marked as such.",
  guardar_investigacion: "Saves what you read in a goal's top 10: what each result covers and the gaps.",
  guardar_brief: "Saves a goal's brief.",
  aprobar: "The person approves a goal: it starts being worked and measured, and its starting point is saved.",
  descartar: "The person discards a goal, with the reason.",
  anadir_accion: "The person adds an action to an approved goal (an article, a service page, a real case, a refresh, internal links).",
  vincular_accion: "Says what an action produced and how it is going (the record made in another module, its address, done).",
  cancelar_accion: "The person cancels an action that is not done.",
  vincular_articulo: "Links the article you created in Art\xEDculos to its goal, as that goal's article action.",
  proponer_siguiente: "Proposes ONE next step for a goal (above all a stalled one); the person adds it with a button.",
  acciones_por_hacer: "The actions of approved goals still to do in Art\xEDculos and not linked yet (what the trigger answers).",
  objetivos: "Every goal with its state today: position, places won, weeks without improving, actions, next step.",
  resumen: "How it is going: goals per state, this week's movements, what is under way and what waits for the person.",
  modulos: "Which action types can be added to a goal, and which another module unlocks.",
  revisar_objetivos: "The weekly review: today's Google position of each approved goal (about 0,002 $ a goal); runs by itself on Mondays.",
  actualizar_articulos: "Brings each goal's article action up to date from what Art\xEDculos exports. Free; runs by itself.",
  datos_dataforseo: "Brings or refreshes ONE goal's real data: figures, today's top 10, why it can be won (about 0,03 $).",
  casi_lista: "Keywords the site ranks 8\u201320 for, each with the page that ranks and what to do with it.",
  buscar_casi: "Finds the keywords the site ranks 8\u201320 for (0,01\u20130,07 $, seconds).",
  casi_a_oportunidad: "Makes goals \xABPor decidir\xBB of almost-there keywords: id, or ids [..] for several in one call.",
  buscar_huecos: "Finds keywords competitors rank for and the site does not, already filtered (0,10\u20130,30 $).",
  refiltrar_huecos: "Runs the gaps filter again after the settings changed, without asking DataForSEO again.",
  descartes_lista: "What the last gaps filter left out, each with why.",
  buscar_competidores: "Proposes the domains that compete with the company in Google (0,10\u20130,20 $); changes no setting.",
  competidores_lista: "The competitors proposed and discarded by the last search.",
  adoptar_competidor: "The person adds a proposed domain to the competitors.",
  importar_competidores: "Adds a list of competitors the PERSON gave you; nunca: true marks them as never competitors.",
  nunca_competidor: "The person says a proposed domain is never a competitor.",
  quien_sale: "Who ranks today for one search, from what the module has kept (free), and whether it can be won.",
  ver_quien_sale: "Asks Google for today's top 10 of ONE search and keeps it (about 0,002 $).",
  diagnosticar: "The diagnosis: why the site does not show in Google and the 5 pages it can win first (0,05\u20130,10 $).",
  diagnostico_ver: "The last diagnosis: conclusion, figures, technical problems and its plan.",
  diagnostico_a_oportunidades: "Makes goals \xABPor decidir\xBB of the last diagnosis' plan (keyword: only that page).",
  probar_serp: "A diagnostic of how a top 10 arrives from DataForSEO (about 0,004 $). Not for normal work.",
  revisar_ia: "Asks ChatGPT and reads Google's AI answer for the company's topics: is it named, and who is (0,03\u20130,05 $).",
  ia_ver: "Whether the AIs name the company, topic by topic, and who they name instead.",
  vigilar_competidores: "Reads what each competitor published since last time. Free; runs by itself on Mondays.",
  novedad_a_objetivo: "The person makes a goal of something a competitor published and the company has nothing on.",
  ia_a_objetivo: "The person makes a goal of a question the AI answers without naming the company.",
  preparar_busqueda: "Before a guided search (free): the criteria, how the site is doing, which suit it, and what to confirm with the person.",
  planear_busqueda: "The screen's own step of the guided search (saves what was confirmed, answers the requests). Use buscar_nuevas.",
  buscar_nuevas: "The whole guided search in ONE command: runs the chosen criteria and measures the 10 best (0\u20130,70 $).",
  medir_candidatos: "Measures candidates before they are goals: figures, today's top 10, whether each can be won (\u22480,03 $ + 0,002 $ each).",
  buscar_defender: "Finds the searches the site already has on the first page (free with Search Console, else about 0,02 $).",
  buscar_empezar: "Finds long, specific searches a new site can win, from Google's own suggestions. Free.",
  candidato_a_objetivo: "The person makes a goal of a \xABYa la tienes\xBB or \xABPara empezar\xBB candidate.",
  descubrir: "What the company could win next: counts per source and the first candidates; fuente, ganar, desde, limite filter and page.",
  descartar_candidato: "The person discards a candidate that has no row of its own (plan, ia, defender, empezar).",
  novedades_ver: "What each competitor published in the last 60 days and whether the company covers it.",
  tu_web: "What the site already has: its pages with the searches each shows for and the goal that covers it.",
  leer_sitemap: "Reads the site's robots.txt and sitemap for \xABTu web\xBB. Free, seconds.",
  ahrefs_estado: "Whether the module may read the company's Ahrefs and how many units are left. Free.",
  gasto_dataforseo: "What each command cost in DataForSEO the last time, and the total.",
  huecos_ejemplo: "Example gaps with no figures, to look at the screen before there is any data.",
  hueco_a_oportunidad: "Makes goals \xABPor decidir\xBB of gaps: id, or ids [..] for several in one call.",
  buscar_ideas_publico: "Finds what the audience searches in its day to day (0,05\u20130,25 $); each idea then needs your bridge.",
  ideas_publico: "The audience ideas: those waiting for your bridge (sin_puente) and those that have one.",
  guardar_puentes: "Saves the bridge of each idea, all in one call: puentes [{ id, puente, producto }].",
  idea_a_oportunidad: "Makes goals \xABPor decidir\xBB of ideas that have a bridge: id, or ids [..] for several in one call.",
  actualizar_search_console: "Reads Search Console's last 28 days by itself, with no agent turn. Free."
};

// server/command.mjs
var POR_ESTADO = { 400: "BAD_INPUT", 403: "NOT_ALLOWED", 404: "NOT_FOUND", 413: "TOO_BIG", 424: "MISSING_KEYS", 429: "SPENDING_LIMIT", 502: "PROVIDER_FAILED", 504: "PROVIDER_TIMEOUT" };
function codeOf(message, status = 409) {
  const m = String(message || "");
  if (/^Only a person/.test(m)) return "PERSON_ONLY";
  if (/^Ya es (la oportunidad|el objetivo|un objetivo)/.test(m)) return "ALREADY_A_GOAL";
  if (/^Ya (está|hay) /.test(m)) return "ALREADY_DONE";
  if (/Aprueba el objetivo|^Está descartado/.test(m)) return "NOT_APPROVED";
  if (/no tiene puente/.test(m)) return "NO_BRIDGE";
  if (/^Instala /.test(m)) return "NEEDS_MODULE";
  if (status === 400 && /^Faltan? /.test(m)) return "MISSING_SETTING";
  return POR_ESTADO[status] ?? (status >= 500 ? "FAILED" : "REFUSED");
}
var Refused = class extends Error {
  constructor(message, status = 409, extra = {}) {
    super(message);
    this.status = status;
    this.code = extra.code ?? codeOf(message, status);
    const n = extra.item ?? (this.code === "ALREADY_A_GOAL" ? Number((String(message).match(/nº (\d+)/) || [])[1]) || void 0 : void 0);
    if (n !== void 0) this.item = n;
  }
};
var entero = (body) => [body?.full, body?.completo].some((v) => v === true || v === "true");
var commandsOf = (app) => app.commands ??= [];
var inputNames = (input) => Array.isArray(input) ? input.flatMap((x) => typeof x === "string" ? [x] : Object.keys(x)) : Object.keys(input ?? {});
function command(app, method, path, spec, handler) {
  const { brief, ...told } = spec;
  const una = UNA_FRASE[spec.name];
  const summary2 = (una ? una + " " : "") + spec.summary + (brief ? " Agents get a brief answer (figures, the first rows, where the rest is); full: true (or completo: true) gives everything the screen reads." : "");
  commandsOf(app).push({ ...told, summary: summary2, method, path, input: brief ? { ...Array.isArray(spec.input) ? Object.fromEntries(inputNames(spec.input).map((k) => [k, "text"])) : spec.input ?? {}, full: "boolean", completo: "boolean" } : spec.input ?? {}, by: spec.by ?? "anyone", read: method === "GET" });
  app.on(method, path, async (c) => {
    const actor = c.req.header("x-actor") || "";
    if (spec.by === "person" && !actor.startsWith("person:")) throw new Refused(`Only a person can do this: ask them. (${spec.name})`, 403);
    const body = method === "GET" ? c.req.query() : await c.req.json().catch(() => ({}));
    const input = {};
    for (const k of inputNames(spec.input)) if (body[k] !== void 0) input[k] = body[k];
    for (const [k, v] of Object.entries(c.req.param())) input[k] = /^\d+$/.test(v) ? Number(v) : v;
    const out = await handler(input, { actor }) ?? { ok: true };
    const whole = !spec.brief || actor.startsWith("person:") || entero(body);
    return c.json(whole ? out : spec.brief(out, input));
  });
}
function mountErrors(app) {
  app.onError((e, c) => c.json({ error: e.message, code: e.code ?? codeOf(e.message, e.status ?? 500), ...e.item !== void 0 ? { item: e.item } : {} }, e.status ?? 500));
  app.get("/_commands", (c) => c.json(commandsOf(app)));
}

// server/keys.mjs
function keysClient(url = process.env.APP_DATA_URL, token = process.env.APP_DATA_TOKEN) {
  const HDR = () => ({ "Content-Type": "application/json", Authorization: `Bearer ${token}` });
  return {
    fetch: async (target, { method = "GET", headers = {}, body, timeoutMs } = {}) => {
      const send = (conTiempo) => globalThis.fetch(`${url}/fetch`, { method: "POST", headers: HDR(), body: JSON.stringify({ url: target, method, headers, body, ...conTiempo && timeoutMs ? { timeoutMs } : {} }), ...timeoutMs ? { signal: AbortSignal.timeout(timeoutMs + 5e3) } : {} });
      let r = await send(true);
      let j = await r.json().catch(() => null);
      if (timeoutMs && r.status === 400 && /timeout/i.test(JSON.stringify(j ?? ""))) {
        r = await send(false);
        j = await r.json().catch(() => null);
      }
      if (!r.ok || !j) throw new Error(j ? [j.error, j.how].filter(Boolean).join(" ") : `Key fetch ${r.status}`);
      return { ...j, json: () => JSON.parse(j.body ?? "null") };
    }
  };
}

// server/semilla.mjs
var SEMILLA_AJUSTES = {
  dominio: "",
  mercado: "",
  pais: "",
  ubicacion: null,
  // location_code de DataForSEO (p. ej. 2724 España, 2484 México)
  idioma: "",
  // language_code de DataForSEO (p. ej. es, en)
  publico: "",
  competidores: "",
  semillas: "",
  ruta_blog: "/blog/",
  volumen_min: 30,
  kd_max: 50
};

// server/services/costes.mjs
var G = "oportunidadesseo_costes";
var now = () => (/* @__PURE__ */ new Date()).toISOString().slice(0, 19).replace("T", " ");
var LIMITE_USD = { buscar_huecos: 0.4, buscar_competidores: 0.3, diagnosticar: 0.2, buscar_casi: 0.1, datos_dataforseo: 0.08, probar_serp: 0.02, revisar_objetivos: 0.1, buscar_ideas_publico: 0.4, revisar_ia: 0.15, vigilar_competidores: 0.01, ver_top10: 0.01, medir_candidatos: 0.15, buscar_defender: 0.05 };
var PRECIOS = { labs_tarea: 0.012, labs_item: 12e-5, serp_live: 2e-3, serp_live_advanced: 2e-3, serp_cola: 6e-4, onpage: 15e-5 };
var clavePath = (path) => String(path).replace(/\/live\/advanced$/, " advanced").replace(/\/(live(\/regular)?|task_post)$/, "").replace(/^dataforseo_labs\/google\//, "labs/");
function meter(comando, max = LIMITE_USD[comando] ?? 0.2) {
  const m = {
    comando,
    usd: 0,
    llamadas: 0,
    por: {},
    max,
    check(path) {
      if (m.usd >= m.max) throw new Refused("Se par\xF3 por seguridad: esta ejecuci\xF3n de " + comando + " ya ha gastado " + usd(m.usd) + " en DataForSEO (l\xEDmite " + usd(m.max) + "). No se hizo: " + path + ".", 429);
    },
    add(path, cost, n = 1) {
      const c = Number(cost) || 0;
      const k = clavePath(path);
      m.usd += c;
      m.llamadas += n;
      m.por[k] = { llamadas: (m.por[k]?.llamadas || 0) + n, usd: (m.por[k]?.usd || 0) + c };
    },
    /** Una llamada sin respuesta (tiempo agotado): se apunta aparte, sin coste, porque DataForSEO no devolvió «cost». */
    fallo(path, motivo = "sin respuesta") {
      const k = clavePath(path) + " (" + motivo + ")";
      m.llamadas += 1;
      m.por[k] = { llamadas: (m.por[k]?.llamadas || 0) + 1, usd: m.por[k]?.usd || 0 };
    },
    /** Notas para el detalle del gasto («3 top 10 de la caché»). */
    notas: []
  };
  return m;
}
var usd = (v) => v == null ? "\u2014" : (Math.round(Number(v) * 1e4) / 1e4).toLocaleString("es-ES", { minimumFractionDigits: 2, maximumFractionDigits: 4 }) + " $";
async function saveCost(db, m, resultado = "ok") {
  const detalle = [...Object.entries(m.por).map(([k, v]) => k + ": " + v.llamadas + " llamada" + (v.llamadas === 1 ? "" : "s") + ", " + usd(v.usd)), ...m.notas ?? []].join(" \xB7 ");
  await db.insert(G, { comando: m.comando, usd: Math.round(m.usd * 1e5) / 1e5, llamadas: m.llamadas, detalle: detalle || "Sin llamadas de pago", resultado, fecha: now() });
  return { usd: Math.round(m.usd * 1e5) / 1e5, llamadas: m.llamadas, detalle };
}
async function withMeter(db, comando, fn) {
  const m = meter(comando);
  try {
    const out = await fn(m);
    const coste = await saveCost(db, m, "ok");
    return { ...out, coste_usd: coste.usd, coste: usd(coste.usd), llamadas: coste.llamadas };
  } catch (e) {
    if (m.llamadas || m.notas?.length) await saveCost(db, m, "error: " + String(e.message).slice(0, 200));
    throw e;
  }
}
async function lastCosts(db) {
  const rows = await db.all("SELECT comando, usd AS coste, llamadas, detalle, resultado, fecha FROM " + G + " WHERE _deleted = 0 ORDER BY _id DESC LIMIT 200");
  const out = {};
  for (const r of rows) if (!out[r.comando]) out[r.comando] = { ...r, texto: usd(r.coste) };
  const total = rows.reduce((a, r) => a + (Number(r.coste) || 0), 0);
  return { ultimo: out, total_usd: Math.round(total * 1e4) / 1e4, total: usd(total), ejecuciones: rows.length };
}

// server/services/dfs.mjs
var DFS = "https://api.dataforseo.com/v3/";
function where(cfg) {
  const location_code = Number(cfg.ubicacion), language_code = String(cfg.idioma || "").trim().toLowerCase();
  if (!location_code || !language_code) throw new Refused("Faltan la ubicaci\xF3n de DataForSEO o el idioma en Ajustes (General).", 400);
  return { location_code, language_code };
}
var DFS_AUTH = { Authorization: "{{basic:DATAFORSEO_LOGIN:DATAFORSEO_PASSWORD}}" };
var DFS_TIMEOUT_MS = 6e4;
var timeoutError = (ms) => {
  const e = new Refused("DataForSEO no respondi\xF3 en " + Math.round(ms / 1e3) + " s (tiempo agotado).", 504);
  e.timeout = true;
  return e;
};
var tooBigError = (path) => {
  const e = new Refused("DataForSEO respondi\xF3 con m\xE1s datos de los que el m\xF3dulo puede leer de una vez (m\xE1s de 5 MB) en " + String(path).replace(/^dataforseo_labs\/google\//, "labs/").replace(/\/live.*$/, "") + ".", 413);
  e.tooBig = true;
  return e;
};
var ES_GRANDE = /over 5 ?MB|KEY_FETCH_TOO_BIG|too big/i;
var ES_TIMEOUT = /time(d)?[ -]?out|timeout|aborted|ETIMEDOUT|ESOCKETTIMEDOUT|UND_ERR_HEADERS_TIMEOUT/i;
async function dfsRaw(keys, method, path, body, meter2, n = 1, { timeoutMs = DFS_TIMEOUT_MS } = {}) {
  if (meter2) meter2.check(path);
  let r;
  try {
    r = await keys.fetch(DFS + path, { method, headers: { ...DFS_AUTH }, ...body ? { body } : {}, timeoutMs });
  } catch (e) {
    if (/not set|no est|withheld|missing|falta/i.test(e.message)) throw new Refused("Faltan las claves de DataForSEO del m\xF3dulo (Usuario y Contrase\xF1a de DataForSEO): mientras tanto se ven datos de ejemplo.", 424);
    if (ES_GRANDE.test(String(e.message))) throw tooBigError(path);
    if (e.timeout || e.name === "TimeoutError" || e.name === "AbortError" || ES_TIMEOUT.test(String(e.message))) throw timeoutError(timeoutMs);
    throw new Refused("No se pudo llamar a DataForSEO: " + e.message, 424);
  }
  if (r.status === 504 || r.status === 408) throw timeoutError(timeoutMs);
  if (r.status === 401) throw new Refused("DataForSEO no acepta el usuario y la contrase\xF1a: revisa \xABUsuario de DataForSEO\xBB y \xABContrase\xF1a de DataForSEO\xBB en las claves del m\xF3dulo.", 502);
  if (r.status !== 200) throw new Refused("DataForSEO respondi\xF3 " + r.status + ".", 502);
  const j = r.json();
  if (meter2) meter2.add(path, j?.cost ?? j?.tasks?.[0]?.cost ?? 0, n);
  if (j?.status_code != null && j.status_code !== 2e4) throw new Refused("DataForSEO: " + (j.status_message || "sin respuesta") + ".", 502);
  return j;
}
async function dfsCall(keys, method, path, body, meter2, opts = {}) {
  const j = await dfsRaw(keys, method, path, body, meter2, 1, opts);
  const t = j?.tasks?.[0];
  if (!t || t.status_code !== 2e4) throw new Refused("DataForSEO: " + (t?.status_message || j?.status_message || "sin respuesta") + ".", 502);
  return t;
}
async function dfs(keys, path, task, meter2, opts = {}) {
  const t = await dfsCall(keys, "POST", path, [task], meter2, opts);
  return t.result?.[0] ?? {};
}
var intentOf = (s) => ({ commercial: "comercial", transactional: "transaccional", informational: "informacional", navigational: "navegacional" })[s] ?? null;
var kdOf = (v) => {
  const n = Number(v);
  return v == null || v === "" || !Number.isFinite(n) || n <= 0 ? null : Math.min(100, Math.round(n));
};
var PAGINA_MIN = 10;
async function dfsPaginas(keys, path, task, meter2, { total = 100, pagina = total, minima = PAGINA_MIN, recordar = null } = {}) {
  const sabida = recordar ? Number(await recordar.leer(path)) || 0 : 0;
  let size = Math.max(1, Math.min(sabida || pagina, total));
  const items = [];
  const avisos = [];
  let offset = 0;
  let total_count = null;
  while (items.length < total) {
    const pido = Math.min(size, total - items.length);
    let r;
    try {
      r = await dfs(keys, path, { ...task, limit: pido, ...offset ? { offset } : {} }, meter2);
    } catch (e) {
      if (!e.tooBig) throw e;
      if (meter2) meter2.fallo(path, "m\xE1s de 5 MB con " + pido + " resultados: DataForSEO la cobra y no se pudo leer");
      if (pido <= minima) {
        avisos.push("DataForSEO responde con m\xE1s de 5 MB incluso pidiendo " + pido + " resultados: se sigue con los " + items.length + " le\xEDdos.");
        break;
      }
      size = Math.max(minima, Math.floor(pido / 2));
      if (recordar) await recordar.guardar(path, size);
      continue;
    }
    const got = r.items ?? [];
    total_count = r.total_count ?? total_count;
    items.push(...got);
    offset += got.length;
    if (got.length < pido || total_count != null && offset >= total_count) break;
  }
  return { items, total_count, pagina: size, avisos };
}

// server/services/serp.mjs
var domainOf = (u) => String(u || "").trim().toLowerCase().replace(/^https?:\/\//, "").replace(/^www\./, "").replace(/[/?#:].*$/, "");
var MIN_VALIDOS = 5;
var isGoogle = (d) => {
  const h = domainOf(d);
  return /(^|\.)google\.[a-z]{2,3}(\.[a-z]{2})?$/.test(h) || /(^|\.)(googleusercontent|gstatic|googleapis|googleadservices|googlesyndication|doubleclick)\.com$/.test(h) || /^(goo\.gl|g\.page|g\.co|maps\.app\.goo\.gl)$/.test(h);
};
var REDIR = /^\/(goto|url|aclk|local|maps|search|imgres|interstitial|pagead)/i;
function finalUrl(u) {
  let url;
  try {
    url = new URL(String(u || ""));
  } catch {
    return null;
  }
  if (!isGoogle(url.hostname)) return url.href;
  if (!REDIR.test(url.pathname)) return url.href;
  for (const k of ["url", "q", "adurl", "u", "dest"]) {
    const v = url.searchParams.get(k);
    if (v && /^https?:\/\//i.test(v)) {
      try {
        const d = new URL(v);
        return isGoogle(d.hostname) ? null : d.href;
      } catch {
      }
    }
  }
  return null;
}
function esRedireccion(u) {
  let url;
  try {
    url = new URL(String(u || ""));
  } catch {
    return false;
  }
  return isGoogle(url.hostname) && REDIR.test(url.pathname);
}
function dominioDeTexto(s) {
  let t = String(s ?? "").trim().toLowerCase();
  if (!t) return null;
  t = t.replace(/^[a-z][a-z0-9+.-]*:\/\//, "").replace(/^www\./, "");
  t = t.split(/\s*›\s*|[/\s?#:]/)[0].replace(/\.$/, "");
  if (!t || !t.includes(".")) return null;
  if (!/^[\p{L}\p{N}-]+(\.[\p{L}\p{N}-]+)+$/u.test(t)) return null;
  if (t.split(".").some((l) => !l || l.startsWith("-") || l.endsWith("-"))) return null;
  if (!/^[\p{L}]{2,}$/u.test(t.split(".").pop())) return null;
  if (isGoogle(t)) return null;
  return t;
}
function dominioDeGoto(x) {
  const w = dominioDeTexto(x?.website_name);
  if (w) return { dominio: w, fuente: "website_name" };
  const b = dominioDeTexto(x?.breadcrumb);
  if (b) return { dominio: b, fuente: "breadcrumb" };
  return null;
}
function urlDeBreadcrumb(breadcrumb, dominio2) {
  const d = dominioDeTexto(dominio2) || dominioDeTexto(breadcrumb);
  if (!d) return null;
  const partes = String(breadcrumb ?? "").trim().split(/\s*›\s*/);
  const cabeza = partes.shift() || "";
  if (dominioDeTexto(cabeza) !== d) return "https://" + d + "/";
  const host = dominioDeTexto(cabeza) === d ? cabeza.trim().replace(/^[a-z][a-z0-9+.-]*:\/\//i, "").split(/[/\s?#]/)[0].toLowerCase() : d;
  const resto = dominioDeTexto(cabeza) === d ? cabeza.trim().replace(/^[a-z][a-z0-9+.-]*:\/\//i, "").split("/").slice(1).filter(Boolean) : [];
  const ruta = [];
  for (const seg of [...resto, ...partes]) {
    const t = seg.trim();
    if (!t || !/^[A-Za-z0-9._~%-]+$/.test(t)) break;
    ruta.push(t);
  }
  return "https://" + host + "/" + ruta.join("/");
}
function urlLimpia(url, dominio2) {
  if (!url) return dominio2 && !isGoogle(dominio2) ? "https://" + domainOf(dominio2) + "/" : null;
  if (!esRedireccion(url)) return String(url);
  const fin = finalUrl(url);
  if (fin) return fin;
  return dominio2 && !isGoogle(dominio2) ? "https://" + domainOf(dominio2) + "/" : null;
}
function materialDe(items) {
  const preguntas = [];
  const relacionadas2 = [];
  const add = (l, v) => {
    const t = String(v ?? "").trim().replace(/\s+/g, " ");
    if (t && !l.some((x) => x.toLowerCase() === t.toLowerCase())) l.push(t.slice(0, 200));
  };
  for (const x of items ?? []) {
    if (x?.type === "people_also_ask") for (const q of x.items ?? x.preguntas ?? []) add(preguntas, typeof q === "string" ? q : q?.title);
    if (x?.type === "related_searches") for (const q of x.items ?? x.busquedas ?? []) add(relacionadas2, typeof q === "string" ? q : q?.title);
  }
  return { preguntas: preguntas.slice(0, 12), relacionadas: relacionadas2.slice(0, 12) };
}
var FUENTE_TXT = { domain: "dominio de DataForSEO", url: "dominio le\xEDdo del destino del enlace", website_name: "dominio le\xEDdo del nombre de la web (website_name)", breadcrumb: "dominio le\xEDdo del breadcrumb" };
function organicTop(items, { n = 10, own = "" } = {}) {
  const tipos = {};
  const quitados = [];
  const validos = [];
  for (const x of items ?? []) {
    const t = String(x?.type || "desconocido");
    tipos[t] = (tipos[t] || 0) + 1;
    if (t !== "organic") continue;
    const titulo = x.title ?? "";
    const pos = x.rank_group ?? x.rank_absolute ?? null;
    const dd = domainOf(x.domain || "");
    const redir = esRedireccion(x.url) || !x.url && (!dd || isGoogle(dd));
    const fin = finalUrl(x.url);
    let dominio2 = null, fuente = null, url = fin;
    if (redir && fin) {
      dominio2 = domainOf(fin);
      fuente = "url";
    } else if (redir) {
      const g = dominioDeGoto(x);
      if (!g) {
        quitados.push({ pos, titulo, motivo: "Enlace de redirecci\xF3n de Google sin destino legible (ni website_name ni breadcrumb con un dominio v\xE1lido)" });
        continue;
      }
      dominio2 = g.dominio;
      fuente = g.fuente;
      url = urlDeBreadcrumb(x.breadcrumb, g.dominio);
    } else if (fin) {
      dominio2 = dd && !isGoogle(dd) && fin === x.url ? dd : domainOf(fin);
      fuente = "domain";
    } else {
      quitados.push({ pos, titulo, motivo: "Sin enlace legible" });
      continue;
    }
    if (!dominio2 || isGoogle(dominio2)) {
      quitados.push({ pos, titulo, motivo: "Es Google, no una web que compita" });
      continue;
    }
    if (validos.length < n) validos.push({ pos: pos ?? validos.length + 1, url: urlLimpia(url, dominio2), dominio: dominio2, titulo, fuente });
  }
  return { validos, quitados, tipos, organicos: tipos.organic || 0, fiable: validos.length >= MIN_VALIDOS };
}
function noFiableTxt(o) {
  const v = o.validos.length;
  const otros = Object.entries(o.tipos).filter(([t]) => t !== "organic");
  return "No se pudo medir la fuerza del top 10: solo " + v + " resultado" + (v === 1 ? "" : "s") + " org\xE1nico" + (v === 1 ? "" : "s") + " v\xE1lido" + (v === 1 ? "" : "s") + " (hacen falta " + MIN_VALIDOS + ")" + (o.quitados.length ? "; se quitaron " + o.quitados.length + " que eran Google o enlaces de redirecci\xF3n de Google" : "") + (otros.length ? "; el resto de la p\xE1gina son " + otros.map(([t, c]) => t + " (" + c + ")").join(", ") : "") + ".";
}

// server/services/lotes.mjs
var CACHE = "oportunidadesseo_cache";
var HORA_MS = 36e5;
var ahora = () => (/* @__PURE__ */ new Date()).toISOString().slice(0, 19).replace("T", " ");
async function pool(items, max, fn) {
  const list3 = [...items ?? []];
  const out = new Array(list3.length);
  let next = 0;
  let fallo = null;
  const worker = async () => {
    while (!fallo && next < list3.length) {
      const i = next++;
      try {
        out[i] = await fn(list3[i], i);
      } catch (e) {
        fallo = fallo || e;
      }
    }
  };
  await Promise.all(Array.from({ length: Math.max(1, Math.min(Number(max) || 1, list3.length)) }, worker));
  if (fallo) throw fallo;
  return out;
}
var trozos = (arr, n) => {
  const out = [];
  for (let i = 0; i < (arr ?? []).length; i += n) out.push(arr.slice(i, i + n));
  return out;
};
var horasDesde = (fecha, now9 = Date.now()) => {
  const s = String(fecha || "");
  const t = Date.parse(s.replace(" ", "T") + (/Z$|[+-]\d\d:?\d\d$/.test(s) ? "" : "Z"));
  return Number.isFinite(t) ? Math.max(0, (now9 - t) / HORA_MS) : Infinity;
};
var haceTxt = (horas) => {
  const h = Math.floor(Number(horas) || 0);
  if (h < 1) return "hace menos de 1 hora";
  if (h < 48) return "hace " + h + " hora" + (h === 1 ? "" : "s");
  return "hace " + Math.floor(h / 24) + " d\xEDas";
};
async function cacheGet(db, clave2, { maxHoras = null, now: now9 = Date.now() } = {}) {
  const r = await db.one("SELECT valor, fecha FROM " + CACHE + " WHERE clave = ? AND _deleted = 0 ORDER BY _id DESC LIMIT 1", [clave2]);
  if (!r) return null;
  const horas = horasDesde(r.fecha, now9);
  if (maxHoras != null && !(horas < maxHoras)) return null;
  let valor = null;
  try {
    valor = JSON.parse(r.valor || "null");
  } catch {
    return null;
  }
  return { valor, fecha: r.fecha, horas };
}
async function cacheSet(db, clave2, valor, fecha = ahora()) {
  const ex = await db.one("SELECT _id FROM " + CACHE + " WHERE clave = ? AND _deleted = 0", [clave2]);
  const data = { clave: clave2, valor: JSON.stringify(valor), fecha };
  if (ex) await db.update(CACHE, ex._id, data);
  else await db.insert(CACHE, data);
  return fecha;
}
function ultimoPeriodo(rows) {
  const con = (rows ?? []).filter((r) => r.hasta);
  if (!con.length) return rows ?? [];
  const hasta = con.map((r) => String(r.hasta)).sort().pop();
  const del = con.filter((r) => String(r.hasta) === hasta);
  const desde = del.map((r) => String(r.desde || "")).sort().pop();
  return del.filter((r) => String(r.desde || "") === desde);
}
var paginaRecordada = (db) => ({
  leer: async (path) => (await cacheGet(db, "pagina:" + path))?.valor?.pagina ?? null,
  guardar: async (path, pagina) => {
    await cacheSet(db, "pagina:" + path, { pagina });
  }
});

// server/services/texto.mjs
var norm = (s) => String(s ?? "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").trim();
var STOP = new Set("de del la las el los lo un una unos unas y e o u en para por con sin a al que como cual cuales cuanto cuanta cuantos cuantas se su sus mi mis tu tus me te le les es son esta este estos estas ese esa hay vs versus mas muy ya the of for and to in on with how what is are a an my near".split(" "));
var MODIF = new Set("precio precios coste costes cuesta cuestan cobrar tarifa tarifas barato barata baratos baratas mejor mejores top gratis gratuito gratuita online cerca ejemplo ejemplos tipos tipo guia guias opinion opiniones ventaja ventajas que hacer cost price best free cheap example examples".split(" "));
function miles(v, dec = 0) {
  const n = Number(v);
  if (v == null || v === "" || !Number.isFinite(n)) return "\u2014";
  const [ent, frac] = Math.abs(n).toFixed(dec).split(".");
  return (n < 0 ? "-" : "") + ent.replace(/\B(?=(\d{3})+(?!\d))/g, ".") + (frac && Number(frac) ? "," + frac.replace(/0+$/, "") : "");
}
var stem = (t) => {
  let s = norm(t);
  if (s.length > 3 && s.endsWith("s")) s = s.slice(0, -1);
  return s;
};
var tokens = (s) => norm(s).split(/[^a-z0-9ñ]+/).filter((w) => w && !/^\d+$/.test(w));
var content = (s) => tokens(s).filter((w) => !STOP.has(w) && !MODIF.has(w)).map(stem);
var same = (a, b) => a === b || a.length >= 5 && b.length >= 5 && a.slice(0, 6) === b.slice(0, 6);
var inVocab = (t, vocab) => {
  for (const v of vocab) if (same(t, v)) return true;
  return false;
};
var vocabOf = (texts) => new Set(texts.flatMap((x) => content(x)).filter((w) => w.length >= 2));
function lev(a, b) {
  const m = a.length, n = b.length;
  if (!m) return n;
  if (!n) return m;
  let prev = Array.from({ length: n + 1 }, (_, i) => i);
  for (let i = 1; i <= m; i++) {
    const cur = [i];
    for (let j = 1; j <= n; j++) cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1));
    prev = cur;
  }
  return prev[n];
}
function fuzzyIn(s, big) {
  if (!s || !big) return 99;
  if (big.includes(s)) return 0;
  let best = 99;
  for (let len = Math.max(1, s.length - 1); len <= s.length + 1; len++) for (let i = 0; i + len <= big.length; i++) best = Math.min(best, lev(s, big.slice(i, i + len)));
  return best;
}
var brandOf = (domain) => {
  const parts = norm(domain).replace(/^https?:\/\//, "").replace(/^www\./, "").replace(/[/?#].*$/, "").split(".").filter(Boolean);
  parts.pop();
  if (parts.length > 1 && /^(com|net|org|gob|edu|co|ac)$/.test(parts[parts.length - 1])) parts.pop();
  return (parts.pop() || "").replace(/[^a-z0-9]/g, "");
};
var SIGLAS = new Map("IA AI ERP CRM SEO SEM SaaS API APIs B2B B2C TPV CMS UX UI KPI KPIs RGPD LOPD IVA IRPF PDF URL SQL PHP HTML CSS JS iOS ROI RRHH NFT QR SMS GPT ChatGPT IoT VPN PWA RPA OCR CEO CTO CRMs ERPs".split(" ").map((s) => [norm(s), s]));
function temaDe(s) {
  const t = String(s ?? "").trim().replace(/\s+/g, " ");
  if (!t) return t;
  const out = t.split(" ").map((w) => {
    const sig = SIGLAS.get(norm(w).replace(/[^a-z0-9ñ]/g, ""));
    return sig ? w.replace(/[\p{L}\p{N}]+/u, sig) : w.toLowerCase();
  }).join(" ");
  return out.replace(new RegExp("^\\p{Ll}", "u"), (c) => c.toUpperCase());
}

// server/services/semillas.mjs
var MAX_SEMILLAS = 20;
var LIMITE_SUGERENCIAS = 30;
var MAX_SEMILLAS_SUG = 10;
var splitList = (s) => String(s ?? "").split(/[;\n,]/).map((x) => x.trim()).filter(Boolean);
function shortSeed(s) {
  const t = String(s || "").trim().replace(/\s+/g, " ");
  const head = t.split(/\s+(?:para|con|en|sin|por|de cara a)\s+/i)[0];
  const words2 = head.split(" ");
  const out = [];
  let n = 0;
  for (const w of words2) {
    const c = content(w).length;
    if (c && n >= 4) break;
    out.push(w);
    n += c;
  }
  while (out.length && !content(out[out.length - 1]).length) out.pop();
  const short = out.join(" ");
  return n >= 2 && norm(short) !== norm(t) ? short : null;
}
function semillasCortas(cfg) {
  const semillas = splitList(String(cfg.semillas || "").replace(/,/g, " ")).slice(0, MAX_SEMILLAS);
  return semillas.map((s) => ({ semilla: s, corta: shortSeed(s) || s }));
}
var claveSugerencias = (semillas, cfg) => "sugerencias:" + norm(semillas.join("|")) + ":" + Number(cfg.ubicacion) + ":" + norm(cfg.idioma) + ":" + (Number(cfg.volumen_min) || 0);
var intents = (si) => [...new Set([intentOf(si?.main_intent), ...(si?.foreign_intent ?? []).map(intentOf)].filter(Boolean))];
async function sugerencias(db, keys, cfg, m, cortas) {
  const semillas = cortas.slice(0, MAX_SEMILLAS_SUG);
  if (!semillas.length) return { items: [] };
  const vmin = Number(cfg.volumen_min) || 0;
  const w = where(cfg);
  const clave2 = claveSugerencias(semillas, cfg);
  const c = await cacheGet(db, clave2);
  if (c?.valor?.items) return { items: c.valor.items, cache: c.fecha };
  const porSemilla = /* @__PURE__ */ new Map();
  const fallos = [];
  await pool(semillas, 4, async (s) => {
    try {
      const r = await dfs(keys, "dataforseo_labs/google/keyword_suggestions/live", {
        keyword: s,
        ...w,
        limit: LIMITE_SUGERENCIAS,
        include_serp_info: false,
        include_seed_keyword: false,
        ...vmin ? { filters: [["keyword_info.search_volume", ">=", vmin]] } : {},
        order_by: ["keyword_info.search_volume,desc"]
      }, m);
      porSemilla.set(s, (r.items ?? []).filter((x) => x?.keyword).map((x) => {
        const ii = intents(x.search_intent_info ?? x.keyword_data?.search_intent_info);
        return { keyword: String(x.keyword).toLowerCase().trim(), volumen: x.keyword_info?.search_volume ?? null, dificultad: kdOf(x.keyword_properties?.keyword_difficulty), intencion: ii[0] ?? null, intenciones: ii.slice(1), semilla: s };
      }));
    } catch (e) {
      if (e.status === 424 || e.status === 429) throw e;
      fallos.push("\xAB" + s + "\xBB (" + e.message + ")");
    }
  });
  const items = semillas.flatMap((s) => porSemilla.get(s) ?? []);
  if (!fallos.length) await cacheSet(db, clave2, { items });
  return { items, aviso: fallos.length ? "Labs keyword_suggestions fall\xF3 para " + fallos.join(", ") + ": se busc\xF3 con el resto." : null };
}

// server/services/lugares.mjs
var LISTA_ENORME = /* @__PURE__ */ new Set(["us"]);
var US_STATES = ["alabama", "alaska", "arizona", "arkansas", "california", "colorado", "connecticut", "delaware", "florida", "georgia", "hawaii", "idaho", "illinois", "indiana", "iowa", "kansas", "kentucky", "louisiana", "maine", "maryland", "massachusetts", "michigan", "minnesota", "mississippi", "missouri", "montana", "nebraska", "nevada", "new hampshire", "new jersey", "new mexico", "new york", "north carolina", "north dakota", "ohio", "oklahoma", "oregon", "pennsylvania", "rhode island", "south carolina", "south dakota", "tennessee", "texas", "utah", "vermont", "virginia", "washington", "west virginia", "wisconsin", "wyoming"];
var US_CITIES = ["los angeles", "chicago", "houston", "phoenix", "philadelphia", "san antonio", "san diego", "dallas", "san jose", "austin", "jacksonville", "fort worth", "columbus", "charlotte", "san francisco", "indianapolis", "seattle", "denver", "boston", "el paso", "nashville", "detroit", "oklahoma city", "portland", "las vegas", "memphis", "louisville", "baltimore", "milwaukee", "albuquerque", "tucson", "fresno", "sacramento", "kansas city", "atlanta", "omaha", "colorado springs", "raleigh", "miami", "long beach", "virginia beach", "oakland", "minneapolis", "tulsa", "tampa", "arlington", "new orleans", "cleveland", "honolulu", "orlando", "pittsburgh", "cincinnati", "st louis", "salt lake city", "silicon valley", "bay area", "brooklyn", "manhattan"];
var LUGARES_BASE = { us: [...US_STATES, ...US_CITIES] };

// server/services/huecos.mjs
var D = "oportunidadesseo_descartes";
var now2 = () => (/* @__PURE__ */ new Date()).toISOString().slice(0, 19).replace("T", " ");
var splitList2 = (s) => String(s ?? "").split(/[;\n]/).map((x) => x.trim()).filter(Boolean);
var cap = (s) => String(s ?? "").replace(/^./, (c) => c.toUpperCase());
var MAX_COMPETIDORES = 6;
var LIMITE_INTERSECCION = 100;
var RELEVANCIA_MIN = 50;
var TIPOS_LUGAR = /* @__PURE__ */ new Set(["City", "Province", "Autonomous Community", "Municipality", "Region", "County", "State", "Department"]);
var FILTROS = {
  volumen: "Volumen bajo el m\xEDnimo",
  dificultad: "Dificultad sobre el m\xE1ximo",
  marca_propia: "Tu propia marca",
  errata: "Errata",
  marca_competidor: "Marca de un competidor",
  ciudad: "Ciudad distinta",
  otra_marca: "Marca de otra empresa",
  ajena: "Ajena al negocio",
  variante: "Variante repetida"
};
var INTENT_LABEL = { comercial: "comercial", transaccional: "transaccional", informacional: "informativa", navegacional: "navegacional" };
var INTENT_GANAR = { comercial: 1.3, informacional: 1, transaccional: 0.9, navegacional: 0.5 };
function ganable({ volumen, dificultad, intencion, relevancia }) {
  const v = Number(volumen) || 0;
  if (!v) return 0;
  return Math.round(v * difficultyFactor({ dificultad }) * (INTENT_GANAR[intencion] ?? 1) * (Number(relevancia ?? 100) / 100));
}
var ORDINARY = /(cion|sion|dad|tad|miento|mento|ador|adora|edor|idor|ario|aria|eria|ismo|ista|able|ible|mente|ivo|iva|oso|osa|ura|ancia|encia|ente|ante|ico|ica|ing|tion|ness|ment|er|or)$/;
var brandLike = (t) => t.length >= 5 && !ORDINARY.test(t);
function context(cfg, { ideas = [], lugares = [] } = {}) {
  const semillas = splitList2(cfg.semillas);
  const S = vocabOf(semillas);
  const P2 = vocabOf([cfg.publico || "", cfg.mercado || ""]);
  const count = /* @__PURE__ */ new Map();
  for (const k of ideas) for (const t of new Set(content(k))) count.set(t, (count.get(t) || 0) + 1);
  const R = new Set([...count].filter(([, n]) => n >= 2).map(([t]) => t));
  const zonas = splitList2(cfg.zonas).map(norm);
  const places2 = [...new Set(lugares.map(norm))].filter((n) => n.length >= 4 && !zonas.some((z) => z === n || z.includes(n) || n.includes(z)) && !n.split(" ").every((w) => inVocab(stem(w), S)));
  return {
    S,
    P: P2,
    R,
    ideas: new Set(ideas.map(norm)),
    semillas,
    places: places2,
    own: brandOf(cfg.dominio),
    comps: competitorsOf(cfg).map((d) => ({ dominio: d, marca: brandOf(d) })).filter((c) => c.marca.length >= 3),
    vmin: Number(cfg.volumen_min) || 0,
    kdmax: cfg.kd_max == null || cfg.kd_max === "" ? null : Number(cfg.kd_max),
    rmin: cfg.relevancia_min == null || cfg.relevancia_min === "" ? RELEVANCIA_MIN : Number(cfg.relevancia_min)
  };
}
function relevance(keyword, ctx) {
  const toks = content(keyword);
  if (!toks.length) return { relevancia: 0, casan: [], semilla: null };
  let sum = 0;
  const casan = [];
  for (const t of toks) {
    const w = inVocab(t, ctx.S) ? [1, "semillas"] : inVocab(t, ctx.R) ? [0.6, "relacionadas"] : inVocab(t, ctx.P) ? [0.5, "p\xFAblico"] : [0, ""];
    sum += w[0];
    if (w[0]) casan.push(t + " (" + w[1] + ")");
  }
  let s = sum / toks.length;
  const idea = ctx.ideas.has(norm(keyword));
  if (idea) s += 0.2;
  let semilla = null, best = 0;
  for (const sd of ctx.semillas) {
    const v = content(sd);
    const n = toks.filter((t) => inVocab(t, new Set(v))).length;
    if (n > best) {
      best = n;
      semilla = sd;
    }
  }
  return { relevancia: Math.round(100 * Math.min(1, s)), casan, semilla, idea };
}
var placeIn = (keyword, ctx) => {
  const k = " " + tokens(keyword).join(" ") + " ";
  return ctx.places.find((p) => k.includes(" " + p + " ")) || null;
};
var unknown = (t, ctx) => !inVocab(t, ctx.S) && !inVocab(t, ctx.R) && !inVocab(t, ctx.P);
function reasons(g, ctx) {
  const out = [];
  const k = norm(g.keyword);
  const toks = tokens(k);
  const compact = toks.join("");
  const rel = relevance(k, ctx);
  if (g.volumen != null && Number(g.volumen) < ctx.vmin) out.push({ filtro: "volumen", motivo: "Volumen bajo el m\xEDnimo: " + g.volumen + " b\xFAsquedas/mes (m\xEDnimo " + ctx.vmin + " en Ajustes)" });
  if (ctx.kdmax != null && g.dificultad != null && Number(g.dificultad) > ctx.kdmax) out.push({ filtro: "dificultad", motivo: "Dificultad sobre el m\xE1ximo: KD " + g.dificultad + " (m\xE1ximo " + ctx.kdmax + " en Ajustes)" });
  if (ctx.own.length >= 3 && compact.includes(ctx.own)) out.push({ filtro: "marca_propia", motivo: "Es tu propia marca (\xAB" + ctx.own + "\xBB): ya es tuya, no es un hueco" });
  if (toks.length === 1 && compact.length >= 3 && !inVocab(stem(compact), ctx.S)) {
    const near = ctx.comps.map((c) => ({ ...c, d: fuzzyIn(compact, c.marca) })).sort((a, b) => a.d - b.d)[0];
    if (near && near.d <= (compact.length <= 5 ? 1 : 2) && compact !== near.marca) out.push({ filtro: "errata", motivo: "Errata o trozo del nombre de " + near.dominio + " (\xAB" + compact + "\xBB se parece a \xAB" + near.marca + "\xBB)" });
    if (!/[aeiou]/.test(compact) || /(.)\1\1/.test(compact)) out.push({ filtro: "errata", motivo: "No parece una palabra (\xAB" + compact + "\xBB)" });
  }
  for (const c of ctx.comps) {
    if (c.marca.length >= 4 && compact.includes(c.marca)) {
      out.push({ filtro: "marca_competidor", motivo: "Marca de " + c.dominio + ": quien la busca quiere esa empresa" });
      break;
    }
    const t = toks.find((x) => x.length >= 4 && unknown(stem(x), ctx) && fuzzyIn(x, c.marca) <= (x.length >= 6 ? 1 : 0));
    if (t && toks.length > 1) {
      out.push({ filtro: "marca_competidor", motivo: "Lleva \xAB" + t + "\xBB, parte del nombre de " + c.dominio + ": es su marca o una parecida" });
      break;
    }
  }
  const lugar = placeIn(k, ctx);
  if (lugar) out.push({ filtro: "ciudad", motivo: "B\xFAsqueda local de " + cap(lugar) + ": no est\xE1 en tus zonas (Ajustes \u2192 Zonas)" });
  const intents3 = [g.intencion, ...g.intenciones || []].filter(Boolean);
  const raras = toks.filter((t) => t.length >= 4 && !/\d/.test(t) && unknown(stem(t), ctx) && !(lugar && lugar.split(" ").includes(t)) && brandLike(t));
  if (raras.length && intents3.includes("navegacional")) out.push({ filtro: "otra_marca", motivo: "Busca una empresa o marca concreta (\xAB" + raras[0] + "\xBB): DataForSEO la da como navegacional" });
  else if (toks.length === 1 && raras.length) out.push({ filtro: "otra_marca", motivo: "Una sola palabra que no es de tu sector (\xAB" + raras[0] + "\xBB): parece el nombre de una marca o empresa" });
  if (rel.relevancia < ctx.rmin) out.push({ filtro: "ajena", motivo: "Ajena al negocio: relevancia " + rel.relevancia + " de 100 (m\xEDnimo " + ctx.rmin + "); " + (rel.casan.length ? "solo casa " + rel.casan.join(", ") : "ninguna palabra casa con tus semillas, tu p\xFAblico ni las b\xFAsquedas relacionadas") });
  return { out, rel };
}
function filterGaps(cands, ctx) {
  const pasan = [], fuera = [];
  for (const g of cands) {
    const { out, rel } = reasons(g, ctx);
    if (out.length) {
      fuera.push({ ...g, filtro: out[0].filtro, motivo: out.slice(0, 2).map((r) => r.motivo).join(" \xB7 "), relevancia: rel.relevancia });
      continue;
    }
    const gan = ganable({ ...g, relevancia: rel.relevancia });
    const f = INTENT_GANAR[g.intencion] ?? 1;
    pasan.push({
      ...g,
      relevancia: rel.relevancia,
      ganable: gan,
      semilla: rel.semilla,
      por_que: (g.volumen ?? "\u2014") + " b\xFAsquedas/mes \xB7 " + kdTxt(g.dificultad) + " \xB7 " + (INTENT_LABEL[g.intencion] || "intenci\xF3n sin datos") + " (\xD7" + String(f).replace(".", ",") + ") \xB7 relevancia " + rel.relevancia + "/100" + (rel.casan.length ? ": " + rel.casan.join(", ") : "")
    });
  }
  pasan.sort((a, b) => b.ganable - a.ganable || (b.volumen || 0) - (a.volumen || 0) || a.keyword.length - b.keyword.length);
  const seen = /* @__PURE__ */ new Map();
  const unicas = [];
  for (const g of pasan) {
    const sig = [...new Set(content(g.keyword))].sort().join(" ");
    const w = seen.get(sig);
    if (w) {
      w.variantes.push(g.keyword);
      fuera.push({ ...g, filtro: "variante", motivo: "Variante de \xAB" + w.keyword + "\xBB, que se queda (m\xE1s ganable)" });
      continue;
    }
    const x = { ...g, variantes: [] };
    seen.set(sig, x);
    unicas.push(x);
  }
  const conteo = Object.fromEntries(Object.keys(FILTROS).map((k) => [k, fuera.filter((f) => f.filtro === k).length]));
  return { pasan: unicas, fuera, conteo };
}
async function places(db, keys, cfg, m) {
  const pais = norm(cfg.pais);
  if (!pais) return { nombres: [], aviso: "Sin c\xF3digo de pa\xEDs en Ajustes: no se detectan b\xFAsquedas de otras ciudades." };
  const base = () => LUGARES_BASE[pais] ? { nombres: LUGARES_BASE[pais], base: true } : { nombres: [], aviso: "La lista de ciudades de DataForSEO para \xAB" + pais + "\xBB es demasiado grande para leerla: no se detectan b\xFAsquedas de otras ciudades." };
  if (LISTA_ENORME.has(pais)) return base();
  const c = await cacheGet(db, "lugares:" + pais);
  if (c?.valor?.length) return { nombres: c.valor };
  if (c?.valor?.enorme) return base();
  try {
    const t = await dfsCall(keys, "GET", "serp/google/locations/" + pais, null, m);
    const nombres = /* @__PURE__ */ new Set();
    for (const x of t.result ?? []) {
      if (!TIPOS_LUGAR.has(x.location_type)) continue;
      const first = String(x.location_name || "").split(",")[0];
      for (const part of [first, ...first.split(/[-/]/)]) {
        const n = tokens(part).join(" ");
        if (n.length >= 4) nombres.add(n);
      }
    }
    const list3 = [...nombres];
    if (list3.length) await cacheSet(db, "lugares:" + pais, list3);
    return { nombres: list3 };
  } catch (e) {
    if (e.status === 424 || e.status === 429) throw e;
    if (e.tooBig) {
      await cacheSet(db, "lugares:" + pais, { enorme: true });
      return base();
    }
    return { nombres: [], aviso: "No se pudo leer la lista de ciudades de DataForSEO (" + e.message + "): no se detectan b\xFAsquedas de otras ciudades." };
  }
}
async function relacionadas(db, keys, cfg, m) {
  const cortas = [...new Map(semillasCortas(cfg).map((x) => [norm(x.corta), x.corta])).values()];
  if (!cortas.length) return { keywords: [], aviso: "Sin temas semilla en Ajustes: la relevancia no se puede medir y todo saldr\xEDa \xABajeno\xBB." };
  try {
    const sg = await sugerencias(db, keys, cfg, m, cortas);
    return { keywords: [...new Set(sg.items.map((x) => norm(x.keyword)))], cache: sg.cache ?? null, aviso: sg.aviso ?? null };
  } catch (e) {
    if (e.status === 424 || e.status === 429) throw e;
    return { keywords: [], aviso: "No se pudieron traer las b\xFAsquedas de tus semillas (" + e.message + "): la relevancia solo usa semillas y p\xFAblico." };
  }
}
function needDomain(cfg) {
  const d = domainOf2(cfg.dominio);
  if (!d) throw new Refused("Falta el dominio en Ajustes (General \u2192 Dominio).", 400);
  return d;
}
var intentsOf = (si) => [...new Set([intentOf(si?.main_intent), ...(si?.foreign_intent ?? []).map(intentOf)].filter(Boolean))];
async function store(db, cfg, { pasan, fuera, conteo }, origen) {
  const buscado = now2();
  const taken = new Set((await db.all("SELECT keyword FROM " + T + " WHERE _deleted = 0")).map((r) => norm(r.keyword)));
  let nuevos = 0, actualizados = 0, filtrados = 0;
  const keep = /* @__PURE__ */ new Set();
  for (const g of pasan) {
    keep.add(g.keyword);
    const data = {
      keyword: g.keyword,
      volumen: g.volumen ?? null,
      dificultad: kdOf(g.dificultad),
      intencion: g.intencion ?? null,
      intenciones: (g.intenciones || []).join(", "),
      competidores: g.competidores,
      mejor_posicion: g.mejor_posicion ?? null,
      relevancia: g.relevancia,
      ganable: g.ganable,
      por_que: g.por_que,
      semilla: g.semilla ?? null,
      variantes: g.variantes.join("; "),
      buscado,
      origen
    };
    const ex = await db.one("SELECT _id, estado FROM " + H + " WHERE keyword = ? AND origen = ? AND _deleted = 0", [g.keyword, origen]);
    if (ex) {
      await db.update(H, ex._id, { ...data, ...ex.estado === "filtrado" || !ex.estado ? { estado: "nuevo" } : {} });
      actualizados++;
    } else {
      await db.insert(H, { ...data, estado: taken.has(norm(g.keyword)) ? "convertido" : "nuevo" });
      nuevos++;
    }
  }
  for (const x of await db.all("SELECT _id, keyword, estado FROM " + H + " WHERE origen = ? AND _deleted = 0", [origen])) {
    if (!keep.has(x.keyword) && (x.estado === "nuevo" || !x.estado)) {
      await db.update(H, x._id, { estado: "filtrado" });
      filtrados++;
    }
  }
  for (const x of await db.all("SELECT _id FROM " + D + " WHERE vigente = 1 AND COALESCE(origen, '') NOT IN ('competidores', 'publico') AND _deleted = 0")) await db.update(D, x._id, { vigente: 0 });
  for (const f of fuera) {
    const data = {
      keyword: f.keyword,
      volumen: f.volumen ?? null,
      dificultad: kdOf(f.dificultad),
      intencion: f.intencion ?? null,
      intenciones: (f.intenciones || []).join(", "),
      competidores: f.competidores,
      mejor_posicion: f.mejor_posicion ?? null,
      filtro: f.filtro,
      motivo: f.motivo,
      relevancia: f.relevancia ?? null,
      vigente: 1,
      buscado,
      origen
    };
    const ex = await db.one("SELECT _id FROM " + D + " WHERE keyword = ? AND origen = ? AND _deleted = 0", [f.keyword, origen]);
    if (ex) await db.update(D, ex._id, data);
    else await db.insert(D, data);
  }
  await db.update(A, cfg._id, { huecos_buscados: buscado, huecos_filtro: JSON.stringify({ pasan: pasan.length, descartadas: fuera.length, por_filtro: conteo, fecha: buscado }) });
  return { nuevos, actualizados, filtrados };
}
async function findGaps(db, _i, keys = keysClient()) {
  return withMeter(db, "buscar_huecos", async (m) => {
    const cfg = await settings(db);
    const dom2 = needDomain(cfg);
    const comps = competitorsOf(cfg).filter((c) => c !== dom2).slice(0, MAX_COMPETIDORES);
    if (!comps.length) throw new Refused("A\xF1ade competidores en Ajustes (General \u2192 Competidores) antes de buscar huecos.", 400);
    const w = where(cfg);
    const filters = [["keyword_data.keyword_info.search_volume", ">=", Number(cfg.volumen_min) || 0]];
    if (cfg.kd_max != null && cfg.kd_max !== "") filters.push("and", ["keyword_data.keyword_properties.keyword_difficulty", "<=", Number(cfg.kd_max)]);
    const byKw = /* @__PURE__ */ new Map();
    const avisos = [];
    let leidos = 0;
    for (const c of comps) {
      let r;
      try {
        r = await dfsPaginas(keys, "dataforseo_labs/google/domain_intersection/live", { target1: c, target2: dom2, intersections: false, filters, order_by: ["keyword_data.keyword_info.search_volume,desc"], ...w }, m, { total: LIMITE_INTERSECCION, recordar: paginaRecordada(db) });
      } catch (e) {
        if (e.status === 424 || e.status === 429) {
          if (!byKw.size) throw e;
          avisos.push("La b\xFAsqueda se par\xF3 en " + c + " (" + e.message + "): se guarda lo encontrado hasta ah\xED.");
          break;
        }
        avisos.push("No se pudo leer " + c + " (" + e.message + "): se busc\xF3 con el resto.");
        continue;
      }
      avisos.push(...r.avisos.map((a) => c + ": " + a));
      if (r.avisos.length && !r.items.length) continue;
      leidos++;
      for (const it of r.items ?? []) {
        const kd = it.keyword_data ?? {};
        const k = String(kd.keyword || "").toLowerCase().trim();
        if (!k) continue;
        const pos = it.first_domain_serp_element?.rank_group ?? null;
        const ints = intentsOf(kd.search_intent_info);
        const g = byKw.get(k) ?? { keyword: k, volumen: kd.keyword_info?.search_volume ?? null, dificultad: kdOf(kd.keyword_properties?.keyword_difficulty), intencion: ints[0] ?? null, intenciones: ints.slice(1), comps: [] };
        g.comps.push({ dominio: c, pos });
        byKw.set(k, g);
      }
    }
    if (!leidos) throw new Refused("No se pudo leer ning\xFAn competidor en DataForSEO: " + avisos.join(" ") + " No se ha cambiado nada: prueba de nuevo en unos minutos.", 502);
    const cands = [...byKw.values()].map((g) => {
      const best = Math.min(...g.comps.map((c) => c.pos ?? 999));
      return { ...g, competidores: g.comps.map((c) => c.dominio + (c.pos ? " #" + c.pos : "")).join("; "), mejor_posicion: best === 999 ? null : best };
    });
    const lug = await places(db, keys, cfg, m).catch((e) => ({ nombres: [], aviso: "No se pudo leer la lista de ciudades (" + e.message + "): no se descartan b\xFAsquedas de otras ciudades." }));
    const id = await relacionadas(db, keys, cfg, m).catch((e) => ({ keywords: [], aviso: "No se pudieron traer las b\xFAsquedas de tus semillas (" + e.message + "): la relevancia solo usa semillas y p\xFAblico." }));
    const res = filterGaps(cands, context(cfg, { ideas: id.keywords, lugares: lug.nombres }));
    const s = await store(db, cfg, res, "dataforseo");
    return { dominio: dom2, competidores: leidos, keywords: cands.length, pasan: res.pasan.length, descartadas: res.fuera.length, por_filtro: res.conteo, ...s, avisos: [...avisos, lug.aviso, id.aviso].filter(Boolean) };
  });
}
async function refilterGaps(db, _i, keys = keysClient()) {
  return withMeter(db, "refiltrar_huecos", async (m) => {
    const cfg = await settings(db);
    needDomain(cfg);
    const rows = [
      ...await db.all("SELECT keyword, volumen, dificultad, intencion, intenciones, competidores, mejor_posicion FROM " + H + " WHERE origen = 'dataforseo' AND _deleted = 0"),
      ...await db.all("SELECT keyword, volumen, dificultad, intencion, intenciones, competidores, mejor_posicion FROM " + D + " WHERE origen = 'dataforseo' AND _deleted = 0")
    ];
    if (!rows.length) throw new Refused("No hay huecos de DataForSEO guardados: pulsa \xABBuscar huecos\xBB.", 404);
    const uniq2 = /* @__PURE__ */ new Map();
    for (const r of rows) if (!uniq2.has(r.keyword)) uniq2.set(r.keyword, { ...r, intenciones: splitList2(String(r.intenciones || "").replace(/,/g, ";")) });
    const lug = await places(db, keys, cfg, m);
    const id = await relacionadas(db, keys, cfg, m);
    const res = filterGaps([...uniq2.values()], context(cfg, { ideas: id.keywords, lugares: lug.nombres }));
    const s = await store(db, cfg, res, "dataforseo");
    return { keywords: uniq2.size, pasan: res.pasan.length, descartadas: res.fuera.length, por_filtro: res.conteo, ...s, avisos: [lug.aviso, id.aviso].filter(Boolean) };
  });
}
async function discardedList(db) {
  const cfg = await settings(db);
  const rows = (await db.all("SELECT _id AS id, keyword, volumen, dificultad, intencion, competidores, filtro, motivo, relevancia, buscado, origen FROM " + D + " WHERE vigente = 1 AND COALESCE(origen, '') NOT IN ('competidores', 'publico') AND _deleted = 0 ORDER BY volumen DESC")).map((r) => ({ ...r, dificultad: kdOf(r.dificultad) }));
  let resumen = null;
  try {
    resumen = JSON.parse(cfg.huecos_filtro || "null");
  } catch {
    resumen = null;
  }
  const costes = await lastCosts(db);
  const comps = competitorsOf(cfg).filter((c) => c !== domainOf2(cfg.dominio)).slice(0, MAX_COMPETIDORES).length;
  return {
    rows,
    resumen,
    filtros: FILTROS,
    buscado: cfg.huecos_buscados ?? null,
    coste: costes.ultimo.buscar_huecos ?? null,
    estimacion: (() => {
      const nSug = Math.min(MAX_SEMILLAS_SUG, new Set(semillasCortas(cfg).map((x) => norm(x.corta))).size);
      const inter = comps * (PRECIOS.labs_tarea + LIMITE_INTERSECCION * PRECIOS.labs_item), sug = nSug * (PRECIOS.labs_tarea + LIMITE_SUGERENCIAS * PRECIOS.labs_item);
      return {
        competidores: comps,
        usd: usd(inter + sug),
        usd_min: usd(inter),
        texto: comps + " consulta" + (comps === 1 ? "" : "s") + " de Labs domain_intersection, una por competidor (hasta " + LIMITE_INTERSECCION + " keywords cada una, " + usd(inter) + ") y, solo si a\xFAn no est\xE1n guardadas, las b\xFAsquedas de tus " + nSug + " semillas cortas (Labs keyword_suggestions, " + usd(sug) + "; se comparten con \xABBuscar competidores\xBB)"
      };
    })(),
    umbrales: { volumen_min: Number(cfg.volumen_min) || 0, kd_max: cfg.kd_max ?? null, relevancia_min: cfg.relevancia_min ?? RELEVANCIA_MIN, zonas: splitList2(cfg.zonas) }
  };
}

// server/services/serpdfs.mjs
var SERP = { concurrencia: 4, timeoutMs: 6e4, cacheHoras: 72, reintentos: 1, depth: 10, device: "desktop", modo: "regular" };
var MODOS = ["regular", "advanced"];
var serpModo = (cfg) => String(cfg?.serp_modo || "").trim().toLowerCase() === "regular" ? "regular" : "advanced";
var serpPath = (modo = "regular") => "serp/google/organic/live/" + (modo === "advanced" ? "advanced" : "regular");
var serpTask = (w) => ({ ...w, depth: SERP.depth, device: SERP.device, os: "windows" });
var serpClave = (q, w, modo = "regular") => "serp:" + norm(q).replace(/\s+/g, " ") + ":" + w.location_code + ":" + w.language_code + ":" + SERP.device + ":" + (modo === "advanced" ? "advanced" : "regular");
var precioClave = (modo) => "precio_serp:" + (modo === "advanced" ? "advanced" : "regular");
async function serpPrecio(db, modo = "regular") {
  const tabla = modo === "advanced" ? PRECIOS.serp_live_advanced : PRECIOS.serp_live;
  if (!db) return { usd: tabla, real: false, modo };
  const c = await cacheGet(db, precioClave(modo));
  const v = Number(c?.valor?.usd);
  return v > 0 ? { usd: v, real: true, fecha: c.fecha, modo } : { usd: tabla, real: false, modo };
}
var serpPrecioTxt = (p) => "DataForSEO Live " + p.modo + ", " + usd(p.usd) + " cada una" + (p.real ? " seg\xFAn el \xFAltimo coste real" : "");
var corta = (v, n = 200) => v == null ? null : String(v).slice(0, n);
var compacto = (items) => (items ?? []).map((x) => x?.type === "organic" ? {
  type: "organic",
  rank_group: x.rank_group ?? null,
  rank_absolute: x.rank_absolute ?? null,
  domain: x.domain ?? null,
  url: x.url ?? null,
  title: corta(x.title),
  breadcrumb: corta(x.breadcrumb),
  website_name: corta(x.website_name)
} : x?.type === "ai_overview" ? aiOverview(x) : x?.type === "people_also_ask" ? { type: "people_also_ask", items: (x.items ?? []).map((q) => corta(typeof q === "string" ? q : q?.title)).filter(Boolean).slice(0, 12) } : x?.type === "related_searches" ? { type: "related_searches", items: (x.items ?? []).map((q) => corta(typeof q === "string" ? q : q?.title)).filter(Boolean).slice(0, 12) } : { type: String(x?.type || "desconocido") });
function aiOverview(x) {
  const refs = [];
  const seen = /* @__PURE__ */ new Set();
  const add = (r) => {
    const url = r?.url ? String(r.url) : null;
    const domain = String(r?.domain || "").toLowerCase().replace(/^www\./, "");
    if (!domain || seen.has(url || domain)) return;
    seen.add(url || domain);
    refs.push({ domain, url, title: corta(r.title, 160), source: corta(r.source, 80) });
  };
  for (const r of x?.references ?? []) add(r);
  for (const it of x?.items ?? []) {
    for (const r of it?.references ?? []) add(r);
    for (const l of it?.links ?? []) add(l);
  }
  const text = String(x?.markdown || (x?.items ?? []).map((it) => [it?.title, it?.text].filter(Boolean).join(": ")).join(" ") || "").replace(/\s+/g, " ").trim();
  return { type: "ai_overview", asynchronous_ai_overview: !!x?.asynchronous_ai_overview, text: text.slice(0, 1500), references: refs.slice(0, 25) };
}
async function serpLive(keys, q, w, m, cfg = SERP) {
  const path = serpPath(cfg.modo);
  for (let intento = 0; ; intento++) {
    try {
      const j = await dfsRaw(keys, "POST", path, [{ keyword: q, ...serpTask(w), ...cfg.extra ?? {} }], m, 1, { timeoutMs: cfg.timeoutMs });
      const t = j?.tasks?.[0];
      if (!t || t.status_code !== 2e4) throw new Refused("DataForSEO: " + (t?.status_message || j?.status_message || "sin respuesta") + ".", 502);
      const cost = Number(j?.cost ?? t?.cost);
      return { items: t.result?.[0]?.items ?? [], intentos: intento + 1, cost: Number.isFinite(cost) ? cost : null };
    } catch (e) {
      if (e.timeout) {
        m?.fallo?.(path, "tiempo agotado, sin coste devuelto");
        if (intento < (cfg.reintentos ?? 1)) continue;
      }
      throw e;
    }
  }
}
async function serpBatch(keys, consultas, w, m, opts = {}) {
  const cfg = { ...SERP, ...opts };
  const db = opts.db ?? null;
  const qs = [...new Set((consultas ?? []).map((q) => String(q || "").trim()).filter(Boolean))];
  const got = /* @__PURE__ */ new Map();
  const pedir = [];
  for (const q of qs) {
    const c = db && !cfg.forzar ? await cacheGet(db, serpClave(q, w, cfg.modo), { maxHoras: cfg.cacheHoras }) : null;
    if (c?.valor?.items) got.set(q, { items: c.valor.items, metodo: "cache", fecha: c.fecha, horas: c.horas });
    else pedir.push(q);
  }
  await pool(pedir, cfg.concurrencia, async (q) => {
    try {
      const r = await serpLive(keys, q, w, m, cfg);
      const items = compacto(r.items);
      const fecha = db ? await cacheSet(db, serpClave(q, w, cfg.modo), { keyword: q, modo: cfg.modo, items }) : ahora();
      if (db && r.cost > 0) await cacheSet(db, precioClave(cfg.modo), { usd: r.cost });
      got.set(q, { items, metodo: "live", fecha, horas: 0, intentos: r.intentos });
    } catch (e) {
      if (e.status === 424 || e.status === 429) throw e;
      got.set(q, { error: e.message, timeout: !!e.timeout });
    }
  });
  const out = /* @__PURE__ */ new Map();
  for (const q of qs) out.set(q, got.get(q));
  if (m?.notas) {
    const r = serpResumen(out);
    if (r.cache) m.notas.push(r.texto);
  }
  return out;
}
function serpResumen(res) {
  const v = [...res?.values?.() ?? []].filter(Boolean);
  const cache = v.filter((x) => x.metodo === "cache");
  const live = v.filter((x) => x.metodo === "live");
  const err = v.filter((x) => x.error);
  const hs = cache.map((x) => x.horas);
  const min = hs.length ? Math.min(...hs) : null, max = hs.length ? Math.max(...hs) : null;
  const de2 = !hs.length ? "" : Math.floor(min) === Math.floor(max) ? " (" + haceTxt(max) + ")" : " (de " + haceTxt(min).replace(/^hace /, "hace ") + " a " + haceTxt(max).replace(/^hace /, "") + ")";
  const partes = [cache.length ? cache.length + " top 10 de la cach\xE9" + de2 : "", live.length ? live.length + " pedido" + (live.length === 1 ? "" : "s") + " ahora" : "", err.length ? err.length + " sin respuesta" : ""].filter(Boolean);
  const n = (k, uno, varios) => k + " " + (k === 1 ? uno : varios);
  const frase = [live.length ? n(live.length, "top 10 pedido", "top 10 pedidos") + " a DataForSEO" : "", cache.length ? n(cache.length, live.length ? "le\xEDdo" : "top 10 le\xEDdo", live.length ? "le\xEDdos" : "top 10 le\xEDdos") + " de los guardados" + de2 + ", sin coste" : "", err.length ? n(err.length, "b\xFAsqueda", "b\xFAsquedas") + " sin respuesta" : ""].filter(Boolean).join("; ");
  return { cache: cache.length, live: live.length, errores: err.length, horas_min: min, horas_max: max, texto: partes.join(", "), frase };
}
var serpEdadTxt = (sr) => !sr || sr.error ? null : sr.metodo === "cache" ? "top 10 de " + haceTxt(sr.horas) + " (cach\xE9)" : "top 10 pedido ahora";
async function serpEnCache(db, consultas, w, opts = {}) {
  const cfg = { ...SERP, ...opts };
  const out = /* @__PURE__ */ new Map();
  for (const q of [...new Set((consultas ?? []).map((x) => String(x || "").trim()).filter(Boolean))]) {
    const c = await cacheGet(db, serpClave(q, w, cfg.modo), { maxHoras: cfg.cacheHoras });
    if (c?.valor?.items) out.set(q, { metodo: "cache", horas: c.horas, fecha: c.fecha });
  }
  return out;
}
var esGoto = (u) => /^https?:\/\/(www\.)?google\.[a-z.]+\/(goto|url|aclk)\b/i.test(String(u || ""));
var porFuente = (validos) => validos.reduce((a, v) => ({ ...a, [v.fuente]: (a[v.fuente] || 0) + 1 }), {});
var urlCorta = (u, n = 80) => {
  if (u == null) return null;
  const s = String(u);
  return s.length > n ? s.slice(0, n - 1) + "\u2026" : s;
};
function itemCrudo(x, max = 300) {
  const rec = (v, prof = 0) => {
    if (typeof v === "string") return v.length > max ? v.slice(0, max) + "\u2026 (" + v.length + " caracteres)" : v;
    if (Array.isArray(v)) return v.map((y) => rec(y, prof + 1));
    if (v && typeof v === "object") return prof > 6 ? "[\u2026]" : Object.fromEntries(Object.entries(v).filter(([k]) => !/authorization|password|login|token|api[_-]?key/i.test(k)).map(([k, y]) => [k, rec(y, prof + 1)]));
    return v;
  };
  return rec(x);
}
function informeDe(modo, r, segundos) {
  const items = r.items ?? [];
  const org = items.filter((x) => x?.type === "organic");
  const o = organicTop(items, { n: 10 });
  const primeros = org.slice(0, 3).map((x) => {
    const v = organicTop([x], { n: 1 }).validos[0];
    return {
      type: x.type ?? null,
      rank_group: x.rank_group ?? null,
      domain: x.domain ?? null,
      url: urlCorta(x.url),
      es_goto: esGoto(x.url),
      breadcrumb: x.breadcrumb ?? null,
      title: x.title != null ? String(x.title).slice(0, 120) : null,
      ...modo === "advanced" ? { website_name: x.website_name ?? null } : {},
      dominio_valido: v ? v.dominio : null,
      dominio_de: v ? v.fuente : null
    };
  });
  const muestra = org.find((x) => esGoto(x.url)) ?? org[0] ?? null;
  const pf = porFuente(o.validos);
  return {
    peticion: serpPath(modo) + " \xB7 depth " + SERP.depth + " \xB7 " + SERP.device + " \xB7 sin resolve_goto_urls",
    segundos,
    items: items.length,
    organicos: org.length,
    con_goto: org.filter((x) => esGoto(x.url)).length,
    coste_usd: r.cost,
    coste: usd(r.cost),
    validos: o.validos.length,
    validos_por_fuente: pf,
    validos_txt: o.validos.length + " con dominio v\xE1lido" + (o.validos.length ? " (" + Object.entries(pf).map(([k, n]) => n + " de " + k).join(", ") + ")" : "") + "; " + o.quitados.length + " descartados",
    fiable: o.fiable,
    tipos: o.tipos,
    primeros_organicos: primeros,
    item_crudo_de: muestra ? (esGoto(muestra.url) ? "el primer org\xE1nico con enlace goto" : "el primer org\xE1nico") + " (posici\xF3n " + (muestra.rank_group ?? "?") + ")" : null,
    item_crudo: muestra ? itemCrudo(muestra) : null
  };
}
async function probeSerp(db, { keyword } = {}, keys = keysClient()) {
  const k = String(keyword || "").trim();
  if (!k) throw new Refused("Di qu\xE9 keyword probar (keyword).", 400);
  return withMeter(db, "probar_serp", async (m) => {
    const cfg = await settings(db);
    const w = where(cfg);
    const out = {};
    for (const modo of MODOS) {
      const t0 = Date.now();
      try {
        const r = await serpLive(keys, k, w, m, { ...SERP, reintentos: 0, modo });
        out[modo] = informeDe(modo, r, Math.round((Date.now() - t0) / 100) / 10);
      } catch (e) {
        if (e.status === 429 || /Faltan las claves/.test(String(e.message))) throw e;
        out[modo] = { peticion: serpPath(modo), error: e.message, segundos: Math.round((Date.now() - t0) / 100) / 10 };
      }
    }
    if (out.regular.error && out.advanced.error) throw new Refused("Fallaron las dos peticiones: regular \u2014 " + out.regular.error + " \xB7 advanced \u2014 " + out.advanced.error, 502);
    const resumen = MODOS.map((md) => md + ": " + (out[md].error ? "fall\xF3 (" + out[md].error + ")" : out[md].validos + " de " + out[md].organicos + " org\xE1nicos con dominio v\xE1lido (" + out[md].con_goto + " con goto), " + out[md].segundos + " s, " + out[md].coste)).join(" \xB7 ");
    return {
      keyword: k,
      ubicacion: w.location_code,
      idioma: w.language_code,
      modo_en_ajustes: serpModo(cfg),
      regular: out.regular,
      advanced: out.advanced,
      resumen,
      fuentes: FUENTE_TXT
    };
  });
}

// server/services/competidores.mjs
var CP = "oportunidadesseo_competidores";
var now3 = () => (/* @__PURE__ */ new Date()).toISOString().slice(0, 19).replace("T", " ");
var splitList3 = (s) => String(s ?? "").split(/[;\n,]/).map((x) => x.trim()).filter(Boolean);
var round1 = (v) => Math.round(v * 10) / 10;
var fmt = (n) => miles(n || 0);
var LIMITE_COMPETIDORES = 100;
var MIN_REL = 3;
var MIN_REL_PCT = 0.1;
function minimoRelevantes(n) {
  const N3 = Number(n) || 0;
  if (!N3) return 0;
  const m = Math.max(MIN_REL, Math.ceil(MIN_REL_PCT * N3));
  return Math.max(Math.min(2, N3), Math.min(m, Math.ceil(N3 / 2)));
}
var minimoTxt = (n) => "m\xEDnimo " + minimoRelevantes(n) + " keywords relevantes compartidas: " + MIN_REL + " o el " + Math.round(MIN_REL_PCT * 100) + " % de las " + n + " buscadas, lo que sea mayor" + (Math.ceil(n / 2) < Math.max(MIN_REL, Math.ceil(MIN_REL_PCT * n)) ? " (con tan pocas b\xFAsquedas, como mucho la mitad)" : "");
var MAX_PROPUESTOS = 20;
var MIN_PROPUESTOS = 3;
var PORTAL_ETV = 5e5;
var GENERICO_ETV = 1e5;
var GENERICO_VECES = 30;
var COMP_SERP_MAX = 16;
var MAX_KW_LABS = 200;
var MAX_LLAMADAS_LABS = 2;
var BASE_DIRECTORIOS = {
  red_social: ["facebook.com", "instagram.com", "linkedin.com", "x.com", "twitter.com", "tiktok.com", "pinterest.com", "youtube.com", "threads.net"],
  foro: ["reddit.com", "quora.com", "stackoverflow.com", "stackexchange.com"],
  hosting: ["godaddy.com", "ionos.es", "ionos.com", "hostinger.com", "hostinger.es", "wix.com", "wordpress.com", "squarespace.com", "webnode.com", "webnode.es", "jimdo.com", "shopify.com", "canva.com", "namecheap.com", "siteground.com", "siteground.es"],
  directorio: ["paginasamarillas.es", "sortlist.es", "sortlist.com", "clutch.co", "goodfirms.co", "trustpilot.com", "capterra.es", "g2.com", "yelp.es"],
  medio: ["wikipedia.org", "wikihow.com", "medium.com", "blogspot.com", "xataka.com", "genbeta.com"]
};
var TIPO_TXT = { red_social: "una red social", foro: "un foro o web de preguntas", hosting: "un hosting, registrador de dominios o creador de webs", directorio: "un directorio o comparador de empresas", medio: "un medio, enciclopedia, blog o web de formaci\xF3n", institucion: "una instituci\xF3n u organizaci\xF3n" };
var NOMBRE = [
  [/(foro|forum)/, "foro"],
  [/(directori|paginas|amarill|listado|ranking|mejores|comparador|marketplace)/, "directorio"],
  [/(hosting)/, "hosting"],
  [/(wiki|noticia|news|diario|periodico|revista|magazine|opinion|review|blog|tutorial|curso|academ|universi)/, "medio"]
];
var dentro = (dom2, x) => dom2 === x || dom2.endsWith("." + x);
function directoriosCtx(cfg) {
  const lista5 = splitList3(cfg.directorios);
  const quitar = new Set(lista5.filter((x) => x.startsWith("-")).map((x) => norm(domainOf2(x.slice(1)))));
  const propios = lista5.filter((x) => !x.startsWith("-")).map((x) => norm(domainOf2(x))).filter(Boolean);
  const base = Object.entries(BASE_DIRECTORIOS).flatMap(([tipo, ds]) => ds.filter((d) => !quitar.has(d)).map((d) => ({ d, tipo })));
  return { directorios: propios, base, quitados: [...quitar], nunca: neverOf(cfg) };
}
function kindOf(d, ctx) {
  const dom2 = norm(d).replace(/^www\./, "");
  if ((ctx.nunca ?? []).some((x) => dentro(dom2, x))) return { filtro: "nunca", motivo: "Est\xE1 en tu lista \xABNunca son competidores\xBB (Ajustes \u2192 Competencia)" };
  if ((ctx.directorios ?? []).some((x) => dentro(dom2, x))) return { filtro: "directorio", motivo: "Est\xE1 en tu lista de directorios y medios (Ajustes \u2192 Directorios)" };
  const b = (ctx.base ?? []).find((x) => dentro(dom2, x.d));
  if (b) return { filtro: b.tipo, motivo: "Es " + TIPO_TXT[b.tipo] + ", no una empresa del sector (lista base del m\xF3dulo; para que cuente, escribe \xAB-" + b.d + "\xBB en Ajustes \u2192 Directorios)" };
  for (const [re, tipo] of NOMBRE) {
    const m = dom2.match(re);
    if (m) return { filtro: tipo, motivo: "Por su nombre (\xAB" + m[1] + "\xBB) parece " + TIPO_TXT[tipo] + ", no una empresa del sector" };
  }
  if (/\.(gob|gov|edu)(\.|$)|\.org$|\.org\./.test(dom2)) return { filtro: "institucion", motivo: "Es una instituci\xF3n u organizaci\xF3n, no una empresa del sector" };
  return null;
}
var LISTA = /(\b\d+\s+mejores\b|\bmejores\s+(empresas|agencias|consultoras|proveedores)\b|\btop\s+\d+\b|\branking\b|\blistado\b|\bdirectorio\b|^empresas\s+de\s.+\sen\s)/;
var fuerte = (x) => x === true || x === "true" || x === 1;
var uniq = (arr) => {
  const seen = /* @__PURE__ */ new Set();
  const out = [];
  for (const k of arr) {
    const s = String(k || "").trim();
    const n = norm(s);
    if (!s || seen.has(n)) continue;
    seen.add(n);
    out.push(s);
  }
  return out;
};
async function keywordsParaCompetidores(db, cfg, keys, m) {
  const ss = semillasCortas(cfg);
  const huecos = (await db.all("SELECT keyword FROM " + H + " WHERE origen = 'dataforseo' AND COALESCE(estado, '') != 'filtrado' AND _deleted = 0 ORDER BY ganable DESC, volumen DESC LIMIT ?", [MAX_KW_LABS * MAX_LLAMADAS_LABS])).map((x) => x.keyword);
  const cortas = uniq(ss.map((x) => x.corta));
  const sg = await sugerencias(db, keys, cfg, m, cortas);
  const ya = new Set([...huecos, ...cortas].map(norm));
  const vistas = /* @__PURE__ */ new Set();
  const cands = [];
  for (const x of sg.items) {
    const n = norm(x.keyword);
    if (ya.has(n) || vistas.has(n)) continue;
    vistas.add(n);
    cands.push({ ...x });
  }
  let lug = { nombres: [] };
  if (cands.length) {
    try {
      lug = await places(db, keys, cfg, m);
    } catch (e) {
      if (e.status === 429) throw e;
      lug = { nombres: [], aviso: "No se pudo leer la lista de ciudades de DataForSEO (" + e.message + "): no se descartan b\xFAsquedas de otras ciudades." };
    }
  }
  const ctx = { ...context(cfg, { ideas: [], lugares: lug.nombres }), kdmax: null };
  const f = filterGaps(cands, ctx);
  const pasan = f.pasan.map((x) => x.keyword);
  const keywords = uniq([...huecos, ...cortas, ...pasan]).slice(0, MAX_KW_LABS * MAX_LLAMADAS_LABS);
  return {
    keywords,
    huecos,
    cortas,
    fuera: f.fuera,
    sugerencias_cache: sg.cache ?? null,
    de: { huecos: huecos.length, semillas_cortas: cortas.length, sugerencias: cands.length, sugerencias_pasan: pasan.length, sugerencias_fuera: f.fuera.length },
    umbral: { relevancia_min: ctx.rmin, volumen_min: ctx.vmin },
    avisos: [sg.aviso, lug.aviso].filter(Boolean)
  };
}
async function guardarDescartadas(db, fuera, buscado) {
  for (const x of await db.all("SELECT _id FROM " + D + " WHERE origen = 'competidores' AND vigente = 1 AND _deleted = 0")) await db.update(D, x._id, { vigente: 0 });
  for (const f of fuera) {
    const data = {
      keyword: f.keyword,
      volumen: f.volumen ?? null,
      dificultad: f.dificultad ?? null,
      intencion: f.intencion ?? null,
      intenciones: (f.intenciones || []).join(", "),
      competidores: f.semilla ? "Sugerencia de \xAB" + f.semilla + "\xBB" : null,
      mejor_posicion: null,
      filtro: f.filtro,
      motivo: f.motivo,
      relevancia: f.relevancia ?? null,
      vigente: 1,
      buscado,
      origen: "competidores"
    };
    const ex = await db.one("SELECT _id FROM " + D + " WHERE keyword = ? AND origen = 'competidores' AND _deleted = 0", [f.keyword]);
    if (ex) await db.update(D, ex._id, data);
    else await db.insert(D, data);
  }
}
function filas(map) {
  return [...map.values()].map((y) => {
    const l = [...y.kws.values()].sort((a, b) => (a.pos ?? 999) - (b.pos ?? 999));
    const ps = l.map((z) => z.pos).filter((p) => Number.isFinite(p));
    return {
      dominio: y.dominio,
      semillas_n: l.length,
      semillas: l.map((z) => z.keyword + (Number.isFinite(z.pos) ? " (#" + z.pos + ")" : "")).join("; "),
      posicion_media: ps.length ? round1(ps.reduce((a, b) => a + b, 0) / ps.length) : null,
      visibilidad: y.visibilidad ?? null,
      etv: null,
      keywords: y.total ?? l.length,
      url: y.url ?? null,
      titulos: y.titulos ?? []
    };
  });
}
var candidatos = (rows, cfg, minimo) => {
  const ya = new Set(competitorsOf(cfg));
  const ctx = directoriosCtx(cfg);
  return rows.filter((x) => !ya.has(x.dominio) && !kindOf(x.dominio, ctx) && x.semillas_n >= minimo);
};
async function trafico(keys, rows, w, m, avisos) {
  if (!rows.length) return;
  try {
    const bt = await dfs(keys, "dataforseo_labs/google/bulk_traffic_estimation/live", { targets: rows.slice(0, LIMITE_COMPETIDORES).map((x) => x.dominio), ...w, item_types: ["organic"] }, m);
    const etv = new Map((bt.items ?? []).map((it) => [domainOf2(it.target), Math.round(it.metrics?.organic?.etv ?? 0)]));
    for (const x of rows) x.etv = etv.get(x.dominio) ?? null;
  } catch (e) {
    if (e.status === 424 || e.status === 429) throw e;
    avisos.push("No se pudo leer el tr\xE1fico estimado de los dominios (" + e.message + "): los portales solo se separan por tipo.");
  }
}
function clasificar(rows, n, cfg, unidad = "keywords relevantes") {
  const ya = new Set(competitorsOf(cfg));
  const ctx = directoriosCtx(cfg);
  const minimo = minimoRelevantes(n);
  const etvs = candidatos(rows, cfg, minimo).map((x) => x.etv).filter((v) => v != null).sort((a, b) => a - b);
  const mediana = etvs.length ? etvs[Math.floor(etvs.length / 2)] : 0;
  const out = [];
  const pasan = [];
  for (const x of rows) {
    const comparte = "Comparte " + x.semillas_n + " de " + n + " " + unidad + (x.posicion_media != null ? ", posici\xF3n media " + String(x.posicion_media).replace(".", ",") : "");
    const tipo = kindOf(x.dominio, ctx);
    const listas = x.titulos?.length && x.titulos.every((t) => LISTA.test(norm(t)));
    const etv = x.etv || 0;
    let r;
    if (ya.has(x.dominio)) r = { estado: "adoptado", filtro: null, motivo: "Ya est\xE1 en Ajustes \u2192 Competidores \xB7 " + comparte };
    else if (tipo) r = { estado: "descartado", ...tipo };
    else if (listas) r = { estado: "descartado", filtro: "directorio", motivo: "Lo que sale es una lista de empresas (\xAB" + x.titulos[0].slice(0, 70) + "\xBB): un directorio, no una empresa del sector" };
    else if (etv >= PORTAL_ETV) r = { estado: "descartado", filtro: "generico", motivo: "M\xE1s de " + fmt(PORTAL_ETV) + " visitas/mes estimadas (" + fmt(etv) + "): un portal o medio generalista, no una empresa como la tuya" };
    else if (mediana > 0 && etv >= GENERICO_ETV && etv > GENERICO_VECES * mediana) r = { estado: "descartado", filtro: "generico", motivo: fmt(etv) + " visitas/mes estimadas, m\xE1s de " + GENERICO_VECES + " veces el dominio mediano de la lista (" + fmt(mediana) + "): un portal generalista" };
    else if (n >= 3 && x.semillas_n / n >= 0.7 && mediana > 0 && etv > 10 * mediana) r = { estado: "descartado", filtro: "generico", motivo: "Sale en casi todas las b\xFAsquedas (" + x.semillas_n + " de " + n + ") y su tr\xE1fico estimado es m\xE1s de 10 veces el del dominio mediano: un portal generalista" };
    else if (x.semillas_n < minimo) r = { estado: "descartado", filtro: "pocas", motivo: "Pocas keywords relevantes: comparte " + x.semillas_n + " (" + minimoTxt(n) + ")" };
    else {
      r = { estado: "propuesto", filtro: null, motivo: comparte };
      pasan.push(out.length);
    }
    out.push({ ...x, ...r });
  }
  pasan.sort((a, b) => out[b].semillas_n - out[a].semillas_n || (out[a].posicion_media ?? 999) - (out[b].posicion_media ?? 999));
  pasan.slice(MAX_PROPUESTOS).forEach((i) => {
    out[i] = { ...out[i], estado: "descartado", filtro: "tope", motivo: "Pasa los criterios (" + out[i].semillas_n + " keywords relevantes), pero hay " + MAX_PROPUESTOS + " que comparten m\xE1s" };
  });
  const cuenta = (e) => out.filter((x) => x.estado === e).length;
  return { rows: out, minimo, mediana, propuestos: cuenta("propuesto"), descartados: cuenta("descartado"), adoptados: cuenta("adoptado") };
}
async function paginas(db, rows) {
  const faltan = rows.filter((x) => !x.url && x.estado !== "descartado");
  if (!faltan.length) return;
  const quiero = new Set(faltan.map((x) => x.dominio));
  const got = /* @__PURE__ */ new Map();
  for (const c of await db.all("SELECT valor FROM " + CACHE + " WHERE clave LIKE 'serp:%' AND _deleted = 0 ORDER BY _id DESC LIMIT 300")) {
    let v = null;
    try {
      v = JSON.parse(c.valor || "null");
    } catch {
      continue;
    }
    for (const t of organicTop(v?.items ?? []).validos) if (quiero.has(t.dominio) && t.url) {
      const l = got.get(t.dominio) || [];
      l.push({ url: t.url, keyword: norm(v.keyword) });
      got.set(t.dominio, l);
    }
  }
  for (const x of faltan) {
    const l = got.get(x.dominio) ?? [];
    const mias = new Set(String(x.semillas || "").split("; ").map((k) => norm(k.replace(/\s*\(#\d+\)$/, ""))));
    x.url = (l.find((p) => mias.has(p.keyword)) ?? l[0])?.url ?? "https://" + x.dominio + "/";
  }
}
async function guardar(db, cfg, cl, metodo, buscado) {
  for (const x of cl.rows) {
    const ex = await db.one("SELECT _id, estado, filtro, motivo FROM " + CP + " WHERE dominio = ? AND _deleted = 0", [x.dominio]);
    const aMano = ex && ex.estado === "descartado" && (ex.filtro === "manual" || !ex.filtro && /^(Sale en|Comparte|Descartado a mano)/.test(String(ex.motivo || "")));
    const { titulos, ...data0 } = x;
    const data = { ...data0, metodo, buscado, ...aMano && x.estado === "propuesto" ? { estado: "descartado", filtro: "manual", motivo: "Descartado a mano" } : {} };
    if (ex) await db.update(CP, ex._id, data);
    else await db.insert(CP, data);
  }
  await db.update(A, cfg._id, { competidores_buscados: buscado });
}
async function findCompetitors(db, input = {}, keys = keysClient()) {
  const forzar = fuerte(input?.forzar);
  return withMeter(db, "buscar_competidores", async (m) => {
    const cfg = await settings(db);
    const ss = semillasCortas(cfg);
    if (!ss.length) throw new Refused("Faltan temas semilla en Ajustes (General \u2192 Temas semilla).", 400);
    const own = domainOf2(cfg.dominio);
    const esPropio = (d) => own && (d === own || d.endsWith("." + own));
    const w = where(cfg);
    const buscado = now3();
    const kw = await keywordsParaCompetidores(db, cfg, keys, m);
    const avisos = [...kw.avisos];
    await guardarDescartadas(db, kw.fuera, buscado);
    const rel = new Map(kw.keywords.map((k) => [norm(k), k]));
    const porDominio = /* @__PURE__ */ new Map();
    let llamadasLabs = 0;
    await pool(trozos(kw.keywords, MAX_KW_LABS).slice(0, MAX_LLAMADAS_LABS), 4, async (lote) => {
      llamadasLabs++;
      try {
        const r = await dfs(keys, "dataforseo_labs/google/serp_competitors/live", { keywords: lote, ...w, item_types: ["organic"], include_subdomains: true, limit: LIMITE_COMPETIDORES }, m);
        for (const x of r.items ?? []) {
          const d = domainOf2(x?.domain);
          if (!d || isGoogle(d) || esPropio(d)) continue;
          const y = porDominio.get(d) || { dominio: d, kws: /* @__PURE__ */ new Map(), total: 0, visibilidad: null };
          for (const [k, pos] of Object.entries(x.keywords_positions || {})) {
            const n2 = norm(k);
            if (!rel.has(n2)) continue;
            const p = Array.isArray(pos) ? Math.min(...pos.map(Number).filter(Number.isFinite)) : Number(pos);
            y.kws.set(n2, { keyword: rel.get(n2), pos: Number.isFinite(p) ? p : null });
          }
          y.total += Number(x.keywords_count ?? Object.keys(x.keywords_positions || {}).length) || 0;
          y.visibilidad = Math.max(y.visibilidad ?? 0, x.visibility ?? 0);
          porDominio.set(d, y);
        }
      } catch (e) {
        if (e.status === 424 || e.status === 429) throw e;
        avisos.push("Labs serp_competitors fall\xF3 (" + e.message + ").");
      }
    });
    const nLabs = kw.keywords.length;
    let labs = null;
    if (porDominio.size) {
      const rows = filas(porDominio);
      await trafico(keys, candidatos(rows, cfg, minimoRelevantes(nLabs)), w, m, avisos);
      labs = clasificar(rows, nLabs, cfg);
    }
    let elegido = labs, metodo = "labs", serp = null, n = nLabs;
    if (!labs || labs.propuestos < MIN_PROPUESTOS) {
      avisos.push(labs ? "DataForSEO Labs dej\xF3 solo " + labs.propuestos + " competidor" + (labs.propuestos === 1 ? "" : "es") + " con " + minimoTxt(nLabs) + ": se busc\xF3 tambi\xE9n en Google." : "DataForSEO Labs no devolvi\xF3 dominios para " + nLabs + " keywords relevantes: se busc\xF3 en Google.");
      const qs = uniq([...kw.cortas, ...kw.huecos]).slice(0, COMP_SERP_MAX);
      if (kw.cortas.length + kw.huecos.length > qs.length) avisos.push("Se buscaron en Google " + qs.length + " de " + (kw.cortas.length + kw.huecos.length) + " keywords (tope de coste): las semillas cortas y los huecos m\xE1s ganables.");
      const res = await serpBatch(keys, qs, w, m, { db, forzar, modo: serpModo(cfg) });
      const agg = /* @__PURE__ */ new Map();
      const consultas = [];
      for (const q of qs) {
        const sr = res.get(String(q).trim());
        if (!sr || sr.error) {
          consultas.push({ consulta: q, error: sr?.error || "sin respuesta" });
          continue;
        }
        const o = organicTop(sr.items, { n: 10 });
        consultas.push({ consulta: q, validos: o.validos.length, quitados: o.quitados.length, fiable: o.fiable, origen: serpEdadTxt(sr) });
        for (const t of o.validos) {
          if (esPropio(t.dominio)) continue;
          const x = agg.get(t.dominio) || { dominio: t.dominio, kws: /* @__PURE__ */ new Map(), titulos: [], url: t.url };
          if (!x.kws.has(norm(q))) x.kws.set(norm(q), { keyword: q, pos: Number(t.pos) || 10 });
          x.titulos.push(t.titulo || "");
          x.total = x.kws.size;
          agg.set(t.dominio, x);
        }
      }
      const resumen = serpResumen(res);
      if (resumen.cache) avisos.push("Top 10: " + resumen.texto + ".");
      const noFiables = consultas.filter((c) => c.fiable === false).length;
      if (noFiables) avisos.push(noFiables + " b\xFAsqueda" + (noFiables === 1 ? "" : "s") + " con menos de " + MIN_VALIDOS + " resultados v\xE1lidos (top 10 no fiable): cuentan sus dominios v\xE1lidos, sin afirmar nada m\xE1s.");
      const nSerp = consultas.filter((c) => !c.error).length || qs.length;
      const rows = filas(agg);
      await trafico(keys, candidatos(rows, cfg, minimoRelevantes(nSerp)), w, m, avisos);
      const cs = clasificar(rows, nSerp, cfg, "b\xFAsquedas en Google");
      serp = { busquedas: consultas.length, consultas, top10: resumen, dominios: rows.length, propuestos: cs.propuestos };
      if (!labs || cs.propuestos >= labs.propuestos) {
        elegido = cs;
        metodo = "serp";
        n = nSerp;
      } else avisos.push("Google dio menos competidores que Labs: se queda lo de Labs.");
    }
    if (elegido) {
      await paginas(db, elegido.rows);
      await guardar(db, cfg, elegido, metodo, buscado);
    } else await db.update(A, cfg._id, { competidores_buscados: buscado });
    const out = {
      metodo,
      semillas: ss.length,
      keywords_labs: nLabs,
      keywords_de: kw.de,
      umbral: kw.umbral,
      llamadas_labs: llamadasLabs,
      keywords_relevantes: n,
      minimo: minimoRelevantes(n),
      criterio: minimoTxt(n),
      dominios: elegido?.rows.length ?? 0,
      propuestos: elegido?.propuestos ?? 0,
      descartados: elegido?.descartados ?? 0,
      adoptados: elegido?.adoptados ?? 0,
      busquedas: serp?.busquedas ?? 0,
      ...serp ? { consultas: serp.consultas, top10: serp.top10 } : {},
      avisos,
      sin_datos: elegido?.rows.length ? null : "Ni Labs ni las b\xFAsquedas en Google devolvieron webs para estas keywords"
    };
    await cacheSet(db, "competidores:resumen", { buscado, metodo, keywords_relevantes: n, minimo: out.minimo, criterio: out.criterio, keywords_de: kw.de, umbral: kw.umbral, labs: labs ? { dominios: labs.rows.length, propuestos: labs.propuestos } : null, serp: serp ? { busquedas: serp.busquedas, dominios: serp.dominios, propuestos: serp.propuestos } : null, avisos });
    return out;
  });
}
async function competitorList(db) {
  const cfg = await settings(db);
  const buscado = cfg.competidores_buscados ?? null;
  const all = await db.all("SELECT _id AS id, dominio, semillas_n, semillas, posicion_media, visibilidad, etv, keywords, estado, motivo, filtro, buscado, metodo, url FROM " + CP + " WHERE _deleted = 0" + (buscado ? " AND buscado = ?" : "") + " ORDER BY semillas_n DESC, posicion_media ASC", buscado ? [buscado] : []);
  const corto3 = (s) => {
    const l = String(s || "").split("; ").filter(Boolean);
    return l.slice(0, 8).join("; ") + (l.length > 8 ? "; \u2026 y " + (l.length - 8) + " m\xE1s" : "");
  };
  const conTxt = (x) => ({ ...x, url: urlLimpia(x.url, x.dominio), keywords_txt: corto3(x.semillas) });
  const costes = await lastCosts(db);
  const ss = semillasCortas(cfg);
  const cortas = uniq(ss.map((x) => x.corta));
  const metodo = all.find((x) => x.metodo)?.metodo ?? null;
  const resumen = (await cacheGet(db, "competidores:resumen"))?.valor ?? null;
  const descartadas = await db.all("SELECT _id AS id, keyword, volumen, filtro, motivo, relevancia, competidores AS semilla FROM " + D + " WHERE origen = 'competidores' AND vigente = 1 AND _deleted = 0 ORDER BY volumen DESC LIMIT 300");
  const dc = directoriosCtx(cfg);
  let sugEnCache = false, huecosN = 0, serpCache = 0, sugPasan = null;
  try {
    const w = where(cfg);
    const c = await cacheGet(db, claveSugerencias(cortas.slice(0, MAX_SEMILLAS_SUG), cfg));
    sugEnCache = !!c?.valor?.items;
    if (sugEnCache && resumen?.keywords_de) sugPasan = resumen.keywords_de.sugerencias_pasan ?? null;
    huecosN = (await db.one("SELECT count(*) AS n FROM " + H + " WHERE origen = 'dataforseo' AND COALESCE(estado, '') != 'filtrado' AND _deleted = 0"))?.n ?? 0;
    const qs = uniq([...cortas, ...(await db.all("SELECT keyword FROM " + H + " WHERE origen = 'dataforseo' AND COALESCE(estado, '') != 'filtrado' AND _deleted = 0 ORDER BY ganable DESC, volumen DESC LIMIT ?", [COMP_SERP_MAX])).map((x) => x.keyword)]).slice(0, COMP_SERP_MAX);
    serpCache = (await serpEnCache(db, qs, w, { modo: serpModo(cfg) })).size;
  } catch {
  }
  const nSug = Math.min(MAX_SEMILLAS_SUG, cortas.length);
  const kwN = Math.min(MAX_KW_LABS * MAX_LLAMADAS_LABS, huecosN + cortas.length + (sugPasan ?? nSug * LIMITE_SUGERENCIAS));
  const llamadasLabs = Math.max(1, Math.min(MAX_LLAMADAS_LABS, Math.ceil(kwN / MAX_KW_LABS)));
  const sugUsd = sugEnCache ? 0 : nSug * (PRECIOS.labs_tarea + LIMITE_SUGERENCIAS * PRECIOS.labs_item);
  const labsUsd = llamadasLabs * (PRECIOS.labs_tarea + LIMITE_COMPETIDORES * PRECIOS.labs_item);
  const traficoUsd = PRECIOS.labs_tarea + 2 * MAX_PROPUESTOS * PRECIOS.labs_item;
  const busquedas = Math.min(COMP_SERP_MAX, cortas.length + huecosN);
  const precio = await serpPrecio(db, serpModo(cfg));
  const serpUsd = Math.max(0, busquedas - serpCache) * precio.usd;
  const conLabs = sugUsd + labsUsd + traficoUsd;
  const conSerp = conLabs + serpUsd + traficoUsd;
  return {
    propuestos: all.filter((x) => x.estado !== "descartado").map(conTxt),
    descartados: all.filter((x) => x.estado === "descartado").map(conTxt),
    buscado,
    metodo,
    semillas: ss.length,
    competidores: competitorsOf(cfg),
    nunca: neverOf(cfg),
    max_huecos: MAX_HUECOS,
    coste: costes.ultimo.buscar_competidores ?? null,
    keywords_descartadas: descartadas,
    resumen,
    criterios: {
      min_rel: MIN_REL,
      min_pct: Math.round(MIN_REL_PCT * 100),
      max_propuestos: MAX_PROPUESTOS,
      min_propuestos: MIN_PROPUESTOS,
      portal_etv: PORTAL_ETV,
      generico_etv: GENERICO_ETV,
      generico_veces: GENERICO_VECES,
      min_validos: MIN_VALIDOS,
      serp_max: COMP_SERP_MAX,
      relevancia_min: resumen?.umbral?.relevancia_min ?? (cfg.relevancia_min ?? 50),
      volumen_min: Number(cfg.volumen_min) || 0,
      minimo: resumen?.minimo ?? null,
      keywords_relevantes: resumen?.keywords_relevantes ?? null,
      texto: resumen?.criterio ?? null,
      base: Object.fromEntries(Object.entries(BASE_DIRECTORIOS).map(([t, ds]) => [t, ds.filter((d) => !dc.quitados.includes(d))])),
      base_quitados: dc.quitados,
      directorios: dc.directorios
    },
    estimacion: {
      usd: usd(conLabs) + "\u2013" + usd(conSerp),
      usd_labs: usd(conLabs),
      usd_serp: usd(conSerp),
      segundos: "15\u201340",
      keywords: kwN,
      llamadas_labs: llamadasLabs,
      sugerencias_en_cache: sugEnCache,
      serp_en_cache: serpCache,
      serp_modo: precio.modo,
      serp_precio: usd(precio.usd),
      serp_precio_real: precio.real,
      texto: (sugEnCache ? "las sugerencias de tus semillas ya est\xE1n en la cach\xE9 (gratis)" : nSug + " consulta" + (nSug === 1 ? "" : "s") + " de Labs keyword_suggestions, una por semilla corta (hasta " + LIMITE_SUGERENCIAS + " b\xFAsquedas que contienen la semilla, " + usd(sugUsd) + ")") + ", " + llamadasLabs + " de Labs serp_competitors con hasta " + kwN + " keywords relevantes (" + huecosN + " huecos que pasan el filtro, " + cortas.length + " semillas cortas y las sugerencias que pasan el mismo filtro; " + usd(PRECIOS.labs_tarea) + " cada una m\xE1s " + usd(PRECIOS.labs_item) + " por dominio, hasta " + LIMITE_COMPETIDORES + ") y 1 de Labs bulk_traffic_estimation con los candidatos (" + usd(traficoUsd) + "); solo si Labs deja menos de " + MIN_PROPUESTOS + " propuestos, " + busquedas + " b\xFAsqueda" + (busquedas === 1 ? "" : "s") + " en Google (" + serpPrecioTxt(precio) + ", 4 a la vez" + (serpCache ? "; " + serpCache + " ya en la cach\xE9 de 3 d\xEDas: no se pagan" : "") + ") y otra de tr\xE1fico. Tarda unos 15\u201340 segundos"
    }
  };
}
async function adoptCompetitor(db, { id }) {
  const x = await db.one("SELECT * FROM " + CP + " WHERE _id = ? AND _deleted = 0", [id]);
  if (!x) throw new Refused("Ese dominio ya no est\xE1 en la lista.", 404);
  const cfg = await settings(db);
  const list3 = competitorsOf(cfg);
  if (!list3.includes(x.dominio)) await db.update(A, cfg._id, { competidores: [...list3, x.dominio].join("; ") });
  await db.update(CP, id, { estado: "adoptado", motivo: "A\xF1adido a Ajustes \u2192 Competidores" });
  return { id, dominio: x.dominio, competidores: [.../* @__PURE__ */ new Set([...list3, x.dominio])] };
}
var MAX_HUECOS = 6;
var MAX_LISTA = 200;
var DOMINIO = /^(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,24}$/;
function parseDomains(texto) {
  const dominios = [];
  const ignorados = [];
  const vistos = /* @__PURE__ */ new Set();
  for (const raw2 of String(texto ?? "").split(/[\s,;|"'<>()]+/)) {
    const t = raw2.trim();
    if (!t) continue;
    if (t.includes("@")) {
      ignorados.push(t);
      continue;
    }
    const d = domainOf2(t).replace(/\.$/, "");
    if (!DOMINIO.test(d)) {
      if (/\./.test(t)) ignorados.push(t);
      continue;
    }
    if (vistos.has(d)) continue;
    vistos.add(d);
    dominios.push(d);
  }
  return { dominios: dominios.slice(0, MAX_LISTA), ignorados: ignorados.slice(0, 20), cortada: dominios.length > MAX_LISTA };
}
async function importCompetitors(db, { lista: lista5, nunca } = {}) {
  const esNunca = nunca === true || nunca === "true" || nunca === 1;
  const p = parseDomains(lista5);
  const cfg = await settings(db);
  const propio = domainOf2(cfg.dominio);
  const nuevos = p.dominios.filter((d) => d !== propio);
  if (!nuevos.length) throw new Refused("En esa lista no hay ning\xFAn dominio (algo como \xABempresa.com\xBB, uno por l\xEDnea o separados por comas)" + (p.ignorados.length ? "; se ignor\xF3: " + p.ignorados.slice(0, 5).join(", ") : "") + ".", 400);
  const comps = competitorsOf(cfg);
  const nuncaYa = neverOf(cfg);
  const destino = esNunca ? nuncaYa : comps;
  const anadidos = nuevos.filter((d) => !destino.includes(d));
  const quita = new Set(nuevos);
  await db.update(A, cfg._id, esNunca ? { no_competidores: [...nuncaYa, ...anadidos].join("; "), competidores: comps.filter((d) => !quita.has(d)).join("; ") } : { competidores: [...comps, ...anadidos].join("; "), no_competidores: nuncaYa.filter((d) => !quita.has(d)).join("; ") });
  for (const x of await db.all("SELECT _id, dominio, estado FROM " + CP + " WHERE _deleted = 0")) {
    if (!quita.has(x.dominio)) continue;
    if (esNunca && x.estado !== "descartado") await db.update(CP, x._id, { estado: "descartado", filtro: "nunca", motivo: "Est\xE1 en tu lista \xABNunca son competidores\xBB" });
    if (!esNunca && x.estado !== "adoptado") await db.update(CP, x._id, { estado: "adoptado", filtro: null, motivo: "A\xF1adido a Ajustes \u2192 Competidores" });
  }
  const total = esNunca ? nuncaYa.length + anadidos.length : comps.length + anadidos.length;
  return {
    nunca: esNunca,
    anadidos,
    ya_estaban: nuevos.filter((d) => destino.includes(d)),
    ignorados: p.ignorados,
    propio_quitado: p.dominios.includes(propio),
    total,
    texto: (anadidos.length ? anadidos.length + (anadidos.length === 1 ? " dominio a\xF1adido" : " dominios a\xF1adidos") : "Ninguno nuevo") + (esNunca ? " a \xABNunca son competidores\xBB" : " a tus competidores") + " (" + total + " en total)" + (!esNunca && total > MAX_HUECOS ? ". \xABBuscar huecos\xBB compara con los " + MAX_HUECOS + " primeros de la lista: ord\xE9nalos en Ajustes \u2192 Competidores." : ".") + (p.ignorados.length ? " No eran dominios: " + p.ignorados.slice(0, 5).join(", ") + (p.ignorados.length > 5 ? "\u2026" : "") + "." : "")
  };
}
async function neverCompetitor(db, { id }) {
  const x = await db.one("SELECT dominio FROM " + CP + " WHERE _id = ? AND _deleted = 0", [id]);
  if (!x) throw new Refused("Ese dominio ya no est\xE1 en la lista.", 404);
  const r = await importCompetitors(db, { lista: x.dominio, nunca: true });
  return { id, dominio: x.dominio, nunca: true, total: r.total };
}

// server/services/ganabilidad.mjs
var domainOf3 = (u) => String(u || "").trim().toLowerCase().replace(/^https?:\/\//, "").replace(/^www\./, "").replace(/[/?#:].*$/, "");
var SEGUNDO = /* @__PURE__ */ new Set(["com", "co", "org", "net", "gob", "gov", "gouv", "govt", "edu", "ac", "mil", "nom", "or", "ne", "go"]);
function registrable(d) {
  const p = domainOf3(d).split(".").filter(Boolean);
  if (p.length <= 2) return p.join(".");
  const tld = p[p.length - 1], sld = p[p.length - 2];
  if (sld === "europa" && tld === "eu") return "europa.eu";
  return p.slice(tld.length === 2 && SEGUNDO.has(sld) ? -3 : -2).join(".");
}
var OFICIALES = [
  "agenciatributaria.es",
  "seg-social.es",
  "boe.es",
  "sepe.es",
  "ine.es",
  "bde.es",
  "cnmv.es",
  "aepd.es",
  "congreso.es",
  "senado.es",
  "poderjudicial.es",
  "lamoncloa.es",
  "incibe.es",
  "camara.es",
  "juntadeandalucia.es",
  "gencat.cat",
  "euskadi.eus",
  "xunta.gal",
  "gva.es",
  "comunidad.madrid",
  "madrid.es",
  "barcelona.cat",
  "who.int",
  "un.org",
  "oecd.org",
  "europa.eu"
];
function oficial(d) {
  const dom2 = domainOf3(d);
  if (/(^|\.)(gob|gov|gouv|govt|edu|mil|ac)(\.[a-z]{2})?$/.test(dom2) || /\.int$/.test(dom2)) return true;
  return OFICIALES.some((o) => dom2 === o || dom2.endsWith("." + o));
}
var FLOJO_ETV = 1e3;
var ETV_CACHE_HORAS = 168;
var MAX_DOMINIOS = 100;
var MAX_ETV_GUARDADOS = 3e3;
var NIVEL = { alta: 0.5, media: 0.3 };
var SIN_DATO_FACTOR = 0.5;
var NIVEL_TXT = { alta: "Se puede ganar", media: "Se puede pelear", baja: "Dif\xEDcil hoy" };
var conRegistrable = (dominios) => [...new Set((dominios ?? []).map(domainOf3).filter((d) => d && !isGoogle(d)).flatMap((d) => [d, registrable(d)]))];
var etvClave = (w) => "etv:" + w.location_code + ":" + w.language_code;
async function trafico2(db, keys, dominios, w, m) {
  const doms = conRegistrable(dominios).slice(0, MAX_DOMINIOS);
  const out = /* @__PURE__ */ new Map();
  if (!doms.length) return { etv: out, medido: false, pedidos: 0, cache: 0 };
  const c = db ? await cacheGet(db, etvClave(w)) : null;
  const guardado = c?.valor && typeof c.valor === "object" ? c.valor : {};
  const faltan = [];
  for (const d of doms) {
    const g = guardado[d];
    if (g && horasDesde(g.fecha) < ETV_CACHE_HORAS) out.set(d, { etv: g.etv, kws: g.kws ?? null });
    else faltan.push(d);
  }
  const cache = doms.length - faltan.length;
  if (!faltan.length) {
    if (m?.notas && cache) m.notas.push("tr\xE1fico de " + cache + " dominios de la cach\xE9");
    return { etv: out, medido: true, pedidos: 0, cache };
  }
  try {
    const bt = await dfs(keys, "dataforseo_labs/google/bulk_traffic_estimation/live", { targets: faltan, ...w, item_types: ["organic"] }, m);
    const fecha = ahora();
    const got = new Map((bt.items ?? []).map((it) => [domainOf3(it.target), { etv: Math.round(it.metrics?.organic?.etv ?? 0), kws: it.metrics?.organic?.count ?? null }]));
    for (const d of faltan) {
      const v = got.get(d) ?? { etv: 0, kws: 0 };
      out.set(d, v);
      guardado[d] = { ...v, fecha };
    }
    if (db) {
      const viejos = Object.entries(guardado).sort((a, b) => String(b[1].fecha).localeCompare(String(a[1].fecha))).slice(0, MAX_ETV_GUARDADOS);
      await cacheSet(db, etvClave(w), Object.fromEntries(viejos));
    }
    return { etv: out, medido: true, pedidos: faltan.length, cache };
  } catch (e) {
    if (e.status === 424 || e.status === 429) throw e;
    return { etv: out, medido: cache > 0, pedidos: 0, cache, error: e.message };
  }
}
var OPR_HOST = "openpagerank.keywordseverywhere.com";
var OPR_URL = "https://" + OPR_HOST + "/api/v1.0/getPageRank";
var OPR_CACHE_HORAS = 720;
var OPR_LOTE = 100;
var OPR_TIMEOUT_MS = 2e4;
var AUTORIDAD_FUERTE = 4;
var OPR_SIN_CLAVE = "Para medir tambi\xE9n la autoridad de cada web del top 10 (Open PageRank, gratis) falta su clave: p\xEDdele a tu agente que la a\xF1ada (module keys) o ponla en las claves del m\xF3dulo como \xABClave de Open PageRank\xBB; se consigue en keywordseverywhere.com/account/openpagerank. Sin ella, la fuerza del top 10 se mide solo con el tr\xE1fico estimado.";
var oprClave = "opr";
function leerOpr(j) {
  const lista5 = Array.isArray(j?.response) ? j.response : Array.isArray(j?.domains) ? j.domains : Array.isArray(j?.results) ? j.results : Array.isArray(j?.data) ? j.data : Array.isArray(j) ? j : [];
  const out = /* @__PURE__ */ new Map();
  for (const x of lista5) {
    const d = domainOf3(x?.domain);
    if (!d) continue;
    const no = x.found === false || x.status_code != null && Number(x.status_code) !== 200;
    const v = Number(x.page_rank_decimal ?? x.open_page_rank);
    out.set(d, no || !Number.isFinite(v) ? null : Math.round(v * 100) / 100);
  }
  return out;
}
async function autoridad(db, keys, dominios, m) {
  const doms = conRegistrable(dominios);
  const out = /* @__PURE__ */ new Map();
  if (!doms.length) return { opr: out, medido: false };
  const c = db ? await cacheGet(db, oprClave) : null;
  const guardado = c?.valor && typeof c.valor === "object" ? c.valor : {};
  const faltan = [];
  for (const d of doms) {
    const g = guardado[d];
    if (g && horasDesde(g.fecha) < OPR_CACHE_HORAS) out.set(d, g.v);
    else faltan.push(d);
  }
  if (!faltan.length) return { opr: out, medido: true, pedidos: 0 };
  try {
    const fecha = ahora();
    for (let i = 0; i < faltan.length; i += OPR_LOTE) {
      const lote = faltan.slice(i, i + OPR_LOTE);
      const r = await keys.fetch(OPR_URL + "?" + lote.map((d) => "domains%5B%5D=" + encodeURIComponent(d)).join("&"), { method: "GET", headers: { "API-OPR": "{{key:OPENPAGERANK_KEY}}", Accept: "application/json" }, timeoutMs: OPR_TIMEOUT_MS });
      if (r.status === 401 || r.status === 403) return { opr: out, medido: out.size > 0, aviso: "Open PageRank no acepta la clave (responde " + r.status + "): revisa \xABClave de Open PageRank\xBB en las claves del m\xF3dulo. Las claves gratuitas solo valen desde la direcci\xF3n IP con la que se crearon; si no es la de este servidor, hace falta una clave de pago o crearla desde aqu\xED." };
      if (r.status !== 200) return { opr: out, medido: out.size > 0, aviso: "Open PageRank respondi\xF3 " + r.status + ": la autoridad queda sin dato esta vez." };
      const got = leerOpr(r.json());
      for (const d of lote) {
        const v = got.has(d) ? got.get(d) : null;
        out.set(d, v);
        guardado[d] = { v, fecha };
      }
    }
    if (db) await cacheSet(db, oprClave, Object.fromEntries(Object.entries(guardado).sort((a, b) => String(b[1].fecha).localeCompare(String(a[1].fecha))).slice(0, MAX_ETV_GUARDADOS)));
    if (m?.notas) m.notas.push("autoridad de " + faltan.length + " dominios (Open PageRank, sin coste)");
    return { opr: out, medido: true, pedidos: faltan.length };
  } catch (e) {
    if (/not set|no est|withheld|missing|falta|not shared|no key|unknown key/i.test(String(e.message))) return { opr: out, medido: false, sin_clave: true, aviso: OPR_SIN_CLAVE };
    return { opr: out, medido: out.size > 0, aviso: "No se pudo leer la autoridad (Open PageRank: " + e.message + "): queda sin dato esta vez." };
  }
}
var KIND_TXT = { red_social: "red social", foro: "foro", hosting: "hosting o creador de webs", directorio: "directorio", medio: "medio o blog", institucion: "instituci\xF3n" };
function winnability(top10, { own = "", etv = /* @__PURE__ */ new Map(), cfg = {}, medido = true, opr = null } = {}) {
  const aut1 = (d) => opr && opr.has(d) && opr.get(d) != null ? opr.get(d) : null;
  const aut = (d) => {
    const a = aut1(d), b = aut1(registrable(d));
    return a == null ? b : b == null ? a : Math.max(a, b);
  };
  const tra = (d) => {
    const a = etv.get(d), b = etv.get(registrable(d));
    return !a ? b : !b ? a : (b.etv ?? 0) > (a.etv ?? 0) ? b : a;
  };
  const ctx = directoriosCtx(cfg);
  const mio = domainOf3(own);
  const resultados = (top10 ?? []).map((t) => {
    const d = domainOf3(t.dominio);
    const e = tra(d);
    const raiz = registrable(d);
    const esOficial = d !== mio && oficial(d);
    const k = d === mio || esOficial ? null : kindOf(d, ctx);
    const tipo = k && k.filtro === "institucion" ? null : k;
    const a = aut(d);
    const fuerteTr = e ? e.etv >= FLOJO_ETV : null, fuerteAu = a != null ? a >= AUTORIDAD_FUERTE : null;
    const clase = mio && d === mio ? "propio" : esOficial ? "fuerte" : tipo ? "portal" : fuerteTr == null && fuerteAu == null ? "sin_dato" : fuerteTr || fuerteAu ? "fuerte" : "pequeno";
    const cifras = [e ? miles(e.etv) + " visitas/mes estimadas" + (raiz !== d && e === etv.get(raiz) ? " de " + raiz : "") : "", a != null ? "autoridad " + miles(a, 1) + "/10" : ""].filter(Boolean).join(", ");
    const porque = clase === "propio" ? "tu propia web" : clase === "portal" ? (KIND_TXT[tipo.filtro] || "portal") + (cifras ? " (" + cifras + ")" : "") : clase === "pequeno" ? "web peque\xF1a: " + cifras : esOficial ? "instituci\xF3n oficial: fuerte aunque esa direcci\xF3n tenga poco tr\xE1fico" + (cifras ? " (" + cifras + ")" : "") : clase === "fuerte" ? cifras : "sin dato de tr\xE1fico";
    return { ...t, etv: e?.etv ?? null, autoridad: a, clase, tipo: esOficial ? "oficial" : tipo?.filtro ?? null, flojo: clase === "propio" ? false : clase === "sin_dato" ? null : clase !== "fuerte", porque };
  });
  const rivales = resultados.filter((r) => r.clase !== "propio");
  const n = (c) => rivales.filter((r) => r.clase === c).length;
  const pequenos = n("pequeno"), portales = n("portal"), fuertes = n("fuerte"), sin_dato = n("sin_dato");
  const algoMedido = medido || portales > 0 || pequenos + fuertes > 0;
  const flojos = algoMedido && rivales.length ? pequenos + portales : null;
  const propio = resultados.find((r) => r.clase === "propio") ?? null;
  const parte = flojos == null ? null : flojos / rivales.length;
  const nivel = parte == null ? null : parte >= NIVEL.alta ? "alta" : parte >= NIVEL.media ? "media" : "baja";
  const lista5 = (l) => l.slice(0, 4).map((r) => r.dominio + " #" + r.pos).join(", ");
  const mas = [...rivales.filter((r) => r.clase === "fuerte")].sort((a, b) => a.pos - b.pos)[0];
  const plural2 = (k, uno, varios) => k + " " + (k === 1 ? uno : varios);
  const conAut = rivales.filter((r) => r.autoridad != null);
  const media = conAut.length ? Math.round(conAut.reduce((x, r) => x + r.autoridad, 0) / conAut.length * 10) / 10 : null;
  const autoridadTxt = media == null ? "" : " " + (media < AUTORIDAD_FUERTE ? "El top 10 son webs peque\xF1as" : "El top 10 tiene webs con autoridad") + ": autoridad media " + miles(media, 1) + "/10" + (conAut.length < rivales.length ? " (" + conAut.length + " de " + rivales.length + " medidas)" : "") + ".";
  const texto = flojos == null ? "No se pudo medir la fuerza del top 10 (sin dato de tr\xE1fico de sus dominios)." + autoridadTxt : NIVEL_TXT[nivel] + ": " + flojos + " de los " + rivales.length + " resultados que hoy salen son flojos" + (flojos ? " (" + [pequenos ? plural2(pequenos, "web peque\xF1a", "webs peque\xF1as") + ", con menos de " + miles(FLOJO_ETV) + " visitas/mes estimadas" + (conAut.length ? " y autoridad bajo " + AUTORIDAD_FUERTE : "") : "", portales ? plural2(portales, "foro, directorio o medio", "foros, directorios o medios") : ""].filter(Boolean).join(", y ") + ": " + lista5(rivales.filter((r) => r.flojo)) + ")" : "") + "." + (sin_dato ? " " + plural2(sin_dato, "resultado", "resultados") + " sin dato de tr\xE1fico." : "") + (mas ? " El m\xE1s fuerte: " + mas.dominio + " #" + mas.pos + " (" + (mas.tipo === "oficial" ? "instituci\xF3n oficial" : miles(mas.etv) + " visitas/mes") + ")." : fuertes ? "" : " Ninguno es una web grande.") + (propio ? " Tu web ya sale en la posici\xF3n " + propio.pos + "." : "") + autoridadTxt;
  return { resultados, autoridad_media: media, autoridad_medidos: conAut.length, total: rivales.length, flojos, pequenos, portales, fuertes, sin_dato, propia_posicion: propio?.pos ?? null, parte, nivel, texto };
}
function difficultyFactor({ dificultad, flojos = null, total = null } = {}) {
  if (flojos != null && total) return 0.25 + 0.75 * (Number(flojos) / Number(total));
  const kd = kdOf(dificultad);
  return kd == null ? SIN_DATO_FACTOR : (1 - kd / 100) ** 2;
}
var kdTxt = (v) => {
  const kd = kdOf(v);
  return kd == null ? "dificultad sin dato" : "KD " + kd;
};

// server/services/oportunidades.mjs
var T = "oportunidadesseo_oportunidades";
var A = "oportunidadesseo_ajustes";
var K = "oportunidadesseo_tipos";
var P = "oportunidadesseo_paginas";
var H = "oportunidadesseo_huecos";
var C = "oportunidadesseo_consultas";
var Q = "oportunidadesseo_casi";
var INTENT = { comercial: 1.3, transaccional: 1.3, informacional: 1, navegacional: 0.5 };
var parse = (v, d = null) => {
  if (v == null || v === "") return d;
  if (typeof v !== "string") return v;
  try {
    return JSON.parse(v);
  } catch {
    return d;
  }
};
var json = (v) => JSON.stringify(v);
var list = (s) => String(s ?? "").split(/[;\n]/).map((x) => x.trim()).filter(Boolean);
var now4 = () => (/* @__PURE__ */ new Date()).toISOString().slice(0, 19).replace("T", " ");
function score({ volumen, dificultad, intencion, potencial, ganabilidad }) {
  const v = Number(potencial || volumen || 0);
  if (!v) return 0;
  const g = parse(ganabilidad, null);
  return Math.round(v * difficultyFactor({ dificultad, flojos: g?.flojos ?? null, total: g?.total ?? null }) * (INTENT[intencion] ?? 1));
}
var priorityOf = (s) => s >= 800 ? "alta" : s >= 300 ? "media" : "baja";
async function get(db, id) {
  const row = await db.one("SELECT * FROM " + T + " WHERE _id = ? AND _deleted = 0", [id]);
  if (!row) throw new Refused("Esa oportunidad ya no est\xE1.", 404);
  return row;
}
async function settings(db) {
  const row = await db.one("SELECT * FROM " + A + " WHERE _deleted = 0 ORDER BY _id LIMIT 1");
  if (row) return row;
  const id = await db.insert(A, { ...SEMILLA_AJUSTES });
  return await db.one("SELECT * FROM " + A + " WHERE _id = ?", [id]) ?? { ...SEMILLA_AJUSTES, _id: id };
}
var domainOf2 = (u) => String(u || "").trim().toLowerCase().replace(/^https?:\/\//, "").replace(/^www\./, "").replace(/[/?#].*$/, "");
var neverOf = (cfg) => [...new Set(list(cfg.no_competidores).map(domainOf2).filter(Boolean))];
var competitorsOf = (cfg) => {
  const nunca = new Set(neverOf(cfg));
  return [...new Set(list(cfg.competidores).map(domainOf2).filter(Boolean))].filter((d) => !nunca.has(d));
};
var dominio = (cfg) => domainOf2(cfg.dominio);
function needDomain2(cfg) {
  const d = dominio(cfg);
  if (!d) throw new Refused("Falta el dominio en Ajustes (General \u2192 Dominio).", 400);
  return d;
}
var contexto = (cfg) => ({
  dominio: dominio(cfg) || null,
  mercado: cfg.mercado || null,
  publico: cfg.publico || null,
  idioma: cfg.idioma || null,
  ubicacion: cfg.ubicacion ?? null,
  competidores: competitorsOf(cfg),
  ruta_blog: cfg.ruta_blog || "/blog/",
  sincronizado: cfg.sincronizado ?? null,
  modo: modoOf(cfg)
});
var MODOS_RADAR = ["producto", "publico", "ambos"];
var modoOf = (cfg) => MODOS_RADAR.includes(String(cfg?.modo || "").trim()) ? String(cfg.modo).trim() : "ambos";
var isOwnPage = (url, cfg) => {
  const u = String(url || "").trim();
  const d = dominio(cfg);
  return /^https?:\/\//i.test(u) ? !!d && domainOf2(u) === d : u.startsWith("/");
};
async function rescore(db, { id }) {
  const row = await get(db, id);
  const puntuacion = score(row);
  await db.update(T, id, { puntuacion, prioridad: priorityOf(puntuacion), ...row.estado ? {} : { estado: "propuesta" } });
  return { id, puntuacion, prioridad: priorityOf(puntuacion) };
}
function defaultBrief(row, tipo, cfg = {}) {
  const d = dominio(cfg);
  const lugar = [cfg.mercado, cfg.idioma ? "idioma " + cfg.idioma : ""].filter(Boolean).join(", ");
  const lines2 = [
    "Keyword principal" + (lugar ? " (" + lugar + ")" : "") + ": " + row.keyword + ".",
    row.secundarias ? "Secundarias: " + list(row.secundarias).join(", ") + "." : "",
    tipo ? "Tipo: " + tipo.label + "." : "",
    row.lectora || cfg.publico ? "Para: " + (row.lectora || cfg.publico) + (/[.!?]$/.test(row.lectora || cfg.publico) ? "" : ".") : "",
    cfg.publico && row.lectora && row.lectora !== cfg.publico ? "P\xFAblico del sitio (Ajustes): " + cfg.publico : "",
    row.angulo ? "\xC1ngulo: " + row.angulo : "",
    row.competencia ? "Qu\xE9 cubre ya la competencia (contexto, no m\xE1s de un tercio del texto): " + row.competencia : "",
    row.puente ? "Puente a lo que vendemos (c\xF3mo este art\xEDculo lleva al lector hasta ah\xED; el cierre y la llamada a la acci\xF3n salen de aqu\xED): " + row.puente : "",
    row.fuentes ? "Fuentes de partida: " + list(row.fuentes).join(" \xB7 ") : "",
    row.cubierto ? "Ya en " + (d || "el sitio") + ", no duplicar y enlazar: " + row.cubierto : "",
    row.ganable_por ? "Por qu\xE9 se puede ganar: " + row.ganable_por : "",
    row.origen === "ejemplo" ? "Ojo: es una oportunidad de ejemplo, sin cifras reales." : row.origen === "estimacion" || !row.origen ? "Ojo: volumen y dificultad no vienen de DataForSEO: sin verificar." : ""
  ];
  return lines2.filter(Boolean).join("\n");
}
function outlineMaterial(row) {
  const m = parse(row.preguntas, null) ?? {};
  const serp = (parse(row.serp, []) ?? []).filter((x) => x?.titulo && row.serp_origen !== "ejemplo");
  const out = [];
  if (m.preguntas?.length) out.push("Preguntas que Google ense\xF1a para \xAB" + row.keyword + "\xBB (resp\xF3ndelas en el art\xEDculo, cada una puede ser un apartado):", ...m.preguntas.map((q) => "- " + q));
  if (m.relacionadas?.length) out.push("B\xFAsquedas relacionadas que Google sugiere:", ...m.relacionadas.map((q) => "- " + q));
  if (serp.length) out.push("T\xEDtulos del top 10 de hoy (lo que ya existe: no lo repitas, sup\xE9ralo):", ...serp.slice(0, 10).map((x) => "- #" + x.pos + " " + x.dominio + ": " + x.titulo));
  return out.join("\n");
}
var MARCA_MATERIAL = "Material para el esquema";
function fullBrief(row, tipo, cfg) {
  const brief = String(row.brief ?? "").trim() || defaultBrief(row, tipo, cfg);
  const material = outlineMaterial(row);
  return !material || brief.includes(MARCA_MATERIAL) ? brief : brief + "\n\n" + MARCA_MATERIAL + " (" + (parse(row.preguntas, null)?.fecha ? "Google, " + String(parse(row.preguntas).fecha).slice(0, 10) : "Google") + "):\n" + material;
}
async function saveBrief(db, { id, brief }) {
  await get(db, id);
  await db.update(T, id, { brief: String(brief ?? "") });
  return { id, saved: true };
}
async function syncArticles(db, { tipos, paginas: paginas2, completo = true }) {
  const ts = parse(tipos, []) ?? [], ps = parse(paginas2, []) ?? [];
  if (!Array.isArray(ts) || !Array.isArray(ps)) throw new Refused("tipos y paginas son listas.", 400);
  const nowKeys = /* @__PURE__ */ new Set();
  for (const t of ts) {
    if (!t?.key) continue;
    nowKeys.add(t.key);
    const ex = await db.one("SELECT _id FROM " + K + " WHERE key = ? AND _deleted = 0", [t.key]);
    const data = { key: t.key, label: t.label || t.key, description: t.description ?? "", activo: t.archived ? 0 : 1 };
    if (ex) await db.update(K, ex._id, data);
    else await db.insert(K, data);
  }
  if (ts.length) {
    for (const r of await db.all("SELECT _id, key FROM " + K + " WHERE _deleted = 0")) if (!nowKeys.has(r.key)) await db.update(K, r._id, { activo: 0 });
  }
  const urls = /* @__PURE__ */ new Set();
  for (const p of ps) {
    if (!p?.url) continue;
    urls.add(p.url);
    const ex = await db.one("SELECT _id FROM " + P + " WHERE url = ? AND _deleted = 0", [p.url]);
    const data = { url: p.url, titulo: p.titulo || p.url, clase: p.clase === "articulo" ? "articulo" : "pagina", keyword: p.keyword ?? "", estado: p.estado ?? "", activa: 1 };
    if (ex) await db.update(P, ex._id, data);
    else await db.insert(P, data);
  }
  if (ps.length && completo) {
    for (const r of await db.all("SELECT _id, url FROM " + P + " WHERE _deleted = 0")) if (!urls.has(r.url)) await db.update(P, r._id, { activa: 0 });
  }
  const cfg = await settings(db);
  let otro_dominio = 0;
  for (const r of await db.all("SELECT _id, url FROM " + P + " WHERE _deleted = 0 AND activa = 1")) if (!isOwnPage(r.url, cfg)) {
    await db.update(P, r._id, { activa: 0 });
    otro_dominio++;
  }
  if (cfg._id) await db.update(A, cfg._id, { sincronizado: now4() });
  const casi = await reclassify(db);
  return { tipos: nowKeys.size, paginas: urls.size, otro_dominio, casi_reclasificadas: casi };
}
var pathOf = (u) => {
  let s = String(u || "").trim().replace(/^https?:\/\/[^/]+/i, "").split(/[?#]/)[0];
  if (!s.startsWith("/")) s = "/" + s;
  if (!s.endsWith("/")) s += "/";
  return s.toLowerCase();
};
function classify(url, pages, cfg = {}) {
  const p = pathOf(url);
  const hit = pages.find((x) => isOwnPage(x.url, cfg) && pathOf(x.url) === p);
  if (hit && hit.clase === "articulo") return { propuesta: "actualizar", criterio: "Es un art\xEDculo en Art\xEDculos" + (hit.titulo && hit.titulo !== hit.url ? ": \xAB" + hit.titulo + "\xBB" : "") };
  if (hit) return { propuesta: "nuevo", criterio: "Es una p\xE1gina del sitio, no un art\xEDculo: mejor un art\xEDculo nuevo que la apoye y enlace a ella" };
  const blog = pathOf(cfg.ruta_blog || "/blog/");
  if (blog !== "/" && p.startsWith(blog) && p.length > blog.length) return { propuesta: "actualizar", criterio: "Su direcci\xF3n cuelga de " + blog + " (a\xFAn sin confirmar en Art\xEDculos)" };
  return { propuesta: "nuevo", criterio: "No es un art\xEDculo del blog" };
}
var activePages = async (db, cfg) => {
  const c = cfg ?? await settings(db);
  return (await db.all("SELECT url, titulo, clase FROM " + P + " WHERE _deleted = 0 AND activa = 1")).filter((x) => isOwnPage(x.url, c));
};
async function reclassify(db) {
  const cfg = await settings(db);
  const pages = await activePages(db, cfg);
  let n = 0;
  for (const r of await db.all("SELECT _id, url, propuesta, criterio FROM " + Q + " WHERE _deleted = 0")) {
    const c = classify(r.url, pages, cfg);
    if (c.propuesta !== r.propuesta || c.criterio !== r.criterio) {
      await db.update(Q, r._id, c);
      n++;
    }
  }
  return n;
}
async function radar(db) {
  const rows = await db.all("SELECT o._id AS id, o.tema, o.keyword, o.volumen, o.dificultad, o.potencial, o.intencion, o.cluster, o.prioridad, o.puntuacion, o.estado, o.origen, o.serp_origen, o.huecos, o.tipo, o.articulo, o.nivel, o.formato, o.fase, t.label AS tipo_label, t.key AS tipo_key FROM " + T + " o LEFT JOIN " + K + " t ON t._id = o.tipo AND t._deleted = 0 WHERE o._deleted = 0 ORDER BY o.puntuacion DESC");
  const tipos = await db.all("SELECT _id AS id, key, label, activo FROM " + K + " WHERE _deleted = 0 ORDER BY _id");
  const cfg = await settings(db);
  const allGaps = (await db.all("SELECT _id AS id, keyword, volumen, dificultad, intencion, competidores, mejor_posicion, estado, origen, oportunidad, ganable, relevancia, por_que, semilla, variantes FROM " + H + " WHERE _deleted = 0 AND (estado IS NULL OR estado != 'filtrado') ORDER BY ganable DESC, volumen DESC")).map((g) => ({ ...g, dificultad: kdOf(g.dificultad) }));
  const realGaps = allGaps.filter((g) => g.origen !== "ejemplo");
  const gapsReal = !!cfg.huecos_buscados || realGaps.length > 0;
  const allQ = await db.all("SELECT _id AS id, consulta, pagina, clics, impresiones, ctr, posicion, desde, hasta, origen FROM " + C + " WHERE _deleted = 0 ORDER BY impresiones DESC");
  const realQ = ultimoPeriodo(allQ.filter((q) => q.origen !== "ejemplo"));
  const pages = await activePages(db, cfg);
  const allCasi = (await db.all("SELECT _id AS id, keyword, posicion, volumen, dificultad, intencion, url, estado, origen, oportunidad FROM " + Q + " WHERE _deleted = 0 ORDER BY volumen DESC")).map((c) => ({ ...c, ruta: pathOf(c.url), ...classify(c.url, pages, cfg) }));
  const realCasi = allCasi.filter((c) => c.origen !== "ejemplo");
  const casiReal = !!cfg.casi_buscados || realCasi.length > 0;
  return {
    rows: rows.map((r) => ({ ...r, dificultad: kdOf(r.dificultad), huecos: parse(r.huecos, []) })),
    tipos,
    ...contexto(cfg),
    brechas: gapsReal ? realGaps : allGaps,
    brechas_origen: gapsReal ? "dataforseo" : allGaps.length ? "ejemplo" : null,
    huecos_buscados: cfg.huecos_buscados ?? null,
    casi: casiReal ? realCasi : allCasi,
    casi_origen: casiReal ? "dataforseo" : allCasi.length ? "ejemplo" : null,
    casi_buscados: cfg.casi_buscados ?? null,
    consultas: realQ.length ? realQ : allQ,
    consultas_origen: realQ.length ? "search_console" : allQ.length ? "ejemplo" : null
  };
}
var STOP2 = ["with", "from", "that", "your", "para", "como", "what", "sobre", "desde", "entre"];
var words = (s) => String(s ?? "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").split(/[^a-z0-9ñ]+/).filter((w) => w.length > 3 && !STOP2.includes(w));
function fuenteLimpia(line) {
  const s = String(line ?? "");
  const dom2 = (/#\d+\s+([a-z0-9.-]+\.[a-z]{2,})\s*:/i.exec(s) || [])[1] ?? null;
  return s.replace(/https?:\/\/\S+/g, (u) => urlLimpia(u, dom2) ?? (dom2 ? "https://" + dom2 + "/" : u));
}
async function detail(db, { id }) {
  const row = await get(db, id);
  const tipo = row.tipo ? await db.one("SELECT _id AS id, key, label, description FROM " + K + " WHERE _id = ?", [row.tipo]) : null;
  const kw = /* @__PURE__ */ new Set([...words(row.keyword), ...words(row.secundarias)]);
  const cfg = await settings(db);
  const pages = (await db.all("SELECT url, titulo, clase, keyword, estado FROM " + P + " WHERE _deleted = 0 AND activa = 1")).filter((p) => isOwnPage(p.url, cfg));
  const related = pages.map((p) => ({ ...p, hits: words(p.url + " " + p.titulo + " " + p.keyword).filter((w) => kw.has(w)).length })).filter((p) => p.hits > 0).sort((a, b) => b.hits - a.hits).slice(0, 8);
  const own = dominio(cfg);
  const serp = (parse(row.serp, []) ?? []).map((x) => ({ ...x, url: urlLimpia(x.url, x.dominio) }));
  const gan = parse(row.ganabilidad, null);
  const material = parse(row.preguntas, null);
  return {
    ...row,
    id: row._id,
    dificultad: kdOf(row.dificultad),
    tipo,
    ganabilidad: gan,
    preguntas: material?.preguntas ?? [],
    busquedas_relacionadas: material?.relacionadas ?? [],
    material_fecha: material?.fecha ?? null,
    material_esquema: outlineMaterial(row),
    brief_completo: fullBrief(row, tipo, cfg),
    keywords: (parse(row.keywords, []) ?? []).map((k) => ({ ...k, dificultad: kdOf(k.dificultad) })),
    serp,
    huecos: parse(row.huecos, []).map((h) => ({ ...h, propio: !!h.propio })),
    // a source stored by an earlier version may carry a google.com/goto link: shown as the real page, or the site
    fuentes_list: list(row.fuentes).map(fuenteLimpia),
    relacionadas: related,
    consultas: await queriesFor(db, kw),
    propia_posicion: own ? (serp.find((x) => domainOf2(x.dominio || x.url) === own) || {}).pos ?? null : null,
    serp_cache: await serpCacheDe(db, row, cfg),
    brief_sugerido: defaultBrief(row, tipo, cfg),
    ...contexto(cfg),
    // the kinds a person may choose from before the draft exists; left empty, the agent that drafts chooses
    tipos: await db.all("SELECT _id AS id, key, label, description FROM " + K + " WHERE _deleted = 0 AND activo = 1 ORDER BY label")
  };
}
async function serpCacheDe(db, row, cfg) {
  if (row.serp_origen !== "dataforseo" || !row.keyword) return null;
  let w;
  try {
    w = where(cfg);
  } catch {
    return null;
  }
  const c = (await serpEnCache(db, [row.keyword], w, { modo: MODO_OPORTUNIDAD })).get(String(row.keyword).trim());
  return c ? { horas: Math.floor(c.horas), fecha: c.fecha, texto: serpEdadTxt(c) } : { horas: null, fecha: null, texto: "top 10 de hace m\xE1s de 3 d\xEDas: \xABTraer datos\xBB lo vuelve a pedir" };
}
async function fromAhrefs(db, { id }, keys = keysClient()) {
  const row = await get(db, id);
  const cfg = await settings(db);
  const country = String(cfg.pais || "").trim().toLowerCase();
  if (!country) throw new Refused("Falta el c\xF3digo de pa\xEDs en Ajustes (General \u2192 C\xF3digo de pa\xEDs).", 400);
  const auth = { Authorization: "Bearer {{key:AHREFS_API_KEY}}", Accept: "application/json" };
  const kws = [row.keyword, ...list(row.secundarias)];
  const r = await keys.fetch("https://api.ahrefs.com/v3/keywords-explorer/overview?select=keyword,volume,difficulty,traffic_potential&country=" + country + "&keywords=" + encodeURIComponent(kws.join(",")), { headers: auth });
  if (r.status !== 200) throw new Refused("Ahrefs respondi\xF3 " + r.status + ".", 502);
  const got = r.json()?.keywords ?? [];
  const main = got.find((k) => k.keyword?.toLowerCase() === row.keyword.toLowerCase()) ?? got[0];
  if (!main) throw new Refused("Ahrefs no tiene datos para esa keyword.", 404);
  const keywords = kws.map((k, i) => {
    const g = got.find((x) => x.keyword?.toLowerCase() === k.toLowerCase());
    return { keyword: k, volumen: g?.volume ?? null, dificultad: kdOf(g?.difficulty), principal: i === 0 };
  });
  const data = { volumen: main.volume ?? null, dificultad: kdOf(main.difficulty), potencial: main.traffic_potential ?? null, origen: "ahrefs", keywords: json(keywords) };
  const s = await keys.fetch("https://api.ahrefs.com/v3/serp-overview/serp-overview?select=position,url,title,domain_rating,traffic&country=" + country + "&keyword=" + encodeURIComponent(row.keyword), { headers: auth });
  if (s.status === 200) {
    const pos = (s.json()?.positions ?? []).filter((p) => p.url).slice(0, 10);
    const serp = pos.map((p, i) => ({ pos: p.position ?? i + 1, url: p.url, dominio: domainOf2(p.url), titulo: p.title ?? "", dr: p.domain_rating ?? null, trafico: p.traffic ?? null, cubre: [] }));
    data.serp = json(serp);
    data.serp_origen = "ahrefs";
    data.huecos = json([]);
  }
  const puntuacion = score({ ...row, ...data });
  await db.update(T, id, { ...data, puntuacion, prioridad: priorityOf(puntuacion) });
  return { id, volumen: data.volumen, dificultad: data.dificultad, potencial: data.potencial, serp: data.serp ? parse(data.serp).length : 0, puntuacion };
}
async function saveResearch(db, { id, serp, huecos }) {
  const row = await get(db, id);
  const data = {};
  if (serp !== void 0) {
    const s = parse(serp);
    if (!Array.isArray(s)) throw new Refused("serp es una lista.", 400);
    data.serp = json(s);
  }
  if (huecos !== void 0) {
    const h = parse(huecos);
    if (!Array.isArray(h)) throw new Refused("huecos es una lista.", 400);
    data.huecos = json(h.map((x) => ({ ...x, propio: !!x?.propio })));
  }
  data.serp_origen = ["ahrefs", "dataforseo"].includes(row.serp_origen) && serp === void 0 ? row.serp_origen : "agente";
  await db.update(T, id, data);
  return { id, saved: Object.keys(data) };
}
var MODO_OPORTUNIDAD = "advanced";
async function fromDataForSEO(db, { id, forzar } = {}, keys = keysClient()) {
  return withMeter(db, "datos_dataforseo", (m) => dataForSEO(db, id, keys, m, forzar === true || forzar === "true" || forzar === 1));
}
async function dataForSEO(db, id, keys, m, forzar = false) {
  const row = await get(db, id);
  const cfg = await settings(db);
  const w = where(cfg);
  const kws = [row.keyword, ...list(row.secundarias)].slice(0, 20);
  const [ov, res] = await Promise.all([
    dfs(keys, "dataforseo_labs/google/keyword_overview/live", { keywords: kws, ...w }, m),
    serpBatch(keys, [row.keyword], w, m, { db, forzar, modo: MODO_OPORTUNIDAD })
  ]);
  const items = ov.items ?? [];
  const find = (k) => items.find((x) => String(x.keyword).toLowerCase() === k.toLowerCase());
  const keywords = kws.map((k, i) => {
    const g = find(k);
    return { keyword: k, volumen: g?.keyword_info?.search_volume ?? null, dificultad: kdOf(g?.keyword_properties?.keyword_difficulty), principal: i === 0 };
  });
  const main = find(row.keyword);
  if (!main) throw new Refused("DataForSEO no tiene datos de \xAB" + row.keyword + "\xBB en " + (cfg.mercado || "esa ubicaci\xF3n") + ".", 404);
  const sum = keywords.reduce((a, k) => a + (Number(k.volumen) || 0), 0);
  const data = {
    volumen: main.keyword_info?.search_volume ?? null,
    dificultad: kdOf(main.keyword_properties?.keyword_difficulty),
    potencial: sum || null,
    intencion: intentOf(main.search_intent_info?.main_intent) ?? row.intencion ?? null,
    origen: "dataforseo",
    keywords: json(keywords)
  };
  const sr = res.get(String(row.keyword).trim());
  if (sr?.error) throw new Refused("No se pudo leer el top 10 de \xAB" + row.keyword + "\xBB: " + sr.error, 502);
  const old = parse(row.serp, []) ?? [];
  const o = organicTop(sr.items, { n: 10 });
  const own = dominio(cfg);
  const rivales = o.validos.map((x) => x.dominio).filter((d) => d !== own);
  const [tr, au] = o.validos.length ? await Promise.all([trafico2(db, keys, rivales, w, m), autoridad(db, keys, rivales, m)]) : [{ etv: /* @__PURE__ */ new Map(), medido: false }, { opr: /* @__PURE__ */ new Map(), medido: false }];
  const gan = o.fiable ? winnability(o.validos, { own, etv: tr.etv, cfg, medido: tr.medido, opr: au.opr }) : null;
  const serp = (gan?.resultados ?? o.validos).map((x) => {
    const prev = old.find((p) => p.url === x.url) ?? old.find((p) => p.dominio === x.dominio);
    return { pos: x.pos, url: x.url, dominio: x.dominio, titulo: x.titulo, fuente: x.fuente, dr: null, trafico: x.etv ?? null, autoridad: x.autoridad ?? null, clase: x.clase ?? null, porque: x.porque ?? null, cubre: prev?.cubre ?? [] };
  });
  data.serp = json(serp);
  data.serp_origen = "dataforseo";
  if (row.serp_origen === "ejemplo") data.huecos = json([]);
  const material = materialDe(sr.items);
  data.preguntas = json({ ...material, fecha: sr.fecha ?? now4() });
  data.ganabilidad = gan ? json({ flojos: gan.flojos, total: gan.total, pequenos: gan.pequenos, portales: gan.portales, fuertes: gan.fuertes, sin_dato: gan.sin_dato, propia_posicion: gan.propia_posicion, nivel: gan.nivel, autoridad_media: gan.autoridad_media, autoridad_medidos: gan.autoridad_medidos, fecha: now4() }) : null;
  data.nivel = gan?.nivel ?? null;
  data.ganable_por = gan ? gan.texto : "No se pudo medir: Google ense\xF1a menos de 5 resultados que sean webs para esta b\xFAsqueda (fichas, mapas o enlaces suyos).";
  const puntuacion = score({ ...row, ...data });
  await db.update(T, id, { ...data, puntuacion, prioridad: priorityOf(puntuacion) });
  return {
    id,
    volumen: data.volumen,
    dificultad: data.dificultad,
    dificultad_txt: data.dificultad == null ? "sin dato" : String(data.dificultad),
    potencial: data.potencial,
    top10: serp.length,
    se_puede_ganar: gan?.nivel ?? null,
    por_que: data.ganable_por,
    autoridad_media: gan?.autoridad_media ?? null,
    preguntas: material.preguntas.length,
    puntuacion,
    top10_origen: serpEdadTxt(sr),
    ...au.aviso ? { avisos: [au.aviso] } : {}
  };
}
var formatoDe = (intencion) => intencion === "comercial" || intencion === "transaccional" ? "servicio" : "articulo";
async function gapToOpportunity(db, { id }) {
  const g = await db.one("SELECT * FROM " + H + " WHERE _id = ? AND _deleted = 0", [id]);
  if (!g) throw new Refused("Ese hueco ya no est\xE1.", 404);
  if (g.estado === "convertido" && g.oportunidad) throw new Refused("Ya es la oportunidad n\xBA " + g.oportunidad + ".");
  const cfg = await settings(db);
  const ex = await db.one("SELECT _id FROM " + T + " WHERE lower(keyword) = lower(?) AND _deleted = 0", [g.keyword]);
  let op = ex?._id;
  if (!op) {
    const data = { tema: temaDe(g.keyword), keyword: g.keyword, secundarias: g.variantes || null, cluster: g.semilla || null, volumen: g.volumen, dificultad: kdOf(g.dificultad), intencion: g.intencion, formato: formatoDe(g.intencion), estado: "propuesta", origen: g.origen === "ejemplo" ? "ejemplo" : "dataforseo", lectora: cfg.publico || null, competencia: "Posicionan y " + (dominio(cfg) || "el sitio") + " no: " + (g.competidores || "\u2014") + "." };
    const puntuacion = score(data);
    op = await db.insert(T, { ...data, puntuacion, prioridad: priorityOf(puntuacion) });
  }
  await db.update(H, id, { estado: "convertido", oportunidad: op });
  return { id, oportunidad: op };
}
var CASI_DESDE = 8;
var CASI_HASTA = 20;
var CASI_MAX = 500;
var CASI_PAGINA = 250;
async function findAlmost(db, _i, keys = keysClient()) {
  return withMeter(db, "buscar_casi", (m) => almost(db, keys, m));
}
async function almost(db, keys, m) {
  const cfg = await settings(db);
  const dom2 = needDomain2(cfg);
  const w = where(cfg);
  const r = await dfsPaginas(keys, "dataforseo_labs/google/ranked_keywords/live", {
    target: dom2,
    ...w,
    item_types: ["organic"],
    load_rank_absolute: false,
    filters: [["ranked_serp_element.serp_item.rank_group", ">=", CASI_DESDE], "and", ["ranked_serp_element.serp_item.rank_group", "<=", CASI_HASTA]],
    order_by: ["keyword_data.keyword_info.search_volume,desc"]
  }, m, { total: CASI_MAX, pagina: CASI_PAGINA, recordar: paginaRecordada(db) });
  const byKw = /* @__PURE__ */ new Map();
  for (const it of r.items ?? []) {
    const kd = it.keyword_data ?? {}, s = it.ranked_serp_element?.serp_item ?? {};
    const keyword = String(kd.keyword || "").toLowerCase();
    const posicion = Number(s.rank_group);
    if (!keyword || !s.url || !(posicion >= CASI_DESDE && posicion <= CASI_HASTA)) continue;
    const prev = byKw.get(keyword);
    if (prev && prev.posicion <= posicion) continue;
    byKw.set(keyword, { keyword, posicion, url: s.url, volumen: kd.keyword_info?.search_volume ?? null, dificultad: kdOf(kd.keyword_properties?.keyword_difficulty), intencion: intentOf(kd.search_intent_info?.main_intent) });
  }
  const pages = await activePages(db, cfg);
  let nuevas = 0, actualizadas = 0, fuera = 0;
  for (const k of byKw.values()) {
    const data = { ...k, ...classify(k.url, pages, cfg), origen: "dataforseo" };
    const ex = await db.one("SELECT _id, estado FROM " + Q + " WHERE keyword = ? AND origen = 'dataforseo' AND _deleted = 0", [k.keyword]);
    if (ex) {
      await db.update(Q, ex._id, { ...data, ...ex.estado === "fuera" ? { estado: "nueva" } : {} });
      actualizadas++;
    } else {
      await db.insert(Q, { ...data, estado: "nueva" });
      nuevas++;
    }
  }
  for (const x of await db.all("SELECT _id, keyword, estado FROM " + Q + " WHERE origen = 'dataforseo' AND _deleted = 0")) {
    if (!byKw.has(x.keyword) && x.estado === "nueva") {
      await db.update(Q, x._id, { estado: "fuera" });
      fuera++;
    }
  }
  await db.update(A, cfg._id, { casi_buscados: now4() });
  const all = [...byKw.values()].map((k) => classify(k.url, pages, cfg).propuesta);
  return { dominio: dom2, keywords: byKw.size, nuevas, actualizadas, fuera, actualizar: all.filter((p) => p === "actualizar").length, escribir_nuevo: all.filter((p) => p === "nuevo").length, ...r.avisos.length ? { avisos: r.avisos } : {} };
}
async function almostList(db) {
  const cfg = await settings(db);
  const pages = await activePages(db, cfg);
  const all = (await db.all("SELECT _id AS id, keyword, posicion, volumen, dificultad, intencion, url, estado, origen, oportunidad FROM " + Q + " WHERE _deleted = 0 ORDER BY volumen DESC")).map((c) => ({ ...c, ruta: pathOf(c.url), ...classify(c.url, pages, cfg) }));
  const real = all.filter((c) => c.origen !== "ejemplo");
  const isReal = !!cfg.casi_buscados || real.length > 0;
  const rows = isReal ? real : all;
  return {
    rows,
    origen: isReal ? "dataforseo" : all.length ? "ejemplo" : null,
    buscados: cfg.casi_buscados ?? null,
    desde: CASI_DESDE,
    hasta: CASI_HASTA,
    dominio: dominio(cfg) || null,
    mercado: cfg.mercado || null,
    ruta_blog: cfg.ruta_blog || "/blog/",
    sincronizado: cfg.sincronizado ?? null,
    articulos: pages.filter((p) => p.clase === "articulo").length
  };
}
async function almostToOpportunity(db, { id }) {
  const c = await db.one("SELECT * FROM " + Q + " WHERE _id = ? AND _deleted = 0", [id]);
  if (!c) throw new Refused("Esa keyword ya no est\xE1.", 404);
  if (c.estado === "convertida" && c.oportunidad) throw new Refused("Ya es la oportunidad n\xBA " + c.oportunidad + ".");
  const cfg = await settings(db);
  const { propuesta, criterio } = classify(c.url, await activePages(db, cfg), cfg);
  const ruta = pathOf(c.url);
  const ex = await db.one("SELECT _id FROM " + T + " WHERE lower(keyword) = lower(?) AND _deleted = 0", [c.keyword]);
  let op = ex?._id;
  if (!op) {
    const actualizar = propuesta === "actualizar";
    const data = {
      tema: actualizar ? "Actualizar " + ruta + " para \xAB" + c.keyword + "\xBB" : temaDe(c.keyword),
      keyword: c.keyword,
      volumen: c.volumen,
      dificultad: kdOf(c.dificultad),
      intencion: c.intencion,
      estado: "propuesta",
      origen: c.origen === "ejemplo" ? "ejemplo" : "dataforseo",
      lectora: cfg.publico || null,
      cubierto: c.url + " ya est\xE1 en la posici\xF3n " + c.posicion + " para \xAB" + c.keyword + "\xBB. " + criterio + ".",
      angulo: actualizar ? "Actualizar y ampliar ese art\xEDculo para subirlo a la primera p\xE1gina." : "Un art\xEDculo nuevo centrado en \xAB" + c.keyword + "\xBB que enlace a " + ruta + "."
    };
    const puntuacion = score(data);
    op = await db.insert(T, { ...data, puntuacion, prioridad: priorityOf(puntuacion) });
  }
  await db.update(Q, id, { estado: "convertida", oportunidad: op });
  return { id, oportunidad: op, propuesta };
}
var num = (v) => v === null || v === void 0 || v === "" ? null : Number(v);
async function saveQueries(db, { consultas, desde, hasta, origen }) {
  const rows = parse(consultas, []);
  if (!Array.isArray(rows)) throw new Refused("consultas es una lista: [{consulta, pagina, clics, impresiones, ctr, posicion}].", 400);
  const o = origen === "ejemplo" ? "ejemplo" : "search_console";
  let n = 0;
  for (const q of rows.slice(0, 1e3)) {
    if (!q?.consulta) continue;
    const data = { consulta: String(q.consulta), pagina: q.pagina ?? "", clics: num(q.clics), impresiones: num(q.impresiones), ctr: num(q.ctr), posicion: num(q.posicion), desde: desde ?? null, hasta: hasta ?? null, origen: o };
    const ex = await db.one("SELECT _id FROM " + C + " WHERE consulta = ? AND pagina = ? AND desde IS ? AND origen = ? AND _deleted = 0", [data.consulta, data.pagina, data.desde, o]);
    if (ex) await db.update(C, ex._id, data);
    else await db.insert(C, data);
    n++;
  }
  return { guardadas: n, desde: desde ?? null, hasta: hasta ?? null, origen: o };
}
async function queriesFor(db, kwWords) {
  const all = await db.all("SELECT consulta, pagina, clics, impresiones, ctr, posicion, origen, desde, hasta FROM " + C + " WHERE _deleted = 0");
  const real = ultimoPeriodo(all.filter((q) => q.origen !== "ejemplo"));
  const pool2 = real.length ? real : all;
  return pool2.map((q) => ({ ...q, hits: words(q.consulta).filter((w) => kwWords.has(w)).length })).filter((q) => q.hits >= 2 || q.hits === 1 && kwWords.size <= 2).sort((a, b) => b.hits - a.hits || b.impresiones - a.impresiones).slice(0, 10);
}
async function goalFrom(db, { tema, keyword, angulo, fuentes = [], formato = "articulo" }) {
  const kw = String(keyword || "").trim().toLowerCase().replace(/[¿?¡!«»"“”:;.,()]/g, " ").replace(/\s+/g, " ").trim().slice(0, 120);
  if (!kw) throw new Refused("No hay una b\xFAsqueda que convertir en objetivo.", 400);
  const ex = await db.one("SELECT _id FROM " + T + " WHERE lower(keyword) = ? AND _deleted = 0", [kw]);
  if (ex) return { id: ex._id, nuevo: false };
  const cfg = await settings(db);
  const data = { tema: String(tema || kw).slice(0, 160), keyword: kw, formato, lectora: cfg.publico || null, angulo: String(angulo || "").slice(0, 2e3) || null, fuentes: fuentes.filter(Boolean).join("\n") || null, estado: "propuesta", origen: "estimacion" };
  const puntuacion = score(data);
  const id = await db.insert(T, { ...data, puntuacion, prioridad: priorityOf(puntuacion) });
  return { id, nuevo: true };
}

// server/services/objetivos.mjs
var ACC = "oportunidadesseo_acciones";
var EVO = "oportunidadesseo_evolucion";
var FASES = ["por_decidir", "en_marcha", "subiendo", "ganada", "estancada", "descartada"];
var LEGADO = ["aprobada", "a_redactar", "en_articulo"];
var aprobado = (estado) => estado === "en_marcha" || LEGADO.includes(estado);
var TIPOS = {
  articulo_blog: { label: "Art\xEDculo del blog", hecha: "Publicado el art\xEDculo", articulo: true },
  pagina_servicio: { label: "P\xE1gina de servicio", hecha: "Publicada la p\xE1gina de servicio" },
  caso_real: { label: "Caso real", hecha: "Publicado el caso real", articulo: true },
  refrescar: { label: "Refrescar un contenido", hecha: "Contenido refrescado", articulo: true },
  enlaces_internos: { label: "Enlaces internos", hecha: "Enlaces internos puestos" }
};
var ACCION_ESTADOS = ["pendiente", "en_curso", "hecha", "cancelada"];
var NOMBRE_MODULO = { articles: "Art\xEDculos" };
var ESTADO_ARTICULO = { idea: "Idea", draft: "Borrador", review: "En revisi\xF3n", ready: "Lista", published: "Publicada", archived: "Archivada" };
var ES_A_CLAVE = { idea: "idea", borrador: "draft", "en revision": "review", lista: "ready", publicada: "published", archivada: "archived" };
var TOP = 10;
var SEMANAS = 4;
var topDe = (cfg) => {
  const n = Math.round(Number(cfg?.objetivo_top));
  return n >= 1 && n <= 100 ? n : TOP;
};
var semanasDe = (cfg) => {
  const n = Math.round(Number(cfg?.semanas_estancada));
  return n >= 1 && n <= 52 ? n : SEMANAS;
};
var now5 = () => (/* @__PURE__ */ new Date()).toISOString().slice(0, 19).replace("T", " ");
var dia = (s) => s ? String(s).slice(0, 10) : null;
var num2 = (v) => v === null || v === void 0 || v === "" || !Number.isFinite(Number(v)) ? null : Number(v);
var tiempo = (s) => {
  const t = Date.parse(String(s || "").slice(0, 10) + "T00:00:00Z");
  return Number.isFinite(t) ? t : null;
};
var norm2 = (s) => String(s ?? "").toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/\s+/g, " ").trim();
var lista = (s) => String(s ?? "").split(/[;\n]/).map((x) => x.trim()).filter(Boolean);
var pos1 = (v) => v == null ? "\u2014" : String(Math.round(Number(v) * 10) / 10).replace(".", ",");
var FUENTE_ORDEN = { search_console: 0, top10: 1 };
var ordenar = (puntos) => [...puntos ?? []].filter((p) => p && p.fecha).sort((a, b) => String(a.fecha).localeCompare(String(b.fecha)) || (FUENTE_ORDEN[a.fuente] ?? 0) - (FUENTE_ORDEN[b.fuente] ?? 0));
function goalState({ estado, aprobada_el, base, puntos, ultima_accion, top = TOP, semanas = SEMANAS, hoy = /* @__PURE__ */ new Date() } = {}) {
  const e = estado || "propuesta";
  if (e === "descartada") return { fase: "descartada" };
  if (!aprobado(e)) return { fase: "por_decidir" };
  const pts = ordenar(puntos);
  const basePos = num2(parse(base, null)?.posicion);
  let mejor = basePos, ultima_mejora = null;
  for (const p of pts) {
    const v = num2(p.posicion);
    if (v == null) continue;
    if (mejor == null || v <= mejor - 1) ultima_mejora = dia(p.fecha);
    if (mejor == null || v < mejor) mejor = v;
  }
  const medidos = pts.filter((p) => num2(p.posicion) != null);
  const ultimo = pts[pts.length - 1] ?? null;
  const visto = medidos[medidos.length - 1] ?? null;
  const posicion = visto ? num2(visto.posicion) : basePos;
  const ganada = ultimo ? num2(ultimo.posicion) != null && num2(ultimo.posicion) <= top : basePos != null && basePos <= top;
  const desde = [dia(aprobada_el), ultima_mejora, dia(ultima_accion)].filter(Boolean).sort().pop() ?? null;
  const t0 = tiempo(desde), t1 = tiempo(new Date(hoy).toISOString());
  const sin = t0 != null && t1 != null ? Math.max(0, Math.floor((t1 - t0) / (7 * 864e5))) : 0;
  const out = {
    posicion,
    posicion_fecha: visto ? dia(visto.fecha) : basePos != null ? dia(aprobada_el) : null,
    mejor,
    ultima_mejora,
    base: basePos,
    semanas_sin_mejora: sin,
    // places gained since it was approved (positive = better); null while there is nothing to compare
    ganado: basePos != null && posicion != null ? Math.round((basePos - posicion) * 10) / 10 : null,
    fuera: !!ultimo && ultimo.fuente === "top10" && num2(ultimo.posicion) == null
  };
  if (ganada) return { ...out, fase: "ganada" };
  if (sin >= semanas) return { ...out, fase: "estancada" };
  if (ultima_mejora && posicion != null && (basePos == null || posicion < basePos)) return { ...out, fase: "subiendo" };
  return { ...out, fase: "en_marcha" };
}
function posicionDe(goal, filas2, urls = []) {
  const kws = new Set([goal.keyword, ...lista(goal.secundarias)].map(norm2).filter(Boolean));
  const rutas = new Set((urls ?? []).filter(Boolean).map(pathOf));
  const propias2 = (filas2 ?? []).filter((q) => kws.has(norm2(q.consulta)));
  const principal = propias2.filter((q) => norm2(q.consulta) === norm2(goal.keyword));
  const base = principal.length ? principal : propias2;
  const imp = base.reduce((n, q) => n + (Number(q.impresiones) || 0), 0);
  const conPos = base.filter((q) => num2(q.posicion) != null);
  const posicion = !conPos.length ? null : imp > 0 ? conPos.reduce((n, q) => n + q.posicion * (Number(q.impresiones) || 0), 0) / imp : Math.min(...conPos.map((q) => q.posicion));
  const todas = (filas2 ?? []).filter((q) => kws.has(norm2(q.consulta)) || q.pagina && rutas.has(pathOf(q.pagina)));
  const mejorFila = [...base].sort((a, b) => (Number(b.impresiones) || 0) - (Number(a.impresiones) || 0))[0];
  return {
    posicion: posicion == null ? null : Math.round(posicion * 10) / 10,
    impresiones: todas.reduce((n, q) => n + (Number(q.impresiones) || 0), 0),
    clics: todas.reduce((n, q) => n + (Number(q.clics) || 0), 0),
    consulta: mejorFila?.consulta ?? null,
    url: mejorFila?.pagina ?? null,
    filas: todas.length
  };
}
var UMBRALES = [50, 30, 20];
function timeline(goal, acciones = [], puntos = [], { top = TOP } = {}) {
  const ev = [];
  const base = parse(goal.base, null);
  if (goal.aprobada_el) ev.push({ fecha: dia(goal.aprobada_el), orden: 0, tipo: "aprobado", texto: "Aprobado. Posici\xF3n " + pos1(num2(base?.posicion)) + (base?.impresiones != null ? " \xB7 " + base.impresiones + " impresiones" : "") });
  for (const a of acciones) {
    const t = TIPOS[a.tipo] ?? { label: a.tipo, hecha: "Hecho" };
    if (a.fecha) ev.push({ fecha: dia(a.fecha), orden: 1, tipo: "accion", accion: a.id ?? a._id, texto: "Acci\xF3n a\xF1adida: " + t.label + (a.titulo ? " (\xAB" + a.titulo + "\xBB)" : "") });
    if (a.estado === "hecha" && a.hecha_el) ev.push({ fecha: dia(a.hecha_el), orden: 2, tipo: "hecha", accion: a.id ?? a._id, texto: t.hecha, url: a.url || null });
    if (a.estado === "cancelada" && a.hecha_el) ev.push({ fecha: dia(a.hecha_el), orden: 2, tipo: "cancelada", accion: a.id ?? a._id, texto: "Acci\xF3n cancelada: " + t.label });
  }
  let mejor = num2(base?.posicion);
  const cruzados = new Set([...UMBRALES, top].filter((u) => mejor != null && mejor <= u));
  let ganada = mejor != null && mejor <= top;
  for (const p of ordenar(puntos)) {
    const v = num2(p.posicion);
    if (v == null) continue;
    const donde = p.fuente === "top10" ? "Google" : "Search Console";
    if (mejor == null) ev.push({ fecha: dia(p.fecha), orden: 3, tipo: "aparece", texto: "Aparece en Google: posici\xF3n " + pos1(v) + " (" + donde + ")" });
    if (v <= top && !ganada) {
      ev.push({ fecha: dia(p.fecha), orden: 4, tipo: "ganada", texto: "Entra en el top " + top + ": posici\xF3n " + pos1(v) + ". Objetivo ganado" });
      ganada = true;
      cruzados.add(top);
    } else if (mejor != null) {
      for (const u of UMBRALES) if (u > top && v <= u && !cruzados.has(u) && mejor > u) {
        ev.push({ fecha: dia(p.fecha), orden: 3, tipo: "sube", texto: "Top " + u + ": posici\xF3n " + pos1(v) });
        break;
      }
    }
    for (const u of UMBRALES) if (v <= u) cruzados.add(u);
    if (mejor == null || v < mejor) mejor = v;
  }
  if (goal.siguiente && goal.siguiente_fecha) ev.push({ fecha: dia(goal.siguiente_fecha), orden: 5, tipo: "propuesta", texto: "Tu agente propone: " + goal.siguiente });
  return ev.filter((e) => e.fecha).sort((a, b) => a.fecha.localeCompare(b.fecha) || a.orden - b.orden).map(({ orden, ...e }) => e);
}
function nextStep(goal, st, acciones = []) {
  const vivas = acciones.filter((a) => a.estado === "pendiente" || a.estado === "en_curso");
  const ultima = acciones.map((a) => dia(a.hecha_el) || dia(a.fecha)).filter(Boolean).sort().pop() ?? "";
  const propuesta = goal.siguiente && (!goal.siguiente_fecha || dia(goal.siguiente_fecha) >= ultima) ? { texto: goal.siguiente, tipo: TIPOS[goal.siguiente_tipo] ? goal.siguiente_tipo : null } : null;
  switch (st.fase) {
    case "descartada":
      return { de: "persona", texto: "Descartado. Puedes recuperarlo si cambias de idea." };
    case "por_decidir":
      return { de: "persona", texto: "Decide: \xABAprobar\xBB para empezar a trabajarlo, o \xABDescartar\xBB." };
    case "ganada":
      return { de: "nadie", texto: "Ganado: est\xE1 en el top. Se sigue midiendo cada semana por si baja." };
    default:
  }
  if (vivas.length) {
    const a = vivas[0];
    const t = TIPOS[a.tipo]?.label ?? a.tipo;
    return { de: "agente", texto: a.estado === "pendiente" ? "Tu agente tiene por empezar: " + t + "." : t + " en curso" + (a.ref_estado ? " (" + (ESTADO_ARTICULO[a.ref_estado] ?? a.ref_estado) + ")" : "") + ".", accion: a.id ?? a._id };
  }
  if (propuesta) return { de: "persona", texto: propuesta.texto, tipo: propuesta.tipo, propuesta: true };
  if (!acciones.some((a) => a.estado === "hecha")) return { de: "persona", texto: "A\xF1ade la primera acci\xF3n: sin ninguna, nada cambia en Google." };
  if (st.fase === "estancada") return { de: "agente", texto: "Lleva " + st.semanas_sin_mejora + " semanas sin mejorar. Pide a tu agente que proponga el siguiente paso.", pedir: true };
  if (st.fase === "subiendo") return { de: "nadie", texto: "Est\xE1 subiendo. Se mide cada semana; si se para, tu agente propondr\xE1 el siguiente paso." };
  return { de: "nadie", texto: "Hecho lo previsto. Google tarda unas semanas en reflejarlo: se mide cada lunes." };
}
function disponibilidad(peers) {
  return Object.entries(TIPOS).map(([tipo, t]) => {
    const p = (peers ?? []).find((x) => (x.unlocks ?? []).includes(tipo)) ?? null;
    const nombre = p ? p.name || NOMBRE_MODULO[p.module] || p.module : null;
    const falta = !!p && p.installed === false;
    return {
      tipo,
      label: t.label,
      disponible: !falta,
      modulo: p?.module ?? null,
      modulo_nombre: nombre,
      como: p ? falta ? "Instala " + nombre + " para que tu agente lo " + (tipo === "refrescar" ? "refresque" : "escriba") : "Lo hace tu agente en " + nombre : "Lo hace el agente de tu equipo",
      ...falta ? { instalar: { modulo: p.module, nombre, lugar: "modules/catalogue/" + p.module } } : {}
    };
  });
}
async function peersOf(db) {
  if (typeof db.peers !== "function") return null;
  try {
    const p = await db.peers();
    return Array.isArray(p) ? p : null;
  } catch {
    return null;
  }
}
async function get2(db, id) {
  const row = await db.one("SELECT * FROM " + T + " WHERE _id = ? AND _deleted = 0", [id]);
  if (!row) throw new Refused("Ese objetivo ya no est\xE1.", 404);
  return row;
}
var accionesDe = async (db, id) => (await db.all("SELECT * FROM " + ACC + " WHERE objetivo = ? AND estado != 'duplicada' AND _deleted = 0 ORDER BY _id", [id])).map((a) => ({ ...a, id: a._id }));
var puntosDe = async (db, id) => db.all("SELECT fecha, posicion, impresiones, clics, fuente, url, consulta FROM " + EVO + " WHERE objetivo = ? AND _deleted = 0 ORDER BY fecha, _id", [id]);
var ultimaAccion = (acciones) => acciones.filter((a) => a.estado !== "cancelada").flatMap((a) => [dia(a.fecha), dia(a.hecha_el)]).filter(Boolean).sort().pop() ?? null;
var estadoDe = (row, acciones, puntos, cfg, hoy) => goalState({ estado: row.estado, aprobada_el: row.aprobada_el, base: row.base, puntos, ultima_accion: ultimaAccion(acciones), top: topDe(cfg), semanas: semanasDe(cfg), hoy });
async function refrescar(db, id, cfg, hoy = /* @__PURE__ */ new Date()) {
  const row = await get2(db, id);
  const c = cfg ?? await settings(db);
  const st = estadoDe(row, await accionesDe(db, id), await puntosDe(db, id), c, hoy);
  const data = {};
  if (row.fase !== st.fase) data.fase = st.fase;
  if (num2(row.posicion) !== (st.posicion ?? null)) data.posicion = st.posicion ?? null;
  if (st.fase === "ganada" && !row.ganada_el) data.ganada_el = new Date(hoy).toISOString().slice(0, 19).replace("T", " ");
  if (Object.keys(data).length) await db.update(T, id, data);
  return st;
}
async function consultasUltimas(db, cfg) {
  const dom2 = domainOf2(cfg.dominio);
  const rows = (await db.all("SELECT consulta, pagina, clics, impresiones, posicion, desde, hasta FROM " + C + " WHERE origen = 'search_console' AND _deleted = 0")).filter((r) => {
    const p = String(r.pagina || "").trim();
    return !p || !/^https?:\/\//i.test(p) || domainOf2(p) === dom2;
  });
  return ultimoPeriodo(rows);
}
async function baseline(db, row, cfg) {
  const filas2 = await consultasUltimas(db, cfg);
  const sc = posicionDe(row, filas2);
  const own = domainOf2(cfg.dominio);
  const serp = (parse(row.serp, []) ?? []).filter((x) => x && x.dominio && row.serp_origen !== "ejemplo");
  const enTop = own ? serp.find((x) => domainOf2(x.dominio) === own) : null;
  const periodo = filas2.find((q) => q.desde && q.hasta);
  return {
    fecha: now5(),
    posicion: sc.posicion ?? (enTop ? Number(enTop.pos) : null),
    fuente: sc.posicion != null ? "search_console" : enTop ? "top10" : null,
    impresiones: filas2.length ? sc.impresiones : null,
    clics: filas2.length ? sc.clics : null,
    periodo: periodo ? periodo.desde + " a " + periodo.hasta : null,
    top10: serp.slice(0, 10).map((x) => ({ pos: x.pos, dominio: x.dominio, titulo: x.titulo ?? "", url: x.url ?? "" })),
    top10_fecha: parse(row.preguntas, null)?.fecha ?? null
  };
}
async function sinDuplicadas(db) {
  const rows = await db.all("SELECT _id, objetivo, modulo, ref FROM " + ACC + " WHERE modulo IS NOT NULL AND ref IS NOT NULL AND estado != 'duplicada' AND _deleted = 0 ORDER BY _id");
  const vistas = /* @__PURE__ */ new Set();
  for (const a of rows) {
    const k = a.objetivo + "|" + a.modulo + "|" + a.ref;
    if (vistas.has(k)) await db.update(ACC, a._id, { estado: "duplicada", nota: "Repeated: the same record was linked twice; it does not count." });
    else vistas.add(k);
  }
}
var migrando = null;
function migrate(db) {
  migrando ??= migrar(db).finally(() => {
    migrando = null;
  });
  return migrando;
}
async function migrar(db) {
  await sinDuplicadas(db);
  const viejas = await db.all("SELECT * FROM " + T + " WHERE estado IN ('aprobada', 'a_redactar', 'en_articulo') AND _deleted = 0");
  if (!viejas.length) return { migradas: 0 };
  const cfg = await settings(db);
  let acciones = 0;
  for (const r of viejas) {
    const aprobada_el = r.aprobada_el || r._updated_at || now5();
    const base = r.base ? null : { ...await baseline(db, r, cfg), fecha: aprobada_el, migrada: true };
    const tenia = r.estado === "a_redactar" || r.estado === "en_articulo" || Number(r.articulo) > 0;
    if (tenia && !await db.one("SELECT _id FROM " + ACC + " WHERE objetivo = ? AND _deleted = 0", [r._id])) {
      const linked = Number(r.articulo) > 0;
      await db.insert(ACC, {
        objetivo: r._id,
        tipo: r.formato === "servicio" && !linked ? "pagina_servicio" : "articulo_blog",
        estado: linked ? "en_curso" : "pendiente",
        titulo: r.tema,
        fecha: aprobada_el,
        ...linked ? { modulo: "articles", ref: String(Number(r.articulo)) } : {},
        nota: "De la versi\xF3n anterior (" + (r.estado === "en_articulo" ? "En Art\xEDculos" : r.estado === "a_redactar" ? "A redactar" : "Aprobada") + ")."
      });
      acciones++;
    }
    await db.update(T, r._id, { estado: "en_marcha", aprobada_el, ...base ? { base: JSON.stringify(base) } : {} });
    await refrescar(db, r._id, cfg);
  }
  return { migradas: viejas.length, acciones };
}
async function approve(db, { id, motivo }) {
  await migrate(db);
  const row = await get2(db, id);
  const e = row.estado || "propuesta";
  if (!["propuesta", "descartada"].includes(e)) throw new Refused("Ya est\xE1 aprobado: se est\xE1 trabajando.");
  const cfg = await settings(db);
  await db.update(T, id, { estado: "en_marcha", aprobada_el: now5(), base: JSON.stringify(await baseline(db, row, cfg)), ...motivo ? { motivo } : {} });
  const st = await refrescar(db, id, cfg);
  return { id, estado: "en_marcha", fase: st.fase, base_posicion: st.base ?? null };
}
async function discard(db, { id, motivo }) {
  await migrate(db);
  const row = await get2(db, id);
  if ((row.estado || "propuesta") === "descartada") throw new Refused("Ya est\xE1 descartado.");
  await db.update(T, id, { estado: "descartada", ...motivo ? { motivo } : {} });
  await refrescar(db, id);
  return { id, estado: "descartada", fase: "descartada" };
}
async function addAction(db, { id, tipo, titulo, nota }) {
  await migrate(db);
  const row = await get2(db, id);
  if (!aprobado(row.estado)) throw new Refused(row.estado === "descartada" ? "Est\xE1 descartado: recup\xE9ralo antes de a\xF1adirle acciones." : "Aprueba el objetivo antes de a\xF1adirle acciones.");
  if (!TIPOS[tipo]) throw new Refused("tipo es uno de: " + Object.keys(TIPOS).join(", ") + ".", 400);
  const d = disponibilidad(await peersOf(db)).find((x) => x.tipo === tipo);
  if (!d.disponible) throw new Refused(d.como + ": \xAB" + TIPOS[tipo].label + "\xBB la hace tu agente con ese m\xF3dulo. Lo instala un propietario o administrador en De la empresa \u203A M\xF3dulos \u203A Cat\xE1logo; despu\xE9s, a\xF1ade la acci\xF3n.", 409);
  const abierta = await db.one("SELECT _id FROM " + ACC + " WHERE objetivo = ? AND tipo = ? AND estado IN ('pendiente', 'en_curso') AND _deleted = 0", [id, tipo]);
  if (abierta) throw new Refused("Ya hay una acci\xF3n \xAB" + TIPOS[tipo].label + "\xBB en marcha para este objetivo (n\xBA " + abierta._id + ").");
  const accion = await db.insert(ACC, { objetivo: id, tipo, estado: "pendiente", titulo: String(titulo ?? "").trim() || row.tema, nota: String(nota ?? "").trim() || null, fecha: now5(), ...d.modulo ? { modulo: d.modulo } : {} });
  await refrescar(db, id);
  return { id, accion, tipo, modulo: d.modulo, que_hace_el_agente: d.modulo ? "Crea el registro en " + d.modulo_nombre + " con brief_completo y lo vincula con vincular_accion." : "La hace y la vincula con vincular_accion cuando est\xE9." };
}
var EN_ARTICULOS = ["articulo_blog", "caso_real", "refrescar"];
async function pendingInArticles(db) {
  const filas2 = await db.all("SELECT a._id AS accion, a.objetivo, a.tipo, a.titulo, o.keyword, o.tema, o.estado AS estado_objetivo FROM " + ACC + " a JOIN " + T + " o ON o._id = a.objetivo AND o._deleted = 0 WHERE a._deleted = 0 AND a.estado = 'pendiente' AND (a.ref IS NULL OR a.ref = '') AND a.tipo IN (" + EN_ARTICULOS.map(() => "?").join(", ") + ") ORDER BY a._id", EN_ARTICULOS);
  const items = filas2.filter((f) => aprobado(f.estado_objetivo)).map((f) => {
    const keyword = f.keyword || f.tema || "";
    const titulo = f.titulo || f.tema || keyword;
    return { key: "accion:" + f.accion, text: (TIPOS[f.tipo]?.label ?? f.tipo) + " \xAB" + titulo + "\xBB para el objetivo \xAB" + keyword + "\xBB", accion: f.accion, objetivo: f.objetivo, tipo: f.tipo, titulo, keyword };
  });
  return { items };
}
var claveEstado = (s) => {
  const k = norm2(s);
  return ESTADO_ARTICULO[k] ? k : ES_A_CLAVE[k] ?? (k || null);
};
async function linkAction(db, { id, modulo, ref, ref_estado, url, estado, nota, titulo }) {
  const a = await db.one("SELECT * FROM " + ACC + " WHERE _id = ? AND estado != 'duplicada' AND _deleted = 0", [id]);
  if (!a) throw new Refused("Esa acci\xF3n ya no est\xE1.", 404);
  if (a.estado === "cancelada") throw new Refused("Esa acci\xF3n est\xE1 cancelada.");
  if (estado !== void 0 && !ACCION_ESTADOS.includes(estado)) throw new Refused("estado es uno de: " + ACCION_ESTADOS.join(", ") + ".", 400);
  const data = {};
  if (modulo !== void 0 && modulo !== null && modulo !== "") data.modulo = String(modulo);
  if (ref !== void 0 && ref !== null && ref !== "") data.ref = String(ref);
  const re = ref_estado !== void 0 ? claveEstado(ref_estado) : void 0;
  if (re !== void 0) data.ref_estado = re;
  if (url !== void 0 && url !== null && String(url).trim()) data.url = String(url).trim();
  if (nota !== void 0) data.nota = String(nota ?? "");
  if (titulo !== void 0 && String(titulo).trim()) data.titulo = String(titulo).trim();
  const publicada = re === "published";
  const sig = estado ?? (publicada ? "hecha" : a.estado === "pendiente" && (data.ref || data.url || re) ? "en_curso" : a.estado);
  if (sig !== a.estado) {
    data.estado = sig;
    if (sig === "hecha" || sig === "cancelada") data.hecha_el = now5();
  }
  if (!Object.keys(data).length) throw new Refused("Di qu\xE9 cambia: modulo y ref (lo que creaste), ref_estado, url o estado.", 400);
  await db.update(ACC, id, data);
  await refrescar(db, a.objetivo);
  return { id, objetivo: a.objetivo, estado: sig, ...data };
}
async function cancelAction(db, { id, nota }) {
  const a = await db.one("SELECT * FROM " + ACC + " WHERE _id = ? AND estado != 'duplicada' AND _deleted = 0", [id]);
  if (!a) throw new Refused("Esa acci\xF3n ya no est\xE1.", 404);
  if (a.estado === "hecha" || a.estado === "cancelada") throw new Refused("Esa acci\xF3n ya est\xE1 " + (a.estado === "hecha" ? "hecha" : "cancelada") + ".");
  await db.update(ACC, id, { estado: "cancelada", hecha_el: now5(), ...nota ? { nota: String(nota) } : {} });
  await refrescar(db, a.objetivo);
  return { id, objetivo: a.objetivo, estado: "cancelada" };
}
async function linkArticle(db, { id, articulo, estado_articulo, url }) {
  await migrate(db);
  const row = await get2(db, id);
  if (!aprobado(row.estado)) throw new Refused("Solo un objetivo aprobado tiene acciones.");
  if (!Number(articulo)) throw new Refused("Falta el n\xFAmero del art\xEDculo.", 400);
  const accion = await accionDeArticulo(db, row, Number(articulo));
  const r = await linkAction(db, { id: accion, modulo: "articles", ref: Number(articulo), ...estado_articulo ? { ref_estado: estado_articulo } : {}, ...url ? { url } : {} });
  await db.update(T, id, { articulo: Number(articulo) });
  return { id, articulo: Number(articulo), accion, estado: r.estado };
}
async function accionDeArticulo(db, row, articulo) {
  const todas = await accionesDe(db, row._id);
  const suya = todas.find((a) => a.modulo === "articles" && String(a.ref) === String(articulo));
  if (suya) return suya._id;
  const libre = todas.find((a) => TIPOS[a.tipo]?.articulo && !a.ref && (a.estado === "pendiente" || a.estado === "en_curso"));
  if (libre) return libre._id;
  return db.insert(ACC, { objetivo: row._id, tipo: "articulo_blog", estado: "pendiente", titulo: row.tema, fecha: now5(), modulo: "articles" });
}
var ORIGEN = /oportunidades\s+seo\s*#\s*(\d+)/i;
async function syncArticleStates(db, articulos) {
  const list3 = parse(articulos, []);
  if (!Array.isArray(list3)) throw new Refused("articulos es una lista: [{ id, state, url, origin, title }].", 400);
  await migrate(db);
  let vinculados = 0, publicados = 0, recien_publicados = 0, sin_objetivo = 0;
  const tocados = /* @__PURE__ */ new Set();
  for (const x of list3.slice(0, 500)) {
    if (!x || !Number(x.id)) continue;
    const m = ORIGEN.exec(String(x.origin ?? x.origen ?? ""));
    let accion = await db.one("SELECT _id, objetivo, estado FROM " + ACC + " WHERE modulo = 'articles' AND ref = ? AND estado != 'duplicada' AND _deleted = 0 ORDER BY _id", [String(Number(x.id))]) ?? null;
    if (!accion && m) {
      const row = await db.one("SELECT * FROM " + T + " WHERE _id = ? AND _deleted = 0", [Number(m[1])]);
      if (row && aprobado(row.estado)) {
        const id = await accionDeArticulo(db, row, Number(x.id));
        accion = { _id: id, objetivo: row._id, estado: "pendiente" };
        await db.update(T, row._id, { articulo: Number(x.id) });
      }
    }
    if (!accion) {
      if (m) sin_objetivo++;
      continue;
    }
    if (accion.estado === "cancelada") continue;
    const estado = claveEstado(x.state ?? x.estado);
    const url = String(x.url ?? "").trim();
    const r = await linkAction(db, { id: accion._id, modulo: "articles", ref: Number(x.id), ...estado ? { ref_estado: estado } : {}, ...url ? { url } : {}, ...x.title || x.titulo ? { titulo: x.title || x.titulo } : {} }).catch((e) => {
      if (e instanceof Refused) return null;
      throw e;
    });
    if (!r) continue;
    vinculados++;
    tocados.add(accion.objetivo);
    if (r.estado === "hecha") {
      publicados++;
      if (accion.estado !== "hecha") recien_publicados++;
    }
  }
  return { articulos: list3.length, vinculados, publicados, recien_publicados, sin_objetivo, objetivos: tocados.size };
}
async function proposeNext(db, { id, siguiente, tipo }) {
  const row = await get2(db, id);
  const texto = String(siguiente ?? "").trim();
  if (texto.length < 10 || texto.length > 600) throw new Refused("siguiente es una frase (de 10 a 600 caracteres) con lo que propones hacer y por qu\xE9.", 400);
  if (tipo && !TIPOS[tipo]) throw new Refused("tipo, si lo das, es uno de: " + Object.keys(TIPOS).join(", ") + ".", 400);
  if (!aprobado(row.estado)) throw new Refused("Solo se propone el siguiente paso de un objetivo aprobado.");
  await db.update(T, id, { siguiente: texto, siguiente_tipo: tipo || null, siguiente_fecha: now5() });
  return { id, siguiente: texto, tipo: tipo || null };
}
async function punto(db, objetivo, p) {
  const ex = await db.one("SELECT _id FROM " + EVO + " WHERE objetivo = ? AND fuente = ? AND fecha = ? AND _deleted = 0", [objetivo, p.fuente, p.fecha]);
  if (ex) await db.update(EVO, ex._id, p);
  else await db.insert(EVO, { objetivo, ...p });
}
async function recordSearchConsole(db, { desde, hasta } = {}) {
  await migrate(db);
  const cfg = await settings(db);
  const dom2 = domainOf2(cfg.dominio);
  const filas2 = (await db.all("SELECT consulta, pagina, clics, impresiones, posicion FROM " + C + " WHERE origen = 'search_console' AND desde IS ? AND hasta IS ? AND _deleted = 0", [desde ?? null, hasta ?? null])).filter((r) => {
    const p = String(r.pagina || "").trim();
    return !p || !/^https?:\/\//i.test(p) || domainOf2(p) === dom2;
  });
  if (!filas2.length) return { objetivos: 0 };
  const fecha = dia(hasta) || dia(now5());
  const goals = await db.all("SELECT * FROM " + T + " WHERE estado = 'en_marcha' AND _deleted = 0");
  let n = 0;
  for (const g of goals) {
    const urls = (await accionesDe(db, g._id)).map((a) => a.url).filter((u) => u && isOwnPage(u, cfg));
    const p = posicionDe(g, filas2, urls);
    await punto(db, g._id, { fecha, fuente: "search_console", posicion: p.posicion, impresiones: p.impresiones, clics: p.clics, consulta: p.consulta, url: p.url, desde: desde ?? null, hasta: hasta ?? null });
    await refrescar(db, g._id, cfg);
    n++;
  }
  return { objetivos: n, fecha };
}
var MAX_REVISION = 25;
async function recheckGoals(db, { forzar } = {}, keys = keysClient(), hoy = /* @__PURE__ */ new Date()) {
  return withMeter(db, "revisar_objetivos", (m) => recheck(db, keys, m, forzar === true || forzar === "true" || forzar === 1, hoy));
}
async function recheck(db, keys, m, forzar, hoy) {
  await migrate(db);
  const cfg = await settings(db);
  const own = domainOf2(cfg.dominio);
  if (!own) throw new Refused("Falta el dominio en Ajustes (General \u2192 Dominio).", 400);
  const goals = (await db.all("SELECT * FROM " + T + " WHERE estado = 'en_marcha' AND _deleted = 0 ORDER BY puntuacion DESC")).slice(0, MAX_REVISION);
  if (!goals.length) return { objetivos: 0, texto: "No hay objetivos aprobados que revisar." };
  const w = where(cfg);
  const res = await serpBatch(keys, goals.map((g) => g.keyword), w, m, { db, forzar, modo: serpModo(cfg) });
  const fecha = dia(new Date(hoy).toISOString());
  const cambios = [];
  let en_top = 0, fallos = 0;
  for (const g of goals) {
    const sr = res.get(String(g.keyword).trim());
    if (!sr || sr.error) {
      fallos++;
      continue;
    }
    const o = organicTop(sr.items, { n: 10 });
    const hit = o.validos.find((x) => domainOf2(x.dominio) === own) ?? null;
    const antes = estadoDe(g, await accionesDe(db, g._id), await puntosDe(db, g._id), cfg, hoy);
    await punto(db, g._id, { fecha, fuente: "top10", posicion: hit ? Number(hit.pos) : null, url: hit?.url ?? null, consulta: g.keyword });
    const st = await refrescar(db, g._id, cfg, hoy);
    if (hit) en_top++;
    if (st.fase !== antes.fase) cambios.push({ id: g._id, tema: g.tema, de: antes.fase, a: st.fase, posicion: st.posicion ?? null });
  }
  return {
    objetivos: goals.length,
    en_top10: en_top,
    sin_leer: fallos,
    cambios,
    estancados: (await goalsView(db, hoy)).rows.filter((r) => r.fase === "estancada").map((r) => ({ id: r.id, tema: r.tema, semanas: r.semanas_sin_mejora, propuesta: !!r.siguiente_propuesta })),
    texto: goals.length + " objetivos revisados: " + en_top + " en el top 10" + (cambios.length ? "; cambian de estado " + cambios.length : "") + (fallos ? "; " + fallos + " sin poder leerse" : "") + "."
  };
}
async function goalsView(db, hoy = /* @__PURE__ */ new Date()) {
  await migrate(db);
  const cfg = await settings(db);
  const rows = await db.all("SELECT _id AS id, tema, keyword, secundarias, volumen, dificultad, intencion, formato, cluster, prioridad, puntuacion, estado, origen, serp_origen, nivel, aprobada_el, base, siguiente, siguiente_tipo, siguiente_fecha, ganada_el, articulo FROM " + T + " WHERE _deleted = 0 ORDER BY puntuacion DESC");
  const acc = await db.all("SELECT _id, _id AS id, objetivo, tipo, estado, titulo, modulo, ref, ref_estado, url, fecha, hecha_el FROM " + ACC + " WHERE estado != 'duplicada' AND _deleted = 0 ORDER BY _id");
  const evo = await db.all("SELECT objetivo, fecha, posicion, impresiones, clics, fuente FROM " + EVO + " WHERE _deleted = 0 ORDER BY fecha, _id");
  const por = (list3, id) => list3.filter((x) => x.objetivo === id);
  const out = rows.map((r) => {
    const acciones = por(acc, r.id), puntos = por(evo, r.id);
    const st = estadoDe(r, acciones, puntos, cfg, hoy);
    const paso = nextStep(r, st, acciones);
    const sc = [...puntos].reverse().find((p) => p.fuente === "search_console") ?? null;
    return {
      id: r.id,
      tema: r.tema,
      keyword: r.keyword,
      volumen: r.volumen,
      intencion: r.intencion,
      formato: r.formato,
      cluster: r.cluster,
      prioridad: r.prioridad,
      puntuacion: r.puntuacion,
      estado: r.estado || "propuesta",
      origen: r.origen,
      serp_origen: r.serp_origen,
      nivel: r.nivel,
      fase: st.fase,
      posicion: st.posicion ?? null,
      posicion_base: st.base ?? null,
      ganado: st.ganado ?? null,
      semanas_sin_mejora: st.semanas_sin_mejora ?? 0,
      aprobada_el: r.aprobada_el ?? null,
      ganada_el: r.ganada_el ?? null,
      impresiones: sc?.impresiones ?? null,
      clics: sc?.clics ?? null,
      acciones: acciones.length,
      acciones_hechas: acciones.filter((a) => a.estado === "hecha").length,
      acciones_vivas: acciones.filter((a) => a.estado === "pendiente" || a.estado === "en_curso").length,
      acciones_txt: acciones.filter((a) => a.estado !== "cancelada").map((a) => TIPOS[a.tipo]?.label ?? a.tipo).join(", "),
      siguiente: paso.texto,
      siguiente_de: paso.de,
      siguiente_propuesta: !!paso.propuesta,
      tendencia: puntos.filter((p) => num2(p.posicion) != null).map((p) => ({ fecha: p.fecha, posicion: p.posicion }))
    };
  });
  const cuenta = Object.fromEntries(FASES.map((f) => [f, out.filter((r) => r.fase === f).length]));
  return { rows: out, cuenta, top: topDe(cfg), semanas: semanasDe(cfg), dominio: domainOf2(cfg.dominio) || null, mercado: cfg.mercado || null };
}
async function goalExtras(db, row, cfg, hoy = /* @__PURE__ */ new Date()) {
  const acciones = await accionesDe(db, row._id);
  const puntos = await puntosDe(db, row._id);
  const st = estadoDe(row, acciones, puntos, cfg, hoy);
  const peers = await peersOf(db);
  return {
    fase: st.fase,
    posicion: st.posicion ?? null,
    posicion_fecha: st.posicion_fecha ?? null,
    ganado: st.ganado ?? null,
    semanas_sin_mejora: st.semanas_sin_mejora ?? 0,
    fuera_top: !!st.fuera,
    objetivo_top: topDe(cfg),
    semanas_estancada: semanasDe(cfg),
    base: parse(row.base, null),
    acciones: acciones.map((a) => ({ id: a._id, tipo: a.tipo, tipo_label: TIPOS[a.tipo]?.label ?? a.tipo, estado: a.estado, titulo: a.titulo, modulo: a.modulo ?? null, ref: a.ref ?? null, ref_estado: a.ref_estado ?? null, ref_estado_label: a.ref_estado ? ESTADO_ARTICULO[a.ref_estado] ?? a.ref_estado : null, url: a.url ?? null, fecha: a.fecha, hecha_el: a.hecha_el ?? null, nota: a.nota ?? null })),
    evolucion: puntos.map((p) => ({ fecha: p.fecha, posicion: num2(p.posicion), impresiones: p.impresiones ?? null, clics: p.clics ?? null, fuente: p.fuente })),
    historia: timeline(row, acciones, puntos, { top: topDe(cfg) }),
    siguiente_paso: nextStep(row, st, acciones),
    tipos_accion: disponibilidad(peers),
    modulos: peers,
    // what this goal's own actions published counts as something the site has, before the next look at the site
    ...Array.isArray(row.relacionadas) ? { relacionadas: conLoPublicado(row.relacionadas, acciones) } : {},
    consultas_leidas: cfg?.consultas_actualizadas ?? null
  };
}
function conLoPublicado(relacionadas2 = [], acciones = []) {
  const norm6 = (u) => String(u || "").replace(/^https?:\/\/(www\.)?/i, "").replace(/\/+$/, "").toLowerCase();
  const tiene = new Set(relacionadas2.map((p) => norm6(p.url)));
  const propias2 = acciones.filter((a) => a.url && a.estado !== "cancelada" && !tiene.has(norm6(a.url))).map((a) => ({
    url: a.url,
    titulo: a.titulo || "",
    clase: TIPOS[a.tipo]?.articulo ? "articulo" : "pagina",
    estado: a.estado === "hecha" ? "Publicado con este objetivo" : ESTADO_ARTICULO[a.ref_estado] ?? "En curso",
    keyword: "",
    hits: 0
  }));
  return [...propias2, ...relacionadas2];
}
async function modulesView(db) {
  const peers = await peersOf(db);
  return { modulos: peers, sabe: peers !== null, acciones: disponibilidad(peers) };
}
async function summary(db, { hoy = /* @__PURE__ */ new Date(), dias = 7 } = {}) {
  const v = await goalsView(db, hoy);
  const corte = new Date(new Date(hoy).getTime() - dias * 864e5).toISOString().slice(0, 10);
  const acc = await db.all("SELECT _id AS id, objetivo, tipo, estado, titulo, url, ref, modulo, ref_estado, fecha, hecha_el FROM " + ACC + " WHERE estado != 'duplicada' AND _deleted = 0 ORDER BY _id DESC");
  const tema = new Map(v.rows.map((r) => [r.id, r.tema]));
  const evo = await db.all("SELECT objetivo, fecha, posicion, fuente FROM " + EVO + " WHERE _deleted = 0 ORDER BY fecha, _id");
  const movidos = [];
  for (const r of v.rows.filter((x) => aprobado(x.estado))) {
    const pts = evo.filter((p) => p.objetivo === r.id && num2(p.posicion) != null);
    const ahora2 = pts.filter((p) => dia(p.fecha) >= corte).pop();
    if (!ahora2) continue;
    const antes = pts.filter((p) => dia(p.fecha) < corte).pop();
    const de2 = antes ? num2(antes.posicion) : r.posicion_base;
    const a = num2(ahora2.posicion);
    if (de2 == null) movidos.push({ id: r.id, tema: r.tema, de: null, a, sube: true, texto: "aparece en la posici\xF3n " + pos1(a) });
    else if (Math.abs(de2 - a) >= 1) movidos.push({ id: r.id, tema: r.tema, de: de2, a, sube: a < de2, texto: (a < de2 ? "sube" : "baja") + " de la " + pos1(de2) + " a la " + pos1(a) });
  }
  const hechas = acc.filter((a) => a.estado === "hecha" && dia(a.hecha_el) >= corte).map((a) => ({ id: a.id, objetivo: a.objetivo, tema: tema.get(a.objetivo) ?? "", texto: TIPOS[a.tipo]?.hecha ?? "Hecho", url: a.url ?? null, fecha: dia(a.hecha_el) }));
  const en_curso = acc.filter((a) => a.estado === "pendiente" || a.estado === "en_curso").map((a) => ({ id: a.id, objetivo: a.objetivo, tema: tema.get(a.objetivo) ?? "", tipo: TIPOS[a.tipo]?.label ?? a.tipo, estado: a.estado, ref_estado: a.ref_estado ? ESTADO_ARTICULO[a.ref_estado] ?? a.ref_estado : null }));
  const ganados = v.rows.filter((r) => r.fase === "ganada" && dia(r.ganada_el) >= corte).map((r) => ({ id: r.id, tema: r.tema, posicion: r.posicion }));
  const te_toca = [
    ...v.rows.filter((r) => r.fase === "estancada").map((r) => ({ id: r.id, tema: r.tema, fase: r.fase, texto: r.siguiente })),
    ...v.rows.filter((r) => ["en_marcha", "subiendo"].includes(r.fase) && r.siguiente_de === "persona").map((r) => ({ id: r.id, tema: r.tema, fase: r.fase, texto: r.siguiente })),
    ...v.rows.filter((r) => r.fase === "por_decidir").slice(0, 5).map((r) => ({ id: r.id, tema: r.tema, fase: r.fase, texto: "Decide: aprobar o descartar." }))
  ];
  const d = await db.one("SELECT conclusion, fecha, dominio FROM oportunidadesseo_diagnosticos WHERE _deleted = 0 ORDER BY _id DESC LIMIT 1").catch(() => null);
  const cfg = await settings(db);
  const filas2 = await consultasUltimas(db, cfg);
  const per = filas2.find((q) => q.desde && q.hasta);
  return {
    dominio: v.dominio,
    mercado: v.mercado,
    top: v.top,
    semanas: v.semanas,
    cuenta: v.cuenta,
    total: v.rows.length,
    diagnostico: d && (!v.dominio || domainOf2(d.dominio) === v.dominio) ? { conclusion: d.conclusion, fecha: d.fecha } : null,
    search_console: filas2.length ? { impresiones: filas2.reduce((n, q) => n + (Number(q.impresiones) || 0), 0), clics: filas2.reduce((n, q) => n + (Number(q.clics) || 0), 0), consultas: new Set(filas2.map((q) => norm2(q.consulta))).size, periodo: per ? per.desde + " a " + per.hasta : null, actualizado: cfg.consultas_actualizadas ?? null } : null,
    semana: { desde: corte, movidos: movidos.sort((a, b) => Number(b.sube) - Number(a.sube)), hechas, ganados, en_curso, te_toca },
    objetivos: v.rows.filter((r) => ["en_marcha", "subiendo", "estancada", "ganada"].includes(r.fase)).slice(0, 8)
  };
}

// server/services/articulos.mjs
var ORIGEN_AQUI = "Oportunidades SEO";
async function readArticles(db) {
  if (typeof db.read !== "function") return { installed: null, articles: [] };
  try {
    const r = await db.read("articles", "published_articles", { origin: ORIGEN_AQUI });
    if (!r || r.installed === false) return { installed: false, articles: [] };
    const list3 = r.result?.articles;
    return { installed: true, articles: Array.isArray(list3) ? list3 : [] };
  } catch (e) {
    return { installed: null, articles: [], error: e.message };
  }
}
async function readKinds(db) {
  if (typeof db.read !== "function") return null;
  try {
    const r = await db.read("articles", "kinds", {});
    const list3 = r?.installed ? r.result : null;
    return Array.isArray(list3) ? list3 : Array.isArray(list3?.rows) ? list3.rows : Array.isArray(list3?.kinds) ? list3.kinds : null;
  } catch {
    return null;
  }
}
async function refreshArticles(db) {
  const r = await readArticles(db);
  if (r.installed === true) {
    const kinds = await readKinds(db);
    const paginas2 = r.articles.filter((a) => a && a.url && a.state === "published").map((a) => ({ url: a.url, titulo: a.title || a.url, clase: "articulo", keyword: a.main_query ?? "", estado: "publicado" }));
    if (paginas2.length || kinds?.length) await syncArticles(db, { tipos: (kinds ?? []).map((k) => ({ key: k.key, label: k.label, description: k.description ?? "", archived: k.archived ? 1 : 0 })), paginas: paginas2, completo: false });
  }
  if (r.installed !== true) return { leido: false, instalado: r.installed, texto: r.installed === false ? "Art\xEDculos no est\xE1 instalado: no hay art\xEDculos que leer." : "No se pudo preguntar a Art\xEDculos ahora" + (r.error ? " (" + r.error + ")" : "") + "." };
  const s = await syncArticleStates(db, r.articles);
  return { leido: true, instalado: true, ...s, texto: s.vinculados ? s.vinculados + " art\xEDculo" + (s.vinculados === 1 ? "" : "s") + " de tus objetivos al d\xEDa" + (s.publicados ? " (" + s.publicados + " publicado" + (s.publicados === 1 ? "" : "s") + ")" : "") + "." : "Ning\xFAn art\xEDculo de Art\xEDculos viene de un objetivo." };
}

// server/integrations.mjs
function integrationsClient(url = process.env.APP_DATA_URL, token = process.env.APP_DATA_TOKEN) {
  return {
    run: async (toolkit, action, args = {}, { account } = {}) => {
      const r = await globalThis.fetch(`${url}/integration`, { method: "POST", headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` }, body: JSON.stringify({ toolkit, action, args, ...account ? { account } : {} }), signal: AbortSignal.timeout(9e4) });
      const j = await r.json().catch(() => null);
      if (!r.ok || !j) throw Object.assign(new Error(j ? [j.error, j.how].filter(Boolean).join(" ") : `Integration ${r.status}`), { status: r.status, code: j?.code ?? null });
      return j;
    }
  };
}

// server/services/searchconsole.mjs
var TOOLKIT = "google_search_console";
var ACCION_CONSULTAS = "GOOGLE_SEARCH_CONSOLE_SEARCH_ANALYTICS_QUERY";
var ACCION_SITIOS = "GOOGLE_SEARCH_CONSOLE_LIST_SITES";
var DIAS = 28;
var RETRASO_DIAS = 3;
var MAX_FILAS = 1e3;
var dia2 = (d) => new Date(d).toISOString().slice(0, 10);
var now6 = () => (/* @__PURE__ */ new Date()).toISOString().slice(0, 19).replace("T", " ");
function listaEn(o, claves, nivel = 0) {
  if (!o || typeof o !== "object" || nivel > 5) return null;
  if (!Array.isArray(o)) {
    for (const k of claves) if (Array.isArray(o[k])) return o[k];
  }
  for (const v of Array.isArray(o) ? o : Object.values(o)) {
    const r = v && typeof v === "object" ? listaEn(v, claves, nivel + 1) : null;
    if (r) return r;
  }
  return null;
}
function propiedadDe(sitios, dominio2) {
  const d = domainOf2(dominio2);
  const urls = (sitios ?? []).map((s) => String(s?.siteUrl ?? s?.site_url ?? s?.url ?? (typeof s === "string" ? s : ""))).filter(Boolean);
  return urls.find((u) => u.toLowerCase() === "sc-domain:" + d) ?? urls.find((u) => /^https:/i.test(u) && domainOf2(u) === d) ?? urls.find((u) => /^https?:/i.test(u) && domainOf2(u) === d) ?? null;
}
function filasDe(result) {
  const rows = listaEn(result, ["rows"]) ?? [];
  return rows.map((r) => {
    const k = Array.isArray(r?.keys) ? r.keys : [r?.query, r?.page];
    return { consulta: String(k[0] ?? "").trim(), pagina: String(k[1] ?? "").trim(), clics: Number(r?.clicks) || 0, impresiones: Number(r?.impressions) || 0, ctr: r?.ctr ?? null, posicion: r?.position ?? null };
  }).filter((r) => r.consulta);
}
var refusal = (e) => new Refused(e.message, e.status && e.status >= 400 && e.status < 600 ? e.status : 502);
async function refreshSearchConsole(db, { desde, hasta } = {}, integ = integrationsClient(), hoy = /* @__PURE__ */ new Date()) {
  const cfg = await settings(db);
  const dom2 = domainOf2(cfg.dominio);
  if (!dom2) throw new Refused("Falta el dominio en Ajustes (General \u2192 Dominio).", 400);
  const account = String(cfg.cuenta_gsc || "").trim() || void 0;
  let propiedad = String(cfg.propiedad_gsc || "").trim();
  if (!propiedad) {
    const r2 = await integ.run(TOOLKIT, ACCION_SITIOS, {}, { account }).catch((e) => {
      throw refusal(e);
    });
    const sitios = listaEn(r2.result, ["siteEntry", "site_entry", "sites"]) ?? [];
    propiedad = propiedadDe(sitios, dom2);
    if (!propiedad) throw new Refused("La cuenta de Search Console conectada no tiene la propiedad de " + dom2 + (sitios.length ? " (tiene " + sitios.map((s2) => s2?.siteUrl ?? s2?.site_url ?? s2).slice(0, 5).join(", ") + ")" : "") + ". A\xF1ade " + dom2 + " a esa cuenta en Search Console, o escribe la propiedad exacta en Ajustes \u2192 \xABPropiedad de Search Console\xBB.", 409);
    await db.update(A, cfg._id, { propiedad_gsc: propiedad });
  }
  const fin = hasta || dia2(new Date(hoy).getTime() - RETRASO_DIAS * 864e5);
  const ini = desde || dia2(Date.parse(fin + "T00:00:00Z") - (DIAS - 1) * 864e5);
  const r = await integ.run(TOOLKIT, ACCION_CONSULTAS, { site_url: propiedad, start_date: ini, end_date: fin, dimensions: ["query", "page"], row_limit: MAX_FILAS }, { account }).catch((e) => {
    throw refusal(e);
  });
  const consultas = filasDe(r.result);
  const s = await saveQueries(db, { consultas, desde: ini, hasta: fin });
  const o = consultas.length ? await recordSearchConsole(db, { desde: ini, hasta: fin }) : { objetivos: 0 };
  await db.update(A, cfg._id, { consultas_actualizadas: now6() });
  return {
    guardadas: s.guardadas,
    desde: ini,
    hasta: fin,
    propiedad,
    cuenta: r.connection ?? null,
    objetivos: o.objetivos,
    texto: consultas.length ? s.guardadas + " b\xFAsquedas de " + ini + " a " + fin + (o.objetivos ? "; " + o.objetivos + " objetivos con su posici\xF3n de esta semana" : "") + "." : "Search Console no tiene b\xFAsquedas de " + dom2 + " entre " + ini + " y " + fin + "."
  };
}

// server/services/ejemplo.mjs
var REALES = ["dataforseo", "ahrefs", "diagnostico"];
var list2 = (s) => String(s ?? "").split(/[;\n]/).map((x) => x.trim()).filter(Boolean);
var SUBTEMAS = ["Qu\xE9 es y cu\xE1ndo tiene sentido", "Costes o tarifas", "Ventajas e inconvenientes", "Proceso paso a paso", "Preguntas frecuentes"];
function sampleResearch(row, competitors, cfg = {}) {
  const own = domainOf2(cfg.dominio);
  const doms = competitors.filter((d) => d && d !== own);
  const kw = row.keyword || row.tema || "";
  const serp = doms.slice(0, 10).map((dominio2, i) => ({ pos: i + 1, dominio: dominio2, url: "https://" + dominio2 + "/", titulo: "Ejemplo: una p\xE1gina de " + dominio2 + " sobre \xAB" + kw + "\xBB", dr: null, trafico: null, cubre: SUBTEMAS.filter((_, j) => (i + j) % 2 === 0) }));
  const angulo = row.angulo ? "\xC1ngulo propuesto: " + String(row.angulo).split(/[.:](\s|$)/)[0].slice(0, 160) : "\xC1ngulo propio" + (own ? " de " + own : "");
  const huecos = [...SUBTEMAS, angulo].map((tema) => {
    const cubren = [...new Set(serp.filter((s) => s.cubre.includes(tema)).map((s) => s.dominio))];
    return { tema, cubren, competidores: cubren, propio: false };
  });
  const keywords = [row.keyword, ...list2(row.secundarias)].filter(Boolean).map((keyword, i) => ({ keyword, volumen: null, dificultad: null, principal: i === 0 }));
  return { serp, huecos, keywords };
}
async function fillSample(db, { id }) {
  const row = await db.one("SELECT * FROM " + T + " WHERE _id = ? AND _deleted = 0", [id]);
  if (!row) throw new Refused("Esa oportunidad ya no est\xE1.", 404);
  if (REALES.includes(row.serp_origen) || REALES.includes(row.origen)) throw new Refused("Ya tiene datos reales: un ejemplo no se mezcla con ellos. Para actualizarlos, \xABTraer datos de DataForSEO\xBB.");
  const cfg = await settings(db);
  const comps = competitorsOf(cfg);
  if (!comps.length) throw new Refused("El ejemplo se hace con los competidores de Ajustes y a\xFAn no hay ninguno: a\xF1\xE1delos en Ajustes \u2192 Competidores.", 400);
  const s = sampleResearch(row, comps, cfg);
  await db.update(T, id, { serp: JSON.stringify(s.serp), huecos: JSON.stringify(s.huecos), keywords: JSON.stringify(s.keywords), serp_origen: "ejemplo", ...row.origen ? {} : { origen: "ejemplo" } });
  return { id, serp: s.serp.length, huecos: s.huecos.length, origen: "ejemplo", aviso: "Es un ejemplo sin cifras: muestra c\xF3mo se ver\xE1, no dice nada del mercado." };
}
async function sampleGaps(db) {
  const cfg = await settings(db);
  if (cfg.huecos_buscados || await db.one("SELECT _id FROM " + H + " WHERE COALESCE(origen, '') != 'ejemplo' AND _deleted = 0")) throw new Refused("Ya hay huecos reales de DataForSEO: no se mezclan con ejemplos.");
  const semillas = list2(cfg.semillas);
  if (!semillas.length) throw new Refused("El ejemplo se hace con los temas semilla de Ajustes y a\xFAn no hay ninguno (General \u2192 Temas semilla).", 400);
  const comps = competitorsOf(cfg);
  let n = 0;
  for (const s of semillas.slice(0, 12)) {
    const keyword = s.toLowerCase();
    if (await db.one("SELECT _id FROM " + H + " WHERE keyword = ? AND _deleted = 0", [keyword])) continue;
    await db.insert(H, { keyword, volumen: null, dificultad: null, intencion: null, competidores: comps.length ? comps.join("; ") : "Sin competidores en Ajustes (ejemplo)", mejor_posicion: null, estado: "nuevo", origen: "ejemplo", por_que: "Ejemplo sin cifras: uno de tus temas semilla" });
    n++;
  }
  return { creados: n, origen: "ejemplo", aviso: "Son ejemplos sin cifras (tus temas semilla): los reales llegan con \xABBuscar huecos\xBB." };
}

// server/services/publico.mjs
var I = "oportunidadesseo_ideas";
var MAX_PALABRAS = 6;
var LIMITE_SUG = 50;
var LIMITE_REL = 50;
var PROFUNDIDAD = 2;
var MAX_IDEAS = 30;
var TOP_IDEAS = 10;
var CACHE_HORAS = 168;
var MAX_LOTE = 1e3;
var RELEVANCIA_PUBLICO = 25;
var PUENTE_MIN = 30;
var PUENTE_MAX = 400;
var FILTROS_PUBLICO = { ...FILTROS, intencion: "No busca informarse", ajena: "No es de tu p\xFAblico", existe: "Ya la tienes" };
var splitList4 = (s) => String(s ?? "").split(/[;\n]/).map((x) => x.trim()).filter(Boolean);
var now7 = ahora;
var truthy = (x) => x === true || x === "true" || x === 1;
function audienceWords(cfg) {
  const propias2 = splitList4(String(cfg.temas_publico ?? "").replace(/,/g, ";"));
  const limpia = (l) => [...new Map(l.map((x) => x.trim().replace(/\s+/g, " ").toLowerCase()).filter((x) => x.length >= 3 && x.split(" ").length <= 4 && content(x).length).map((x) => [norm(x), x])).values()].slice(0, MAX_PALABRAS);
  if (propias2.length) return { palabras: limpia(propias2), de: "ajustes" };
  const cabeza = String(cfg.publico ?? "").split(/[.;:(]|\s+(?:que|en|para|con|sin|de cara a)\s+/i)[0];
  return { palabras: limpia(cabeza.split(/,|\s+(?:y|e|o|u)\s+/i)), de: "publico" };
}
var intents2 = (si) => [...new Set([intentOf(si?.main_intent), ...(si?.foreign_intent ?? []).map(intentOf)].filter(Boolean))];
var item = (kd, palabra, fuente) => {
  const k = String(kd?.keyword || "").toLowerCase().trim();
  if (!k) return null;
  const ii = intents2(kd.search_intent_info);
  return { keyword: k, volumen: kd.keyword_info?.search_volume ?? null, dificultad: kdOf(kd.keyword_properties?.keyword_difficulty), kd_leido: kd.keyword_properties?.keyword_difficulty != null, intencion: ii[0] ?? null, intenciones: ii.slice(1), palabra, fuente };
};
var clave = (palabra, cfg, vmin) => "publico:" + norm(palabra) + ":" + Number(cfg.ubicacion) + ":" + norm(cfg.idioma) + ":" + vmin;
async function deUnaPalabra(db, keys, cfg, m, palabra, { forzar = false } = {}) {
  const w = where(cfg);
  const vmin = Number(cfg.volumen_min) || 0;
  const c = forzar ? null : await cacheGet(db, clave(palabra, cfg, vmin), { maxHoras: CACHE_HORAS });
  if (c?.valor?.items) return { items: c.valor.items, cache: true };
  const fallos = [];
  const una = async (path, task, leer3) => {
    try {
      return leer3(await dfs(keys, "dataforseo_labs/google/" + path + "/live", { ...task, ...w }, m));
    } catch (e) {
      if (e.status === 424 || e.status === 429) throw e;
      fallos.push(path + ": " + e.message);
      return [];
    }
  };
  const [sug, rel] = await Promise.all([
    una(
      "keyword_suggestions",
      { keyword: palabra, limit: LIMITE_SUG, include_serp_info: false, include_seed_keyword: false, ...vmin ? { filters: [["keyword_info.search_volume", ">=", vmin]] } : {}, order_by: ["keyword_info.search_volume,desc"] },
      (r) => (r.items ?? []).map((x) => item({ ...x, search_intent_info: x.search_intent_info ?? x.keyword_data?.search_intent_info }, palabra, "sugerencia")).filter(Boolean)
    ),
    una(
      "related_keywords",
      { keyword: palabra, depth: PROFUNDIDAD, limit: LIMITE_REL, include_serp_info: false, include_seed_keyword: false, ...vmin ? { filters: [["keyword_data.keyword_info.search_volume", ">=", vmin]] } : {}, order_by: ["keyword_data.keyword_info.search_volume,desc"] },
      (r) => (r.items ?? []).map((x) => item(x.keyword_data, palabra, "relacionada")).filter(Boolean)
    )
  ]);
  const items = [...sug, ...rel];
  if (!fallos.length) await cacheSet(db, clave(palabra, cfg, vmin), { items });
  return { items, cache: false, fallos };
}
var SUGGEST_URL = "https://suggestqueries.google.com/complete/search";
var SUGGEST_TIMEOUT_MS = 8e3;
var MAX_ASI = 5;
var MAX_SUELTAS = 20;
var PREGUNTAS = { es: ["c\xF3mo", "qu\xE9", "cu\xE1nto"], en: ["how", "what", "why"] };
async function autocompletar(db, net, palabra, cfg, { forzar = false } = {}) {
  const hl = norm(cfg.idioma) || "es", gl = norm(cfg.pais) || "";
  const k = "suggest:" + norm(palabra) + ":" + hl + ":" + gl;
  const c = forzar ? null : await cacheGet(db, k, { maxHoras: CACHE_HORAS });
  if (c?.valor?.frases) return { frases: c.valor.frases, cache: true };
  if (typeof net !== "function") return { frases: [], error: "sin acceso a la red" };
  const qs = [palabra, palabra + " ", ...(PREGUNTAS[hl.slice(0, 2)] ?? []).map((q) => q + " " + palabra)];
  const frases = [];
  const fallos = [];
  await pool(qs, 2, async (q) => {
    try {
      const r = await net(SUGGEST_URL + "?client=firefox&ie=utf-8&oe=utf-8&hl=" + encodeURIComponent(hl) + (gl ? "&gl=" + encodeURIComponent(gl) : "") + "&q=" + encodeURIComponent(q), { headers: { Accept: "application/json" }, signal: AbortSignal.timeout(SUGGEST_TIMEOUT_MS) });
      if (r.status !== 200) {
        fallos.push("responde " + r.status);
        return;
      }
      const j = JSON.parse(await r.text());
      for (const f of Array.isArray(j?.[1]) ? j[1] : []) {
        const t = String(typeof f === "string" ? f : f?.[0] ?? "").toLowerCase().trim().replace(/\s+/g, " ");
        if (t && t.length <= 80 && !frases.includes(t)) frases.push(t);
      }
    } catch (e) {
      fallos.push(e.cause?.code || e.name || e.message);
    }
  });
  if (frases.length) await cacheSet(db, k, { frases });
  return { frases, cache: false, ...fallos.length && !frases.length ? { error: fallos[0] } : {} };
}
function comoLoEscriben(keyword, frases) {
  const a = [...new Set(content(keyword))];
  if (!a.length) return [];
  const dentro3 = (x, y) => x.every((t) => y.includes(t));
  return frases.filter((f) => {
    if (norm(f) === norm(keyword)) return false;
    const b = [...new Set(content(f))];
    return b.length > 0 && (dentro3(a, b) || dentro3(b, a));
  }).slice(0, MAX_ASI);
}
async function completar(keys, cfg, m, cands) {
  const w = where(cfg);
  const avisos = [];
  const sinInt = cands.filter((c) => !c.intencion).slice(0, MAX_LOTE);
  if (sinInt.length) {
    try {
      const r = await dfs(keys, "dataforseo_labs/google/search_intent/live", { keywords: sinInt.map((c) => c.keyword), language_code: w.language_code }, m);
      const por = new Map((r.items ?? []).map((x) => [String(x.keyword || "").toLowerCase(), x]));
      for (const c of sinInt) {
        const x = por.get(c.keyword);
        if (!x) continue;
        c.intencion = intentOf(x.keyword_intent?.label);
        c.intenciones = (x.secondary_keyword_intents ?? []).map((s) => intentOf(s.label)).filter(Boolean);
      }
    } catch (e) {
      if (e.status === 424 || e.status === 429) throw e;
      avisos.push("No se pudo leer la intenci\xF3n de " + sinInt.length + " b\xFAsquedas (" + e.message + "): se quedan sin intenci\xF3n y no entran.");
    }
  }
  const sinKd = cands.filter((c) => !c.kd_leido).slice(0, MAX_LOTE);
  if (sinKd.length) {
    try {
      const r = await dfs(keys, "dataforseo_labs/google/bulk_keyword_difficulty/live", { keywords: sinKd.map((c) => c.keyword), ...w }, m);
      const por = new Map((r.items ?? []).map((x) => [String(x.keyword || "").toLowerCase(), x.keyword_difficulty]));
      for (const c of sinKd) c.dificultad = kdOf(por.get(c.keyword));
    } catch (e) {
      if (e.status === 424 || e.status === 429) throw e;
      avisos.push("No se pudo leer la dificultad de " + sinKd.length + " b\xFAsquedas (" + e.message + "): quedan \xABsin dato\xBB.");
    }
  }
  return avisos;
}
function filterAudience(cands, cfg, { lugares = [], palabras = [], existentes = /* @__PURE__ */ new Set() } = {}) {
  const base = context(cfg, { ideas: [], lugares });
  const V = vocabOf([...palabras, cfg.publico || ""]);
  const ctx = { ...base, S: V, P: V, R: /* @__PURE__ */ new Set(), semillas: palabras, kdmax: null, rmin: RELEVANCIA_PUBLICO };
  const fuera = [];
  const quedan = [];
  for (const c of cands) {
    if (existentes.has(norm(c.keyword))) {
      fuera.push({ ...c, filtro: "existe", motivo: "Ya es una oportunidad o un hueco tuyo" });
      continue;
    }
    const ints = [c.intencion, ...c.intenciones ?? []].filter(Boolean);
    if (!c.intencion) {
      fuera.push({ ...c, filtro: "intencion", motivo: "DataForSEO no da su intenci\xF3n: sin saber qu\xE9 busca quien la escribe, no entra" });
      continue;
    }
    if (!ints.includes("informacional") && c.intencion !== "comercial") {
      fuera.push({ ...c, filtro: "intencion", motivo: "Quien la busca quiere " + (c.intencion === "navegacional" ? "ir a una web concreta" : "comprar ya") + ", no informarse: un art\xEDculo no le sirve" });
      continue;
    }
    quedan.push(c);
  }
  const f = filterGaps(quedan, ctx);
  const todas = [...fuera, ...f.fuera.map((x) => x.filtro === "ajena" ? { ...x, motivo: "No es de tu p\xFAblico: ninguna de sus palabras casa con " + palabras.map((p) => "\xAB" + p + "\xBB").join(", ") } : x)];
  const conteo = Object.fromEntries(Object.keys(FILTROS_PUBLICO).map((k) => [k, todas.filter((x) => x.filtro === k).length]));
  return { pasan: f.pasan.map((x) => ({ ...x, palabra: x.semilla || x.palabra })), fuera: todas, conteo };
}
async function findAudienceIdeas(db, input = {}, keys = keysClient(), net = globalThis.fetch) {
  const forzar = truthy(input?.forzar);
  return withMeter(db, "buscar_ideas_publico", async (m) => {
    const cfg = await settings(db);
    const w0 = audienceWords(cfg);
    if (!w0.palabras.length) throw new Refused("Falta decir qu\xE9 busca tu p\xFAblico: en Ajustes \u2192 General \u2192 \xABQu\xE9 busca tu p\xFAblico en su d\xEDa a d\xEDa\xBB escribe de 3 a 6 palabras cortas separadas por \xAB;\xBB (no tu producto: lo que esa gente busca, p. ej. \xABaut\xF3nomos; facturas; pymes\xBB), o rellena \xABP\xFAblico\xBB.", 400);
    where(cfg);
    const avisos = [];
    if (modoOf(cfg) === "producto") avisos.push("Ajustes \u2192 Modo dice \xABLo que vendemos\xBB: estas ideas se guardan, pero el Radar no las ense\xF1a hasta que el modo sea \xABLo que buscan nuestros clientes\xBB o \xABAmbos\xBB.");
    const [leidas, sugeridas] = await Promise.all([
      pool(w0.palabras, 4, (p) => deUnaPalabra(db, keys, cfg, m, p, { forzar })),
      pool(w0.palabras, 2, (p) => autocompletar(db, net, p, cfg, { forzar }))
    ]);
    const frases = [...new Set(sugeridas.flatMap((x) => x.frases))];
    if (sugeridas.every((x) => x.error)) avisos.push("No se pudo leer el autocompletado de Google (" + sugeridas[0].error + "): las ideas van sin \xABc\xF3mo lo escribe la gente\xBB.");
    else if (m?.notas) m.notas.push("autocompletado de Google: " + frases.length + " sugerencias (sin coste)");
    const enCache = leidas.filter((x) => x.cache).length;
    if (enCache && m?.notas) m.notas.push(enCache + " de " + w0.palabras.length + " palabras del p\xFAblico, de las guardadas");
    for (const x of leidas) for (const f of x.fallos ?? []) avisos.push("Labs " + f + ".");
    const por = /* @__PURE__ */ new Map();
    for (const x of leidas) for (const it of x.items) {
      const k = norm(it.keyword);
      if (!por.has(k)) por.set(k, { ...it });
    }
    const cands = [...por.values()];
    avisos.push(...await completar(keys, cfg, m, cands));
    let lug = { nombres: [] };
    if (cands.length) {
      try {
        lug = await places(db, keys, cfg, m);
      } catch (e) {
        if (e.status === 424 || e.status === 429) throw e;
        avisos.push("No se pudo leer la lista de ciudades: no se descartan b\xFAsquedas de otras ciudades.");
      }
    }
    if (lug.aviso) avisos.push(lug.aviso);
    const existentes = new Set((await db.all("SELECT keyword FROM " + T + " WHERE _deleted = 0")).map((r) => norm(r.keyword)));
    const res = filterAudience(cands, cfg, { lugares: lug.nombres, palabras: w0.palabras, existentes });
    const buscado = now7();
    let nuevas = 0, actualizadas = 0;
    for (const g of res.pasan.slice(0, MAX_IDEAS)) {
      const data = {
        keyword: g.keyword,
        volumen: g.volumen ?? null,
        dificultad: kdOf(g.dificultad),
        intencion: g.intencion ?? null,
        palabra: g.palabra ?? null,
        fuente: g.fuente ?? null,
        relevancia: g.relevancia,
        puntuacion: g.ganable,
        por_que: g.por_que,
        variantes: (g.variantes ?? []).join("; "),
        asi_lo_escriben: comoLoEscriben(g.keyword, frases).join("; "),
        buscado,
        origen: "dataforseo"
      };
      const ex = await db.one("SELECT _id FROM " + I + " WHERE keyword = ? AND _deleted = 0", [g.keyword]);
      if (ex) {
        await db.update(I, ex._id, data);
        actualizadas++;
      } else {
        await db.insert(I, { ...data, estado: "nueva" });
        nuevas++;
      }
    }
    const conocidas = new Set(cands.map((x) => norm(x.keyword)));
    const sueltas = frases.filter((f) => !conocidas.has(norm(f)) && !res.pasan.some((g) => comoLoEscriben(g.keyword, [f]).length)).slice(0, MAX_SUELTAS);
    await db.update(A, cfg._id, { ideas_buscadas: buscado, ideas_filtro: JSON.stringify({ autocompletar: sueltas, autocompletar_n: frases.length, palabras: w0.palabras, palabras_de: w0.de, candidatas: cands.length, pasan: res.pasan.length, guardadas: Math.min(MAX_IDEAS, res.pasan.length), por_filtro: res.conteo, fecha: buscado }) });
    const sinPuente = await db.all("SELECT _id AS id, keyword, volumen, palabra FROM " + I + " WHERE estado = 'nueva' AND COALESCE(puente, '') = '' AND _deleted = 0 ORDER BY puntuacion DESC LIMIT ?", [MAX_IDEAS]);
    return {
      palabras: w0.palabras,
      candidatas: cands.length,
      pasan: res.pasan.length,
      nuevas,
      actualizadas,
      por_filtro: res.conteo,
      sin_puente: sinPuente.length,
      autocompletado: frases.length,
      siguiente: sinPuente.length ? "Escribe el puente de cada una con guardar_puentes (o di que no lo tiene): sin puente no se ense\xF1an. Las que esperan: " + sinPuente.map((x) => "#" + x.id + " \xAB" + x.keyword + "\xBB").join(", ") + "." : "Todas las ideas guardadas tienen ya su puente.",
      avisos
    };
  });
}
function bridgeProblem(puente) {
  const t = String(puente ?? "").trim().replace(/\s+/g, " ");
  if (!t) return "est\xE1 vac\xEDo";
  if (t.length < PUENTE_MIN) return "es demasiado corto (" + t.length + " caracteres): di el \xE1ngulo del art\xEDculo y a qu\xE9 lleva";
  if (t.length > PUENTE_MAX) return "es demasiado largo (" + t.length + " caracteres; m\xE1ximo " + PUENTE_MAX + "): una frase";
  return null;
}
async function saveBridges(db, { puentes } = {}) {
  let rows = puentes;
  if (typeof rows === "string") {
    try {
      rows = JSON.parse(rows);
    } catch {
      rows = null;
    }
  }
  if (!Array.isArray(rows) || !rows.length) throw new Refused("puentes es una lista: [{ id, puente, producto }] o [{ id, sin_puente: true, motivo }].", 400);
  const out = { guardados: 0, descartadas: 0, rechazados: [] };
  for (const r of rows.slice(0, 100)) {
    const idea = r?.id ? await db.one("SELECT _id, keyword, estado FROM " + I + " WHERE _id = ? AND _deleted = 0", [Number(r.id)]) : null;
    if (!idea) {
      out.rechazados.push({ id: r?.id ?? null, por: "esa idea no existe" });
      continue;
    }
    if (idea.estado === "convertida") {
      out.rechazados.push({ id: idea._id, por: "ya es una oportunidad: su puente se cambia all\xED (\xE1ngulo)" });
      continue;
    }
    if (truthy(r.sin_puente)) {
      await db.update(I, idea._id, { estado: "descartada", puente: "", motivo: "Sin puente: " + (String(r.motivo ?? "").trim() || "no lleva a nada que la empresa venda") });
      out.descartadas++;
      continue;
    }
    const mal = bridgeProblem(r.puente);
    if (mal) {
      out.rechazados.push({ id: idea._id, keyword: idea.keyword, por: "el puente " + mal });
      continue;
    }
    await db.update(I, idea._id, { puente: String(r.puente).trim().replace(/\s+/g, " "), producto: String(r.producto ?? "").trim() || null, ...idea.estado === "descartada" ? { estado: "nueva", motivo: "" } : {} });
    out.guardados++;
  }
  return out;
}
async function audienceView(db) {
  const cfg = await settings(db);
  const all = (await db.all("SELECT _id AS id, keyword, volumen, dificultad, intencion, palabra, fuente, relevancia, puntuacion, por_que, puente, producto, asi_lo_escriben, estado, motivo, oportunidad, buscado FROM " + I + " WHERE _deleted = 0 ORDER BY puntuacion DESC, volumen DESC")).map((x) => ({ ...x, dificultad: kdOf(x.dificultad), con_puente: !!String(x.puente ?? "").trim() }));
  const vivas = all.filter((x) => x.estado === "nueva");
  const listas = vivas.filter((x) => x.con_puente);
  const w0 = audienceWords(cfg);
  let resumen = null;
  try {
    resumen = JSON.parse(cfg.ideas_filtro || "null");
  } catch {
    resumen = null;
  }
  const costes = await lastCosts(db);
  const n = w0.palabras.length;
  let guardadas = 0;
  try {
    where(cfg);
    for (const p of w0.palabras) if (await cacheGet(db, clave(p, cfg, Number(cfg.volumen_min) || 0), { maxHoras: CACHE_HORAS })) guardadas++;
  } catch {
  }
  const porPalabra = 2 * PRECIOS.labs_tarea + (LIMITE_SUG + LIMITE_REL) * PRECIOS.labs_item;
  const max = (n - guardadas) * porPalabra;
  return {
    modo: modoOf(cfg),
    dominio: domainOf2(cfg.dominio) || null,
    publico: cfg.publico || null,
    palabras: w0.palabras,
    palabras_de: w0.de,
    top: listas.slice(0, TOP_IDEAS),
    listas,
    sin_puente: vivas.filter((x) => !x.con_puente),
    convertidas: all.filter((x) => x.estado === "convertida"),
    descartadas: all.filter((x) => x.estado === "descartada"),
    google_sugiere: resumen?.autocompletar ?? [],
    buscado: cfg.ideas_buscadas ?? null,
    resumen,
    filtros: FILTROS_PUBLICO,
    coste: costes.ultimo.buscar_ideas_publico ?? null,
    estimacion: {
      usd: usd(max),
      palabras: n,
      guardadas,
      texto: !n ? "faltan las palabras del p\xFAblico en Ajustes" : guardadas === n ? "las b\xFAsquedas de tus " + n + " palabras del p\xFAblico est\xE1n guardadas (se leyeron esta semana): no cuesta nada; \xABForzar actualizaci\xF3n\xBB las pide de nuevo" : "por cada palabra del p\xFAblico (" + (n - guardadas) + (guardadas ? " de " + n + "; el resto est\xE1n guardadas" : "") + "), 2 consultas de Labs: keyword_suggestions y related_keywords (hasta " + LIMITE_SUG + " b\xFAsquedas cada una); solo si alguna llega sin intenci\xF3n o sin dificultad, 1 de search_intent y 1 de bulk_keyword_difficulty. Tarda unos 10\u201325 segundos",
      usd_forzar: usd(n * porPalabra)
    },
    criterios: { volumen_min: Number(cfg.volumen_min) || 0, relevancia_min: RELEVANCIA_PUBLICO, max_ideas: MAX_IDEAS, top: TOP_IDEAS }
  };
}
async function ideaToOpportunity(db, { id }) {
  const g = await db.one("SELECT * FROM " + I + " WHERE _id = ? AND _deleted = 0", [id]);
  if (!g) throw new Refused("Esa idea ya no est\xE1.", 404);
  if (g.estado === "convertida" && g.oportunidad) throw new Refused("Ya es la oportunidad n\xBA " + g.oportunidad + ".");
  const mal = bridgeProblem(g.puente);
  if (mal) throw new Refused("Esta idea a\xFAn no tiene puente (" + mal + "): sin una frase que diga c\xF3mo ese art\xEDculo lleva a lo que vendes no pasa a \xABPor decidir\xBB. Escr\xEDbelo (guardar_puentes, o en la propia idea) o desc\xE1rtala.", 409);
  const cfg = await settings(db);
  const ex = await db.one("SELECT _id FROM " + T + " WHERE lower(keyword) = lower(?) AND _deleted = 0", [g.keyword]);
  let op = ex?._id;
  if (!op) {
    const data = {
      tema: temaDe(g.keyword),
      keyword: g.keyword,
      secundarias: g.variantes || null,
      cluster: g.palabra || null,
      volumen: g.volumen,
      dificultad: kdOf(g.dificultad),
      intencion: g.intencion,
      formato: "articulo",
      lectora: cfg.publico || null,
      angulo: g.puente + (g.asi_lo_escriben ? " As\xED lo escribe la gente en Google: " + g.asi_lo_escriben.split("; ").join(", ") + "." : ""),
      puente: g.puente + (g.producto ? " (lleva a: " + g.producto + ")" : ""),
      competencia: null,
      estado: "propuesta",
      origen: "dataforseo"
    };
    const puntuacion = score(data);
    op = await db.insert(T, { ...data, puntuacion, prioridad: priorityOf(puntuacion) });
  }
  await db.update(I, id, { estado: "convertida", oportunidad: op });
  return { id, oportunidad: op };
}

// server/services/ahrefs.mjs
var AHREFS = "ahrefs";
var AHREFS_LIMITES = "AHREFS_RETRIEVE_SUBSCRIPTION_LIMITS_AND_USAGE";
var AHREFS_RESERVA = 5e3;
function campo(o, nombres, nivel = 0) {
  if (o == null || typeof o !== "object" || nivel > 6) return void 0;
  for (const n of nombres) if (o[n] != null && typeof o[n] !== "object") return o[n];
  for (const v of Object.values(o)) {
    const x = campo(v, nombres, nivel + 1);
    if (x !== void 0) return x;
  }
  return void 0;
}
var num3 = (v) => {
  const n = Number(v);
  return v == null || v === "" || !Number.isFinite(n) ? null : n;
};
var miles2 = (n) => String(Math.round(n)).replace(/\B(?=(\d{3})+(?!\d))/g, ".");
function readLimits(result) {
  const lw = num3(campo(result, ["units_limit_workspace"])), uw = num3(campo(result, ["units_usage_workspace"]));
  const lk = num3(campo(result, ["units_limit_api_key"])), uk = num3(campo(result, ["units_usage_api_key"]));
  const quedanW = lw != null && uw != null ? Math.max(0, lw - uw) : null, quedanK = lk != null && uk != null ? Math.max(0, lk - uk) : null;
  const quedan = quedanW != null && quedanK != null ? Math.min(quedanW, quedanK) : quedanW ?? quedanK;
  const renueva = campo(result, ["usage_reset_date"]) ?? null, plan = campo(result, ["subscription"]) ?? null;
  const puede = quedan == null ? null : quedan > AHREFS_RESERVA;
  return {
    plan,
    limite: lw ?? lk,
    usadas: uw ?? uk,
    quedan,
    renueva: renueva ? String(renueva).slice(0, 10) : null,
    puede,
    texto: quedan == null ? "Ahrefs respondi\xF3, pero sin decir cu\xE1ntas unidades quedan: el m\xF3dulo no le pide nada m\xE1s hasta saberlo." : "Quedan " + miles2(quedan) + " unidades de Ahrefs" + (renueva ? " hasta el " + String(renueva).slice(0, 10) : "") + (puede ? "." : ": por debajo de " + miles2(AHREFS_RESERVA) + " el m\xF3dulo no usa Ahrefs, para no gastar las tuyas.")
  };
}
async function ahrefsStatus(db, _input = {}, integ = integrationsClient()) {
  let r;
  try {
    r = await integ.run(AHREFS, AHREFS_LIMITES, {});
  } catch (e) {
    if (e.code || e.status) return { conectado: false, motivo: e.code ?? null, texto: e.message };
    throw new Refused("No se pudo preguntar a Ahrefs: " + e.message, 502);
  }
  return { conectado: true, cuenta: r.connection ?? null, ...readLimits(r.result) };
}

// server/services/breve.mjs
var N = 10;
var corto = (s, n = 160) => {
  const t = String(s ?? "");
  return t.length > n ? t.slice(0, n - 1) + "\u2026" : t;
};
var lleno = (o) => Object.fromEntries(Object.entries(o).filter(([, v]) => v !== null && v !== void 0 && v !== ""));
var lista2 = (rows, pick, n = N) => {
  const l = rows ?? [];
  return { total: l.length, primeras: l.slice(0, n).map((x) => lleno(pick(x))), ...l.length > n ? { mas: l.length - n } : {} };
};
var TODO = (name) => "Brief answer for agents. Everything the screen reads: " + name + " { full: true } (large).";
var BREVE = {
  radar: (r) => ({
    dominio: r.dominio,
    mercado: r.mercado,
    idioma: r.idioma,
    modo: r.modo,
    publico: corto(r.publico, 240),
    competidores: r.competidores,
    objetivos: (r.rows ?? []).length,
    huecos: (r.brechas ?? []).length,
    casi: (r.casi ?? []).length,
    consultas_search_console: (r.consultas ?? []).length,
    leer: "Counts only. Goals: objetivos. What could be won next: descubrir. Positions 8\u201320: casi_lista. The site and its searches: tu_web. " + TODO("radar")
  }),
  objetivos: (r) => ({
    cuenta: r.cuenta,
    dominio: r.dominio,
    mercado: r.mercado,
    objetivos: lista2(r.rows, (g) => ({ id: g.id, keyword: g.keyword, fase: g.fase, posicion: g.posicion, posicion_base: g.posicion_base, acciones: g.acciones_txt || g.acciones, siguiente: corto(g.siguiente, 90), siguiente_de: g.siguiente_de }), 10),
    leer: "One goal whole: oportunidad_detalle { id }. " + TODO("objetivos")
  }),
  /**
   * «Descubrir» for an agent: the counts (per source, what can be won, what is unmeasured), how the site is doing and
   * what to search next, and the FIRST candidates — what can be won first — with what a proposal needs. The rest by
   * asking: fuente (one source), ganar (si | pelear | dificil | tuya | subir | sin_medir), desde and limite (a page).
   */
  descubrir: (r, i = {}) => {
    const limite = Math.max(1, Math.min(40, Math.round(Number(i.limite)) || 8)), desde = Math.max(0, Math.round(Number(i.desde)) || 0);
    const todas = (r.candidatos ?? []).filter((c) => (!i.fuente || c.fuente === i.fuente) && (!i.ganar || c.ganar?.veredicto === i.ganar));
    const pagina = todas.slice(desde, desde + limite);
    return {
      total: r.total,
      por_fuente: Object.fromEntries(Object.entries(r.por_fuente ?? {}).filter(([, n]) => n)),
      ganables: r.ganables,
      peleables: r.peleables,
      dificiles: r.dificiles,
      sin_medir: r.sin_medir,
      no_encajan: r.no_encajan,
      quien: r.quien,
      nivel: r.nivel?.nivel ?? null,
      criterios_despues: r.siguiente?.criterios ?? [],
      ...i.fuente || i.ganar ? { filtradas: todas.length } : {},
      candidatos: pagina.map((c) => ({ busqueda: c.titulo, fuente: c.fuente, volumen: c.volumen ?? null, se_puede_ganar: c.ganar?.veredicto ?? null, ...c.publico?.encaja === false ? { encaja: false } : {}, ...c.posicion != null ? { posicion: c.posicion } : {} })),
      ...todas.length > desde + pagina.length ? { mas: todas.length - desde - pagina.length, siguiente_pagina: { desde: desde + pagina.length, limite } } : {},
      leer: "What can be won goes first. Why, and who ranks, for one: quien_sale { keyword }. Unmeasured: medir_candidatos. More candidates: buscar_nuevas { criterios: criterios_despues }. Converting and discarding are the person's, on screen."
    };
  },
  casi_lista: (r) => ({
    dominio: r.dominio,
    buscados: r.buscados,
    desde: r.desde,
    hasta: r.hasta,
    keywords: lista2([...r.rows ?? []].sort((a, b) => (b.volumen || 0) - (a.volumen || 0)), (k) => ({ id: k.id, keyword: k.keyword, posicion: k.posicion, volumen: k.volumen, url: k.url, propuesta: k.propuesta, estado: k.estado })),
    leer: TODO("casi_lista")
  }),
  competidores_lista: (r) => ({
    buscado: r.buscado,
    competidores: r.competidores,
    nunca: r.nunca,
    coste: r.coste?.texto ?? null,
    repetir_cuesta: r.estimacion?.usd ?? null,
    propuestos: lista2(r.propuestos, (x) => ({ id: x.id, dominio: x.dominio, estado: x.estado, keywords_que_comparte: x.semillas_n, posicion_media: x.posicion_media }), 20),
    descartados: (r.descartados ?? []).length,
    leer: "Adopting one is the person's (adoptar_competidor); a list they give you: importar_competidores. " + TODO("competidores_lista")
  }),
  tu_web: (r, i = {}) => {
    const limite = Math.max(1, Math.min(60, Math.round(Number(i.limite)) || 10)), desde = Math.max(0, Math.round(Number(i.desde)) || 0);
    const rows = r.rows ?? [];
    return {
      dominio: r.dominio,
      resumen: r.resumen,
      search_console: r.search_console ? { periodo: r.search_console.periodo ?? null, actualizado: r.search_console.actualizado ?? null } : null,
      total: rows.length,
      con_objetivo: rows.filter((p) => p.oportunidad).length,
      paginas: rows.slice(desde, desde + limite).map((p) => ({ ruta: p.ruta, clase: p.clase, impresiones: p.impresiones ?? null, posicion: p.posicion ?? null, busquedas: corto(p.consultas_txt, 70) || null, objetivo: p.oportunidad ?? null })),
      ...rows.length > desde + limite ? { mas: rows.length - desde - limite, siguiente_pagina: { desde: desde + limite, limite } } : {},
      leer: "Ordered by what shows most in Google. The next pages: desde, limite."
    };
  },
  descartes_lista: (r) => ({
    buscado: r.buscado,
    resumen: r.resumen,
    umbrales: r.umbrales,
    coste: r.coste?.texto ?? null,
    repetir_cuesta: r.estimacion?.usd ?? null,
    descartadas: lista2(r.rows, (x) => ({ keyword: x.keyword, volumen: x.volumen, filtro: x.filtro, motivo: corto(x.motivo, 100) }), 10),
    leer: TODO("descartes_lista")
  }),
  ideas_publico: (r) => ({
    palabras: r.palabras,
    buscado: r.buscado,
    resumen: r.resumen ? { candidatas: r.resumen.candidatas, pasan: r.resumen.pasan, guardadas: r.resumen.guardadas } : null,
    coste: r.coste?.texto ?? null,
    repetir_cuesta: r.estimacion?.usd ?? null,
    sin_puente: lista2(r.sin_puente, (x) => ({ id: x.id, keyword: x.keyword, volumen: x.volumen, palabra: x.palabra, asi_lo_escriben: corto(x.asi_lo_escriben, 100) }), 30),
    con_puente: lista2(r.listas, (x) => ({ id: x.id, keyword: x.keyword, volumen: x.volumen, puente: corto(x.puente, 80) }), 5),
    convertidas: (r.convertidas ?? []).length,
    descartadas: (r.descartadas ?? []).length,
    leer: "Each idea in sin_puente needs its bridge: guardar_puentes. " + TODO("ideas_publico")
  }),
  novedades_ver: (r) => ({
    conclusion: r.conclusion,
    vigilado: r.vigilado,
    competidores: r.competidores,
    novedades: lista2(r.rows, (x) => ({ id: x.id, competidor: x.competidor, que: corto(x.que, 100), url: x.url, cubierto: !!x.cubierto, objetivo: x.objetivo ?? null, estado: x.estado })),
    leer: TODO("novedades_ver")
  }),
  diagnostico_ver: (r) => {
    const d = r.diagnostico;
    if (!d) return { diagnostico: null, repetir_cuesta: r.estimacion?.usd ?? null, leer: "No diagnosis yet: diagnosticar." };
    let plan = [];
    try {
      plan = typeof d.plan === "string" ? JSON.parse(d.plan) : d.plan ?? [];
    } catch {
      plan = [];
    }
    let tecnico = [];
    try {
      tecnico = typeof d.tecnico === "string" ? JSON.parse(d.tecnico) : d.tecnico ?? [];
    } catch {
      tecnico = [];
    }
    return {
      fecha: d.fecha,
      dominio: d.dominio,
      conclusion: d.conclusion,
      estado_tecnico: d.estado_tecnico,
      cifras: { keywords_top100: d.keywords_top100, keywords_top10: d.keywords_top10, keywords_marca: d.keywords_marca, urls_posicionadas: d.urls_posicionadas, urls_sitemap: d.urls_sitemap },
      problemas_tecnicos: (Array.isArray(tecnico) ? tecnico : []).filter((c) => c.estado === "problema").map((c) => corto(c.detalle || c.titulo, 160)),
      plan: (Array.isArray(plan) ? plan : []).map((p) => ({ keyword: p.keyword, volumen: p.volumen ?? null, nivel: p.nivel ?? null, por_que: corto(p.por_que || p.razon, 160), objetivo: p.oportunidad ?? null })),
      search_console: r.search_console_actual ? { consultas: r.search_console_actual.consultas, impresiones: r.search_console_actual.impresiones, clics: r.search_console_actual.clics } : null,
      repetir_cuesta: r.estimacion?.usd ?? null,
      leer: TODO("diagnostico_ver")
    };
  },
  ia_ver: (r) => ({
    conclusion: r.conclusion,
    revisada: r.revisada,
    marca: r.marca,
    coste: r.coste?.texto ?? null,
    repetir_cuesta: r.estimacion?.usd ?? null,
    temas: lista2(r.temas, (t) => ({ tema: t.tema, tu: t.tu, quien_sale: corto(t.frase, 160), objetivo: t.objetivo ?? null }), 10),
    leer: "The answers themselves and every site cited: ia_ver { completo: true } (large)."
  }),
  /**
   * One goal, for the agent that works it: what it is, how it is going, its actions and the brief to write from
   * (brief_completo is what goes to Artículos: it is here whole, once). The top 10 with every result, the history,
   * the weekly points and the screen's own lists are in { completo: true }.
   */
  oportunidad_detalle: (d, i = {}) => ({
    id: d.id,
    tema: d.tema,
    keyword: d.keyword,
    secundarias: d.secundarias || null,
    estado: d.estado,
    fase: d.fase,
    volumen: d.volumen ?? null,
    dificultad: d.dificultad ?? null,
    intencion: d.intencion ?? null,
    formato: d.formato ?? null,
    tipo: d.tipo ? { id: d.tipo.id, key: d.tipo.key } : null,
    posicion: d.posicion ?? null,
    ganado: d.ganado ?? null,
    semanas_sin_mejora: d.semanas_sin_mejora ?? null,
    nivel: d.nivel ?? null,
    ganable_por: corto(d.ganable_por, 200) || null,
    top10: (d.serp ?? []).slice(0, 10).map((x) => x.dominio),
    acciones: (d.acciones ?? []).map((a) => ({ id: a.id, tipo: a.tipo, estado: a.estado, ...a.modulo ? { modulo: a.modulo, ref: a.ref ?? null, ref_estado: a.ref_estado ?? null } : {}, ...a.url ? { url: a.url } : {} })),
    siguiente_paso: d.siguiente_paso ? { texto: corto(d.siguiente_paso.texto ?? d.siguiente_paso, 200), de: d.siguiente_paso.de ?? null, tipo: d.siguiente_paso.tipo ?? null } : null,
    no_se_puede_anadir: (d.tipos_accion ?? []).filter((t) => (t.disponible ?? t.puede) === false).map((t) => t.tipo ?? t.id),
    // the brief to write from is long: it comes ONCE, when the work is writing (brief: true), never with every look
    ...i.brief === true || i.brief === "true" ? { brief_completo: d.brief_completo } : { brief: corto(d.brief_completo, 200) },
    leer: "To do an action of this goal: oportunidad_detalle { id, brief: true } once (the whole brief, to pass to Art\xEDculos). Every result of the top 10 with its strength, Google's questions, the history and the weekly points: { id, full: true } (large)."
  }),
  /** «Resumen» for an agent: the counts and this week; the goals themselves are in `objetivos`. */
  resumen: (r) => ({
    dominio: r.dominio,
    total: r.total,
    cuenta: r.cuenta,
    diagnostico: r.diagnostico ? { fecha: r.diagnostico.fecha ?? null, conclusion: corto(r.diagnostico.conclusion, 240) } : null,
    search_console: r.search_console ?? null,
    semana: r.semana ? Object.fromEntries(Object.entries(r.semana).map(([k, v]) => [k, Array.isArray(v) ? v.slice(0, 6).map((x) => x && typeof x === "object" ? { id: x.id ?? x.objetivo ?? null, tema: corto(x.tema ?? x.titulo, 60), texto: corto(x.texto, 100) } : x) : v])) : null,
    leer: "Each goal with its state: objetivos. One goal: oportunidad_detalle { id }. Everything the screen reads: resumen { full: true }."
  }),
  /** Before a guided search: what to tell the person and ask them to confirm. */
  preparar_busqueda: (r) => ({
    nivel: r.nivel?.nivel ?? null,
    por_que: corto(r.nivel?.frase, 260),
    recomendados: r.recomendados,
    criterios: (r.criterios ?? []).map((c) => ({ id: c.id, nombre: c.nombre, coste: c.coste, ...c.falta ? { falta: c.falta } : {} })),
    propuesta: Object.fromEntries(Object.entries(r.propuesta ?? {}).map(([k, v]) => [k, { valor: typeof v.valor === "string" ? corto(v.valor, 160) : v.valor, de: v.de, ...v.falta ? { falta: v.falta } : {}, ...v.propuestos?.length ? { propuestos: v.propuestos.slice(0, 5).map((p) => p.dominio) } : {} }])),
    medir: r.medir?.coste ?? null,
    ultima: r.ultima ?? null,
    leer: "Tell the person which criteria you propose and why, what you would use and the cost; then buscar_nuevas { criterios, ajustes: only what they confirmed or corrected }. mercado is one of: " + (r.mercados ?? []).map((m) => m.id).join(", ") + "."
  }),
  gasto_dataforseo: (r) => ({
    total: r.total,
    ejecuciones: r.ejecuciones,
    ultimo: Object.fromEntries(Object.entries(r.ultimo ?? {}).map(([k, v]) => [k, { coste: v.texto, fecha: String(v.fecha || "").slice(0, 10), ...v.resultado && v.resultado !== "ok" ? { resultado: corto(v.resultado, 80) } : {} }])),
    leer: "The calls behind each: gasto_dataforseo { full: true }."
  }),
  /** Who ranks for one search: each result in a few words; titles and addresses are in { full: true }. */
  quien_sale: (r) => ({
    keyword: r.keyword,
    en_cache: r.en_cache,
    ...r.en_cache ? { leido: r.hace, tu_posicion: r.tu_posicion ?? null } : { coste: r.coste, coste_medir: r.coste_medir },
    se_puede_ganar: r.ganar ? { veredicto: r.ganar.veredicto, frase: corto(r.ganar.frase, 220), razones: (r.ganar.razones ?? []).slice(0, 3).map((x) => corto(x, 140)) } : null,
    quien_la_busca: r.lectura ? { lectura: r.lectura.lectura ?? null, encaja: r.lectura.encaja ?? null, frase: corto(r.lectura.frase, 160) } : null,
    resultados: (r.resultados ?? []).map((x) => ({ pos: x.pos, dominio: x.dominio, tipo: x.tipo, ...x.clase ? { fuerza: x.clase } : {}, ...x.tuya ? { tuya: true } : {} })),
    leer: r.en_cache ? "Titles and addresses: quien_sale { keyword, full: true }." : "Nothing kept for this search: medir_candidatos { keywords: [it] } measures it; ver_quien_sale only reads its top 10."
  })
};

// server/services/intencion.mjs
var QUIEN = { compra: "Quien contrata o compra", trabajo: "Quien busca trabajo o formarse", ambas: "Ambos" };
var quienOf = (cfg) => ["compra", "trabajo"].includes(String(cfg?.intencion || "").trim()) ? String(cfg.intencion).trim() : "ambas";
var ETIQUETA = { trabajo: "La busca quien quiere trabajar o formarse", compra: "La busca quien contrata o compra", mixta: "P\xFAblico mezclado" };
var TIPO_RESULTADO = { empleo: "Empleo o carrera", formacion: "Formaci\xF3n", empresa: "Empresa que lo ofrece", otro: "Otro" };
var EMPLEO_DOM = ["indeed.com", "glassdoor.com", "ziprecruiter.com", "monster.com", "builtin.com", "wellfound.com", "levels.fyi", "salary.com", "payscale.com", "talent.com", "simplyhired.com", "careerbuilder.com", "dice.com", "themuse.com", "zippia.com", "careerexplorer.com", "infojobs.net", "computrabajo.com", "getonbrd.com", "remoteok.com", "weworkremotely.com", "jooble.org", "tecnoempleo.com", "bls.gov"];
var FORMACION_DOM = ["coursera.org", "udemy.com", "edx.org", "freecodecamp.org", "geeksforgeeks.org", "w3schools.com", "codecademy.com", "khanacademy.org", "pluralsight.com", "udacity.com", "datacamp.com", "simplilearn.com", "roadmap.sh", "platzi.com", "domestika.org"];
var dentro2 = (dom2, x) => dom2 === x || dom2.endsWith("." + x);
var limpio = (s) => String(s ?? "").toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "");
var T_EMPLEO = /\b(how to become|become an?|careers?|salar(y|ies)|job description|jobs?|resume|cv|interview (questions|prep)|internships?|day in the life|hiring now|what (do|does) .+ do|como ser|cuanto (cobra|gana)|sueldos?|salarios?|empleos?|ofertas de (trabajo|empleo)|practicas|que hace un)\b/;
var T_FORMACION = /\b(courses?|bootcamps?|certifications?|tutorials?|learn|roadmap|for beginners|cursos?|aprende|que estudiar|master en|formacion)\b/;
var T_EMPRESA = /\b(hire|hiring guide|outsourc\w*|staff augmentation|nearshor\w*|offshor\w*|agenc(y|ies)|services?|solutions|consulting|compan(y|ies)|providers?|vendors?|pricing|cost to|rates|dedicated teams?|for (startups|enterprises|businesses)|contratar|empresas?|servicios?|agencias?|consultoria|precios?|presupuesto|proveedores?)\b/;
var P_EMPLEO = /(^|\/)(jobs?|careers?|career-advice|salar(y|ies)|empleo|ofertas)(\/|$)/;
var P_EMPRESA = /(^|\/)(hire[-/]|services?(\/|$)|solutions?(\/|$)|pricing(\/|$)|servicios(\/|$)|contratar)/;
function resultKind({ dominio: dominio2 = "", url = "", titulo = "" } = {}) {
  const dom2 = limpio(dominio2).replace(/^www\./, "");
  const t = limpio(titulo);
  let path = "";
  try {
    path = limpio(new URL(url).pathname);
  } catch {
    path = "";
  }
  if (EMPLEO_DOM.some((x) => dentro2(dom2, x)) || /^(jobs?|careers?|jobsblog|empleo)\./.test(dom2) || P_EMPLEO.test(path) || T_EMPLEO.test(t)) return "empleo";
  if (FORMACION_DOM.some((x) => dentro2(dom2, x)) || T_FORMACION.test(t)) return "formacion";
  if (P_EMPRESA.test(path) || T_EMPRESA.test(t)) return "empresa";
  return "otro";
}
function readQuery(keyword) {
  const k = limpio(keyword);
  const a = k.match(T_EMPLEO) || k.match(T_FORMACION);
  if (a) return { lectura: "trabajo", senal: a[0] };
  const b = k.match(T_EMPRESA);
  if (b) return { lectura: "compra", senal: b[0] };
  return null;
}
var MIN_RESULTADOS = 5;
var de = (n, total, uno, varios) => n + " de " + total + " " + (n === 1 ? uno : varios);
function readSerp(top10) {
  const filas2 = (top10 ?? []).map((x) => ({ ...x, tipo: resultKind(x) }));
  const n = filas2.length;
  const c = { empleo: 0, formacion: 0, empresa: 0, otro: 0 };
  for (const f of filas2) c[f.tipo]++;
  if (n < MIN_RESULTADOS) return { lectura: "sin_dato", n, ...c, filas: filas2, frase: "No hay bastantes resultados legibles para saber qui\xE9n la busca." };
  const buscan = c.empleo + c.formacion;
  const lectura = buscan / n >= 0.5 ? "trabajo" : c.empresa / n >= 0.4 && buscan <= 2 ? "compra" : "mixta";
  const frase = lectura === "trabajo" ? de(buscan, n, "resultado es", "resultados son") + " ofertas de empleo, gu\xEDas de carrera o formaci\xF3n: quien busca esto quiere trabajar o aprender, no contratar." : lectura === "compra" ? de(c.empresa, n, "resultado es", "resultados son") + " de empresas que lo ofrecen: quien busca esto quiere contratar o comprar." : "P\xFAblico mezclado: " + [buscan ? buscan + " de empleo o formaci\xF3n" : "", c.empresa ? c.empresa + " de empresas que lo ofrecen" : "", c.otro ? c.otro + " de otro tipo (foros, definiciones, medios)" : ""].filter(Boolean).join(", ") + ".";
  return { lectura, n, ...c, filas: filas2, frase };
}
function fit({ keyword, top10 = null } = {}, quien = "ambas") {
  const s = top10 ? readSerp(top10) : null;
  const q = readQuery(keyword);
  let lectura = null, origen = null, frase = null;
  if (s && s.lectura !== "sin_dato") {
    lectura = s.lectura;
    origen = "top10";
    frase = s.frase;
  } else if (q) {
    lectura = q.lectura;
    origen = "palabras";
    frase = "Por sus palabras (\xAB" + q.senal + "\xBB), la busca " + (q.lectura === "trabajo" ? "quien quiere trabajar o formarse" : "quien quiere contratar o comprar") + ". Su top 10 lo dir\xE1 con m\xE1s seguridad.";
  }
  const encaja = quien === "ambas" || !lectura || lectura === "mixta" ? null : lectura === quien;
  return { lectura, de: origen, frase, etiqueta: lectura ? ETIQUETA[lectura] : null, encaja };
}

// server/services/medir.mjs
var MEDIDA_DIAS = 30;
var MAX_MEDIR = 10;
var MODO_MEDIDA = "advanced";
var PRECIO_MEDIR = { por_busqueda: 2e-3, fijo: 0.03 };
var costeMedir = (n) => n > 0 ? PRECIO_MEDIR.fijo + PRECIO_MEDIR.por_busqueda * n : 0;
var norm3 = (s) => String(s ?? "").toLowerCase().replace(/[¿?¡!«»"“”:;.,()]/g, " ").replace(/\s+/g, " ").trim();
var medidaClave = (keyword, w) => "medida:" + norm3(keyword) + ":" + w.location_code + ":" + w.language_code;
var truthy2 = (x) => x === true || x === "true" || x === 1;
async function medir(db, keys, m, cfg, keywords, { forzar = false } = {}) {
  const w = where(cfg);
  const kws = [...new Map((keywords ?? []).map((k) => String(k || "").trim()).filter(Boolean).map((k) => [norm3(k), k])).values()].slice(0, MAX_MEDIR);
  if (!kws.length) return [];
  const paran = (e) => {
    if (e.status === 424 || e.status === 429) throw e;
    return null;
  };
  const [ov, res] = await Promise.all([
    dfs(keys, "dataforseo_labs/google/keyword_overview/live", { keywords: kws, ...w }, m).catch(paran),
    serpBatch(keys, kws, w, m, { db, forzar, modo: MODO_MEDIDA })
  ]);
  const cifras = new Map((ov?.items ?? []).map((x) => [norm3(x.keyword), x]));
  const own = domainOf2(cfg.dominio);
  const tops = /* @__PURE__ */ new Map();
  for (const k of kws) {
    const sr = res.get(k);
    tops.set(k, sr && !sr.error ? { sr, o: organicTop(sr.items, { n: 10 }) } : null);
  }
  const rivales = [...new Set([...tops.values()].filter(Boolean).flatMap((t) => t.o.validos.map((x) => x.dominio)).filter((d) => d !== own))];
  const [tr, au] = rivales.length ? await Promise.all([trafico2(db, keys, rivales, w, m), autoridad(db, keys, rivales, m)]) : [{ etv: /* @__PURE__ */ new Map(), medido: false }, { opr: /* @__PURE__ */ new Map(), medido: false }];
  const out = [];
  for (const k of kws) {
    const g = cifras.get(norm3(k));
    const t = tops.get(k);
    const gan = t?.o.fiable ? winnability(t.o.validos, { own, etv: tr.etv, cfg, medido: tr.medido, opr: au.opr }) : null;
    const serp = t ? (gan?.resultados ?? t.o.validos).map((x) => ({ pos: x.pos, url: x.url, dominio: x.dominio, titulo: x.titulo, fuente: x.fuente, dr: null, trafico: x.etv ?? null, autoridad: x.autoridad ?? null, clase: x.clase ?? null, porque: x.porque ?? null, cubre: [] })) : null;
    const fuerte2 = (gan?.resultados ?? []).filter((r) => r.clase === "fuerte").sort((a, b) => a.pos - b.pos)[0] ?? null;
    const data = {
      keyword: k,
      volumen: g?.keyword_info?.search_volume ?? null,
      dificultad: kdOf(g?.keyword_properties?.keyword_difficulty),
      intencion: intentOf(g?.search_intent_info?.main_intent) ?? null,
      con_cifras: !!g,
      serp,
      top10: !!serp,
      ganabilidad: gan ? { flojos: gan.flojos, total: gan.total, pequenos: gan.pequenos, portales: gan.portales, fuertes: gan.fuertes, sin_dato: gan.sin_dato, propia_posicion: gan.propia_posicion, nivel: gan.nivel, autoridad_media: gan.autoridad_media, autoridad_medidos: gan.autoridad_medidos, mas_fuerte: fuerte2 ? { dominio: fuerte2.dominio, pos: fuerte2.pos, etv: fuerte2.etv ?? null, oficial: fuerte2.tipo === "oficial" } : null, fecha: ahora() } : null,
      nivel: gan?.nivel ?? null,
      ganable_por: gan ? gan.texto : serp ? "No se pudo medir: Google ense\xF1a menos de 5 resultados que sean webs para esta b\xFAsqueda (fichas, mapas o enlaces suyos)." : null,
      preguntas: t ? { ...materialDe(t.sr.items), fecha: t.sr.fecha ?? ahora() } : null,
      ...t ? {} : { sin_top10: res.get(k)?.error || "sin respuesta" },
      fecha: ahora()
    };
    if (data.con_cifras || data.top10) await cacheSet(db, medidaClave(k, w), data);
    out.push(data);
  }
  return out;
}
async function medidasDe(db, keywords, cfg) {
  let w;
  try {
    w = where(cfg);
  } catch {
    return /* @__PURE__ */ new Map();
  }
  const claves = new Map((keywords ?? []).map((k) => [medidaClave(k, w), k]));
  const out = /* @__PURE__ */ new Map();
  const todas = [...claves.keys()];
  for (let i = 0; i < todas.length; i += 200) {
    const trozo = todas.slice(i, i + 200);
    const rows = await db.all("SELECT clave, valor, fecha FROM " + CACHE + " WHERE _deleted = 0 AND clave IN (" + trozo.map(() => "?").join(", ") + ") ORDER BY _id", trozo);
    for (const r of rows) {
      if (!(horasDesde(r.fecha) < MEDIDA_DIAS * 24)) continue;
      const v = parse(r.valor, null);
      if (v && (v.con_cifras || v.top10)) out.set(claves.get(r.clave), { ...v, fecha: r.fecha });
    }
  }
  return out;
}
var plural = (n, uno, varios) => n + " " + (n === 1 ? uno : varios);
var GANAR = { si: "Se puede ganar", pelear: "Se puede pelear", dificil: "Dif\xEDcil hoy", tuya: "Ya es tuya: defi\xE9ndela", subir: "Ya est\xE1s cerca: s\xFAbela", sin_medir: "Sin medir todav\xEDa", sin_lectura: "No se pudo medir" };
var GANAR_TONO = { si: "good", pelear: "warn", dificil: "bad", tuya: "good", subir: "good", sin_medir: "neutral", sin_lectura: "neutral" };
var GANAR_ORDEN = { tuya: 0, subir: 0, si: 1, pelear: 2, sin_medir: 3, sin_lectura: 3, dificil: 4 };
function lecturaGanar(medida, { publico = null, posicion = null, coste = null } = {}) {
  const razones = [];
  const vol = medida?.volumen;
  if (medida?.con_cifras || vol != null) razones.push(vol == null ? "DataForSEO no tiene cu\xE1ntas veces se busca." : vol < 10 ? "Se busca muy poco (menos de 10 veces al mes): vale si quien la busca es justo tu cliente." : "Se busca unas " + miles(vol) + " veces al mes.");
  const g = medida?.ganabilidad ?? null;
  const pos = g?.propia_posicion ?? (posicion != null && Number(posicion) > 0 ? Math.round(Number(posicion)) : null);
  if (publico?.encaja === false) razones.push("Ojo: no parece que la busque tu p\xFAblico. " + (publico.frase || ""));
  else if (publico?.encaja === true && publico.frase) razones.push(publico.frase);
  const fin = (veredicto, frase) => ({ veredicto, titulo: GANAR[veredicto], tono: GANAR_TONO[veredicto], frase, razones, medida: !!g, posicion: pos });
  if (!medida || !medida.top10) {
    if (pos != null && pos <= 3) return fin("tuya", "Tu web ya sale en la posici\xF3n " + pos + ". No hay que ganarla: hay que mantenerla al d\xEDa para que nadie te la quite.");
    if (pos != null && pos <= 10) return fin("subir", "Tu web ya sale en la posici\xF3n " + pos + ", en la primera p\xE1gina. Los tres primeros se llevan casi todos los clics: mejorar esa p\xE1gina es lo m\xE1s rentable.");
    const kd = medida?.dificultad;
    return fin("sin_medir", "A\xFAn no se ha mirado qui\xE9n sale hoy en Google para esta b\xFAsqueda, que es lo que dice si se puede ganar." + (kd != null ? " DataForSEO le da una dificultad de " + kd + " sobre 100, pero es una estimaci\xF3n." : "") + (coste ? " Medirla cuesta " + coste + "." : ""));
  }
  if (!g || g.nivel == null) return fin("sin_lectura", medida.ganable_por || "Google ense\xF1a pocos resultados que sean webs para esta b\xFAsqueda: no se puede decir qui\xE9n es fuerte.");
  const flojos = g.flojos ?? 0, total = g.total ?? 0, fuerte2 = g.mas_fuerte;
  const quienes = [g.pequenos ? plural(g.pequenos, "web peque\xF1a", "webs peque\xF1as") : "", g.portales ? plural(g.portales, "foro, directorio o medio", "foros, directorios o medios") : ""].filter(Boolean).join(" y ");
  razones.unshift(flojos ? "De los " + total + " resultados que salen hoy, " + flojos + (flojos === 1 ? " es flojo" : " son flojos") + " (" + quienes + ")." : "Los " + total + " resultados que salen hoy son webs fuertes.");
  if (fuerte2) razones.push("El m\xE1s fuerte: " + fuerte2.dominio + ", en la posici\xF3n " + fuerte2.pos + (fuerte2.oficial ? " (un organismo oficial)." : fuerte2.etv != null ? " (unas " + miles(fuerte2.etv) + " visitas al mes)." : "."));
  if (pos != null && pos <= 3) return fin("tuya", "Tu web ya sale en la posici\xF3n " + pos + ". No hay que ganarla: hay que mantenerla al d\xEDa para que nadie te la quite.");
  if (pos != null && pos <= 10) return fin("subir", "Tu web ya sale en la posici\xF3n " + pos + ", en la primera p\xE1gina. Los tres primeros se llevan casi todos los clics: mejorar esa p\xE1gina es lo m\xE1s rentable.");
  if (g.nivel === "alta") return fin("si", "S\xED: " + (flojos === total ? "todos los resultados" : "la mitad o m\xE1s de los resultados") + " que salen hoy son webs peque\xF1as, foros o directorios. Una p\xE1gina bien hecha sobre esto puede entrar en la primera p\xE1gina.");
  if (g.nivel === "media") return fin("pelear", "Se puede, con trabajo: hay algunos resultados flojos, pero la mayor\xEDa son webs con fuerza. Cuenta con una p\xE1gina muy buena y con algo m\xE1s que la acompa\xF1e (enlaces desde tu web, un caso real).");
  return fin("dificil", "Hoy es dif\xEDcil: casi todo lo que sale son webs grandes. Puedes elegirla igualmente; cuenta con meses y con m\xE1s de una acci\xF3n. Una versi\xF3n m\xE1s concreta de esta b\xFAsqueda (m\xE1s larga, con tu ciudad o tu tipo de cliente) suele ser m\xE1s f\xE1cil de ganar.");
}
var medidaBreve = (md) => !md ? null : { volumen: md.volumen ?? null, dificultad: md.dificultad ?? null, intencion: md.intencion ?? null, top10: !!md.top10, nivel: md.nivel ?? null, flojos: md.ganabilidad?.flojos ?? null, total: md.ganabilidad?.total ?? null, propia_posicion: md.ganabilidad?.propia_posicion ?? null, fecha: md.fecha };
async function medirCandidatos(db, { keywords, max, forzar } = {}, keys = keysClient(), { candidatos: candidatos2 = [] } = {}) {
  const n = Math.max(1, Math.min(MAX_MEDIR, Math.round(Number(max)) || MAX_MEDIR));
  const dadas = (Array.isArray(keywords) ? keywords : typeof keywords === "string" && keywords.trim() ? keywords.split(/[;\n]/) : []).map((k) => String(k || "").trim()).filter(Boolean);
  const lista5 = (dadas.length ? dadas : candidatos2.filter((c) => !c.medida?.top10 && c.publico?.encaja !== false).map((c) => c.titulo)).slice(0, n);
  if (!lista5.length) return { medidas: 0, pedidas: 0, texto: dadas.length ? "No hay ninguna b\xFAsqueda que medir." : "Todo lo que hay en \xABDescubrir\xBB ya est\xE1 medido.", coste_usd: 0, coste: usd(0) };
  return withMeter(db, "medir_candidatos", async (m) => {
    const cfg = await settings(db);
    const r = await medir(db, keys, m, cfg, lista5, { forzar: truthy2(forzar) });
    const con = r.filter((x) => x.top10);
    const cuenta = (v) => r.filter((x) => lecturaGanar(x).veredicto === v).length;
    return {
      pedidas: lista5.length,
      medidas: con.length,
      sin_top10: r.filter((x) => !x.top10).map((x) => x.keyword),
      se_pueden_ganar: cuenta("si"),
      se_pueden_pelear: cuenta("pelear"),
      dificiles: cuenta("dificil"),
      ya_tuyas: cuenta("tuya") + cuenta("subir"),
      busquedas: r.map((x) => ({ keyword: x.keyword, volumen: x.volumen, dificultad: x.dificultad, se_puede_ganar: lecturaGanar(x).veredicto, por_que: x.ganable_por }))
    };
  });
}
async function heredar(db, id) {
  const row = id ? await db.one("SELECT * FROM " + T + " WHERE _id = ? AND _deleted = 0", [id]) : null;
  if (!row || !row.keyword || row.serp_origen === "dataforseo" || row.serp_origen === "diagnostico") return false;
  const cfg = await settings(db);
  const md = (await medidasDe(db, [row.keyword], cfg)).get(row.keyword);
  if (!md) return false;
  const data = {};
  if (md.con_cifras) {
    Object.assign(data, {
      volumen: md.volumen ?? row.volumen ?? null,
      dificultad: md.dificultad ?? kdOf(row.dificultad),
      potencial: md.volumen ?? row.potencial ?? null,
      intencion: md.intencion ?? row.intencion ?? null,
      origen: "dataforseo",
      keywords: JSON.stringify([{ keyword: row.keyword, volumen: md.volumen ?? null, dificultad: md.dificultad ?? null, principal: true }])
    });
  }
  if (md.top10) {
    Object.assign(data, { serp: JSON.stringify(md.serp), serp_origen: "dataforseo", preguntas: JSON.stringify(md.preguntas ?? {}), ganabilidad: md.ganabilidad ? JSON.stringify(md.ganabilidad) : null, nivel: md.nivel ?? null, ganable_por: md.ganable_por ?? null });
    if (row.serp_origen === "ejemplo") data.huecos = JSON.stringify([]);
  }
  if (!Object.keys(data).length) return false;
  const puntuacion = score({ ...row, ...data });
  await db.update(T, id, { ...data, puntuacion, prioridad: priorityOf(puntuacion) });
  return true;
}
var idsDe = (r) => [r?.oportunidad, r?.objetivo, r?.id_objetivo, ...Array.isArray(r?.oportunidades) ? r.oportunidades : []].filter((x) => Number.isInteger(x) && x > 0);
var conMedida = (db, fn) => async (i, ctx) => {
  const r = await fn(i, ctx);
  let heredadas = 0;
  for (const id of idsDe(r)) if (await heredar(db, id).catch(() => false)) heredadas++;
  return heredadas ? { ...r, con_datos: true } : r;
};

// server/services/top10.mjs
var TOP10_DIAS = 30;
var vista = (keyword, items, fecha, cfg, md = null) => {
  const fuerza = new Map((md?.serp ?? []).map((x) => [x.dominio, x]));
  const own = domainOf2(cfg.dominio);
  const o = organicTop(items, { n: 10, own });
  const s = readSerp(o.validos);
  const tuya = o.validos.find((x) => own && (x.dominio === own || x.dominio.endsWith("." + own)));
  return {
    keyword,
    en_cache: true,
    fecha,
    hace: haceTxt(horasDesde(fecha)),
    resultados: s.filas.map((x) => ({ pos: x.pos, dominio: x.dominio, titulo: x.titulo, url: x.url, tipo: x.tipo, tipo_txt: TIPO_RESULTADO[x.tipo], tuya: !!own && (x.dominio === own || x.dominio.endsWith("." + own)), ...fuerza.get(x.dominio)?.clase ? { clase: fuerza.get(x.dominio).clase, porque: fuerza.get(x.dominio).porque ?? null } : {} })),
    lectura: { ...fit({ keyword, top10: o.validos }, quienOf(cfg)), empleo: s.empleo, formacion: s.formacion, empresa: s.empresa, otro: s.otro, n: s.n },
    tu_posicion: tuya?.pos ?? null,
    fiable: o.fiable,
    medida: medidaBreve(md)
  };
};
async function top10Guardados(db, keywords, cfg) {
  let w;
  try {
    w = where(cfg);
  } catch {
    return /* @__PURE__ */ new Map();
  }
  const claves = /* @__PURE__ */ new Map();
  for (const k of keywords) for (const modo of MODOS) claves.set(serpClave(k, w, modo), k);
  const out = /* @__PURE__ */ new Map();
  const todas = [...claves.keys()];
  for (let i = 0; i < todas.length; i += 200) {
    const trozo = todas.slice(i, i + 200);
    const rows = await db.all("SELECT clave, valor, fecha FROM " + CACHE + " WHERE _deleted = 0 AND clave IN (" + trozo.map(() => "?").join(", ") + ") ORDER BY _id", trozo);
    for (const r of rows) {
      if (!(horasDesde(r.fecha) < TOP10_DIAS * 24)) continue;
      let v = null;
      try {
        v = JSON.parse(r.valor);
      } catch {
        v = null;
      }
      const k = claves.get(r.clave);
      if (v?.items && (!out.has(k) || String(out.get(k).fecha) < String(r.fecha))) out.set(k, { items: v.items, fecha: r.fecha });
    }
  }
  return out;
}
async function top10View(db, { keyword } = {}) {
  const k = String(keyword || "").trim();
  if (!k) throw new Refused("Di de qu\xE9 b\xFAsqueda: { keyword }.", 400);
  const cfg = await settings(db);
  const g = (await top10Guardados(db, [k], cfg)).get(k);
  const md = (await medidasDe(db, [k], cfg).catch(() => /* @__PURE__ */ new Map())).get(k) ?? null;
  const publico = fit({ keyword: k, top10: g ? organicTop(g.items, { n: 10 }).validos : null }, quienOf(cfg));
  const ganar = lecturaGanar(md, { publico, coste: usd(costeMedir(1)) });
  if (g) return { ...vista(k, g.items, g.fecha, cfg, md), ganar, coste_medir: usd(costeMedir(1)) };
  const precio = await serpPrecio(db, serpModo(cfg)).catch(() => ({ usd: 2e-3 }));
  return { keyword: k, en_cache: false, coste: usd(precio.usd), coste_medir: usd(costeMedir(1)), lectura: publico, ganar, medida: medidaBreve(md) };
}
async function top10Fetch(db, { keyword, forzar } = {}, keys = keysClient()) {
  const k = String(keyword || "").trim();
  if (!k) throw new Refused("Di de qu\xE9 b\xFAsqueda: { keyword }.", 400);
  return withMeter(db, "ver_top10", async (m) => {
    const cfg = await settings(db);
    const w = where(cfg);
    const r = (await serpBatch(keys, [k], w, m, { db, modo: serpModo(cfg), forzar: forzar === true || forzar === "true" })).get(k);
    if (!r || r.error) throw new Refused("Google no respondi\xF3 para \xAB" + k + "\xBB" + (r?.error ? " (" + r.error + ")" : "") + ". Prueba de nuevo en un momento.", 502);
    return { ...vista(k, r.items, r.fecha, cfg), pedido: r.metodo === "live" };
  });
}

// server/services/diagnostico.mjs
var DG = "oportunidadesseo_diagnosticos";
var now8 = () => (/* @__PURE__ */ new Date()).toISOString().slice(0, 19).replace("T", " ");
var splitList5 = (s) => String(s ?? "").split(/[;\n]/).map((x) => x.trim()).filter(Boolean);
var parse2 = (v, d) => {
  if (v == null || v === "") return d;
  if (typeof v !== "string") return v;
  try {
    return JSON.parse(v);
  } catch {
    return d;
  }
};
var n0 = (v) => miles(v || 0);
var RANKED_LIMIT = 100;
var MAX_SERP = 8;
var MAX_SERP_TOTAL = 16;
var PLAN_N = 5;
var MAX_SITEMAPS = 30;
var MAX_NIVELES = 3;
var UA = "Mozilla/5.0 (compatible; OportunidadesSEO/1.0; revision tecnica)";
async function getPublic(url, net, keys) {
  const errs = [];
  if (net) {
    try {
      const r = await net(url, { redirect: "follow", headers: { "User-Agent": UA, Accept: "*/*" }, signal: AbortSignal.timeout(1e4) });
      const headers = {};
      r.headers?.forEach?.((v, k) => {
        headers[String(k).toLowerCase()] = v;
      });
      return { via: "directa", status: r.status, url: r.url || url, headers, body: String(await r.text()).slice(0, 3e6) };
    } catch (e) {
      errs.push("petici\xF3n directa: " + (e.cause?.code || e.message));
    }
  }
  try {
    const r = await keys.fetch(url, { method: "GET", headers: { "User-Agent": UA } });
    const headers = Object.fromEntries(Object.entries(r.headers || {}).map(([k, v]) => [k.toLowerCase(), v]));
    return { via: "plataforma", status: r.status, url: r.url || url, headers, body: String(r.body ?? "") };
  } catch (e) {
    errs.push("plataforma: " + e.message);
  }
  return { via: null, error: errs.join(" \xB7 ") };
}
var JS = "(function(){var q=function(s){return document.querySelector(s)};var mr=q('meta[name=robots]'),mg=q('meta[name=googlebot]'),c=q('link[rel=canonical]');return {robots:mr?mr.getAttribute('content'):null,googlebot:mg?mg.getAttribute('content'):null,canonical:c?c.getAttribute('href'):null,locs:document.getElementsByTagName('loc').length,text:((document.body&&document.body.innerText)||(document.documentElement&&document.documentElement.textContent)||'').slice(0,20000)}})()";
async function viaOnPage(url, keys, m) {
  const r = await dfs(keys, "on_page/instant_pages", { url, custom_js: JS }, m);
  const it = (r.items ?? [])[0];
  if (!it) return { via: null, error: "DataForSEO On-Page no devolvi\xF3 la p\xE1gina" };
  const js = typeof it.custom_js_response === "object" && it.custom_js_response ? it.custom_js_response : null;
  return { via: "dataforseo_onpage", status: it.status_code ?? null, url: it.url || url, headers: {}, body: null, js, meta: it.meta ?? {} };
}
function fetcher(net, keys, m, log, { pagar = true } = {}) {
  let onpage = !!keys && pagar;
  return async (url) => {
    const r = await getPublic(url, net, keys);
    if (r.via) {
      log.add(r.via);
      return r;
    }
    if (onpage) {
      try {
        const o = await viaOnPage(url, keys, m);
        if (o.via) {
          log.add(o.via);
          return o;
        }
        return { via: null, error: r.error + " \xB7 " + o.error };
      } catch (e) {
        if (e.status === 429) throw e;
        onpage = false;
        return { via: null, error: r.error + " \xB7 DataForSEO On-Page: " + e.message };
      }
    }
    return r;
  };
}
function parseRobots(text) {
  const groups = [];
  const sitemaps = [];
  let cur = null;
  let lastWasAgent = false;
  for (const raw2 of String(text || "").split(/\r?\n/)) {
    const line = raw2.replace(/#.*$/, "").trim();
    if (!line) continue;
    const i = line.indexOf(":");
    if (i < 0) continue;
    const k = line.slice(0, i).trim().toLowerCase(), v = line.slice(i + 1).trim();
    if (k === "sitemap") {
      if (v) sitemaps.push(v);
      continue;
    }
    if (k === "user-agent") {
      if (!lastWasAgent || !cur) {
        cur = { agents: [], rules: [] };
        groups.push(cur);
      }
      cur.agents.push(v.toLowerCase());
      lastWasAgent = true;
      continue;
    }
    lastWasAgent = false;
    if (!cur) continue;
    if (k === "disallow" || k === "allow") cur.rules.push({ allow: k === "allow", path: v });
  }
  return { groups, sitemaps };
}
var ruleRe = (p) => new RegExp("^" + p.replace(/[.+?^{}()|[\]\\]/g, "\\$&").replace(/\*/g, ".*").replace(/\\\$$/, "$"));
function blocked(robots, path, agent = "googlebot") {
  const g = robots.groups.filter((x) => x.agents.some((a) => a !== "*" && agent.startsWith(a)));
  const rules = (g.length ? g : robots.groups.filter((x) => x.agents.includes("*"))).flatMap((x) => x.rules).filter((r) => r.path);
  let best = null;
  for (const r of rules) if (ruleRe(r.path).test(path) && (!best || r.path.length > best.path.length || r.path.length === best.path.length && r.allow)) best = r;
  return best && !best.allow ? best : null;
}
var check = (id, nombre, estado, detalle, extra = {}) => ({ id, nombre, estado, detalle, ...extra });
var locsOf = (b) => [...String(b || "").matchAll(/<loc>\s*(?:<!\[CDATA\[)?\s*([^<\]\s]+)\s*(?:\]\]>)?\s*<\/loc>/gi)].map((x) => x[1].replace(/&amp;/g, "&"));
var esSitemap = (u) => {
  try {
    return /\.xml(\.gz)?$/i.test(new URL(u).pathname);
  } catch {
    return /\.xml(\.gz)?(\?|$)/i.test(String(u));
  }
};
async function followSitemaps(sm, get3) {
  const urls = [];
  const vistos = /* @__PURE__ */ new Set([sm.url]);
  let leidos = 0, sinLeer = 0;
  const cola = [{ body: sm.body, nivel: 0 }];
  if (sm.body == null) return { urls: Array.from({ length: sm.locsJs || 0 }, () => null), nota: "", hijos: 0 };
  while (cola.length) {
    const { body, nivel } = cola.shift();
    const indice = /<sitemapindex/i.test(body);
    for (const loc of locsOf(body)) {
      if (!indice && !esSitemap(loc)) {
        urls.push(loc);
        continue;
      }
      if (vistos.has(loc)) continue;
      vistos.add(loc);
      if (/\.gz$/i.test(loc) || nivel + 1 > MAX_NIVELES || leidos >= MAX_SITEMAPS) {
        sinLeer++;
        continue;
      }
      leidos++;
      const r = await get3(loc);
      if (!r.via || r.status !== 200) {
        sinLeer++;
        continue;
      }
      if (r.body != null) cola.push({ body: r.body, nivel: nivel + 1 });
      else urls.push(...Array.from({ length: r.js?.locs || 0 }, () => null));
    }
  }
  return { urls, hijos: leidos, nota: leidos ? " (en " + leidos + " sitemap" + (leidos === 1 ? "" : "s") + " hijo" + (leidos === 1 ? "" : "s") + (sinLeer ? "; " + sinLeer + " no se " + (sinLeer === 1 ? "pudo" : "pudieron") + " leer: al menos" : "") + ")" : sinLeer ? " (" + sinLeer + " sitemap" + (sinLeer === 1 ? "" : "s") + " hijo" + (sinLeer === 1 ? "" : "s") + " sin leer: al menos)" : "" };
}
var FUENTE = { directa: "Lectura directa de la web", plataforma: "Lectura de la web (plataforma)", dataforseo_onpage: "DataForSEO On-Page" };
async function technical(dom2, cfg, get3) {
  const out = [];
  const blog = cfg.ruta_blog || "/blog/";
  const rb = await get3("https://" + dom2 + "/robots.txt");
  let robots = { groups: [], sitemaps: [] };
  if (!rb.via) out.push(check("robots", "robots.txt: \xBFbloquea a Google?", "no_comprobado", "No se pudo leer robots.txt: " + rb.error));
  else {
    const text = rb.body ?? rb.js?.text ?? null;
    if (rb.status === 404 || rb.status === 410 || rb.status >= 400 && rb.status < 500) out.push(check("robots", "robots.txt: \xBFbloquea a Google?", "bien", "No hay robots.txt (responde " + rb.status + "): Google entiende que puede entrar en todo.", { fuente: FUENTE[rb.via] }));
    else if (rb.status >= 500) out.push(check("robots", "robots.txt: \xBFbloquea a Google?", "problema", "robots.txt responde con error " + rb.status + ": mientras falle, Google deja de rastrear la web.", { grave: true, fuente: FUENTE[rb.via] }));
    else if (text == null) out.push(check("robots", "robots.txt: \xBFbloquea a Google?", "no_comprobado", "robots.txt existe (" + rb.status + ") pero no se pudo leer su contenido.", { fuente: FUENTE[rb.via] }));
    else {
      robots = parseRobots(text);
      const all = blocked(robots, "/"), b = blocked(robots, blog);
      if (all) out.push(check("robots", "robots.txt: \xBFbloquea a Google?", "problema", "Bloquea la web entera a Google (Disallow: " + all.path + ").", { grave: true, fuente: FUENTE[rb.via] }));
      else if (b) out.push(check("robots", "robots.txt: \xBFbloquea a Google?", "problema", "Bloquea el blog (" + blog + ") a Google (Disallow: " + b.path + ").", { grave: true, fuente: FUENTE[rb.via] }));
      else out.push(check("robots", "robots.txt: \xBFbloquea a Google?", "bien", "No bloquea la home ni " + blog + " a Google" + (robots.sitemaps.length ? "; declara " + robots.sitemaps.length + " sitemap" + (robots.sitemaps.length > 1 ? "s" : "") : "") + ".", { fuente: FUENTE[rb.via] }));
    }
  }
  const hm = await get3("https://" + dom2 + "/");
  if (!hm.via) {
    out.push(check("noindex", "Home: \xBFse puede indexar? (meta robots / noindex)", "no_comprobado", "No se pudo leer la home: " + hm.error));
    out.push(check("canonical", "Home: canonical", "no_comprobado", "No se pudo leer la home: " + hm.error));
  } else {
    const html = hm.body;
    const metas = html != null ? [...html.matchAll(/<meta\b[^>]*>/gi)].map((x) => x[0]).filter((t) => /name\s*=\s*["']?(robots|googlebot)["'\s>]/i.test(t)).map((t) => (t.match(/content\s*=\s*["']([^"']*)["']/i) || [])[1] || "") : [hm.js?.robots, hm.js?.googlebot].filter((x) => x != null);
    const xr = hm.headers?.["x-robots-tag"] || "";
    const leido = html != null || hm.js;
    if (!(hm.status >= 200 && hm.status < 300)) out.push(check("noindex", "Home: \xBFse puede indexar? (meta robots / noindex)", "problema", "La home responde " + hm.status + ": Google no puede indexarla.", { grave: true, fuente: FUENTE[hm.via] }));
    else if (!leido) out.push(check("noindex", "Home: \xBFse puede indexar? (meta robots / noindex)", "no_comprobado", "La home responde " + hm.status + ", pero no se pudo leer su HTML.", { fuente: FUENTE[hm.via] }));
    else if ([...metas, xr].some((v) => /noindex|none/i.test(v))) out.push(check("noindex", "Home: \xBFse puede indexar? (meta robots / noindex)", "problema", "La home pide no salir en Google (" + [...metas, xr].find((v) => /noindex|none/i.test(v)) + ").", { grave: true, fuente: FUENTE[hm.via] }));
    else out.push(check("noindex", "Home: \xBFse puede indexar? (meta robots / noindex)", "bien", "Responde " + hm.status + " y no tiene noindex" + (metas.length ? " (meta robots: \xAB" + metas.join(", ") + "\xBB)" : " (no declara meta robots: se indexa)") + (xr ? "; cabecera X-Robots-Tag: " + xr : "") + ".", { fuente: FUENTE[hm.via] }));
    const href = html != null ? [...html.matchAll(/<link\b[^>]*>/gi)].map((x) => x[0]).filter((t) => /rel\s*=\s*["']?canonical["'\s>]/i.test(t)).map((t) => (t.match(/href\s*=\s*["']([^"']*)["']/i) || [])[1])[0] ?? null : hm.js ? hm.js.canonical ?? null : hm.meta?.canonical ?? void 0;
    if (href === void 0 || !leido) out.push(check("canonical", "Home: canonical", "no_comprobado", "No se pudo leer el canonical de la home.", { fuente: FUENTE[hm.via] }));
    else if (!href) out.push(check("canonical", "Home: canonical", "bien", "No declara canonical en el HTML que sirve: Google usa la propia direcci\xF3n (en una home est\xE1 bien).", { fuente: FUENTE[hm.via] }));
    else {
      let abs;
      try {
        abs = new URL(href, hm.url || "https://" + dom2 + "/");
      } catch {
        abs = null;
      }
      const host = (u) => String(u || "").toLowerCase().replace(/^www\./, "");
      if (!abs) out.push(check("canonical", "Home: canonical", "problema", "El canonical no es una direcci\xF3n v\xE1lida: \xAB" + href + "\xBB.", { grave: true, fuente: FUENTE[hm.via] }));
      else if (host(abs.hostname) !== host(dom2)) out.push(check("canonical", "Home: canonical", "problema", "Apunta a otro dominio (" + abs.href + "): Google puede indexar ese en lugar de " + dom2 + ".", { grave: true, fuente: FUENTE[hm.via] }));
      else if (abs.pathname.replace(/\/+$/, "") !== "") out.push(check("canonical", "Home: canonical", "problema", "Apunta a otra p\xE1gina (" + abs.href + "): Google puede no indexar la home.", { grave: true, fuente: FUENTE[hm.via] }));
      else out.push(check("canonical", "Home: canonical", "bien", "Apunta a s\xED misma (" + abs.href + ").", { fuente: FUENTE[hm.via] }));
    }
  }
  const cands = [.../* @__PURE__ */ new Set([...robots.sitemaps, "https://" + dom2 + "/sitemap.xml", "https://" + dom2 + "/sitemap_index.xml"])];
  let sm = null;
  const fallos = [];
  let leidos = 0;
  for (const u of cands.slice(0, 4)) {
    const r = await get3(u);
    if (!r.via) {
      fallos.push(u + ": " + r.error);
      continue;
    }
    leidos++;
    if (r.status !== 200) {
      fallos.push(u + " responde " + r.status);
      continue;
    }
    const body = r.body;
    const locsJs = r.js?.locs;
    if (body == null && !locsJs) {
      fallos.push(u + ": responde 200 pero no se pudo leer");
      continue;
    }
    sm = { url: u, body, locsJs, via: r.via };
    break;
  }
  let urls_sitemap = null;
  let sitemap_urls = null;
  if (sm) {
    const leido = await followSitemaps(sm, get3);
    const urls = leido.urls;
    const nota = leido.nota;
    const reales = urls.filter(Boolean);
    const ajenas = reales.filter((u) => {
      try {
        return new URL(u).hostname.replace(/^www\./, "") !== dom2;
      } catch {
        return true;
      }
    });
    urls_sitemap = urls.length;
    sitemap_urls = [...new Set(reales.filter((u) => !ajenas.includes(u)))].slice(0, MAX_URLS_SITEMAP);
    if (!urls.length) out.push(check("sitemap", "sitemap.xml: existe, URLs y acceso", "problema", "Existe (" + sm.url + ") pero no tiene URLs.", { fuente: FUENTE[sm.via] }));
    else if (ajenas.length) out.push(check("sitemap", "sitemap.xml: existe, URLs y acceso", "problema", sm.url + " tiene " + ajenas.length + " de " + urls.length + " URLs de otro dominio (p. ej. " + ajenas[0] + ").", { fuente: FUENTE[sm.via] }));
    else out.push(check("sitemap", "sitemap.xml: existe, URLs y acceso", "bien", "Accesible en " + sm.url + " con " + urls.length + " URL" + (urls.length === 1 ? "" : "s") + nota + ".", { fuente: FUENTE[sm.via] }));
  } else if (leidos && fallos.every((f) => / responde (404|410)$/.test(f))) out.push(check("sitemap", "sitemap.xml: existe, URLs y acceso", "problema", "No hay sitemap (" + cands.slice(0, 4).join(", ") + " no existen) y robots.txt no declara ninguno: Google tarda m\xE1s en descubrir p\xE1ginas nuevas.", { fuente: "Lectura de la web" }));
  else out.push(check("sitemap", "sitemap.xml: existe, URLs y acceso", leidos ? "problema" : "no_comprobado", (leidos ? "El sitemap no responde bien: " : "No se pudo leer el sitemap: ") + fallos.join(" \xB7 ")));
  return { checks: out, urls_sitemap, sitemap_urls, sitemap: sm?.url ?? null };
}
var MAX_URLS_SITEMAP = 2e3;
var SITEMAP_CLAVE = "sitemap";
async function guardarSitemap(db, dom2, tec) {
  if (!tec.sitemap_urls) return null;
  return cacheSet(db, SITEMAP_CLAVE, { dominio: dom2, sitemap: tec.sitemap, total: tec.urls_sitemap, urls: tec.sitemap_urls });
}
async function readSitemap(db, _input = {}, keys = keysClient(), net = globalThis.fetch) {
  const cfg = await settings(db);
  const dom2 = domainOf2(cfg.dominio);
  if (!dom2) throw new Refused("Falta el dominio en Ajustes (General \u2192 Dominio).", 400);
  const tec = await technical(dom2, cfg, fetcher(net, keys, null, /* @__PURE__ */ new Set(), { pagar: false }));
  const sm = tec.checks.find((c) => c.id === "sitemap");
  if (!tec.sitemap_urls) throw new Refused("No se pudo leer el sitemap de " + dom2 + ": " + (sm?.detalle || "no responde") + " Sin sitemap, \xABTu web\xBB se llena con lo que Art\xEDculos importe y con Search Console.", 424);
  await guardarSitemap(db, dom2, tec);
  return { dominio: dom2, sitemap: tec.sitemap, urls: tec.sitemap_urls.length, total: tec.urls_sitemap };
}
async function rankedNow(dom2, cfg, keys, m) {
  const r = await dfs(keys, "dataforseo_labs/google/ranked_keywords/live", { target: dom2, ...where(cfg), item_types: ["organic"], load_rank_absolute: false, limit: RANKED_LIMIT, order_by: ["keyword_data.keyword_info.search_volume,desc"] }, m);
  const items = (r.items ?? []).map((it) => ({ keyword: String(it.keyword_data?.keyword || ""), posicion: it.ranked_serp_element?.serp_item?.rank_group ?? null, url: it.ranked_serp_element?.serp_item?.url ?? null, volumen: it.keyword_data?.keyword_info?.search_volume ?? null })).filter((x) => x.keyword);
  const own = brandOf(dom2);
  const marca = items.filter((x) => own.length >= 3 && tokens(x.keyword).join("").includes(own)).length;
  return { total: r.total_count ?? items.length, leidas: items.length, marca, top10: items.filter((x) => x.posicion != null && x.posicion <= 10).length, urls: new Set(items.map((x) => x.url).filter(Boolean)).size, items };
}
var formatoOf = formatoDe;
async function buildPlan(db, cfg, keys, m, { forzar = false } = {}) {
  const cands = await db.all("SELECT _id AS id, keyword, volumen, dificultad, intencion, ganable, relevancia, por_que, semilla, variantes, competidores, estado, oportunidad FROM " + H + " WHERE origen = 'dataforseo' AND estado IN ('nuevo', 'convertido') AND ganable IS NOT NULL AND _deleted = 0 ORDER BY ganable DESC, volumen DESC LIMIT ?", [MAX_SERP_TOTAL]);
  if (!cands.length) return { plan: [], no_fiables: [], aviso: "No hay huecos filtrados y puntuados: pulsa \xABBuscar huecos\xBB (o \xABVolver a filtrar\xBB) antes del diagn\xF3stico." };
  const w = where(cfg);
  const own = domainOf2(cfg.dominio);
  const leidos = [];
  let fiables = 0;
  const todas = /* @__PURE__ */ new Map();
  while (leidos.length < cands.length && !(leidos.length >= MAX_SERP && fiables >= PLAN_N)) {
    const tanda = cands.slice(leidos.length, leidos.length ? cands.length : MAX_SERP);
    const res = await serpBatch(keys, tanda.map((c) => c.keyword), w, m, { db, forzar, modo: serpModo(cfg) });
    for (const c of tanda) {
      const sr = res.get(String(c.keyword || "").trim());
      todas.set(c.keyword, sr);
      c.top10_origen = serpEdadTxt(sr);
      c.top10_fecha = sr?.fecha ?? null;
      if (!sr || sr.error) {
        c.top10 = null;
        c.fiable = false;
        c.error = sr?.error || "sin respuesta";
      } else {
        const o = organicTop(sr.items, { n: 10 });
        c.top10 = o.validos;
        c.fiable = o.fiable;
        c.lectura = o;
        c.metodo = sr.metodo;
      }
      leidos.push(c);
      if (c.fiable) fiables++;
    }
  }
  const ok = leidos.filter((c) => c.fiable);
  const rivales = ok.flatMap((c) => c.top10.map((t) => t.dominio)).filter((d) => d && d !== own);
  const [tr, au] = await Promise.all([trafico2(db, keys, rivales, w, m), autoridad(db, keys, rivales, m)]);
  const fuerza = tr.medido ? "DataForSEO Labs bulk_traffic_estimation" : null;
  const base = (c) => n0(c.volumen) + " b\xFAsquedas/mes, " + kdTxt(c.dificultad) + ". ";
  const plan = ok.map((c) => {
    const g = winnability(c.top10, { own, etv: tr.etv, cfg, medido: tr.medido, opr: au.opr });
    const factor = g.flojos == null ? 0.5 : 0.5 + g.flojos / 10;
    const quitados = c.lectura?.quitados?.length || 0;
    const material = materialDe(todas.get(c.keyword)?.items);
    const razon = base(c) + g.texto + (quitados ? " (Se quitaron " + quitados + " resultado" + (quitados === 1 ? "" : "s") + " de Google: fichas o enlaces de redirecci\xF3n.)" : "");
    return {
      hueco: c.id,
      keyword: c.keyword,
      volumen: c.volumen,
      dificultad: kdOf(c.dificultad),
      intencion: c.intencion,
      relevancia: c.relevancia,
      ganable: c.ganable,
      semilla: c.semilla,
      variantes: c.variantes,
      formato: formatoOf(c.intencion),
      flojos: g.flojos,
      nivel: g.nivel,
      ganabilidad: { flojos: g.flojos, total: g.total, pequenos: g.pequenos, portales: g.portales, fuertes: g.fuertes, sin_dato: g.sin_dato, propia_posicion: g.propia_posicion, nivel: g.nivel, autoridad_media: g.autoridad_media, autoridad_medidos: g.autoridad_medidos },
      por_que: g.texto,
      preguntas: material.preguntas,
      busquedas_relacionadas: material.relacionadas,
      top10: g.resultados,
      fiable: true,
      razon,
      puntuacion: Math.round((c.ganable || 0) * factor),
      oportunidad: c.oportunidad ?? null,
      top10_origen: c.top10_origen,
      top10_fecha: c.top10_fecha
    };
  }).sort((a, b) => b.puntuacion - a.puntuacion).slice(0, PLAN_N);
  const no_fiables = leidos.filter((c) => !c.fiable).map((c) => ({
    hueco: c.id,
    keyword: c.keyword,
    volumen: c.volumen,
    dificultad: kdOf(c.dificultad),
    intencion: c.intencion,
    ganable: c.ganable,
    fiable: false,
    flojos: null,
    top10: c.top10 || [],
    razon: base(c) + (c.top10 == null ? "No se pudo leer su top 10 (" + c.error + ")." : noFiableTxt(c.lectura)) + " Top 10 no fiable: no entra en el plan.",
    top10_origen: c.top10_origen,
    top10_fecha: c.top10_fecha
  }));
  return { plan, no_fiables, fuerza, leidos: leidos.length, candidatos: cands.length, serp: serpResumen(todas), autoridad_aviso: plan.length ? au.aviso ?? null : null };
}
var MESES = ["enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre"];
var dia3 = (s) => {
  const m = String(s || "").match(/^(\d{4})-(\d{2})-(\d{2})/);
  return m ? { y: m[1], txt: Number(m[3]) + " de " + MESES[Number(m[2]) - 1] } : null;
};
function periodoTxt(desde, hasta) {
  const a = dia3(desde), b = dia3(hasta);
  if (a && b) return "del " + a.txt + (a.y !== b.y ? " de " + a.y : "") + " al " + b.txt + " de " + b.y;
  if (b) return "hasta el " + b.txt + " de " + b.y;
  if (a) return "desde el " + a.txt + " de " + a.y;
  return "en el periodo cargado";
}
var esMarca = (consulta, dom2) => {
  const b = brandOf(dom2);
  if (b.length < 3) return false;
  return tokens(consulta).join("").includes(b);
};
async function searchConsoleSummary(db, dom2) {
  const rows = ultimoPeriodo((await db.all("SELECT consulta, pagina, clics, impresiones, posicion, desde, hasta FROM " + C + " WHERE origen = 'search_console' AND _deleted = 0")).filter((r) => {
    const p = String(r.pagina || "").trim();
    return !p || !/^https?:\/\//i.test(p) || domainOf2(p) === dom2;
  }));
  if (!rows.length) return null;
  const por = /* @__PURE__ */ new Map();
  for (const r of rows) {
    const k = norm(r.consulta);
    const x = por.get(k) || { consulta: r.consulta, impresiones: 0, clics: 0, marca: esMarca(r.consulta, dom2), pos: [] };
    x.impresiones += Number(r.impresiones) || 0;
    x.clics += Number(r.clics) || 0;
    if (r.posicion != null) x.pos.push(Number(r.posicion));
    por.set(k, x);
  }
  const q = [...por.values()].map((x) => ({ consulta: x.consulta, impresiones: x.impresiones, clics: x.clics, marca: x.marca, pos_min: x.pos.length ? Math.min(...x.pos) : null, pos_max: x.pos.length ? Math.max(...x.pos) : null })).sort((a, b) => b.impresiones - a.impresiones);
  const sum = (l, k) => l.reduce((a, x) => a + x[k], 0);
  const conImp = q.filter((x) => x.impresiones > 0);
  const marca = q.filter((x) => x.marca), sin = q.filter((x) => !x.marca);
  const ds = rows.map((r) => r.desde).filter(Boolean).sort(), hs = rows.map((r) => r.hasta).filter(Boolean).sort();
  const desde = ds[0] ?? null, hasta = hs[hs.length - 1] ?? null;
  return {
    filas: rows.length,
    consultas: q.length,
    impresiones: sum(q, "impresiones"),
    clics: sum(q, "clics"),
    con_impresiones: conImp.length,
    marca: marca.length,
    no_marca: sin.length,
    marca_con_impresiones: conImp.filter((x) => x.marca).length,
    no_marca_con_impresiones: conImp.filter((x) => !x.marca).length,
    impresiones_marca: sum(marca, "impresiones"),
    clics_marca: sum(marca, "clics"),
    impresiones_no_marca: sum(sin, "impresiones"),
    clics_no_marca: sum(sin, "clics"),
    desde,
    hasta,
    periodo: periodoTxt(desde, hasta),
    marca_nombre: brandOf(dom2),
    top: q.slice(0, 20)
  };
}
var lista3 = (xs) => {
  const a = xs.map((x) => "\xAB" + x + "\xBB");
  return a.length <= 1 ? a.join("") : a.slice(0, -1).join(", ") + " o " + a[a.length - 1];
};
function conclude({ checks, ranked, plan, dominio: dominio2, gsc = null }) {
  const graves = checks.filter((c) => c.estado === "problema" && c.grave);
  const leves = checks.filter((c) => c.estado === "problema" && !c.grave);
  const sin = checks.filter((c) => c.estado === "no_comprobado");
  const fiable = plan.filter((p) => p.fiable !== false);
  const volPlan = fiable.reduce((a, p) => a + (Number(p.volumen) || 0), 0);
  if (graves.length) return "Hay un problema t\xE9cnico que impide a Google ver " + dominio2 + ": " + graves.map((c) => c.detalle.replace(/\.$/, "")).join("; ") + ". Arr\xE9glalo antes de escribir nada.";
  const tecBien = !sin.length && !leves.length;
  const tecnico = sin.length ? "No se pudo comprobar " + [...new Set(sin.map((c) => c.nombre.split(":")[0].toLowerCase()))].join(", ") + "; en lo dem\xE1s la web est\xE1 bien" : leves.length ? "La web no bloquea a Google, pero " + leves.map((c) => c.detalle.replace(/\.$/, "").replace(/^./, (x) => x.toLowerCase())).join("; ") : "La web est\xE1 bien";
  const planTxt = "hay " + n0(volPlan) + " b\xFAsquedas al mes en " + fiable.length + " tema" + (fiable.length === 1 ? "" : "s") + " que puedes ganar";
  const sinPlan = "a\xFAn no hay un plan fiable: busca huecos para saber qu\xE9 p\xE1ginas crear";
  const tecYPlan = () => tecBien ? fiable.length ? "La web est\xE1 bien, pero no tiene p\xE1ginas para lo que buscan tus clientes: " + planTxt + "." : "La web est\xE1 bien, pero " + sinPlan + "." : tecnico + (fiable.length ? "; rev\xEDsalo antes de crear las p\xE1ginas del plan." : "; y " + sinPlan + ".");
  const sc = gsc && gsc.filas ? gsc : null;
  const labsSin = ranked ? Math.max(0, ranked.total - ranked.marca) : null;
  if (!sc) {
    const labs = !ranked ? "tampoco se pudo leer qu\xE9 posiciona seg\xFAn DataForSEO" : ranked.total === 0 ? "DataForSEO Labs no la encuentra en el top 100 de ninguna b\xFAsqueda que tenga en su base (no ve las b\xFAsquedas peque\xF1as)" : "DataForSEO Labs la ve en el top 100 de " + ranked.total + " b\xFAsqueda" + (ranked.total === 1 ? "" : "s");
    return "Falta cargar Search Console: sin \xE9l no se sabe por qu\xE9 b\xFAsquedas aparece hoy " + dominio2 + " en Google; " + labs + ". " + tecYPlan();
  }
  if (!sc.con_impresiones) return "Seg\xFAn Search Console, " + dominio2 + " no tuvo impresiones en Google " + sc.periodo + ". " + tecYPlan();
  if (!sc.no_marca_con_impresiones) {
    const marcas = sc.top.filter((x) => x.marca && x.impresiones > 0).map((x) => x.consulta).slice(0, 3);
    return "Hoy " + dominio2 + " solo aparece en Google cuando buscan " + lista3(marcas) + " (" + n0(sc.impresiones_marca) + " impresiones, " + n0(sc.clics_marca) + " clics " + sc.periodo + ", seg\xFAn Search Console); por ninguna b\xFAsqueda de lo que hac\xE9is aparece todav\xEDa" + (labsSin > 10 ? " (aunque DataForSEO Labs la ve en " + labsSin + " b\xFAsquedas sin marca: revisa que Search Console est\xE9 cargado entero)" : "") + ". " + tecYPlan();
  }
  const scTxt = "Seg\xFAn Search Console, " + dominio2 + " aparece por " + sc.no_marca_con_impresiones + " b\xFAsqueda" + (sc.no_marca_con_impresiones === 1 ? "" : "s") + " que no son su marca (" + n0(sc.impresiones_no_marca) + " impresiones, " + n0(sc.clics_no_marca) + " clics " + sc.periodo + ")" + (sc.marca_con_impresiones ? " y por " + sc.marca_con_impresiones + " de su marca" : "") + ". ";
  if (ranked && labsSin > 10) {
    if (ranked.top10 < Math.max(3, ranked.leidas * 0.1)) return scTxt + tecnico + " y DataForSEO la ve en " + ranked.total + " b\xFAsquedas, pero solo " + ranked.top10 + " en la primera p\xE1gina: empuja las de \xABCasi lo tienes\xBB" + (fiable.length ? " y crea las " + fiable.length + " p\xE1ginas del plan." : ".");
    return scTxt + tecnico + " y DataForSEO la ve en " + ranked.total + " b\xFAsquedas (" + ranked.top10 + " en la primera p\xE1gina)" + (fiable.length ? "; el plan suma " + n0(volPlan) + " b\xFAsquedas al mes m\xE1s." : ".");
  }
  return scTxt + (tecBien ? fiable.length ? "La web est\xE1 bien, pero le faltan p\xE1ginas para lo que buscan tus clientes: " + planTxt + "." : "La web est\xE1 bien, pero " + sinPlan + "." : tecYPlan());
}
async function diagnose(db, input = {}, keys = keysClient(), net = globalThis.fetch) {
  const forzar = input?.forzar === true || input?.forzar === "true" || input?.forzar === 1;
  return withMeter(db, "diagnosticar", async (m) => {
    const cfg = await settings(db);
    const dom2 = domainOf2(cfg.dominio);
    if (!dom2) throw new Refused("Falta el dominio en Ajustes (General \u2192 Dominio).", 400);
    where(cfg);
    const avisos = [];
    const vias = /* @__PURE__ */ new Set();
    const [rk, tec, pl] = await Promise.all([
      rankedNow(dom2, cfg, keys, m).then((r) => ({ r }), (e) => {
        if (e.status === 424 || e.status === 429) throw e;
        return { e };
      }),
      technical(dom2, cfg, fetcher(net, keys, m, vias)),
      buildPlan(db, cfg, keys, m, { forzar })
    ]);
    const ranked = rk.r ?? null;
    if (rk.e) avisos.push("No se pudo leer qu\xE9 posiciona hoy (" + rk.e.message + ").");
    if (pl.aviso) avisos.push(pl.aviso);
    if (pl.serp?.frase) avisos.push("En este diagn\xF3stico: " + pl.serp.frase + ".");
    if (pl.autoridad_aviso) avisos.push(pl.autoridad_aviso);
    if (pl.plan.length && !pl.fuerza) avisos.push("No se pudo medir la fuerza de los dominios del top 10: \xAB\xBFse puede ganar?\xBB queda sin dato.");
    if (pl.no_fiables?.length && !pl.plan.length) avisos.push("Ninguna de las " + pl.leidos + " keywords miradas tiene un top 10 fiable (menos de " + MIN_VALIDOS + " resultados org\xE1nicos que sean webs), as\xED que el plan queda vac\xEDo" + (pl.leidos >= MAX_SERP_TOTAL ? " (tope de coste: " + MAX_SERP_TOTAL + " b\xFAsquedas)" : "") + ".");
    else if (pl.no_fiables?.length) avisos.push(pl.no_fiables.length + " keyword" + (pl.no_fiables.length === 1 ? "" : "s") + " con el top 10 no fiable (menos de " + MIN_VALIDOS + " resultados org\xE1nicos v\xE1lidos) se " + (pl.no_fiables.length === 1 ? "sustituy\xF3" : "sustituyeron") + " en el plan por la" + (pl.no_fiables.length === 1 ? "" : "s") + " siguiente" + (pl.no_fiables.length === 1 ? "" : "s") + " ganable" + (pl.no_fiables.length === 1 ? "" : "s") + " (" + pl.leidos + " de " + pl.candidatos + " huecos mirados).");
    if (pl.candidatos && pl.plan.length && pl.plan.length < Math.min(PLAN_N, pl.candidatos) && pl.no_fiables?.length) avisos.push("Solo " + pl.plan.length + " p\xE1gina" + (pl.plan.length === 1 ? "" : "s") + " con top 10 fiable tras mirar " + pl.leidos + " huecos (tope de coste: " + MAX_SERP_TOTAL + " b\xFAsquedas).");
    const gsc = await searchConsoleSummary(db, dom2);
    const conclusion = conclude({ checks: tec.checks, ranked, plan: pl.plan, dominio: dom2, gsc });
    const estado_tecnico = tec.checks.some((c) => c.estado === "problema") ? "problema" : tec.checks.some((c) => c.estado === "no_comprobado") ? "no_comprobado" : "bien";
    const fecha = now8();
    const row = {
      conclusion,
      dominio: dom2,
      fecha,
      keywords_top100: ranked?.total ?? null,
      keywords_marca: ranked?.marca ?? null,
      keywords_top10: ranked?.top10 ?? null,
      urls_posicionadas: ranked?.urls ?? null,
      urls_sitemap: tec.urls_sitemap,
      estado_tecnico,
      tecnico: JSON.stringify(tec.checks),
      plan: JSON.stringify(pl.plan),
      no_fiables: JSON.stringify(pl.no_fiables || []),
      search_console: gsc ? JSON.stringify(gsc) : null,
      posiciones: JSON.stringify((ranked?.items ?? []).slice(0, 50)),
      coste: Math.round(m.usd * 1e5) / 1e5,
      avisos: [...avisos, vias.size ? "Web le\xEDda con: " + [...vias].map((v) => FUENTE[v]).join(", ") + "." : ""].filter(Boolean).join(" ")
    };
    const id = await db.insert(DG, row);
    await guardarSitemap(db, dom2, tec);
    await db.update(A, cfg._id, { diagnosticado: fecha });
    return { id, conclusion, estado_tecnico, keywords_top100: row.keywords_top100, search_console: gsc ? { filas: gsc.filas, consultas: gsc.consultas, impresiones: gsc.impresiones, clics: gsc.clics, marca: gsc.marca, no_marca: gsc.no_marca, periodo: gsc.periodo } : null, urls_posicionadas: row.urls_posicionadas, urls_sitemap: row.urls_sitemap, plan: pl.plan.map((p) => p.keyword), no_fiables: (pl.no_fiables || []).map((p) => p.keyword), avisos };
  });
}
async function latest(db) {
  const r = await db.one("SELECT * FROM " + DG + " WHERE _deleted = 0 ORDER BY _id DESC LIMIT 1");
  if (!r) return null;
  return { ...r, id: r._id, tecnico: parse2(r.tecnico, []), plan: parse2(r.plan, []), no_fiables: parse2(r.no_fiables, []), search_console: parse2(r.search_console, null), posiciones: parse2(r.posiciones, []) };
}
async function diagnosisView(db) {
  const cfg = await settings(db);
  const d = await latest(db);
  const dom2 = domainOf2(cfg.dominio);
  const gscAhora = dom2 ? await searchConsoleSummary(db, dom2) : null;
  const avisosVista = [];
  if (d) {
    const viejos = d.plan.filter((p) => p.fiable === void 0);
    if (viejos.length) {
      const malos = [];
      d.plan = d.plan.filter((p) => {
        if (p.fiable !== void 0) return true;
        const top = (p.top10 || []).filter((t) => !isGoogle(t.dominio) && !/google\.[a-z.]+\/(goto|url|aclk)/i.test(String(t.url || "")));
        if (top.length >= MIN_VALIDOS && top.length === (p.top10 || []).length) {
          p.fiable = true;
          return true;
        }
        malos.push({ ...p, top10: top, fiable: false, flojos: null, razon: "Top 10 no fiable: este diagn\xF3stico es de una versi\xF3n anterior que cont\xF3 resultados de Google (fichas o enlaces de redirecci\xF3n) como competidores. No se pudo medir la fuerza del top 10: repite el diagn\xF3stico." });
        return false;
      });
      d.no_fiables = [...d.no_fiables || [], ...malos];
      if (malos.length) avisosVista.push("Este diagn\xF3stico es de una versi\xF3n anterior: " + malos.length + " keyword" + (malos.length === 1 ? "" : "s") + " del plan ten\xEDa" + (malos.length === 1 ? "" : "n") + " el top 10 mal le\xEDdo (resultados de Google) y se " + (malos.length === 1 ? "muestra" : "muestran") + " como \xABtop 10 no fiable\xBB. Repite el diagn\xF3stico para tener el plan bien medido.");
    }
    if (!d.search_console && gscAhora) avisosVista.push("Este diagn\xF3stico se hizo sin leer Search Console, y ya hay " + gscAhora.filas + " filas cargadas: repite el diagn\xF3stico para que la conclusi\xF3n las tenga en cuenta.");
    for (const p of [...d.plan, ...d.no_fiables || []]) {
      p.dificultad = kdOf(p.dificultad);
      p.top10 = (p.top10 || []).map((t) => ({ ...t, url: urlLimpia(t.url, t.dominio) }));
    }
    for (const p of d.plan) {
      const o = await db.one("SELECT _id, estado FROM " + T + " WHERE lower(keyword) = lower(?) AND _deleted = 0", [p.keyword]);
      p.oportunidad = o?._id ?? null;
      p.estado_oportunidad = o?.estado ?? null;
    }
  }
  const costes = await lastCosts(db);
  const listos = (await db.one("SELECT count(*) AS n FROM " + H + " WHERE origen = 'dataforseo' AND estado IN ('nuevo', 'convertido') AND ganable IS NOT NULL AND _deleted = 0"))?.n ?? 0;
  const sinPuntuar = (await db.one("SELECT count(*) AS n FROM " + H + " WHERE origen = 'dataforseo' AND ganable IS NULL AND estado != 'filtrado' AND _deleted = 0"))?.n ?? 0;
  const serps = Math.min(MAX_SERP, listos), serpsMax = Math.min(MAX_SERP_TOTAL, listos);
  const fijo = PRECIOS.labs_tarea + RANKED_LIMIT * PRECIOS.labs_item;
  const fuerza = (n) => n ? PRECIOS.labs_tarea + Math.min(MAX_DOMINIOS, n * 10) * PRECIOS.labs_item : 0;
  let enCache = 0, cacheTxt = "";
  try {
    const w = where(cfg);
    const primeras2 = (await db.all("SELECT keyword FROM " + H + " WHERE origen = 'dataforseo' AND estado IN ('nuevo', 'convertido') AND ganable IS NOT NULL AND _deleted = 0 ORDER BY ganable DESC, volumen DESC LIMIT ?", [serps])).map((x) => x.keyword);
    const c = await serpEnCache(db, primeras2, w, { modo: serpModo(cfg) });
    enCache = c.size;
    if (enCache) {
      const hs = [...c.values()].map((x) => x.horas);
      const edad = serpEdadTxt({ metodo: "cache", horas: Math.max(...hs) }).replace(/^top 10 de /, "").replace(/ \(caché\)$/, "");
      cacheTxt = (enCache === serps ? "los " + serps + " top 10 del plan est\xE1n guardados" : enCache + " de los " + serps + " top 10 del plan est\xE1n guardados") + " (" + (enCache === 1 ? "se pidi\xF3 " : "el m\xE1s antiguo se pidi\xF3 ") + edad + ") y no se vuelven a pagar hasta que cumplan 3 d\xEDas; \xABForzar actualizaci\xF3n\xBB los pide todos de nuevo";
    }
  } catch {
  }
  const precio = await serpPrecio(db, serpModo(cfg));
  const ps = precio.usd;
  const est = fijo + Math.max(0, serps - enCache) * ps + fuerza(serps) + 8 * PRECIOS.onpage;
  const estMax = fijo + serpsMax * ps + fuerza(serpsMax) + 8 * PRECIOS.onpage;
  const estForzar = fijo + serps * ps + fuerza(serps) + 8 * PRECIOS.onpage;
  return {
    diagnostico: d,
    dominio: domainOf2(cfg.dominio) || null,
    mercado: cfg.mercado || null,
    ruta_blog: cfg.ruta_blog || "/blog/",
    costes: costes.ultimo,
    gasto_total: costes.total,
    huecos_listos: listos,
    huecos_sin_puntuar: sinPuntuar,
    modo: modoOf(cfg),
    estimacion: {
      usd: usd(est) + (estMax > est ? "\u2013" + usd(estMax) : ""),
      usd_min: usd(est),
      usd_max: usd(estMax),
      usd_forzar: usd(estForzar),
      en_cache: enCache,
      cache_txt: cacheTxt || null,
      segundos: "15\u201330",
      serp_modo: precio.modo,
      serp_precio: usd(ps),
      serp_precio_real: precio.real,
      texto: "1 consulta de Labs ranked_keywords (hasta " + RANKED_LIMIT + "), " + serps + (serpsMax > serps ? "\u2013" + serpsMax : "") + " b\xFAsquedas de Google para el top 10 del plan (" + serpPrecioTxt(precio) + ", 4 a la vez; m\xE1s de " + serps + " solo si alguna keyword no tiene un top 10 fiable)" + (cacheTxt ? ": " + cacheTxt : "") + ", 1 de Labs bulk_traffic_estimation (gratis si el tr\xE1fico de esos dominios se ley\xF3 esta semana) y, si el m\xF3dulo no puede leer la web, hasta 8 p\xE1ginas de On-Page; Search Console no cuesta nada (ya est\xE1 cargado). Tarda unos 15\u201330 segundos"
    },
    criterios: { flojo_etv: FLOJO_ETV, max_serp: MAX_SERP, max_serp_total: MAX_SERP_TOTAL, plan_n: PLAN_N, min_validos: MIN_VALIDOS },
    search_console: d?.search_console ?? gscAhora,
    search_console_guardado: !!d?.search_console,
    search_console_actual: gscAhora,
    avisos_vista: avisosVista
  };
}
var COMPARA = /\b(vs|versus|mejores?|comparativa|comparar|alternativas?|diferencias?|frente)\b/;
function tipoFor(p, tipos) {
  const act = tipos.filter((t) => t.activo !== 0);
  const find = (re) => act.find((t) => re.test(norm(t.key + " " + t.label)));
  if (COMPARA.test(norm(p.keyword))) {
    const t = find(/compar/);
    if (t) return { tipo: t, por: "la b\xFAsqueda compara opciones" };
  }
  const g = find(/gui|guide|how|tutorial/);
  if (g) return { tipo: g, por: p.formato === "servicio" ? "una p\xE1gina de servicio explica qu\xE9 haces y c\xF3mo; el tipo m\xE1s cercano es una gu\xEDa" : "b\xFAsqueda informativa: una gu\xEDa pr\xE1ctica" };
  return act[0] ? { tipo: act[0], por: "el primer tipo activo de Art\xEDculos" } : { tipo: null, por: "no hay tipos le\xEDdos de Art\xEDculos" };
}
async function planToOpportunities(db, { keyword = null } = {}) {
  const d = await latest(db);
  if (!d) throw new Refused("A\xFAn no hay diagn\xF3stico: pulsa \xABHacer diagn\xF3stico\xBB.", 404);
  if (!d.plan.length) throw new Refused("El \xFAltimo diagn\xF3stico no tiene plan: busca huecos y vuelve a hacer el diagn\xF3stico.", 404);
  const planOk = d.plan.filter((p) => p.fiable !== false && !(p.top10 || []).some((t) => isGoogle(t.dominio)) && (!keyword || String(p.keyword).toLowerCase() === String(keyword).toLowerCase()));
  if (keyword && !planOk.length) throw new Refused("\xAB" + keyword + "\xBB no est\xE1 en el plan del \xFAltimo diagn\xF3stico.", 404);
  if (!planOk.length) throw new Refused("El plan del \xFAltimo diagn\xF3stico no tiene ninguna p\xE1gina con el top 10 bien medido: repite el diagn\xF3stico.", 409);
  const cfg = await settings(db);
  const tipos = await db.all("SELECT _id, key, label, activo FROM " + K + " WHERE _deleted = 0 ORDER BY _id");
  const dom2 = domainOf2(cfg.dominio);
  const blog = cfg.ruta_blog || "/blog/";
  let creadas = 0, ya = 0;
  const ids = [];
  for (const p of planOk) {
    const ex = await db.one("SELECT _id FROM " + T + " WHERE lower(keyword) = lower(?) AND _deleted = 0", [p.keyword]);
    if (ex) {
      ya++;
      ids.push(ex._id);
      p.oportunidad = ex._id;
      continue;
    }
    const { tipo, por } = tipoFor(p, tipos);
    const variantes = splitList5(p.variantes);
    const vv = variantes.length ? await db.all("SELECT keyword, volumen, dificultad FROM " + D + " WHERE keyword IN (" + variantes.map(() => "?").join(",") + ") AND _deleted = 0", variantes) : [];
    const keywords = [{ keyword: p.keyword, volumen: p.volumen, dificultad: kdOf(p.dificultad), principal: true }, ...variantes.map((k) => {
      const v = vv.find((x) => x.keyword === k);
      return { keyword: k, volumen: v?.volumen ?? null, dificultad: kdOf(v?.dificultad) };
    })];
    const servicio = p.formato === "servicio";
    const top = (p.top10 || []).map((t) => ({ ...t, url: urlLimpia(t.url, t.dominio) }));
    const gan = p.ganabilidad ?? (p.flojos != null ? { flojos: p.flojos, total: top.length, nivel: p.flojos / Math.max(1, top.length) >= 0.5 ? "alta" : p.flojos / Math.max(1, top.length) >= 0.3 ? "media" : "baja" } : null);
    const competencia = top.length ? "Top 10 en Google" + (cfg.mercado ? " " + cfg.mercado : "") + " (DataForSEO, " + String(d.fecha).slice(0, 10) + "): " + top.map((t) => "#" + t.pos + " " + t.dominio + " (" + (t.etv != null ? n0(t.etv) + " visitas/mes" : "sin dato") + (t.flojo ? ", flojo" : "") + ")").join("; ") + "." : "Sin top 10 le\xEDdo en el diagn\xF3stico.";
    const hueco = p.flojos != null && p.flojos >= 5 ? "Hoy " + p.flojos + " de los 10 primeros son dominios peque\xF1os, directorios o foros: hay sitio para una p\xE1gina clara." : p.flojos != null ? "El top 10 lo ocupan sobre todo dominios con tr\xE1fico: hace falta una p\xE1gina claramente mejor y m\xE1s concreta." : "";
    const publico = cfg.publico || "el p\xFAblico de Ajustes";
    const angulo = servicio ? "P\xE1gina de servicio de " + (dom2 || "la web") + " para quien busca \xAB" + p.keyword + "\xBB: qu\xE9 incluye, para qui\xE9n (" + publico + "), c\xF3mo se trabaja, plazos y precio orientativo o de qu\xE9 depende, y un contacto claro. " + hueco : "Art\xEDculo pr\xE1ctico que responda \xAB" + p.keyword + "\xBB para " + publico + ", con pasos y ejemplos, que enlace a la p\xE1gina de servicio de " + (dom2 || "la web") + (p.semilla ? " sobre \xAB" + p.semilla + "\xBB" : "") + ". " + hueco;
    const row = {
      tema: temaDe(p.keyword),
      keyword: p.keyword,
      secundarias: variantes.join("; "),
      volumen: p.volumen,
      dificultad: kdOf(p.dificultad),
      potencial: keywords.reduce((a, k) => a + (Number(k.volumen) || 0), 0) || null,
      intencion: p.intencion,
      tipo: tipo?._id ?? null,
      formato: p.formato,
      cluster: p.semilla || null,
      lectora: cfg.publico || null,
      competencia,
      angulo: angulo.trim(),
      fuentes: top.slice(0, 3).map((t) => "Top 10 hoy, #" + t.pos + " " + t.dominio + ": " + t.url).join("\n"),
      keywords: JSON.stringify(keywords),
      serp: JSON.stringify(top.map((t) => ({ pos: t.pos, url: t.url, dominio: t.dominio, titulo: t.titulo, fuente: t.fuente ?? null, dr: null, trafico: t.etv ?? null, clase: t.clase ?? null, porque: typeof t.porque === "string" ? t.porque : null, cubre: [] }))),
      huecos: JSON.stringify([]),
      ganabilidad: gan ? JSON.stringify({ ...gan, fecha: d.fecha }) : null,
      nivel: gan?.nivel ?? null,
      ganable_por: p.por_que || p.razon || null,
      preguntas: JSON.stringify({ preguntas: p.preguntas ?? [], relacionadas: p.busquedas_relacionadas ?? [], fecha: p.top10_fecha ?? d.fecha }),
      serp_origen: "dataforseo",
      origen: "diagnostico",
      estado: "propuesta"
    };
    const brief = [
      "Formato: " + (servicio ? "p\xE1gina de servicio (no un art\xEDculo del blog: va con las p\xE1ginas de servicios, fuera de " + blog + ")" : "art\xEDculo del blog (en " + blog + ")") + ".",
      "Tipo en Art\xEDculos: " + (tipo ? tipo.label + " (" + por + ")" : "sin tipo (" + por + ")") + ".",
      defaultBrief(row, tipo, cfg)
    ].join("\n");
    const puntuacion = score(row);
    const id = await db.insert(T, { ...row, brief, puntuacion, prioridad: priorityOf(puntuacion) });
    if (p.hueco) await db.update(H, p.hueco, { estado: "convertido", oportunidad: id });
    p.oportunidad = id;
    ids.push(id);
    creadas++;
  }
  await db.update(DG, d.id, { plan: JSON.stringify(d.plan) });
  return { creadas, ya_existian: ya, oportunidades: ids };
}

// server/services/web.mjs
var dominioDe = (cfg) => domainOf2(cfg.dominio);
var tituloDe = (ruta) => {
  const s = ruta.split("/").filter(Boolean).pop() || "";
  return s ? s.replace(/[-_]+/g, " ").replace(/\.\w+$/, "") : "Inicio";
};
var norm4 = (s) => String(s ?? "").trim().toLowerCase();
var slugDe = (s) => String(s ?? "").toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "");
async function siteView(db) {
  const cfg = await settings(db);
  const dom2 = dominioDe(cfg);
  const blog = pathOf(cfg.ruta_blog || "/blog/");
  const esBlog = (ruta) => blog !== "/" && ruta.startsWith(blog) && ruta.length > blog.length;
  const filas2 = /* @__PURE__ */ new Map();
  const fila = (ruta) => {
    if (!filas2.has(ruta)) filas2.set(ruta, { id: ruta, ruta, url: dom2 ? "https://" + dom2 + ruta : ruta, titulo: "", clase: esBlog(ruta) ? "articulo" : "pagina", fuentes: [], keyword: "", estado_articulo: "", consultas: [], impresiones: 0, clics: 0, posicion: null, oportunidad: null, oportunidad_tema: "" });
    return filas2.get(ruta);
  };
  const sm = await cacheGet(db, SITEMAP_CLAVE);
  const sitemap = sm?.valor && sm.valor.dominio === dom2 ? sm.valor : null;
  for (const u of (sitemap?.urls ?? []).filter((x) => !esSitemap(x))) {
    const f = fila(pathOf(u));
    if (!f.fuentes.includes("sitemap")) f.fuentes.push("sitemap");
  }
  const pags = (await db.all("SELECT url, titulo, clase, keyword, estado FROM " + P + " WHERE _deleted = 0 AND activa = 1")).filter((p) => isOwnPage(p.url, cfg));
  for (const p of pags) {
    const f = fila(pathOf(p.url));
    f.fuentes.push("articulos");
    f.clase = p.clase === "articulo" ? "articulo" : "pagina";
    if (p.titulo && p.titulo !== p.url) f.titulo = p.titulo;
    f.keyword = p.keyword || "";
    f.estado_articulo = p.estado || "";
  }
  const todas = await db.all("SELECT consulta, pagina, clics, impresiones, posicion, desde, hasta, origen FROM " + C + " WHERE _deleted = 0");
  const reales = ultimoPeriodo(todas.filter((q) => q.origen !== "ejemplo"));
  const consultas = reales.length ? reales : todas;
  for (const q of consultas) {
    if (!q.pagina || !isOwnPage(q.pagina, cfg)) continue;
    const f = fila(pathOf(q.pagina));
    if (!f.fuentes.includes("search_console")) f.fuentes.push("search_console");
    f.consultas.push({ consulta: q.consulta, impresiones: q.impresiones || 0, clics: q.clics || 0, posicion: q.posicion });
  }
  const ops = await db.all("SELECT _id AS id, tema, keyword, estado FROM " + T + " WHERE _deleted = 0 AND COALESCE(estado, 'propuesta') != 'descartada'");
  const porKeyword = new Map(ops.map((o) => [norm4(o.keyword), o]));
  const porId = new Map(ops.map((o) => [o.id, o]));
  const porRuta = /* @__PURE__ */ new Map();
  for (const c of await db.all("SELECT url, oportunidad FROM " + Q + " WHERE _deleted = 0 AND oportunidad IS NOT NULL")) if (porId.has(c.oportunidad) && isOwnPage(c.url, cfg)) porRuta.set(pathOf(c.url), porId.get(c.oportunidad));
  const porAccion = /* @__PURE__ */ new Map();
  for (const a of await db.all("SELECT objetivo, tipo, estado, url FROM " + ACC + " WHERE _deleted = 0 AND url IS NOT NULL AND url != '' AND estado NOT IN ('cancelada', 'duplicada')")) {
    if (!porId.has(a.objetivo) || !isOwnPage(a.url, cfg)) continue;
    porAccion.set(pathOf(a.url), { ...porId.get(a.objetivo), accion: TIPOS[a.tipo]?.label ?? a.tipo });
    const f = fila(pathOf(a.url));
    if (!f.fuentes.includes("objetivo")) f.fuentes.push("objetivo");
  }
  const art = await readArticles(db);
  for (const x of art.articles) {
    if (x.state !== "published" || !x.url || !isOwnPage(x.url, cfg)) continue;
    const f = fila(pathOf(x.url));
    if (!f.fuentes.includes("articulos")) f.fuentes.push("articulos");
    f.clase = "articulo";
    if (x.title) f.titulo = x.title;
    if (x.main_query && !f.keyword) f.keyword = x.main_query;
    f.estado_articulo = "published";
    const m = /oportunidades\s+seo\s*#\s*(\d+)/i.exec(String(x.origin ?? ""));
    if (m && porId.has(Number(m[1])) && !porAccion.has(pathOf(x.url))) porAccion.set(pathOf(x.url), { ...porId.get(Number(m[1])), accion: "Art\xEDculo del blog" });
  }
  const porSlug = /* @__PURE__ */ new Map();
  for (const o of ops) for (const s of [slugDe(o.keyword), slugDe(o.tema)]) if (s.length >= 8 && !porSlug.has(s)) porSlug.set(s, o);
  const rows = [...filas2.values()].map((f) => {
    f.consultas.sort((a, b) => b.impresiones - a.impresiones);
    const imp = f.consultas.reduce((n, q) => n + q.impresiones, 0);
    const ultimo = slugDe(f.ruta.split("/").filter(Boolean).pop() || "");
    const o = porAccion.get(f.ruta) ?? porRuta.get(f.ruta) ?? (f.keyword ? porKeyword.get(norm4(f.keyword)) : null) ?? (ultimo ? porSlug.get(ultimo) : null) ?? f.consultas.map((q) => porKeyword.get(norm4(q.consulta))).find(Boolean) ?? null;
    return {
      ...f,
      titulo: f.titulo || tituloDe(f.ruta),
      n_consultas: f.consultas.length,
      impresiones: imp,
      clics: f.consultas.reduce((n, q) => n + q.clics, 0),
      posicion: imp ? Math.round(f.consultas.reduce((n, q) => n + (q.posicion || 0) * q.impresiones, 0) / imp * 10) / 10 : f.consultas[0]?.posicion ?? null,
      consultas: f.consultas.slice(0, 5),
      consultas_txt: f.consultas.slice(0, 3).map((q) => "\xAB" + q.consulta + "\xBB" + (q.posicion ? " (pos. " + String(Math.round(q.posicion * 10) / 10).replace(".", ",") + ")" : "")).join(", ") + (f.consultas.length > 3 ? " y " + (f.consultas.length - 3) + " m\xE1s" : ""),
      oportunidad: o?.id ?? null,
      oportunidad_tema: o?.tema ?? "",
      oportunidad_por: o ? porAccion.get(f.ruta) ? "accion" : porRuta.get(f.ruta) ? "casi" : "coincidencia" : null,
      oportunidad_aprobada: o ? aprobado(o.estado) : false
    };
  }).sort((a, b) => b.impresiones - a.impresiones || a.ruta.localeCompare(b.ruta));
  const periodo = consultas.find((q) => q.desde && q.hasta);
  return {
    rows,
    dominio: dom2,
    ruta_blog: cfg.ruta_blog || "/blog/",
    sitemap: sitemap ? { leido: sm.fecha, url: sitemap.sitemap, urls: sitemap.urls.length, total: sitemap.total } : null,
    articulos_modulo: art.installed,
    articulos: { paginas: pags.length, articulos: pags.filter((p) => p.clase === "articulo").length, sincronizado: cfg.sincronizado ?? null },
    search_console: { actualizado: cfg.consultas_actualizadas ?? null, consultas: consultas.length, origen: reales.length ? "search_console" : todas.length ? "ejemplo" : null, periodo: periodo ? periodo.desde + " a " + periodo.hasta : null },
    resumen: { paginas: rows.filter((r) => r.clase === "pagina").length, articulos: rows.filter((r) => r.clase === "articulo").length, con_busquedas: rows.filter((r) => r.n_consultas).length, con_oportunidad: rows.filter((r) => r.oportunidad).length }
  };
}

// server/services/ia.mjs
var IA = "oportunidadesseo_ia";
var MAX_TEMAS = 8;
var MAX_POR_ORIGEN = 5;
var CHATGPT_PATH = "ai_optimization/chat_gpt/llm_scraper/live/advanced";
var CHATGPT_TIMEOUT_MS = 15e4;
var CHATGPT_USD = 4e-3;
var IA_CACHE_HORAS = 168;
var ASYNC_USD = 2e-3;
var MOTOR = { google: "Google (AI Overview)", chatgpt: "ChatGPT" };
var lines = (s) => String(s ?? "").split(/\n|;/).map((x) => x.trim()).filter(Boolean);
var truthy3 = (x) => x === true || x === "true" || x === 1;
var dom = (d) => String(d || "").trim().toLowerCase().replace(/^https?:\/\//, "").replace(/^www\./, "").replace(/[/?#:].*$/, "");
async function topics(db, cfg) {
  const out = [];
  const seen = /* @__PURE__ */ new Set();
  const add = (tema, origen) => {
    const k = norm(tema);
    if (!k || seen.has(k) || out.length >= MAX_TEMAS) return;
    seen.add(k);
    out.push({ tema: String(tema).trim(), origen });
  };
  for (const q of lines(cfg.preguntas_ia).slice(0, MAX_POR_ORIGEN)) add(q, "pregunta");
  const d = await latest(db);
  for (const p of (d?.plan ?? []).slice(0, MAX_POR_ORIGEN)) add(p.keyword, "plan");
  for (const s of semillasCortas(cfg).slice(0, MAX_POR_ORIGEN)) add(s.corta, "servicio");
  return out;
}
var marcaDe = (cfg) => String(cfg.marca ?? "").trim() || brandOf(cfg.dominio);
function nombrada(texto, marca) {
  const m = norm(marca).replace(/[^a-z0-9ñ ]+/g, " ").trim();
  if (m.length < 3) return false;
  const t = " " + norm(texto).replace(/[^a-z0-9ñ]+/g, " ") + " ";
  const junto = m.replace(/ /g, "");
  if (t.includes(" " + m + " ") || t.includes(" " + junto + " ")) return true;
  const ws = t.trim().split(" ");
  return ws.some((_, i) => ws[i] + (ws[i + 1] ?? "") === junto || ws[i] + (ws[i + 1] ?? "") + (ws[i + 2] ?? "") === junto);
}
function leer({ texto = "", fuentes = [], marcas = [] }, cfg) {
  const own = domainOf2(cfg.dominio);
  const marca = marcaDe(cfg);
  const dominios = [...new Set(fuentes.map((f) => dom(f.domain || f.url)).filter(Boolean))];
  const es = (d, x) => d === x || d.endsWith("." + x);
  const citada = !!own && dominios.some((d) => es(d, own));
  const mencionada = citada || nombrada(texto, marca) || marcas.some((b) => nombrada(b, marca)) || !!own && norm(texto).includes(own);
  const comps = competitorsOf(cfg).filter((c) => dominios.some((d) => es(d, c)) || nombrada(texto, brandOf(c)) || marcas.some((b) => nombrada(b, brandOf(c))));
  return { mencionada, citada, dominios: dominios.filter((d) => !own || !es(d, own)), marcas: [...new Set(marcas.map((b) => String(b).trim()).filter(Boolean))].slice(0, 15), competidores: comps };
}
var primeras = (t, n = 600) => {
  const s = String(t ?? "").replace(/\*\*|__|`/g, "").replace(/[#>|]+/g, " ").replace(/\[([^\]]+)\]\([^)]+\)/g, "$1").replace(/\s+/g, " ").trim();
  return s.length > n ? s.slice(0, n - 1).replace(/\s+\S*$/, "") + "\u2026" : s;
};
async function chatgpt(db, keys, tema, w, m, forzar) {
  const clave2 = "ia:chatgpt:" + norm(tema) + ":" + w.location_code + ":" + w.language_code;
  const c = forzar ? null : await cacheGet(db, clave2, { maxHoras: IA_CACHE_HORAS });
  if (c?.valor) return { ...c.valor, fecha: c.fecha, cache: true };
  try {
    const j = await dfsRaw(keys, "POST", CHATGPT_PATH, [{ keyword: tema, ...w }], m, 1, { timeoutMs: CHATGPT_TIMEOUT_MS });
    const t = j?.tasks?.[0];
    if (!t || t.status_code !== 2e4) return { estado: "error", detalle: "DataForSEO: " + (t?.status_message || j?.status_message || "sin respuesta") };
    const r = t.result?.[0];
    if (!r || !(r.markdown || (r.items ?? []).length)) return { estado: "sin_respuesta", detalle: "ChatGPT no devolvi\xF3 una respuesta para esta pregunta" };
    const marcas = [...r.brand_entities ?? [], ...(r.items ?? []).flatMap((it) => it?.brand_entities ?? [])].map((b) => b?.title).filter(Boolean);
    const fuentes = [...r.sources ?? [], ...(r.items ?? []).flatMap((it) => it?.sources ?? [])].filter((s) => s?.domain || s?.url).map((s) => ({ domain: dom(s.domain || s.url), url: s.url ?? null, title: s.title ? String(s.title).slice(0, 160) : null }));
    const valor = { estado: "respuesta", texto: String(r.markdown || (r.items ?? []).map((it) => it?.markdown || it?.text || "").join("\n")).slice(0, 6e3), fuentes: fuentes.slice(0, 30), marcas: marcas.slice(0, 30), modelo: r.model ?? null };
    const fecha = await cacheSet(db, clave2, valor);
    return { ...valor, fecha };
  } catch (e) {
    if (e.status === 424 || e.status === 429) throw e;
    return { estado: "error", detalle: e.message };
  }
}
async function reviewAI(db, input = {}, keys = keysClient()) {
  const forzar = truthy3(input?.forzar), completo = truthy3(input?.completo), conChatgpt = input?.chatgpt === void 0 ? true : truthy3(input.chatgpt);
  return withMeter(db, "revisar_ia", async (m) => {
    const cfg = await settings(db);
    if (!domainOf2(cfg.dominio)) throw new Refused("Falta el dominio en Ajustes (General \u2192 Dominio).", 400);
    const w = where(cfg);
    const temas = await topics(db, cfg);
    if (!temas.length) throw new Refused("No hay temas que preguntar: escribe en Ajustes \u2192 General \u2192 \xABPreguntas que tu cliente har\xEDa a una IA\xBB (una por l\xEDnea), a\xF1ade temas semilla o haz antes el diagn\xF3stico (se usan las keywords de su plan).", 400);
    const avisos = [];
    const serps = await serpBatch(keys, temas.map((t) => t.tema), w, m, { db, forzar, modo: "advanced" });
    const google = /* @__PURE__ */ new Map();
    for (const t of temas) {
      const sr = serps.get(t.tema);
      if (!sr || sr.error) {
        google.set(t.tema, { estado: "error", detalle: sr?.error || "sin respuesta" });
        continue;
      }
      const aio = (sr.items ?? []).find((x) => x?.type === "ai_overview");
      google.set(t.tema, !aio ? { estado: "sin_respuesta", detalle: "Google no ense\xF1a una respuesta de IA para esta b\xFAsqueda" } : !aio.text && !aio.references?.length ? { estado: "sin_cargar", detalle: "Google carga esta respuesta aparte: \xABRevisar tambi\xE9n las que se cargan aparte\xBB la pide (0,002 $ m\xE1s por b\xFAsqueda)" } : { estado: "respuesta", texto: aio.text, fuentes: aio.references ?? [], marcas: [], fecha: sr.fecha });
    }
    const aparte = temas.filter((t) => google.get(t.tema).estado === "sin_cargar");
    if (completo && aparte.length) {
      await pool(aparte, SERP.concurrencia, async (t) => {
        try {
          const r = await serpLive(keys, t.tema, w, m, { ...SERP, modo: "advanced", extra: { load_async_ai_overview: true } });
          const raw2 = (r.items ?? []).find((x) => x?.type === "ai_overview");
          const aio = raw2 ? aiOverview(raw2) : null;
          google.set(t.tema, aio && (aio.text || aio.references.length) ? { estado: "respuesta", texto: aio.text, fuentes: aio.references, marcas: [], fecha: ahora() } : { estado: "sin_respuesta", detalle: "Google no ense\xF1a una respuesta de IA para esta b\xFAsqueda" });
        } catch (e) {
          if (e.status === 424 || e.status === 429) throw e;
          google.set(t.tema, { estado: "error", detalle: e.message });
        }
      });
    } else if (aparte.length) avisos.push(aparte.length + " respuesta" + (aparte.length === 1 ? "" : "s") + " de Google se carga" + (aparte.length === 1 ? "" : "n") + " aparte y no se " + (aparte.length === 1 ? "ley\xF3" : "leyeron") + ": \xABRevisar tambi\xE9n las que se cargan aparte\xBB (completo: true) " + (aparte.length === 1 ? "la" : "las") + " pide, unos " + usd(aparte.length * (ASYNC_USD + 2e-3)) + ".");
    const gpt = /* @__PURE__ */ new Map();
    if (conChatgpt) {
      const rs = await pool(temas, SERP.concurrencia, (t) => chatgpt(db, keys, t.tema, w, m, forzar));
      temas.forEach((t, i) => gpt.set(t.tema, rs[i]));
      const enCache = rs.filter((x) => x.cache).length;
      if (enCache && m?.notas) m.notas.push(enCache + " respuesta" + (enCache === 1 ? "" : "s") + " de ChatGPT de las guardadas");
      const mal = rs.filter((x) => x.estado === "error");
      if (mal.length === rs.length) avisos.push("ChatGPT no se pudo consultar (" + mal[0].detalle + "). Puede que DataForSEO no lo ofrezca para la ubicaci\xF3n o el idioma de Ajustes.");
    }
    const fecha = ahora();
    const vivos = /* @__PURE__ */ new Set();
    for (const t of temas) {
      for (const [motor, r] of [["google", google.get(t.tema)], ...conChatgpt ? [["chatgpt", gpt.get(t.tema)]] : []]) {
        const l = r.estado === "respuesta" ? leer(r, cfg) : { mencionada: false, citada: false, dominios: [], marcas: [], competidores: [] };
        const data = {
          tema: t.tema,
          motor,
          origen_tema: t.origen,
          estado: r.estado,
          mencionada: l.mencionada ? 1 : 0,
          citada: l.citada ? 1 : 0,
          dominios: l.dominios.join("; "),
          marcas: l.marcas.join("; "),
          competidores: l.competidores.join("; "),
          respuesta: r.estado === "respuesta" ? primeras(r.texto) : "",
          fuentes: JSON.stringify((r.fuentes ?? []).slice(0, 25)),
          detalle: r.detalle ?? (r.modelo ? "Modelo: " + r.modelo : ""),
          fecha: r.fecha ?? fecha,
          vigente: 1
        };
        const ex = await db.one("SELECT _id FROM " + IA + " WHERE tema = ? AND motor = ? AND _deleted = 0", [t.tema, motor]);
        const id = ex ? (await db.update(IA, ex._id, data), ex._id) : await db.insert(IA, data);
        vivos.add(id);
      }
    }
    for (const x of await db.all("SELECT _id FROM " + IA + " WHERE vigente = 1 AND _deleted = 0")) if (!vivos.has(x._id)) await db.update(IA, x._id, { vigente: 0 });
    await db.update(A, cfg._id, { ia_revisada: fecha });
    const v = await aiView(db);
    return { temas: temas.length, conclusion: v.conclusion, por_tema: v.temas.map((t) => ({ tema: t.tema, tu: t.tu, citan: t.dominios.slice(0, 5), nombran: t.marcas.slice(0, 5) })), avisos };
  });
}
function concludeAI(temas, cfg) {
  const con = temas.filter((t) => t.respondio);
  if (!temas.length) return "A\xFAn no se ha revisado qu\xE9 responde la IA sobre tus temas.";
  if (!con.length) return "Ninguna IA dio una respuesta para tus " + temas.length + " temas: no hay nada que comparar todav\xEDa.";
  const tu = con.filter((t) => t.tu !== "no").length;
  const cuenta = (campo2) => {
    const n = /* @__PURE__ */ new Map();
    for (const t of con) for (const x of new Set(t[campo2])) n.set(x, (n.get(x) || 0) + 1);
    return [...n].sort((a, b) => b[1] - a[1]);
  };
  const doms = cuenta("dominios"), marcas = cuenta("marcas").filter(([b]) => !nombrada(b, marcaDe(cfg)));
  const N3 = con.length + " tema" + (con.length === 1 ? "" : "s");
  const ati = tu === 0 ? "a ti en ninguno" : tu === con.length ? "a ti tambi\xE9n, en todos" : "a ti en " + tu;
  const nombres = marcas.slice(0, 3).map(([b]) => b);
  const y = (l) => l.length <= 1 ? l.join("") : l.slice(0, -1).join(", ") + " y " + l[l.length - 1];
  if (doms.length) return "En " + doms[0][1] + " de " + N3 + " la IA cita a " + doms[0][0] + (nombres.length ? " y nombra a " + y(nombres) : "") + "; " + ati + ".";
  if (nombres.length) return "En " + marcas[0][1] + " de " + N3 + " la IA nombra a " + y(nombres) + "; " + ati + ".";
  return "La IA respondi\xF3 en " + N3 + " sin citar ninguna web; " + ati + ".";
}
async function aiView(db) {
  const cfg = await settings(db);
  const rows = (await db.all("SELECT _id AS id, tema, motor, origen_tema, estado, mencionada, citada, dominios, marcas, competidores, respuesta, fuentes, detalle, fecha FROM " + IA + " WHERE vigente = 1 AND _deleted = 0 ORDER BY _id")).map((r) => {
    let fuentes = [];
    try {
      fuentes = JSON.parse(r.fuentes || "[]");
    } catch {
      fuentes = [];
    }
    return { ...r, mencionada: !!r.mencionada, citada: !!r.citada, dominios: lines(r.dominios), marcas: lines(r.marcas), competidores: lines(r.competidores), fuentes };
  });
  const por = /* @__PURE__ */ new Map();
  for (const r of rows) {
    const t = por.get(r.tema) ?? { tema: r.tema, origen: r.origen_tema, motores: [] };
    t.motores.push(r);
    por.set(r.tema, t);
  }
  const temas = [...por.values()].map((t) => {
    const con = t.motores.filter((x) => x.estado === "respuesta");
    const uni = (campo2) => [...new Set(con.flatMap((x) => x[campo2]))];
    const tu = con.some((x) => x.citada) ? "citada" : con.some((x) => x.mencionada) ? "mencionada" : "no";
    const quien = uni("marcas").length ? uni("marcas").slice(0, 4) : uni("dominios").slice(0, 4);
    return {
      ...t,
      respondio: con.length > 0,
      tu,
      dominios: uni("dominios"),
      marcas: uni("marcas"),
      competidores: uni("competidores"),
      frase: !con.length ? "Ninguna IA respondi\xF3 a esto" + (t.motores.some((x) => x.estado === "sin_cargar") ? " (la respuesta de Google se carga aparte y no se ley\xF3)" : "") : (quien.length ? "Nombra o cita a " + quien.join(", ") : "Responde sin citar a nadie") + "; " + (tu === "citada" ? "a ti te cita" : tu === "mencionada" ? "a ti te nombra, sin enlazarte" : "a ti no"),
      respuesta: (con.find((x) => x.motor === "chatgpt") ?? con[0])?.respuesta ?? "",
      motores_txt: t.motores.map((x) => MOTOR[x.motor] + ": " + { respuesta: x.citada ? "te cita" : x.mencionada ? "te nombra" : "no apareces", sin_respuesta: "sin respuesta de IA", sin_cargar: "se carga aparte", error: "no se pudo consultar" }[x.estado]).join(" \xB7 ")
    };
  });
  const proximos = await topics(db, cfg);
  let est = null;
  try {
    const w = where(cfg);
    const enSerp = (await serpEnCache(db, proximos.map((t) => t.tema), w, { modo: "advanced" })).size;
    let enGpt = 0;
    for (const t of proximos) if (await cacheGet(db, "ia:chatgpt:" + norm(t.tema) + ":" + w.location_code + ":" + w.language_code, { maxHoras: IA_CACHE_HORAS })) enGpt++;
    const ps = (await serpPrecio(db, "advanced")).usd;
    const total = (proximos.length - enSerp) * ps + (proximos.length - enGpt) * CHATGPT_USD;
    est = {
      usd: usd(total),
      usd_forzar: usd(proximos.length * (ps + CHATGPT_USD)),
      temas: proximos.length,
      texto: proximos.length + " tema" + (proximos.length === 1 ? "" : "s") + ": " + (proximos.length - enGpt) + " pregunta" + (proximos.length - enGpt === 1 ? "" : "s") + " a ChatGPT (" + usd(CHATGPT_USD) + " cada una" + (enGpt ? "; " + enGpt + " guardadas esta semana" : "") + ") y " + (proximos.length - enSerp) + " b\xFAsqueda" + (proximos.length - enSerp === 1 ? "" : "s") + " de Google (" + usd(ps) + " cada una" + (enSerp ? "; " + enSerp + " guardadas" : "") + "). ChatGPT puede tardar hasta 2 minutos por pregunta: va en segundo plano"
    };
  } catch {
    est = null;
  }
  const costes = await lastCosts(db);
  const kwDe = (t) => String(t || "").toLowerCase().replace(/[¿?¡!«»"“”:;.,()]/g, " ").replace(/\s+/g, " ").trim();
  const goals = new Map((await db.all("SELECT _id, keyword FROM " + T + " WHERE _deleted = 0")).map((g) => [String(g.keyword || "").toLowerCase(), g._id]));
  for (const t of temas) t.objetivo = goals.get(kwDe(t.tema)) ?? null;
  return {
    dominio: domainOf2(cfg.dominio) || null,
    marca: marcaDe(cfg) || null,
    revisada: cfg.ia_revisada ?? null,
    conclusion: concludeAI(temas, cfg),
    temas,
    filas: rows,
    proximos: proximos.map((t) => t.tema),
    preguntas_propias: lines(cfg.preguntas_ia).length,
    coste: costes.ultimo.revisar_ia ?? null,
    estimacion: est,
    motores: MOTOR,
    n: miles(temas.length)
  };
}
async function aiToGoal(db, { tema }) {
  const t = String(tema || "").trim();
  const rows = await db.all("SELECT motor, estado, dominios, marcas, fuentes FROM " + IA + " WHERE tema = ? AND vigente = 1 AND _deleted = 0", [t]);
  if (!rows.length) throw new Refused("Esa pregunta ya no est\xE1 en \xABEn las respuestas de IA\xBB.", 404);
  const quien = [...new Set(rows.flatMap((r) => lines(r.marcas).concat(lines(r.dominios))))].slice(0, 5);
  const fuentes = [...new Set(rows.flatMap((r) => {
    try {
      return JSON.parse(r.fuentes || "[]").map((f) => typeof f === "string" ? f : f && f.url).filter(Boolean);
    } catch {
      return [];
    }
  }))].slice(0, 5);
  const g = await goalFrom(db, {
    tema: t.replace(/^[¿]/, "").replace(/[?]$/, ""),
    keyword: t,
    angulo: "Que la IA te nombre cuando alguien pregunta \xAB" + t + "\xBB. Hoy " + (quien.length ? "nombra o cita a " + quien.join(", ") : "responde sin citar a nadie") + " y a ti no. Lo que suele hacer que una IA cite una p\xE1gina: la respuesta clara al principio, datos concretos (precios, pasos, plazos), un caso real y estar en las fuentes que ya usa.",
    fuentes: fuentes.map((u) => "La IA cita: " + u)
  });
  return { tema: t, objetivo: g.id, nuevo: g.nuevo };
}

// server/services/vigilancia.mjs
var N2 = "oportunidadesseo_novedades";
var MAX_COMPETIDORES2 = 10;
var MAX_VISTAS = 4e3;
var MAX_HIJOS = 6;
var MAX_NUEVAS = 25;
var MAX_TITULOS = 8;
var LEER_MS = 12e3;
var MAX_CUERPO = 4e6;
var DIAS_VISTA = 60;
var UA2 = "Mozilla/5.0 (compatible; OportunidadesSEO/1.0; novedades de la competencia)";
var FEEDS = ["/feed", "/rss.xml", "/blog/feed", "/feed.xml", "/atom.xml"];
var SITEMAPS = ["/sitemap.xml", "/sitemap_index.xml", "/wp-sitemap.xml"];
var NO_CONTENIDO = /\/(tag|tags|etiqueta|category|categoria|categorias|author|autor|page|pagina)\/|\/(feed|rss)\/?$|\.(jpg|jpeg|png|gif|webp|svg|pdf|xml|css|js)(\?|$)|[?&](utm_|replytocom|s=)/i;
var ARTICULOS = /post|blog|article|articul|noticia|news|entrada/i;
var desXml = (s) => String(s ?? "").replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, "$1").replace(/&amp;/g, "&").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&#0?39;|&apos;/g, "'").replace(/&#(\d+);/g, (_, n) => String.fromCodePoint(Number(n))).replace(/\s+/g, " ").trim();
var fechaDe = (s) => {
  const t = Date.parse(String(s ?? ""));
  return Number.isFinite(t) ? new Date(t).toISOString().slice(0, 10) : null;
};
var llave = (u) => String(u ?? "").trim().toLowerCase().replace(/^https?:\/\//, "").replace(/^www\./, "").replace(/[?#].*$/, "").replace(/\/+$/, "");
async function leer2(net, url) {
  try {
    const r = await net(url, { redirect: "follow", headers: { "User-Agent": UA2, Accept: "*/*" }, signal: AbortSignal.timeout(LEER_MS) });
    return { status: r.status, body: r.status === 200 ? String(await r.text()).slice(0, MAX_CUERPO) : "" };
  } catch (e) {
    return { status: 0, body: "", error: e.cause?.code || e.name || e.message };
  }
}
function parseSitemap(xml) {
  const indice = /<sitemapindex[\s>]/i.test(xml);
  const out = [];
  for (const b of String(xml ?? "").matchAll(indice ? /<sitemap[\s>][\s\S]*?<\/sitemap>/gi : /<url[\s>][\s\S]*?<\/url>/gi)) {
    const loc = (b[0].match(/<loc>\s*([\s\S]*?)\s*<\/loc>/i) || [])[1];
    if (!loc) continue;
    out.push({ url: desXml(loc), fecha: fechaDe((b[0].match(/<lastmod>\s*([\s\S]*?)\s*<\/lastmod>/i) || [])[1]) });
  }
  return { indice, entradas: out };
}
function parseFeed(xml) {
  const out = [];
  for (const b of String(xml ?? "").matchAll(/<(item|entry)[\s>][\s\S]*?<\/\1>/gi)) {
    const x = b[0];
    const titulo = desXml((x.match(/<title[^>]*>([\s\S]*?)<\/title>/i) || [])[1]).replace(/<[^>]+>/g, "");
    const url = desXml((x.match(/<link[^>]*>\s*([^<\s][\s\S]*?)\s*<\/link>/i) || [])[1]) || desXml((x.match(/<link[^>]*href\s*=\s*["']([^"']+)["']/i) || [])[1]);
    if (!url) continue;
    out.push({ url, titulo: titulo.slice(0, 200), fecha: fechaDe((x.match(/<(pubDate|published|updated|dc:date)[^>]*>([\s\S]*?)<\/\1>/i) || [])[2]) });
  }
  return out;
}
var tituloDeHtml = (html) => {
  const t = desXml((String(html ?? "").match(/<title[^>]*>([\s\S]*?)<\/title>/i) || [])[1]).replace(/<[^>]+>/g, "");
  return t ? t.slice(0, 200) : null;
};
async function leerSitio(net, dominio2) {
  const base = "https://" + dominio2;
  const paginas2 = /* @__PURE__ */ new Map();
  const fuentes = [];
  const add = (p) => {
    let h;
    try {
      h = new URL(p.url, base).hostname.replace(/^www\./, "");
    } catch {
      return;
    }
    if (h !== dominio2 && !h.endsWith("." + dominio2)) return;
    const k = llave(p.url);
    if (!k || k === dominio2 || NO_CONTENIDO.test(p.url)) return;
    const ya = paginas2.get(k);
    paginas2.set(k, { url: p.url, titulo: p.titulo || ya?.titulo || null, fecha: p.fecha || ya?.fecha || null });
  };
  const rb = await leer2(net, base + "/robots.txt");
  const declarados = [...String(rb.body).matchAll(/^\s*sitemap:\s*(\S+)/gim)].map((x) => x[1]);
  for (const u of [.../* @__PURE__ */ new Set([...declarados, ...SITEMAPS.map((s) => base + s)])].slice(0, 5)) {
    const r = await leer2(net, u);
    if (r.status !== 200) continue;
    const sm = parseSitemap(r.body);
    if (!sm.indice) {
      if (sm.entradas.length) {
        sm.entradas.forEach(add);
        fuentes.push("sitemap");
        break;
      }
      continue;
    }
    const hijos = [...sm.entradas].sort((a, b) => ARTICULOS.test(b.url) - ARTICULOS.test(a.url) || String(b.fecha ?? "").localeCompare(String(a.fecha ?? ""))).slice(0, MAX_HIJOS);
    const leidos = await pool(hijos, 3, (h) => leer2(net, h.url));
    for (const h of leidos) if (h.status === 200) parseSitemap(h.body).entradas.forEach(add);
    if (paginas2.size) {
      fuentes.push("sitemap");
      break;
    }
  }
  for (const f of FEEDS) {
    const r = await leer2(net, base + f);
    if (r.status !== 200 || !/<(rss|feed|rdf)[\s:>]/i.test(r.body)) continue;
    const items = parseFeed(r.body);
    if (!items.length) continue;
    items.forEach(add);
    fuentes.push("feed");
    break;
  }
  return { paginas: paginas2, fuentes, error: paginas2.size ? null : rb.error ? "no se pudo leer la web (" + rb.error + ")" : "no declara sitemap ni feed" };
}
function yaCubierto(titulo, propias2) {
  const t = [...new Set(content(titulo))];
  if (t.length < 2) return null;
  let mejor = null;
  for (const p of propias2) {
    const n = t.filter((x) => p.palabras.has(x)).length;
    if (n >= 2 && n / t.length >= 0.5 && (!mejor || n > mejor.n)) mejor = { n, que: p.que };
  }
  return mejor?.que ?? null;
}
async function propias(db, cfg) {
  const pags = (await db.all("SELECT url, titulo, keyword FROM " + P + " WHERE _deleted = 0 AND activa = 1")).filter((p) => isOwnPage(p.url, cfg)).map((p) => ({ que: p.titulo && p.titulo !== p.url ? p.titulo : p.url, palabras: new Set(content([p.titulo, p.keyword, String(p.url).replace(/[/_-]+/g, " ")].join(" "))) }));
  const ops = (await db.all("SELECT tema, keyword, estado FROM " + T + " WHERE _deleted = 0 AND COALESCE(estado, '') != 'descartada'")).map((o) => ({ que: "la oportunidad \xAB" + o.tema + "\xBB", palabras: new Set(content(o.tema + " " + o.keyword)) }));
  return [...pags, ...ops];
}
var tituloDeRuta = (url) => {
  try {
    return decodeURIComponent(new URL(url).pathname.split("/").filter(Boolean).pop() || "").replace(/\.[a-z0-9]+$/i, "").replace(/[-_]+/g, " ").trim();
  } catch {
    return "";
  }
};
async function watchCompetitors(db, _input = {}, net = globalThis.fetch) {
  return withMeter(db, "vigilar_competidores", async (m) => {
    const cfg = await settings(db);
    const own = domainOf2(cfg.dominio);
    const comps = competitorsOf(cfg).filter((c) => c !== own).slice(0, MAX_COMPETIDORES2);
    if (!comps.length) throw new Refused("No hay competidores que vigilar: a\xF1\xE1delos en Ajustes \u2192 General \u2192 Competidores, o adopta alguno en la pesta\xF1a Competidores.", 400);
    const mias = await propias(db, cfg);
    const visto = ahora();
    const resumen = await pool(comps, 3, async (dominio2) => {
      const sitio = await leerSitio(net, dominio2);
      if (sitio.error) return { dominio: dominio2, error: sitio.error, nuevas: 0, paginas: 0 };
      const c = await cacheGet(db, "vistas:" + dominio2);
      const antes = Array.isArray(c?.valor?.urls) ? new Set(c.valor.urls) : null;
      const ahoraTodas = [...sitio.paginas.keys()];
      let nuevas2 = [];
      if (antes) {
        nuevas2 = ahoraTodas.filter((k) => !antes.has(k)).map((k) => sitio.paginas.get(k)).sort((a, b) => String(b.fecha ?? "").localeCompare(String(a.fecha ?? ""))).slice(0, MAX_NUEVAS);
        const sin = nuevas2.filter((p) => !p.titulo).slice(0, MAX_TITULOS);
        const html = await pool(sin, 3, (p) => leer2(net, p.url));
        sin.forEach((p, i) => {
          p.titulo = tituloDeHtml(html[i].body);
        });
        for (const p of nuevas2) {
          if (await db.one("SELECT _id FROM " + N2 + " WHERE url = ? AND _deleted = 0", [p.url])) continue;
          const cubre = yaCubierto(p.titulo || tituloDeRuta(p.url), mias);
          await db.insert(N2, { competidor: dominio2, url: p.url, titulo: p.titulo || "", publicado: p.fecha, visto, cubierto: cubre ? 1 : 0, propia: cubre || "", estado: "nueva" });
        }
      }
      const todas = [.../* @__PURE__ */ new Set([...ahoraTodas, ...antes ?? []])].slice(0, MAX_VISTAS);
      await cacheSet(db, "vistas:" + dominio2, { urls: todas, primera: c?.valor?.primera ?? visto, fuentes: sitio.fuentes });
      return { dominio: dominio2, paginas: sitio.paginas.size, fuentes: sitio.fuentes, primera_lectura: !antes, nuevas: nuevas2.length, sin_cubrir: nuevas2.filter((p) => !yaCubierto(p.titulo || tituloDeRuta(p.url), mias)).length };
    });
    m.notas.push("sin coste: sitemaps y feeds p\xFAblicos de " + comps.length + " competidor" + (comps.length === 1 ? "" : "es"));
    await db.update(A, cfg._id, { vigilado: visto });
    await cacheSet(db, "vigilancia:resumen", resumen);
    const nuevas = resumen.reduce((a, r) => a + (r.nuevas || 0), 0);
    const primeras2 = resumen.filter((r) => r.primera_lectura).length;
    return {
      competidores: comps.length,
      novedades: nuevas,
      sin_cubrir: resumen.reduce((a, r) => a + (r.sin_cubrir || 0), 0),
      primeras_lecturas: primeras2,
      por_competidor: resumen,
      resumen: nuevas ? nuevas + " novedad" + (nuevas === 1 ? "" : "es") + " de la competencia desde la \xFAltima lectura." : primeras2 === comps.length ? "Primera lectura: se han guardado las p\xE1ginas de hoy de cada competidor; las novedades saldr\xE1n a partir de la pr\xF3xima." : "Sin novedades desde la \xFAltima lectura."
    };
  });
}
async function newsView(db) {
  const cfg = await settings(db);
  const desde = new Date(Date.now() - DIAS_VISTA * 864e5).toISOString().slice(0, 19).replace("T", " ");
  const rows = (await db.all("SELECT _id AS id, competidor, url, titulo, publicado, visto, cubierto, propia, estado FROM " + N2 + " WHERE _deleted = 0 AND visto >= ? AND COALESCE(estado, 'nueva') != 'descartada' ORDER BY visto DESC, publicado DESC LIMIT 200", [desde])).map((r) => {
    const que = r.titulo ? "\xAB" + r.titulo + "\xBB" : "una p\xE1gina nueva (" + (tituloDeRuta(r.url) || r.url) + ")";
    return {
      ...r,
      cubierto: !!r.cubierto,
      que: r.titulo || tituloDeRuta(r.url) || r.url,
      tu: r.cubierto ? "ya" : "no",
      objetivo: r.estado === "convertida" ? Number((/(\d+)$/.exec(r.propia || "") || [])[1]) || null : null,
      frase: r.competidor + " ha publicado " + que + "; " + (r.estado === "convertida" ? "ya es uno de tus objetivos" : r.cubierto ? "t\xFA ya tienes " + (/^la oportunidad/.test(r.propia) ? r.propia : "\xAB" + r.propia + "\xBB") : "t\xFA no tienes nada sobre eso") + "."
    };
  });
  const comps = competitorsOf(cfg).filter((c) => c !== domainOf2(cfg.dominio)).slice(0, MAX_COMPETIDORES2);
  const resumen = (await cacheGet(db, "vigilancia:resumen"))?.valor ?? [];
  const sin = rows.filter((r) => !r.cubierto && r.estado !== "convertida");
  return {
    rows,
    competidores: comps,
    vigilado: cfg.vigilado ?? null,
    dias: cfg.vigilado ? Math.floor(horasDesde(cfg.vigilado) / 24) : null,
    por_competidor: resumen,
    coste: (await lastCosts(db)).ultimo.vigilar_competidores ?? null,
    conclusion: !cfg.vigilado ? null : !rows.length ? "Sin novedades de tus " + comps.length + " competidores en los \xFAltimos " + DIAS_VISTA + " d\xEDas." : rows.length + " novedad" + (rows.length === 1 ? "" : "es") + " de tu competencia en los \xFAltimos " + DIAS_VISTA + " d\xEDas; " + (sin.length ? "sobre " + sin.length + " no tienes nada." : "de todas tienes ya algo.")
  };
}
async function newsToGoal(db, { id }) {
  const n = await db.one("SELECT * FROM " + N2 + " WHERE _id = ? AND _deleted = 0", [id]);
  if (!n) throw new Refused("Esa novedad ya no est\xE1.", 404);
  if (n.estado === "convertida") throw new Refused("Ya es un objetivo: " + (n.propia || "mira en \xABObjetivos\xBB") + ".");
  const que = n.titulo || tituloDeRuta(n.url) || "";
  const g = await goalFrom(db, { tema: que, keyword: que, angulo: n.competidor + " ha publicado \xAB" + que + "\xBB y tu web no tiene nada sobre eso. Antes de escribir, mira qu\xE9 se busca de verdad sobre este tema (datos_dataforseo) y qu\xE9 le falta a su p\xE1gina.", fuentes: ["Lo public\xF3 " + n.competidor + ": " + n.url] });
  await db.update(N2, id, { estado: "convertida", propia: "la oportunidad n\xBA " + g.id });
  return { id, objetivo: g.id, nuevo: g.nuevo };
}

// server/services/buscar.mjs
var CRITERIOS = [
  { id: "casi", nombre: "Lo que casi tengo", encuentra: "B\xFAsquedas por las que tu web ya sale en Google, entre la posici\xF3n 8 y la 20: a un empuj\xF3n de la primera p\xE1gina.", comando: "buscar_casi", usd: [0.01, 0.07], tarda: "unos segundos", necesita: ["dominio", "mercado"] },
  { id: "competencia", nombre: "Lo que tiene mi competencia y yo no", encuentra: "B\xFAsquedas en las que salen tus competidores y tu web no.", comando: "buscar_huecos", usd: [0.1, 0.3], tarda: "medio minuto", necesita: ["dominio", "mercado", "competidores"] },
  { id: "publico", nombre: "Lo que busca mi p\xFAblico", encuentra: "Lo que tus clientes buscan en su d\xEDa a d\xEDa, aunque todav\xEDa no te busquen a ti.", comando: "buscar_ideas_publico", usd: [0.05, 0.25], tarda: "medio minuto", necesita: ["mercado", "publico"] },
  { id: "ia", nombre: "D\xF3nde la IA no me nombra", encuentra: "Preguntas que la gente hace a ChatGPT y a Google en las que responden sin nombrarte.", comando: "revisar_ia", usd: [0.03, 0.05], tarda: "unos minutos", necesita: ["mercado", "temas"] },
  { id: "defender", nombre: "Lo que ya tengo y puedo subir", encuentra: "B\xFAsquedas por las que ya sales en la primera p\xE1gina: mantenerlas o subirlas a los tres primeros, donde est\xE1n los clics.", comando: "buscar_defender", usd: [0, 0.03], tarda: "unos segundos", necesita: ["dominio"] },
  { id: "empezar", nombre: "Por d\xF3nde empezar con una web nueva", encuentra: "B\xFAsquedas largas y concretas sobre tus temas, con poca competencia: las que una web peque\xF1a s\xED puede ganar.", comando: "buscar_empezar", usd: [0, 0], tarda: "unos segundos", necesita: ["temas"] }
];
var CRITERIO = Object.fromEntries(CRITERIOS.map((c) => [c.id, c]));
var BUSCANDO_CRITERIO = { casi: "Buscando lo que casi tienes\u2026", competencia: "Buscando lo que tiene tu competencia y t\xFA no\u2026", publico: "Buscando lo que busca tu p\xFAblico\u2026", ia: "Preguntando a las IA\u2026", defender: "Mirando lo que ya tienes en la primera p\xE1gina\u2026", empezar: "Buscando por d\xF3nde empezar\u2026", medir: "Midiendo las mejores: cu\xE1nto se buscan, qui\xE9n sale hoy y si se pueden ganar\u2026" };
var MERCADOS = [
  { id: "es", nombre: "Espa\xF1a", pais: "es", idioma: "es", ubicacion: 2724, tld: ["es", "cat", "eus", "gal"] },
  { id: "mx", nombre: "M\xE9xico", pais: "mx", idioma: "es", ubicacion: 2484, tld: ["mx"] },
  { id: "ar", nombre: "Argentina", pais: "ar", idioma: "es", ubicacion: 2032, tld: ["ar"] },
  { id: "co", nombre: "Colombia", pais: "co", idioma: "es", ubicacion: 2170, tld: ["co"] },
  { id: "cl", nombre: "Chile", pais: "cl", idioma: "es", ubicacion: 2152, tld: ["cl"] },
  { id: "pe", nombre: "Per\xFA", pais: "pe", idioma: "es", ubicacion: 2604, tld: ["pe"] },
  { id: "us", nombre: "Estados Unidos (ingl\xE9s)", pais: "us", idioma: "en", ubicacion: 2840, tld: ["us"] },
  { id: "us-es", nombre: "Estados Unidos (espa\xF1ol)", pais: "us", idioma: "es", ubicacion: 2840, tld: [] },
  { id: "uk", nombre: "Reino Unido", pais: "gb", idioma: "en", ubicacion: 2826, tld: ["uk"] },
  { id: "fr", nombre: "Francia", pais: "fr", idioma: "fr", ubicacion: 2250, tld: ["fr"] },
  { id: "de", nombre: "Alemania", pais: "de", idioma: "de", ubicacion: 2276, tld: ["de"] },
  { id: "it", nombre: "Italia", pais: "it", idioma: "it", ubicacion: 2380, tld: ["it"] },
  { id: "pt", nombre: "Portugal", pais: "pt", idioma: "pt", ubicacion: 2620, tld: ["pt"] },
  { id: "br", nombre: "Brasil", pais: "br", idioma: "pt", ubicacion: 2076, tld: ["br"] }
];
var lista4 = (s) => (Array.isArray(s) ? s : String(s ?? "").split(/[;\n]/)).map((x) => String(x ?? "").trim()).filter(Boolean);
var unicos = (l, clave2 = (x) => String(x).toLowerCase()) => [...new Map(l.map((x) => [clave2(x), x])).values()];
var mercadoDe = (cfg) => MERCADOS.find((m) => m.ubicacion === Number(cfg.ubicacion) && m.idioma === String(cfg.idioma || "").trim().toLowerCase()) ?? null;
function nivelSitio({ consultas = [], diagnostico = null, dominio: dominio2 = "" } = {}) {
  const propias2 = consultas.filter((q) => q.consulta && !esMarca(q.consulta, dominio2) && q.posicion != null);
  const mejor = /* @__PURE__ */ new Map();
  for (const q of propias2) {
    const k = String(q.consulta).toLowerCase();
    const p = Number(q.posicion);
    if (!mejor.has(k) || p < mejor.get(k)) mejor.set(k, p);
  }
  const pos = [...mejor.values()];
  const top3 = pos.filter((p) => p <= 3.5).length, top10 = pos.filter((p) => p <= 10.5).length, top20 = pos.filter((p) => p <= 20.5).length;
  const d10 = Number(diagnostico?.keywords_top10) || 0, d100 = Number(diagnostico?.keywords_top100) || 0;
  const sabe = consultas.length > 0 || !!diagnostico;
  const nivel = top10 >= 10 || d10 >= 20 ? "fuerte" : top20 < 3 && d100 < 10 ? "nuevo" : "medio";
  const frase = !sabe ? "Todav\xEDa no s\xE9 c\xF3mo est\xE1 tu web en Google (falta el diagn\xF3stico o Search Console), as\xED que empiezo como con una web nueva: por b\xFAsquedas concretas que se pueden ganar." : nivel === "fuerte" ? "Tu web ya sale en la primera p\xE1gina por " + Math.max(top10, d10) + " b\xFAsquedas" + (top3 ? " (" + top3 + " entre las tres primeras)" : "") + ". Lo que toca: defender lo ganado, empujar lo que casi tienes y subir de nivel con lo que tiene tu competencia." : nivel === "nuevo" ? "Tu web casi no sale todav\xEDa en Google por lo que haces. Lo que toca: empezar por b\xFAsquedas largas y concretas, que una web peque\xF1a s\xED puede ganar, y por lo que busca tu p\xFAblico." : "Tu web ya sale por algunas b\xFAsquedas (" + top10 + " en la primera p\xE1gina, " + top20 + " entre las veinte primeras). Lo que toca: empujar lo que casi tienes y cubrir lo que tiene tu competencia y t\xFA no.";
  return { nivel, sabe, top3, top10, top20, frase };
}
var RECOMENDADOS = { fuerte: ["defender", "casi", "competencia", "ia"], medio: ["casi", "competencia", "publico"], nuevo: ["empezar", "publico", "competencia"] };
function proponer({ cfg = {}, propuestos = [], paginas: paginas2 = [], consultas = [], plan = [] } = {}) {
  const dominio2 = domainOf2(cfg.dominio);
  const tld = dominio2.split(".").pop();
  const mer = mercadoDe(cfg);
  const porTld = !mer && !Number(cfg.ubicacion) ? MERCADOS.find((m) => m.tld.includes(tld)) ?? null : null;
  const mercado = mer ? { valor: mer.id, nombre: mer.nombre, de: "ajustes" } : Number(cfg.ubicacion) && cfg.idioma ? { valor: "otro", nombre: cfg.mercado || "El de Ajustes", de: "ajustes" } : porTld ? { valor: porTld.id, nombre: porTld.nombre, de: "dominio", por_que: "Tu web acaba en ." + tld } : { valor: null, nombre: null, de: null, falta: "Elige el pa\xEDs y el idioma en los que quieres aparecer." };
  const mios = competitorsOf(cfg);
  const prop = unicos(propuestos.map((p) => ({ dominio: domainOf2(p.dominio), por_que: p.keywords ? "sale en Google para " + p.keywords + " de tus b\xFAsquedas" : "sale en Google para tus b\xFAsquedas" })).filter((p) => p.dominio && p.dominio !== dominio2 && !mios.includes(p.dominio)), (p) => p.dominio).slice(0, 8);
  const competidores = mios.length ? { valor: mios, de: "ajustes", propuestos: prop } : prop.length ? { valor: prop.slice(0, 5).map((p) => p.dominio), de: "propuestos", propuestos: prop, por_que: "Son los que salen en Google para tus b\xFAsquedas: quita los que no compiten contigo." } : { valor: [], de: null, propuestos: [], falta: "A\xFAn no s\xE9 qui\xE9n compite contigo: escribe sus webs o deja que los busque." };
  const w = audienceWords(cfg);
  const publico = String(cfg.publico || "").trim() ? { valor: String(cfg.publico).trim(), palabras: w.palabras, de: "ajustes" } : { valor: "", palabras: w.palabras, de: null, falta: "Di en una frase qui\xE9n es tu cliente: a qui\xE9n le vendes y qu\xE9 le preocupa." };
  const quien = { valor: quienOf(cfg), nombre: QUIEN[quienOf(cfg)], de: ["compra", "trabajo"].includes(String(cfg.intencion || "").trim()) ? "ajustes" : "por_defecto" };
  const semillas = unicos(semillasCortas(cfg).map((s) => s.corta).filter(Boolean));
  const deWeb = unicos([
    ...plan.map((p) => p.keyword),
    ...[...consultas].filter((q) => q.consulta && !esMarca(q.consulta, dominio2)).sort((a, b) => (Number(b.impresiones) || 0) - (Number(a.impresiones) || 0)).map((q) => q.consulta),
    ...paginas2.map((p) => p.keyword)
  ].map((x) => String(x || "").trim().toLowerCase()).filter((x) => x && content(x).length >= 1 && x.split(" ").length <= 5)).slice(0, 6);
  const temas = semillas.length ? { valor: semillas, de: "ajustes" } : deWeb.length ? { valor: deWeb, de: "web", por_que: "Es de lo que ya habla tu web (sus p\xE1ginas y por lo que sale en Google): deja lo que vendes." } : { valor: [], de: null, falta: "Escribe de 2 a 6 temas cortos: lo que vendes, como lo buscar\xEDa un cliente (\xABprograma de facturaci\xF3n\xBB, \xABabogado laboralista\xBB)." };
  return { dominio: dominio2 ? { valor: dominio2, de: "ajustes" } : { valor: "", de: null, falta: "Escribe la direcci\xF3n de tu web." }, mercado, competidores, publico, quien, temas };
}
function ajustesDe(confirmado = {}, cfg = {}) {
  const out = {};
  const c = confirmado ?? {};
  if (c.dominio != null) {
    const d = domainOf2(c.dominio);
    if (d && !/^[a-z0-9-]+(\.[a-z0-9-]+)+$/.test(d)) throw new Refused("\xAB" + c.dominio + "\xBB no parece la direcci\xF3n de una web. Escr\xEDbela como tuweb.com.", 400);
    if (d && d !== domainOf2(cfg.dominio)) out.dominio = d;
  }
  if (c.mercado != null && c.mercado !== "otro") {
    const m = MERCADOS.find((x) => x.id === c.mercado);
    if (!m) throw new Refused("No conozco ese mercado: elige uno de la lista, o ponlo en Ajustes \u2192 General (pa\xEDs, idioma y ubicaci\xF3n de DataForSEO).", 400);
    if (Number(cfg.ubicacion) !== m.ubicacion || String(cfg.idioma || "").toLowerCase() !== m.idioma) Object.assign(out, { ubicacion: m.ubicacion, idioma: m.idioma, pais: m.pais, mercado: m.nombre.replace(/ \(.*\)$/, "") });
  }
  if (c.competidores != null) {
    const l = unicos(lista4(c.competidores).map(domainOf2).filter((d) => /^[a-z0-9-]+(\.[a-z0-9-]+)+$/.test(d) && d !== domainOf2(out.dominio ?? cfg.dominio)));
    if (l.join("; ") !== competitorsOf(cfg).join("; ")) out.competidores = l.join("; ");
  }
  if (c.publico != null && String(c.publico).trim() !== String(cfg.publico || "").trim()) out.publico = String(c.publico).trim().slice(0, 600);
  if (c.quien != null) {
    if (!["compra", "trabajo", "ambas"].includes(c.quien)) throw new Refused("\xABA qui\xE9n quieres atraer\xBB es compra, trabajo o ambas.", 400);
    if (c.quien !== quienOf(cfg) || !cfg.intencion) out.intencion = c.quien;
  }
  if (c.temas != null) {
    const l = unicos(lista4(c.temas).map((t) => t.slice(0, 80))).slice(0, 12);
    if (l.join("; ") !== lista4(cfg.semillas).join("; ")) out.semillas = l.join("; ");
  }
  return out;
}
function faltaPara(id, cfg) {
  const c = CRITERIO[id];
  if (!c) return "No conozco ese criterio.";
  for (const n of c.necesita) {
    if (n === "dominio" && !domainOf2(cfg.dominio)) return "Falta la direcci\xF3n de tu web.";
    if (n === "mercado" && !(Number(cfg.ubicacion) && String(cfg.idioma || "").trim())) return "Falta el pa\xEDs y el idioma en los que quieres aparecer.";
    if (n === "competidores" && !competitorsOf(cfg).length) return "Faltan tus competidores: escribe sus webs o b\xFAscalos antes.";
    if (n === "publico" && !audienceWords(cfg).palabras.length) return "Falta decir qui\xE9n es tu p\xFAblico.";
    if (n === "temas" && !semillasCortas(cfg).length && !lista4(cfg.preguntas_ia).length && !audienceWords(cfg).palabras.length) return "Faltan tus temas: lo que vendes, como lo buscar\xEDa un cliente.";
  }
  return null;
}
var rango = ([a, b]) => !b ? "Gratis" : a === b ? "unos " + usd(a) : !a ? "Gratis o hasta " + usd(b) : "unos " + usd(a).replace(" $", "") + "\u2013" + usd(b);
function planear({ criterios = [], cfg = {}, medir: medir2 = true } = {}) {
  const ids = unicos(lista4(criterios)).filter((id) => CRITERIO[id]);
  if (!ids.length) throw new Refused("Elige al menos un criterio: " + CRITERIOS.map((c) => c.id).join(", ") + ".", 400);
  const pasos = [], falta = [];
  for (const c of CRITERIOS.filter((x) => ids.includes(x.id)).sort((a, b) => a.usd[1] - b.usd[1])) {
    const que = faltaPara(c.id, cfg);
    if (que) {
      falta.push({ criterio: c.id, nombre: c.nombre, que });
      continue;
    }
    pasos.push({ id: c.id, criterio: c.id, nombre: c.nombre, comando: c.comando, params: {}, texto: BUSCANDO_CRITERIO[c.id], usd: c.usd });
  }
  if (medir2 !== false && medir2 !== "false" && pasos.length && !faltaPara("casi", { ...cfg, dominio: cfg.dominio || "x.com" }))
    pasos.push({ id: "medir", criterio: null, nombre: "Medir las " + MAX_MEDIR + " mejores", comando: "medir_candidatos", params: { max: MAX_MEDIR }, texto: BUSCANDO_CRITERIO.medir, usd: [0, costeMedir(MAX_MEDIR)] });
  const total = [pasos.reduce((a, p) => a + p.usd[0], 0), pasos.reduce((a, p) => a + p.usd[1], 0)];
  return { pasos, falta, usd: total, coste: rango(total) };
}
async function loQueSabe(db, cfg) {
  const dominio2 = domainOf2(cfg.dominio);
  const consultas = ultimoPeriodo(await db.all("SELECT consulta, pagina, impresiones, posicion, desde, hasta FROM " + C + " WHERE origen = 'search_console' AND _deleted = 0"));
  const d = await latest(db).catch(() => null);
  const propuestos = await db.all("SELECT dominio, semillas_n AS keywords FROM " + CP + " WHERE estado = 'propuesto' AND _deleted = 0 ORDER BY semillas_n DESC LIMIT 12").catch(() => []);
  const paginas2 = await db.all("SELECT titulo, keyword FROM " + P + " WHERE _deleted = 0 AND COALESCE(keyword, '') != '' LIMIT 40").catch(() => []);
  return { dominio: dominio2, consultas, diagnostico: d, propuestos, paginas: paginas2, plan: d?.plan ?? [] };
}
var ULTIMA = "busqueda:ultima";
async function preparar(db) {
  const cfg = await settings(db);
  const s = await loQueSabe(db, cfg);
  const nivel = nivelSitio(s);
  const recomendados = RECOMENDADOS[nivel.nivel];
  const ultima = (await cacheGet(db, ULTIMA))?.valor ?? null;
  return {
    criterios: CRITERIOS.map((c) => ({ id: c.id, nombre: c.nombre, encuentra: c.encuentra, coste: rango(c.usd), usd: c.usd, tarda: c.tarda, comando: c.comando, necesita: c.necesita, recomendado: recomendados.includes(c.id), falta: faltaPara(c.id, cfg) })),
    recomendados,
    nivel,
    propuesta: proponer({ cfg, ...s }),
    mercados: MERCADOS.map((m) => ({ id: m.id, nombre: m.nombre })),
    medir: { n: MAX_MEDIR, coste: "hasta " + usd(costeMedir(MAX_MEDIR)), usd: [0, costeMedir(MAX_MEDIR)] },
    ultima,
    primera_vez: !ultima
  };
}
async function confirmarYPlanear(db, { criterios, ajustes, medir: medir2 } = {}) {
  let cfg = await settings(db);
  const conf = typeof ajustes === "string" ? JSON.parse(ajustes || "{}") : ajustes ?? {};
  const cambios = ajustesDe(conf, cfg);
  if (Object.keys(cambios).length) {
    await db.update(A, cfg._id, cambios);
    cfg = await settings(db);
  }
  const plan = planear({ criterios, cfg, medir: medir2 });
  await cacheSet(db, ULTIMA, { fecha: ahora(), criterios: plan.pasos.filter((p) => p.criterio).map((p) => p.criterio) });
  return { ...plan, guardado: Object.keys(cambios) };
}
var DEFENDER = "criterio:defender";
var EMPEZAR = "criterio:empezar";
var DEFENDER_HASTA = 10;
var DEFENDER_MAX = 20;
var EMPEZAR_MAX = 30;
var EMPEZAR_TEMAS = 6;
function yaTienes(consultas, dominio2) {
  const por = /* @__PURE__ */ new Map();
  for (const q of consultas ?? []) {
    const p = Number(q.posicion);
    const k = String(q.consulta || "").trim().toLowerCase();
    if (!k || !(p > 0 && p <= DEFENDER_HASTA + 0.5) || esMarca(k, dominio2)) continue;
    const x = por.get(k);
    if (!x || p < x.posicion) por.set(k, { keyword: k, posicion: Math.round(p * 10) / 10, url: q.pagina || x?.url || null, impresiones: (x?.impresiones || 0) + (Number(q.impresiones) || 0), fuente: "search_console" });
    else x.impresiones += Number(q.impresiones) || 0;
  }
  return [...por.values()].sort((a, b) => b.impresiones - a.impresiones).slice(0, DEFENDER_MAX);
}
async function findDefend(db, _i = {}, keys = keysClient(), integ = void 0) {
  return withMeter(db, "buscar_defender", async (m) => {
    const cfg = await settings(db);
    const dom2 = domainOf2(cfg.dominio);
    if (!dom2) throw new Refused("Falta el dominio en Ajustes (General \u2192 Dominio).", 400);
    const avisos = [];
    await (integ ? refreshSearchConsole(db, {}, integ) : refreshSearchConsole(db, {})).catch((e) => {
      avisos.push("Search Console no se pudo leer ahora (" + String(e.message).slice(0, 160) + ")");
    });
    const consultas = ultimoPeriodo(await db.all("SELECT consulta, pagina, impresiones, posicion, desde, hasta FROM " + C + " WHERE origen = 'search_console' AND _deleted = 0"));
    let filas2 = yaTienes(consultas, dom2);
    let fuente = "search_console";
    if (!filas2.length && Number(cfg.ubicacion) && cfg.idioma) {
      fuente = "dataforseo";
      const r = await dfsPaginas(keys, "dataforseo_labs/google/ranked_keywords/live", {
        target: dom2,
        location_code: Number(cfg.ubicacion),
        language_code: String(cfg.idioma).trim().toLowerCase(),
        item_types: ["organic"],
        load_rank_absolute: false,
        filters: [["ranked_serp_element.serp_item.rank_group", "<=", DEFENDER_HASTA]],
        order_by: ["keyword_data.keyword_info.search_volume,desc"]
      }, m, { total: 100, pagina: 100, recordar: paginaRecordada(db) });
      const por = /* @__PURE__ */ new Map();
      for (const it of r.items ?? []) {
        const kd = it.keyword_data ?? {}, s = it.ranked_serp_element?.serp_item ?? {};
        const keyword = String(kd.keyword || "").toLowerCase();
        const posicion = Number(s.rank_group);
        if (!keyword || !(posicion >= 1 && posicion <= DEFENDER_HASTA) || esMarca(keyword, dom2) || por.has(keyword)) continue;
        por.set(keyword, { keyword, posicion, url: s.url || null, volumen: kd.keyword_info?.search_volume ?? null, dificultad: kdOf(kd.keyword_properties?.keyword_difficulty), intencion: intentOf(kd.search_intent_info?.main_intent), fuente: "dataforseo" });
      }
      filas2 = [...por.values()].slice(0, DEFENDER_MAX);
      avisos.push(...r.avisos ?? []);
    }
    const antes = new Set(((await cacheGet(db, DEFENDER))?.valor?.filas ?? []).map((f) => f.keyword));
    await cacheSet(db, DEFENDER, { filas: filas2, fuente });
    return { dominio: dom2, keywords: filas2.length, nuevas: filas2.filter((f) => !antes.has(f.keyword)).length, top3: filas2.filter((f) => f.posicion <= 3.5).length, fuente, ...avisos.length ? { avisos } : {} };
  });
}
var defendidas = async (db) => (await cacheGet(db, DEFENDER))?.valor?.filas ?? [];
function largas(frases, tema, { marca = "" } = {}) {
  const t = new Set(content(tema));
  const b = String(marca || "").toLowerCase();
  return unicos((frases ?? []).map((f) => String(f || "").toLowerCase().trim().replace(/\s+/g, " ")).filter((f) => {
    const w = tokens(f);
    return w.length >= 3 && f.length <= 80 && content(f).some((x) => t.has(x)) && !(b.length >= 3 && w.join("").includes(b)) && f !== String(tema).toLowerCase().trim();
  }));
}
async function findStarters(db, input = {}, net = globalThis.fetch) {
  const cfg = await settings(db);
  const temas = unicos([...semillasCortas(cfg).map((s) => s.corta), ...audienceWords(cfg).palabras].filter(Boolean)).slice(0, EMPEZAR_TEMAS);
  if (!temas.length) throw new Refused("Faltan tus temas: en Ajustes \u2192 General \u2192 \xABTemas semilla\xBB escribe lo que vendes, como lo buscar\xEDa un cliente (o dilo en \xABBuscar nuevas oportunidades\xBB).", 400);
  const marca = brandOf(cfg.dominio);
  const filas2 = [];
  const fallos = [];
  for (const tema of temas) {
    const r = await autocompletar(db, net, tema, cfg, { forzar: input?.forzar === true || input?.forzar === "true" });
    if (r.error) fallos.push(r.error);
    for (const keyword of largas(r.frases, tema, { marca }).slice(0, 8)) if (!filas2.some((f) => f.keyword === keyword)) filas2.push({ keyword, tema });
  }
  if (!filas2.length && fallos.length) throw new Refused("Google no respondi\xF3 a las sugerencias (" + fallos[0] + "). Prueba de nuevo en un momento.", 502);
  const antes = new Set(((await cacheGet(db, EMPEZAR))?.valor?.filas ?? []).map((f) => f.keyword));
  const guardar2 = filas2.slice(0, EMPEZAR_MAX);
  await cacheSet(db, EMPEZAR, { filas: guardar2 });
  return { keywords: guardar2.length, nuevas: guardar2.filter((f) => !antes.has(f.keyword)).length, temas, coste_usd: 0, coste: usd(0) };
}
var paraEmpezar = async (db) => (await cacheGet(db, EMPEZAR))?.valor?.filas ?? [];
async function candidateToGoal(db, { fuente, clave: clave2 } = {}) {
  const k = String(clave2 || "").trim().toLowerCase();
  if (!["defender", "empezar"].includes(fuente) || !k) throw new Refused("Di cu\xE1l: { fuente: defender | empezar, clave: la b\xFAsqueda }.", 400);
  if (fuente === "defender") {
    const f2 = (await defendidas(db)).find((x) => x.keyword === k) ?? yaTienes(ultimoPeriodo(await db.all("SELECT consulta, pagina, impresiones, posicion, desde, hasta FROM " + C + " WHERE origen = 'search_console' AND _deleted = 0")), domainOf2((await settings(db)).dominio)).find((x) => x.keyword === k);
    if (!f2) throw new Refused("Esa b\xFAsqueda ya no est\xE1 entre las que tienes en la primera p\xE1gina.", 404);
    const p = Math.round(f2.posicion);
    const g2 = await goalFrom(db, { tema: k, keyword: k, formato: "articulo", fuentes: [f2.url], angulo: "Tu web ya sale en la posici\xF3n " + p + (f2.url ? " con " + f2.url : "") + ". " + (p <= 3 ? "El objetivo es mantenerla: tener ese contenido al d\xEDa y mejor que el de quien viene detr\xE1s (acci\xF3n \xABRefrescar un contenido\xBB)." : "El objetivo es subirla a los tres primeros: mejorar esa p\xE1gina con lo que cubren los que est\xE1n delante (acci\xF3n \xABRefrescar un contenido\xBB) y enlazarla desde el resto de la web.") });
    if (g2.nuevo && f2.volumen != null) await db.update(T, g2.id, { volumen: f2.volumen, dificultad: f2.dificultad ?? null, intencion: f2.intencion ?? null });
    return { objetivo: g2.id, nuevo: g2.nuevo };
  }
  const f = (await paraEmpezar(db)).find((x) => x.keyword === k);
  if (!f) throw new Refused("Esa b\xFAsqueda ya no est\xE1 en la lista.", 404);
  const g = await goalFrom(db, { tema: k, keyword: k, formato: "articulo", angulo: "Una b\xFAsqueda larga y concreta sobre \xAB" + f.tema + "\xBB: responderla bien, con un caso o un dato propio, es como una web que empieza gana sus primeras posiciones." });
  return { objetivo: g.id, nuevo: g.nuevo };
}
var corto2 = (r) => Object.fromEntries(Object.entries(r ?? {}).filter(([, v]) => v == null || ["number", "string", "boolean"].includes(typeof v)).map(([k, v]) => [k, typeof v === "string" ? v.slice(0, 200) : v]));
async function searchNew(db, input = {}, keys = keysClient(), net = globalThis.fetch, { candidatos: candidatos2 = async () => [] } = {}) {
  const plan = await confirmarYPlanear(db, input);
  const RUN = {
    buscar_casi: () => findAlmost(db, {}, keys),
    buscar_huecos: () => findGaps(db, {}, keys),
    buscar_ideas_publico: () => findAudienceIdeas(db, {}, keys, net),
    revisar_ia: () => reviewAI(db, {}, keys),
    buscar_defender: () => findDefend(db, {}, keys),
    buscar_empezar: () => findStarters(db, {}, net),
    medir_candidatos: async () => medirCandidatos(db, { max: MAX_MEDIR }, keys, { candidatos: await candidatos2() })
  };
  const pasos = [];
  let gastado = 0;
  for (const p of plan.pasos) {
    try {
      const r = await RUN[p.comando]();
      gastado += Number(r?.coste_usd) || 0;
      pasos.push({ paso: p.id, comando: p.comando, hecho: true, resultado: corto2(r) });
    } catch (e) {
      pasos.push({ paso: p.id, comando: p.comando, hecho: false, error: String(e.message).slice(0, 300) });
      if (e.status === 424) break;
    }
  }
  return { pasos, falta: plan.falta, guardado: plan.guardado, coste_usd: Math.round(gastado * 1e4) / 1e4, coste: usd(gastado), leer: "What it found, each with its figures and whether it can be won: descubrir." };
}

// server/services/descubrir.mjs
var FUENTES = {
  casi: "Casi la tienes",
  plan: "Del diagn\xF3stico",
  competencia: "Tu competencia la tiene y t\xFA no",
  publico: "La busca tu p\xFAblico",
  ia: "La IA no te nombra",
  defender: "Ya la tienes",
  empezar: "Para empezar"
};
var ORDEN = ["defender", "casi", "plan", "competencia", "publico", "ia", "empezar"];
var norm5 = (s) => String(s ?? "").toLowerCase().replace(/[¿?¡!«»"“”:;.,()]/g, " ").replace(/\s+/g, " ").trim();
var DESCARTE = (fuente, clave2) => "descubrir:descartado:" + fuente + ":" + norm5(clave2);
async function candidates(db) {
  const cfg = await settings(db);
  const goals = new Set((await db.all("SELECT keyword FROM " + T + " WHERE _deleted = 0")).map((g) => norm5(g.keyword)));
  const out = [];
  for (const c of await db.all("SELECT _id AS id, keyword, posicion, volumen, dificultad, url FROM " + Q + " WHERE estado = 'nueva' AND COALESCE(origen, '') != 'ejemplo' AND _deleted = 0 ORDER BY volumen DESC LIMIT 100"))
    out.push({ fuente: "casi", clave: c.keyword, titulo: c.keyword, volumen: c.volumen, dificultad: kdOf(c.dificultad), por_que: "Ya sales en la posici\xF3n " + Math.round(Number(c.posicion) || 0) + (c.url ? " con " + c.url : "") + ": mejorarla es lo m\xE1s r\xE1pido.", convertir: { command: "casi_a_oportunidad", params: { id: c.id } }, descartar: { command: "update_casi", params: { id: c.id, estado: "descartada" } } });
  const d = await latest(db).catch(() => null);
  for (const p of (d?.plan || []).filter((x) => x.fiable !== false && !x.oportunidad)) {
    if (await cacheGet(db, DESCARTE("plan", p.keyword))) continue;
    out.push({ fuente: "plan", clave: p.keyword, titulo: p.keyword, volumen: p.volumen, dificultad: kdOf(p.dificultad), ganable: p.nivel || null, por_que: p.por_que || p.razon || "Una de las p\xE1ginas que el diagn\xF3stico ve m\xE1s ganables.", convertir: { command: "diagnostico_a_oportunidades", params: { keyword: p.keyword } }, descartar: { command: "descartar_candidato", params: { fuente: "plan", clave: p.keyword } } });
  }
  for (const h of await db.all("SELECT _id AS id, keyword, volumen, dificultad, ganable, por_que, competidores FROM " + H + " WHERE estado = 'nuevo' AND COALESCE(origen, '') != 'ejemplo' AND _deleted = 0 ORDER BY ganable DESC, volumen DESC LIMIT 100"))
    out.push({ fuente: "competencia", clave: h.keyword, titulo: h.keyword, volumen: h.volumen, dificultad: kdOf(h.dificultad), por_que: h.por_que || "Sale tu competencia" + (h.competidores ? " (" + h.competidores + ")" : "") + " y t\xFA no.", convertir: { command: "hueco_a_oportunidad", params: { id: h.id } }, descartar: { command: "update_hueco", params: { id: h.id, estado: "descartado" } } });
  const nv = await newsView(db).catch(() => ({ rows: [] }));
  for (const n of nv.rows.filter((x) => !x.cubierto && !x.objetivo && x.estado !== "convertida"))
    out.push({ fuente: "competencia", clave: n.que, titulo: n.que, por_que: n.competidor + " lo ha publicado y t\xFA no tienes nada sobre eso.", url: n.url, convertir: { command: "novedad_a_objetivo", params: { id: n.id } }, descartar: { command: "update_novedad", params: { id: n.id, estado: "descartada" } } });
  for (const x of await db.all("SELECT _id AS id, keyword, volumen, dificultad, puente FROM " + I + " WHERE estado = 'nueva' AND COALESCE(puente, '') != '' AND _deleted = 0 ORDER BY puntuacion DESC LIMIT 60"))
    out.push({ fuente: "publico", clave: x.keyword, titulo: x.keyword, volumen: x.volumen, dificultad: kdOf(x.dificultad), por_que: x.puente, convertir: { command: "idea_a_oportunidad", params: { id: x.id } }, descartar: { command: "update_idea", params: { id: x.id, estado: "descartada", motivo: "Descartada en Descubrir" } } });
  const ia = await aiView(db).catch(() => ({ temas: [] }));
  for (const t of ia.temas.filter((x) => x.respondio && x.tu !== "citada" && !x.objetivo)) {
    if (await cacheGet(db, DESCARTE("ia", t.tema))) continue;
    out.push({ fuente: "ia", clave: t.tema, titulo: t.tema, por_que: t.frase + ".", convertir: { command: "ia_a_objetivo", params: { tema: t.tema } }, descartar: { command: "descartar_candidato", params: { fuente: "ia", clave: t.tema } } });
  }
  const consultas = ultimoPeriodo(await db.all("SELECT consulta, pagina, impresiones, posicion, desde, hasta FROM " + C + " WHERE origen = 'search_console' AND _deleted = 0").catch(() => []));
  const tengo = new Map([...await defendidas(db).catch(() => []), ...yaTienes(consultas, domainOf2(cfg.dominio))].map((f) => [f.keyword, f]));
  for (const f of tengo.values()) {
    if (await cacheGet(db, DESCARTE("defender", f.keyword))) continue;
    const p = Math.round(f.posicion);
    out.push({
      fuente: "defender",
      clave: f.keyword,
      titulo: f.keyword,
      volumen: f.volumen ?? null,
      dificultad: kdOf(f.dificultad),
      posicion: f.posicion,
      url: f.url || void 0,
      por_que: p <= 3 ? "Ya sales en la posici\xF3n " + p + ": es tuya. Mantenerla al d\xEDa cuesta poco y perderla, mucho." : "Ya sales en la posici\xF3n " + p + ", en la primera p\xE1gina: subirla a las tres primeras es donde est\xE1n los clics.",
      convertir: { command: "candidato_a_objetivo", params: { fuente: "defender", clave: f.keyword } },
      descartar: { command: "descartar_candidato", params: { fuente: "defender", clave: f.keyword } }
    });
  }
  for (const f of await paraEmpezar(db).catch(() => [])) {
    if (await cacheGet(db, DESCARTE("empezar", f.keyword))) continue;
    out.push({
      fuente: "empezar",
      clave: f.keyword,
      titulo: f.keyword,
      por_que: "Una b\xFAsqueda larga y concreta sobre \xAB" + f.tema + "\xBB, tal como la escribe la gente en Google: suelen tener poca competencia, y son por donde una web que empieza gana sus primeras posiciones.",
      convertir: { command: "candidato_a_objetivo", params: { fuente: "empezar", clave: f.keyword } },
      descartar: { command: "descartar_candidato", params: { fuente: "empezar", clave: f.keyword } }
    });
  }
  const visto = new Set(goals);
  const filas2 = [];
  for (const f of ORDEN) for (const c of out.filter((x) => x.fuente === f)) {
    const k = norm5(c.clave);
    if (!k || visto.has(k)) continue;
    visto.add(k);
    filas2.push({ ...c, id: c.fuente + ":" + k, fuente_txt: FUENTES[c.fuente] });
  }
  const quien = quienOf(cfg);
  const guardados = await top10Guardados(db, filas2.map((c) => c.titulo), cfg).catch(() => /* @__PURE__ */ new Map());
  const medidas = await medidasDe(db, filas2.map((c) => c.titulo), cfg).catch(() => /* @__PURE__ */ new Map());
  const una = usd(costeMedir(1));
  const conPublico = filas2.map((c) => {
    const g = guardados.get(c.titulo);
    const md = medidas.get(c.titulo) ?? null;
    const publico = fit({ keyword: c.titulo, top10: g ? organicTop(g.items, { n: 10 }).validos : null }, quien);
    const ganar = !md?.top10 && c.fuente === "plan" && c.ganable ? { ...lecturaGanar(null, { publico }), veredicto: { alta: "si", media: "pelear", baja: "dificil" }[c.ganable], titulo: { alta: "Se puede ganar", media: "Se puede pelear", baja: "Dif\xEDcil hoy" }[c.ganable], tono: { alta: "good", media: "warn", baja: "bad" }[c.ganable], frase: c.por_que, medida: true } : lecturaGanar(md, { publico, posicion: c.posicion ?? null, coste: una });
    return { ...c, volumen: md?.volumen ?? c.volumen ?? null, dificultad: md?.dificultad ?? c.dificultad ?? null, publico, top10: !!g || !!md?.top10, medida: medidaBreve(md), ganar };
  });
  const porGanar = (l) => [...l].sort((a, b) => (GANAR_ORDEN[a.ganar.veredicto] ?? 3) - (GANAR_ORDEN[b.ganar.veredicto] ?? 3));
  const ordenadas = [...porGanar(conPublico.filter((c) => c.publico.encaja !== false)), ...porGanar(conPublico.filter((c) => c.publico.encaja === false))];
  const por_fuente = Object.fromEntries(ORDEN.map((f) => [f, ordenadas.filter((x) => x.fuente === f).length]));
  const sinMedir = ordenadas.filter((c) => !c.ganar.medida && c.publico.encaja !== false).length;
  const nivel = nivelSitio({ consultas, diagnostico: d, dominio: domainOf2(cfg.dominio) });
  const cuenta = (v) => ordenadas.filter((c) => v.includes(c.ganar.veredicto)).length;
  return {
    candidatos: ordenadas,
    por_fuente,
    fuentes: FUENTES,
    modo: cfg.modo || "ambos",
    total: ordenadas.length,
    quien,
    quien_txt: QUIEN[quien],
    no_encajan: ordenadas.filter((c) => c.publico.encaja === false).length,
    ganables: cuenta(["si", "tuya", "subir"]),
    peleables: cuenta(["pelear"]),
    dificiles: cuenta(["dificil"]),
    sin_medir: sinMedir,
    medir: sinMedir ? { n: Math.min(sinMedir, MAX_MEDIR), coste: "hasta " + usd(costeMedir(Math.min(sinMedir, MAX_MEDIR))) } : null,
    nivel,
    siguiente: siguientePaso(nivel, ordenadas.length)
  };
}
function siguientePaso(nivel, total = 0) {
  const ids = RECOMENDADOS[nivel.nivel] ?? RECOMENDADOS.nuevo;
  const nombres = ids.map((id) => CRITERIOS.find((c) => c.id === id)?.nombre).filter(Boolean);
  return {
    criterios: ids,
    titulo: total ? "Qu\xE9 buscar despu\xE9s" : nivel.nivel === "fuerte" ? "Tu web ya sale bien: defiende y sube de nivel" : nivel.nivel === "nuevo" ? "Empieza por lo que s\xED puedes ganar" : "Empuja lo que casi tienes",
    texto: nivel.frase + " Te propongo buscar con: " + nombres.map((n) => "\xAB" + n + "\xBB").join(", ") + ".",
    corto: "Para c\xF3mo est\xE1 tu web ahora, te propongo buscar: " + nombres.map((n) => "\xAB" + n + "\xBB").join(", ") + "."
  };
}
async function discardCandidate(db, { fuente, clave: clave2 }) {
  if (!["plan", "ia", "defender", "empezar"].includes(fuente) || !String(clave2 || "").trim()) throw new Refused("Descarta as\xED una p\xE1gina del plan, una pregunta de IA, una b\xFAsqueda que ya tienes o una para empezar: { fuente: plan | ia | defender | empezar, clave }.", 400);
  await cacheSet(db, DESCARTE(fuente, clave2), { descartado: true });
  return { fuente, clave: clave2, descartado: true };
}

// server/routes/oportunidades.mjs
var VARIAS = "One: { id }. Several in ONE call: { ids: [..] } \u2192 { hechos: [{ id, oportunidad }], fallidos: [{ id, code, error }] } (one already a goal \u2014 code ALREADY_A_GOAL, item its goal \u2014 does not stop the rest). ";
function oportunidades_default(app, db) {
  const mirarWeb = () => readSitemap(db).catch((e) => ({ leido: false, texto: e.message }));
  const heredando = (fn) => conMedida(db, fn);
  const lista5 = async () => (await candidates(db)).candidatos;
  const varias = (fn) => {
    const uno = heredando(fn);
    return async (i, ctx) => {
      const ids = typeof i.ids === "string" ? i.ids.split(/[,;\s]+/).filter(Boolean).map(Number) : i.ids;
      if (!Array.isArray(ids)) {
        if (i.id == null) throw new Refused("Say which: { id } for one, or { ids: [..] } for several in one call.", 400, { code: "MISSING_PARAM" });
        return uno({ id: Number(i.id) }, ctx);
      }
      const hechos = [], fallidos = [];
      for (const id of [...new Set(ids.map(Number).filter((n) => Number.isInteger(n) && n > 0))].slice(0, 50)) {
        try {
          const r = await uno({ id }, ctx);
          hechos.push({ id, oportunidad: r.oportunidad });
        } catch (e) {
          if (!(e instanceof Refused)) throw e;
          fallidos.push({ id, code: e.code, error: e.message, ...e.item !== void 0 ? { item: e.item } : {} });
        }
      }
      return { hechos, fallidos };
    };
  };
  command(app, "GET", "/radar", { name: "radar", brief: BREVE.radar, summary: "Lo que hay para descubrir y de d\xF3nde sale: los objetivos (con su estado guardado; su lectura al d\xEDa, en objetivos), \xABCasi lo tienes\xBB, huecos, las consultas del \xFAltimo periodo de Search Console y lo que dice Ajustes (dominio, mercado, p\xFAblico, competidores, modo)." }, async () => {
    await migrate(db);
    return radar(db);
  });
  command(app, "GET", "/oportunidades/:id/detalle", { name: "oportunidad_detalle", brief: BREVE.oportunidad_detalle, of: "oportunidad", input: { brief: "boolean" }, summary: "Un objetivo entero. Su marcha: fase (por_decidir, en_marcha, subiendo, ganada, estancada, descartada: le\xEDda de los datos), posici\xF3n hoy y al aprobarlo (base: posici\xF3n, impresiones, clics y el top 10 de ese d\xEDa), sus acciones (tipo, estado, lo que produjeron), evolucion (un punto por semana y fuente), historia (la l\xEDnea de tiempo), siguiente_paso y tipos_accion (qu\xE9 acciones se pueden a\xF1adir y cu\xE1l pide instalar otro m\xF3dulo). Su investigaci\xF3n: keywords, top 10 con la fuerza de cada resultado, por qu\xE9 se puede ganar, las preguntas de Google, huecos, fuentes, lo que el sitio ya tiene, el brief y brief_completo: el brief con el material del esquema, que es lo que se pasa a Art\xEDculos." }, async (i) => {
    await migrate(db);
    const d = await detail(db, i);
    return { ...d, ...await goalExtras(db, d, await settings(db)) };
  });
  command(app, "POST", "/oportunidades/:id/puntuar", { name: "puntuar", label: "Recalcular puntuaci\xF3n", on: "oportunidad", summary: "Calcula puntuaci\xF3n y prioridad: volumen \xD7 dificultad \xD7 intenci\xF3n. La dificultad sale del top 10 real si ya se midi\xF3 (cu\xE1ntos resultados son flojos); si no, del KD de DataForSEO; sin dato, un 0,5 neutro. Instant\xE1neo, sin coste." }, (i) => rescore(db, i));
  command(app, "POST", "/oportunidades/:id/ahrefs", { name: "datos_ahrefs", on: "oportunidad", summary: "Opcional: cifras y top 10 de Ahrefs con el c\xF3digo de pa\xEDs de Ajustes (necesita la key AHREFS_API_KEY compartida con el m\xF3dulo)." }, (i) => fromAhrefs(db, i));
  command(app, "POST", "/oportunidades/:id/ejemplo", { name: "datos_ejemplo", on: "oportunidad", summary: "Solo para ense\xF1ar c\xF3mo se ver\xE1 una oportunidad que a\xFAn no tiene nada real: rellena el top 10 y los huecos con los competidores de Ajustes, SIN ninguna cifra, y la marca como ejemplo. Se niega si la oportunidad ya tiene datos reales. Instant\xE1neo, sin coste." }, (i) => fillSample(db, i));
  command(app, "POST", "/oportunidades/:id/investigacion", { name: "guardar_investigacion", on: "oportunidad", input: ["serp", "huecos"], summary: "Guarda lo le\xEDdo en el top 10: serp [{pos,url,dominio,titulo,cubre:[subtemas]}] y huecos [{tema,cubren:[dominios],competidores:[dominios],propio:bool}] (propio: el dominio de Ajustes ya lo cubre)." }, (i) => saveResearch(db, i));
  command(app, "POST", "/oportunidades/:id/brief", { name: "guardar_brief", on: "oportunidad", input: ["brief"], summary: "Guarda el brief del art\xEDculo." }, (i) => saveBrief(db, i));
  command(app, "POST", "/oportunidades/:id/aprobar", { name: "aprobar", label: "Aprobar", on: "oportunidad", when: { estado: "propuesta" }, by: "person", primary: true, input: ["motivo"], summary: "La persona lo aprueba: pasa a \xABEn marcha\xBB y se guarda su punto de partida (posici\xF3n, impresiones y clics del \xFAltimo periodo de Search Console y el top 10 de hoy). Desde aqu\xED su estado se lee de los datos. Tambi\xE9n recupera uno descartado." }, (i) => approve(db, i));
  command(app, "POST", "/oportunidades/:id/descartar", { name: "descartar", label: "Descartar", on: "oportunidad", when: { estado: ["propuesta", "en_marcha"] }, by: "person", input: ["motivo"], summary: "La persona lo descarta, con el motivo. Sus acciones y su historia se quedan; se puede recuperar." }, (i) => discard(db, i));
  command(app, "POST", "/oportunidades/:id/acciones", { name: "anadir_accion", label: "A\xF1adir acci\xF3n", on: "oportunidad", when: { estado: "en_marcha" }, by: "person", input: { tipo: "text", titulo: "text", nota: "text" }, summary: "La persona a\xF1ade una acci\xF3n a un objetivo aprobado: tipo articulo_blog, pagina_servicio, caso_real, refrescar o enlaces_internos. Queda \xABPor hacer\xBB para el agente del equipo. articulo_blog, caso_real y refrescar los hace el agente en Art\xEDculos: si Art\xEDculos no est\xE1 instalado se niega diciendo qu\xE9 instalar (modulos lo dice antes). Una sola acci\xF3n viva de cada tipo por objetivo." }, (i) => addAction(db, i));
  command(app, "POST", "/acciones/:id/vincular", { name: "vincular_accion", on: "accion", input: { modulo: "text", ref: "text", ref_estado: "text", url: "text", estado: "text", titulo: "text", nota: "text" }, summary: 'Quien hace una acci\xF3n dice lo que produjo y c\xF3mo va: modulo y ref (el registro creado en otro m\xF3dulo: modulo "articles", ref el id del art\xEDculo), ref_estado (su estado all\xED: idea, draft, review, ready, published), url (la direcci\xF3n cuando est\xE1 en la web), estado (pendiente, en_curso, hecha, cancelada) y nota. Con ref pasa a \xABEn curso\xBB; publicada o con estado hecha, a \xABHecha\xBB con su fecha. Para una p\xE1gina de servicio o unos enlaces internos: url y estado hecha.' }, (i) => linkAction(db, i));
  command(app, "POST", "/acciones/:id/cancelar", { name: "cancelar_accion", label: "Cancelar la acci\xF3n", on: "accion", when: { estado: ["pendiente", "en_curso"] }, by: "person", input: { nota: "text" }, summary: "La persona cancela una acci\xF3n que no est\xE1 hecha. Lo creado en otro m\xF3dulo no se toca." }, (i) => cancelAction(db, i));
  command(app, "POST", "/oportunidades/:id/articulo", { name: "vincular_articulo", on: "oportunidad", input: { articulo: "number", estado_articulo: "text", url: "text" }, summary: 'El art\xEDculo creado en Art\xEDculos para un objetivo (su id): queda como la acci\xF3n \xABArt\xEDculo del blog\xBB de ese objetivo, vinculada (la que esperaba su borrador, o una nueva). Igual que vincular_accion con modulo "articles".' }, (i) => linkArticle(db, i));
  command(app, "POST", "/oportunidades/:id/siguiente", { name: "proponer_siguiente", on: "oportunidad", input: { siguiente: "text", tipo: "text" }, summary: "El agente propone el siguiente paso de un objetivo (sobre todo de uno estancado): siguiente, una frase con qu\xE9 har\xEDa y por qu\xE9, mirando su top 10 y lo ya hecho; tipo, si es una acci\xF3n (articulo_blog, pagina_servicio, caso_real, refrescar, enlaces_internos). La persona lo ve en el objetivo y lo a\xF1ade con un bot\xF3n. No crea la acci\xF3n." }, (i) => proposeNext(db, i));
  command(app, "GET", "/acciones/por-hacer", { name: "acciones_por_hacer", summary: `What the trigger accion_en_articulos answers: every action of an approved goal still to do in Art\xEDculos (articulo_blog, caso_real, refrescar) and not linked yet \u2014 items [{ key: "accion:<id>", text, accion, objetivo, tipo, titulo, keyword }]. A read: it changes nothing. Do each in Art\xEDculos from the goal's brief (oportunidad_detalle), then link it with vincular_accion {id: accion}.` }, () => pendingInArticles(db));
  command(app, "GET", "/objetivos", { name: "objetivos", brief: BREVE.objetivos, summary: "Todos los objetivos con su lectura al d\xEDa: fase, posici\xF3n hoy y al aprobarlo, puestos ganados, semanas sin mejorar, acciones (cu\xE1ntas, hechas, vivas), impresiones y clics del \xFAltimo periodo y su siguiente paso (y de qui\xE9n es); y cu\xE1ntos hay en cada fase. Sin coste." }, () => goalsView(db));
  command(app, "GET", "/resumen", { name: "resumen", brief: BREVE.resumen, summary: "\xABResumen\xBB, el inicio del m\xF3dulo y la versi\xF3n en pantalla del resumen del lunes: la conclusi\xF3n del \xFAltimo diagn\xF3stico, cu\xE1ntos objetivos hay en cada fase, Search Console del \xFAltimo periodo y \xABEsta semana\xBB: qu\xE9 objetivos se movieron (de qu\xE9 posici\xF3n a cu\xE1l), qu\xE9 se hizo, cu\xE1les se ganaron, qu\xE9 est\xE1 en curso y qu\xE9 espera a la persona. Sin coste." }, () => summary(db));
  command(app, "GET", "/modulos", { name: "modulos", summary: "Qu\xE9 acciones se pueden a\xF1adir a un objetivo y cu\xE1l la desbloquea otro m\xF3dulo: \xABArt\xEDculo del blog\xBB, \xABRefrescar un contenido\xBB y \xABCaso real\xBB las hace el agente en Art\xEDculos (instalado: disponible; no instalado: instalar dice cu\xE1l y d\xF3nde). sabe: false si la plataforma no pudo decirlo (entonces nada se bloquea). Sin coste." }, () => modulesView(db));
  command(app, "POST", "/objetivos/revisar", { name: "revisar_objetivos", label: "Revisar posiciones", slow: true, input: { forzar: "boolean" }, confirm: { title: "Revisar la posici\xF3n de tus objetivos", text: "Mira qui\xE9n sale hoy en Google para cada objetivo aprobado (hasta 25). Cuesta unos 0,002 $ por objetivo (nada para los que se miraron en los \xFAltimos 3 d\xEDas) y tarda de unos segundos a un minuto. Se hace sola cada lunes.", yes: "Revisar" }, summary: "La revisi\xF3n semanal de los objetivos aprobados (hasta 25): antes, pone al d\xEDa sus art\xEDculos leyendo Art\xEDculos (gratis); luego, para la keyword de cada uno, el top 10 de Google de hoy (DataForSEO Live en el modo de Ajustes, depth 10, 4 a la vez, cach\xE9 de 3 d\xEDas; forzar: true la salta) y si el dominio de Ajustes est\xE1: guarda un punto por objetivo (su posici\xF3n, o fuera del top 10) y vuelve a leer su fase. Devuelve los que cambian de fase y los estancados (con si ya tienen propuesta: a los que no, proponer_siguiente). Corre sola cada lunes (programada), y antes lee el sitemap de la web (gratis) para que \xABTu web\xBB tenga lo publicado esa semana. Unos 0,002 $ por objetivo y de 5 s a 1 min. Guarda el coste." }, async (i) => {
    const articulos = await refreshArticles(db).catch((e) => ({ leido: false, texto: e.message }));
    const web = await mirarWeb();
    return { ...await recheckGoals(db, i), articulos, web };
  });
  command(app, "POST", "/articulos/actualizar", { name: "actualizar_articulos", label: "Poner al d\xEDa los art\xEDculos", summary: "Lee de Art\xEDculos, por su comando exportado published_articles (nunca sus tablas), los art\xEDculos que vienen de un objetivo (origin \xABOportunidades SEO #<id>\xBB) y pone al d\xEDa la acci\xF3n de cada uno: su estado all\xED, su direcci\xF3n y el d\xEDa en que se public\xF3 (publicado: la acci\xF3n queda hecha). Con eso \xABTu web\xBB sabe qu\xE9 objetivo cubre cada p\xE1gina. Sin agente y sin coste; si Art\xEDculos no est\xE1 instalado lo dice y no hace nada." }, async () => {
    const r = await refreshArticles(db);
    return r.recien_publicados ? { ...r, web: await mirarWeb() } : r;
  });
  command(app, "POST", "/oportunidades/:id/dataforseo", { name: "datos_dataforseo", label: "Traer datos de DataForSEO", on: "oportunidad", input: { forzar: "boolean" }, confirm: { title: "Traer los datos de DataForSEO", text: "Cuesta unos 0,03 $ (menos si el top 10 se pidi\xF3 en los \xFAltimos 3 d\xEDas) y tarda unos 5\u201315 segundos.", yes: "Traer datos" }, summary: "Lo real de una oportunidad en el mercado de Ajustes (ubicaci\xF3n e idioma): volumen, dificultad (o \xABsin dato\xBB si DataForSEO no la tiene: 0 no es \xABf\xE1cil\xBB) e intenci\xF3n de sus keywords (Labs keyword_overview, una llamada), el top 10 de Google (una b\xFAsqueda Live advanced, o la cach\xE9 de 3 d\xEDas: gratis; forzar: true la pide de nuevo), POR QU\xC9 se puede ganar (de esos resultados, cu\xE1ntos son webs peque\xF1as \u2014menos de 1.000 visitas/mes estimadas, Labs bulk_traffic_estimation, cach\xE9 de una semana\u2014, foros, directorios o medios, y si tu web ya sale) y el material del esquema: las preguntas que ense\xF1a Google (\xABPeople also ask\xBB), sus b\xFAsquedas relacionadas y los t\xEDtulos del top 10. Unos 0,03 $ y 5\u201315 s. Guarda el coste." }, (i) => fromDataForSEO(db, i));
  command(app, "GET", "/casi", { name: "casi_lista", brief: BREVE.casi_lista, summary: "\xABCasi lo tienes\xBB: keywords entre la posici\xF3n 8 y la 20 con la p\xE1gina que posiciona y la propuesta (actualizar ese art\xEDculo o escribir uno nuevo), de DataForSEO." }, () => almostList(db));
  command(app, "POST", "/casi/buscar", { name: "buscar_casi", label: "Buscar casi lo tienes", confirm: { title: "Buscar \xABCasi lo tienes\xBB", text: "Cuesta unos 0,01\u20130,07 $ (una consulta de DataForSEO Labs) y tarda unos segundos.", yes: "Buscar" }, summary: "Keywords por las que el dominio de Ajustes ya est\xE1 entre la posici\xF3n 8 y la 20 en Google (DataForSEO Labs ranked_keywords, ubicaci\xF3n e idioma de Ajustes). Guarda keyword, posici\xF3n, volumen y la URL que posiciona, con la propuesta: actualizar ese art\xEDculo o escribir uno nuevo. Una llamada: unos 0,01\u20130,07 $ y pocos segundos." }, (i) => findAlmost(db, i));
  command(app, "POST", "/casi/oportunidad", { name: "casi_a_oportunidad", label: "Pasar a \xABPor decidir\xBB", on: "casi", when: { estado: "nueva" }, primary: true, input: { id: "number", ids: "json" }, summary: VARIAS + "Convierte la keyword en una oportunidad propuesta: actualizar la p\xE1gina que posiciona o escribir un art\xEDculo nuevo." }, varias((i) => almostToOpportunity(db, i)));
  command(app, "POST", "/huecos/buscar", { name: "buscar_huecos", label: "Buscar huecos", slow: true, confirm: { title: "Buscar huecos en DataForSEO", text: "Cuesta unos 0,10\u20130,30 $ (una consulta por competidor de Ajustes, hasta 6, y, si a\xFAn no est\xE1n guardadas, las b\xFAsquedas de tus semillas cortas) y tarda unos 10\u201330 segundos.", yes: "Buscar" }, summary: "Keywords en las que posicionan los competidores de Ajustes y el dominio no (DataForSEO Labs domain_intersection, ubicaci\xF3n e idioma de Ajustes), FILTRADAS antes de guardar: fuera las de volumen bajo el m\xEDnimo o dificultad sobre el m\xE1ximo de Ajustes, erratas, marcas (propia, de competidores o de otras empresas), otras ciudades (Ajustes \u2192 Zonas), ajenas al negocio (relevancia bajo el m\xEDnimo: se mide con tus semillas, tu p\xFAblico y las b\xFAsquedas que contienen tus semillas cortas, Labs keyword_suggestions; nunca keyword_ideas) y variantes repetidas. Las que pasan se guardan con su puntuaci\xF3n \xABqu\xE9 se puede ganar\xBB (una dificultad 0 o vac\xEDa de DataForSEO es \xABsin dato\xBB, no \xABf\xE1cil\xBB); las descartadas, con su motivo, en \xABDescartadas y por qu\xE9\xBB. Unos 0,10\u20130,30 $ (0,024 $ por competidor, hasta 6, m\xE1s las b\xFAsquedas de las semillas cortas si no est\xE1n guardadas) y 10\u201330 segundos. Guarda el coste." }, (i) => findGaps(db, i));
  command(app, "POST", "/huecos/refiltrar", { name: "refiltrar_huecos", label: "Volver a filtrar", slow: true, summary: "Pasa otra vez el filtro a los huecos ya guardados (y a los descartados), sin volver a pedirlos a DataForSEO: tras cambiar Ajustes (zonas, semillas, m\xEDnimos). Solo paga (Labs keyword_suggestions de tus semillas cortas) si cambiaron las semillas. Unos segundos." }, (i) => refilterGaps(db, i));
  command(app, "GET", "/huecos/descartes", { name: "descartes_lista", brief: BREVE.descartes_lista, summary: "\xABDescartadas y por qu\xE9\xBB: las keywords que quit\xF3 el \xFAltimo filtro de huecos, con el filtro y el motivo, cu\xE1ntas quit\xF3 cada filtro y el coste de la \xFAltima b\xFAsqueda." }, () => discardedList(db));
  command(app, "POST", "/competidores/buscar", { name: "buscar_competidores", label: "Buscar competidores", slow: true, input: { forzar: "boolean" }, confirm: { title: "Buscar competidores en DataForSEO", text: "Cuesta unos 0,10\u20130,20 $ (lo exacto, en la pesta\xF1a Competidores): Labs keyword_suggestions con las semillas cortas (gratis si est\xE1 en cach\xE9), Labs serp_competitors con las keywords relevantes y el tr\xE1fico de los candidatos; si Labs deja menos de 3 propuestos, b\xFAsquedas en Google (DataForSEO Live en el modo de Ajustes, unos 0,002 $ cada una, 4 a la vez, cach\xE9 de 3 d\xEDas). Tarda unos 15\u201340 segundos. No cambia Ajustes.", yes: "Buscar" }, summary: "Dominios que compiten con el negocio de Ajustes en Google (ubicaci\xF3n e idioma de Ajustes). Keywords RELEVANTES: los huecos que pasan el filtro, las semillas cortas y las sugerencias de esas semillas (Labs keyword_suggestions: b\xFAsquedas que contienen la semilla, 30 por semilla, volumen m\xEDnimo de Ajustes) que pasan el MISMO filtro que los huecos (relevancia_min con semillas y p\xFAblico, marcas, erratas, otras ciudades, variantes; sin KD m\xE1ximo); lo que no pasa queda con su motivo en \xABKeywords que no se usaron\xBB. Labs serp_competitors con ellas: por dominio cuentan solo las keywords relevantes que comparte (no su total), con m\xEDnimo de 3 o el 10 % de las buscadas (lo mayor). Descarta por tipo (Ajustes \u2192 Directorios m\xE1s una lista base de redes sociales, foros, hosting y creadores de webs, directorios y grandes medios; \xAB-dominio\xBB en Directorios quita uno), por nombre, instituciones, listas de empresas, portales por tr\xE1fico (Labs bulk_traffic_estimation: 500.000 visitas/mes o 100.000 y 30 veces el mediano) y los que no llegan al m\xEDnimo; como mucho 20 propuestos, el resto en \xABDescartados\xBB con motivo. Si Labs deja menos de 3 propuestos: b\xFAsqueda Live en Google por semilla corta y hueco filtrado (hasta 16; serp/google/organic/live/regular o /advanced seg\xFAn Ajustes \u2192 serp_modo, depth 10, 4 a la vez, cach\xE9 de 3 d\xEDas por modo; forzar: true la salta), agregadas por dominio con los mismos criterios. Marca \xABYa en Ajustes\xBB los que ya est\xE1n. Unos 0,10\u20130,20 $ y 15\u201340 segundos. Guarda el coste real. No toca Ajustes \u2192 Competidores." }, (i) => findCompetitors(db, i));
  command(app, "GET", "/competidores", { name: "competidores_lista", brief: BREVE.competidores_lista, summary: "\xABCompetidores propuestos\xBB y \xABDescartados\xBB de la \xFAltima b\xFAsqueda de competidores, con su coste." }, () => competitorList(db));
  command(app, "POST", "/competidores/:id/adoptar", { name: "adoptar_competidor", label: "Adoptar como competidor", on: "competidor", when: { estado: "propuesto" }, by: "person", confirm: { title: "A\xF1adir a tus competidores", text: "Se a\xF1ade a Ajustes \u2192 Competidores y contar\xE1 en la pr\xF3xima b\xFAsqueda de huecos.", yes: "A\xF1adir" }, summary: "A\xF1ade el dominio a Ajustes \u2192 Competidores." }, (i) => adoptCompetitor(db, i));
  command(app, "POST", "/competidores/importar", { name: "importar_competidores", label: "A\xF1adir una lista", input: { lista: "text", nunca: "boolean" }, summary: "A list of competitors the PERSON gave (pasted, or the text of their CSV or Excel): lista, the domains or addresses one per line or separated by commas; nunca: false (default) adds them to Ajustes \u2192 Competidores, true adds them to \xABNunca son competidores\xBB (never proposed nor counted: freelance marketplaces, custom-software shops, whatever the person says) and takes them out of the competitors. Answers { anadidos, ya_estaban, ignorados, total, texto }. Only with a list the person gave you, never one you made up. Free." }, (i) => importCompetitors(db, i));
  command(app, "POST", "/competidores/:id/nunca", { name: "nunca_competidor", label: "Nunca es competidor", on: "competidor", when: { estado: ["propuesto", "descartado"] }, by: "person", summary: "The person says a proposed domain is never a competitor: it goes to Ajustes \u2192 \xABNunca son competidores\xBB and is not proposed again." }, (i) => neverCompetitor(db, i));
  command(app, "GET", "/top10", { name: "quien_sale", brief: BREVE.quien_sale, input: { keyword: "text" }, summary: "Who ranks today for a search BEFORE making it a goal, from what the module already has (free): { en_cache, resultados: [{ pos, dominio, titulo, url, tipo: empleo | formacion | empresa | otro }], lectura: { lectura: trabajo | compra | mixta, frase, encaja }, tu_posicion }. en_cache: false \u2192 nothing kept: ver_quien_sale asks Google (coste says how much). Use it before proposing a search as a goal: a top 10 of job boards and career guides is not for a company that sells to those who hire." }, (i) => top10View(db, i));
  command(app, "POST", "/top10", { name: "ver_quien_sale", label: "Ver qui\xE9n sale hoy", input: { keyword: "text", forzar: "boolean" }, summary: "Asks Google (DataForSEO Live, one search: about 0,002 $, 5\u201315 s; free if the module has it from the last 3 days) for today's top 10 of ONE search and answers like quien_sale. Kept, so a goal made from it does not pay again. Records the cost." }, (i) => top10Fetch(db, i));
  command(app, "POST", "/diagnostico", { name: "diagnosticar", label: "Hacer diagn\xF3stico", slow: true, input: { forzar: "boolean" }, confirm: { title: "Hacer el diagn\xF3stico", text: "Cuesta unos 0,05\u20130,08 $ de DataForSEO (qu\xE9 posiciona hoy, el top 10 de 8 huecos \u2014hasta 16 si alguno no tiene un top 10 fiable\u2014 y la fuerza de esos dominios; los top 10 de los \xFAltimos 3 d\xEDas salen de la cach\xE9 y no se pagan) y tarda unos 15\u201330 segundos. Search Console no cuesta nada.", yes: "Hacer diagn\xF3stico" }, summary: "\xBFPor qu\xE9 no aparezco y qu\xE9 hago? Keywords del dominio en el top 100 (Labs ranked_keywords) y, por separado, lo que dice Search Console (consultas guardadas: impresiones, clics, de marca y sin marca), p\xE1ginas que ya salen y URLs del sitemap, revisi\xF3n t\xE9cnica (robots.txt, noindex y canonical de la home, sitemap.xml), conclusi\xF3n por reglas con ambos datos y plan de las 5 p\xE1ginas m\xE1s ganables de los huecos filtrados con su top 10 real (DataForSEO Live en el modo de Ajustes, depth 10, 4 a la vez, cach\xE9 de 3 d\xEDas; forzar: true lo pide de nuevo; solo resultados org\xE1nicos que son webs: sin Google, sus fichas ni sus redirecciones; con menos de 5 v\xE1lidos la keyword queda \xABtop 10 no fiable\xBB y se sustituye por la siguiente, hasta 16 b\xFAsquedas) y POR QU\xC9 se puede ganar cada una: cu\xE1ntos de esos resultados son flojos (webs peque\xF1as por su tr\xE1fico estimado, Labs bulk_traffic_estimation con cach\xE9 de una semana; foros, directorios o medios) y si tu web ya sale. Si el top 10 se ley\xF3 en modo avanzado, guarda tambi\xE9n las preguntas que ense\xF1a Google. Unos 0,05\u20130,10 $ y 15\u201330 s; repetirlo en 3 d\xEDas es casi gratis. Guarda el coste." }, (i) => diagnose(db, i));
  command(app, "GET", "/diagnostico", { name: "diagnostico_ver", brief: BREVE.diagnostico_ver, summary: "El \xFAltimo diagn\xF3stico: conclusi\xF3n, cifras, revisi\xF3n t\xE9cnica, plan, costes y lo que costar\xEDa repetirlo." }, () => diagnosisView(db));
  command(app, "POST", "/diagnostico/oportunidades", { name: "diagnostico_a_oportunidades", label: "Crear las oportunidades del plan", summary: "Crea las p\xE1ginas del plan del \xFAltimo diagn\xF3stico como oportunidades \xABPor decidir\xBB (origen diagn\xF3stico), con cifras, top 10, por qu\xE9 se puede ganar, las preguntas de Google (si se leyeron), tipo, formato (p\xE1gina de servicio o art\xEDculo), \xE1ngulo, competencia y brief. Instant\xE1neo, sin coste. No duplica las que ya existen. Con keyword, solo esa p\xE1gina del plan (Descubrir).", input: { keyword: "text" } }, (i) => planToOpportunities(db, i));
  command(app, "POST", "/serp/probar", { name: "probar_serp", slow: true, input: { keyword: "text" }, summary: "Prueba (unos 0,004 $) de c\xF3mo llega de DataForSEO el top 10 de una keyword en la ubicaci\xF3n e idioma de Ajustes: DOS peticiones Live, una tras otra (depth 10, desktop, sin resolve_goto_urls, 60 s cada una): primero /regular y despu\xE9s /advanced. De cada una (regular, advanced): los 3 primeros org\xE1nicos (type, rank_group, domain, url recortada, es_goto, breadcrumb, title y en advanced website_name, con el dominio v\xE1lido que sale y de qu\xE9 campo), segundos, items, org\xE1nicos, con goto, coste real, cu\xE1ntos dan un dominio v\xE1lido y de d\xF3nde (domain, url, breadcrumb, website_name) y un item org\xE1nico crudo (item_crudo, solo con las cadenas largas recortadas). Si una falla, devuelve la otra y el error de la que fall\xF3. No usa la cach\xE9; solo guarda el coste." }, (i) => probeSerp(db, i));
  command(app, "POST", "/ia/revisar", { name: "revisar_ia", label: "Revisar las respuestas de IA", slow: true, input: { forzar: "boolean", completo: "boolean", chatgpt: "boolean" }, confirm: { title: "Revisar qu\xE9 responde la IA", text: "Pregunta a ChatGPT y mira la respuesta de IA de Google para tus temas (hasta 8). Cuesta unos 0,03\u20130,05 $ de DataForSEO y puede tardar unos minutos: va en segundo plano.", yes: "Revisar" }, summary: "\xABEn las respuestas de IA\xBB: cuando alguien pregunta a una IA por lo que hace la empresa, \xBFsale la empresa, y qui\xE9n sale? Temas (hasta 8, en este orden): las preguntas de Ajustes \u2192 \xABPreguntas que tu cliente har\xEDa a una IA\xBB, las keywords del plan del \xFAltimo diagn\xF3stico y los temas semilla cortos. Dos motores: Google (su AI Overview, le\xEDdo del top 10 advanced que ya se pide: item ai_overview, sus references; sin coste si el top 10 est\xE1 guardado; completo: true pide tambi\xE9n las que Google carga aparte, load_async_ai_overview, 0,002 $ m\xE1s por b\xFAsqueda) y ChatGPT (DataForSEO ai_optimization/chat_gpt/llm_scraper/live/advanced: su respuesta, sources y brand_entities; 0,004 $ por pregunta, hasta 2 minutos cada una, 4 a la vez, guardadas una semana; chatgpt: false lo salta). Guarda por tema y motor si te nombra, si cita tu web, qu\xE9 webs cita, qu\xE9 empresas nombra y las primeras l\xEDneas. forzar: true pregunta todo de nuevo. Unos 0,03\u20130,05 $ y de 30 s a unos minutos. Guarda el coste." }, (i) => reviewAI(db, i));
  command(app, "GET", "/ia", { name: "ia_ver", brief: BREVE.ia_ver, summary: "\xABEn las respuestas de IA\xBB: la conclusi\xF3n en una l\xEDnea (\xABEn 3 de 5 temas la IA cita a X; a ti en ninguno\xBB) y, por tema, qu\xE9 respondi\xF3 cada motor, a qui\xE9n nombra o cita y si sales t\xFA; con el coste de la \xFAltima revisi\xF3n y lo que costar\xEDa repetirla." }, () => aiView(db));
  command(app, "POST", "/novedades/vigilar", { name: "vigilar_competidores", label: "Mirar novedades de la competencia", slow: true, summary: "\xABNovedades de la competencia\xBB: lee el sitemap y el feed p\xFAblicos de cada competidor de Ajustes (hasta 10) y guarda las p\xE1ginas que no estaban la \xFAltima vez, con su t\xEDtulo (del feed o de la propia p\xE1gina; si no hay, la direcci\xF3n) y si tu web ya tiene algo sobre eso. La primera lectura de un competidor solo guarda lo que hay (no anuncia su pasado). Corre sola cada lunes (programada), y antes lee el sitemap de la web (gratis) para que \xABTu web\xBB tenga lo publicado esa semana. Sin coste (no usa DataForSEO); de 20 s a un par de minutos." }, (i) => watchCompetitors(db, i));
  command(app, "POST", "/novedades/:id/objetivo", { name: "novedad_a_objetivo", label: "Convertir en objetivo", on: "novedad", when: { estado: "nueva" }, by: "person", summary: "La persona convierte en objetivo \xABPor decidir\xBB algo que ha publicado un competidor y sobre lo que la empresa no tiene nada: su t\xEDtulo como b\xFAsqueda a mirar (af\xEDnala con datos_dataforseo antes de escribir) y su p\xE1gina como fuente. Si esa b\xFAsqueda ya es un objetivo, responde ese. La novedad pasa a \xABEs un objetivo\xBB." }, heredando((i) => newsToGoal(db, i)));
  command(app, "POST", "/ia/objetivo", { name: "ia_a_objetivo", label: "Quiero aparecer aqu\xED", input: { tema: "text" }, by: "person", summary: "La persona convierte en objetivo \xABPor decidir\xBB una pregunta de \xABEn las respuestas de IA\xBB en la que no sale: su brief dice qu\xE9 responde hoy la IA, a qui\xE9n cita y qu\xE9 suele hacer que una IA cite una p\xE1gina (la respuesta clara al principio, datos concretos, un caso real, estar en las fuentes que ya usa). Si ya es un objetivo, responde ese." }, heredando((i) => aiToGoal(db, i)));
  command(app, "GET", "/buscar", { name: "preparar_busqueda", brief: BREVE.preparar_busqueda, summary: "\xABBuscar nuevas oportunidades\xBB, before it runs (free): criterios [{ id: casi | competencia | publico | ia | defender | empezar, nombre, encuentra, coste, tarda, recomendado, falta }] \u2014 the ways to look, each with what it finds, what it costs and what it still lacks; nivel { nivel: fuerte | medio | nuevo, frase } \u2014 how the site is doing, from Search Console and the last diagnosis, and recomendados, the criteria that suit it (a site that already ranks: defender, casi, competencia, ia; a site with almost nothing: empezar, publico, competencia); propuesta \u2014 what the module proposes for each thing a criterion needs (dominio, mercado, competidores, publico, quien, temas), each with where it came from (de: ajustes | propuestos | web | dominio) or what is missing (falta), for the person to confirm or correct. Read it, tell the person what you propose and why, then buscar_nuevas with their yes." }, () => preparar(db));
  command(app, "POST", "/buscar/plan", { name: "planear_busqueda", input: { criterios: "json", ajustes: "json", medir: "boolean" }, summary: "What the screen calls between step 2 and step 3 of \xABBuscar nuevas oportunidades\xBB: saves what the person confirmed (ajustes: { dominio, mercado: an id of preparar_busqueda.mercados, competidores: [domains], publico, quien: compra | trabajo | ambas, temas: [short topics] } \u2014 only what changed is written to Ajustes) and answers the requests to run for those criterios, in order: pasos [{ id, comando, params, texto }], falta [{ criterio, que }] for a criterion that lacks something, and coste. Free; runs nothing. An agent uses buscar_nuevas instead." }, (i) => confirmarYPlanear(db, i));
  command(app, "POST", "/buscar/nuevas", { name: "buscar_nuevas", label: "Buscar nuevas oportunidades", slow: true, input: { criterios: "json", ajustes: "json", medir: "boolean" }, summary: "The whole guided search in ONE command \u2014 what \xABBuscar nuevas oportunidades\xBB does on screen. criterios: one or more of casi (positions 8\u201320: 0,01\u20130,07 $), competencia (what competitors rank for and the site does not: 0,10\u20130,30 $; needs competitors), publico (what the audience searches: 0,05\u20130,25 $; its ideas wait for your bridges, guardar_puentes), ia (questions the AI answers without naming the company: 0,03\u20130,05 $), defender (what the site already has on the first page: free with Search Console, else about 0,02 $), empezar (long, specific searches a new site can win: free). ajustes (optional): what the PERSON confirmed or corrected, as in planear_busqueda \u2014 never values you made up; propose them first (preparar_busqueda \u2192 propuesta) and save them only on their yes. It runs each criterion in turn (one that lacks something or fails says so in falta / pasos and the rest go on) and then measures the 10 best candidates (medir: false skips it; up to 0,05 $): how much each is searched, who ranks today and whether it can be won. Answers pasos [{ paso, hecho, resultado | error }], falta, coste. From 30 s to a few minutes; tell the person the cost first. Then read descubrir." }, async (i) => searchNew(db, i, void 0, void 0, { candidatos: lista5 }));
  command(app, "POST", "/descubrir/medir", { name: "medir_candidatos", label: "Medir las mejores", slow: true, input: { keywords: "json", max: "number", forzar: "boolean" }, summary: "Measures candidates BEFORE they are goals, so the person decides with the data: for each search, how much it is searched and its difficulty (Labs keyword_overview, one call for all), today's top 10 (one Live search each, about 0,002 $; free if kept from the last 3 days) and how strong that top 10 is (traffic of its domains, one call, kept a week) \u2192 \xAB\xBFSe puede ganar?\xBB. keywords: the searches to measure (up to 10); with none, the first unmeasured candidates of descubrir that fit the audience (max, default 10). About 0,03 $ plus 0,002 $ a search (10: up to 0,05 $), 10\u201340 s. What is measured is kept 30 days and the goal made from that search inherits it: its page opens with its figures, its top 10 and why it can be won, and datos_dataforseo is only a refresh. Records the cost." }, async (i) => medirCandidatos(db, i, void 0, { candidatos: i?.keywords ? [] : await lista5() }));
  command(app, "POST", "/descubrir/defender", { name: "buscar_defender", label: "Buscar lo que ya tienes", input: { forzar: "boolean" }, summary: "The criterion \xABLo que ya tengo y puedo subir\xBB: the searches (not the brand) the site already has on the first page \u2014 from Search Console, which the module reads itself (free); only if Search Console has nothing, one Labs ranked_keywords call for positions 1\u201310 (about 0,02 $). They show in descubrir as \xABYa la tienes\xBB: positions 1\u20133 to keep, 4\u201310 to push into the top three. Records the cost." }, (i) => findDefend(db, i));
  command(app, "POST", "/descubrir/empezar", { name: "buscar_empezar", label: "Buscar por d\xF3nde empezar", input: { forzar: "boolean" }, summary: "The criterion \xABPor d\xF3nde empezar con una web nueva\xBB: for each seed topic and audience word (up to 6), what Google itself suggests (its autocomplete: free, no key), keeping the long, specific searches \u2014 three words or more \u2014 which are the ones a small site can win. They show in descubrir as \xABPara empezar\xBB, with no figure until measured (medir_candidatos). Free, a few seconds." }, (i) => findStarters(db, i));
  command(app, "POST", "/descubrir/objetivo", { name: "candidato_a_objetivo", label: "Convertir en objetivo", input: { fuente: "text", clave: "text" }, by: "person", summary: "The person makes a goal \xABPor decidir\xBB of a candidate \xABYa la tienes\xBB or \xABPara empezar\xBB of descubrir: { fuente: defender | empezar, clave: the search }. It inherits what was measured for it. If that search is already a goal, answers that one." }, heredando((i) => candidateToGoal(db, i)));
  command(app, "GET", "/descubrir", { name: "descubrir", brief: BREVE.descubrir, input: { fuente: "text", ganar: "text", desde: "number", limite: "number" }, summary: "\xABDescubrir\xBB: UNA lista de lo que la empresa podr\xEDa ganar ahora, de todas las fuentes (lo que ya tiene en la primera p\xE1gina, casi, plan del diagn\xF3stico, competencia: huecos y novedades, p\xFAblico, IA, b\xFAsquedas largas para empezar), sin repetir ni lo que ya es objetivo; cada una dice de d\xF3nde sale y por qu\xE9, lo medido (volumen, dificultad, si se ley\xF3 su top 10) y se_puede_ganar (si | pelear | dificil | tuya | subir | sin_medir, con su frase: informa, nunca bloquea), y qu\xE9 comando la convierte en objetivo (convertir) o la descarta (descartar). Lo que se puede ganar va primero; lo dif\xEDcil, al final. nivel dice c\xF3mo est\xE1 la web y siguiente qu\xE9 criterios buscar despu\xE9s (buscar_nuevas). Convertir y descartar son de la persona." }, () => candidates(db));
  command(app, "POST", "/descubrir/descartar", { name: "descartar_candidato", input: { fuente: "text", clave: "text" }, by: "person", summary: "Descarta en \xABDescubrir\xBB una p\xE1gina del plan, una pregunta de IA, una b\xFAsqueda que la web ya tiene o una para empezar (no tienen estado propio): no vuelve a salir. { fuente: plan | ia | defender | empezar, clave }." }, (i) => discardCandidate(db, i));
  command(app, "GET", "/novedades", { name: "novedades_ver", brief: BREVE.novedades_ver, summary: "\xABNovedades de la competencia\xBB de los \xFAltimos 60 d\xEDas: qu\xE9 ha publicado cada competidor (\xABdeveloop.net ha publicado \xAB\u2026\xBB; t\xFA no tienes nada sobre eso\xBB), cu\xE1ndo se ley\xF3 por \xFAltima vez y qu\xE9 se pudo leer de cada uno." }, () => newsView(db));
  command(app, "GET", "/web", { name: "tu_web", brief: BREVE.tu_web, input: { desde: "number", limite: "number" }, summary: "\xABTu web\xBB: lo que ya tiene el sitio de Ajustes, una fila por direcci\xF3n: las del sitemap (le\xEDdo por el diagn\xF3stico o por leer_sitemap), las p\xE1ginas y art\xEDculos que Art\xEDculos sincroniz\xF3 y las que salen en Search Console; con qu\xE9 es (p\xE1gina o art\xEDculo del blog), las b\xFAsquedas por las que sale (impresiones, clics, posici\xF3n) y la oportunidad que la cubre, si la hay. L\xE9elo antes de proponer nada: lo que ya existe se actualiza, no se propone de nuevo. Sin coste." }, () => siteView(db));
  command(app, "POST", "/web/sitemap", { name: "leer_sitemap", label: "Leer el sitemap", summary: "Lee robots.txt y el sitemap.xml del dominio de Ajustes (lectura directa de la web, sin DataForSEO: no cuesta nada, unos segundos) y guarda sus direcciones para \xABTu web\xBB. El diagn\xF3stico tambi\xE9n lo hace." }, (i) => readSitemap(db, i));
  command(app, "GET", "/ahrefs", { name: "ahrefs_estado", summary: "Whether the module may read the company's Ahrefs (its own connection, through the platform: an owner or admin allows it in M\xF3dulos \u203A Oportunidades SEO \u203A \xABCuentas que puede leer\xBB) and how many API units are left: { conectado, quedan, renueva, puede, texto }. One read-only action (the subscription's limits and usage); free. Ahrefs units are scarce: under 5.000 left the module uses none. Today this is all the module reads from Ahrefs; figures come from DataForSEO." }, (i) => ahrefsStatus(db, i));
  command(app, "GET", "/gasto", { name: "gasto_dataforseo", brief: BREVE.gasto_dataforseo, summary: "Lo que cost\xF3 en DataForSEO la \xFAltima ejecuci\xF3n de cada comando y el total." }, () => lastCosts(db));
  command(app, "POST", "/huecos/ejemplo", { name: "huecos_ejemplo", summary: "Solo para ense\xF1ar la pantalla mientras no hay DataForSEO: tus temas semilla como huecos de ejemplo, SIN ninguna cifra y marcados como tales. Se niega si ya hay huecos reales. Instant\xE1neo, sin coste." }, () => sampleGaps(db));
  command(app, "POST", "/huecos/oportunidad", { name: "hueco_a_oportunidad", label: "Pasar a \xABPor decidir\xBB", on: "hueco", when: { estado: "nuevo" }, primary: true, input: { id: "number", ids: "json" }, summary: VARIAS + "Convierte el hueco en una oportunidad propuesta." }, varias((i) => gapToOpportunity(db, i)));
  command(app, "POST", "/ideas/buscar", { name: "buscar_ideas_publico", label: "Buscar ideas para tu p\xFAblico", slow: true, input: { forzar: "boolean" }, confirm: { title: "Buscar lo que busca tu p\xFAblico", text: "Cuesta unos 0,05\u20130,25 $ de DataForSEO (dos consultas por cada palabra de tu p\xFAblico; nada si se buscaron esta semana) y tarda unos 10\u201325 segundos.", yes: "Buscar" }, summary: "\xABLo que buscan nuestros clientes\xBB: lo que el P\xDABLICO de Ajustes busca en su d\xEDa a d\xEDa, no el producto. Parte de las palabras cortas del p\xFAblico (Ajustes \u2192 \xABQu\xE9 busca tu p\xFAblico\xBB; si est\xE1 vac\xEDo, de las personas que nombra \xABP\xFAblico\xBB; hasta 6) y trae de DataForSEO Labs, por cada palabra, las b\xFAsquedas que la contienen (keyword_suggestions, hasta 50) y las que Google relaciona con ella (related_keywords, profundidad 2, hasta 50): 4 a la vez, guardadas una semana (forzar: true las pide de nuevo). Solo para las que llegan sin intenci\xF3n o sin dificultad, una llamada de search_intent y una de bulk_keyword_difficulty (hasta 1000 keywords cada una). Filtra: volumen m\xEDnimo de Ajustes, que quien busca quiera informarse (no ir a una web ni comprar ya), que sea de tu p\xFAblico, marcas, erratas, otras ciudades, variantes y lo que ya tienes. Guarda las 30 mejores SIN PUENTE: no se ense\xF1an hasta que cada una tenga el suyo (guardar_puentes). Unos 0,05\u20130,25 $ y 10\u201325 s. Guarda el coste." }, (i) => findAudienceIdeas(db, i));
  command(app, "GET", "/ideas", { name: "ideas_publico", brief: BREVE.ideas_publico, summary: "\xABIdeas para atraer a tu p\xFAblico\xBB: las 10 mejores con puente (top), todas las que lo tienen (listas), las que a\xFAn lo esperan (sin_puente), las convertidas y las descartadas, con las palabras del p\xFAblico de las que salen, cu\xE1ntas quit\xF3 cada filtro, el coste de la \xFAltima b\xFAsqueda y lo que costar\xEDa repetirla." }, () => audienceView(db));
  command(app, "POST", "/ideas/puentes", { name: "guardar_puentes", input: { puentes: "json" }, summary: "El puente de cada idea, que escribes t\xFA (el agente) con lo que sabes de la empresa: puentes [{ id, puente, producto }]. puente: UNA frase (30 a 400 caracteres) con el \xE1ngulo del art\xEDculo y c\xF3mo lleva a lo que la empresa vende, con su llamada a la acci\xF3n; producto: a qu\xE9 lleva (uno de los temas semilla de Ajustes o un servicio suyo). Si una idea no lleva de forma natural a nada que venda, no fuerces el puente: [{ id, sin_puente: true, motivo }] la descarta. Sin puente una idea no se ense\xF1a ni pasa a \xABPor decidir\xBB. Instant\xE1neo, sin coste." }, (i) => saveBridges(db, i));
  command(app, "POST", "/ideas/oportunidad", { name: "idea_a_oportunidad", label: "Pasar a \xABPor decidir\xBB", on: "idea", when: { estado: "nueva" }, primary: true, input: { id: "number", ids: "json" }, summary: VARIAS + "Convierte una idea CON puente en una oportunidad \xABPor decidir\xBB (art\xEDculo del blog; el puente pasa a su \xE1ngulo y a su brief). Se niega si la idea no tiene puente. Instant\xE1neo, sin coste." }, varias((i) => ideaToOpportunity(db, i)));
  command(app, "POST", "/consultas/actualizar", { name: "actualizar_search_console", label: "Actualizar Search Console", input: { desde: "date", hasta: "date" }, summary: "Trae de Search Console las b\xFAsquedas del dominio de Ajustes SIN el agente (ning\xFAn turno de modelo, sin coste): la plataforma ejecuta las dos acciones de solo lectura que este m\xF3dulo declara (la lista de propiedades, una vez, y searchanalytics.query por consulta y p\xE1gina) con la conexi\xF3n de Search Console del agente del equipo. Por defecto, los \xFAltimos 28 d\xEDas hasta hace 3 (lo que Search Console ya tiene cerrado); guarda el periodo aparte, da a cada objetivo aprobado su punto y apunta cu\xE1ndo se actualiz\xF3. Se niega, diciendo qui\xE9n lo arregla, si un propietario o administrador a\xFAn no lo ha permitido (M\xF3dulos \u203A Oportunidades SEO \u203A \xABCuentas que puede leer\xBB), si ning\xFAn agente del equipo tiene Search Console conectado o si la cuenta no tiene la propiedad del dominio. Es lo que usa la Rutina semanal." }, (i) => refreshSearchConsole(db, i));
}

// server/app.mjs
function createApp(db) {
  const app = new Hono2();
  mountErrors(app);
  oportunidades_default(app, db);
  return app;
}

// server/db.mjs
function dataClient(url = process.env.APP_DATA_URL, token = process.env.APP_DATA_TOKEN) {
  const call = async (path, body) => {
    const r = await fetch(`${url}${path}`, { method: "POST", headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` }, body: JSON.stringify(body) });
    const j = await r.json().catch(() => null);
    if (!r.ok || !j) throw new Error(j?.error ?? `Data ${r.status}`);
    return j;
  };
  return {
    all: async (sql, params = []) => (await call("/all", { sql, params })).rows,
    one: async (sql, params = []) => (await call("/all", { sql, params })).rows[0] ?? null,
    insert: async (table, data) => (await call("/batch", { ops: [{ op: "insert", table, data }] })).ids[0],
    update: async (table, id, data, where2 = {}) => (await call("/update", { table, id, data, where: where2 })).changed,
    batch: async (ops) => (await call("/batch", { ops })).ids,
    // Which of the modules app.json `suggests` are installed for the company: [{ module, installed, name, version, for, unlocks }].
    // Asked each time, never kept; nothing of the other module is reachable.
    peers: async () => (await call("/peers", {})).peers,
    // One read command another module EXPORTS and app.json `reads` declares: { installed: false } when it is not
    // installed, else { installed: true, result }. Never its tables, never a write.
    read: async (module, command2, params = {}) => call("/read", { module, command: command2, params })
  };
}

// server/main.mjs
serve({ fetch: createApp(dataClient()).fetch, hostname: "127.0.0.1", port: Number(process.env.PORT) });
