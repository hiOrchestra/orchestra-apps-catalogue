// The last 30 minutes, read straight from the visits as they arrive (the
// reports wait for the hourly run). Refreshes itself every 15 seconds while
// it is on screen.
import { T, allSites, chosenSite, remember, num } from '../data.js';

const { el, router, fmt } = Orch;
const WINDOW_MIN = 30;
const BOT = /bot|crawl|spider|headless|lighthouse|preview/i;
let timer = null;

export function render(_params, path) {
  stop();
  const host = el('div', { class: 'oc-stack oc-stack--loose an-live' });
  Orch.mount('view', host);
  const draw = () => Orch.load(host, async () => {
    const list = await allSites();
    const site = chosenSite(list, path);
    if (!site) {
      return el('div', { class: 'oc-card oc-state' }, [el('p', { class: 'oc-state__title' }, 'No website yet.'),
        el('p', { class: 'oc-help' }, 'Live shows who is on your site right now, once it sends visits here.'), router.link('/', 'Get started', { class: 'oc-btn' })]);
    }
    remember(site.key);
    const since = new Date(Date.now() - WINDOW_MIN * 60000).toISOString();
    const r = await Orch.db.list(T.events, { filter: { site: site.key, at: { gte: since } }, sort: 'at:desc', limit: 500 });
    return view(site, (r.rows || []).filter((x) => !BOT.test(x.ua || '')));
  });
  draw();
  timer = setInterval(() => { if (document.visibilityState === 'visible') draw(); }, 15000);
  window.addEventListener('hashchange', stop, { once: true });
}
function stop() { if (timer) { clearInterval(timer); timer = null; } }

function view(site, hits) {
  const now = Date.now();
  const recent = hits.filter((h) => now - Date.parse(h.at) < 5 * 60000);
  const views = hits.filter((h) => h.kind === 'pageview');
  const people = new Set(hits.map((h) => h.anon)).size;
  const perMin = Array.from({ length: WINDOW_MIN }, (_, i) => {
    const end = now - (WINDOW_MIN - 1 - i) * 60000;
    const n = views.filter((v) => { const t = Date.parse(v.at); return t <= end && t > end - 60000; }).length;
    return { x: `-${WINDOW_MIN - 1 - i}m`, views: n };
  });
  const firstOf = new Map();
  for (const v of [...views].reverse()) if (!firstOf.has(v.anon)) firstOf.set(v.anon, v);
  const count = (items, key) => {
    const m = new Map();
    for (const it of items) { const k = key(it); m.set(k, (m.get(k) || 0) + 1); }
    return [...m.entries()].sort((a, b) => b[1] - a[1]).slice(0, 8);
  };
  const source = (v) => (v.utm_source ? v.utm_source : v.ref ? String(v.ref).split('/')[0].replace(/^www\./, '') : 'Direct');
  const small = (title, rows) => el('section', { class: 'oc-card oc-card--pad0 an-panel' }, [
    el('div', { class: 'an-panel__head an-panel__head--pad' }, el('h2', { class: 'oc-h2' }, title)),
    rows.length ? el('ul', { class: 'an-list' }, rows.map(([k, n]) => el('li', { class: 'an-row', style: { gridTemplateColumns: 'minmax(0, 1fr) 56px' } }, [
      el('span', { class: 'an-row__name' }, k), el('span', { class: 'oc-value an-n' }, num(n)),
    ]))) : el('p', { class: 'oc-help an-none' }, 'Nothing yet.'),
  ]);
  const nowCount = new Set(recent.map((h) => h.anon)).size;
  return el('div', { class: 'oc-stack oc-stack--loose' }, [
    el('header', { class: 'an-head' }, [
      el('div', { class: 'an-head__title' }, [el('h1', { class: 'oc-h1 oc-h1--collection' }, 'Live'),
        el('p', { class: 'oc-eyebrow' }, `${site.name || site.key} · last 30 minutes · updates every 15 seconds`)]),
      el('div', { class: 'an-head__tools' }, nowCount ? el('span', { class: 'oc-badge oc-badge--warn' }, `● ${nowCount} on the site now`) : el('span', { class: 'oc-badge' }, 'Nobody on the site now')),
    ]),
    el('div', { class: 'oc-metrics' }, [
      metric('On the site now', num(nowCount), 'active in the last 5 minutes'),
      metric('Visitors', num(people), 'in the last 30 minutes'),
      metric('Page views', num(views.length), 'in the last 30 minutes'),
    ]),
    el('section', { class: 'oc-card an-chart' }, [el('div', { class: 'an-panel__head' }, el('h2', { class: 'oc-h2' }, 'Page views per minute')),
      Orch.chart({ rows: perMin, x: 'x', kind: 'bar', width: 1160, height: 180, series: [{ key: 'views', label: 'Page views' }] })]),
    el('div', { class: 'an-panels' }, [
      small('Pages', count(views, (v) => v.path)),
      small('Came from', count([...firstOf.values()], source)),
      small('Actions', count(hits.filter((h) => h.kind === 'event'), (h) => h.name)),
    ]),
    el('section', { class: 'oc-card oc-card--pad0' }, [el('div', { class: 'an-panel__head an-panel__head--pad' }, el('h2', { class: 'oc-h2' }, 'Latest page views')),
      views.length ? el('ul', { class: 'an-feed' }, views.slice(0, 20).map((v) => el('li', { class: 'an-feed__row' }, [
        el('span', { class: 'oc-value oc-muted' }, fmt.ago(v.at)), el('span', { class: 'oc-value an-feed__path' }, v.path),
        el('span', { class: 'oc-muted an-feed__from' }, firstOf.get(v.anon) === v ? source(v) : ''),
      ]))) : el('p', { class: 'oc-help an-none' }, 'Nobody in the last 30 minutes.')]),
  ]);
}

const metric = (label, value, note) => el('div', { class: 'oc-metric oc-metric--compact' }, [
  el('span', { class: 'oc-kpi__label' }, label), el('span', { class: 'oc-kpi__value' }, value), el('span', { class: 'oc-kpi__delta' }, note),
]);
