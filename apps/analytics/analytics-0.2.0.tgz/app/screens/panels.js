// The breakdowns of a report. `pages` is the one wide table — every number a
// page has for the period, with its own trend and its change. `panels` is the
// grid under it: sources, actions, places, devices and speed, each a panel of
// thin rows whose tabs switch between related breakdowns. A few rows show; the
// rest open in place.
import { num, pct, duration, ms, change } from '../data.js';

const { el } = Orch;

// A value's numbers, as rollup.js writes them; a dims entry is [value, numbers, visitors before].
const V = 0; const S = 1; const P = 2; const B = 3; const D = 4; const TM = 6; const TN = 7; const SC = 8; const SN = 9; const EN = 10;
const shade = (i) => `color-mix(in srgb, var(--brand-ink) ${[100, 70, 50, 34, 22, 14, 9][Math.min(i, 6)]}%, var(--brand-surface))`;
const speedOf = (r) => new Map((r.vitals || []).map(([p, lcp, inp, cls, ttfb, n]) => [p, { lcp, inp, cls, ttfb, n }]));

/** A tiny bar trend, from numbers this app computed (never text), so plain SVG is safe. */
function spark(values) {
  if (!values || values.length < 2) return el('span', { class: 'an-spark' });
  const top = Math.max(1, ...values);
  const w = 120; const h = 18; const step = w / values.length; const bw = Math.max(1.5, step - 1);
  const bars = values.map((v, i) => {
    const bh = Math.max(v ? 1.5 : 0.5, Math.round((v / top) * h * 10) / 10);
    return `<rect x="${(i * step).toFixed(1)}" y="${(h - bh).toFixed(1)}" width="${bw.toFixed(1)}" height="${bh}"/>`;
  }).join('');
  return el('span', { class: 'an-spark', 'aria-hidden': 'true', html: `<svg viewBox="0 0 ${w} ${h}" width="${w}" height="${h}">${bars}</svg>` });
}

function grade(kind, v) {
  if (v === null || v === undefined) return el('span', { class: 'oc-value an-n oc-muted' }, '—');
  const good = { lcp: 2500, inp: 200, cls: 0.1 }[kind];
  const poor = { lcp: 4000, inp: 500, cls: 0.25 }[kind];
  const tone = v <= good ? 'good' : v > poor ? 'bad' : '';
  const text = kind === 'cls' ? Number(v).toFixed(2) : ms(v);
  return el('span', { class: `oc-value an-n${tone ? ` an-${tone}` : ''}`, title: tone === 'good' ? 'Good (Google\'s threshold)' : tone === 'bad' ? 'Poor' : 'Needs work' }, text);
}

/** The first rows, and a button that adds the rest in place. */
function more(ul, rest, line, what) {
  if (!rest.length) return ul;
  const btn = el('button', { class: 'oc-btn oc-btn--sm oc-btn--ghost an-more', type: 'button' }, `Show ${rest.length} more${what ? ` ${what}` : ''}`);
  btn.addEventListener('click', () => { rest.forEach((x) => ul.appendChild(line(x))); btn.remove(); });
  return el('div', {}, [ul, btn]);
}

/** A panel with tabs over related breakdowns; `draw(dim)` fills it. */
function tabbed(title, tabs, draw, { note, extra } = {}) {
  const host = el('div');
  const buttons = tabs.map(([dim, label]) => el('button', { class: 'oc-tab', type: 'button', onclick: () => show(dim) }, label));
  const show = (dim) => {
    buttons.forEach((b, i) => b.setAttribute('aria-selected', String(tabs[i][0] === dim)));
    Orch.mount(host, draw(dim));
  };
  const section = el('section', { class: 'oc-card oc-card--pad0 an-panel' }, [
    el('div', { class: 'an-panel__head an-panel__head--pad' }, [el('h2', { class: 'oc-h2' }, title),
      tabs.length > 1 ? el('div', { class: 'oc-tabs an-tabs', role: 'tablist' }, buttons) : extra || null]),
    host,
    note ? el('p', { class: 'oc-help an-note' }, note) : null,
  ]);
  show(tabs[0][0]);
  return section;
}

// ── Pages: the wide table ─────────────────────────────────────────────────
export function pages(r) {
  const speed = speedOf(r);
  const tabs = [['page', 'Top pages'], ['entry', 'Landing pages'], ['exit', 'Exit pages']].filter(([dim], i) => i === 0 || (r.dims[dim] || []).length);
  return tabbed('Pages', tabs, (dim) => pageRows(r, dim, speed));
}

function pageRows(r, dim, speed) {
  const list = r.dims[dim] || [];
  if (!list.length) return el('p', { class: 'oc-help an-none' }, 'Nothing here in this period.');
  const t = r.totals;
  const n_ = (x) => el('span', { class: 'oc-value an-n' }, x);
  const cols = {
    page: [['Trend', 0], ['Visitors', 1], ['Change', 1], ['Views', 1], ['Time', 1], ['Entry', 1], ['Scroll', 0], ['Main content', 1]],
    entry: [['Visits', 1], ['Change', 1], ['Bounce', 1], ['Visit length', 1]],
    exit: [['Visits', 1], ['Share of exits', 1]],
  }[dim];
  const cells = ([k, n, before]) => {
    if (dim === 'entry') return [n_(num(n[S])), n_(change(n[V], before)), n_(pct(n[B], n[S])), n_(duration(n[D] / Math.max(1, n[S])))];
    if (dim === 'exit') return [n_(num(n[S])), n_(pct(n[S], t.visits))];
    const scroll = n[SN] ? Math.round(n[SC] / n[SN]) : null;
    return [
      spark((r.spark || {})[k]), n_(num(n[V])), n_(change(n[V], before)), n_(num(n[P])),
      n_(n[TN] ? duration(n[TM] / n[TN] / 1000) : '—'), n_(pct(n[EN], t.visits)),
      scroll === null ? el('span', { class: 'oc-muted' }, '—')
        : el('span', { class: 'an-scroll', title: `Scrolled ${scroll}% of the page on average` }, [
          el('span', { class: 'an-scroll__track' }, el('span', { class: 'an-scroll__fill', style: { width: `${scroll}%` } })),
          el('span', { class: 'oc-value an-scroll__n' }, `${scroll}%`)]),
      grade('lcp', (speed.get(k) || {}).lcp),
    ];
  };
  const titles = r.titles || {};
  const line = (entry) => el('li', { class: `an-pg an-pg--${dim}` }, [
    el('span', { class: 'an-pg__name', title: titles[entry[0]] || entry[0] }, [
      el('span', { class: 'oc-value an-path' }, entry[0]),
      titles[entry[0]] ? el('span', { class: 'an-pg__title' }, titles[entry[0]]) : null]),
    ...cells(entry),
  ]);
  const head = el('li', { class: `an-pg an-pg--${dim} an-pg--head`, 'aria-hidden': 'true' },
    [el('span', { class: 'oc-eyebrow' }, 'Page'), ...cols.map(([label, right]) => el('span', { class: `oc-eyebrow${right ? ' an-n' : ''}` }, label))]);
  return more(el('ul', { class: 'an-list an-list--pages' }, [head, ...list.slice(0, 12).map(line)]), list.slice(12), line, 'pages');
}

// ── The grid of panels ────────────────────────────────────────────────────
const share = (n, t) => pct(n[V], t.visitors);
const PANELS = [
  { title: 'Channels', tabs: [['channel', 'Channels']], stack: true, cols: [['Visitors', (n) => num(n[V])], ['Share', share]] },
  { title: 'Sources', tabs: [['source', 'Sources'], ['utm_campaign', 'Campaigns'], ['referrer', 'Referrers'], ['utm_medium', 'Medium']],
    cols: [['Visitors', (n) => num(n[V])], ['Change', (n, t, before) => change(n[V], before)]] },
  { title: 'What they did', tabs: [['event', 'Actions'], ['event_detail', 'Which ones']],
    cols: [['Visitors', (n) => num(n[V])], ['Of all', share]],
    note: 'Clicks to sign up, sign in, contact or pricing; links out; downloads; forms; videos; pages not found.' },
  { title: 'Where they are', tabs: [['country', 'Countries'], ['lang', 'Languages'], ['site_lang', 'Site language']],
    cols: [['Visitors', (n) => num(n[V])], ['Share', share]], note: 'From the device\'s time zone: close, not exact.' },
  { title: 'Devices', tabs: [['device', 'Devices'], ['browser', 'Browsers'], ['os', 'Systems'], ['screen', 'Screens']], stack: true,
    cols: [['Visitors', (n) => num(n[V])], ['Share', share]] },
];

export function panels(r) {
  return el('div', { class: 'an-panels' }, [
    ...PANELS.map((p) => tabbed(p.title, p.tabs.filter(([dim], i) => i === 0 || (r.dims[dim] || []).length),
      (dim) => rows(r.dims[dim] || [], p, r, p.stack && dim === p.tabs[0][0]), { note: p.note })),
    speedPanel(r),
  ]);
}

function rows(list, spec, r, stacked) {
  if (!list.length) return el('p', { class: 'oc-help an-none' }, 'Nothing here in this period.');
  const t = r.totals;
  const total = list.reduce((s, [, n]) => s + n[V], 0) || 1;
  const bar = stacked ? el('div', { class: 'an-stack', role: 'img', 'aria-label': 'Share of visitors' },
    list.slice(0, 7).map(([, n], i) => el('span', { style: { width: `${(n[V] / total) * 100}%`, background: shade(i) } }))) : null;
  const line = ([k, n, before], i) => el('li', { class: 'an-row' }, [
    el('span', { class: 'an-row__name', title: k }, [stacked && i < 7 ? el('span', { class: 'an-key', style: { background: shade(i) } }) : null,
      k === '(none)' ? el('span', { class: 'oc-muted' }, 'Not set') : k]),
    ...spec.cols.map(([, f]) => el('span', { class: 'oc-value an-n' }, f(n, t, before))),
  ]);
  const head = el('li', { class: 'an-row an-row--head', 'aria-hidden': 'true' }, [el('span'), ...spec.cols.map(([label]) => el('span', { class: 'oc-eyebrow an-n' }, label))]);
  return el('div', {}, [bar, more(el('ul', { class: 'an-list' }, [head, ...list.slice(0, 8).map(line)]), list.slice(8), (x) => line(x, 99), '')]);
}

function speedPanel(r) {
  const list = (r.vitals || []).slice(0, 10);
  return el('section', { class: 'oc-card oc-card--pad0 an-panel' }, [
    el('div', { class: 'an-panel__head an-panel__head--pad' }, [el('h2', { class: 'oc-h2' }, 'Page speed'), el('span', { class: 'oc-eyebrow' }, '75th percentile')]),
    list.length ? el('ul', { class: 'an-list' }, [
      el('li', { class: 'an-row an-row--speed an-row--head', 'aria-hidden': 'true' }, [el('span'), ...['Content', 'Clicks', 'Shift'].map((x) => el('span', { class: 'oc-eyebrow an-n' }, x))]),
      ...list.map(([p, lcp, inp, cls]) => el('li', { class: 'an-row an-row--speed' }, [
        el('span', { class: 'an-row__name oc-value', title: p }, p), grade('lcp', lcp), grade('inp', inp), grade('cls', cls)])),
    ]) : el('p', { class: 'oc-help an-none' }, 'No speed measured in this period.'),
    el('p', { class: 'oc-help an-note' }, 'Measured in visitors\' own browsers on the first page of each visit. Three in four were this fast or faster; green is Google\'s "good".'),
  ]);
}
