// The report for one site and one period, in the order a person reads it:
// what the site is and when, the six numbers against the period before, the
// visitors per day with the period before dashed under them, every page in one
// table, then the breakdowns (panels.js). One row of analytics_reports holds
// all of it; Refresh rebuilds it now instead of at the next hourly run.
// Getting started (start.js) sits on top until every site has had a visit, and
// is the whole screen while there is no site.
import { A, PERIODS, DEFAULT_PERIOD, act, allSites, settings as readSettings, chosenSite, remember, report, num, pct, duration, delta, ago, hostOf, liveNow } from '../data.js';
import { pages, panels } from './panels.js';
import { withVisits, progress, showStart, startPanel } from './start.js';

const { el, router, fmt } = Orch;
const SPAN = { today: 'Today', yesterday: 'Yesterday', '7d': 'Last 7 days', '30d': 'Last 30 days', '90d': 'Last 90 days', '12m': 'Last 12 months' };

export function render(params, path) {
  const period = PERIODS.some((p) => p[0] === params.period) ? params.period : DEFAULT_PERIOD;
  Orch.load('view', async () => {
    const [list, prefs] = await Promise.all([allSites(), readSettings()]);
    const again = () => render(params, path);
    const visits = await withVisits(list);
    const p = progress(visits, prefs);
    const start = showStart(p, prefs) ? startPanel(visits, prefs, again) : null;
    const site = chosenSite(list, path);
    if (!site) {
      return el('div', { class: 'oc-stack oc-stack--loose an-overview' }, [
        el('div', { class: 'an-head__title' }, [el('h1', { class: 'oc-h1 oc-h1--collection' }, 'Welcome to Analytics'),
          el('p', { class: 'oc-lede' }, 'Count the visits to your website without cookies. Three steps, about five minutes.')]),
        start,
      ]);
    }
    remember(site.key);
    const [r, live] = await Promise.all([report(site.key, period), liveNow(site)]);
    const arrived = !!(visits.find((x) => x.site.key === site.key) || {}).visit;
    return el('div', { class: 'oc-stack an-overview' }, [
      head(list, site, period, r, live, again),
      start,
      // While Getting started waits for this site's first visit, it is the empty state.
      r && r.totals.visits ? body(r, period) : start && !arrived ? null : empty(site, r, arrived),
    ]);
  });
}

const day = (d) => fmt.date(`${d}T12:00:00Z`, { day: 'numeric', month: 'short' });

function head(list, site, period, r, live, again) {
  const link = (p) => `/p/${p}${list.length > 1 ? `?site=${encodeURIComponent(site.key)}` : ''}`;
  const refresh = el('button', { class: 'oc-btn oc-btn--sm', type: 'button' }, 'Refresh');
  refresh.addEventListener('click', async () => {
    refresh.disabled = true;
    refresh.textContent = 'Building…';
    const ok = await act(A.refresh, {});
    if (!ok) { refresh.disabled = false; refresh.textContent = 'Refresh'; return; }
    // The build runs on the instance; draw again as soon as the report changed (or after a minute).
    const was = r ? r.built_at : null;
    for (let i = 0; i < 30; i += 1) {
      await new Promise((res) => setTimeout(res, 2000));
      if (!refresh.isConnected) return;
      const now = await report(site.key, period).catch(() => null);
      if (now && now.built_at !== was) break;
    }
    if (refresh.isConnected) again();
  });
  const meta = [SPAN[period]];
  if (r) meta.push(r.from === r.to ? day(r.from) : `${day(r.from)} – ${day(r.to)}`);
  meta.push(site.timezone || 'UTC', r ? `rebuilt ${ago(r.built_at)}` : 'not built yet');
  return el('header', { class: 'an-head' }, [
    el('div', { class: 'an-head__title' }, [
      list.length > 1
        ? el('select', { class: 'oc-select an-site', 'aria-label': 'Website', onchange: (e) => router.go(`/p/${period}?site=${encodeURIComponent(e.target.value)}`) },
          list.map((s) => el('option', { value: s.key, selected: s.key === site.key }, hostOf(s))))
        : el('h1', { class: 'oc-h1 an-host' }, hostOf(site)),
      el('p', { class: 'oc-eyebrow' }, meta.join(' · ')),
    ]),
    el('div', { class: 'an-head__tools' }, [
      live ? router.link('/live', `● ${live} on the site now`, { class: 'oc-badge oc-badge--warn an-live' }) : null,
      el('nav', { class: 'oc-segmented', 'aria-label': 'Period' }, PERIODS.map(([key, label]) =>
        router.link(link(key), label, { class: 'oc-segmented__item', 'aria-current': key === period ? 'true' : 'false' }))),
      refresh,
    ]),
  ]);
}

function empty(site, r, arrived) {
  return el('div', { class: 'oc-card oc-state' }, [
    el('p', { class: 'oc-state__title' }, r ? 'No visits in this period.' : 'The reports have not been built yet.'),
    el('p', { class: 'oc-help' }, site.last_hit_at || arrived
      ? `Visits are arriving${site.last_hit_at ? ` (the last one ${ago(site.last_hit_at)})` : ''}. Press Refresh to build the reports now, or wait for the hourly run.`
      : 'Nothing has arrived from this site yet. Check that the tracker line is inside the head of its pages.'),
    router.link('/sites', 'See the tracker line', { class: 'oc-btn' }),
  ]);
}

function body(r) {
  const t = r.totals;
  const p = r.prev || {};
  const per = (a, b) => (b ? a / b : null);
  const metric = (label, value, d, hint) => el('div', { class: 'oc-metric oc-metric--compact', title: hint || '' }, [
    el('span', { class: 'oc-kpi__label' }, label), el('span', { class: 'oc-kpi__value' }, value), d,
  ]);
  const unit = r.days === 1 ? 'hour' : r.days > 90 ? 'month' : 'day';
  return el('div', { class: 'oc-stack oc-stack--loose' }, [
    el('div', { class: 'oc-metrics an-kpis' }, [
      metric('Visitors', num(t.visitors), delta(t.visitors, p.visitors, 'up', num(p.visitors)), 'Different people each day; a person on two days counts twice'),
      metric('Visits', num(t.visits), delta(t.visits, p.visits, 'up', num(p.visits)), 'A visit ends after 30 minutes without activity'),
      metric('Page views', num(t.pageviews), delta(t.pageviews, p.pageviews, 'up', num(p.pageviews))),
      metric('Pages / visit', (t.pageviews / t.visits).toFixed(1), delta(t.pageviews / t.visits, per(p.pageviews, p.visits))),
      metric('Bounce rate', pct(t.bounces, t.visits), bounceDelta(t, p), 'Visits that saw one page and clicked nothing that leads anywhere'),
      metric('Visit length', duration(t.duration_s / t.visits), delta(t.duration_s / t.visits, per(p.duration_s, p.visits), 'up', p.visits ? duration(p.duration_s / p.visits) : '')),
    ]),
    el('section', { class: 'oc-card an-chart' }, [
      el('div', { class: 'an-panel__head' }, [
        el('h2', { class: 'oc-h2' }, `Visitors per ${unit}`),
        el('span', { class: 'oc-eyebrow' }, '— visitors · ┄ the period before'),
      ]),
      Orch.chart({ rows: (r.series || []).map((s) => ({ x: s.x, visitors: s.visitors, before: s.before })), x: 'x', kind: 'line', width: 1160, height: 220,
        series: [{ key: 'visitors', label: 'Visitors' }, { key: 'before', label: 'The period before' }] }),
    ]),
    pages(r),
    panels(r),
  ]);
}

/** Bounce rate changes in points, and down is the good direction. */
function bounceDelta(t, p) {
  if (!p.visits) return el('span', { class: 'oc-kpi__delta' }, 'no earlier data');
  const now = Math.round((t.bounces / t.visits) * 100);
  const before = Math.round((p.bounces / p.visits) * 100);
  const d = now - before;
  return el('span', { class: 'oc-kpi__delta' }, d === 0 ? 'same as before' : `${d > 0 ? '+' : '−'}${Math.abs(d)} pts vs ${before}%`);
}
