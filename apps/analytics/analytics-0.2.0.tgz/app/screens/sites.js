// Each website: the line to paste into its pages, whether visits are
// arriving, and its settings (name, time zone, pages not to count). Only the
// sites listed here may send visits: adding or removing one re-declares the
// public action's origins (the workflow "Allow the sites", automations/sites.js),
// and a browser on any other site is refused.
import { A, act, allSites, ago, snippet } from '../data.js';
import { addSiteForm } from './start.js';

const { el } = Orch;
const ZONES = ['UTC', 'Europe/Madrid', 'Europe/London', 'Europe/Lisbon', 'Europe/Paris', 'Europe/Berlin', 'America/New_York', 'America/Chicago',
  'America/Denver', 'America/Los_Angeles', 'America/Mexico_City', 'America/Bogota', 'America/Lima', 'America/Santiago',
  'America/Argentina/Buenos_Aires', 'America/Sao_Paulo', 'Asia/Dubai', 'Asia/Kolkata', 'Asia/Singapore', 'Asia/Tokyo', 'Australia/Sydney'];

export function render() {
  Orch.load('view', async () => {
    const list = await allSites();
    return el('div', { class: 'oc-stack oc-stack--loose an-sites' }, [
      el('div', { class: 'an-head__title' }, [el('h1', { class: 'oc-h1 oc-h1--collection' }, 'Sites'),
        el('p', { class: 'oc-lede' }, 'The websites Analytics counts, the line each one needs, and how its reports are built.')]),
      ...(list.length ? list.map(site) : [el('div', { class: 'oc-card oc-state' }, [el('p', { class: 'oc-state__title' }, 'No website yet.'),
        el('p', { class: 'oc-help' }, 'Add yours below. The overview\'s Getting started walks through the rest.')])]),
      el('section', { class: 'oc-card an-field' }, [
        el('h2', { class: 'oc-h2' }, list.length ? 'Counting another website' : 'Add your website'),
        el('p', { class: 'oc-help' }, 'Only websites on this list can send visits here: a page anywhere else that copies the line is refused.'),
        addSiteForm(list, () => render()),
      ]),
    ]);
  });
}

function site(s) {
  const line = snippet(s);
  const copy = el('button', { class: 'oc-btn oc-btn--sm', type: 'button' }, 'Copy');
  copy.addEventListener('click', async () => {
    try { await navigator.clipboard.writeText(line); Orch.toast('Copied: paste it inside <head> on every page.'); } catch { Orch.toast('Select the line and copy it.', { error: true }); }
  });
  const origins = String(s.origins || '').split(/[\s,]+/).filter(Boolean);
  const arriving = s.last_hit_at ? `Last visit ${ago(s.last_hit_at)}` : 'No visits have arrived yet';
  return el('section', { class: 'oc-card an-site-card' }, [
    el('div', { class: 'an-site-card__head' }, [
      el('div', {}, [el('h2', { class: 'oc-h1', style: { fontSize: '26px' } }, s.name || s.key), el('p', { class: 'oc-eyebrow' }, origins.join(' · ') || 'No address set')]),
      el('span', { class: `oc-badge ${s.last_hit_at ? 'oc-badge--good' : 'oc-badge--warn'}` }, arriving),
    ]),
    el('div', { class: 'an-field' }, [
      el('span', { class: 'oc-eyebrow' }, 'The line for its pages'),
      el('p', { class: 'oc-help' }, 'Paste it inside <head> on every page you want counted. It sets no cookies and needs no consent banner of its own.'),
      el('div', { class: 'an-code' }, [el('code', line), copy]),
    ]),
    el('div', { class: 'an-field' }, [
      el('span', { class: 'oc-eyebrow' }, 'Your own visits'),
      el('p', { class: 'oc-help' }, [
        'To stop counting yourself, open the site once in each browser you use with ',
        el('code', '#orch-analytics=off'), ' at the end of the address',
        origins[0] ? [' — ', el('a', { href: `${origins[0]}/#orch-analytics=off`, target: '_blank', rel: 'noopener' }, 'like this'), ''] : '',
        '. Open it with ', el('code', '#orch-analytics=on'), ' to be counted again.',
      ]),
    ]),
    settings(s),
    el('div', { class: 'an-site-card__foot' }, [
      el('p', { class: 'oc-eyebrow' }, `Reports built ${ago(s.rolled_at)}${s.rollup_note ? ` · ${s.rollup_note}` : ''}`),
      removeButton(s),
    ]),
  ]);
}

function settings(s) {
  const name = el('input', { class: 'oc-input', value: s.name || '', maxlength: '80' });
  const tz = el('select', { class: 'oc-select' }, [...new Set([s.timezone || 'UTC', ...ZONES])].map((z) => el('option', { value: z, selected: z === (s.timezone || 'UTC') }, z)));
  const exclude = el('textarea', { class: 'oc-textarea', rows: '4' }, s.exclude || '');
  const save = el('button', { class: 'oc-btn oc-btn--primary', type: 'submit' }, 'Save');
  const form = el('form', { class: 'an-form' }, [
    el('label', { class: 'oc-field' }, [el('span', { class: 'oc-label' }, 'Name'), name]),
    el('label', { class: 'oc-field' }, [el('span', { class: 'oc-label' }, 'Time zone'), tz,
      el('span', { class: 'oc-help' }, 'Where a day begins and ends in the reports.')]),
    el('label', { class: 'oc-field' }, [el('span', { class: 'oc-label' }, 'Pages not to count'), exclude,
      el('span', { class: 'oc-help' }, 'One per line. End with * for everything under it: /portal/* skips every page under /portal/. Applies to reports built from now on; update the line on the site too, so those visits are not even sent.')]),
    el('div', { class: 'oc-row' }, save),
  ]);
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    save.disabled = true;
    const ok = await act(A.updateSite, { id: s._id, name: name.value.trim() || s.key, timezone: tz.value, exclude: exclude.value.trim() }, 'Saved. The reports use it from their next build.');
    save.disabled = false;
    if (ok) render();
  });
  return el('details', { class: 'an-settings' }, [el('summary', {}, 'Settings'), form]);
}

/**
 * Removing a site stops its visits at once (its addresses leave the public
 * action) and hides it; its reports stay, and adding the same address again
 * brings it back. Two steps: the second names what stops, and its button
 * waits for the tick.
 */
function removeButton(s) {
  const b = el('button', { class: 'oc-btn oc-btn--sm oc-btn--ghost', type: 'button' }, 'Remove…');
  b.addEventListener('click', () => {
    const ack = el('input', { type: 'checkbox' });
    const yes = el('button', { class: 'oc-btn oc-btn--danger', type: 'button', disabled: true }, 'Remove');
    const no = el('button', { class: 'oc-btn', type: 'button' }, 'Keep it');
    const name = s.name || s.key;
    const d = Orch.dialog(el('div', { class: 'oc-stack an-remove' }, [
      el('p', {}, `Visits from ${name} will be refused from the next minute on, even with the line still on its pages.`),
      el('p', { class: 'oc-help' }, 'Its reports so far are kept. Adding the same address again brings it back.'),
      el('label', { class: 'an-remove__ack' }, [ack, ` I understand ${name} stops being counted.`]),
      el('div', { class: 'oc-row' }, [yes, no]),
    ]), { title: `Remove ${name}?` });
    const close = () => { window.removeEventListener('hashchange', close); d.close(); };
    window.addEventListener('hashchange', close);
    ack.addEventListener('change', () => { yes.disabled = !ack.checked; });
    no.addEventListener('click', close);
    yes.addEventListener('click', async () => {
      yes.disabled = true;
      const ok = await act(A.siteStatus, { id: s._id, status: 'Removed' }, `${name} removed. Its visits are refused from now on.`);
      close();
      if (ok) render();
    });
  });
  return b;
}
