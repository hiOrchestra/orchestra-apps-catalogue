// Getting started: the three things a new owner does before Analytics shows
// anything, each checked from the data rather than ticked by hand.
//   1. a site in analytics_sites            (add_site, which also lets its addresses in)
//   2. the line copied, or a visit arrived  (settings.snippet_copied_at)
//   3. a page view from that site           (analytics_events)
// The overview shows it until every site has had a visit; once all is done it
// can be hidden (settings.onboarding_dismissed_at). A new site with no visit
// yet brings it back.
import { A, T, act, firstVisit, saveSettings, snippet, trackerSrc } from '../data.js';
import { normalizeDomain, siteOf } from '../domain.js';

const { el } = Orch;
const POLL_MS = 10000;
const MAX_SITES = 10; // the public action takes 20 origins, two per site

/** Each site with its first visit (or null). */
export async function withVisits(sites) {
  return Promise.all(sites.map(async (s) => ({ site: s, visit: await firstVisit(s).catch(() => null) })));
}

/** Where each step stands. `focus` is the site steps 2 and 3 are about: the first still waiting for a visit. */
export function progress(list, settings) {
  const waiting = list.find((x) => !x.visit);
  const focus = waiting || list[0] || null;
  const steps = {
    site: list.length > 0,
    snippet: !!focus && (!!focus.visit || !!settings.snippet_copied_at),
    'first-visit': !!focus && !!focus.visit,
  };
  const done = steps.site && !waiting;
  return { focus, steps, done, count: Object.values(steps).filter(Boolean).length };
}

/**
 * Show the panel? While something is left, or until it is hidden once all is
 * done. Without a settings row (its table not approved yet) there is nowhere
 * to remember the hiding, so a finished panel is not shown at all.
 */
export const showStart = (p, settings) => !p.done || (!!settings._id && !settings.onboarding_dismissed_at);

/**
 * The panel. `changed()` redraws the screen it sits on (a site added, the
 * first visit arrived, hidden).
 */
export function startPanel(list, settings, changed) {
  const p = progress(list, settings);
  let chosen = p.focus;
  const stepsHost = el('ol', { class: 'an-steps' });
  const draw = () => {
    const now = progress(list, settings);
    stepsHost.replaceChildren(
      step(1, 'Add your website', now.steps.site,
        'Analytics only accepts visits from the websites listed here, so a copy of your line on someone else\'s site counts nothing.',
        [list.length ? el('ul', { class: 'an-step__sites' }, list.map((x) => el('li', { class: 'oc-value' }, [x.site.name || x.site.key,
          el('span', { class: 'oc-muted' }, x.visit ? ' · visits arriving' : ' · waiting for the first visit')]))) : null,
        addSiteForm(list.map((x) => x.site), changed, list.length ? 'Add another' : 'Add')]),
      step(2, 'Paste this line in your website', !!chosen && (!!chosen.visit || !!settings.snippet_copied_at),
        'It loads a small script that sends each page view here. It sets no cookies, so it needs no consent banner of its own.',
        chosen ? snippetBlock(chosen.site, list, settings, (key) => { chosen = list.find((x) => x.site.key === key) || chosen; draw(); }) : waitFor('Add your website first.')),
      step(3, 'Receive the first visit', !!(chosen && chosen.visit),
        'A visit only arrives once the line is on the live site, so this proves the whole path works.',
        chosen ? visitBlock(chosen) : waitFor('Paste the line first.')),
    );
  };
  draw();
  const head = el('div', { class: 'an-panel__head' }, [
    el('div', { class: 'an-start__title' }, [el('h2', { class: 'oc-h2' }, 'Getting started'),
      el('span', { class: 'oc-eyebrow' }, p.done ? 'All set' : `${p.count} of 3 done`)]),
    p.done ? hideButton(settings, changed) : null,
  ]);
  // All done: one line, until it is hidden.
  const doneLine = el('p', { class: 'oc-help an-start__done' }, [el('span', { class: 'an-good' }, '✓ '),
    `${list.length > 1 ? 'Your websites send' : `${list[0] ? (list[0].site.name || list[0].site.key) : 'Your website'} sends`} visits here. To count another website, add it on `,
    Orch.router.link('/sites', 'Sites'), '.']);
  const panel = el('section', { class: 'oc-card an-start', 'aria-label': 'Getting started' }, [head, p.done ? doneLine : stepsHost]);
  if (!p.done) poll(panel, list, changed);
  return panel;
}

function step(n, title, done, why, body) {
  return el('li', { class: `an-step${done ? ' is-done' : ''}` }, [
    el('span', { class: 'an-step__mark oc-value', 'aria-hidden': 'true' }, done ? '✓' : String(n)),
    el('div', { class: 'an-step__body' }, [
      el('h3', { class: 'an-step__title' }, [title, done ? el('span', { class: 'an-sr' }, ' (done)') : '']),
      el('p', { class: 'oc-help' }, why),
      ...[].concat(body).filter(Boolean),
    ]),
  ]);
}

const waitFor = (text) => el('p', { class: 'oc-help an-step__wait' }, text);

/** A domain field, checked as it is typed and again on Add. Used here and on Sites. */
export function addSiteForm(sites, changed, label = 'Add') {
  const input = el('input', { class: 'oc-input', type: 'text', inputmode: 'url', autocomplete: 'off', autocapitalize: 'none', spellcheck: 'false',
    placeholder: 'example.com', 'aria-label': 'Your website\'s address', 'aria-describedby': 'an-add-msg' });
  const msg = el('p', { class: 'oc-help an-add__msg', id: 'an-add-msg' }, 'The address people type to reach it, like example.com or www.example.com.');
  const add = el('button', { class: 'oc-btn oc-btn--primary', type: 'submit' }, label);
  const form = el('form', { class: 'an-add', novalidate: true }, [el('div', { class: 'an-add__row' }, [input, add]), msg]);
  const say = (text, bad) => { msg.textContent = text; msg.classList.toggle('an-add__msg--bad', !!bad); input.setAttribute('aria-invalid', bad ? 'true' : 'false'); };
  input.addEventListener('input', () => { if (input.getAttribute('aria-invalid') === 'true') { const d = normalizeDomain(input.value); if (d.host) say(`Will count ${d.host}.`); } });
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const d = normalizeDomain(input.value);
    if (d.error) { say(d.error, true); input.focus(); return; }
    const timezone = (() => { try { return Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC'; } catch { return 'UTC'; } })();
    const row = siteOf(d.host, timezone);
    if (sites.some((s) => s.key === row.key)) { say(`${row.name} is already on the list.`, true); return; }
    if (sites.length >= MAX_SITES) { say(`Analytics counts up to ${MAX_SITES} websites. Remove one on Sites to add another.`, true); return; }
    add.disabled = true;
    // Removed once: it comes back with its reports instead of a second row.
    const before = await Orch.db.find(T.sites, { key: row.key }).catch(() => null);
    const ok = before
      ? await act(A.siteStatus, { id: before._id, status: 'Active' }, `${row.name} is back. Its visits are let in within a minute.`)
      : await act(A.addSite, row, `${row.name} added. Its visits are let in within a minute.`);
    add.disabled = false;
    if (ok) changed(); else say('That did not save. Try again.', true);
  });
  return form;
}

function snippetBlock(site, list, settings, pick) {
  const line = snippet(site);
  const copy = el('button', { class: 'oc-btn oc-btn--sm', type: 'button' }, 'Copy');
  copy.addEventListener('click', async () => {
    try {
      await navigator.clipboard.writeText(line);
      copy.textContent = 'Copied';
      Orch.toast('Copied. Paste it inside <head> on every page.');
      if (!settings.snippet_copied_at) {
        settings.snippet_copied_at = new Date().toISOString();
        saveSettings(settings, { snippet_copied_at: settings.snippet_copied_at });
      }
    } catch { Orch.toast('Select the line and copy it.', { error: true }); }
  });
  const next = `<Script src="${trackerSrc()}" data-site="${site.key}" strategy="afterInteractive" />`;
  return [
    list.length > 1 ? el('label', { class: 'oc-field an-step__for' }, [el('span', { class: 'oc-label' }, 'For'),
      el('select', { class: 'oc-select', onchange: (e) => pick(e.target.value) }, list.map((x) => el('option', { value: x.site.key, selected: x.site.key === site.key }, x.site.name || x.site.key)))]) : null,
    el('div', { class: 'an-code' }, [el('code', line), copy]),
    el('ul', { class: 'an-how' }, [
      how('Plain HTML', ['Paste it inside ', el('code', '<head>'), ' on every page, or once in the template they share.']),
      how('WordPress', ['Appearance → Theme File Editor → ', el('code', 'header.php'), ', just before ', el('code', '</head>'), '; or a header-code plugin such as WPCode.']),
      how('Webflow, Wix, Squarespace', ['Site settings → Custom code → Head code.']),
      how('Next.js', ['In ', el('code', 'app/layout.tsx'), ': ', el('code', next), ' (from ', el('code', 'next/script'), ').']),
    ]),
  ];
}
const how = (where, text) => el('li', {}, [el('span', { class: 'oc-eyebrow' }, where), el('span', { class: 'an-how__text' }, text)]);

function visitBlock(x) {
  if (x.visit) {
    return el('p', { class: 'an-step__ok' }, [el('span', { class: 'an-good' }, '✓ '), 'First visit received from ',
      el('code', x.visit.path || '/'), ` · ${Orch.fmt.ago(x.visit.at)}`]);
  }
  const host = String(x.site.origins || '').split(/[\s,]+/).find(Boolean) || '';
  return el('div', { class: 'an-step__waiting' }, [
    el('p', {}, [host ? el('a', { href: host, target: '_blank', rel: 'noopener' }, 'Open your site in another tab') : 'Open your site in another tab',
      ' and load a page or two. This turns to ✓ by itself.']),
    el('p', { class: 'oc-eyebrow an-pulse', role: 'status' }, 'Waiting for the first visit · checking every 10 seconds'),
    el('p', { class: 'oc-help' }, 'Nothing after a few minutes? Check the line is inside <head> of the published site (not a draft), and that an ad blocker is not stopping it in your browser.'),
  ]);
}

/** Every 10 s while the panel is on screen: did a site waiting for its first visit get one? */
function poll(panel, list, changed) {
  const waiting = list.filter((x) => !x.visit).map((x) => x.site);
  if (!waiting.length) return;
  const timer = setInterval(async () => {
    if (!panel.isConnected) { clearInterval(timer); return; }
    if (document.visibilityState !== 'visible') return;
    for (const s of waiting) {
      const v = await firstVisit(s).catch(() => null);
      if (v) { clearInterval(timer); if (panel.isConnected) changed(); return; }
    }
  }, POLL_MS);
}

function hideButton(settings, changed) {
  const b = el('button', { class: 'oc-btn oc-btn--sm', type: 'button' }, 'Hide this');
  b.addEventListener('click', async () => {
    b.disabled = true;
    const ok = await saveSettings(settings, { onboarding_dismissed_at: new Date().toISOString() });
    if (ok) changed(); else b.disabled = false;
  });
  return b;
}
