// A website's address as a person types it, turned into what Analytics keeps:
// the host ("example.com"), the key the tracker line names ("example-com") and
// the origins the public action `hit` lets in (https, with and without www).
// Pure, so test/sites.test.js runs it without a browser.

const LABEL = /^(?!-)[a-z0-9-]{1,63}(?<!-)$/;

/**
 * "Example.com", "https://www.example.com/" → { host: 'example.com' } / { host: 'www.example.com' }.
 * A scheme and a lone trailing slash are dropped (that is how an address is
 * copied); a path, a port, an IP address or a name without a dot is refused
 * with a sentence that says what to type instead.
 */
export function normalizeDomain(input) {
  let s = String(input || '').trim().toLowerCase();
  if (!s) return { error: 'Type your website\'s address, like example.com.' };
  s = s.replace(/^[a-z][a-z0-9+.-]*:\/\//, '').replace(/\/+$/, '').replace(/\.$/, '');
  if (/[/?#]/.test(s)) {
    const host = s.split(/[/?#]/)[0];
    return { error: `Only the address, without the page: ${host || 'example.com'}.` };
  }
  if (s.includes('@')) return { error: 'That looks like an email address. Type the website\'s address, like example.com.' };
  if (/:\d*$/.test(s)) return { error: `Leave out the port: ${s.replace(/:\d*$/, '')}.` };
  if (/^[\d.]+$/.test(s) || s.includes(':')) return { error: 'Type the website\'s name, not an IP address.' };
  if (s.length > 253) return { error: 'That address is too long.' };
  // A name with accents (müller.de) becomes the form browsers send (xn--mller-kva.de).
  if (/[^a-z0-9.-]/.test(s)) {
    try { s = new URL(`https://${s}`).hostname; } catch { return { error: 'Use only letters, numbers, dots and dashes.' }; }
    if (/[^a-z0-9.-]/.test(s)) return { error: 'Use only letters, numbers, dots and dashes.' };
  }
  const labels = s.split('.');
  if (labels.length < 2 || !labels.every((l) => LABEL.test(l)) || !/^(xn--[a-z0-9-]+|[a-z]{2,63})$/.test(labels[labels.length - 1])) {
    return { error: 'That is not a website address. It looks like example.com or www.example.com.' };
  }
  return { host: s };
}

/** The host without www: the site's name and the root of both origins. */
export const bareHost = (host) => String(host).replace(/^www\./, '');

/** "www.shop.example.com" → "shop-example-com": the key in the tracker line (a-z0-9_-, up to 40). */
export function keyOf(host) {
  const k = bareHost(host).replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
  return k.length <= 40 ? k : k.slice(0, 40).replace(/-+$/, '');
}

/** What add_site writes for a host, as install.js does with --site. */
export function siteOf(host, timezone) {
  const bare = bareHost(host);
  return { key: keyOf(host), name: bare, origins: `https://${bare},https://www.${bare}`, timezone: timezone || 'UTC' };
}
