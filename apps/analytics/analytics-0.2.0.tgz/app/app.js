// The router and the rail. Overview is home: one site, one period, every
// breakdown. Live is the last 30 minutes, read straight from the visits.
// Sites holds each site's settings and the line to paste into it.
import { render as overview } from './screens/overview.js';
import { render as live } from './screens/live.js';
import { render as sites } from './screens/sites.js';

const { el, router } = Orch;

router.define({
  '/': overview,
  '/p/:period': overview,
  '/live': live,
  '/sites': sites,
}, () => Orch.mount('view', el('div', { class: 'oc-state' }, [
  el('p', 'There is no screen here.'), router.link('/', 'Go to the overview'),
]))).start();

Orch.mount('nav', [
  router.link('/', 'Overview', { class: 'oc-tab' }),
  router.link('/live', 'Live', { class: 'oc-tab' }),
  router.link('/sites', 'Sites', { class: 'oc-tab' }),
]);
