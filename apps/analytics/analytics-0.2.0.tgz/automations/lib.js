'use strict';
/**
 * What every Analytics script shares (copied from Forms' lib.js, which is the
 * SDK the platform does not have yet): reading the project's database, writing
 * to it, and talking to the instance as the workflow's agent.
 *
 * Reads go to the project's SQLite file directly, read-only and
 * parameterised. Every write goes through `orch-database batch`, the
 * platform's own writer: one transaction, and a `when` precondition checked
 * inside the UPDATE, so "this response is mine now" is atomic.
 *
 * The project is the one these scripts were installed into
 * (projects/<p>/apps/analytics/automations), so nothing names it by hand.
 *
 * Locally (ANALYTICS_LOCAL=1) the same batch runs against ANALYTICS_DB with the
 * same semantics, so every script is tested off the instance.
 */
const { DatabaseSync } = require('node:sqlite');
const { execFileSync } = require('child_process');
const fs = require('fs');
const os = require('os');
const path = require('path');

const PROJECT = process.env.ANALYTICS_PROJECT || (__dirname.match(/projects\/([^/]+)\/apps\/analytics/) || [])[1] || 'default';
const STATE = process.env.OPENCLAW_STATE_DIR || '/home/node/.openclaw';
const DB_PATH = process.env.ANALYTICS_DB || path.join(STATE, 'orchestra', 'projects', PROJECT, 'data', 'data.db');
const LOCAL = process.env.ANALYTICS_LOCAL === '1';

// ── reading ──────────────────────────────────────────────────────────────
let reader = null;
function db() {
  if (!reader) {
    reader = new DatabaseSync(DB_PATH, { readOnly: true });
    reader.exec('PRAGMA busy_timeout = 5000');
  }
  return reader;
}
const all = (sql, ...params) => db().prepare(sql).all(...params);
const one = (sql, ...params) => db().prepare(sql).get(...params);

/** JSON kept in a text column, or the fallback when it is empty or not JSON. */
function jsonOf(text, fallback) {
  if (text === null || text === undefined || text === '') return fallback;
  if (typeof text === 'object') return text;
  try { return JSON.parse(text); } catch { return fallback; }
}

// ── writing ──────────────────────────────────────────────────────────────
/**
 * One transaction per chunk, all or nothing; the inserted ids in order. Big
 * batches are split by size: one argv string over 128 KB is refused by the
 * kernel before the CLI ever runs.
 */
function write(ops) {
  const chunks = [];
  let cur = [];
  let size = 0;
  for (const op of ops) {
    const n = JSON.stringify(op).length;
    if (cur.length && size + n > 90000) { chunks.push(cur); cur = []; size = 0; }
    cur.push(op);
    size += n;
  }
  if (cur.length) chunks.push(cur);
  const results = [];
  for (const chunk of chunks) results.push(...((LOCAL ? localBatch(chunk) : cliBatch(chunk)).results || []));
  return results;
}

function cliBatch(ops) {
  let out;
  try {
    out = execFileSync('orch-database', ['--project', PROJECT, 'batch', '--ops', JSON.stringify(ops)],
      { encoding: 'utf8', timeout: 60000, maxBuffer: 16 << 20 });
  } catch (e) {
    let j = null;
    try { j = JSON.parse(String(e.stdout || '')); } catch { /* not JSON */ }
    throw new Error((j && j.error) || String(e.stderr || e.message).trim().slice(0, 300));
  }
  const j = JSON.parse(out);
  if (!j.ok) throw new Error(j.error || 'the write failed');
  return j;
}

/** orch-database's run_batch, for local tests: same `when`, same all-or-none, same results. */
function localBatch(ops) {
  const w = new DatabaseSync(DB_PATH);
  w.exec('PRAGMA busy_timeout = 5000');
  const now = sqlNow();
  const named = {};
  const deref = (v) => (typeof v === 'string' && v.startsWith('$') && named[v.slice(1).split('.')[0]]
    ? named[v.slice(1).split('.')[0]]._id : v);
  const results = [];
  w.exec('BEGIN IMMEDIATE');
  try {
    ops.forEach((op, i) => {
      const data = {};
      for (const [k, v] of Object.entries(op.data || {})) if (!k.startsWith('_')) data[k] = deref(v);
      if (op.op === 'insert') {
        const cols = [...Object.keys(data), '_created_at', '_updated_at'];
        const r = w.prepare(`INSERT INTO "${op.table}" (${cols.map((c) => `"${c}"`).join(', ')}) VALUES (${cols.map(() => '?').join(', ')})`)
          .run(...Object.values(data), now, now);
        const id = Number(r.lastInsertRowid);
        if (op.as) named[op.as] = { _id: id };
        results.push({ op: 'insert', table: op.table, _id: id });
      } else {
        const when = op.when || {};
        const r = w.prepare(`UPDATE "${op.table}" SET ${Object.keys(data).map((c) => `"${c}" = ?`).join(', ')}, _updated_at = ? `
          + `WHERE _id = ? AND _deleted = 0${Object.keys(when).map((c) => ` AND "${c}" IS ?`).join('')}`)
          .run(...Object.values(data), now, deref(op.id), ...Object.values(when));
        if (!r.changes) throw new Error(`op ${i}: row ${op.id} changed meanwhile (precondition failed)`);
        results.push({ op: 'update', table: op.table, _id: deref(op.id) });
      }
    });
    w.exec('COMMIT');
  } catch (e) {
    w.exec('ROLLBACK');
    w.close();
    throw e;
  }
  w.close();
  return { ok: true, applied: results.length, results };
}

/** Soft-delete rows by id (integers only, so the WHERE is safe to build). */
function softDelete(table, ids) {
  const list = ids.filter((x) => Number.isInteger(x));
  if (!list.length) return 0;
  const where = `_id IN (${list.join(',')})`;
  if (LOCAL) {
    const w = new DatabaseSync(DB_PATH);
    const r = w.prepare(`UPDATE "${table}" SET _deleted = 1, _updated_at = ? WHERE ${where}`).run(sqlNow());
    w.close();
    return r.changes;
  }
  const out = JSON.parse(execFileSync('orch-database', ['--project', PROJECT, 'delete', table, '--where', where], { encoding: 'utf8', timeout: 60000 }));
  if (out.ok === false) throw new Error(out.error || 'the delete failed');
  return out.affected || 0;
}

// ── one run at a time ────────────────────────────────────────────────────
const STALE_MS = 150000; // longer than a step may run (120 s): a file this old was left by a run that was killed

/**
 * A lock file, so two runs (the hourly one and a Refresh) do not build the
 * same reports at once. A run that cannot create the file goes on without it.
 *   lock('rollup') -> { release() }, or null when another run holds it
 */
function lock(name) {
  // Per agent: a file another agent left in /tmp (sticky) is one this one could never remove.
  let who = process.env.ORCHESTRA_AGENT_ID;
  if (!who) { try { who = os.userInfo().username; } catch { who = String(process.getuid ? process.getuid() : 'node'); } }
  const file = path.join(process.env.ANALYTICS_LOCK_DIR || os.tmpdir(), `orchestra-analytics-${PROJECT}-${who}-${name}.lock`);
  const held = { file, release() { try { fs.unlinkSync(file); } catch { /* already gone */ } } };
  for (let i = 0; i < 2; i += 1) {
    try {
      fs.writeFileSync(file, String(process.pid), { flag: 'wx' });
      return held;
    } catch (e) {
      if (e.code !== 'EEXIST') return { file: null, release() {} };
      let age;
      try { age = Date.now() - fs.statSync(file).mtimeMs; } catch { continue; } // let go meanwhile: try again
      if (age < STALE_MS) return null;
      try { fs.unlinkSync(file); } catch { /* another run took it over first */ }
    }
  }
  return null;
}

// ── time ─────────────────────────────────────────────────────────────────
/** 'YYYY-MM-DD HH:MM:SS' in UTC: the format orch-database stamps rows with. */
const sqlNow = (d = new Date()) => d.toISOString().slice(0, 19).replace('T', ' ');

/** '2026-10-03 10:00:00' (orch-database, UTC) or '2026-10-03T10:00:00.000Z' ($now) as a Date. */
function toDate(v) {
  if (!v) return null;
  const s = String(v).trim();
  const iso = s.includes('T') ? s : s.replace(' ', 'T');
  const d = new Date(/[zZ]|[+-]\d\d:?\d\d$/.test(iso) ? iso : `${iso}Z`);
  return Number.isNaN(d.getTime()) ? null : d;
}

// ── the instance, as this workflow's agent ───────────────────────────────
/**
 * Scripts run as the workflow's agent (runsAs, through orch-as): its id and
 * token are in the environment. HOOKS_TOKEN is only there when a person runs a
 * script by hand as `node`.
 */
function identityHeaders() {
  const id = process.env.ORCHESTRA_AGENT_ID;
  const token = process.env.ORCHESTRA_AGENT_TOKEN;
  if (id && token) return { 'x-orchestra-agent': id, 'x-orchestra-agent-token': token };
  const secret = process.env.HOOKS_TOKEN || process.env.OPENCLAW_GATEWAY_TOKEN || '';
  return secret ? { 'x-orchestra-secret': secret } : {};
}

/**
 * POST to the instance's api-server. Headers go to curl on stdin (-K -),
 * never argv, so the token is not in the process list. Never throws.
 */
function post(route, body) {
  const q = (v) => `"${String(v).replace(/[\\"]/g, '\\$&')}"`;
  const config = [
    `url = ${q(`http://127.0.0.1:${Number(process.env.API_SERVER_PORT || 3001)}${route}`)}`,
    'request = "POST"',
    'header = "Content-Type: application/json"',
    ...Object.entries(identityHeaders()).map(([k, v]) => `header = ${q(`${k}: ${v}`)}`),
    `data = ${q(JSON.stringify(body))}`,
  ].join('\n');
  try {
    const out = execFileSync('curl', ['-sS', '-m', '30', '-K', '-'], { input: config, timeout: 35000, stdio: ['pipe', 'pipe', 'pipe'] }).toString();
    let j = null;
    try { j = JSON.parse(out); } catch { /* reported below */ }
    if (j && j.success) return { ok: true, data: j.data };
    return { ok: false, why: String((j && j.error && (j.error.message || j.error)) || out).trim().slice(0, 200) };
  } catch (e) {
    return { ok: false, why: String((e.stderr && e.stderr.toString()) || e.message).trim().slice(0, 200) };
  }
}

/** The one JSON line a workflow step leaves as its output. */
function done(result) {
  process.stdout.write(`${JSON.stringify(result)}\n`);
  return result;
}

/**
 * Delete rows for good. orch-database backs the whole database up before a
 * destructive statement, so this runs rarely (the monthly prune), with a WHERE
 * built only from integers and dates this script made.
 */
function hardDelete(table, where) {
  if (LOCAL) {
    const w = new DatabaseSync(DB_PATH);
    const r = w.prepare(`DELETE FROM "${table}" WHERE ${where}`).run();
    w.close();
    return r.changes;
  }
  const out = JSON.parse(execFileSync('orch-database', ['--project', PROJECT, 'sql', `DELETE FROM "${table}" WHERE ${where}`, '--confirm'],
    { encoding: 'utf8', timeout: 100000 }));
  if (out.ok === false) throw new Error(out.error || 'the delete failed');
  return out.affected || 0;
}

module.exports = {
  PROJECT, DB_PATH, LOCAL, all, one, jsonOf, write, softDelete, hardDelete, lock, sqlNow, toDate,
  identityHeaders, post, done,
};
