'use strict';
/**
 * Reading what a visit says about itself: the browser, system and device from
 * the user agent, whether it is a bot, the country from the browser's time
 * zone (the instance has no IP-to-country database, and never keeps the IP),
 * and where the visit came from.
 *
 * Pure functions: the tests call them directly.
 */

// ── bots ──────────────────────────────────────────────────────────────────
const BOT = /bot\b|bot\/|crawl|spider|slurp|headless|lighthouse|pagespeed|prerender|preview|facebookexternalhit|embedly|quora link|whatsapp|telegrambot|discordbot|slackbot|vercel|uptime|monitor|pingdom|statuscake|python-requests|curl\/|wget\/|axios\/|node-fetch|go-http|java\/|okhttp|httpclient|scrapy|phantom|selenium|puppeteer|playwright|chrome-lighthouse|gtmetrix|semrush|ahrefs|mj12|dotbot|petalbot|bytespider|gptbot|claudebot|perplexitybot|ccbot|applebot|yandex|baiduspider|duckduckbot|bingpreview/i;
const isBot = (ua) => !ua || ua.length < 20 || BOT.test(ua);

// ── browser, system, device ───────────────────────────────────────────────
function browserOf(ua) {
  if (/Edg(e|A|iOS)?\//.test(ua)) return 'Edge';
  if (/OPR\/|Opera/.test(ua)) return 'Opera';
  if (/SamsungBrowser/.test(ua)) return 'Samsung Internet';
  if (/Firefox|FxiOS/.test(ua)) return 'Firefox';
  if (/DuckDuckGo/.test(ua)) return 'DuckDuckGo';
  if (/Brave/.test(ua)) return 'Brave';
  if (/Instagram/.test(ua)) return 'Instagram (in-app)';
  if (/FBAN|FBAV/.test(ua)) return 'Facebook (in-app)';
  if (/LinkedInApp/.test(ua)) return 'LinkedIn (in-app)';
  if (/CriOS|Chrome\//.test(ua)) return 'Chrome';
  if (/Safari\//.test(ua) && /Version\//.test(ua)) return 'Safari';
  if (/AppleWebKit/.test(ua) && /Mobile\//.test(ua)) return 'Safari (in-app)';
  return 'Other';
}

function osOf(ua) {
  if (/Windows NT/.test(ua)) return 'Windows';
  if (/iPhone|iPad|iPod/.test(ua)) return 'iOS';
  if (/Android/.test(ua)) return 'Android';
  if (/CrOS/.test(ua)) return 'ChromeOS';
  if (/Mac OS X|Macintosh/.test(ua)) return 'macOS';
  if (/Linux/.test(ua)) return 'Linux';
  return 'Other';
}

function deviceOf(ua, vw) {
  if (/iPad|Tablet|Nexus (7|9|10)|SM-T|Kindle|Silk/.test(ua) || (/Android/.test(ua) && !/Mobile/.test(ua))) return 'Tablet';
  if (/Mobi|iPhone|iPod|Android.*Mobile|Windows Phone/.test(ua)) return 'Mobile';
  const w = Number(vw) || 0;
  if (w && w < 600) return 'Mobile';
  if (w && w < 1024 && /Macintosh/.test(ua) && /Version\//.test(ua)) return 'Tablet'; // an iPad asking for the desktop site
  return 'Desktop';
}

function screenOf(vw) {
  const w = Number(vw) || 0;
  if (!w) return 'Unknown';
  if (w < 600) return 'Phone (< 600 px)';
  if (w < 1024) return 'Tablet (600–1023 px)';
  if (w < 1440) return 'Laptop (1024–1439 px)';
  return 'Desktop (≥ 1440 px)';
}

// ── country from the time zone ────────────────────────────────────────────
// The IANA zone a browser reports names a place, and nearly every zone sits in
// one country. Approximate by design: a traveller's laptop on home time counts
// at home.
const TZ = {
  'Europe/Madrid': 'ES', 'Atlantic/Canary': 'ES', 'Africa/Ceuta': 'ES', 'Europe/Lisbon': 'PT', 'Atlantic/Madeira': 'PT', 'Atlantic/Azores': 'PT',
  'Europe/London': 'GB', 'Europe/Dublin': 'IE', 'Europe/Paris': 'FR', 'Europe/Berlin': 'DE', 'Europe/Busingen': 'DE', 'Europe/Rome': 'IT',
  'Europe/Amsterdam': 'NL', 'Europe/Brussels': 'BE', 'Europe/Luxembourg': 'LU', 'Europe/Zurich': 'CH', 'Europe/Vienna': 'AT',
  'Europe/Copenhagen': 'DK', 'Europe/Stockholm': 'SE', 'Europe/Oslo': 'NO', 'Europe/Helsinki': 'FI', 'Atlantic/Reykjavik': 'IS',
  'Europe/Warsaw': 'PL', 'Europe/Prague': 'CZ', 'Europe/Bratislava': 'SK', 'Europe/Budapest': 'HU', 'Europe/Bucharest': 'RO',
  'Europe/Sofia': 'BG', 'Europe/Athens': 'GR', 'Europe/Istanbul': 'TR', 'Europe/Kiev': 'UA', 'Europe/Kyiv': 'UA', 'Europe/Moscow': 'RU',
  'Europe/Minsk': 'BY', 'Europe/Vilnius': 'LT', 'Europe/Riga': 'LV', 'Europe/Tallinn': 'EE', 'Europe/Belgrade': 'RS', 'Europe/Zagreb': 'HR',
  'Europe/Ljubljana': 'SI', 'Europe/Sarajevo': 'BA', 'Europe/Skopje': 'MK', 'Europe/Tirane': 'AL', 'Europe/Chisinau': 'MD',
  'Europe/Malta': 'MT', 'Asia/Nicosia': 'CY', 'Europe/Monaco': 'MC', 'Europe/Andorra': 'AD', 'Europe/Gibraltar': 'GI',
  'America/New_York': 'US', 'America/Chicago': 'US', 'America/Denver': 'US', 'America/Los_Angeles': 'US', 'America/Phoenix': 'US',
  'America/Anchorage': 'US', 'Pacific/Honolulu': 'US', 'America/Detroit': 'US', 'America/Indiana/Indianapolis': 'US', 'America/Boise': 'US',
  'America/Toronto': 'CA', 'America/Vancouver': 'CA', 'America/Edmonton': 'CA', 'America/Winnipeg': 'CA', 'America/Halifax': 'CA',
  'America/St_Johns': 'CA', 'America/Regina': 'CA', 'America/Montreal': 'CA',
  'America/Mexico_City': 'MX', 'America/Monterrey': 'MX', 'America/Tijuana': 'MX', 'America/Cancun': 'MX', 'America/Merida': 'MX',
  'America/Guatemala': 'GT', 'America/El_Salvador': 'SV', 'America/Tegucigalpa': 'HN', 'America/Managua': 'NI', 'America/Costa_Rica': 'CR',
  'America/Panama': 'PA', 'America/Havana': 'CU', 'America/Santo_Domingo': 'DO', 'America/Puerto_Rico': 'PR', 'America/Jamaica': 'JM',
  'America/Bogota': 'CO', 'America/Caracas': 'VE', 'America/Lima': 'PE', 'America/Guayaquil': 'EC', 'America/La_Paz': 'BO',
  'America/Santiago': 'CL', 'America/Argentina/Buenos_Aires': 'AR', 'America/Buenos_Aires': 'AR', 'America/Argentina/Cordoba': 'AR',
  'America/Argentina/Mendoza': 'AR', 'America/Montevideo': 'UY', 'America/Asuncion': 'PY', 'America/Sao_Paulo': 'BR',
  'America/Fortaleza': 'BR', 'America/Recife': 'BR', 'America/Manaus': 'BR', 'America/Bahia': 'BR', 'America/Belem': 'BR',
  'Asia/Tokyo': 'JP', 'Asia/Seoul': 'KR', 'Asia/Shanghai': 'CN', 'Asia/Hong_Kong': 'HK', 'Asia/Taipei': 'TW', 'Asia/Singapore': 'SG',
  'Asia/Kuala_Lumpur': 'MY', 'Asia/Bangkok': 'TH', 'Asia/Ho_Chi_Minh': 'VN', 'Asia/Saigon': 'VN', 'Asia/Jakarta': 'ID', 'Asia/Manila': 'PH',
  'Asia/Kolkata': 'IN', 'Asia/Calcutta': 'IN', 'Asia/Karachi': 'PK', 'Asia/Dhaka': 'BD', 'Asia/Colombo': 'LK', 'Asia/Kathmandu': 'NP',
  'Asia/Dubai': 'AE', 'Asia/Riyadh': 'SA', 'Asia/Qatar': 'QA', 'Asia/Bahrain': 'BH', 'Asia/Kuwait': 'KW', 'Asia/Muscat': 'OM',
  'Asia/Jerusalem': 'IL', 'Asia/Tel_Aviv': 'IL', 'Asia/Beirut': 'LB', 'Asia/Amman': 'JO', 'Asia/Baghdad': 'IQ', 'Asia/Tehran': 'IR',
  'Asia/Tbilisi': 'GE', 'Asia/Yerevan': 'AM', 'Asia/Baku': 'AZ', 'Asia/Almaty': 'KZ', 'Asia/Tashkent': 'UZ',
  'Australia/Sydney': 'AU', 'Australia/Melbourne': 'AU', 'Australia/Brisbane': 'AU', 'Australia/Perth': 'AU', 'Australia/Adelaide': 'AU',
  'Pacific/Auckland': 'NZ', 'Africa/Johannesburg': 'ZA', 'Africa/Lagos': 'NG', 'Africa/Nairobi': 'KE', 'Africa/Cairo': 'EG',
  'Africa/Casablanca': 'MA', 'Africa/Algiers': 'DZ', 'Africa/Tunis': 'TN', 'Africa/Accra': 'GH', 'Africa/Addis_Ababa': 'ET',
  'Africa/Dakar': 'SN', 'Africa/Abidjan': 'CI', 'Africa/Kampala': 'UG', 'Africa/Dar_es_Salaam': 'TZ', 'Africa/Kigali': 'RW',
};
let regionNames = null;
try { regionNames = new Intl.DisplayNames(['en'], { type: 'region' }); } catch { /* names stay codes */ }

function countryOf(tz) {
  const code = TZ[tz];
  if (code) return (regionNames && regionNames.of(code)) || code;
  if (!tz) return 'Unknown';
  if (/^(UTC|Etc\/)/.test(tz)) return 'Unknown';
  const area = { America: 'Americas (other)', Europe: 'Europe (other)', Asia: 'Asia (other)', Africa: 'Africa (other)', Australia: 'Oceania (other)', Pacific: 'Oceania (other)', Atlantic: 'Other', Indian: 'Other' };
  return area[tz.split('/')[0]] || 'Unknown';
}

// ── languages ─────────────────────────────────────────────────────────────
let langNames = null;
try { langNames = new Intl.DisplayNames(['en'], { type: 'language' }); } catch { /* codes */ }
function languageOf(code) {
  const c = String(code || '').split('-')[0].toLowerCase();
  if (!/^[a-z]{2,3}$/.test(c)) return 'Unknown';
  try { return (langNames && langNames.of(c)) || c; } catch { return c; }
}

// ── where a visit came from ───────────────────────────────────────────────
const SOURCES = [
  [/(^|\.)google\.[a-z.]+$/, 'Google', 'Organic search'], [/(^|\.)bing\.com$/, 'Bing', 'Organic search'],
  [/(^|\.)duckduckgo\.com$/, 'DuckDuckGo', 'Organic search'], [/(^|\.)search\.yahoo\.com$|(^|\.)yahoo\.com$/, 'Yahoo', 'Organic search'],
  [/(^|\.)ecosia\.org$/, 'Ecosia', 'Organic search'], [/(^|\.)search\.brave\.com$/, 'Brave Search', 'Organic search'],
  [/(^|\.)yandex\.[a-z.]+$/, 'Yandex', 'Organic search'], [/(^|\.)baidu\.com$/, 'Baidu', 'Organic search'],
  [/(^|\.)chatgpt\.com$|(^|\.)chat\.openai\.com$/, 'ChatGPT', 'AI assistants'], [/(^|\.)perplexity\.ai$/, 'Perplexity', 'AI assistants'],
  [/(^|\.)claude\.ai$/, 'Claude', 'AI assistants'], [/(^|\.)gemini\.google\.com$/, 'Gemini', 'AI assistants'],
  [/(^|\.)copilot\.microsoft\.com$/, 'Copilot', 'AI assistants'], [/(^|\.)you\.com$/, 'You.com', 'AI assistants'],
  [/(^|\.)linkedin\.com$|(^|\.)lnkd\.in$/, 'LinkedIn', 'Social'], [/(^|\.)t\.co$|(^|\.)twitter\.com$|(^|\.)x\.com$/, 'X (Twitter)', 'Social'],
  [/(^|\.)facebook\.com$|(^|\.)fb\.com$|(^|\.)l\.facebook\.com$/, 'Facebook', 'Social'], [/(^|\.)instagram\.com$/, 'Instagram', 'Social'],
  [/(^|\.)youtube\.com$|(^|\.)youtu\.be$/, 'YouTube', 'Social'], [/(^|\.)reddit\.com$/, 'Reddit', 'Social'],
  [/(^|\.)news\.ycombinator\.com$/, 'Hacker News', 'Social'], [/(^|\.)producthunt\.com$/, 'Product Hunt', 'Social'],
  [/(^|\.)tiktok\.com$/, 'TikTok', 'Social'], [/(^|\.)threads\.net$/, 'Threads', 'Social'], [/(^|\.)bsky\.app$/, 'Bluesky', 'Social'],
  [/(^|\.)github\.com$/, 'GitHub', 'Referral'], [/(^|\.)medium\.com$/, 'Medium', 'Referral'], [/(^|\.)substack\.com$/, 'Substack', 'Referral'],
  [/(^|\.)mail\.google\.com$|(^|\.)outlook\.(live|office)\.com$|(^|\.)mail\.yahoo\.com$/, 'Email', 'Email'],
];
const UTM_NAMES = { google: 'Google', linkedin: 'LinkedIn', facebook: 'Facebook', fb: 'Facebook', instagram: 'Instagram', ig: 'Instagram',
  twitter: 'X (Twitter)', x: 'X (Twitter)', youtube: 'YouTube', reddit: 'Reddit', newsletter: 'Newsletter', chatgpt: 'ChatGPT',
  'chatgpt.com': 'ChatGPT', perplexity: 'Perplexity', bing: 'Bing', email: 'Email', producthunt: 'Product Hunt', hn: 'Hacker News' };

/**
 * { source, channel, referrer } for the first page of a visit.
 * `ref` is "host/path" of the page that linked here (another site only).
 */
function sourceOf(ref, utmSource, utmMedium) {
  const medium = String(utmMedium || '').toLowerCase();
  const raw = String(utmSource || '').trim();
  const host = String(ref || '').split('/')[0].toLowerCase().replace(/^www\./, '');
  const known = SOURCES.find(([re]) => host && re.test(host));
  let source;
  let channel;
  if (raw) {
    source = UTM_NAMES[raw.toLowerCase()] || raw;
  } else if (known) {
    [, source, channel] = known;
  } else if (host) {
    source = host;
  } else {
    source = 'Direct';
  }
  if (/^(cpc|ppc|paid|paidsearch|paid_social|paidsocial|display|cpm|ads?)$/.test(medium)) channel = 'Paid';
  else if (/^(e-?mail|newsletter)$/.test(medium)) channel = 'Email';
  else if (/^(social|social-media|sm)$/.test(medium)) channel = 'Social';
  else if (/^(affiliate|partner|referral)$/.test(medium)) channel = 'Referral';
  if (!channel) {
    if (raw) {
      const byName = SOURCES.find(([re, name]) => name.toLowerCase() === source.toLowerCase() || re.test(raw.toLowerCase()));
      channel = byName ? byName[2] : 'Campaigns';
    } else channel = host ? 'Referral' : 'Direct';
  }
  return { source, channel, referrer: host ? String(ref).replace(/^www\./, '').replace(/\/$/, '') : '' };
}

module.exports = { isBot, browserOf, osOf, deviceOf, screenOf, countryOf, languageOf, sourceOf, TZ };
