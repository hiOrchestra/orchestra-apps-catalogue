'use strict';
/**
 * Which websites may send visits: the public action `hit` of the app `visits`
 * accepts a browser only from the origins it declares (canvas-collect.js
 * `originDecision`). Those origins follow the sites table: every site that is
 * not Removed, each with the addresses kept in its `origins`.
 *
 *   node sites.js            re-declare `hit` with every site's origins
 *   node sites.js --dry-run  say what it would declare
 *
 * It runs as the workflow "Analytics · Allow the sites", which the desk's
 * add_site and set_site_status actions trigger, and install.js does the same
 * at install. It reads the table and ignores its args: what a trigger passes
 * is whatever the caller sent.
 *
 * Declaring is `orch-canvas action add visits --name hit … --origins …`, as
 * the workflow's agent (a member of the project the app lives in, which is
 * what the api-server checks on /api/canvas/apps).
 */
const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');

// scheme + host (+ port): what orch-canvas and canvas-collect accept.
const ORIGIN = /^https?:\/\/[a-z0-9.-]+(:\d{1,5})?$/;
// orch-canvas takes at most 20 origins; a site added from the desk uses two.
const MAX_ORIGINS = 20;
// With no site, `hit` must still name an origin: an action that names none is
// open to every website (originDecision: "no origins declared: unchanged").
// `.invalid` is reserved (RFC 2606), so no browser ever sends it, and the
// instance's own host stays allowed as it always is.
const NO_SITE_YET = 'https://no-site-yet.invalid';

/** A site's own origins, as the table keeps them: comma or space separated, normalised, valid only. */
function originsOf(site) {
  return String((site && site.origins) || '').split(/[\s,]+/)
    .map((o) => o.trim().replace(/\/+$/, '').toLowerCase())
    .filter((o) => ORIGIN.test(o));
}

/**
 * The origins `hit` must declare for these sites: the union of every site's
 * origins, Removed sites left out, in the order the sites were added, capped
 * at MAX_ORIGINS. Never empty (NO_SITE_YET).
 *   -> { origins: [...], dropped: [...] }
 */
function originsFor(sites) {
  const all = [];
  for (const s of (sites || []).filter((x) => x && x.status !== 'Removed' && !x._deleted)) {
    for (const o of originsOf(s)) if (!all.includes(o)) all.push(o);
  }
  if (!all.length) return { origins: [NO_SITE_YET], dropped: [] };
  return { origins: all.slice(0, MAX_ORIGINS), dropped: all.slice(MAX_ORIGINS) };
}

/**
 * `orch-canvas action add` arguments for one declared action (actions.json,
 * public-actions.json). `workflows` names the ids behind "$WF_<KEY>";
 * `origins` replaces "$SITE_ORIGINS". install.js declares every action with it.
 */
function actionArgs(app, a, { workflows = {}, origins = [] } = {}) {
  const sub = (v) => (typeof v === 'string' && v.startsWith('$WF_') ? workflows[v.slice(4).toLowerCase()] : v);
  const args = ['action', 'add', app, '--name', a.name, '--type', a.type, '--access', a.access || 'members'];
  if (a.table) args.push('--table', a.table);
  if (a.fields) args.push('--fields', a.fields.join(','));
  if (a.defaults) args.push('--defaults', JSON.stringify(a.defaults));
  if (a.precondition) args.push('--precondition', JSON.stringify(a.precondition));
  if (a.workflow) args.push('--workflow', sub(a.workflow));
  if (a.args) args.push('--args', JSON.stringify(a.args));
  if (a.trigger) args.push('--trigger-workflow', sub(a.trigger));
  if (a.origins) args.push('--origins', a.origins === '$SITE_ORIGINS' ? origins.join(',') : a.origins);
  if (a.limits) args.push('--limits', JSON.stringify(a.limits));
  return args;
}

/** The declaration of `hit`: next to this script on the instance, one folder up in the source. */
function hitSpec() {
  for (const f of [path.join(__dirname, 'public-actions.json'), path.join(__dirname, '..', 'public-actions.json')]) {
    if (fs.existsSync(f)) return JSON.parse(fs.readFileSync(f, 'utf8')).find((a) => a.name === 'hit');
  }
  throw new Error('public-actions.json is not next to sites.js: run the installer again');
}

function declare(origins, { dryRun = false } = {}) {
  const L = require('./lib');
  const args = actionArgs('visits', hitSpec(), { origins });
  if (dryRun || L.LOCAL) return { declared: false, args };
  let text;
  try {
    text = execFileSync('orch-canvas', args, { encoding: 'utf8', timeout: 60000, maxBuffer: 8 << 20 });
  } catch (e) {
    text = String(e.stdout || '') || String(e.stderr || e.message);
  }
  let r;
  try { r = JSON.parse(text); } catch { r = { ok: false, error: String(text).trim().slice(0, 300) }; }
  if (!r.ok) throw new Error(`orch-canvas refused: ${r.error || JSON.stringify(r).slice(0, 300)}`);
  return { declared: true };
}

function main(argv) {
  const L = require('./lib');
  const dryRun = argv.includes('--dry-run');
  const held = dryRun ? { release() {} } : L.lock('sites');
  // Another run is declaring: it looks at the table again after it declares, so it sees this change too.
  if (!held) return L.done({ ok: true, skipped: 'another run is declaring the sites' });
  try {
    const read = () => originsFor(L.all('SELECT key, origins, status FROM analytics_sites WHERE _deleted = 0 ORDER BY _id'));
    let want = read();
    let result = declare(want.origins, { dryRun });
    // A site added while this one declared: once more, with it.
    for (let i = 0; i < 2 && !dryRun; i += 1) {
      const now = read();
      if (now.origins.join(',') === want.origins.join(',')) break;
      want = now;
      result = declare(want.origins);
    }
    L.done(Object.assign({ ok: true, origins: want.origins, dropped: want.dropped.length ? want.dropped : undefined }, result));
  } catch (e) {
    L.done({ ok: false, error: String(e.message).slice(0, 400) });
    process.exitCode = 1;
  } finally {
    held.release();
  }
}

if (require.main === module) main(process.argv.slice(2));

module.exports = { originsOf, originsFor, actionArgs, NO_SITE_YET, MAX_ORIGINS };
