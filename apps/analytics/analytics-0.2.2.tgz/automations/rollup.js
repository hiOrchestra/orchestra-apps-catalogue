'use strict';
/**
 * Build a site's reports from the visits it recorded.
 *
 *   node rollup.js [--auto|--now] [--all|<site key>] [--dry-run] [--prune]
 *   node rollup.js --scrub-ua    only blank the raw user agent of old rows (install.js runs it)
 *
 * 1. Each day that has new visits (and always today and yesterday, in the
 *    site's own time zone) is rebuilt from the raw rows into ONE row of
 *    `analytics_daily`: the day's totals, and every breakdown (pages, sources,
 *    countries, devices, events, page speed) as JSON.
 * 2. Each period the dashboard shows (today, yesterday, 7, 30 and 90 days,
 *    12 months) is added up from those days into ONE row of
 *    `analytics_reports`, with the period before it for the comparison.
 *    The dashboard reads a single row: no counting in the browser.
 * 3. Once a month (or with --prune) raw visits older than RETAIN_DAYS (every
 *    site alike), and visits for a key no site has once a day old, are
 *    deleted for good. The days already built keep their numbers.
 *
 * How a visit is counted (as Plausible and Umami do): a visitor is the
 * server's daily id ($anon_id), so the same person on two days is two
 * visitors; a visit ends after 30 minutes without activity; a bounce is a visit
 * with one page and no click that leads anywhere. Bots are dropped by user
 * agent, and paths the site excludes are dropped too.
 *
 * The raw user agent is not kept (0.2.2): the tracker sends only the browser,
 * system and device families. Rows written before that still carry `ua`;
 * `--scrub-ua` (run by install.js, and before every build) turns each into its
 * families and blanks it. Idempotent: it only touches rows that still have one.
 */
const L = require('./lib');
const C = require('./classify');

const RETAIN_DAYS = 90;
const VISIT_GAP_MS = 30 * 60 * 1000;
const MAX_VISIT_S = 4 * 3600;
const ROW_BYTES = 85000; // one row travels as one argv string (128 KB) to orch-database
const PERIODS = { today: 1, yesterday: 1, '7d': 7, '30d': 30, '90d': 90, '12m': 365 };
const INTERACTIVE = new Set(['CTA click', 'Outbound link', 'Download', 'Form sent', 'Video play', 'Email click', 'Phone click']);

// A breakdown value's numbers, as an array (JSON stays small):
//   0 visitors · 1 visits · 2 pageviews · 3 bounces · 4 duration (s) · 5 events
//   6 visible time (ms) · 7 pages timed · 8 scroll % (sum) · 9 pages scrolled · 10 entries · 11 exits
const N = 12;
const VISIT_DIMS = ['channel', 'source', 'referrer', 'utm_source', 'utm_medium', 'utm_campaign', 'utm_content', 'utm_term',
  'entry', 'exit', 'country', 'device', 'browser', 'os', 'screen', 'lang', 'site_lang'];

// ── time in the site's zone ───────────────────────────────────────────────
function validZone(tz) {
  try { new Intl.DateTimeFormat('en-CA', { timeZone: tz }); return tz; } catch { return 'UTC'; }
}
const fmtCache = {};
function parts(date, tz) {
  const f = fmtCache[tz] || (fmtCache[tz] = new Intl.DateTimeFormat('en-CA', {
    timeZone: tz, year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hourCycle: 'h23',
  }));
  const o = {};
  for (const p of f.formatToParts(date)) o[p.type] = p.value;
  return o;
}
const localDay = (date, tz) => { const p = parts(date, tz); return `${p.year}-${p.month}-${p.day}`; };
const localHour = (date, tz) => Number(parts(date, tz).hour);
function addDays(day, n) {
  const [y, m, d] = day.split('-').map(Number);
  return new Date(Date.UTC(y, m - 1, d + n)).toISOString().slice(0, 10);
}
/** The UTC instant a local day starts at (twice round, for the DST edge). */
function dayStart(day, tz) {
  const [y, m, d] = day.split('-').map(Number);
  let t = Date.UTC(y, m - 1, d);
  for (let i = 0; i < 2; i += 1) {
    const p = parts(new Date(t), tz);
    const seen = Date.UTC(+p.year, +p.month - 1, +p.day, +p.hour, +p.minute);
    t -= seen - Date.UTC(y, m - 1, d);
  }
  return new Date(t);
}
const iso = (d) => d.toISOString();

// ── one day ───────────────────────────────────────────────────────────────
function excluder(text) {
  const rules = String(text || '').split(/[\n,]+/).map((s) => s.trim()).filter(Boolean);
  return (p) => rules.some((r) => (r.endsWith('*') ? String(p).startsWith(r.slice(0, -1)) : p === r));
}
const props = (t) => { const o = L.jsonOf(t, {}); return o && typeof o === 'object' ? o : {}; };
const detailOf = (e) => {
  const p = props(e.props);
  const what = p.label || p.url || p.file || p.form || p.video || p.to || (e.name === '404' ? (p.path || e.path) : '') || '';
  return `${e.name}${what ? ` — ${String(what).slice(0, 120)}` : ''}`;
};
const q75 = (xs) => {
  const v = xs.filter((x) => Number.isFinite(x)).sort((a, b) => a - b);
  return v.length ? v[Math.min(v.length - 1, Math.floor(v.length * 0.75))] : null;
};

/** Everything one day of raw rows adds up to. Pure: the tests call it. */
function buildDay(rows, { tz = 'UTC', exclude = '' } = {}) {
  const out = excluder(exclude);
  const hits = rows.filter((r) => r.anon && !C.familiesOf(r).bot && !out(r.path || '/'))
    .map((r) => Object.assign({}, r, { t: Date.parse(r.at) })).filter((r) => Number.isFinite(r.t))
    .sort((a, b) => a.t - b.t);
  const dims = {};
  const cell = (dim, value) => {
    const d = dims[dim] || (dims[dim] = {});
    const k = value === null || value === undefined || value === '' ? '(none)' : String(value).slice(0, 200);
    return d[k] || (d[k] = { a: new Set(), n: new Array(N).fill(0) });
  };
  const leaves = new Map(); // page_id → the last word on that page
  for (const h of hits) {
    if (h.kind !== 'leave') continue;
    const was = leaves.get(h.page_id) || {};
    leaves.set(h.page_id, {
      time: Math.max(was.time || 0, Number(h.time_ms) || 0), scroll: Math.max(was.scroll || 0, Number(h.scroll) || 0),
      lcp: h.lcp ?? was.lcp, inp: h.inp ?? was.inp, cls: h.cls ?? was.cls, ttfb: h.ttfb ?? was.ttfb, path: h.path, t: h.t,
    });
  }

  // visits: per visitor, split where 30 minutes passed without anything
  const byAnon = new Map();
  for (const h of hits) { if (!byAnon.has(h.anon)) byAnon.set(h.anon, []); byAnon.get(h.anon).push(h); }
  const visits = [];
  for (const [anon, list] of byAnon) {
    let cur = null;
    for (const h of list) {
      if (!cur || h.t - cur.last > VISIT_GAP_MS) { cur = { anon, first: h.t, last: h.t, pv: [], ev: [] }; visits.push(cur); }
      cur.last = Math.max(cur.last, h.t);
      if (h.kind === 'pageview') cur.pv.push(h);
      else if (h.kind === 'event') cur.ev.push(h);
      else if (h.kind === 'leave') cur.last = Math.max(cur.last, h.t);
    }
  }

  const totals = { visitors: 0, visits: 0, pageviews: 0, bounces: 0, duration_s: 0, events: 0 };
  const hours = Array.from({ length: 24 }, () => ({ p: 0, a: new Set() }));
  const vitals = {}; // path → {lcp:[], inp:[], cls:[], ttfb:[]}
  const visitors = new Set();
  for (const v of visits) {
    for (const e of v.ev) {
      totals.events += 1;
      for (const [dim, val] of [['event', e.name], ['event_detail', detailOf(e)]]) {
        const c = cell(dim, val); c.a.add(v.anon); c.n[5] += 1;
      }
    }
    if (!v.pv.length) continue; // events after midnight from a visit that began yesterday: counted above, not a visit
    visitors.add(v.anon);
    const entry = v.pv[0];
    const exit = v.pv[v.pv.length - 1];
    const bounce = v.pv.length === 1 && !v.ev.some((e) => INTERACTIVE.has(e.name)) ? 1 : 0;
    const lastLeave = leaves.get(exit.page_id);
    const end = Math.max(v.last, lastLeave ? lastLeave.t : 0);
    const duration = Math.min(MAX_VISIT_S, Math.round((end - v.first) / 1000));
    totals.visits += 1; totals.pageviews += v.pv.length; totals.bounces += bounce; totals.duration_s += duration;
    const src = C.sourceOf(entry.ref, entry.utm_source, entry.utm_medium);
    const fam = C.familiesOf(entry);
    const attrs = {
      channel: src.channel, source: src.source, referrer: src.referrer || null,
      utm_source: entry.utm_source || null, utm_medium: entry.utm_medium || null, utm_campaign: entry.utm_campaign || null,
      utm_content: entry.utm_content || null, utm_term: entry.utm_term || null,
      entry: entry.path, exit: exit.path, country: C.countryOf(entry.tz), device: fam.device,
      browser: fam.browser, os: fam.os, screen: C.screenOf(entry.vw), lang: C.languageOf(entry.lang),
      site_lang: entry.site_lang ? C.languageOf(entry.site_lang) : null,
    };
    for (const dim of VISIT_DIMS) {
      if (attrs[dim] === null && /^(utm_|referrer|site_lang)/.test(dim)) continue; // "no campaign" is not a campaign
      const c = cell(dim, attrs[dim]);
      c.a.add(v.anon); c.n[1] += 1; c.n[2] += v.pv.length; c.n[3] += bounce; c.n[4] += duration;
    }
    v.pv.forEach((p, i) => {
      const c = cell('page', p.path);
      c.a.add(v.anon); c.n[2] += 1;
      if (i === 0) c.n[10] += 1;
      if (i === v.pv.length - 1) c.n[11] += 1;
      const lv = leaves.get(p.page_id);
      if (lv) {
        if (lv.time > 0) { c.n[6] += lv.time; c.n[7] += 1; }
        c.n[8] += lv.scroll; c.n[9] += 1;
        if (lv.lcp != null || lv.ttfb != null) {
          const s = vitals[p.path] || (vitals[p.path] = { lcp: [], inp: [], cls: [], ttfb: [] });
          for (const k of ['lcp', 'inp', 'cls', 'ttfb']) if (lv[k] != null && s[k].length < 300) s[k].push(Number(lv[k]));
        }
      }
      if (p.title) cell('title', `${p.path}\u0000${p.title}`).n[2] += 1;
      const hr = hours[localHour(new Date(p.t), tz)];
      hr.p += 1; hr.a.add(v.anon);
    });
  }
  totals.visitors = visitors.size;

  // page titles: the most seen title per path, for labels
  const titles = {};
  for (const [k, c] of Object.entries(dims.title || {})) {
    const [p, t] = k.split('\u0000');
    if (!titles[p] || c.n[2] > titles[p].n) titles[p] = { t, n: c.n[2] };
  }
  delete dims.title;

  const flat = {};
  for (const [dim, values] of Object.entries(dims)) {
    flat[dim] = Object.entries(values).map(([k, c]) => { c.n[0] = c.a.size; return [k, c.n]; })
      .sort((a, b) => b[1][0] - a[1][0] || b[1][2] - a[1][2] || b[1][5] - a[1][5]);
  }
  return {
    totals,
    data: {
      dims: flat,
      hours: hours.map((h) => [h.a.size, h.p]),
      vitals,
      titles: Object.fromEntries(Object.entries(titles).map(([p, x]) => [p, x.t])),
    },
  };
}

/** The day's JSON, cut to fit one row: fewer values per breakdown until it does. */
function fitDay(data) {
  for (const cap of [300, 150, 80, 40, 20]) {
    const d = Object.assign({}, data, { dims: Object.fromEntries(Object.entries(data.dims).map(([k, v]) => [k, v.slice(0, cap)])) });
    if (cap <= 80) d.vitals = Object.fromEntries(Object.entries(data.vitals).slice(0, 30));
    const text = JSON.stringify(d);
    if (text.length < ROW_BYTES) return text;
  }
  return JSON.stringify({ dims: {}, hours: data.hours, vitals: {}, titles: {}, cut: true });
}

// ── a period, from its days ───────────────────────────────────────────────
function emptyTotals() { return { visitors: 0, visits: 0, pageviews: 0, bounces: 0, duration_s: 0, events: 0 }; }
function addTotals(t, row) { for (const k of Object.keys(t)) t[k] += Number(row[k]) || 0; return t; }

/** Pure: `days` are the period's day strings; `daily` maps day → {totals…, data}. */
function buildReport(period, days, prevDays, daily, { top = 50 } = {}) {
  const totals = emptyTotals();
  const prev = emptyTotals();
  const sums = {};
  const vit = {};
  const titles = {};
  const series = [];
  const pageDays = []; // per day of the period: page → visitors, for the sparklines
  let withData = 0;
  for (const day of days) {
    const row = daily[day];
    if (!row) { series.push({ x: day, visitors: null, pageviews: null }); continue; }
    withData += 1;
    addTotals(totals, row);
    const data = typeof row.data === 'string' ? L.jsonOf(row.data, {}) : (row.data || {});
    series.push({ x: day, visitors: Number(row.visitors) || 0, pageviews: Number(row.pageviews) || 0, hours: data.hours });
    pageDays.push([day, new Map(((data.dims || {}).page || []).map(([k, n]) => [k, Number(n[0]) || 0]))]);
    for (const [dim, list] of Object.entries(data.dims || {})) {
      const s = sums[dim] || (sums[dim] = new Map());
      for (const [k, n] of list) {
        const acc = s.get(k) || new Array(N).fill(0);
        for (let i = 0; i < N; i += 1) acc[i] += Number(n[i]) || 0;
        s.set(k, acc);
      }
    }
    for (const [p, v] of Object.entries(data.vitals || {})) {
      const a = vit[p] || (vit[p] = { lcp: [], inp: [], cls: [], ttfb: [] });
      for (const k of Object.keys(a)) if (Array.isArray(v[k])) a[k].push(...v[k]);
    }
    Object.assign(titles, data.titles || {});
  }
  // The period before: its totals always; its breakdowns (visitors per value,
  // for the change beside each row) when those days still carry their data.
  const prevSums = {};
  const prevSeries = [];
  let prevWithData = 0;
  for (const day of prevDays) {
    const row = daily[day];
    if (!row) { prevSeries.push({ x: day, visitors: null, hours: null }); continue; }
    addTotals(prev, row);
    const data = typeof row.data === 'string' ? L.jsonOf(row.data, null) : (row.data || null);
    prevSeries.push({ x: day, visitors: Number(row.visitors) || 0, hours: data && data.hours });
    if (!data) continue;
    prevWithData += 1;
    for (const [dim, list] of Object.entries(data.dims || {})) {
      const s = prevSums[dim] || (prevSums[dim] = new Map());
      for (const [k, n] of list) s.set(k, (s.get(k) || 0) + (Number(n[0]) || 0));
    }
  }

  // one day: by hour; 12 months: by month; otherwise by day
  // `before` is the period before at the same position (day 3 against its day 3).
  let points = series.map((s, i) => ({ x: s.x, visitors: s.visitors, pageviews: s.pageviews, before: prevSeries[i] ? prevSeries[i].visitors : null }));
  if (days.length === 1) {
    const h = (series[0] && series[0].hours) || [];
    const ph = (prevSeries[0] && prevSeries[0].hours) || null;
    const none = series[0].visitors === null;
    points = Array.from({ length: 24 }, (_, i) => ({ x: `${String(i).padStart(2, '0')}:00`,
      visitors: h[i] ? h[i][0] : (none ? null : 0), pageviews: h[i] ? h[i][1] : (none ? null : 0), before: ph ? (ph[i] ? ph[i][0] : 0) : null }));
  } else if (days.length > 90) {
    const m = new Map();
    series.forEach((s, i) => {
      const k = s.x.slice(0, 7);
      const acc = m.get(k) || { x: k, visitors: null, pageviews: null, before: null };
      if (s.visitors !== null) { acc.visitors = (acc.visitors || 0) + s.visitors; acc.pageviews = (acc.pageviews || 0) + s.pageviews; }
      const b = prevSeries[i] && prevSeries[i].visitors;
      if (b !== null && b !== undefined) acc.before = (acc.before || 0) + b;
      m.set(k, acc);
    });
    points = [...m.values()];
  }
  // A page's own trend, in the chart's buckets (none for a single day).
  const bucketOf = days.length > 90 ? (d) => d.slice(0, 7) : (d) => d;
  const buckets = days.length === 1 ? [] : [...new Set(days.map(bucketOf))];

  const report = (n) => {
    const dimsOut = {};
    for (const [dim, s] of Object.entries(sums)) {
      const before = prevSums[dim];
      dimsOut[dim] = [...s.entries()].sort((a, b) => b[1][0] - a[1][0] || b[1][2] - a[1][2] || b[1][5] - a[1][5]).slice(0, n)
        // [value, its numbers, its visitors in the period before — null when that period has no breakdowns to compare]
        .map(([k, v]) => [k, v, prevWithData ? ((before && before.get(k)) || 0) : null]);
    }
    const spark = {};
    if (buckets.length) {
      for (const [k] of (dimsOut.page || []).slice(0, Math.min(n, 25))) {
        const by = new Map(buckets.map((b) => [b, 0]));
        for (const [day, m] of pageDays) by.set(bucketOf(day), by.get(bucketOf(day)) + (m.get(k) || 0));
        spark[k] = [...by.values()];
      }
    }
    const vitals = Object.entries(vit).map(([p, v]) => [p, q75(v.lcp), q75(v.inp), q75(v.cls), q75(v.ttfb), Math.max(v.lcp.length, v.ttfb.length)])
      .sort((a, b) => b[5] - a[5]).slice(0, n);
    const usedTitles = {};
    for (const [p] of (dimsOut.page || []).concat(dimsOut.entry || [], dimsOut.exit || [])) if (titles[p]) usedTitles[p] = titles[p];
    return { period, from: days[0], to: days[days.length - 1], days: days.length, days_with_data: withData, totals, prev, series: points, dims: dimsOut, spark, vitals, titles: usedTitles };
  };
  for (const n of [top, 30, 20, 10, 5]) {
    const text = JSON.stringify(report(n));
    if (text.length < ROW_BYTES) return text;
  }
  return JSON.stringify(Object.assign(report(0), { cut: true }));
}

function periodDays(period, today) {
  const n = PERIODS[period];
  const end = period === 'yesterday' ? addDays(today, -1) : today;
  const days = Array.from({ length: n }, (_, i) => addDays(end, i - n + 1));
  const prevDays = Array.from({ length: n }, (_, i) => addDays(days[0], i - n));
  return { days, prevDays };
}

// ── a site ────────────────────────────────────────────────────────────────
const EVENT_COLS = 'kind, page_id, path, title, ref, utm_source, utm_medium, utm_campaign, utm_content, utm_term, lang, site_lang, tz, vw, name, props, time_ms, scroll, lcp, inp, cls, ttfb, anon, ua, browser, os, device, at';

function rollSite(site, { now = new Date(), dryRun = false } = {}) {
  const tz = validZone(site.timezone || 'UTC');
  const today = localDay(now, tz);
  const maxId = (L.one('SELECT MAX(_id) AS m FROM analytics_events WHERE site = ? AND _deleted = 0', site.key) || {}).m || 0;
  const since = Number(site.last_event_id) || 0;
  const days = new Set([today, addDays(today, -1)]);
  const hoursSeen = site.rolled_at
    ? L.all('SELECT DISTINCT substr(at, 1, 13) AS h FROM analytics_events WHERE site = ? AND _deleted = 0 AND _id > ?', site.key, since)
    : L.all('SELECT DISTINCT substr(at, 1, 13) AS h FROM analytics_events WHERE site = ? AND _deleted = 0', site.key);
  for (const { h } of hoursSeen) {
    // an hour in UTC can straddle two local days; look at both of its ends
    for (const min of ['00', '59']) {
      const d = new Date(`${h}:${min}:00Z`);
      if (!Number.isNaN(d.getTime())) days.add(localDay(d, tz));
    }
  }

  // 1. the days
  const have = new Map(L.all('SELECT _id, day FROM analytics_daily WHERE site = ? AND _deleted = 0', site.key).map((r) => [r.day, r._id]));
  const ops = [];
  const built = {};
  for (const day of [...days].sort()) {
    if (day > today) continue;
    const from = iso(dayStart(day, tz));
    const to = iso(dayStart(addDays(day, 1), tz));
    const rows = L.all(`SELECT ${EVENT_COLS} FROM analytics_events WHERE site = ? AND _deleted = 0 AND at >= ? AND at < ?`, site.key, from, to);
    if (!rows.length && !have.has(day)) continue; // nothing ever happened that day: no row
    const { totals, data } = buildDay(rows, { tz, exclude: site.exclude });
    const row = Object.assign({ site: site.key, day, data: fitDay(data), built_at: iso(now) }, totals);
    built[day] = row;
    ops.push(have.has(day) ? { op: 'update', table: 'analytics_daily', id: have.get(day), data: row } : { op: 'insert', table: 'analytics_daily', data: row });
  }

  // 2. the periods
  const oldest = addDays(today, -730);
  const daily = {};
  const cur12 = addDays(today, -365);
  for (const r of L.all('SELECT day, visitors, visits, pageviews, bounces, duration_s, events, CASE WHEN day > ? THEN data END AS data FROM analytics_daily WHERE site = ? AND _deleted = 0 AND day >= ?', cur12, site.key, oldest)) {
    daily[r.day] = r;
  }
  Object.assign(daily, built);
  const haveReports = new Map(L.all('SELECT _id, period FROM analytics_reports WHERE site = ? AND _deleted = 0', site.key).map((r) => [r.period, r._id]));
  for (const period of Object.keys(PERIODS)) {
    const { days: pd, prevDays } = periodDays(period, today);
    const row = { site: site.key, period, from_day: pd[0], to_day: pd[pd.length - 1], data: buildReport(period, pd, prevDays, daily), built_at: iso(now) };
    ops.push(haveReports.has(period) ? { op: 'update', table: 'analytics_reports', id: haveReports.get(period), data: row } : { op: 'insert', table: 'analytics_reports', data: row });
  }

  const lastHit = (L.one('SELECT MAX(at) AS m FROM analytics_events WHERE site = ? AND _deleted = 0', site.key) || {}).m || site.last_hit_at || null;
  const daysBuilt = Object.keys(built).sort();
  const note = `${daysBuilt.length} day(s) rebuilt; ${Object.values(built).reduce((n, r) => n + r.pageviews, 0)} page views in them`;
  ops.push({ op: 'update', table: 'analytics_sites', id: site._id, data: { rolled_at: L.sqlNow(now), last_event_id: maxId, last_hit_at: lastHit, rollup_note: note } });
  if (!dryRun) L.write(ops);
  return { site: site.key, timezone: tz, days: daysBuilt, writes: ops.length, note };
}

// ── pruning ───────────────────────────────────────────────────────────────
function prune(sites, { now = new Date(), dryRun = false } = {}) {
  const cut = new Date(now.getTime() - RETAIN_DAYS * 86400000).toISOString();
  const known = sites.map((s) => s.key).filter((k) => /^[a-z0-9_-]+$/i.test(k));
  const old = (L.one('SELECT COUNT(*) AS n FROM analytics_events WHERE at < ?', cut) || {}).n || 0;
  // rows for a site nobody has (a typo in a snippet, or junk): at this monthly prune, any older than a day
  // (never reported meanwhile: the rollup reads by site key)
  const dayAgo = new Date(now.getTime() - 86400000).toISOString();
  const strangers = known.length
    ? (L.one(`SELECT COUNT(*) AS n FROM analytics_events WHERE at < ? AND site NOT IN (${known.map(() => '?').join(',')})`, dayAgo, ...known) || {}).n || 0
    : 0;
  if (dryRun || (!old && !strangers)) return { old, strangers, deleted: 0, dryRun };
  let deleted = 0;
  const safeIso = (s) => (/^\d{4}-\d\d-\d\dT\d\d:\d\d:\d\d\.\d{3}Z$/.test(s) ? s : null);
  if (old && safeIso(cut)) deleted += L.hardDelete('analytics_events', `at < '${cut}'`);
  if (strangers && safeIso(dayAgo)) deleted += L.hardDelete('analytics_events', `at < '${dayAgo}' AND site NOT IN (${known.map((k) => `'${k}'`).join(',')})`);
  return { old, strangers, deleted };
}

// ── the raw user agent, out ───────────────────────────────────────────────
const SCRUB_BATCH = 20000;
/**
 * Rows from before 0.2.2 (or written by an old `hit` declaration in the
 * minutes before the installer re-declared it) still hold the raw user agent:
 * replace it with its families (browser 'Bot' for a bot's) and blank it.
 * Bounded per run; another run picks up what is left.
 */
function scrubUa({ dryRun = false, limit = SCRUB_BATCH } = {}) {
  const rows = L.all("SELECT _id, ua, vw FROM analytics_events WHERE _deleted = 0 AND ua IS NOT NULL AND ua <> '' ORDER BY _id LIMIT ?", limit);
  const deleted = (L.one("SELECT COUNT(*) AS n FROM analytics_events WHERE _deleted = 1 AND ua IS NOT NULL AND ua <> ''") || {}).n || 0;
  if (dryRun) return { scrubbed: 0, would: rows.length, deleted, dryRun };
  if (rows.length) {
    L.write(rows.map((r) => {
      const f = C.familiesOf(r);
      return { op: 'update', table: 'analytics_events', id: r._id, data: { browser: f.bot ? 'Bot' : f.browser, os: f.os, device: f.device, ua: null } };
    }));
  }
  // A soft-deleted row is never read again; with a user agent in it, it goes for good.
  if (deleted) L.hardDelete('analytics_events', "_deleted = 1 AND ua IS NOT NULL AND ua <> ''");
  const left = (L.one("SELECT COUNT(*) AS n FROM analytics_events WHERE ua IS NOT NULL AND ua <> ''") || {}).n || 0;
  return { scrubbed: rows.length, deleted, left };
}

// ── run ───────────────────────────────────────────────────────────────────
function main(argv) {
  const dryRun = argv.includes('--dry-run');
  const only = argv.find((a) => !a.startsWith('--'));
  const held = dryRun ? { release() {} } : L.lock('rollup');
  if (!held) return L.done({ ok: true, skipped: 'another run is building the reports' });
  try {
    if (argv.includes('--scrub-ua')) {
      let r = scrubUa({ dryRun });
      for (let i = 0; i < 50 && !dryRun && r.left && r.scrubbed; i += 1) r = scrubUa();
      return L.done(Object.assign({ ok: !r.left || dryRun }, r));
    }
    let scrub = null;
    try { scrub = scrubUa({ dryRun }); } catch (e) { scrub = { error: String(e.message).slice(0, 200) }; }
    const all = L.all("SELECT * FROM analytics_sites WHERE _deleted = 0 ORDER BY _id");
    const sites = all.filter((s) => s.status === 'Active' && (!only || only === s.key));
    const now = new Date();
    const results = [];
    for (const s of sites) {
      try { results.push(rollSite(s, { now, dryRun })); } catch (e) { results.push({ site: s.key, error: String(e.message).slice(0, 300) }); }
    }
    let pruned = null;
    const monthly = now.getUTCDate() === 1 && now.getUTCHours() < 2;
    if (argv.includes('--prune') || monthly) pruned = prune(all, { now, dryRun });
    const failed = results.filter((r) => r.error);
    L.done({ ok: !failed.length, mode: argv.includes('--now') ? 'now' : 'auto', sites: results, pruned,
      scrub: scrub && (scrub.scrubbed || scrub.would || scrub.error) ? scrub : undefined, dryRun: dryRun || undefined });
    if (failed.length) process.exitCode = 1;
  } finally {
    held.release();
  }
}

if (require.main === module) main(process.argv.slice(2));

module.exports = { buildDay, buildReport, periodDays, rollSite, prune, scrubUa, localDay, dayStart, addDays, fitDay, N, PERIODS };
