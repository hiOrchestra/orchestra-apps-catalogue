---
name: app-analytics
version: 0.2.1
description: >-
  Read and run the Analytics app (cookieless website analytics, a Google
  Analytics replacement): how many people visited, top pages, where visits come
  from, comparing periods, adding a website and giving its tracking line,
  checking the tracker is receiving visits. Use for "how many visits this week /
  cuántas visitas tuvimos esta semana", "top pages / páginas más vistas", "where
  does traffic come from / de dónde vienen las visitas", "compare with last month
  / compara con el mes pasado", "add my website / añade mi web", "the tracking
  code / el código de seguimiento", "is analytics working / ¿está llegando
  tráfico?". Needs the Analytics app installed in a project you work in.
metadata:
  openclaw:
    emoji: "📈"
---
# Analytics — website visits, without cookies

A small script on a website sends its visits to this instance; every hour the
app turns them into reports per site and period. No cookies, no IP kept.

## Is it installed

```bash
ls -d ~/.openclaw/orchestra/projects/*/apps/analytics       # the project is the folder name under projects/
P=<project>; D=~/.openclaw/orchestra/projects/$P/apps/analytics
cat $D/workflows.json                                        # {"rollup": "<id>", "sites": "<id>"}
orch-canvas url analytics                                    # the desk, for the person
```

If nothing is there, Analytics is not installed in a project you work in: say
so, and do not count visits some other way.

## The model

| Table | One row per | Written by |
|---|---|---|
| `analytics_sites` | website: `key` (in the tracking line, unique), `name`, `origins` (comma-separated addresses allowed to send), `timezone` (where a day starts), `exclude` (paths not counted, one per line, `*` at the end for everything under), `status`, and rollup bookkeeping (`rolled_at`, `last_event_id`, `last_hit_at`, `rollup_note`) | the desk; the rollup writes the bookkeeping |
| `analytics_events` | raw hit from the tracker: `kind` (`pageview`, `leave`, `event`), `path`, `title`, `ref`, `utm_*`, `tz`, `vw`, `name`/`props` for events, timing and page speed, `anon` (a daily visitor hash), `ua`, `at` (UTC ISO) | only the public action `hit` |
| `analytics_daily` | site × day: `visitors`, `visits`, `pageviews`, `bounces`, `duration_s`, `events`, and `data` (every breakdown as JSON) | `rollup.js` |
| `analytics_reports` | site × `period` (`today`, `yesterday`, `7d`, `30d`, `90d`, `12m`): `from_day`, `to_day`, `data`, `built_at` | `rollup.js` |
| `analytics_settings` | the install: Getting started's state | the desk |

Site `status`: `Active` (counted and rolled up), `Removed` (its addresses are
taken off the allowed list, so visits are refused; its reports stay; adding the
same address again sets it back to `Active`). `Paused` exists in the docs but
nothing in the app sets it; the rollup skips anything not `Active`.

How things are counted (as Plausible/Umami do): a visitor is the `anon` hash,
which changes every UTC day, so one person on two days is two visitors; a visit
ends after 30 minutes without activity; a bounce is a one-page visit with no
click that leads anywhere. Bots (by user agent) and excluded paths are dropped
at rollup. The country comes from the browser's time zone: close, not exact.

Raw events vs rollups: the desk and you read the rollups. They are rebuilt
hourly (minute 7, UTC) only for a site with new visits or when a day turned,
so they can be up to an hour behind. Live (last 30 minutes) reads raw events.
Retention: raw events older than 90 days are hard-deleted on the 1st of each
month; daily rows keep their numbers, but a day older than that can never be
rebuilt (a changed time zone or exclusion only applies to days still in raw).

A report's `data` JSON: `totals` and `prev` (the period before), each with
`visitors, visits, pageviews, bounces, duration_s, events`; `days_with_data`;
`series`; and `dims.<name>` = top 50 of `[value, n, visitors_before]`, where
`n[0]` visitors, `n[1]` visits, `n[2]` pageviews, `n[3]` bounces, `n[4]` seconds,
`n[5]` events, `n[10]` entries, `n[11]` exits (for `page` use `n[0]` and `n[2]`).
Dims: `page`, `entry`, `exit`, `channel` (Direct, Organic search, AI assistants,
Social, Email, Paid, Referral, Campaigns), `source`, `referrer`, `utm_source`,
`utm_medium`, `utm_campaign`, `utm_content`, `utm_term`, `country`, `device`,
`browser`, `os`, `screen`, `lang`, `site_lang`, `event`, `event_detail`.
Bounce rate = bounces / visits; average visit = duration_s / visits.

## How you act

- Read with `orch-database --project $P query "SELECT …"` (always `_deleted = 0`).
- Fresh numbers: run the rollup first, `node $D/automations/rollup.js --now <key or --all>`
  (or `orch-workflows run <rollup id> --args '{"mode":"--now","key":"--all"}'`).
  It prints one JSON line; `skipped` means a run is already building.
- Never pass `--prune` to `rollup.js`: it hard-deletes raw visits.
- The only raw write you may make is adding a site (recipe below), mirroring the
  desk's `add_site`. Name, time zone and exclusions are edited by the person on
  the desk's Sites screen. Removing a site is the person's call, on Sites.
- You cannot make the `visits` app Public, publish an app or approve tables:
  the person does that in Canvas.

## Recipes

Visits this week (the last 7 days, today included):
```bash
orch-database --project $P query "SELECT s.name, r.from_day, r.to_day, r.built_at, json_extract(r.data,'\$.totals') AS now, json_extract(r.data,'\$.prev') AS before FROM analytics_reports r JOIN analytics_sites s ON s.key = r.site AND s._deleted = 0 WHERE r._deleted = 0 AND r.period = '7d' AND s.status = 'Active'"
```
Say the period's dates. For a calendar week, sum the days instead (next recipe).

Compare periods: each report already has `prev`. For any two ranges:
```bash
orch-database --project $P query "SELECT SUM(visitors) visitors, SUM(visits) visits, SUM(pageviews) pageviews, SUM(bounces) bounces, SUM(duration_s) duration_s FROM analytics_daily WHERE _deleted = 0 AND site = '<key>' AND day BETWEEN '2026-09-01' AND '2026-09-30'"
```
Days are in the site's own time zone. Summed visitors match how the app counts.

Top pages / top sources: read one breakdown of a period's report.
```bash
orch-database --project $P query "SELECT json_extract(data,'\$.dims.page') FROM analytics_reports WHERE _deleted = 0 AND site = '<key>' AND period = '30d'"
```
Use `dims.channel`, `dims.source`, `dims.referrer` or `dims.utm_campaign` for
where visits come from. Lists are already sorted by visitors; name the top 5–10
with visitors and the change against `visitors_before`.

Add a website (only when the person asks, with its address):
1. Turn the address into the host the way the desk does: lowercase, drop
   `https://` and a trailing `/`; refuse paths, ports, IPs, names without a dot.
   Bare host = host without `www.`. Key = bare host with every run of non
   `a-z0-9` replaced by `-` (`shop.example.com` → `shop-example-com`, max 40).
2. Check it is new and the cap: at most 10 sites not `Removed`.
   `orch-database --project $P query "SELECT _id, key, status FROM analytics_sites WHERE _deleted = 0"`.
   If the key exists as `Removed`, set it back instead:
   `orch-database --project $P update analytics_sites --id <id> --data '{"status":"Active"}'`.
3. Otherwise insert, with the desk's defaults:
   `orch-database --project $P insert analytics_sites --data '{"key":"example-com","name":"example.com","origins":"https://example.com,https://www.example.com","timezone":"Europe/Madrid","status":"Active","exclude":"","last_event_id":0}'`
   (time zone: ask, or use the person's).
4. Let its addresses in: `orch-workflows run <sites id>` (a raw insert does not
   trigger it the way the desk does). Check the run with `orch-workflows status <run>`.
5. Give the tracking line, to paste inside `<head>` on every page:
   `<script defer src="<url>t.js" data-site="<key>"></script>`, where `<url>` is the
   `url` that `orch-canvas url visits` prints (it ends in `/canvas/a/visits/`).
   The Sites screen shows the same line ready to copy.

Is the tracker receiving data:
```bash
orch-database --project $P query "SELECT site, kind, COUNT(*) n, MAX(at) last FROM analytics_events WHERE _deleted = 0 AND at >= strftime('%Y-%m-%dT%H:%M:%SZ','now','-1 day') GROUP BY site, kind"
orch-canvas action list visits     # `hit` must name the site's origins; access must be public
```
Nothing arriving, in order: the line is on the pages with the right `data-site`;
`visits` is Public and published (ask the person); the site's address is in
`hit`'s origins (if not, run the sites workflow); visits from localhost are never
sent; a browser opened once with `#orch-analytics=off` is not counted. Rows with
an unknown key are not reported and are deleted later.

## Connections

No other Orchestra app reads or writes Analytics today, and none of their
public pages carries the tracking line. Linking a visit to a CRM contact or a
form answer is not possible: nothing personal is kept.

## Never

- Delete or edit rows in `analytics_events`, `analytics_daily` or `analytics_reports`, or run `rollup.js --prune`.
- Remove a site, or change another site's `origins`, without the person's explicit OK naming the site.
- Promise numbers newer than the report's `built_at` without running the rollup.
- Call a period "this week" or "this month" without saying its dates.
- Say who a visitor is: the app cannot know, by design.
