// Each website: the line to paste into its pages, whether visits are
// arriving, and its settings (name, time zone, pages not to count). Which
// sites may send visits at all is decided where the app is installed — a
// browser on any other site is refused.
import { A, act, allSites, ago, trackerSrc } from '../data.js';

const { el } = Orch;
const ZONES = ['UTC', 'Europe/Madrid', 'Europe/London', 'Europe/Lisbon', 'Europe/Paris', 'Europe/Berlin', 'America/New_York', 'America/Chicago',
  'America/Denver', 'America/Los_Angeles', 'America/Mexico_City', 'America/Bogota', 'America/Lima', 'America/Santiago',
  'America/Argentina/Buenos_Aires', 'America/Sao_Paulo', 'Asia/Dubai', 'Asia/Kolkata', 'Asia/Singapore', 'Asia/Tokyo', 'Australia/Sydney'];

export function render() {
  Orch.load('view', async () => {
    const list = await allSites();
    return el('div', { class: 'oc-stack oc-stack--loose an-sites' }, [
      el('div', { class: 'an-head__title' }, [el('h1', { class: 'oc-h1 oc-h1--collection' }, 'Sites'),
        el('p', { class: 'oc-lede' }, 'The websites Analytics counts, the line each one needs, and how its reports are built.')]),
      ...(list.length ? list.map(site) : [el('div', { class: 'oc-card oc-state' }, el('p', { class: 'oc-state__title' }, 'No website is set up yet.'))]),
      el('section', { class: 'oc-card' }, [
        el('h2', { class: 'oc-h2' }, 'Counting another website'),
        el('p', { class: 'oc-help', style: { margin: '6px 0 0' } }, 'Ask your agent to add it to Analytics. Only websites on that list can send visits here: a page anywhere else that copies the line is refused.'),
      ]),
    ]);
  });
}

function site(s) {
  const line = `<script defer src="${trackerSrc()}" data-site="${s.key}" data-exclude="${String(s.exclude || '').split(/\n+/).map((x) => x.trim()).filter(Boolean).join(',')}"></script>`;
  const copy = el('button', { class: 'oc-btn oc-btn--sm', type: 'button' }, 'Copy');
  copy.addEventListener('click', async () => {
    try { await navigator.clipboard.writeText(line); Orch.toast('Copied: paste it inside <head> on every page.'); } catch { Orch.toast('Select the line and copy it.', { error: true }); }
  });
  const origins = String(s.origins || '').split(/[\s,]+/).filter(Boolean);
  const arriving = s.last_hit_at ? `Last visit ${ago(s.last_hit_at)}` : 'No visits have arrived yet';
  return el('section', { class: 'oc-card an-site-card' }, [
    el('div', { class: 'an-site-card__head' }, [
      el('div', {}, [el('h2', { class: 'oc-h1', style: { fontSize: '26px' } }, s.name || s.key), el('p', { class: 'oc-eyebrow' }, origins.join(' · ') || 'No address set')]),
      el('span', { class: `oc-badge ${s.last_hit_at ? 'oc-badge--good' : 'oc-badge--warn'}` }, arriving),
    ]),
    el('div', { class: 'an-field' }, [
      el('span', { class: 'oc-eyebrow' }, 'The line for its pages'),
      el('p', { class: 'oc-help' }, 'Paste it inside <head> on every page you want counted. It sets no cookies and needs no consent banner of its own.'),
      el('div', { class: 'an-code' }, [el('code', line), copy]),
    ]),
    el('div', { class: 'an-field' }, [
      el('span', { class: 'oc-eyebrow' }, 'Your own visits'),
      el('p', { class: 'oc-help' }, [
        'To stop counting yourself, open the site once in each browser you use with ',
        el('code', '#orch-analytics=off'), ' at the end of the address',
        origins[0] ? [' — ', el('a', { href: `${origins[0]}/#orch-analytics=off`, target: '_blank', rel: 'noopener' }, 'like this'), ''] : '',
        '. Open it with ', el('code', '#orch-analytics=on'), ' to be counted again.',
      ]),
    ]),
    settings(s),
    el('p', { class: 'oc-eyebrow' }, `Reports built ${ago(s.rolled_at)}${s.rollup_note ? ` · ${s.rollup_note}` : ''}`),
  ]);
}

function settings(s) {
  const name = el('input', { class: 'oc-input', value: s.name || '', maxlength: '80' });
  const tz = el('select', { class: 'oc-select' }, [...new Set([s.timezone || 'UTC', ...ZONES])].map((z) => el('option', { value: z, selected: z === (s.timezone || 'UTC') }, z)));
  const exclude = el('textarea', { class: 'oc-textarea', rows: '4' }, s.exclude || '');
  const save = el('button', { class: 'oc-btn oc-btn--primary', type: 'submit' }, 'Save');
  const form = el('form', { class: 'an-form' }, [
    el('label', { class: 'oc-field' }, [el('span', { class: 'oc-label' }, 'Name'), name]),
    el('label', { class: 'oc-field' }, [el('span', { class: 'oc-label' }, 'Time zone'), tz,
      el('span', { class: 'oc-help' }, 'Where a day begins and ends in the reports.')]),
    el('label', { class: 'oc-field' }, [el('span', { class: 'oc-label' }, 'Pages not to count'), exclude,
      el('span', { class: 'oc-help' }, 'One per line. End with * for everything under it: /portal/* skips every page under /portal/. Applies to reports built from now on; update the line on the site too, so those visits are not even sent.')]),
    el('div', { class: 'oc-row' }, save),
  ]);
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    save.disabled = true;
    const ok = await act(A.updateSite, { id: s._id, name: name.value.trim() || s.key, timezone: tz.value, exclude: exclude.value.trim() }, 'Saved. The reports use it from their next build.');
    save.disabled = false;
    if (ok) render();
  });
  return el('details', { class: 'an-settings' }, [el('summary', {}, 'Settings'), form]);
}
