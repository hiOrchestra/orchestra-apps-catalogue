// What Analytics reads, the only things it writes, and what the screens share.
// The reports are built on the instance (automations/rollup.js) into one row
// per site and period, so a screen reads one row and draws it. Live reads the
// raw visits of the last 30 minutes. Every write is a declared action (A).
const { el, fmt } = Orch;

export const T = { sites: 'analytics_sites', events: 'analytics_events', reports: 'analytics_reports' };
export const A = { refresh: 'refresh_now', updateSite: 'update_site' };

export const PERIODS = [
  ['today', 'Today', 'yesterday'], ['yesterday', 'Yesterday', 'the day before'], ['7d', '7 days', 'the 7 days before'],
  ['30d', '30 days', 'the 30 days before'], ['90d', '90 days', 'the 90 days before'], ['12m', '12 months', 'the 12 months before'],
];
export const DEFAULT_PERIOD = '30d';

/** Run a declared action, say how it went, and hand back its result (null on failure). */
export async function act(name, params, done) {
  try {
    const r = await Orch.action(name, params);
    if (done) Orch.toast(done);
    return r || {};
  } catch (e) {
    Orch.toast(e.status === 409 ? 'It changed in the meantime: look again.' : (e.message || 'That did not work.'), { error: true });
    return null;
  }
}

/** Every site, oldest first. */
export async function allSites() {
  return (await Orch.db.list(T.sites, { sort: '_id:asc', limit: 50 })).rows || [];
}

/** The site this screen is about: ?site=<key>, else the one remembered, else the first. */
export function chosenSite(list, path) {
  const q = new URLSearchParams(String(path || '').split('?')[1] || '');
  const want = q.get('site') || remembered();
  return list.find((s) => s.key === want) || list[0] || null;
}
function remembered() { try { return localStorage.getItem('analytics.site'); } catch { return null; } }
export function remember(key) { try { localStorage.setItem('analytics.site', key); } catch { /* not kept */ } }

/** One report row's data, or null while it was never built. */
export async function report(site, period) {
  const r = await Orch.db.list(T.reports, { filter: { site, period }, limit: 1 });
  const row = (r.rows || [])[0];
  if (!row) return null;
  try { return Object.assign(JSON.parse(row.data), { built_at: row.built_at }); } catch { return null; }
}

// ── numbers, as people read them ────────────────────────────────────────
export const num = (n) => fmt.number(Math.round(Number(n) || 0));
export const pct = (part, whole) => (whole ? `${Math.round((part / whole) * 100)}%` : '—');
export function duration(s) {
  const v = Math.round(Number(s) || 0);
  if (!v) return '0s';
  if (v < 60) return `${v}s`;
  const m = Math.floor(v / 60);
  return m < 60 ? `${m}m ${String(v % 60).padStart(2, '0')}s` : `${Math.floor(m / 60)}h ${String(m % 60).padStart(2, '0')}m`;
}
export const ms = (v) => (v === null || v === undefined ? '—' : v < 1000 ? `${Math.round(v)} ms` : `${(v / 1000).toFixed(1)} s`);

/**
 * The change against the period before, said in mono beside the number:
 * "+16% vs 541". `better` says which way is good (a bounce rate going down);
 * colour only when the change is large enough to mean something.
 */
export function delta(now, before, better = 'up', said) {
  if (before === null || before === undefined || !Number.isFinite(before) || before === 0) {
    return el('span', { class: 'oc-kpi__delta' }, now ? 'no earlier data' : '');
  }
  const r = Math.round(((now - before) / Math.abs(before)) * 100);
  const vs = said ? ` vs ${said}` : '';
  if (r === 0) return el('span', { class: 'oc-kpi__delta' }, `same as before${vs}`);
  return el('span', { class: 'oc-kpi__delta' }, `${r > 0 ? '+' : '−'}${Math.abs(r)}%${vs}`);
}

/** A row's change, short: "+12%", "−6%", "new", or "" when nothing to compare. */
export function change(now, before) {
  if (before === null || before === undefined) return '';
  if (!before) return now ? 'new' : '';
  const r = Math.round(((now - before) / before) * 100);
  return r === 0 ? '0%' : `${r > 0 ? '+' : '−'}${Math.abs(r)}%`;
}

/** The host of a site's first origin, as its page title names it. */
export const hostOf = (site) => String(site.origins || '').split(/[\s,]+/).filter(Boolean)[0]?.replace(/^https?:\/\//, '') || site.name || site.key;

/** How many different visitors in the last five minutes (a live state, so gold). */
export async function liveNow(site) {
  try {
    const since = new Date(Date.now() - 5 * 60000).toISOString();
    const r = await Orch.db.count(T.events, { filter: { site: site.key, at: { gte: since } }, group: 'anon' });
    return (r.groups || []).length;
  } catch { return 0; }
}

/** '2026-10-03 10:00:00' (UTC, as rows are stamped) or ISO, as "12 minutes ago". */
export const ago = (v) => (v ? fmt.ago(String(v).includes('T') ? v : `${String(v).replace(' ', 'T')}Z`) : 'never');

/** The address visits are sent to and the tracker is served from: this instance. */
export function trackerSrc() {
  return `${location.origin}${location.pathname.replace(/\/canvas\/a\/[^/]+\/?.*$/, '/canvas/a/visits/t.js')}`;
}
