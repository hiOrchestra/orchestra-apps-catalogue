// Analytics, installed into one project of this instance: tables and indexes,
// the first site (only into an empty table), the script and its workflow with
// the hourly run, the desk `analytics` and the public `visits` (the tracker
// and the action websites send visits to) with their grants, actions, brand
// and brief. Converges: run it again after a change and it ends in the same
// state. Prints one JSON line per step, and at the end what a person still
// has to do.
//
//   as node, by the team over ssh:  gosu node node install.js <bundle> --project default --agent dario
//   another site:                   … --site key=docs,name=Docs,origin=https://docs.example.com,tz=Europe/Madrid
//   parts (the MCP's 120 s a call): --only files,tables,seed · --only workflows,schedule · --only desk · --only public
//
// Which websites may send visits is the public action's `origins`: every
// site's origins, read back from analytics_sites each time this runs. Adding a
// site means running it again (--site), which re-declares the action.
'use strict';
const { execFileSync } = require('child_process');
const fs = require('fs');
const path = require('path');

const B = path.resolve(process.argv[2] || __dirname);
const flag = (name, fallback) => { const i = process.argv.indexOf(`--${name}`); return i > 0 && process.argv[i + 1] ? process.argv[i + 1] : fallback; };
const flags = (name) => process.argv.flatMap((a, i) => (a === `--${name}` && process.argv[i + 1] ? [process.argv[i + 1]] : []));
const PROJECT = flag('project', 'default');
const AGENT = flag('agent', '');
const ONLY = new Set((flag('only', 'files,tables,seed,workflows,schedule,desk,public')).split(','));
const STATE = process.env.OPENCLAW_STATE_DIR || '/home/node/.openclaw';
const HOME = path.join(STATE, 'orchestra', 'projects', PROJECT);
const AUTO = path.join(HOME, 'apps', 'analytics', 'automations');
const read = (f) => fs.readFileSync(path.join(B, f), 'utf8');
const json = (f) => JSON.parse(read(f));
const todo = [];
const out = (step, data) => console.log(JSON.stringify(Object.assign({ step }, data)));

function cli(bin, args, { soft = false } = {}) {
  let text;
  try {
    text = execFileSync(bin, args, { encoding: 'utf8', timeout: 100000, maxBuffer: 32 << 20 });
  } catch (e) {
    text = String(e.stdout || '') || String(e.stderr || e.message);
    if (!soft) out('warn', { bin, args: args.slice(0, 3), said: text.trim().slice(0, 300) });
  }
  try { return JSON.parse(text); } catch { return { raw: String(text).trim().slice(0, 600) }; }
}
const db = (...a) => cli('orch-database', ['--project', PROJECT, ...a]);
const canvas = (...a) => cli('orch-canvas', a);
const wf = (...a) => cli('orch-workflows', a);
const pick = (o, keys) => Object.fromEntries(keys.filter((k) => o && o[k] !== undefined).map((k) => [k, o[k]]));
const ids = () => { try { return JSON.parse(fs.readFileSync(path.join(AUTO, '..', 'workflows.json'), 'utf8')); } catch { return {}; } };
const ORIGIN = /^https?:\/\/[a-z0-9.-]+(:\d{1,5})?$/i;

// ── 1. the script ────────────────────────────────────────────────────────
if (ONLY.has('files')) {
  fs.mkdirSync(AUTO, { recursive: true });
  for (const f of fs.readdirSync(path.join(B, 'automations'))) fs.copyFileSync(path.join(B, 'automations', f), path.join(AUTO, f));
  out('files', { dir: AUTO, files: fs.readdirSync(AUTO) });
}

// ── 2. tables and indexes ────────────────────────────────────────────────
const schema = json('schema.json');
if (ONLY.has('tables')) {
  for (const [table, cols] of Object.entries(schema.tables)) {
    out('table', Object.assign({ table }, pick(db('ensure-table', table, '--columns', ...cols), ['ok', 'action', 'created', 'added', 'error', 'raw'])));
  }
  for (const sql of schema.indexes) out('index', Object.assign({ sql: sql.slice(0, 80) }, pick(db('sql', sql, '--confirm'), ['ok', 'error', 'raw'])));
}

// ── 3. the sites: the seed into an empty table, and any --site ───────────
if (ONLY.has('seed')) {
  const rows = (db('query', 'SELECT _id, key FROM analytics_sites WHERE _deleted = 0').rows) || [];
  if (!rows.length) {
    out('seed', Object.assign({ table: 'analytics_sites' }, pick(db('insert-many', 'analytics_sites', '--data', JSON.stringify(json('seed.json').analytics_sites)), ['ok', 'count', 'error', 'raw'])));
  } else out('seed', { table: 'analytics_sites', left: 'it has rows' });
  for (const spec of flags('site')) {
    const s = Object.fromEntries(spec.split(',').map((kv) => kv.split('=').map((x) => x.trim())));
    if (!/^[a-z0-9_-]{1,40}$/.test(s.key || '') || !ORIGIN.test(s.origin || '')) { out('site', { refused: spec, why: 'key=<a-z0-9_-> and origin=https://host are required' }); continue; }
    const have = ((db('query', `SELECT _id FROM analytics_sites WHERE _deleted = 0 AND key = '${s.key}'`).rows) || [])[0];
    const data = { key: s.key, name: s.name || s.key, origins: s.origin.toLowerCase(), timezone: s.tz || 'UTC', status: 'Active' };
    if (!have) data.exclude = s.exclude || '';
    out('site', Object.assign({ key: s.key, did: have ? 'updated' : 'added' }, pick(have ? db('update', 'analytics_sites', '--id', String(have._id), '--data', JSON.stringify(data)) : db('insert', 'analytics_sites', '--data', JSON.stringify(Object.assign(data, { last_event_id: 0 }))), ['ok', 'error', 'raw'])));
  }
}

// ── 4. the workflow (by name: created once, updated after) ───────────────
if (ONLY.has('workflows')) {
  if (!AGENT) throw new Error('--agent <id> names the project member the reports are built as (the project\'s coordinator)');
  const existing = wf('list').workflows || [];
  const WF = {};
  const tmp = fs.mkdtempSync('/tmp/analytics-wf-');
  for (const key of ['rollup']) {
    const spec = Object.assign(JSON.parse(read(`workflows/${key}.json`).replace(/__AUTO__/g, AUTO)), { project: PROJECT, runsAs: AGENT });
    const file = path.join(tmp, `${key}.json`);
    fs.writeFileSync(file, JSON.stringify(spec));
    const found = existing.find((w) => w.name === spec.name);
    const r = found ? wf('update', found.id, '--file', file) : wf('create', '--file', file);
    WF[key] = found ? found.id : ((r.workflow && r.workflow.id) || r.id || r.workflowId);
    out('workflow', { name: spec.name, id: WF[key], did: found ? 'updated' : 'created', error: r.error || undefined });
  }
  fs.rmSync(tmp, { recursive: true, force: true });
  fs.writeFileSync(path.join(AUTO, '..', 'workflows.json'), JSON.stringify(WF, null, 1));
}

// ── 5. the hourly run: only for a site with new visits, or when a day turned ─
if (ONLY.has('schedule')) {
  const WF = ids();
  for (const s of (wf('schedules', WF.rollup).schedules || [])) out('unschedule', pick(wf('unschedule', s.jobId), ['ok', 'error']));
  out('schedule', pick(wf('schedule', WF.rollup, '--cron', '7 * * * *', '--timezone', 'UTC', '--name', 'Analytics · Build reports (hourly, when there are new visits)',
    '--table', 'analytics_sites', '--where', read('workflows/rollup.where'), '--limit', '20'), ['ok', 'jobId', 'schedule', 'error', 'raw']));
}

// ── 6. the apps ──────────────────────────────────────────────────────────
function app(id, src, brief) {
  let a = (canvas('list').apps || []).find((x) => x.id === id);
  if (!a) {
    out('init', Object.assign({ app: id }, pick(canvas('init', id, '--project', PROJECT, '--pattern', 'dashboard', '--confirmed', ...brief), ['ok', 'dir', 'url', 'error', 'raw'])));
    a = (canvas('list').apps || []).find((x) => x.id === id);
  }
  if (!a) throw new Error(`The app ${id} could not be created`);
  const dir = path.join(STATE, 'orchestra', a.dir);
  const ours = new Set();
  const copy = (from, to) => {
    for (const f of fs.readdirSync(from)) {
      const s = path.join(from, f);
      const d = path.join(to, f);
      if (fs.statSync(s).isDirectory()) { fs.mkdirSync(d, { recursive: true }); copy(s, d); } else { fs.copyFileSync(s, d); ours.add(path.relative(dir, d)); }
    }
  };
  copy(path.join(B, src), dir);
  // What the starter wrote and Analytics does not use goes, so the app is exactly the source.
  const sweep = (d) => {
    for (const f of fs.readdirSync(d)) {
      const p = path.join(d, f);
      const rel = path.relative(dir, p);
      if (rel.startsWith('_') || rel.startsWith('.')) continue;
      if (fs.statSync(p).isDirectory()) sweep(p); else if (!ours.has(rel)) { fs.unlinkSync(p); out('removed', { app: id, file: rel }); }
    }
  };
  sweep(dir);
  out('files', { app: id, dir, count: ours.size });
  return a;
}

function actions(id, list, extra = {}) {
  const WF = ids();
  const sub = (v) => (typeof v === 'string' && v.startsWith('$WF_') ? WF[v.slice(4).toLowerCase()] : v);
  for (const a of list) {
    const args = ['action', 'add', id, '--name', a.name, '--type', a.type, '--access', a.access || 'members'];
    if (a.table) args.push('--table', a.table);
    if (a.fields) args.push('--fields', a.fields.join(','));
    if (a.defaults) args.push('--defaults', JSON.stringify(a.defaults));
    if (a.precondition) args.push('--precondition', JSON.stringify(a.precondition));
    if (a.workflow) args.push('--workflow', sub(a.workflow));
    if (a.args) args.push('--args', JSON.stringify(a.args));
    if (a.origins) args.push('--origins', a.origins === '$SITE_ORIGINS' ? extra.origins : a.origins);
    if (a.limits) args.push('--limits', JSON.stringify(a.limits));
    const r = canvas(...args);
    out('action', Object.assign({ app: id, name: a.name }, pick(r, ['ok', 'error', 'raw']), a.origins ? { origins: extra.origins } : {}));
  }
}

function brand(id, spec) {
  const args = ['brand', 'set', id, '--preset', spec.preset];
  for (const [k, v] of Object.entries(spec.brand || {})) args.push(`--${k}`, v);
  out('brand', Object.assign({ app: id }, pick(canvas(...args), ['ok', 'error', 'raw'])));
}

if (ONLY.has('desk')) {
  app('analytics', 'app', ['--name', 'Analytics', '--icon', '📈', '--desc', 'Visits to your websites, without cookies: how many people come, from where, what they read and do, and how fast the pages are',
    '--user', 'The people who run the company\'s websites and marketing',
    '--frequency', 'A few times a week, and right after a launch or a campaign',
    '--question', 'How many people visit, and is it going up or down?',
    '--question', 'Where do they come from: search, AI assistants, social, campaigns, other sites?',
    '--question', 'What do they read and do: which pages, how long, and do they click to sign up?',
    '--primary-action', 'Read the reports for a period, and compare it with the one before']);
  // One --grant with every table: the flag is nargs="*", so repeating it keeps only the last.
  const g = canvas('grants', 'set', 'analytics', '--grant', 'analytics_sites:action', 'analytics_reports:read', 'analytics_events:read');
  out('grants', Object.assign({ app: 'analytics' }, pick(g, ['ok', 'grants', 'pendingApproval', 'error', 'raw'])));
  if ((g.pendingApproval || []).length) todo.push(`Approve the tables Analytics asks for: ${g.pendingApproval.map((x) => x.table || x).join(', ')} (Canvas → Analytics → who gets in)`);
  actions('analytics', json('actions.json'));
  brand('analytics', json('brand.json').analytics);
  out('brief', pick(canvas('brief', 'set', 'analytics', '--density', 'compact', '--variety', 'focused', '--confirmed'), ['ok', 'error', 'raw']));
  todo.push('Publish Analytics (Canvas → Analytics → Historial)');
}

if (ONLY.has('public')) {
  app('visits', 'public', ['--name', 'Visits', '--icon', '📈', '--desc', 'Serves the tracker websites load and receives their visits. Nobody reads this page.',
    '--user', 'Visitors of the websites Analytics counts, without knowing it is there',
    '--frequency', 'On every page view of those websites',
    '--question', 'What is this address?',
    '--primary-action', 'None: it serves t.js and receives visits']);
  const sites = (db('query', "SELECT origins FROM analytics_sites WHERE _deleted = 0").rows) || [];
  const origins = [...new Set(sites.flatMap((s) => String(s.origins || '').split(/[\s,]+/)).map((o) => o.trim().replace(/\/+$/, '').toLowerCase()).filter((o) => ORIGIN.test(o)))];
  if (!origins.length) throw new Error('No site has an address: add one with --site key=…,origin=https://…');
  actions('visits', json('public-actions.json'), { origins: origins.join(',') });
  brand('visits', json('brand.json').visits);
  todo.push('Set Visits to Public, and publish it (Canvas → Visits): until then the tracker is not served and visits are refused');
}

out('done', { project: PROJECT, a_person_still_has_to: todo });
