// What both screens of the booking page share: the business and its rules
// (two approved public views), the busy times (a third, with no names), the
// language, and the one way a request travels: the public action `request`,
// retried on a busy platform, then `process` (carrying nothing), then the
// answer read back from the client's own sealed link (a fourth view, that
// only the token in this browser can open).
import { WORDS } from './words.js';
import { top } from './ui.js';

const { el } = Orch;
const S = window.AptSched;
const C = window.AptCore;
export const T0 = Date.now();
const WAITS = [3, 6, 12, 20, 30, 30, 30];
const sleep = (ms) => new Promise((r) => { setTimeout(r, ms); });
export const store = {
  get(k, fallback) { try { const v = JSON.parse(localStorage.getItem(k) || 'null'); return v === null ? fallback : v; } catch { return fallback; } },
  set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch { /* private window */ } },
};
export const newId = () => (self.crypto && crypto.randomUUID ? crypto.randomUUID() : `${Date.now().toString(36)}${Math.random().toString(36).slice(2)}`);

/** Where this visit came from: ?src=instagram on the link (kept for the visit). The page reads the query on purpose. */
export const SRC = (() => {
  try {
    const q = new URLSearchParams(location.search).get('src');
    if (q) sessionStorage.setItem('apt:src', q);
    return q || sessionStorage.getItem('apt:src') || '';
  } catch { return ''; }
})();
export const channel = () => { let v = SRC; try { v = sessionStorage.getItem('apt:src') || SRC; } catch { /* none */ } return v === 'link' ? 'link' : (v ? `page:${v}` : 'page'); };

async function viewAll(name, o = {}) {
  const out = [];
  for (let offset = 0; offset < 4000; offset += 500) {
    const r = await Orch.db.view(name, Object.assign({ limit: 500, offset }, o));
    out.push(...(r.rows || []));
    if (!r.hasMore) break;
  }
  return out;
}

export let site = null;
export async function load() {
  if (site) return site;
  const [rows, staff] = await Promise.all([viewAll('book_page', { sort: 'position:asc' }), viewAll('book_staff', { sort: 'position:asc' })]);
  const s = rows[0] || {};
  const langs = String(s.languages || 'es').split(',').map((x) => x.trim()).filter((x) => WORDS[x]);
  site = {
    s: { timezone: s.timezone || 'UTC', slot_step_min: s.slot_step_min, min_notice_min: s.min_notice_min, window_days: s.window_days,
      change_hours: s.change_hours, currency: s.currency || 'EUR', paused: s.paused, mails: s.mails === 'yes' },
    biz: { name: s.business_name || '', address: s.address || '', phone: s.phone || '', intro: s.intro || '' },
    langs: langs.length ? langs : ['es'], def: WORDS[s.default_language] ? s.default_language : 'es',
    services: rows.filter((r) => r.service_id).map((r) => ({ _id: r.service_id, name: r.name, category: r.category, description: r.description,
      duration_min: r.duration_min, price_minor: r.price_minor, buffer_before_min: r.buffer_before_min, buffer_after_min: r.buffer_after_min, active: 'yes' })),
    staff: staff.map((r) => ({ _id: r.staff_id, name: r.name, hours: r.hours, services: r.services, max_per_day: r.max_per_day, position: r.position, active: 'yes' })),
  };
  return site;
}

let cache = { at: 0, rows: null };
/** Busy times from yesterday on (bookings with buffers, blocks, days off): no names, no ids but the booking's. */
export async function busy(force) {
  if (!force && cache.rows && Date.now() - cache.at < 15000) return cache.rows;
  const from = new Date(Date.now() - 86400000).toISOString().slice(0, 10);
  cache = { at: Date.now(), rows: await viewAll('book_busy', { filter: { end_at: { gte: from } } }) };
  return cache.rows;
}
/** The rules' input; `mine` leaves out the client's own booking when they move it. */
export function rules(rows, mine) {
  const own = (b) => mine && b.kind === 'booking' && Number(b.staff_id) === Number(mine.staff_id) && b.start_at === mine.busy_from && b.end_at === mine.busy_to;
  return {
    settings: site.s, services: site.services, staff: site.staff, now: Date.now(),
    busy: rows.filter((b) => b.kind !== 'off' && !own(b)),
    offs: rows.filter((b) => b.kind === 'off').map((b) => ({ staff_id: b.staff_id, day_from: String(b.start_at).slice(0, 10), day_to: String(b.end_at).slice(0, 10) })),
  };
}

// ── language ─────────────────────────────────────────────────────────────
let LANG = null;
export function lang() {
  if (LANG) return LANG;
  const want = [store.get('apt:lang', ''), (navigator.language || '').slice(0, 2)];
  LANG = want.find((l) => site && site.langs.includes(l)) || (site ? (site.langs.includes(site.def) ? site.def : site.langs[0]) : 'es');
  document.documentElement.lang = LANG;
  return LANG;
}
export const w = () => WORDS[lang()];
export function setLang(l, again) { LANG = l; store.set('apt:lang', l); document.documentElement.lang = l; again(); }

/** One card on the page, with the business on top. */
export function show(again, ...nodes) {
  Orch.mount('page', el('section', { class: 'bp-card' }, [top(site ? site.biz : {}, lang(), site ? site.langs : [], (l) => setLang(l, again)), ...nodes]));
  const h = document.querySelector('#page h1');
  if (h) { h.tabIndex = -1; h.focus({ preventScroll: true }); }
  window.scrollTo(0, 0);
}

// ── sending ──────────────────────────────────────────────────────────────
/** The request, sent; on a busy platform or a lost connection, again after a wait. */
export async function send(params, status) {
  status.textContent = w().booking;
  // The server sets aside what comes in under 3 seconds (bots): a quick hand with autofill waits the rest.
  if (Date.now() - T0 < 3300) await sleep(3300 - (Date.now() - T0));
  for (let i = 0; ; i += 1) {
    try { return await Orch.action('request', Object.assign({ ms: Date.now() - T0, hp: '', language: lang() }, params)); } catch (e) {
      const passing = !e.status || e.status === 429 || e.status >= 500;
      if (!passing || i >= WAITS.length) throw e;
      for (let s = WAITS[i]; s > 0; s -= 1) { status.textContent = w().busy(s); await sleep(1000); }
      status.textContent = w().booking;
    }
  }
}
const BASE = (() => { const p = location.pathname; const i = p.indexOf('/canvas/a/'); return i < 0 ? '.' : `${p.slice(0, i)}/canvas/a/${p.slice(i + 10).split('/')[0]}`; })();
/** Ask for it to be taken now. A refused beacon is picked up by the half-hourly check. */
export function processNow() {
  const body = new Blob([JSON.stringify({ params: {} })], { type: 'application/json' });
  try { if (navigator.sendBeacon && navigator.sendBeacon(`${BASE}/api/actions/process`, body)) return; } catch { /* plain call below */ }
  Orch.action('process', {}).catch(() => { /* the half-hourly check takes it */ });
}
/** The client's page as sealed for this token, or null. */
export async function opened(token) {
  const k = await C.linkKey(token);
  const r = await Orch.db.view('client_links', { filter: { k }, limit: 1 });
  const row = (r.rows || [])[0];
  return row ? C.open(token, row.box) : null;
}
/** Wait (up to ~45 s) until the sealed page says how the ask with this `visit` went. */
export async function answer(token, visit, { tries = 36 } = {}) {
  for (let i = 0; i < tries; i++) {
    await sleep(i < 8 ? 700 : 1500);
    const box = await opened(token).catch(() => null);
    if (box && box.last && box.last.visit === visit) return box;
  }
  return null;
}
export function remember(token) { const mine = store.get('apt:mine', []).filter((t) => t !== token); mine.unshift(token); store.set('apt:mine', mine.slice(0, 5)); }
export const linkFor = (token) => `${location.origin}${location.pathname}#/c/${token}`;
export { S, C };
