// Settings → Emails to clients: the confirmation, any change or
// cancellation and the reminders, through Gmail or Resend. Both are
// connected in Orchestra → Integrations; this card only chooses one and says
// what the last look found (the Send workflow's --check: on its own when
// Settings opens, every six hours while emails are on, and with "Look
// again"). It is part of Settings' one form: `take(data, s)` adds its fields
// to the save and never stops it. Turning emails on is the one thing that
// needs a working sender: when it is not ready, emails stay off and a plain
// sentence says why, never an error.
import { CORE, INTEGRATIONS, field, input, lookAgain } from '../data.js';

const { el, fmt } = Orch;

export function emailsCard(s, t, check, again) {
  const st = CORE.senders(s, 'clients');
  const domains = CORE.verifiedDomains(s);
  let sender = st.sender;
  const c = {
    resend_from_name: input({ value: s.resend_from_name || '', maxlength: '80', placeholder: s.business_name || 'Estudio Brava' }),
    resend_from: input({ type: 'email', value: s.resend_from || '', maxlength: '120', placeholder: domains && domains[0] ? `hola@${domains[0]}` : 'hola@yourbusiness.com' }),
    resend_reply_to: input({ type: 'email', value: s.resend_reply_to || '', maxlength: '120', placeholder: 'Optional' }),
  };
  const option = (value, label, sub) => {
    const r = el('input', { type: 'radio', name: 'ap-sender', value, checked: sender === value });
    r.addEventListener('change', () => { sender = value; draw(); });
    return el('label', { class: 'ap-choice' }, [r, el('span', { class: 'ap-choice__text' }, [el('span', { class: 'ap-choice__name' }, label), el('span', { class: 'oc-help' }, sub)])]);
  };
  const gmailSub = st.connected.gmail ? `Connected: ${s.gmail_account || 'it answers'}. Emails go from that address, and replies land in it.` : 'Not connected to this workspace.';
  const resendSub = st.connected.resend
    ? `Connected${domains && domains.length ? `; verified domains: ${domains.join(', ')}` : ''}. Emails go from an address on your own domain.`
    : 'Not connected to this workspace.';
  const resendBox = el('div', { class: 'oc-stack' }, [
    el('div', { class: 'ap-two' }, [field('From name', c.resend_from_name, 'What clients see as the sender. Empty: the business name.'),
      field('From address', c.resend_from, 'On a domain verified in your Resend account.')]),
    field('Reply-to (optional)', c.resend_reply_to, 'Where clients\' replies go. Empty: to the From address.'),
  ]);
  const said = el('p', { class: 'ap-said' });
  const agentNote = el('p', { class: 'ap-said' });
  function draw() {
    resendBox.hidden = sender !== 'resend';
    const problem = CORE.senderProblem(s, { sender, resend_from: c.resend_from.value });
    said.textContent = sender === st.sender && !problem ? [st.say, st.note].filter(Boolean).join(' ') : (problem || (sender === 'resend' ? 'Save, and Resend is asked about this address.' : ''));
    said.hidden = !said.textContent;
    agentNote.textContent = sender === 'resend' && s.inbox_on === 'yes'
      ? 'Book from emails (Email assistant) needs Gmail: the agent reads that inbox and answers in the client\'s thread. While Resend sends, it does not read it.' : '';
    agentNote.hidden = !agentNote.textContent;
  }
  draw();

  const nothing = !st.connected.gmail && !st.connected.resend && (s.gmail_status || s.resend_status);
  const look = el('button', { type: 'button', class: 'oc-btn oc-btn--sm oc-btn--ghost' }, 'Look again');
  look.addEventListener('click', async () => { look.disabled = true; look.textContent = 'Looking…'; await lookAgain(s, again); });
  const card = el('section', { class: 'oc-card oc-stack ap-emails' }, [
    el('div', { class: 'oc-row oc-row--between' }, [el('h2', { class: 'oc-h2' }, 'Emails to clients'),
      el('span', { class: `oc-badge${s.emails_on === 'yes' && st.ready ? ' oc-badge--good' : ''}` }, s.emails_on === 'yes' ? (st.ready ? 'On' : 'On, not sending') : 'Off')]),
    nothing ? el('p', { class: 'ap-said' }, ['Connect Gmail or Resend in ', el('a', { href: INTEGRATIONS, target: '_top' }, 'Integrations'), ' to email clients. Bookings work the same without emails.']) : null,
    el('fieldset', { class: 'ap-fieldset' }, [el('legend', { class: 'oc-label' }, 'Send through'), el('div', { class: 'ap-choices' }, [
      option('gmail', 'Gmail', gmailSub), option('resend', 'Resend', resendSub)])]),
    resendBox, said, agentNote,
    check(t.emails_on, 'Send emails to clients', 'Their confirmation, any change or cancellation, and reminders. They go on their own, because the client booked.'),
    check(t.reminder_24h, 'A reminder the day before'),
    check(t.reminder_2h, 'Another reminder 2 hours before'),
    el('div', { class: 'oc-row ap-look' }, [el('span', { class: 'oc-help' }, s.resend_checked_at ? `Looked at Gmail and Resend ${fmt.ago(s.resend_checked_at)}.` : 'Not looked yet.'), look]),
  ]);

  /**
   * This card's part of the save: the sender's fields, and emails kept off
   * (with a plain sentence) when they are being turned on and the sender is
   * not ready. Returns { note, changed } (null note: nothing to say).
   */
  function take(data) {
    Object.assign(data, { sender, resend_from_name: c.resend_from_name.value.trim(), resend_from: CORE.normEmail(c.resend_from.value), resend_reply_to: CORE.normEmail(c.resend_reply_to.value) });
    if (data.resend_from && !CORE.isEmail(data.resend_from)) return { stop: 'The From address does not look like an email address.', focus: c.resend_from };
    if (data.resend_reply_to && !CORE.isEmail(data.resend_reply_to)) return { stop: 'The reply-to does not look like an email address.', focus: c.resend_reply_to };
    const notes = [];
    const problem = CORE.senderProblem(s, data);
    if (data.emails_on === 'yes' && s.emails_on !== 'yes' && problem) { data.emails_on = 'no'; notes.push(`Emails stay off for now: ${problem}`); }
    if (data.inbox_on === 'yes' && s.inbox_on !== 'yes' && sender !== 'gmail') { data.inbox_on = 'no'; notes.push('Book from emails stays off: it needs Gmail as the sender.'); }
    return { note: notes.join(' ') || null, changed: sender !== st.sender || data.resend_from !== CORE.normEmail(s.resend_from) };
  }
  return { card, take };
}
