// Messages: the emails that wait for a person. To approve: what the agent
// wrote outside the rules (an answer, free times offered, an invitation to
// come back), editable, Approve sends it through the chosen sender (Gmail or Resend). Could not be sent:
// the reason and Try again. Then what the email assistant did with booking
// requests (only when it is on), and the last emails sent.
import { A, CORE, SCH, T, act, badge, every, field, head, input, settings, shortDay, dayOf, hhmm } from '../data.js';

const { el, router } = Orch;
const PURPOSE = { confirm: 'Confirmation', changed: 'Change', cancelled: 'Cancellation', reminder24: 'Reminder (day before)', reminder2: 'Reminder (2 h)',
  reply: 'Answer', options: 'Free times offered', rebook: 'Come back invitation' };

export function render() {
  const again = () => render();
  Orch.load('view', async () => {
    const [s, review, failed, sent, inbox] = await Promise.all([
      settings(),
      every(T.emails, { filter: { status: 'Review' }, sort: '_id:asc' }),
      every(T.emails, { filter: { status: 'Failed' }, sort: '_id:desc' }),
      Orch.db.list(T.emails, { filter: { status: ['Sent', 'Queued', 'Sending', 'Approved'] }, sort: '_id:desc', limit: 15 }),
      Orch.db.list(T.inbox, { filter: { status: { ne: 'Ignored' } }, sort: '_id:desc', limit: 15 }),
    ]);
    const when = (v) => (v ? `${shortDay(dayOf(v, s))} ${hhmm(v, s)}` : '');
    const off = s.emails_on !== 'yes' || !CORE.senders(s, 'clients').ready;
    return el('div', { class: 'oc-stack oc-stack--loose' }, [
      head('Messages', 'Emails to your clients that wait for you, and what went out.'),
      off ? el('div', { class: 'ap-notice' }, [s.emails_on === 'yes' ? `Emails are on, but not going out: ${CORE.senders(s, 'clients').say} ` : 'Emails are off: bookings work, clients just get no confirmation or reminder. ', router.link('/settings', s.emails_on === 'yes' ? 'See Settings' : 'Turn them on in Settings')]) : null,
      section('To approve', review.length, review.length ? review.map((m) => draft(m, again, s)) : [el('p', { class: 'oc-help ap-pad' }, 'Nothing waits for your OK.')]),
      failed.length ? section('Could not be sent', failed.length, failed.map((m) => el('div', { class: 'ap-msg' }, [
        el('div', { class: 'ap-msg__head' }, [el('span', `${PURPOSE[m.purpose] || m.purpose} · ${m.to_email}`), badge('Failed')]),
        el('p', { class: 'ap-bad' }, m.error || 'It did not go out.'),
        el('div', { class: 'oc-row' }, [
          el('button', { type: 'button', class: 'oc-btn oc-btn--sm', onClick: async () => { if (await act(A.retry, { id: m._id }, 'Sending again.')) again(); } }, 'Try again'),
          el('button', { type: 'button', class: 'oc-btn oc-btn--sm oc-btn--ghost', onClick: async () => { if (await act(A.dismissEmail, { id: m._id }, 'Dismissed.')) again(); } }, 'Dismiss'),
        ]),
      ]))) : null,
      s.inbox_on === 'yes' || (inbox.rows || []).length ? section('Booking requests by email', null, (inbox.rows || []).length ? [el('ul', { class: 'ap-rows' }, inbox.rows.map((r) => el('li', { class: 'ap-row' }, [
        el('span', { class: 'ap-row__main' }, [el('span', `${r.from_name || r.from_email} · ${r.subject || '(no subject)'}`), el('span', { class: 'ap-row__sub' }, r.why || r.intent || ' ')]),
        el('span', { class: 'oc-value ap-row__fact' }, when(r.received_at)),
        r.status === 'Failed' ? el('button', { type: 'button', class: 'oc-btn oc-btn--sm', onClick: async () => { if (await act(A.inboxAgain, { id: r._id }, 'The agent will look again.')) again(); } }, 'Try again') : badge(r.status),
      ])))] : [el('p', { class: 'oc-help ap-pad' }, 'No booking requests by email yet.')]) : null,
      section('Last sent', null, (sent.rows || []).length ? [el('ul', { class: 'ap-rows' }, sent.rows.map((m) => el('li', { class: 'ap-row' }, [
        el('span', { class: 'ap-row__main' }, [el('span', m.to_email), el('span', { class: 'ap-row__sub' }, PURPOSE[m.purpose] || m.purpose)]),
        el('span', { class: 'oc-value ap-row__fact' }, when(m.sent_at || m._created_at)),
        badge(m.status),
      ])))] : [el('p', { class: 'oc-help ap-pad' }, 'Nothing sent yet.')]),
    ]);
  });
}

function section(title, n, body) {
  return el('section', { class: 'oc-card oc-card--pad0' }, [el('h2', { class: 'oc-eyebrow ap-group' }, n === null ? title : `${title} · ${n}`), ...body]);
}

function draft(m, again, s) {
  const subject = input({ value: m.subject || '', maxlength: '200' });
  const body = el('textarea', { class: 'oc-textarea', rows: String(Math.min(14, String(m.body || '').split('\n').length + 1)), maxlength: '3000' }, m.body || '');
  const params = () => ({ id: m._id, subject: subject.value.trim(), body: body.value.trim() });
  return el('div', { class: 'ap-msg oc-stack oc-stack--tight' }, [
    el('div', { class: 'ap-msg__head' }, [el('span', `${PURPOSE[m.purpose] || m.purpose} · to ${m.to_email}`), el('span', { class: 'oc-eyebrow' }, m.drafted_by === 'agent' ? 'Written by the agent' : 'Written from the template')]),
    field('Subject', subject), field('Text', body),
    el('div', { class: 'oc-row' }, [
      el('button', { type: 'button', class: 'oc-btn oc-btn--primary', onClick: async () => { if (await act(A.approve, params(), `Approved: it goes out through ${CORE.senderOf(s) === 'resend' ? 'Resend' : 'your Gmail'} now.`)) again(); } }, 'Approve and send'),
      el('button', { type: 'button', class: 'oc-btn', onClick: () => act(A.saveEmail, params(), 'Saved.') }, 'Save'),
      el('button', { type: 'button', class: 'oc-btn oc-btn--ghost', onClick: async () => { if (await act(A.drop, { id: m._id }, 'Dropped: nothing goes out.')) again(); } }, 'Drop'),
    ]),
  ]);
}
export { SCH };
