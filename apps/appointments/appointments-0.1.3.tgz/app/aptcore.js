/**
 * Appointments · what the desk, the public page and the scripts must agree
 * on besides the slot rules (sched.js): who a client is (email, phone, name),
 * money, the client's sealed link, what that link shows, and the emails'
 * words in Spanish (tú) and English. Pure functions, no database, no DOM.
 * test/sync.js copies it to app/, public/ and automations/.
 *
 * The sealed link is Invoices' (apps/invoices/shared/invcore.js): a public
 * view cannot require a filter, so what it holds means nothing without the
 * link. k = SHA-256("apt-k:"+token) finds the row, the row is AES-GCM sealed
 * with SHA-256("apt-e:"+token), and the token lives after the link's #.
 */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.AptCore = api;
}(typeof self !== 'undefined' ? self : this, () => {
  'use strict';

  const LANGS = ['es', 'en'];
  const CURRENCIES = ['EUR', 'USD', 'GBP', 'CHF', 'MXN', 'COP', 'ARS', 'CLP', 'PEN', 'BRL', 'CAD', 'AUD'];
  const EMAIL = /^[^\s@<>(),;:"]+@[^\s@<>(),;:"]+\.[A-Za-z]{2,}$/;

  const normEmail = (v) => String(v || '').trim().toLowerCase();
  const isEmail = (v) => EMAIL.test(normEmail(v)) && normEmail(v).length <= 200;
  /** A phone as people type it, kept readable: digits, spaces, + ( ) - only; at least 6 digits. */
  function normPhone(v) {
    const s = String(v || '').replace(/[^\d+()\-\s]/g, '').replace(/\s+/g, ' ').trim().slice(0, 25);
    return (s.match(/\d/g) || []).length >= 6 ? s : '';
  }
  /** The same phone written two ways ("+34 600 11 22 33", "600112233") is one: its last 9 digits. */
  const phoneKey = (v) => (String(v || '').match(/\d/g) || []).join('').slice(-9);
  const cleanName = (v) => String(v || '').replace(/\s+/g, ' ').trim().slice(0, 120);
  const firstName = (v) => cleanName(v).split(' ')[0] || '';
  const langOf = (v, fallback) => (LANGS.includes(String(v || '').slice(0, 2).toLowerCase()) ? String(v).slice(0, 2).toLowerCase() : (fallback || 'es'));

  // ── money: whole minor units ────────────────────────────────────────────
  function decimals(currency) {
    try { return new Intl.NumberFormat('en', { style: 'currency', currency: String(currency || 'EUR').toUpperCase() }).resolvedOptions().maximumFractionDigits; } catch { return 2; }
  }
  /** '25', '25,50', '25.5' → minor units (2550); null when it is not an amount. */
  function toMinor(text, currency) {
    const s = String(text === null || text === undefined ? '' : text).trim().replace(/\s/g, '');
    if (!s) return 0;
    const norm = /,\d{1,2}$/.test(s) ? s.replace(/\./g, '').replace(',', '.') : s.replace(/,/g, '');
    if (!/^\d+(\.\d+)?$/.test(norm)) return null;
    return Math.round(Number(norm) * 10 ** decimals(currency));
  }
  const fromMinor = (n, currency) => (Number(n) || 0) / 10 ** decimals(currency);
  function money(n, currency, lang) {
    const v = fromMinor(n, currency);
    try {
      return new Intl.NumberFormat(lang === 'en' ? 'en-GB' : 'es-ES', { style: 'currency', currency: String(currency || 'EUR').toUpperCase(),
        minimumFractionDigits: v % 1 ? 2 : 0, maximumFractionDigits: 2 }).format(v);
    } catch { return String(v); }
  }

  // ── dates in words ──────────────────────────────────────────────────────
  const loc = (lang) => (lang === 'en' ? 'en-GB' : 'es-ES');
  const at = (v) => new Date(/[zZ]$/.test(String(v)) ? v : `${String(v).replace(' ', 'T')}Z`);
  const longDay = (v, tz, lang) => new Intl.DateTimeFormat(loc(lang), { timeZone: tz, weekday: 'long', day: 'numeric', month: 'long' }).format(at(v));
  const timeOf = (v, tz, lang) => new Intl.DateTimeFormat(loc(lang), { timeZone: tz, hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }).format(at(v));

  // ── the sealed link (Invoices' pattern) ─────────────────────────────────
  const subtle = () => (globalThis.crypto && globalThis.crypto.subtle) || null;
  const enc = (s) => new TextEncoder().encode(s);
  const b64u = (bytes) => btoa(String.fromCharCode(...new Uint8Array(bytes))).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  const unb64u = (s) => Uint8Array.from(atob(String(s).replace(/-/g, '+').replace(/_/g, '/') + '==='.slice((String(s).length + 3) % 4)), (c) => c.charCodeAt(0));
  const hex = (bytes) => [...new Uint8Array(bytes)].map((b) => b.toString(16).padStart(2, '0')).join('');
  const TOKEN = /^[A-Za-z0-9_-]{22,64}$/;
  /** 128 random bits, base64url (22 characters). */
  function newToken() { const b = new Uint8Array(16); globalThis.crypto.getRandomValues(b); return b64u(b); }
  async function linkKey(token) { return hex(await subtle().digest('SHA-256', enc(`apt-k:${token}`))); }
  async function boxKey(token, use) {
    const raw = await subtle().digest('SHA-256', enc(`apt-e:${token}`));
    return subtle().importKey('raw', raw, { name: 'AES-GCM' }, false, [use]);
  }
  async function seal(token, obj) {
    const iv = new Uint8Array(12);
    globalThis.crypto.getRandomValues(iv);
    const ct = await subtle().encrypt({ name: 'AES-GCM', iv }, await boxKey(token, 'encrypt'), enc(JSON.stringify(obj)));
    const out = new Uint8Array(12 + ct.byteLength);
    out.set(iv, 0);
    out.set(new Uint8Array(ct), 12);
    return b64u(out);
  }
  async function open(token, box) {
    try {
      const all = unb64u(box);
      const pt = await subtle().decrypt({ name: 'AES-GCM', iv: all.slice(0, 12) }, await boxKey(token, 'decrypt'), all.slice(12));
      return JSON.parse(new TextDecoder().decode(pt));
    } catch { return null; }
  }
  /** A stable fingerprint of what the client sees, so a link is rewritten only when it changed. */
  function fingerprint(obj) {
    const s = JSON.stringify(obj);
    let h = 2166136261;
    for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); }
    return (h >>> 0).toString(16);
  }

  /**
   * What the client's page shows for one booking (or one request that could
   * not be given): no other client, no note of the business.
   */
  function snapshot(b, s, extra) {
    return Object.assign({
      v: 1,
      state: b ? ({ Booked: 'booked', Arrived: 'booked', Cancelled: 'cancelled', NoShow: 'past' }[b.status] || 'booked') : 'failed',
      lang: langOf((b && b.language) || (s && s.default_language)),
      business: { name: String((s && s.business_name) || ''), address: String((s && s.address) || ''), phone: String((s && s.phone) || '') },
      tz: String((s && s.timezone) || 'UTC'),
      booking: b ? {
        service: b.service_name || '', service_ids: (() => { try { return JSON.parse(b.service_ids || '[]'); } catch { return []; } })(), staff: b.staff_name || '', staff_id: Number(b.staff_id) || 0,
        any: b.any_staff === 'yes', start_at: b.start_at, end_at: b.end_at, price: Number(b.price_minor) || 0,
        currency: (s && s.currency) || 'EUR', name: firstName(b.client_name),
      } : null,
    }, extra || {});
  }

  // ── the emails ──────────────────────────────────────────────────────────
  const WORDS = {
    es: {
      hi: (n) => `Hola${n ? ` ${n}` : ''}:`,
      confirm: (f) => [`Tu cita está confirmada: ${f.service}${f.staff ? ` con ${f.staff}` : ''}, el ${f.day} a las ${f.time}.`],
      changed: (f) => [`Hemos cambiado tu cita: ahora es ${f.service}${f.staff ? ` con ${f.staff}` : ''}, el ${f.day} a las ${f.time}.`],
      cancelled: (f) => [`Tu cita de ${f.service} del ${f.day} a las ${f.time} está cancelada.`, f.byUs ? 'Si quieres otra hora, puedes reservarla cuando quieras.' : 'Gracias por avisarnos.'],
      reminder: (f) => [`Te recordamos tu cita: ${f.service}${f.staff ? ` con ${f.staff}` : ''}, ${f.soon ? 'hoy' : 'mañana'} ${f.day} a las ${f.time}.`],
      where: (f) => (f.address ? `Dónde: ${f.address}` : ''),
      manage: (f) => (f.link ? `Para ver, cambiar o cancelar tu cita: ${f.link}${f.until ? ` (hasta el ${f.until})` : ''}` : ''),
      call: (f) => (f.phone ? `Si necesitas algo, llámanos al ${f.phone}.` : ''),
      bye: (f) => ['Un saludo,', f.business],
      subject: { confirm: 'Cita confirmada', changed: 'Tu cita ha cambiado', cancelled: 'Cita cancelada', reminder: 'Recordatorio de tu cita', options: 'Horarios disponibles', rebook: '¿Te reservamos la próxima?' },
      options: (f) => [`No tenemos libre lo que nos pediste${f.service ? ` para ${f.service}` : ''}. Estas horas sí lo están:`],
      pick: 'Responde con la que prefieras y te la reservamos.',
      rebook: (f) => [`Ya han pasado unas semanas desde tu última visita (${f.service}). ¿Te reservamos la próxima?`],
      book: (f) => (f.page ? `Puedes elegir día y hora aquí: ${f.page}` : 'Responde a este correo con el día que te va bien.'),
      at: 'a las',
    },
    en: {
      hi: (n) => `Hello${n ? ` ${n}` : ''},`,
      confirm: (f) => [`Your appointment is confirmed: ${f.service}${f.staff ? ` with ${f.staff}` : ''}, on ${f.day} at ${f.time}.`],
      changed: (f) => [`Your appointment has changed: it is now ${f.service}${f.staff ? ` with ${f.staff}` : ''}, on ${f.day} at ${f.time}.`],
      cancelled: (f) => [`Your ${f.service} appointment on ${f.day} at ${f.time} is cancelled.`, f.byUs ? 'If you would like another time, you can book one whenever you like.' : 'Thank you for letting us know.'],
      reminder: (f) => [`A reminder of your appointment: ${f.service}${f.staff ? ` with ${f.staff}` : ''}, ${f.soon ? 'today' : 'tomorrow'}, ${f.day} at ${f.time}.`],
      where: (f) => (f.address ? `Where: ${f.address}` : ''),
      manage: (f) => (f.link ? `To see, change or cancel it: ${f.link}${f.until ? ` (until ${f.until})` : ''}` : ''),
      call: (f) => (f.phone ? `If you need anything, call us on ${f.phone}.` : ''),
      bye: (f) => ['Best wishes,', f.business],
      subject: { confirm: 'Appointment confirmed', changed: 'Your appointment has changed', cancelled: 'Appointment cancelled', reminder: 'Your appointment reminder', options: 'Times we have free', rebook: 'Shall we book your next one?' },
      options: (f) => [`We do not have free what you asked for${f.service ? ` (${f.service})` : ''}. These times are:`],
      pick: 'Reply with the one you prefer and we will book it.',
      rebook: (f) => [`It has been a few weeks since your last visit (${f.service}). Shall we book the next one?`],
      book: (f) => (f.page ? `You can pick a day and time here: ${f.page}` : 'Reply to this email with a day that suits you.'),
      at: 'at',
    },
  };

  /** The facts an email about a booking needs, in the client's language and the business's zone. */
  function facts(b, s, { link, page, byUs, soon } = {}) {
    const lang = langOf(b.language, s.default_language);
    const tz = String(s.timezone || 'UTC');
    const until = Number(s.change_hours) > 0 ? `${longDay(new Date(at(b.start_at).getTime() - Number(s.change_hours) * 3600000).toISOString(), tz, lang)} ${WORDS[lang].at} ${timeOf(new Date(at(b.start_at).getTime() - Number(s.change_hours) * 3600000).toISOString(), tz, lang)}` : '';
    return { lang, name: firstName(b.client_name), service: b.service_name || '', staff: b.any_staff === 'yes' && !b.staff_name ? '' : (b.staff_name || ''),
      day: longDay(b.start_at, tz, lang), time: timeOf(b.start_at, tz, lang), address: s.address || '', phone: s.phone || '',
      business: s.business_name || '', link: link || '', page: page || '', until, byUs: Boolean(byUs), soon: Boolean(soon) };
  }
  /** One of the automatic emails: confirm, changed, cancelled, reminder. {subject, body, lang}. */
  function bookingEmail(kind, b, s, opts) {
    const f = facts(b, s, opts);
    const w = WORDS[f.lang];
    const lines = [w.hi(f.name), '', ...w[kind](f)];
    if (kind !== 'cancelled') lines.push(w.where(f));
    if (kind !== 'cancelled') lines.push('', w.manage(f));
    lines.push(w.call(f), '', ...w.bye(f));
    const name = f.business ? ` · ${f.business}` : '';
    return { lang: f.lang, subject: `${w.subject[kind]}${name}`, body: lines.filter((l, i, a) => l !== '' || (a[i - 1] !== '' && i > 0)).join('\n').trim() };
  }
  /** A reply offering free times (the owner approves it before it goes). */
  function optionsEmail(lang, s, { name, service, times, page }) {
    const w = WORDS[langOf(lang, s.default_language)];
    const tz = String(s.timezone || 'UTC');
    const l = langOf(lang, s.default_language);
    const list = (times || []).map((t) => `- ${longDay(t.start_at, tz, l)} ${w.at} ${timeOf(t.start_at, tz, l)}${t.staff_name ? ` (${t.staff_name})` : ''}`);
    return { subject: `${w.subject.options}${s.business_name ? ` · ${s.business_name}` : ''}`,
      body: [w.hi(firstName(name)), '', ...w.options({ service }), ...list, '', list.length ? w.pick : w.book({ page }), '', ...w.bye({ business: s.business_name || '' })].join('\n') };
  }
  /** The invitation to come back when no agent wrote one. */
  function rebookEmail(lang, s, { name, service, page }) {
    const w = WORDS[langOf(lang, s.default_language)];
    return { subject: `${w.subject.rebook}${s.business_name ? ` · ${s.business_name}` : ''}`,
      body: [w.hi(firstName(name)), '', ...w.rebook({ service }), w.book({ page }), '', ...w.bye({ business: s.business_name || '' })].join('\n') };
  }

  /** What makes a text unfit to send as it is: a placeholder left in, or a link (the scripts add the only link). */
  function draftProblems(text) {
    const t = String(text || '');
    const out = [];
    if (!t.trim()) out.push('empty');
    if (/\[[^\]]{1,40}\]|\{\{|\}\}|<[A-Z_ ]{3,}>|XX:XX|\bTBD\b/.test(t)) out.push('placeholder');
    if (/https?:\/\/|www\./i.test(t)) out.push('link');
    if (t.length > 3000) out.push('too long');
    return out;
  }

  // ── where a booking came from ───────────────────────────────────────────
  // channel: 'page' or 'page:<src>' (the public link, with ?src=instagram…),
  // 'link' (booked again from a client's own link), 'email' (the agent),
  // and by hand at the desk: 'phone', 'walk-in', 'marketplace:<name>'.
  const slug = (v) => String(v || '').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 30);
  /** The marketplace names of Settings, as a list. */
  const marketplacesOf = (s) => String((s && s.marketplaces) || '').split(',').map((x) => x.trim()).filter(Boolean).slice(0, 12);
  /**
   * A channel as the server keeps it, whatever the caller sent: the public
   * page can only say page/page:<src>/link; the desk phone, walk-in or one of
   * Settings' marketplaces; anything else falls back to how it arrived.
   */
  function channelOf(source, raw, s) {
    const v = String(raw || '').trim();
    if (source === 'online') {
      if (v === 'link') return 'link';
      const src = slug(v.replace(/^page:?/, ''));
      return src ? `page:${src}` : 'page';
    }
    if (source === 'email') return 'email';
    if (v === 'phone' || v === 'walk-in') return v;
    if (/^marketplace:/.test(v)) {
      const name = marketplacesOf(s).find((m) => m.toLowerCase() === v.slice(12).trim().toLowerCase());
      if (name) return `marketplace:${name}`;
    }
    return source === 'desk' ? 'phone' : (source || 'other');
  }
  const isMarketplace = (ch) => /^marketplace:/.test(String(ch || ''));
  function channelLabel(ch) {
    const v = String(ch || '');
    if (v === 'page') return 'Booking page';
    if (v.startsWith('page:')) return `Booking page · ${v.slice(5)}`;
    if (v === 'link') return 'Client link';
    if (v === 'email') return 'Email';
    if (v === 'phone') return 'Phone';
    if (v === 'walk-in') return 'Walk-in';
    if (v === 'agent') return 'Agent';
    if (isMarketplace(v)) return v.slice(12);
    return v || 'Unknown';
  }
  /**
   * The commission a marketplace would have charged, estimated: every new
   * client who came direct (not through a marketplace) × their first
   * appointment's price × the owner's fee %. clients: [{first_channel, first_price}].
   */
  function avoided(clients, feePct) {
    const pct = Math.max(0, Math.min(100, Number(feePct) || 0)) / 100;
    let n = 0;
    let minor = 0;
    for (const c of clients || []) {
      if (!c.first_channel || isMarketplace(c.first_channel)) continue;
      n += 1;
      minor += Math.round((Number(c.first_price) || 0) * pct);
    }
    return { clients: n, minor };
  }


  // ── who sends the emails: Gmail or Resend ──────────────────────────────
  // Both are Composio integrations the business connects in Orchestra →
  // Integrations; the app only chooses between them and says what it found.
  // The last check (send.js --check) is kept on the settings row:
  // gmail_status / gmail_account, resend_status, resend_domains (the verified
  // ones as a JSON list, '' when Resend did not say), and for the From
  // address it checked (resend_checked_from) resend_from_status: verified,
  // unverified or unknown.
  /** The sender Settings chose: 'resend' or 'gmail' (an install from before the choice sends with Gmail). */
  const senderOf = (s) => (s && s.sender === 'resend' ? 'resend' : 'gmail');
  const domainOf = (address) => (String(address || '').trim().toLowerCase().split('@')[1] || '');
  /** Resend's "Name <address>", the name stripped of what would break the header (quoted when it has punctuation). */
  function fromLine(name, address) {
    const n = String(name || '').replace(/[\r\n<>"\\]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 80);
    const a = normEmail(address);
    if (!n) return a;
    return /[,;:()@[\].]/.test(n) ? `"${n}" <${a}>` : `${n} <${a}>`;
  }
  /** The domains Resend said are verified, or null when it did not say. */
  function verifiedDomains(s) {
    if (!s || s.resend_domains === null || s.resend_domains === undefined || s.resend_domains === '') return null;
    try { const v = JSON.parse(s.resend_domains); return Array.isArray(v) ? v.map((d) => String(d).toLowerCase()) : null; } catch { return null; }
  }
  /**
   * Why `choice` ({ sender, resend_from }) could not send yet, from what the
   * last check found, in plain words; null when it can.
   */
  function senderProblem(s, choice) {
    const sender = senderOf(choice || s);
    if (sender === 'gmail') {
      if (s.gmail_status === 'ok') return null;
      if (s.gmail_status === 'error') return `Gmail did not answer the last check${s.gmail_note ? ` (${String(s.gmail_note).slice(0, 120)})` : ''}.`;
      return 'Gmail is not connected to this workspace.';
    }
    if (s.resend_status === 'error') return `Resend did not answer the last check${s.resend_note ? ` (${String(s.resend_note).slice(0, 120)})` : ''}.`;
    if (s.resend_status !== 'ok') return 'Resend is not connected to this workspace.';
    const from = normEmail(choice ? choice.resend_from : s.resend_from);
    if (!isEmail(from)) return 'Resend needs a From address: one on a domain verified in your Resend account.';
    const domains = verifiedDomains(s);
    const domain = domainOf(from);
    if (domains && !domains.includes(domain)) {
      return `${domain} is not verified in your Resend account${domains.length ? ` (verified: ${domains.join(', ')})` : ''}. Verify it in Resend → Domains, or use an address on a verified domain.`;
    }
    return null;
  }
  /**
   * Where the emails stand, from the settings row: { sender, ready, connected:
   * {gmail, resend}, say, problem, note }. `ready` is what the booking page's
   * promise (the `mails` flag) and Getting started read: the chosen sender is
   * connected and, with Resend, the From address was checked and is not on an
   * unverified domain. `say` is one plain sentence for the desk.
   */
  function senders(s, who = 'guests') {
    const sender = senderOf(s);
    const connected = { gmail: s.gmail_status === 'ok', resend: s.resend_status === 'ok' };
    const problem = senderProblem(s, null);
    const from = normEmail(s.resend_from);
    const checked = sender === 'gmail' || (s.resend_checked_from || '') === from;
    const ready = !problem && checked && !(sender === 'resend' && s.resend_from_status === 'unverified');
    let note = '';
    if (sender === 'resend' && ready && s.resend_from_status !== 'verified') note = `Resend did not say whether ${domainOf(from)} is verified: make sure it is, in Resend → Domains, or the emails will be refused.`;
    let say;
    if (!connected.gmail && !connected.resend && !s.gmail_status && !s.resend_status) say = `Not checked yet which of Gmail or Resend is connected.`;
    else if (!connected.gmail && !connected.resend) say = `Connect Gmail or Resend in Integrations to email ${who}.`;
    else if (sender === 'gmail' && connected.gmail) say = `Emails go out through Gmail${s.gmail_account ? ` (${s.gmail_account})` : ''}; replies from ${who} land there.`;
    else if (sender === 'resend' && ready) say = `Emails go out through Resend, from ${fromLine(s.resend_from_name || s.business_name, from)}${isEmail(s.resend_reply_to) ? `; replies go to ${normEmail(s.resend_reply_to)}` : ''}.`;
    else if (sender === 'resend' && !problem && !checked) say = `Resend is connected. Checking ${from} with it…`;
    else if (problem && connected[sender === 'gmail' ? 'resend' : 'gmail']) say = `${problem} ${sender === 'gmail' ? 'Resend' : 'Gmail'} is connected: choose it, or connect ${sender === 'gmail' ? 'Gmail' : 'Resend'} in Integrations.`;
    else say = problem || '';
    return { sender, ready, connected, say, problem, note };
  }

  return {
    LANGS, CURRENCIES, TOKEN, WORDS,
    normEmail, isEmail, normPhone, phoneKey, cleanName, firstName, langOf,
    decimals, toMinor, fromMinor, money, longDay, timeOf,
    newToken, linkKey, seal, open, b64u, fingerprint, snapshot,
    facts, bookingEmail, optionsEmail, rebookEmail, draftProblems,
    slug, marketplacesOf, channelOf, isMarketplace, channelLabel, avoided,
    senderOf, domainOf, fromLine, verifiedDomains, senderProblem, senders,
  };
}));
