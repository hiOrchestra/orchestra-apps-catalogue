'use strict';
/**
 * Appointments · Send emails, in plain text, through the sender Settings
 * chose: the business's Gmail or its Resend (both Composio integrations,
 * connected in Orchestra → Integrations).
 *
 * Two kinds go out:
 *   Queued    what the client asked for by booking: the confirmation, a
 *             change, a cancellation, and the reminders 24 h (and, if Settings
 *             say so, 2 h) before. They go on their own, only while "Send
 *             emails" is on in Settings.
 *   Approved  what the agent wrote outside those rules (an answer, free times
 *             offered, an invitation to come back): it waited in Review for a
 *             person's Approve.
 *
 * Each email is CLAIMED before the sender is called (→ Sending, atomic), so
 * none leaves twice. One left Sending (a run that died, the sender did not
 * answer) is Failed and says it may have gone out: never retried blind. A
 * reminder or a confirmation whose appointment has already started is
 * Dropped, not sent late. With Gmail a reminder goes in the thread of the
 * confirmation; Resend has no threads (a new email).
 *
 * --check looks at which of Gmail and Resend this workspace has connected
 * (the instance's connections list, else one cheap call to each), Gmail's
 * address, Resend's verified domains and whether the From address is on one,
 * and notes it in Settings; with no sender chosen yet it picks the connected
 * one (Gmail if both). --auto does it too when the last look is over six
 * hours old, or the From address changed since.
 *   node send.js [--auto|--now|--after-intake|--check] [--dry-run]
 */
const L = require('./lib');
const S = require('./sched');
const C = require('./aptcore');
const G = require('./composio');
const E = require('./engine');

const STALE_MIN = 15;

/** The reminders that are due now, queued (and the booking stamped, atomically). */
function queueReminders(s, now, dry) {
  if (s.emails_on !== 'yes') return 0;
  const kinds = [{ col: 'reminded_24_at', hours: 24, early: 20, on: s.reminder_24h !== 'no' }, { col: 'reminded_2_at', hours: 2, early: 3, on: s.reminder_2h === 'yes' }];
  let n = 0;
  for (const k of kinds.filter((x) => x.on)) {
    const rows = L.all(`SELECT b.*, c.email AS email FROM ap_bookings b JOIN ap_clients c ON c._id = b.client_id
      WHERE b._deleted = 0 AND b.status = 'Booked' AND b.${k.col} IS NULL AND COALESCE(c.email, '') <> ''
        AND b.start_at > ? AND b.start_at <= ? AND datetime(COALESCE(b.moved_at, b._created_at)) <= datetime(b.start_at, '-${k.early} hours')
      ORDER BY b.start_at LIMIT 40`, L.isoZ(now), L.isoZ(new Date(now.getTime() + k.hours * 3600000)));
    for (const b of rows) {
      if (dry) { n += 1; continue; }
      const m = C.bookingEmail('reminder', b, s, { link: E.linkOf(s, b.link_token), soon: k.hours === 2 });
      try {
        L.write([{ op: 'update', table: 'ap_bookings', id: b._id, when: { [k.col]: null, status: 'Booked' }, data: { [k.col]: L.sqlNow() } },
          { op: 'insert', table: 'ap_emails', data: { booking_id: b._id, client_id: b.client_id, purpose: k.hours === 2 ? 'reminder2' : 'reminder24',
            to_email: C.normEmail(b.email), subject: m.subject, body: m.body, status: 'Queued', thread_id: b.thread_id || null, drafted_by: 'script' } }]);
        n += 1;
      } catch { /* moved or cancelled meanwhile */ }
    }
  }
  return n;
}

const LOOK_EVERY_H = 6;
const NAME = { gmail: 'Gmail', resend: 'Resend' };
const WHERE_SENT = { gmail: 'Gmail\'s Sent folder', resend: 'Resend\'s Emails list' };

function readable(e, via = e.via || 'gmail') {
  const t = String(e.message || e);
  const who = NAME[via] || 'Gmail';
  if (e.noFrom) return 'Resend has no From address in Settings: nothing went out. Write one (Settings → Emails to clients), then Send again.';
  if (e.notConnected) return `${who} is not connected: nothing went out. Connect it in Orchestra → Integrations (or choose the other sender in Settings), then Send again. (${t.slice(0, 160)})`;
  if (e.timeout) return `${who} did not answer in time, so it may or may not have gone out. Look in ${WHERE_SENT[via]} before sending again. (${t.slice(0, 160)})`;
  if (via === 'resend' && /not verified|verify your domain/i.test(t)) return `Resend refused the From address: its domain is not verified in your Resend account. Verify it in Resend → Domains, or change the From address in Settings, then Send again. (${t.slice(0, 160)})`;
  return `${who} did not take it: nothing went out. (${t.slice(0, 200)})`;
}

/** Which senders are connected, and what each says; noted in Settings. */
function check(s) {
  const now = L.sqlNow();
  const conn = G.connections();
  const data = { gmail_checked_at: now, resend_checked_at: now };
  if (conn.ok && !conn.has('gmail')) Object.assign(data, { gmail_status: 'not_connected', gmail_note: null });
  else {
    try { Object.assign(data, { gmail_status: 'ok', gmail_account: G.profile() || s.gmail_account || null, gmail_note: null }); } catch (e) {
      Object.assign(data, { gmail_status: e.notConnected ? 'not_connected' : 'error', gmail_note: String(e.message).slice(0, 200) });
    }
  }
  const from = C.normEmail(s.resend_from);
  if (conn.ok && !conn.has('resend')) Object.assign(data, { resend_status: 'not_connected', resend_note: null, resend_domains: null });
  else {
    try { Object.assign(data, { resend_status: 'ok', resend_note: null, resend_domains: JSON.stringify(G.resendDomains().verified) }); } catch (e) {
      if (e.notConnected) Object.assign(data, { resend_status: 'not_connected', resend_note: null, resend_domains: null });
      else {
        try { G.resendPing(); Object.assign(data, { resend_status: 'ok', resend_note: null, resend_domains: null }); } catch (e2) {
          Object.assign(data, { resend_status: e2.notConnected ? 'not_connected' : 'error', resend_note: String(e2.message).slice(0, 200), resend_domains: null });
        }
      }
    }
  }
  const verified = data.resend_domains ? JSON.parse(data.resend_domains) : null;
  Object.assign(data, { resend_checked_from: from,
    resend_from_status: !C.isEmail(from) || data.resend_status !== 'ok' ? null : !verified ? 'unknown' : verified.includes(C.domainOf(from)) ? 'verified' : 'unverified' });
  if (!s.sender) {
    const pick = data.gmail_status === 'ok' ? 'gmail' : data.resend_status === 'ok' ? 'resend' : null;
    if (pick) data.sender = pick;
  }
  L.write([{ op: 'update', table: 'ap_settings', id: s._id, data }]);
  const st = C.senders(Object.assign({}, s, data), 'clients');
  return { ok: true, mode: '--check', sender: st.sender, ready: st.ready, gmail: data.gmail_status, address: data.gmail_status === 'ok' ? data.gmail_account || undefined : undefined,
    resend: data.resend_status, from: from || undefined, from_status: data.resend_from_status || undefined, via: conn.ok ? 'connections' : 'calls', say: st.say };
}

/** Time for a look: never looked, over six hours ago (while emails are on), or the From address changed since. */
function lookDue(s) {
  const last = L.toDate(s.resend_checked_at);
  if (!last) return true;
  if (C.senderOf(s) === 'resend' && C.normEmail(s.resend_from) !== (s.resend_checked_from || '')) return true;
  return s.emails_on === 'yes' && L.now().getTime() - last.getTime() > LOOK_EVERY_H * 3600000;
}

function run(mode = '--auto', { dry = false } = {}) {
  if (mode === '--check') return check(L.settings());
  let looked;
  if (!dry && lookDue(L.settings())) looked = check(L.settings());
  const held = dry ? { release() {} } : L.lock('send');
  if (!held) return { ok: true, mode, skipped: 'Another run is sending' };
  try {
    const s = L.settings();
    const now = L.now();
    const via = C.senderOf(s);
    const out = { ok: true, mode, via, reminders: queueReminders(s, now, dry), sent: 0, failed: 0, dropped: 0 };
    if (looked) out.looked = { gmail: looked.gmail, resend: looked.resend, ready: looked.ready };
    if (dry) return Object.assign(out, { dry: true, waiting: L.all("SELECT _id, purpose, to_email FROM ap_emails WHERE _deleted = 0 AND status IN ('Queued', 'Approved')") });
    const stale = L.all(`SELECT _id FROM ap_emails WHERE _deleted = 0 AND status = 'Sending' AND datetime(lock_at) <= datetime(?, '-${STALE_MIN} minutes')`, L.sqlNow());
    for (const m of stale) {
      try { L.write([{ op: 'update', table: 'ap_emails', id: m._id, when: { status: 'Sending' }, data: { status: 'Failed', error: `The send did not finish, so it may or may not have gone out. Look in ${WHERE_SENT[via]} before sending again.` } }]); } catch { /* moved on */ }
    }
    const late = L.all(`SELECT e._id FROM ap_emails e JOIN ap_bookings b ON b._id = e.booking_id WHERE e._deleted = 0 AND e.status = 'Queued'
      AND (b.start_at <= ? OR (e.purpose IN ('reminder24', 'reminder2', 'confirm', 'changed') AND b.status <> 'Booked'))`, L.isoZ(now));
    for (const m of late) {
      try { L.write([{ op: 'update', table: 'ap_emails', id: m._id, when: { status: 'Queued' }, data: { status: 'Dropped', error: 'Not sent: the appointment had started or changed before it could go' } }]); out.dropped += 1; } catch { /* moved on */ }
    }
    const queue = L.all(`SELECT * FROM ap_emails WHERE _deleted = 0 AND (status = 'Approved' OR (status = 'Queued' AND ? = 'yes')) ORDER BY _id LIMIT 30`, s.emails_on || 'no');
    for (const m of queue) {
      const from = m.status;
      if (!C.isEmail(m.to_email) || !String(m.subject || '').trim() || !String(m.body || '').trim()) {
        try { L.write([{ op: 'update', table: 'ap_emails', id: m._id, when: { status: from }, data: { status: 'Failed', error: 'It has no valid address, subject or text: nothing went out.' } }]); } catch { /* moved */ }
        out.failed += 1;
        continue;
      }
      try { L.write([{ op: 'update', table: 'ap_emails', id: m._id, when: { status: from }, data: { status: 'Sending', lock_at: L.sqlNow(), error: null } }]); } catch { continue; }
      let res;
      try {
        res = G.deliver(s, m);
      } catch (e) {
        L.write([{ op: 'update', table: 'ap_emails', id: m._id, data: { status: 'Failed', error: readable(e, via).slice(0, 500) } }]);
        if (e.notConnected) {
          L.write([{ op: 'update', table: 'ap_settings', id: s._id, data: via === 'resend' ? { resend_status: 'not_connected', resend_checked_at: L.sqlNow(), resend_note: String(e.message).slice(0, 200) }
            : { gmail_status: 'not_connected', gmail_checked_at: L.sqlNow(), gmail_note: String(e.message).slice(0, 200) } }]);
        }
        out.failed += 1;
        continue;
      }
      const ops = [{ op: 'update', table: 'ap_emails', id: m._id, data: { status: 'Sent', sent_at: L.sqlNow(), sent_via: via, gmail_message_id: via === 'gmail' ? res.id : null,
        resend_id: via === 'resend' ? res.id : null, thread_id: res.threadId || m.thread_id || null, error: null } }];
      // The thread of the confirmation: a client's answer to it is read as theirs (mail.js).
      if (m.booking_id && res.threadId && !m.thread_id) ops.push({ op: 'update', table: 'ap_bookings', id: m.booking_id, data: { thread_id: res.threadId } });
      try { L.write(ops); } catch { L.write([ops[0]]); }
      out.sent += 1;
    }
    return out;
  } finally { held.release(); }
}

if (require.main === module) {
  const argv = process.argv.slice(2);
  try { L.done(run(argv.find((a) => ['--now', '--auto', '--after-intake', '--check'].includes(a)) || '--auto', { dry: argv.includes('--dry-run') })); } catch (e) { L.done({ ok: false, error: e.message }); process.exitCode = 1; }
}

module.exports = { run, queueReminders, readable, check, lookDue, S };
