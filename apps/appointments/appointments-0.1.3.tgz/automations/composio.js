'use strict';
/**
 * Every call Appointments makes to Composio (the business's Gmail or its
 * Resend; Settings chooses which one sends), and nothing else: the slugs,
 * their arguments, and how each answer is read. When Composio renames an
 * argument, this is the only file to change.
 *
 *   connections()                GET /api/composio/connections   which toolkits are connected (ACTIVE)
 *   profile()                    GMAIL_GET_PROFILE        the connected mailbox's address
 *   fetch({ query, pageToken })  GMAIL_FETCH_EMAILS       one page of messages (read only)
 *   send({ to, subject, body })  GMAIL_SEND_EMAIL         a new plain-text email
 *   reply({ thread, to, body })  GMAIL_REPLY_TO_THREAD    an answer inside the client's own thread
 *   resendPing()                 RESEND_LIST_EMAILS       limit 1: does Resend answer (nothing is sent)
 *   resendDomains()              RESEND_LIST_DOMAINS      the domains and which are verified
 *   resendSend(s, { to, … })     RESEND_SEND_EMAIL        a plain-text email from Settings' From ("Name <address>")
 *   deliver(s, m)                one queued email through the chosen sender (a thread reply only with Gmail)
 *
 * Argument names follow the CRM's and Helpdesk's (checked on staging 10/2026);
 * RESEND_SEND_EMAIL's were read live on staging 2026-10-06 (from, to, subject,
 * text, reply_to…). Calls go through the instance as the workflow's agent
 * (lib.composio).
 *
 * APPT_FAKE_COMPOSIO=1 answers from APPT_FAKE_GMAIL, a JSON file:
 * { address, messages: [{messageId, threadId, messageTimestamp, sender, subject, messageText}],
 *   fail: "why" (every call fails), failSlug: {SLUG: "why"}, connected: ["gmail", "resend"]
 *   (both when absent; null: the connections list is refused), domains: [{name, status}], sent: [] };
 * every email "sent" is appended to `sent`. An address starting with fail@ is
 * refused, timeout@ never answers.
 */
const fs = require('fs');
const L = require('./lib');
const C = require('./aptcore');

const SLUG = { profile: 'GMAIL_GET_PROFILE', fetch: 'GMAIL_FETCH_EMAILS', send: 'GMAIL_SEND_EMAIL', reply: 'GMAIL_REPLY_TO_THREAD',
  resendSend: 'RESEND_SEND_EMAIL', resendList: 'RESEND_LIST_EMAILS', resendDomains: 'RESEND_LIST_DOMAINS' };
const NOT_CONNECTED = /no connected account|not connected|connection.*(not found|expired|revoked)|connectedAccount|auth.*(expired|revoked)|invalid_grant/i;

function arrayAt(obj, key, depth = 0) {
  if (!obj || typeof obj !== 'object' || depth > 4) return null;
  if (Array.isArray(obj[key])) return obj[key];
  for (const v of Object.values(obj)) { const f = arrayAt(v, key, depth + 1); if (f) return f; }
  return null;
}
function valueAt(obj, key, depth = 0) {
  if (!obj || typeof obj !== 'object' || depth > 5) return undefined;
  if (obj[key] !== undefined && obj[key] !== null && typeof obj[key] !== 'object') return obj[key];
  for (const v of Object.values(obj)) { const f = valueAt(v, key, depth + 1); if (f !== undefined) return f; }
  return undefined;
}
function timeOf(v) {
  if (v === null || v === undefined || v === '') return null;
  const n = Number(v);
  const d = Number.isFinite(n) && String(v).trim() !== '' ? new Date(n < 1e12 ? n * 1000 : n) : new Date(String(v));
  return Number.isNaN(d.getTime()) ? null : d;
}
const fail = (r) => Object.assign(new Error(r.why), { timeout: !!r.timedOut, notConnected: NOT_CONNECTED.test(String(r.why || '')) });

/** The connected mailbox's address; throws (notConnected) when there is none. */
function profile() {
  const r = L.composio(SLUG.profile, { user_id: 'me' }, 30);
  if (!r.ok) throw fail(r);
  return String(valueAt(r.data, 'emailAddress') || valueAt(r.data, 'email_address') || '').toLowerCase();
}

/** One page of messages, newest first: { messages: [{ id, threadId, at, from, subject, text }], next }. */
function fetch({ query, pageToken, max = 25 }) {
  const args = { user_id: 'me', query, max_results: max, include_payload: true, verbose: true };
  if (pageToken) args.page_token = pageToken;
  const r = L.composio(SLUG.fetch, args, 60);
  if (!r.ok) throw fail(r);
  return {
    messages: (arrayAt(r.data, 'messages') || []).map((m) => ({
      id: String(m.messageId || m.id || ''),
      threadId: String(m.threadId || m.thread_id || ''),
      at: timeOf(m.messageTimestamp || m.internalDate || m.date),
      from: String(m.sender || m.from || ''),
      subject: String(m.subject || (m.preview && m.preview.subject) || ''),
      text: String(m.messageText || (m.preview && m.preview.body) || m.snippet || ''),
      labels: Array.isArray(m.labelIds) ? m.labelIds : [],
    })).filter((m) => m.id),
    next: String(valueAt(r.data, 'nextPageToken') || '') || null,
  };
}

/** A plain-text email from the connected account: { id, threadId }; throws (with .timeout when it may have gone). */
function send({ to, subject, body }) {
  const r = L.composio(SLUG.send, { user_id: 'me', recipient_email: to, subject, body, is_html: false }, 60);
  if (!r.ok) throw fail(r);
  return { id: String(valueAt(r.data, 'id') || '') || null, threadId: String(valueAt(r.data, 'threadId') || '') || null };
}

/** An answer inside the thread the client wrote in. */
function reply({ thread, to, body }) {
  const r = L.composio(SLUG.reply, { user_id: 'me', thread_id: thread, recipient_email: to, message_body: body, is_html: false }, 60);
  if (!r.ok) throw fail(r);
  return { id: String(valueAt(r.data, 'id') || '') || null, threadId: thread };
}

/**
 * The toolkits this workspace has connected (status ACTIVE), from the
 * instance's own list: { ok, has(slug) }, or { ok: false } when it cannot be
 * read (then the cheap calls tell).
 */
function connections() {
  const r = process.env.APPT_FAKE_COMPOSIO === '1' ? fakeConnections() : L.api('GET', '/api/composio/connections?view=brief', undefined, 20);
  if (!r.ok) return { ok: false, why: r.why };
  const d = r.data || {};
  const slug = (x) => String((x && typeof x === 'object' ? (x.slug || x.name) : x) || '').toLowerCase();
  const active = Array.isArray(d.connections)
    ? d.connections.filter((c) => !c.status || /^active$/i.test(String(c.status))).map((c) => slug(c.toolkit))
    : (Array.isArray(d.toolkits) ? d.toolkits.map(slug) : null);
  if (!active) return { ok: false, why: 'The connections list had no toolkits' };
  const set = new Set(active);
  return { ok: true, has: (k) => set.has(k) };
}

/** Does Resend answer? One read of its latest email; nothing is sent. Throws (notConnected) when not. */
function resendPing() {
  const r = L.composio(SLUG.resendList, { limit: 1 }, 30);
  if (!r.ok) throw fail(r);
  return true;
}

/** Resend's domains: { all: [{ name, status }], verified: ['example.com'] }; throws when Resend does not answer. */
function resendDomains() {
  const r = L.composio(SLUG.resendDomains, {}, 30);
  if (!r.ok) throw fail(r);
  const list = (arrayAt(r.data, 'data') || arrayAt(r.data, 'domains') || []).filter((d) => d && typeof d === 'object' && d.name);
  const all = list.map((d) => ({ name: String(d.name).toLowerCase(), status: String(d.status || '').toLowerCase() }));
  return { all, verified: all.filter((d) => d.status === 'verified').map((d) => d.name) };
}

/** A plain-text email through Resend, "Name <from>" and the reply-to from Settings: { id }; throws (with .timeout when it may have gone). */
function resendSend(s, { to, subject, body }) {
  const from = C.normEmail(s.resend_from);
  if (!C.isEmail(from)) throw Object.assign(new Error('No From address for Resend in Settings'), { noFrom: true });
  const args = { from: C.fromLine(s.resend_from_name || s.business_name, from), to, subject, text: body };
  if (C.isEmail(s.resend_reply_to)) args.reply_to = C.normEmail(s.resend_reply_to);
  const r = L.composio(SLUG.resendSend, args, 60);
  if (!r.ok) throw fail(r);
  return { id: String(valueAt(r.data, 'id') || '') || null, threadId: null };
}

/** A queued email through the sender Settings chose: Gmail answers inside the client's thread; Resend has no threads. */
function deliver(s, m) {
  const via = C.senderOf(s);
  try {
    if (via === 'resend') return Object.assign(resendSend(s, { to: m.to_email, subject: m.subject, body: m.body }), { via });
    return Object.assign(m.thread_id ? reply({ thread: m.thread_id, to: m.to_email, body: m.body }) : send({ to: m.to_email, subject: m.subject, body: m.body }), { via });
  } catch (e) { throw Object.assign(e, { via }); }
}

// ── the fake, for tests and the local harness ────────────────────────────
function fakeData() {
  try { return JSON.parse(fs.readFileSync(process.env.APPT_FAKE_GMAIL, 'utf8')); } catch { return {}; }
}
function fakeConnections() {
  const d = fakeData();
  if (d.connected === null) return { ok: false, why: 'Instance discovery requires a workspace admin. (fake)' };
  const on = d.connected || ['gmail', 'resend'];
  return { ok: true, data: { toolkits: on, connections: on.map((k) => ({ id: `ca_${k}`, toolkit: k, status: 'ACTIVE' })) } };
}
function fake(slug, args) {
  const file = process.env.APPT_FAKE_GMAIL;
  const d = fakeData();
  if (d.fail) return { ok: false, why: d.fail };
  if (d.failSlug && d.failSlug[slug]) return { ok: false, why: d.failSlug[slug] };
  const toolkit = slug.startsWith('RESEND_') ? 'resend' : 'gmail';
  if (Array.isArray(d.connected) && !d.connected.includes(toolkit)) return { ok: false, why: `No connected account found for toolkit ${toolkit} (fake)` };
  const domains = d.domains === undefined ? [{ name: 'appointments-test.example', status: 'verified' }] : d.domains;
  if (slug === SLUG.resendList) return { ok: true, data: { object: 'list', has_more: false, data: [] } };
  if (slug === SLUG.resendDomains) {
    if (domains === null) return { ok: false, why: 'The tool returned no domain list (fake)' };
    return { ok: true, data: { data: { object: 'list', data: domains.map((x, i) => Object.assign({ id: `dom-${i}`, region: 'eu-west-1' }, x)) } } };
  }
  if (slug === SLUG.resendSend) {
    const to = String(args.to || '');
    if (/^fail@/.test(to)) return { ok: false, why: 'Invalid `to` field (fake)' };
    if (/^timeout@/.test(to)) return { ok: false, why: 'Operation timed out (28)', timedOut: true };
    const domain = C.domainOf((String(args.from).match(/<([^>]+)>/) || [])[1] || args.from);
    if (!(domains || []).some((x) => x.name === domain && x.status === 'verified')) return { ok: false, why: `The ${domain} domain is not verified. Please, add and verify your domain on https://resend.com/domains (fake)` };
    d.sent = d.sent || [];
    d.sent.push(Object.assign({ slug }, args));
    if (file) fs.writeFileSync(file, JSON.stringify(d));
    return { ok: true, data: { data: { id: `re-${d.sent.length}` } } };
  }
  if (slug === SLUG.profile) return { ok: true, data: { response_data: { emailAddress: d.address || 'salon@appointments-test.example' } } };
  if (slug === SLUG.fetch) {
    const after = Number((String(args.query).match(/after:(\d+)/) || [])[1] || 0) * 1000;
    const list = (d.messages || []).filter((m) => Number(m.messageTimestamp) >= after).sort((a, b) => Number(b.messageTimestamp) - Number(a.messageTimestamp));
    return { ok: true, data: { messages: list.slice(0, Number(args.max_results) || 25) } };
  }
  if (slug === SLUG.send || slug === SLUG.reply) {
    const to = String(args.recipient_email || '');
    if (/^fail@/.test(to)) return { ok: false, why: 'Invalid To header (fake)' };
    if (/^timeout@/.test(to)) return { ok: false, why: 'Operation timed out (28)', timedOut: true };
    d.sent = d.sent || [];
    d.sent.push(Object.assign({ slug }, args));
    if (file) fs.writeFileSync(file, JSON.stringify(d));
    return { ok: true, data: { response_data: { id: `fake-${d.sent.length}`, threadId: args.thread_id || `thread-${d.sent.length}` } } };
  }
  return { ok: false, why: `fake Composio has no ${slug}` };
}

module.exports = { SLUG, NOT_CONNECTED, connections, profile, fetch, send, reply, resendPing, resendDomains, resendSend, deliver, fake, timeOf };
