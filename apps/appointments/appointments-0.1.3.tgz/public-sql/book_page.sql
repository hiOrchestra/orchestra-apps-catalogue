SELECT st.business_name, st.address, st.phone, st.timezone, st.currency, st.languages, st.default_language, st.intro,
       st.slot_step_min, st.min_notice_min, st.window_days, st.change_hours, st.paused, st.mails,
       s._id AS service_id, s.name, s.category, s.description, s.duration_min, s.price_minor,
       s.buffer_before_min, s.buffer_after_min, s.position
FROM (SELECT business_name, address, phone, timezone, currency, languages, default_language, intro,
             slot_step_min, min_notice_min, window_days, change_hours, paused,
             CASE WHEN COALESCE(emails_on, '') <> 'yes' THEN 'no'
                  WHEN sender = 'resend' THEN CASE WHEN resend_status = 'ok' AND COALESCE(resend_from, '') <> '' AND resend_checked_from = lower(trim(resend_from))
                                                   AND COALESCE(resend_from_status, '') <> 'unverified' THEN 'yes' ELSE 'no' END
                  WHEN gmail_status = 'ok' THEN 'yes' ELSE 'no' END AS mails
      FROM ap_settings WHERE _deleted = 0 ORDER BY _id LIMIT 1) st
LEFT JOIN ap_services s ON s._deleted = 0 AND s.active = 'yes'
