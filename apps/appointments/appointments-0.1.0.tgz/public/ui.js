// The pieces of the booking page: the business on top, a state with nothing
// to pick, the services, the people, the days and times, the details form.
// Times are the business's (the salon is a place), in its own zone.
const { el } = Orch;
const S = window.AptSched;
const C = window.AptCore;

export function page(lang) {
  const loc = lang === 'en' ? 'en-GB' : 'es-ES';
  return {
    day: (day) => new Intl.DateTimeFormat(loc, { timeZone: 'UTC', weekday: 'long', day: 'numeric', month: 'long' }).format(new Date(`${day}T12:00:00Z`)),
    short: (day) => new Intl.DateTimeFormat(loc, { timeZone: 'UTC', weekday: 'short', day: 'numeric' }).format(new Date(`${day}T12:00:00Z`)),
    month: (day) => new Intl.DateTimeFormat(loc, { timeZone: 'UTC', month: 'short' }).format(new Date(`${day}T12:00:00Z`)),
  };
}

/** The business: its name, address and phone, and the language switch. */
export function top(biz, lang, langs, setLang) {
  return el('header', { class: 'bp-top' }, [
    el('div', { class: 'bp-top__row' }, [
      el('p', { class: 'bp-biz' }, biz.name || ''),
      langs.length > 1 ? el('div', { class: 'bp-langs', role: 'group', 'aria-label': 'Language' }, langs.map((l) => el('button', {
        type: 'button', class: 'bp-lang', 'aria-pressed': l === lang ? 'true' : 'false', onClick: () => setLang(l) }, l.toUpperCase()))) : null,
    ]),
    biz.address || biz.phone ? el('p', { class: 'bp-where' }, [biz.address || '', biz.address && biz.phone ? ' · ' : '',
      biz.phone ? el('a', { href: `tel:${biz.phone.replace(/[^\d+]/g, '')}` }, biz.phone) : '']) : null,
    biz.intro ? el('p', { class: 'bp-text' }, biz.intro) : null,
  ]);
}

export function state(title, text, extra) {
  return el('section', { class: 'bp-card bp-state', 'aria-live': 'polite' }, [
    el('h1', { class: 'bp-title', tabindex: '-1' }, title),
    text ? el('p', { class: 'bp-text' }, text) : null,
    extra || null,
  ]);
}
export const back = (label, go) => el('button', { type: 'button', class: 'bp-back', onClick: go }, `← ${label}`);

/** Services, grouped by category: name, length and price, and the line under it. */
export function services(list, w, currency, lang, open) {
  const groups = new Map();
  for (const x of list) { const k = x.category || ''; if (!groups.has(k)) groups.set(k, []); groups.get(k).push(x); }
  return el('div', { class: 'bp-groups' }, [...groups].map(([cat, rows]) => el('section', { class: 'bp-group' }, [
    cat ? el('h2', { class: 'bp-eyebrow' }, cat) : null,
    el('ul', { class: 'bp-list' }, rows.map((x) => el('li', {}, el('button', { type: 'button', class: 'bp-item', onClick: () => open(x) }, [
      el('span', { class: 'bp-item__main' }, [el('span', { class: 'bp-item__name' }, x.name), x.description ? el('span', { class: 'bp-item__sub' }, x.description) : null]),
      el('span', { class: 'bp-item__facts' }, [el('span', { class: 'bp-mono' }, `${x.duration_min} ${w.min}`), Number(x.price_minor) ? el('span', C.money(x.price_minor, currency, lang)) : null]),
    ])))),
  ])));
}

/** "Whoever is free", then each person who does it. */
export function people(list, w, open) {
  return el('ul', { class: 'bp-list' }, [
    el('li', {}, el('button', { type: 'button', class: 'bp-item', onClick: () => open(0) }, [
      el('span', { class: 'bp-item__main' }, [el('span', { class: 'bp-item__name' }, w.anyone), el('span', { class: 'bp-item__sub' }, w.anyoneSub)]),
    ])),
    ...list.map((p) => el('li', {}, el('button', { type: 'button', class: 'bp-item', onClick: () => open(p._id) }, [
      el('span', { class: 'bp-item__main' }, el('span', { class: 'bp-item__name' }, p.name)),
    ]))),
  ]);
}

/** The days with free times (a strip), then the times of the day picked. */
export function picker(days, day, times, w, fmt, tz, onDay, onTime) {
  return el('div', { class: 'bp-pick' }, [
    el('div', { class: 'bp-days', role: 'group', 'aria-label': w.when }, days.map((d) => el('button', {
      type: 'button', class: 'bp-day', 'aria-pressed': d.day === day ? 'true' : 'false', onClick: () => onDay(d.day),
    }, [el('span', { class: 'bp-day__m' }, fmt.month(d.day)), el('span', fmt.short(d.day))]))),
    el('section', { class: 'bp-times', 'aria-label': fmt.day(day) }, [
      el('h2', { class: 'bp-h2' }, fmt.day(day)),
      times.length ? el('div', { class: 'bp-times__grid' }, times.map((t) => el('button', { type: 'button', class: 'bp-time', onClick: () => onTime(t) },
        S.localTime(S.ms(t.start_at), tz)))) : el('p', { class: 'bp-note' }, w.noTimes),
    ]),
  ]);
}

/** Name, email, phone and a note; the bot trap off-screen. */
export function details(w, saved) {
  const field = (label, control, help) => el('label', { class: 'oc-field bp-field' }, [el('span', { class: 'oc-label' }, label), control, help ? el('span', { class: 'oc-help' }, help) : null]);
  const name = el('input', { class: 'oc-input', name: 'name', autocomplete: 'name', required: true, maxlength: '120', value: saved.name || '' });
  const email = el('input', { class: 'oc-input', name: 'email', type: 'email', autocomplete: 'email', required: true, maxlength: '200', value: saved.email || '' });
  const phone = el('input', { class: 'oc-input', name: 'phone', type: 'tel', autocomplete: 'tel', required: true, maxlength: '25', value: saved.phone || '' });
  const note = el('textarea', { class: 'oc-textarea', name: 'note', rows: '2', maxlength: '500' }, saved.note || '');
  const trap = el('input', { class: 'bp-trap', type: 'text', name: 'website_url', tabindex: '-1', autocomplete: 'off', 'aria-hidden': 'true' });
  return {
    nodes: [field(w.name, name), field(w.email, email, w.emailHelp), field(w.phone, phone), field(w.note, note), trap],
    read: () => ({ name: name.value.trim(), email: email.value.trim(), phone: phone.value.trim(), note: note.value.trim(), hp: trap.value }),
  };
}
