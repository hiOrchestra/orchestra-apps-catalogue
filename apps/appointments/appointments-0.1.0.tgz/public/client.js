// The client's own link (#/c/<token>): their appointment, and until the
// deadline of the business, Change (the same free times, without their own
// booking in the way) and Cancel (two steps). After the deadline it says to
// call, with the number. Nothing here is readable without the token: the
// public view holds a hash and a sealed box (aptcore.js).
import { C, S, answer, busy, lang, load, newId, opened, processNow, rules, send, show, site, w } from './site.js';
import { back, page, picker, state } from './ui.js';

const { el, router } = Orch;

export async function clientPage({ token }, note) {
  const again = () => clientPage({ token }, note);
  let box;
  try { await load(); box = C.TOKEN.test(token) ? await opened(token) : null; } catch { show(again, state(w().loadFail, w().loadFailText)); return; }
  if (!box || !box.booking) { show(again, state(w().notFound, w().notFoundText)); return; }
  const b = box.booking;
  const fmt = page(lang());
  const at = { day: fmt.day(S.localDay(S.ms(b.start_at), box.tz)), time: S.localTime(S.ms(b.start_at), box.tz) };
  const open = box.state === 'booked' && Date.now() <= S.ms(box.change_until);
  const until = box.change_until ? `${fmt.day(S.localDay(S.ms(box.change_until), box.tz))}, ${S.localTime(S.ms(box.change_until), box.tz)}` : '';
  const status = el('p', { class: 'bp-status', role: 'status', 'aria-live': 'polite' }, note || '');
  const ask = el('div', { class: 'bp-confirm', hidden: true });
  const phone = box.business.phone;
  const actions = [];
  if (open) {
    actions.push(el('p', { class: 'bp-note' }, w().until(until)), el('div', { class: 'bp-row' }, [
      el('button', { type: 'button', class: 'oc-btn oc-btn--primary', onClick: () => change(token, box) }, w().change),
      el('button', { type: 'button', class: 'oc-btn oc-btn--ghost', onClick: () => { ask.hidden = false; } }, w().cancel),
    ]));
    ask.append(el('p', { class: 'bp-text' }, w().cancelAsk(at)), el('div', { class: 'bp-row' }, [
      el('button', { type: 'button', class: 'oc-btn oc-btn--danger', onClick: async (e) => {
        e.target.disabled = true;
        const r = await ask_(token, { kind: 'cancel' }, status);
        clientPage({ token }, r && r.last.ok ? w().cancelled : (r && r.last.code === 'deadline' ? w().deadline : w().sendFail));
      } }, w().cancelYes),
      el('button', { type: 'button', class: 'oc-btn oc-btn--ghost', onClick: () => { ask.hidden = true; } }, w().keepIt),
    ]));
  } else if (box.state === 'booked') {
    actions.push(el('div', { class: 'bp-late' }, [el('p', { class: 'bp-h2' }, w().lateTitle), el('p', { class: 'bp-text' }, w().late(phone)),
      phone ? el('a', { class: 'oc-btn', href: `tel:${phone.replace(/[^\d+]/g, '')}` }, `${w().call} ${phone}`) : null]));
  } else {
    actions.push(el('button', { type: 'button', class: 'oc-btn', onClick: () => { try { sessionStorage.setItem('apt:src', 'link'); } catch { /* none */ } router.go('/'); } }, w().bookAgain));
  }
  const tone = { booked: 'good', cancelled: 'warn', past: '' }[box.state] || '';
  show(again,
    el('div', { class: 'bp-row bp-row--between' }, [el('h1', { class: 'bp-title' }, w().yours), el('span', { class: `oc-badge${tone ? ` oc-badge--${tone}` : ''}` }, w().state[box.state] || box.state)]),
    el('dl', { class: 'bp-facts' }, [
      [b.service, b.staff ? `${w().with} ${b.staff}` : ''],
      [`${at.day}`, `${at.time}`],
      box.business.address ? [w().where, box.business.address] : null,
      b.price ? [C.money(b.price, b.currency, lang()), ''] : null,
    ].filter(Boolean).map(([k, v]) => el('div', { class: 'bp-fact' }, [el('dt', k), v ? el('dd', v) : null]))),
    status, ...actions, ask);
}

/** Send a cancel or a move for this token and wait for how it went. */
async function ask_(token, params, status) {
  const visit = newId();
  try { await send(Object.assign({ token, visit }, params), status); } catch { status.textContent = w().sendFail; return null; }
  processNow();
  status.textContent = w().working;
  return answer(token, visit);
}

/** The free times for the same service, with the same person (or anyone), without this booking in the way. */
async function change(token, box, day) {
  const b = box.booking;
  const rows = await busy(true);
  const cb = S.combo(site.services, b.service_ids);
  if (!cb.ok) { clientPage({ token }, w().changeFail); return; }
  const mine = { staff_id: b.staff_id, busy_from: S.iso(S.ms(b.start_at) - cb.before * 60000), busy_to: S.iso(S.ms(b.end_at) + cb.after * 60000) };
  const d = rules(rows, mine);
  const pid = b.any ? 0 : b.staff_id;
  const days = S.openDays(d, cb.ids, pid, 62);
  const status = el('p', { class: 'bp-status', role: 'status', 'aria-live': 'polite' });
  const again = () => change(token, box, day);
  if (!days.length) { show(again, back(w().back, () => clientPage({ token })), el('p', { class: 'bp-text' }, w().noDays)); return; }
  const pick = days.some((x) => x.day === day) ? day : days[0].day;
  show(again, back(w().back, () => clientPage({ token })), el('h1', { class: 'bp-title' }, w().change), el('p', { class: 'bp-chosen' }, `${b.service}${b.staff && !b.any ? ` · ${b.staff}` : ''}`),
    picker(days, pick, S.slots(d, cb.ids, pid, pick), w(), page(lang()), box.tz, (x) => change(token, box, x), async (t) => {
      const r = await ask_(token, { kind: 'reschedule', start_at: t.start_at, staff_id: pid }, status);
      if (r && r.last.ok) { clientPage({ token }, w().moved); return; }
      if (r && r.last.code === 'deadline') { clientPage({ token }, w().deadline); return; }
      status.textContent = w().changeFail;
      setTimeout(() => change(token, r || box, pick), 1500);
    }), status);
}
