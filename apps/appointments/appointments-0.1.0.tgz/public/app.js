// The booking page: service → who (or whoever is free) → day and time →
// your details → booked, in a few seconds, with a private link to change or
// cancel. #/c/<token> is that link (client.js). Free times are worked out
// here with the same rules the server uses (sched.js) on the approved public
// views; the server judges the booking again, so a time taken a second
// earlier comes back as "just taken" with the nearest free ones.
import { C, S, answer, busy, channel, lang, load, newId, processNow, remember, rules, send, show, site, store, w, linkFor } from './site.js';
import { back, details, page, people, picker, services, state } from './ui.js';
import { clientPage } from './client.js';

const { el, router } = Orch;

function trouble(e, again) {
  if (e && (e.reason === 'public-view-pending' || e.status === 403)) return Orch.mount('page', state(w().closedTitle, w().closedText));
  if (e && e.status === 429) return Orch.mount('page', state(w().manyTitle, w().manyText, el('button', { type: 'button', class: 'oc-btn', onClick: again }, w().retry)));
  return Orch.mount('page', state(w().loadFail, w().loadFailText, el('button', { type: 'button', class: 'oc-btn', onClick: again }, w().retry)));
}
const ready = () => site && site.services.length && site.staff.length;
const svc = (id) => site.services.find((x) => Number(x._id) === Number(id));
const doers = (id) => site.staff.filter((p) => S.does(p, [id]));

async function home() {
  const again = () => home();
  try { await load(); } catch (e) { trouble(e, again); return; }
  if (site.s.paused === 'yes') { show(again, state(w().pausedTitle, w().pausedText)); return; }
  if (!ready()) { show(again, state(w().closedTitle, w().closedText)); return; }
  show(again, el('h1', { class: 'bp-title' }, w().pick), services(site.services, w(), site.s.currency, lang(), (x) => router.go(`/s/${x._id}`)));
}

async function who({ sid }) {
  const again = () => who({ sid });
  try { await load(); } catch (e) { trouble(e, again); return; }
  const x = svc(sid);
  if (!x || !ready()) { router.go('/', { replace: true }); return; }
  const list = doers(x._id);
  if (list.length === 1) { router.go(`/s/${sid}/${list[0]._id}`, { replace: true }); return; }
  show(again, back(w().back, () => router.go('/')), el('h1', { class: 'bp-title' }, w().who), el('p', { class: 'bp-chosen' }, `${x.name} · ${x.duration_min} ${w().min}`),
    people(list, w(), (pid) => router.go(`/s/${sid}/${pid}`)));
}

let chosenDay = null;
async function when({ sid, pid }, keep) {
  const again = () => when({ sid, pid }, keep);
  let rows;
  try { await load(); rows = await busy(); } catch (e) { trouble(e, again); return; }
  const x = svc(sid);
  if (!x) { router.go('/', { replace: true }); return; }
  const person = site.staff.find((p) => Number(p._id) === Number(pid));
  const d = rules(rows);
  const days = S.openDays(d, [x._id], Number(pid) || 0, 62);
  const head = [back(w().back, () => router.go(doers(x._id).length > 1 ? `/s/${sid}` : '/')), el('h1', { class: 'bp-title' }, w().when),
    el('p', { class: 'bp-chosen' }, `${x.name} · ${person ? person.name : w().anyone}`)];
  if (!days.length) { show(again, ...head, el('p', { class: 'bp-text' }, w().noDays)); return; }
  if (!days.some((z) => z.day === chosenDay)) chosenDay = days[0].day;
  const fmt = page(lang());
  show(again, ...head, picker(days, chosenDay, S.slots(d, [x._id], Number(pid) || 0, chosenDay), w(), fmt, site.s.timezone,
    (day) => { chosenDay = day; when({ sid, pid }, keep); }, (t) => form(x, Number(pid) || 0, t, keep)),
  el('p', { class: 'bp-note' }, w().zone(site.s.timezone.replace(/_/g, ' '))));
}

/** "Thursday 8 October, 18:00" in the business's zone and the page's language. */
function said(t) {
  const fmt = page(lang());
  return { day: fmt.day(S.localDay(S.ms(t.start_at), site.s.timezone)), time: S.localTime(S.ms(t.start_at), site.s.timezone) };
}

function form(x, pid, t, keep) {
  const again = () => form(x, pid, t, keep);
  const saved = Object.assign({}, store.get('apt:me', {}), keep || {});
  const d = details(w(), saved);
  const status = el('p', { class: 'bp-status', role: 'status', 'aria-live': 'polite' });
  const go = el('button', { type: 'submit', class: 'oc-btn oc-btn--primary bp-send' }, w().book);
  const person = site.staff.find((p) => Number(p._id) === Number(pid));
  const at = said(t);
  const f = el('form', { class: 'bp-form' }, [
    el('div', { class: 'bp-summary' }, [el('p', { class: 'bp-summary__what' }, `${x.name}${person ? ` · ${person.name}` : ''}`),
      el('p', { class: 'bp-summary__when' }, `${at.day}, ${at.time}`), back(w().another, () => when({ sid: x._id, pid }, d.read()))]),
    el('h2', { class: 'bp-h2' }, w().details),
    ...d.nodes, go, status, el('p', { class: 'bp-note' }, w().privacy),
  ]);
  f.addEventListener('input', () => { const v = d.read(); store.set('apt:me', { name: v.name, email: v.email, phone: v.phone }); });
  f.addEventListener('submit', async (e) => {
    e.preventDefault();
    if (!f.reportValidity()) return;
    go.disabled = true;
    const v = d.read();
    const token = C.newToken();
    const visit = newId();
    try {
      await send({ kind: 'new', token, visit, service_id: x._id, service_ids: JSON.stringify([x._id]), staff_id: pid, start_at: t.start_at,
        name: v.name, email: v.email, phone: v.phone, note: v.note, hp: v.hp, channel: channel() }, status);
    } catch {
      go.disabled = false;
      status.textContent = w().sendFail;
      return;
    }
    remember(token);
    processNow();
    show(again, state(w().waitTitle, w().waitText));
    const box = await answer(token, visit);
    if (!box) { show(again, state(w().slowTitle, w().slowText, el('a', { href: `#/c/${token}`, class: 'bp-link' }, linkFor(token)))); return; }
    if (box.state === 'booked') { booked(box, v, token); return; }
    failed(box, x, pid, v);
  });
  show(again, f);
}

function booked(box, v, token) {
  const b = box.booking;
  const at = said(b);
  const link = linkFor(token);
  show(() => booked(box, v, token), state(w().doneTitle, w().doneText({ service: b.service, staff: b.staff, day: at.day, time: at.time }), el('div', { class: 'bp-stack' }, [
    el('p', { class: 'bp-text' }, w().doneMail(v.email)),
    el('p', { class: 'bp-note' }, w().keep),
    el('div', { class: 'bp-linkrow' }, [el('a', { href: `#/c/${token}`, class: 'bp-link' }, link),
      el('button', { type: 'button', class: 'oc-btn oc-btn--sm', onClick: async () => { try { await navigator.clipboard.writeText(link); Orch.toast(w().copied); } catch { /* select it */ } } }, w().copy)]),
  ])));
}

function failed(box, x, pid, v) {
  const code = box.last && box.last.code;
  const text = code === 'paused' ? w().failPaused : code === 'details' ? w().failDetails : (box.alternatives || []).length ? w().failText : w().failGeneric;
  show(() => failed(box, x, pid, v), state(w().failTitle, text, el('div', { class: 'bp-stack' }, [
    el('div', { class: 'bp-times__grid' }, (box.alternatives || []).map((a) => {
      const at = said(a);
      return el('button', { type: 'button', class: 'bp-time bp-time--wide', onClick: () => form(x, a.staff_id || pid, a, v) }, `${at.day.split(' ').slice(0, 2).join(' ')} ${at.time}${a.staff_name ? ` · ${a.staff_name}` : ''}`);
    })),
    el('button', { type: 'button', class: 'oc-btn oc-btn--ghost', onClick: () => when({ sid: x._id, pid }, v) }, w().failOther),
  ])));
}

router.define({ '/': home, '/s/:sid': who, '/s/:sid/:pid': (p) => when(p), '/c/:token': (p) => clientPage(p) }, () => home()).start();
