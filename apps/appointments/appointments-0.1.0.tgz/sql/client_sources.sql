SELECT c._id, c.name, c.first_channel, c._created_at AS since,
  (SELECT b.price_minor FROM ap_bookings b WHERE b._deleted = 0 AND b.client_id = c._id ORDER BY b._id LIMIT 1) AS first_price,
  CASE WHEN c.first_channel LIKE 'marketplace:%' AND EXISTS (
    SELECT 1 FROM ap_bookings b WHERE b._deleted = 0 AND b.client_id = c._id AND b.status IN ('Booked', 'Arrived')
      AND COALESCE(b.channel, '') NOT LIKE 'marketplace:%') THEN 'yes' ELSE 'no' END AS recovered
FROM ap_clients c
WHERE c._deleted = 0
