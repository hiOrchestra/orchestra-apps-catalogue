SELECT c._id, c.name, c.phone, c.email, c.notes, c.language, c._created_at AS since,
  (SELECT COUNT(*) FROM ap_bookings b WHERE b._deleted = 0 AND b.client_id = c._id
     AND (b.status = 'Arrived' OR (b.status = 'Booked' AND b.start_at <= strftime('%Y-%m-%dT%H:%M:%SZ', 'now')))) AS visits,
  (SELECT COUNT(*) FROM ap_bookings b WHERE b._deleted = 0 AND b.client_id = c._id AND b.status = 'NoShow') AS no_shows,
  (SELECT MIN(b.start_at) FROM ap_bookings b WHERE b._deleted = 0 AND b.client_id = c._id AND b.status = 'Booked'
     AND b.start_at > strftime('%Y-%m-%dT%H:%M:%SZ', 'now')) AS next_at,
  (SELECT MAX(b.start_at) FROM ap_bookings b WHERE b._deleted = 0 AND b.client_id = c._id AND b.status IN ('Arrived', 'Booked')
     AND b.start_at <= strftime('%Y-%m-%dT%H:%M:%SZ', 'now')) AS last_at
FROM ap_clients c
WHERE c._deleted = 0
