SELECT c._id AS client_id, c.name, c.phone, c.email, s._id AS service_id, s.name AS service, s.rebook_weeks,
       MAX(b.start_at) AS last_at,
       date(MAX(b.start_at), '+' || (s.rebook_weeks * 7) || ' days') AS due_on,
       (SELECT MAX(e._created_at) FROM ap_emails e WHERE e._deleted = 0 AND e.client_id = c._id AND e.purpose = 'rebook') AS invited_at
FROM ap_bookings b
JOIN ap_clients c ON c._id = b.client_id AND c._deleted = 0
JOIN ap_services s ON s._id = b.service_id AND s._deleted = 0
WHERE b._deleted = 0 AND s.rebook_weeks > 0
  AND (b.status = 'Arrived' OR (b.status = 'Booked' AND b.start_at <= strftime('%Y-%m-%dT%H:%M:%SZ', 'now')))
  AND NOT EXISTS (SELECT 1 FROM ap_bookings f WHERE f._deleted = 0 AND f.client_id = c._id AND f.status = 'Booked'
                  AND f.start_at > strftime('%Y-%m-%dT%H:%M:%SZ', 'now'))
GROUP BY c._id, s._id
HAVING due_on <= date('now')
