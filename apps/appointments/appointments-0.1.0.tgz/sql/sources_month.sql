SELECT COALESCE(NULLIF(b.channel, ''), b.source, 'other') AS channel,
  SUM(CASE WHEN b._created_at >= datetime('now', 'start of month') THEN 1 ELSE 0 END) AS this_month,
  SUM(CASE WHEN b._created_at < datetime('now', 'start of month') THEN 1 ELSE 0 END) AS last_month,
  SUM(CASE WHEN b._created_at >= datetime('now', 'start of month') AND b.moved_by = 'client' THEN 1 ELSE 0 END) AS moved_by_client
FROM ap_bookings b
WHERE b._deleted = 0 AND b.status IN ('Booked', 'Arrived', 'NoShow')
  AND b._created_at >= datetime('now', 'start of month', '-1 month')
GROUP BY 1
