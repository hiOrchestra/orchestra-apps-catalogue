SELECT _id AS staff_id, name, hours, services, max_per_day, position
FROM ap_staff
WHERE _deleted = 0 AND active = 'yes'
