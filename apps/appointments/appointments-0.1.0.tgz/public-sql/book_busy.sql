SELECT staff_id, busy_from AS start_at, busy_to AS end_at, 'booking' AS kind, _id AS booking_id
FROM ap_bookings
WHERE _deleted = 0 AND status IN ('Booked', 'Arrived') AND busy_to > strftime('%Y-%m-%dT%H:%M:%SZ', 'now', '-1 day')
UNION ALL
SELECT staff_id, start_at, end_at, 'block' AS kind, NULL AS booking_id
FROM ap_blocks
WHERE _deleted = 0 AND active = 'yes' AND end_at > strftime('%Y-%m-%dT%H:%M:%SZ', 'now', '-1 day')
UNION ALL
SELECT staff_id, day_from AS start_at, day_to AS end_at, 'off' AS kind, NULL AS booking_id
FROM ap_time_off
WHERE _deleted = 0 AND active = 'yes' AND day_to >= date('now', '-1 day')
