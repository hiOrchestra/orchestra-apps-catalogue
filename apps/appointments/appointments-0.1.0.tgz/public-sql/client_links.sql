SELECT k, box FROM ap_links WHERE _deleted = 0
