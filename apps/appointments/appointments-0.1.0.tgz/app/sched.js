/**
 * Appointments · the slot rules, in one file that the public page, the desk,
 * the scripts and the agent's tool all run (test/sync.js copies it to app/,
 * public/ and automations/; a test fails when a copy is stale).
 *
 * What it answers: which start times a person (or "anyone") can take for a
 * service on a day, and whether one given request is still allowed, with the
 * clashes listed when it is not.
 *
 *   working hours with breaks  → real UTC ranges for one local day, DST-correct
 *   time off by date           → the day has no ranges
 *   bookings (with buffers) and blocked time → busy spans
 *   minimum notice, booking window, a per-day limit per person
 *   "anyone" → the least booked person that day among those free
 *
 * Every time and length is a multiple of 5 minutes (STEP), so a booking can
 * hold its 5-minute pieces in the database (ap_holds, unique): two people can
 * never be given the same person's time, whichever process wrote first.
 *
 * Sources (all MIT; full texts in THIRD_PARTY_LICENSES):
 *  - mergeBusy, pad, isFree, startsIn: ported from recal-dev/scheduling-sdk
 *    0.7.2 (src/helpers/busy-time/merge.ts, padding.ts, overlap.ts,
 *    slot/generator.ts), Copyright (c) 2025 Torben Köhler. TypeScript types
 *    removed and Date objects replaced by epoch milliseconds; logic unchanged.
 *  - dayRanges: the idea of calcom/cal.diy packages/features/schedules/lib/
 *    date-ranges.ts (main, MIT since 2026-04-15): build each local day from
 *    its wall-clock hours in the zone, so the day of a DST change keeps its
 *    hours; written anew here without dayjs.
 *  - conflictText: the agent-readable 409 of clawnify/OpenSalon
 *    (src/server/scheduling.ts describeConflicts), reworded, ES/EN.
 * Easy!Appointments (GPL) was read for ideas only (breaks, per-date
 * exceptions, blocked periods); nothing of it is here.
 */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.AptSched = api;
}(typeof self !== 'undefined' ? self : this, () => {
  'use strict';

  const MIN = 60000;
  const STEP = 5;
  const DAYS = ['sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat'];
  const ACTIVE = ['Booked', 'Arrived'];

  // ── vendored: recal-dev/scheduling-sdk 0.7.2 (MIT, (c) 2025 Torben Köhler) ──
  /** Combines overlapping and adjacent busy spans into one each (fresh objects, sorted). */
  function mergeBusy(busy) {
    if (busy.length <= 1) return busy.map((b) => ({ start: b.start, end: b.end }));
    const sorted = busy.slice().sort((a, b) => a.start - b.start);
    const merged = [{ start: sorted[0].start, end: sorted[0].end }];
    for (let i = 1; i < sorted.length; i++) {
      const cur = sorted[i];
      const last = merged[merged.length - 1];
      if (cur.start > last.end) merged.push({ start: cur.start, end: cur.end });
      else if (cur.end > last.end) last.end = cur.end;
    }
    return merged;
  }
  /** Busy spans grown by `minutes` on both sides. */
  function pad(busy, minutes) {
    if (!minutes || !busy.length) return busy;
    const ms = minutes * MIN;
    return busy.map((b) => ({ start: b.start - ms, end: b.end + ms }));
  }
  /** True when the slot touches none of the busy spans (sorted by start; zero-length spans never block). */
  function isFree(slot, busy) {
    for (let i = 0; i < busy.length; i++) {
      const b = busy[i];
      if (b.start >= slot.end) break;
      if (b.start !== b.end && slot.start < b.end && b.start < slot.end) return false;
    }
    return true;
  }
  /** Start times every `stepMin` from `startMs`, each with `durMin` that still ends by `endMs`. */
  function startsIn(startMs, endMs, durMin, stepMin) {
    const out = [];
    const dur = durMin * MIN;
    const step = (stepMin || durMin) * MIN;
    for (let t = startMs; t + dur <= endMs; t += step) out.push(t);
    return out;
  }
  // ── end of the vendored part ──────────────────────────────────────────────

  // ── time in a zone ──────────────────────────────────────────────────────
  const fmtCache = {};
  function zone(tz) { try { new Intl.DateTimeFormat('en-CA', { timeZone: tz }); return tz; } catch { return 'UTC'; } }
  function parts(ms, tz) {
    const f = fmtCache[tz] || (fmtCache[tz] = new Intl.DateTimeFormat('en-CA', {
      timeZone: tz, year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hourCycle: 'h23',
    }));
    const o = {};
    for (const p of f.formatToParts(new Date(ms))) o[p.type] = p.value;
    return o;
  }
  /** 'YYYY-MM-DD' of an instant on the wall in `tz`. */
  const localDay = (ms, tz) => { const p = parts(ms, tz); return `${p.year}-${p.month}-${p.day}`; };
  /** 'HH:MM' of an instant on the wall in `tz`. */
  const localTime = (ms, tz) => { const p = parts(ms, tz); return `${p.hour}:${p.minute}`; };
  function addDays(day, n) {
    const [y, m, d] = String(day).split('-').map(Number);
    return new Date(Date.UTC(y, m - 1, d + n)).toISOString().slice(0, 10);
  }
  const weekday = (day) => DAYS[new Date(`${day}T12:00:00Z`).getUTCDay()];
  const realDay = (s) => /^\d{4}-\d{2}-\d{2}$/.test(String(s || '')) && new Date(`${s}T00:00:00Z`).toISOString().slice(0, 10) === s;
  /** Minutes past midnight of 'HH:MM' (24:00 allowed as the end of a day), or null. */
  function hm(s) {
    const m = /^(\d{1,2}):(\d{2})$/.exec(String(s || '').trim());
    if (!m) return null;
    const h = Number(m[1]);
    const mi = Number(m[2]);
    if (h > 24 || mi > 59 || (h === 24 && mi)) return null;
    return h * 60 + mi;
  }
  /**
   * The UTC instant of a wall-clock time in `tz`, corrected twice for the DST
   * edge: a time that does not exist (the hour skipped in spring) lands an
   * hour later; one that happens twice (autumn) is the second.
   */
  function localToUtc(day, hhmm, tz) {
    const [y, m, d] = String(day).split('-').map(Number);
    const mins = hm(hhmm);
    const want = Date.UTC(y, m - 1, d, Math.floor(mins / 60), mins % 60);
    let t = want;
    for (let i = 0; i < 2; i++) {
      const p = parts(t, tz);
      t -= Date.UTC(+p.year, +p.month - 1, +p.day, +p.hour, +p.minute) - want;
    }
    return t;
  }
  /** 'YYYY-MM-DDTHH:MM:SSZ', the one format times are kept in (so strings compare). */
  const iso = (ms) => `${new Date(ms).toISOString().slice(0, 19)}Z`;
  function ms(v) {
    if (v === null || v === undefined || v === '') return NaN;
    if (typeof v === 'number') return v;
    const s = String(v).trim();
    const x = s.includes('T') ? s : s.replace(' ', 'T');
    return Date.parse(/[zZ]|[+-]\d\d:?\d\d$/.test(x) ? x : `${x}Z`);
  }

  // ── the business's data, read forgivingly ───────────────────────────────
  function json(v, fallback) {
    if (v === null || v === undefined || v === '') return fallback;
    if (typeof v === 'object') return v;
    try { return JSON.parse(v); } catch { return fallback; }
  }
  /** Weekly hours as {mon: [[a, b], …]}: the gaps between ranges are the breaks. Bad ranges are dropped. */
  function hoursOf(v) {
    const h = json(v, {});
    const out = {};
    for (const d of DAYS) {
      const list = (Array.isArray(h[d]) ? h[d] : [])
        .map((r) => [hm(r && r[0]), hm(r && r[1])])
        .filter(([a, b]) => a !== null && b !== null && a < b)
        .sort((x, y) => x[0] - y[0]);
      const merged = [];
      for (const r of list) {
        const last = merged[merged.length - 1];
        if (last && r[0] <= last[1]) last[1] = Math.max(last[1], r[1]); else merged.push(r.slice());
      }
      out[d] = merged.map(([a, b]) => [clock(a), clock(b)]);
    }
    return out;
  }
  const clock = (m) => `${String(Math.floor(m / 60)).padStart(2, '0')}:${String(m % 60).padStart(2, '0')}`;
  const servicesOf = (staff) => json(staff && staff.services, []).map(Number).filter(Number.isFinite);
  const does = (staff, ids) => { const mine = servicesOf(staff); return ids.every((id) => mine.includes(Number(id))); };
  const on = (row) => String((row && row.active) || 'yes') === 'yes';

  /**
   * The working ranges of one local day, as UTC milliseconds (cal.diy's idea:
   * each day built from its own wall clock, so a DST day keeps 09:00–19:00).
   */
  function dayRanges(hours, day, tz) {
    return (hoursOf(hours)[weekday(day)] || []).map(([a, b]) => ({
      start: localToUtc(day, a, tz),
      end: b === '24:00' ? localToUtc(addDays(day, 1), '00:00', tz) : localToUtc(day, b, tz),
    })).filter((r) => r.start < r.end);
  }
  /** Time off by date: rows {staff_id (0 = everybody: the business is closed), day_from, day_to}. */
  const isOff = (staffId, day, offs) => (offs || []).some((o) => (Number(o.staff_id) === 0 || Number(o.staff_id) === Number(staffId))
    && String(o.day_from) <= day && day <= String(o.day_to || o.day_from));

  /**
   * Several services done one after the other by one person: their lengths
   * add up, the first's buffer before and the last's after.
   */
  function combo(services, ids) {
    const list = (Array.isArray(ids) ? ids : [ids]).map(Number).filter(Number.isFinite);
    const rows = list.map((id) => (services || []).find((s) => Number(s._id) === id));
    if (!list.length || rows.some((s) => !s || !on(s))) return { ok: false, problem: 'service' };
    const n = (v) => Math.max(0, Number(v) || 0);
    const duration = rows.reduce((t, s) => t + n(s.duration_min), 0);
    const before = n(rows[0].buffer_before_min);
    const after = n(rows[rows.length - 1].buffer_after_min);
    if (!duration || [duration, before, after].some((x) => x % STEP)) return { ok: false, problem: 'length' };
    return { ok: true, ids: list, rows, name: rows.map((s) => s.name).join(' + '), duration, before, after,
      price: rows.reduce((t, s) => t + n(s.price_minor), 0) };
  }

  /** One person's busy spans (bookings already carry their buffers; blocks as they are), merged. */
  function busyOf(staffId, busy, ignore) {
    return mergeBusy((busy || []).filter((b) => b.kind !== 'off' && Number(b.staff_id) === Number(staffId)
      && !(ignore && Number(b.booking_id) === Number(ignore)))
      .map((b) => ({ start: ms(b.start_at), end: ms(b.end_at) })).filter((b) => b.start < b.end));
  }
  /** Bookings a person has on a local day, and their minutes. */
  function load(staffId, day, tz, busy, ignore) {
    let n = 0;
    let minutes = 0;
    for (const b of busy || []) {
      if (b.kind !== 'booking' || Number(b.staff_id) !== Number(staffId) || (ignore && Number(b.booking_id) === Number(ignore))) continue;
      if (localDay(ms(b.start_at), tz) !== day) continue;
      n += 1;
      minutes += (ms(b.end_at) - ms(b.start_at)) / MIN;
    }
    return { n, minutes };
  }

  /** The common context every question needs. */
  function ctxOf(d) {
    const s = d.settings || {};
    const tz = zone(s.timezone || 'UTC');
    const now = typeof d.now === 'number' ? d.now : ms(d.now || new Date().toISOString());
    const today = localDay(now, tz);
    return {
      tz, now, today,
      step: Math.max(STEP, Number(s.slot_step_min) || 15),
      notice: Math.max(0, Number(s.min_notice_min) || 0) * MIN,
      // Bookable up to the end of the window's last day, on the wall.
      until: localToUtc(addDays(today, Math.max(1, Number(s.window_days) || 60) + 1), '00:00', tz),
      services: d.services || [], staff: d.staff || [], busy: d.busy || [], offs: d.offs || [],
    };
  }

  /** What stops one person taking [t, t+duration) for this combo, as a list of reasons (empty: free). */
  function problemsAt(c, person, cb, t, ignore) {
    const out = [];
    const day = localDay(t, c.tz);
    const end = t + cb.duration * MIN;
    if (!on(person)) return [{ code: 'staff' }];
    if (!does(person, cb.ids)) return [{ code: 'staff' }];
    if (t < c.now) out.push({ code: 'past' });
    else if (t < c.now + c.notice) out.push({ code: 'notice' });
    if (t >= c.until) out.push({ code: 'window' });
    if (isOff(person._id, day, c.offs)) out.push({ code: 'off' });
    else if (!dayRanges(person.hours, day, c.tz).some((r) => r.start <= t && end <= r.end)) out.push({ code: 'hours' });
    const max = Number(person.max_per_day) || 0;
    if (max && load(person._id, day, c.tz, c.busy, ignore).n >= max) out.push({ code: 'limit' });
    const span = { start: t - cb.before * MIN, end: end + cb.after * MIN };
    const clashes = (c.busy || []).filter((b) => b.kind !== 'off' && Number(b.staff_id) === Number(person._id)
      && !(ignore && Number(b.booking_id) === Number(ignore)) && ms(b.start_at) < span.end && span.start < ms(b.end_at));
    if (clashes.length) out.push({ code: 'clash', clashes });
    return out;
  }

  /** Free start times for one person on one local day (milliseconds). */
  function startsFor(c, person, cb, day, ignore) {
    if (!on(person) || !does(person, cb.ids) || isOff(person._id, day, c.offs)) return [];
    const max = Number(person.max_per_day) || 0;
    if (max && load(person._id, day, c.tz, c.busy, ignore).n >= max) return [];
    const taken = busyOf(person._id, c.busy, ignore);
    const out = [];
    for (const r of dayRanges(person.hours, day, c.tz)) {
      for (const t of startsIn(r.start, r.end, cb.duration, c.step)) {
        if (t < c.now + c.notice || t >= c.until) continue;
        if (isFree({ start: t - cb.before * MIN, end: t + (cb.duration + cb.after) * MIN }, taken)) out.push(t);
      }
    }
    return out;
  }

  /** People who do every service of the combo and are active, in their order. */
  const staffFor = (c, cb) => c.staff.filter((p) => on(p) && does(p, cb.ids))
    .sort((a, b) => (Number(a.position) || 0) - (Number(b.position) || 0) || Number(a._id) - Number(b._id));

  /**
   * The free times of a day: [{start_at, end_at, staff: [ids free then]}].
   * staffId 0 (or empty) is "anyone": every person who does the services.
   */
  function slots(d, serviceIds, staffId, day) {
    const c = ctxOf(d);
    const cb = combo(c.services, serviceIds);
    if (!cb.ok) return [];
    const people = Number(staffId) ? staffFor(c, cb).filter((p) => Number(p._id) === Number(staffId)) : staffFor(c, cb);
    const at = new Map();
    for (const p of people) for (const t of startsFor(c, p, cb, day, d.ignore)) (at.get(t) || at.set(t, []).get(t)).push(Number(p._id));
    return [...at.keys()].sort((a, b) => a - b).map((t) => ({ start_at: iso(t), end_at: iso(t + cb.duration * MIN), staff: at.get(t) }));
  }
  /** The days (from today, inside the window) that have at least one free time. */
  function openDays(d, serviceIds, staffId, max = 62) {
    const c = ctxOf(d);
    const out = [];
    for (let day = c.today, i = 0; i < max; i++, day = addDays(day, 1)) {
      if (localToUtc(day, '00:00', c.tz) >= c.until) break;
      const n = slots(d, serviceIds, staffId, day).length;
      if (n) out.push({ day, count: n });
    }
    return out;
  }

  /**
   * "Anyone": the person least booked that day among those free, then the one
   * with fewer booked minutes, then their order. Fair without a counter.
   */
  function pickStaff(d, ids, day, ignore) {
    const c = ctxOf(d);
    const rank = ids.map((id) => {
      const p = c.staff.find((x) => Number(x._id) === Number(id)) || {};
      const l = load(id, day, c.tz, c.busy, ignore);
      return { id: Number(id), n: l.n, m: l.minutes, pos: Number(p.position) || 0 };
    }).sort((a, b) => a.n - b.n || a.m - b.m || a.pos - b.pos || a.id - b.id);
    return rank.length ? rank[0].id : null;
  }

  /**
   * Is this request allowed now? The one judgement the page, the desk, the
   * scripts and the agent share.
   *   req: {service_ids, staff_id (0 = anyone), start_at, ignore (a booking being moved)}
   *   override: the owner said "book anyway": the rules and clashes are skipped,
   *             a service the person does not do is not.
   * → {ok: true, staff_id, start_at, end_at, busy_from, busy_to, any, combo, warnings}
   *   or {ok: false, code, clashes: [{staff_id, kind, start_at, end_at, label}]}
   */
  function check(d, req, { override = false } = {}) {
    const c = ctxOf(d);
    const cb = combo(c.services, req.service_ids);
    if (!cb.ok) return { ok: false, code: cb.problem };
    const t = ms(req.start_at);
    if (!Number.isFinite(t)) return { ok: false, code: 'time' };
    if ((t / MIN) % STEP) return { ok: false, code: 'time' };
    const any = !Number(req.staff_id);
    const people = any ? staffFor(c, cb) : c.staff.filter((p) => Number(p._id) === Number(req.staff_id));
    if (!people.length) return { ok: false, code: 'staff' };
    const day = localDay(t, c.tz);
    const judged = people.map((p) => ({ p, problems: problemsAt(c, p, cb, t, req.ignore) }));
    const invalid = (x) => x.problems.some((q) => q.code === 'staff');
    const free = judged.filter((x) => !x.problems.length);
    let chosen = null;
    let warnings = [];
    if (free.length) chosen = any ? pickStaff(d, free.map((x) => x.p._id), day, req.ignore) : Number(free[0].p._id);
    else if (override) {
      const usable = judged.filter((x) => !invalid(x) && !x.problems.some((q) => q.code === 'past'));
      if (usable.length) { chosen = Number(usable[0].p._id); warnings = usable[0].problems.map((q) => q.code); }
    }
    if (!chosen) {
      const worst = judged.filter((x) => !invalid(x));
      if (!worst.length) return { ok: false, code: 'staff' };
      const codes = worst.flatMap((x) => x.problems.map((q) => q.code));
      const order = ['past', 'notice', 'window', 'off', 'hours', 'limit', 'clash'];
      const clashes = worst.flatMap((x) => (x.problems.find((q) => q.code === 'clash') || { clashes: [] }).clashes
        .map((b) => ({ staff_id: Number(x.p._id), staff: x.p.name || '', kind: b.kind, start_at: b.start_at, end_at: b.end_at, label: b.label || '' })));
      return { ok: false, code: order.find((o) => codes.includes(o)) || 'clash', clashes };
    }
    return {
      ok: true, staff_id: chosen, any, combo: cb, warnings,
      start_at: iso(t), end_at: iso(t + cb.duration * MIN),
      busy_from: iso(t - cb.before * MIN), busy_to: iso(t + (cb.duration + cb.after) * MIN),
    };
  }

  /** The free times nearest to a wanted instant, over the next `days` days: [{start_at, staff}] (n of them). */
  function nearest(d, serviceIds, staffId, wantMs, n = 6, days = 14) {
    const c = ctxOf(d);
    const from = localDay(Math.max(wantMs || c.now, c.now), c.tz);
    const out = [];
    for (let i = 0; i < days && out.length < n * 3; i++) out.push(...slots(d, serviceIds, staffId, addDays(from, i)));
    const want = wantMs || c.now;
    return out.sort((a, b) => Math.abs(ms(a.start_at) - want) - Math.abs(ms(b.start_at) - want)).slice(0, n)
      .sort((a, b) => ms(a.start_at) - ms(b.start_at));
  }

  /** The first free time inside a list of wishes [{date, from, to}], in order; null when none fits. */
  function firstWish(d, serviceIds, staffId, wishes) {
    const c = ctxOf(d);
    for (const w of wishes || []) {
      if (!realDay(w.date)) continue;
      const lo = hm(w.from) === null ? -1 : localToUtc(w.date, w.from, c.tz);
      const hi = hm(w.to) === null ? Infinity : localToUtc(w.date, w.to, c.tz);
      const hit = slots(d, serviceIds, staffId, w.date).find((s) => ms(s.start_at) >= lo && ms(s.start_at) < hi);
      if (hit) return hit;
    }
    return null;
  }

  /** May the client still cancel or move it themselves? Until `change_hours` before the start. */
  function canChange(booking, settings, now) {
    const start = ms(booking.start_at);
    const until = start - Math.max(0, Number(settings && settings.change_hours) || 0) * 3600000;
    const at = typeof now === 'number' ? now : ms(now);
    return { ok: ACTIVE.includes(booking.status || 'Booked') && booking.status !== 'Arrived' && at <= until, until: iso(until) };
  }

  /** The 5-minute pieces a busy span holds (ap_holds.slot). */
  function holdKeys(from, to) {
    const out = [];
    const a = Math.floor(ms(from) / (STEP * MIN)) * STEP * MIN;
    for (let t = a; t < ms(to); t += STEP * MIN) out.push(iso(t).slice(0, 16));
    return out;
  }

  /**
   * The clash answer an agent (or the desk) can act on (OpenSalon's 409, MIT):
   * what is taken and the two ways out.
   */
  function conflictText(clashes, lang, tz) {
    const es = lang === 'es';
    const t = (v) => localTime(ms(v), tz || 'UTC');
    const list = (clashes || []).map((x) => `${x.staff ? `${x.staff} ` : ''}${t(x.start_at)}–${t(x.end_at)}${x.label ? ` (${x.label})` : ''}`).join(', ');
    return es
      ? `Ese horario está ocupado: ${list || 'sin detalle'}. Elige otra hora u otra persona, o resérvalo igual (override).`
      : `That time is taken: ${list || 'no detail'}. Pick another time or person, or book anyway with override.`;
  }

  return {
    STEP, DAYS, ACTIVE, mergeBusy, pad, isFree, startsIn,
    zone, parts, localDay, localTime, addDays, weekday, realDay, hm, clock, localToUtc, iso, ms, json,
    hoursOf, servicesOf, does, dayRanges, isOff, combo, busyOf, load, ctxOf, problemsAt, startsFor, staffFor,
    slots, openDays, pickStaff, check, nearest, firstWish, canChange, holdKeys, conflictText,
  };
}));
