// What the Appointments desk reads, the only things it writes, and what the
// screens share. The slot rules are AptSched (sched.js, the same file the
// public page and the scripts run); client words, money and links AptCore.
// Every write is a declared action (A); bookings and moves go through the
// server's one door (a request, then `process_now`), so the desk can never
// give a time the rules would not.
const { el, router } = Orch;
export const SCH = window.AptSched;
export const CORE = window.AptCore;

export const T = { settings: 'ap_settings', services: 'ap_services', staff: 'ap_staff', off: 'ap_time_off', blocks: 'ap_blocks',
  clients: 'ap_clients', bookings: 'ap_bookings', requests: 'ap_requests', emails: 'ap_emails', inbox: 'ap_inbox' };
export const V = { clients: 'clients_list', rebook: 'due_rebook', sources: 'sources_month', clientSources: 'client_sources' };
export const A = {
  add: 'add_booking', move: 'move_booking', process: 'process_now', arrived: 'mark_arrived', noShow: 'mark_no_show', undoArrived: 'undo_arrived',
  undoNoShow: 'undo_no_show', cancel: 'cancel_booking', note: 'update_booking_note', block: 'block_time', unblock: 'unblock_time',
  createService: 'create_service', updateService: 'update_service', serviceOn: 'service_on', serviceOff: 'service_off',
  createStaff: 'create_staff', updateStaff: 'update_staff', staffOn: 'staff_on', staffOff: 'staff_off', addOff: 'add_time_off', removeOff: 'remove_time_off',
  client: 'update_client', settings: 'update_settings', pause: 'pause_online', resume: 'resume_online', dismissStart: 'dismiss_onboarding',
  checkGmail: 'check_gmail', sendNow: 'send_now', approve: 'approve_email', saveEmail: 'save_email', drop: 'drop_email', retry: 'retry_email',
  dismissEmail: 'dismiss_email', inboxDone: 'inbox_done', inboxAgain: 'inbox_again',
};

const PORTAL_ORIGIN = (() => {
  try {
    const o = document.referrer ? new URL(document.referrer).origin : '';
    if (/^https:\/\/([a-z0-9-]+\.)*(hiorchestra\.com|orchestra-portal[a-z0-9-]*\.up\.railway\.app)$/.test(o)) return o;
  } catch { /* no referrer */ }
  return 'https://hiorchestra.com';
})();
export const INTEGRATIONS = `${PORTAL_ORIGIN}/portal/integrations`;

/** Run a declared action, say how it went, hand back its result (null on failure). */
export async function act(name, params, done) {
  try {
    const r = await Orch.action(name, params);
    if (done) Orch.toast(done);
    return r || {};
  } catch (e) {
    Orch.toast(e.status === 409 ? 'It changed in the meantime: look again.' : (e.message || 'That did not work.'), { error: true });
    return null;
  }
}
/** All rows of a small table (services, staff), in pages of 500. */
export async function every(table, o = {}) {
  const out = [];
  for (let offset = 0; offset < 5000; offset += 500) {
    const r = await Orch.db.list(table, Object.assign({ limit: 500, offset }, o));
    out.push(...(r.rows || []));
    if (!r.hasMore) break;
  }
  return out;
}
export async function settings() { return (await Orch.db.list(T.settings, { sort: '_id:asc', limit: 1 })).rows[0] || {}; }

/**
 * What the slot rules need for the days [from, to]: services, staff, time off,
 * and the busy spans (bookings with their buffers, blocked time).
 */
export async function ruleData(s, from, to) {
  const lo = new Date(SCH.ms(`${from}T00:00:00Z`) - 86400000).toISOString();
  const hi = new Date(SCH.ms(`${to}T00:00:00Z`) + 2 * 86400000).toISOString();
  const [services, staff, offs, bookings, blocks] = await Promise.all([
    every(T.services, { sort: 'position:asc' }), every(T.staff, { sort: 'position:asc' }),
    every(T.off, { filter: { active: 'yes', day_to: { gte: SCH.addDays(from, -1) } } }),
    every(T.bookings, { filter: { status: ['Booked', 'Arrived'], busy_to: { gt: lo }, busy_from: { lt: hi } } }),
    every(T.blocks, { filter: { active: 'yes', end_at: { gt: lo }, start_at: { lt: hi } } }),
  ]);
  const busy = [
    ...bookings.map((b) => ({ staff_id: b.staff_id, start_at: b.busy_from, end_at: b.busy_to, kind: 'booking', booking_id: b._id, label: b.client_name })),
    ...blocks.map((b) => ({ staff_id: b.staff_id, start_at: b.start_at, end_at: b.end_at, kind: 'block', label: b.note || 'Blocked' })),
  ];
  return { settings: s, services, staff, offs, busy, bookings, blocks, now: Date.now() };
}

// ── time, always in the business's zone (the salon is a place) ──────────
export const zoneOf = (s) => SCH.zone((s && s.timezone) || 'UTC');
export const today = (s) => SCH.localDay(Date.now(), zoneOf(s));
export const hhmm = (v, s) => SCH.localTime(SCH.ms(v), zoneOf(s));
export const dayOf = (v, s) => SCH.localDay(SCH.ms(v), zoneOf(s));
export const longDay = (day) => new Intl.DateTimeFormat('en-GB', { timeZone: 'UTC', weekday: 'long', day: 'numeric', month: 'long' }).format(new Date(`${day}T12:00:00Z`));
export const shortDay = (day) => new Intl.DateTimeFormat('en-GB', { timeZone: 'UTC', weekday: 'short', day: 'numeric', month: 'short' }).format(new Date(`${day}T12:00:00Z`));
export const nowIso = () => `${new Date().toISOString().slice(0, 19)}Z`;
export const money = (n, s) => CORE.money(n, (s && s.currency) || 'EUR', 'en');
export const mins = (n) => (n >= 60 ? `${Math.floor(n / 60)} h${n % 60 ? ` ${n % 60}` : ''}` : `${n} min`);

const TONE = { Booked: '', Arrived: 'good', NoShow: 'bad', Cancelled: 'warn', Review: 'warn', Approved: 'warn', Queued: '', Sending: 'warn', Sent: 'good', Failed: 'bad', Dropped: '' };
const SAID = { NoShow: 'No-show', Queued: 'Waiting to send' };
export const badge = (status) => el('span', { class: `oc-badge${TONE[status] ? ` oc-badge--${TONE[status]}` : ''}` }, SAID[status] || status || '—');

/** The public booking page of this instance; Settings may name another. */
export function publicLink(s) {
  const own = `${location.origin}${location.pathname.replace(/\/canvas\/a\/[^/]+\/?.*$/, '/canvas/a/appointments-book/')}`;
  return (s && s.public_url) || own;
}
export async function copy(text, said) {
  try { await navigator.clipboard.writeText(text); Orch.toast(said || 'Copied.'); } catch { Orch.toast('Select the link and copy it.', { error: true }); }
}

/** A dialog that closes when the screen changes. */
export function sheet(content, opts) {
  const d = Orch.dialog(content, opts);
  window.addEventListener('hashchange', () => { try { d.close(); } catch { /* closed */ } }, { once: true });
  return d;
}
/** A screen's head: title and a sentence on the left, tools on the right. */
export const head = (title, lede, tools) => el('header', { class: 'ap-head' }, [
  el('div', { class: 'ap-head__title' }, [el('h1', { class: 'oc-h1 oc-h1--collection' }, title), lede ? el('p', { class: 'oc-lede' }, lede) : null]),
  tools ? el('div', { class: 'ap-head__tools' }, tools) : null,
]);
export const field = (label, control, help) => el('label', { class: 'oc-field' }, [el('span', { class: 'oc-label' }, label), control, help ? el('span', { class: 'oc-help' }, help) : null]);
export const input = (attrs) => el('input', Object.assign({ class: 'oc-input' }, attrs));
export function select(options, value, attrs) {
  return el('select', Object.assign({ class: 'oc-select' }, attrs || {}), options.map(([v, label]) => el('option', { value: String(v), selected: String(v) === String(value) }, label)));
}

/**
 * Send a booking or a move through the server's door and wait for the verdict
 * (the request row): {status: 'Booked' | 'Done' | 'Conflict' | 'Failed', reason, clashes}.
 */
export async function through(action, params) {
  const r = await act(action, params);
  if (!r || !r._id) return { status: 'Failed', reason: 'It could not be sent.' };
  act(A.process, {});
  for (let i = 0; i < 40; i++) {
    await new Promise((ok) => { setTimeout(ok, i < 10 ? 500 : 1000); });
    const row = await Orch.db.get(T.requests, r._id).catch(() => null);
    if (row && row.status !== 'New') return Object.assign({}, row, { clashes: CORE && row.clashes ? JSON.parse(row.clashes) : [] });
  }
  return { status: 'Waiting', reason: 'The server has not answered yet: it will appear here when it does.' };
}
export const go = (path) => router.go(path);
/** This browser's time zone, the default for a first setup. */
export const browserZone = () => { try { return Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC'; } catch { return 'UTC'; } };
