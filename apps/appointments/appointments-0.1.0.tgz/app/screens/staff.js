// Team: the people who take appointments, thin rows with their week and how
// many services they do. A person opens their editor (/team/<id>). Days the
// whole business is closed (holidays) are kept here too.
import { A, SCH, act, every, field, head, input, settings, shortDay, today } from '../data.js';

const { el, router } = Orch;
const SHORT = { mon: 'Mon', tue: 'Tue', wed: 'Wed', thu: 'Thu', fri: 'Fri', sat: 'Sat', sun: 'Sun' };
const ORDER = ['mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun'];

/** "Mon–Fri 09:00–19:00 · Sat 10:00–14:00": the week in one line. */
export function weekLine(hours) {
  const h = SCH.hoursOf(hours);
  const parts = [];
  for (const d of ORDER) {
    const v = (h[d] || []).length ? `${h[d][0][0]}–${h[d][h[d].length - 1][1]}${h[d].length > 1 ? ' (break)' : ''}` : '';
    const last = parts[parts.length - 1];
    if (v && last && last.v === v && ORDER.indexOf(last.to) === ORDER.indexOf(d) - 1) last.to = d;
    else if (v) parts.push({ from: d, to: d, v });
  }
  return parts.map((p) => `${SHORT[p.from]}${p.to !== p.from ? `–${SHORT[p.to]}` : ''} ${p.v}`).join(' · ') || 'No hours yet';
}

export function render() {
  const again = () => render();
  Orch.load('view', async () => {
    const [s, people, services, closed] = await Promise.all([
      settings(), every('ap_staff', { sort: 'position:asc' }), every('ap_services', { filter: { active: 'yes' } }),
      every('ap_time_off', { filter: { staff_id: 0, active: 'yes' }, sort: 'day_from:asc' }),
    ]);
    const upcoming = closed.filter((o) => o.day_to >= today(s));
    const from = el('input', { class: 'oc-input', type: 'date', required: true });
    const to = el('input', { class: 'oc-input', type: 'date' });
    const why = input({ maxlength: '80', placeholder: 'Holiday, inventory…' });
    return el('div', { class: 'oc-stack oc-stack--loose' }, [
      head('Team', 'Who takes appointments, when they work, and what each one does.', [router.link('/team/new', 'Add a person', { class: 'oc-btn oc-btn--primary' })]),
      people.length ? el('ul', { class: 'ap-rows oc-card oc-card--pad0' }, people.map((p) => {
        const n = SCH.servicesOf(p).filter((id) => services.some((x) => Number(x._id) === id)).length;
        return el('li', { class: `ap-row${p.active === 'yes' ? '' : ' ap-row--off'}` }, [
          el('a', { class: 'ap-row__main', href: `#/team/${p._id}` }, [el('span', p.name), el('span', { class: 'ap-row__sub' }, weekLine(p.hours))]),
          el('span', { class: 'ap-row__fact' }, n ? `${n} of ${services.length} services` : 'No services yet'),
          p.active === 'yes' ? el('span', { class: 'ap-row__fact' }) : el('span', { class: 'oc-badge' }, 'Off'),
        ]);
      })) : el('div', { class: 'oc-card oc-state' }, [
        el('p', { class: 'oc-state__title' }, 'Nobody yet.'),
        el('p', { class: 'oc-help' }, 'Add each person who takes appointments, even if it is only you: their hours and services decide what clients can book.'),
        router.link('/team/new', 'Add the first person', { class: 'oc-btn' }),
      ]),
      el('section', { class: 'oc-card oc-stack' }, [
        el('h2', { class: 'oc-h2' }, 'Days the business is closed'),
        el('p', { class: 'oc-help' }, 'Holidays and closures: nobody can be booked on these days.'),
        upcoming.length ? el('ul', { class: 'ap-rows' }, upcoming.map((o) => el('li', { class: 'ap-row' }, [
          el('span', { class: 'ap-row__main' }, [el('span', o.day_to && o.day_to !== o.day_from ? `${shortDay(o.day_from)} – ${shortDay(o.day_to)}` : shortDay(o.day_from)), el('span', { class: 'ap-row__sub' }, o.note || ' ')]),
          el('button', { type: 'button', class: 'oc-btn oc-btn--sm oc-btn--ghost', onClick: async () => { if (await act(A.removeOff, { id: o._id }, 'Open again.')) again(); } }, 'Remove'),
        ]))) : null,
        el('form', { class: 'ap-inline', onSubmit: async (e) => {
          e.preventDefault();
          if (!SCH.realDay(from.value) || (to.value && to.value < from.value)) { Orch.toast('Pick the first day (and a last day after it).', { error: true }); return; }
          if (await act(A.addOff, { staff_id: 0, day_from: from.value, day_to: to.value || from.value, note: why.value.trim() }, 'Closed on those days.')) again();
        } }, [field('From', from), field('To (optional)', to), field('Why', why), el('button', { type: 'submit', class: 'oc-btn' }, 'Close these days')]),
      ]),
    ]);
  });
}
