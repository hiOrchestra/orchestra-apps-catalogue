// The agenda of one day: a time ruler and one column per person, the hours
// they work drawn as paper on a sunken ground, each appointment where it
// falls, blocked time hatched. A click on free paper starts a booking at that
// time with that person (the first of the two clicks of a phone booking).
import { SCH, hhmm, zoneOf } from '../data.js';

const { el } = Orch;
const PX = 1.4; // pixels per minute: an hour is 84 px

/** The minutes past midnight the day's grid starts and ends at, whole hours. */
function span(people, day, tz, items) {
  let lo = 9 * 60;
  let hi = 19 * 60;
  let seen = false;
  for (const p of people) {
    for (const [a, b] of (SCH.hoursOf(p.hours)[SCH.weekday(day)] || [])) {
      const x = SCH.hm(a);
      const y = SCH.hm(b);
      lo = seen ? Math.min(lo, x) : x;
      hi = seen ? Math.max(hi, y) : y;
      seen = true;
    }
  }
  for (const it of items) {
    const a = SCH.hm(SCH.localTime(SCH.ms(it.start_at), tz));
    const b = SCH.hm(SCH.localTime(SCH.ms(it.end_at), tz)) || 24 * 60;
    if (SCH.localDay(SCH.ms(it.start_at), tz) === day) { lo = Math.min(lo, a); hi = Math.max(hi, b); }
  }
  return { lo: Math.floor(lo / 60) * 60, hi: Math.min(24 * 60, Math.ceil(hi / 60) * 60) };
}

const minuteOf = (v, day, tz) => {
  const t = SCH.ms(v);
  const base = SCH.localToUtc(day, '00:00', tz);
  return (t - base) / 60000;
};

/** Appointments that overlap (one booked anyway over another) sit side by side: a lane each. */
function lanes(list, day, tz) {
  const evs = list.map((b) => ({ b, a: minuteOf(b.start_at, day, tz), z: minuteOf(b.end_at, day, tz) })).sort((x, y) => x.a - y.a);
  let group = [];
  let ends = [];
  let until = -Infinity;
  const close = () => { const n = Math.max(1, ...group.map((e) => e.lane + 1)); for (const e of group) e.n = n; group = []; ends = []; };
  for (const e of evs) {
    if (group.length && e.a >= until) close();
    let lane = ends.findIndex((t) => t <= e.a);
    if (lane < 0) { lane = ends.length; ends.push(e.z); } else ends[lane] = e.z;
    e.lane = lane;
    group.push(e);
    until = Math.max(until, e.z);
  }
  if (group.length) close();
  return evs;
}

/**
 * grid({s, day, people, bookings, blocks, offs, onEmpty(person, isoStart), onBooking(b), onBlock(block)})
 */
export function grid(o) {
  const tz = zoneOf(o.s);
  const { lo, hi } = span(o.people, o.day, tz, [...o.bookings, ...o.blocks]);
  const height = (hi - lo) * PX;
  const step = Math.max(5, Number(o.s.slot_step_min) || 15);
  const ruler = el('div', { class: 'ap-grid__ruler', style: { height: `${height}px` } });
  for (let m = lo; m < hi; m += 60) ruler.append(el('span', { class: 'oc-value ap-grid__hour', style: { top: `${(m - lo) * PX}px` } }, SCH.clock(m)));

  const cols = o.people.map((p) => {
    const off = SCH.isOff(p._id, o.day, o.offs);
    const mine = o.bookings.filter((b) => Number(b.staff_id) === Number(p._id));
    const body = el('div', { class: `ap-col__body${off ? ' ap-col__body--off' : ''}`, style: { height: `${height}px` } });
    body.style.setProperty('--hour', `${60 * PX}px`);
    if (!off) {
      for (const r of SCH.dayRanges(p.hours, o.day, tz)) {
        const a = (r.start - SCH.localToUtc(o.day, '00:00', tz)) / 60000;
        const b = (r.end - SCH.localToUtc(o.day, '00:00', tz)) / 60000;
        body.append(el('div', { class: 'ap-open', style: { top: `${(a - lo) * PX}px`, height: `${(b - a) * PX}px`, backgroundPosition: `0 ${-(a - lo) * PX}px` } }));
      }
    } else body.append(el('p', { class: 'ap-col__off' }, 'Off today'));
    for (const k of o.blocks.filter((x) => Number(x.staff_id) === Number(p._id))) {
      const a = Math.max(lo, minuteOf(k.start_at, o.day, tz));
      const b = Math.min(hi, minuteOf(k.end_at, o.day, tz));
      if (b <= a) continue;
      body.append(el('button', { type: 'button', class: 'ap-block', style: { top: `${(a - lo) * PX}px`, height: `${(b - a) * PX}px` },
        onClick: (e) => { e.stopPropagation(); o.onBlock(k); } }, [el('span', { class: 'oc-value' }, `${hhmm(k.start_at, o.s)}–${hhmm(k.end_at, o.s)}`), el('span', k.note || 'Blocked')]));
    }
    for (const { b, a, z, lane, n } of lanes(mine, o.day, tz)) {
      const tall = (z - a) * PX >= 50;
      body.append(el('button', { type: 'button', class: `ap-ev ap-ev--${String(b.status).toLowerCase()}${tall ? '' : ' ap-ev--short'}`,
        style: { top: `${(a - lo) * PX}px`, height: `${Math.max(18, (z - a) * PX - 2)}px`,
          left: `calc(4px + (100% - 8px) * ${lane} / ${n})`, width: `calc((100% - 8px) / ${n} - ${n > 1 ? 3 : 0}px)`, right: 'auto' },
        title: `${hhmm(b.start_at, o.s)} ${b.client_name} · ${b.service_name}`,
        onClick: (e) => { e.stopPropagation(); o.onBooking(b); } }, [
        el('span', { class: 'oc-value ap-ev__time' }, `${hhmm(b.start_at, o.s)}–${hhmm(b.end_at, o.s)}`),
        el('span', { class: 'ap-ev__name' }, b.client_name || '—'),
        tall ? el('span', { class: 'ap-ev__what' }, b.service_name) : null,
      ]));
    }
    if (!off) {
      body.addEventListener('click', (e) => {
        if (e.target !== body && !e.target.classList.contains('ap-open')) return;
        const y = e.clientY - body.getBoundingClientRect().top;
        const m = lo + Math.floor(y / PX / step) * step;
        o.onEmpty(p, new Date(SCH.localToUtc(o.day, SCH.clock(m), tz)).toISOString().replace(/\.\d+Z$/, 'Z'));
      });
      body.title = 'Click free time to book it';
    }
    const n = mine.filter((b) => b.status !== 'Cancelled').length;
    return el('div', { class: 'ap-col' }, [
      el('div', { class: 'ap-col__head' }, [el('span', { class: 'ap-col__name' }, p.name), el('span', { class: 'oc-eyebrow' }, n ? `${n} booked` : (off ? 'Off' : 'Free'))]),
      body,
    ]);
  });

  const wrap = el('div', { class: 'ap-grid', style: { '--cols': String(Math.max(1, cols.length)) } });
  wrap.style.setProperty('--cols', String(Math.max(1, cols.length)));
  wrap.append(el('div', { class: 'ap-grid__gutter' }, [el('div', { class: 'ap-col__head' }), ruler]), ...cols);
  if (o.day === SCH.localDay(Date.now(), tz)) {
    const m = minuteOf(new Date().toISOString(), o.day, tz);
    if (m > lo && m < hi) wrap.append(el('div', { class: 'ap-now', style: { top: `calc(var(--head) + ${(m - lo) * PX}px)` }, 'aria-hidden': 'true' }));
  }
  return el('div', { class: 'oc-scroll-x ap-grid__scroll' }, wrap);
}
