// Today: the day's agenda, one column per person, in the business's time.
// Click free time to book a phone call or a walk-in there; click an
// appointment for Arrived, No-show, Move or Cancel. /day/<YYYY-MM-DD> is any
// other day. Until the business is set up, Getting started sits on top.
import { A, SCH, T, act, every, head, longDay, ruleData, settings, today as todayOf, zoneOf } from '../data.js';
import { grid } from './grid.js';
import { openBooking, openBlock } from './booking.js';
import { newBooking, blockTime } from './new.js';
import { startPanel } from './start.js';

const { el, router } = Orch;

export function render(params) {
  const again = () => render(params);
  Orch.load('view', async () => {
    const s = await settings();
    const tz = zoneOf(s);
    const now = todayOf(s);
    const day = params && SCH.realDay(params.day) ? params.day : now;
    const from = new Date(SCH.localToUtc(day, '00:00', tz)).toISOString();
    const to = new Date(SCH.localToUtc(SCH.addDays(day, 1), '00:00', tz)).toISOString();
    const [d, bookings, cancelled, conflicts] = await Promise.all([
      ruleData(s, day, day),
      every(T.bookings, { filter: { status: ['Booked', 'Arrived', 'NoShow'], start_at: { gte: from, lt: to } }, sort: 'start_at:asc' }),
      Orch.db.count(T.bookings, { filter: { status: 'Cancelled', start_at: { gte: from, lt: to } } }),
      Orch.db.count(T.requests, { filter: { status: 'Conflict' } }),
    ]);
    const people = d.staff.filter((p) => p.active === 'yes' || bookings.some((b) => Number(b.staff_id) === Number(p._id)))
      .sort((a, b) => (Number(a.position) || 0) - (Number(b.position) || 0) || a._id - b._id);
    const blocks = d.blocks.filter((k) => k.start_at < to && k.end_at > from);
    const ctx = { s, d, day, again };
    const start = startPanel(s, d, again);
    const nav = el('div', { class: 'ap-daynav' }, [
      router.link(`/day/${SCH.addDays(day, -1)}`, '←', { class: 'oc-btn oc-btn--ghost oc-btn--sm', 'aria-label': 'The day before' }),
      day !== now ? router.link('/', 'Today', { class: 'oc-btn oc-btn--ghost oc-btn--sm' }) : null,
      router.link(`/day/${SCH.addDays(day, 1)}`, '→', { class: 'oc-btn oc-btn--ghost oc-btn--sm', 'aria-label': 'The day after' }),
      el('input', { class: 'oc-input ap-daynav__pick', type: 'date', value: day, 'aria-label': 'Go to a day',
        onChange: (e) => { if (SCH.realDay(e.target.value)) router.go(`/day/${e.target.value}`); } }),
    ]);
    const booked = bookings.filter((b) => b.status !== 'NoShow').length;
    const closed = SCH.isOff(0, day, d.offs);
    const lede = `${longDay(day)} · ${closed ? 'closed · ' : ''}${booked} ${booked === 1 ? 'appointment' : 'appointments'}${cancelled ? ` · ${cancelled} cancelled` : ''}`;
    const tools = people.length ? [
      el('button', { type: 'button', class: 'oc-btn oc-btn--ghost', onClick: () => blockTime(ctx, null, null) }, 'Block time'),
      el('button', { type: 'button', class: 'oc-btn oc-btn--primary', onClick: () => newBooking(ctx, null, null) }, 'New appointment'),
    ] : null;
    const notes = [];
    if (s.paused === 'yes') notes.push(el('div', { class: 'ap-notice ap-notice--warn' }, ['Online booking is paused: the booking page offers no times. ', router.link('/settings', 'Resume it in Settings')]));
    if (conflicts) notes.push(el('div', { class: 'ap-notice' }, [`${conflicts === 1 ? 'A phone booking was' : `${conflicts} phone bookings were`} not saved because the time was taken. `, el('button', { type: 'button', class: 'ap-linkbtn', onClick: async () => {
      const rows = await every(T.requests, { filter: { status: 'Conflict' } });
      for (const r of rows) await act('close_request', { id: r._id });
      again();
    } }, 'Clear')]));
    return el('div', { class: 'oc-stack oc-stack--loose' }, [
      head(day === now ? 'Today' : longDay(day).split(' ')[0], lede, tools),
      start,
      ...notes,
      nav,
      people.length ? grid({
        s, day, people, bookings, blocks, offs: d.offs,
        onEmpty: (p, at) => newBooking(ctx, p, at),
        onBooking: (b) => openBooking(ctx, b),
        onBlock: (k) => openBlock(ctx, k),
      }) : el('div', { class: 'oc-card oc-state' }, [
        el('p', { class: 'oc-state__title' }, 'Nobody to book yet.'),
        el('p', { class: 'oc-help' }, 'Add the people who take appointments, their hours and the services each one does. Their columns appear here.'),
        router.link('/team/new', 'Add a person', { class: 'oc-btn' }),
      ]),
    ]);
  });
}
export { A };
