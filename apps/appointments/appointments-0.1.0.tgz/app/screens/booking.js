// One appointment's panel: who, what, with whom, when, the price and the
// note; Arrived and No-show (each with Undo), Move, and Cancel in two steps
// that name what happens. Also a blocked time's panel, and the move dialog.
import { A, CORE, SCH, act, badge, field, hhmm, longDay, money, ruleData, select, sheet, through, zoneOf } from '../data.js';

const { el, router } = Orch;
const SOURCE = (b) => CORE.channelLabel(b.channel || (b.source === 'desk' ? 'phone' : b.source));

export function openBooking(ctx, b) {
  const { s } = ctx;
  const day = SCH.localDay(SCH.ms(b.start_at), zoneOf(s));
  const done = (msg) => async (name, extra) => { if (await act(name, Object.assign({ id: b._id }, extra || {}), msg)) { d.close(); ctx.again(); } };
  const note = el('textarea', { class: 'oc-textarea', rows: '2', maxlength: '1000' }, b.note || '');
  const actions = el('div', { class: 'oc-row ap-panel__actions' });
  const live = b.status === 'Booked';
  if (live) {
    actions.append(
      el('button', { type: 'button', class: 'oc-btn oc-btn--primary', onClick: () => done('Marked as arrived.')(A.arrived) }, 'Arrived'),
      el('button', { type: 'button', class: 'oc-btn', onClick: () => done('Marked as a no-show.')(A.noShow) }, 'No-show'),
      el('button', { type: 'button', class: 'oc-btn oc-btn--ghost', onClick: () => { d.close(); moveBooking(ctx, b); } }, 'Move'),
      el('button', { type: 'button', class: 'oc-btn oc-btn--ghost ap-danger-text', onClick: () => askCancel() }, 'Cancel appointment…'),
    );
  } else if (b.status === 'Arrived') actions.append(el('button', { type: 'button', class: 'oc-btn oc-btn--ghost', onClick: () => done('Back to booked.')(A.undoArrived) }, 'Undo arrived'));
  else if (b.status === 'NoShow') actions.append(el('button', { type: 'button', class: 'oc-btn oc-btn--ghost', onClick: () => done('Back to booked.')(A.undoNoShow) }, 'Undo no-show'));
  const confirmBox = el('div', { class: 'ap-confirm', hidden: true });

  // Cancel, step two: says what happens, and the button waits for the tick.
  function askCancel() {
    const emailed = s.emails_on === 'yes' && s.gmail_status === 'ok';
    const ack = el('input', { type: 'checkbox' });
    const reason = el('input', { class: 'oc-input', maxlength: '300', placeholder: 'Optional: why' });
    const go = el('button', { type: 'button', class: 'oc-btn oc-btn--danger', disabled: true, onClick: () => done('Cancelled.')(A.cancel, { cancel_reason: reason.value.trim() }) }, 'Cancel it');
    ack.addEventListener('change', () => { go.disabled = !ack.checked; });
    confirmBox.replaceChildren(
      el('p', `Cancel ${b.client_name}'s ${b.service_name} with ${b.staff_name} at ${hhmm(b.start_at, s)} on ${longDay(day)}?`),
      el('p', { class: 'oc-help' }, `The time becomes free on the booking page at once.${emailed ? ` ${CORE.firstName(b.client_name)} gets an email saying it is cancelled.` : ' No email goes out: tell the client yourself.'}`),
      field('Reason (kept on the appointment)', reason),
      el('label', { class: 'ap-check' }, [ack, el('span', 'I understand, cancel this appointment')]),
      el('div', { class: 'oc-row' }, [go, el('button', { type: 'button', class: 'oc-btn oc-btn--ghost', onClick: () => { confirmBox.hidden = true; } }, 'Keep it')]),
    );
    confirmBox.hidden = false;
  }

  const facts = el('dl', { class: 'ap-facts' }, [
    ['When', `${longDay(day)}, ${hhmm(b.start_at, s)}–${hhmm(b.end_at, s)}`],
    ['With', `${b.staff_name}${b.any_staff === 'yes' ? ' (they chose anyone)' : ''}`],
    ['Service', `${b.service_name} · ${money(b.price_minor, s)}`],
    ['Came from', SOURCE(b)],
  ].map(([k, v]) => el('div', { class: 'ap-fact' }, [el('dt', k), el('dd', v)])));
  const d = sheet(el('div', { class: 'oc-stack ap-panel' }, [
    el('div', { class: 'oc-row oc-row--between' }, [
      el('a', { href: `#/clients?open=${b.client_id}`, class: 'ap-panel__who' }, b.client_name || '—'),
      badge(b.status),
    ]),
    facts,
    field('Note', note, 'Only your team sees it.'),
    el('div', { class: 'oc-row' }, [el('button', { type: 'button', class: 'oc-btn oc-btn--sm oc-btn--ghost', onClick: async () => {
      if (await act(A.note, { id: b._id, note: note.value.trim() || '' }, 'Note saved.')) ctx.again();
    } }, 'Save note')]),
    actions,
    confirmBox,
  ]), { title: 'Appointment' });
}

export function openBlock(ctx, k) {
  const { s } = ctx;
  const d = sheet(el('div', { class: 'oc-stack' }, [
    el('p', `${hhmm(k.start_at, s)}–${hhmm(k.end_at, s)}${k.note ? ` · ${k.note}` : ''}`),
    el('p', { class: 'oc-help' }, 'Nobody can book this time, online or here. Remove the block to free it.'),
    el('div', { class: 'oc-row' }, [el('button', { type: 'button', class: 'oc-btn', onClick: async () => {
      if (await act(A.unblock, { id: k._id }, 'The time is free again.')) { d.close(); ctx.again(); }
    } }, 'Remove the block')]),
  ]), { title: 'Blocked time' });
}

/** Move: another day, time or person. The server judges it like any booking; a clash can be overridden. */
export function moveBooking(ctx, b) {
  const { s } = ctx;
  const tz = zoneOf(s);
  const ids = SCH.json(b.service_ids, [b.service_id]);
  const dayIn = el('input', { class: 'oc-input', type: 'date', value: SCH.localDay(SCH.ms(b.start_at), tz) });
  const people = ctx.d.staff.filter((p) => p.active === 'yes' && SCH.does(p, ids));
  const who = select([['0', 'Anyone free'], ...people.map((p) => [p._id, p.name])], b.staff_id);
  const time = el('select', { class: 'oc-select' });
  const said = el('div', { class: 'oc-stack oc-stack--tight' });
  const save = el('button', { type: 'submit', class: 'oc-btn oc-btn--primary' }, 'Move it');
  async function times() {
    const day = dayIn.value;
    if (!SCH.realDay(day)) return;
    const data = await ruleData(s, day, day);
    data.ignore = b._id;
    const list = SCH.slots(data, ids, Number(who.value), day);
    time.replaceChildren(...(list.length ? list.map((x) => el('option', { value: x.start_at }, SCH.localTime(SCH.ms(x.start_at), tz)))
      : [el('option', { value: '' }, 'No free time that day')]));
  }
  dayIn.addEventListener('change', times);
  who.addEventListener('change', times);
  async function send(override) {
    if (!time.value) return;
    save.disabled = true;
    said.replaceChildren(el('p', { class: 'oc-help' }, 'Moving…'));
    const r = await through(A.move, { booking_id: b._id, start_at: time.value, staff_id: Number(who.value), override: override ? 'yes' : 'no' });
    save.disabled = false;
    if (r.status === 'Done') { Orch.toast('Moved.'); d.close(); ctx.again(); return; }
    said.replaceChildren(el('p', { class: 'ap-bad' }, r.reason || 'It could not be moved.'),
      ...(r.clashes && r.clashes.length ? [el('p', { class: 'oc-help' }, SCH.conflictText(r.clashes, 'en', tz)),
        el('div', { class: 'oc-row' }, el('button', { type: 'button', class: 'oc-btn oc-btn--sm', onClick: () => send(true) }, 'Move it anyway'))] : []));
  }
  const form = el('form', { class: 'oc-stack', onSubmit: (e) => { e.preventDefault(); send(false); } }, [
    el('p', { class: 'oc-help' }, `${b.client_name} · ${b.service_name}. Only free times are offered; the client gets an email about the change if emails are on.`),
    el('div', { class: 'ap-two' }, [field('Day', dayIn), field('With', who)]),
    field('Time', time),
    said,
    el('div', { class: 'oc-row' }, [save]),
  ]);
  const d = sheet(form, { title: 'Move appointment' });
  times();
  return router;
}
