// A new appointment from the desk (a phone call, a walk-in, one taken on a
// marketplace) and blocked time. The free times offered are the same rules'
// as the booking page; the server judges the booking again, and when the time
// was taken meanwhile it says by whom, with "Book anyway".
import { A, CORE, SCH, T, act, field, input, money, ruleData, select, sheet, through, zoneOf } from '../data.js';

const { el } = Orch;

export function newBooking(ctx, person, at) {
  const { s } = ctx;
  const tz = zoneOf(s);
  const services = ctx.d.services.filter((x) => x.active === 'yes').sort((a, b) => (a.position || 0) - (b.position || 0) || a._id - b._id);
  if (!services.length) { Orch.toast('Add a service first (Services).', { error: true }); return; }
  const svcOptions = services.map((x) => [x._id, `${x.category ? `${x.category} · ` : ''}${x.name} · ${x.duration_min} min · ${money(x.price_minor, s)}`]);
  const picks = el('div', { class: 'oc-stack oc-stack--tight' });
  const addSvc = (v) => { const sel = select(svcOptions, v); sel.addEventListener('change', refresh); picks.append(sel); return sel; };
  const first = addSvc(services[0]._id);
  if (person) { const can = services.find((x) => SCH.does(person, [x._id])); if (can) first.value = String(can._id); }
  const more = el('button', { type: 'button', class: 'ap-linkbtn ap-start-self', onClick: () => { if (picks.children.length < 3) { addSvc(services[0]._id); refresh(); } } }, '+ another service after it');
  const who = el('select', { class: 'oc-select' });
  const dayIn = el('input', { class: 'oc-input', type: 'date', value: at ? SCH.localDay(SCH.ms(at), tz) : ctx.day });
  const time = el('select', { class: 'oc-select' });
  const name = input({ maxlength: '120', required: true, autocomplete: 'off', list: 'ap-client-names' });
  const names = el('datalist', { id: 'ap-client-names' });
  const phone = input({ type: 'tel', maxlength: '25' });
  const email = input({ type: 'email', maxlength: '200' });
  const note = el('textarea', { class: 'oc-textarea', rows: '2', maxlength: '1000' });
  const from = select([['phone', 'Phone'], ['walk-in', 'Walk-in'], ...CORE.marketplacesOf(s).map((m) => [`marketplace:${m}`, m])], 'phone');
  const said = el('div', { class: 'oc-stack oc-stack--tight' });
  const save = el('button', { type: 'submit', class: 'oc-btn oc-btn--primary' }, 'Book');
  let wanted = at || '';
  let refused = null;
  let found = [];
  const ids = () => [...picks.querySelectorAll('select')].map((x) => Number(x.value));

  async function refresh() {
    const day = dayIn.value;
    const people = ctx.d.staff.filter((p) => p.active === 'yes' && SCH.does(p, ids()));
    const keep = who.value || (person ? String(person._id) : '0');
    who.replaceChildren(...[['0', 'Anyone free'], ...people.map((p) => [p._id, p.name])].map(([v, l]) => el('option', { value: String(v), selected: String(v) === keep }, l)));
    if (!SCH.realDay(day)) return;
    const data = day === ctx.day ? ctx.d : await ruleData(s, day, day);
    const list = SCH.slots(Object.assign({}, data, { now: Date.now() }), ids(), Number(who.value), day);
    const opts = list.map((x) => [x.start_at, SCH.localTime(SCH.ms(x.start_at), tz)]);
    if (wanted && SCH.localDay(SCH.ms(wanted), tz) === day && !list.some((x) => x.start_at === wanted)) opts.unshift([wanted, `${SCH.localTime(SCH.ms(wanted), tz)} · taken`]);
    time.replaceChildren(...(opts.length ? opts.map(([v, l]) => el('option', { value: v, selected: v === wanted }, l)) : [el('option', { value: '' }, 'No free time that day')]));
  }
  dayIn.addEventListener('change', () => { wanted = ''; refresh(); });
  who.addEventListener('change', refresh);
  time.addEventListener('change', () => { wanted = time.value; });
  let timer = null;
  name.addEventListener('input', () => {
    clearTimeout(timer);
    timer = setTimeout(async () => {
      const q = name.value.trim();
      const hit = found.find((c) => c.name === q);
      if (hit) { phone.value = hit.phone || ''; email.value = hit.email || ''; return; }
      if (q.length < 2) return;
      found = (await Orch.db.list(T.clients, { filter: { name: { like: `%${q}%` } }, limit: 8 }).catch(() => ({ rows: [] }))).rows || [];
      names.replaceChildren(...found.map((c) => el('option', { value: c.name }, [c.phone, c.email].filter(Boolean).join(' · '))));
    }, 200);
  });

  async function send(override) {
    if (!time.value) { Orch.toast('Pick a time.', { error: true }); return; }
    if (email.value.trim() && !CORE.isEmail(email.value)) { Orch.toast('That email does not look right.', { error: true }); return; }
    save.disabled = true;
    said.replaceChildren(el('p', { class: 'oc-help' }, 'Booking…'));
    const list = ids();
    const r = await through(A.add, { service_id: list[0], service_ids: JSON.stringify(list), staff_id: Number(who.value), start_at: time.value,
      name: name.value.trim(), phone: phone.value.trim(), email: email.value.trim(), note: note.value.trim(), language: s.default_language || 'es',
      override: override ? 'yes' : 'no', channel: from.value });
    save.disabled = false;
    if (r.status === 'Booked') {
      // The refused try is answered: it should not stay on Today as "not saved".
      if (refused) await act('close_request', { id: refused });
      Orch.toast(override ? 'Booked over the clash.' : 'Booked.'); d.close(); ctx.again(); return;
    }
    if (r.status === 'Conflict') refused = r._id;
    said.replaceChildren(el('p', { class: 'ap-bad' }, r.reason || 'It could not be booked.'),
      ...(r.status === 'Conflict' ? [r.clashes && r.clashes.length ? el('p', { class: 'oc-help' }, SCH.conflictText(r.clashes, 'en', tz)) : null,
        el('div', { class: 'oc-row' }, el('button', { type: 'button', class: 'oc-btn oc-btn--sm', onClick: () => send(true) }, 'Book anyway'))] : []));
  }
  const form = el('form', { class: 'oc-stack', onSubmit: (e) => { e.preventDefault(); send(false); } }, [
    field('Service', picks), more,
    el('div', { class: 'ap-two' }, [field('With', who), field('Came from', from)]),
    el('div', { class: 'ap-two' }, [field('Day', dayIn), field('Time', time)]),
    field('Client name', name), names,
    el('div', { class: 'ap-two' }, [field('Phone', phone), field('Email (optional)', email, 'For the confirmation and the reminder.')]),
    field('Note (optional)', note),
    said,
    el('div', { class: 'oc-row' }, [save]),
  ]);
  const d = sheet(form, { title: 'New appointment' });
  refresh().then(() => name.focus());
}

export function blockTime(ctx, person, at) {
  const { s } = ctx;
  const tz = zoneOf(s);
  const people = ctx.d.staff.filter((p) => p.active === 'yes');
  const who = select([['all', 'Everyone'], ...people.map((p) => [p._id, p.name])], person ? person._id : 'all');
  const dayIn = el('input', { class: 'oc-input', type: 'date', value: ctx.day });
  const t0 = at ? SCH.localTime(SCH.ms(at), tz) : '13:00';
  const fromIn = el('input', { class: 'oc-input', type: 'time', step: '300', value: t0 });
  const toIn = el('input', { class: 'oc-input', type: 'time', step: '300', value: SCH.clock(Math.min(24 * 60 - 5, SCH.hm(t0) + 60)) });
  const note = input({ maxlength: '120', placeholder: 'Training, errand, lunch…' });
  const form = el('form', { class: 'oc-stack', onSubmit: async (e) => {
    e.preventDefault();
    const day = dayIn.value;
    if (!SCH.realDay(day) || !(SCH.hm(fromIn.value) < SCH.hm(toIn.value))) { Orch.toast('Pick a day and a time that ends after it starts.', { error: true }); return; }
    const start = new Date(SCH.localToUtc(day, fromIn.value, tz)).toISOString().replace(/\.\d+Z$/, 'Z');
    const end = new Date(SCH.localToUtc(day, toIn.value, tz)).toISOString().replace(/\.\d+Z$/, 'Z');
    const ids = who.value === 'all' ? people.map((p) => p._id) : [Number(who.value)];
    for (const id of ids) if (!await act(A.block, { staff_id: id, start_at: start, end_at: end, note: note.value.trim() })) return;
    Orch.toast('Blocked.');
    d.close();
    ctx.again();
  } }, [
    el('p', { class: 'oc-help' }, 'Nobody can book a blocked time, online or here. Appointments already in it stay: move them if needed.'),
    el('div', { class: 'ap-two' }, [field('Who', who), field('Day', dayIn)]),
    el('div', { class: 'ap-two' }, [field('From', fromIn), field('To', toIn)]),
    field('Why (only your team sees it)', note),
    el('div', { class: 'oc-row' }, [el('button', { type: 'submit', class: 'oc-btn oc-btn--primary' }, 'Block it')]),
  ]);
  const d = sheet(form, { title: 'Block time' });
}
