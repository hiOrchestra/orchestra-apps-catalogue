// Sources: where appointments come from, this month against the last, and
// what booking direct saved against a marketplace's new-client fee. It is an
// estimate, and says so: every new client who came direct (the booking page,
// phone, walk-in, email) × their first appointment's price × the fee % of
// Settings. Clients who first came through a marketplace and now book direct
// count as recovered.
import { CORE, SCH, V, copy, head, money, publicLink, settings } from '../data.js';

const { el, router } = Orch;

export function render() {
  Orch.load('view', async () => {
    const s = await settings();
    const start = new Date();
    start.setUTCDate(1);
    const thisMonth = `${start.toISOString().slice(0, 7)}-01 00:00:00`;
    const prev = new Date(Date.UTC(start.getUTCFullYear(), start.getUTCMonth() - 1, 1)).toISOString().slice(0, 10);
    const [rows, fresh, recovered] = await Promise.all([
      viewAll(V.sources, null),
      viewAll(V.clientSources, { since: { gte: `${prev} 00:00:00` } }),
      Orch.db.view(V.clientSources, { filter: { recovered: 'yes' }, limit: 1, count: true }).then((r) => r.total || 0).catch(() => 0),
    ]);
    const now = fresh.filter((c) => c.since >= thisMonth);
    const before = fresh.filter((c) => c.since < thisMonth);
    const fee = Number(s.marketplace_fee_pct) || 0;
    const a = CORE.avoided(now, fee);
    const b = CORE.avoided(before, fee);
    const list = rows.sort((x, y) => (y.this_month - x.this_month) || (y.last_month - x.last_month));
    const total = (k) => list.reduce((t, r) => t + (Number(r[k]) || 0), 0);
    const moved = total('moved_by_client');
    return el('div', { class: 'oc-stack oc-stack--loose' }, [
      head('Sources', 'Where your appointments come from, and what booking direct saves you.'),
      el('div', { class: 'ap-kpis' }, [
        kpi('Saved in commissions this month', money(a.minor, s), `${a.clients} new ${a.clients === 1 ? 'client' : 'clients'} booked direct · last month ${money(b.minor, s)}`),
        kpi('New clients this month', String(now.length), `${now.filter((c) => CORE.isMarketplace(c.first_channel)).length} through a marketplace · last month ${before.length}`),
        kpi('Recovered from marketplaces', String(recovered), 'First came through a marketplace, now book direct'),
      ]),
      el('p', { class: 'oc-help' }, [`An estimate: each new client who booked direct × the price of their first appointment × ${fee}%, the marketplace fee in `, router.link('/settings', 'Settings'), '. It is what a marketplace like Fresha or Booksy would have charged for that client.']),
      el('section', { class: 'oc-card oc-card--pad0' }, [
        el('h2', { class: 'oc-eyebrow ap-group' }, 'Appointments booked, by source'),
        list.length ? el('table', { class: 'oc-table ap-table' }, [
          el('thead', el('tr', [el('th', 'Source'), el('th', { class: 'oc-num' }, 'This month'), el('th', { class: 'oc-num' }, 'Last month')])),
          el('tbody', list.map((r) => el('tr', [el('td', CORE.channelLabel(r.channel)), el('td', { class: 'oc-num' }, String(r.this_month || 0)), el('td', { class: 'oc-num' }, String(r.last_month || 0))]))),
          el('tfoot', el('tr', [el('td', 'Total'), el('td', { class: 'oc-num' }, String(total('this_month'))), el('td', { class: 'oc-num' }, String(total('last_month')))])),
        ]) : el('p', { class: 'oc-help ap-pad' }, 'No appointments booked in the last two months yet.'),
        moved ? el('p', { class: 'oc-help ap-pad' }, `${moved} moved by the client from their own link this month.`) : null,
      ]),
      links(s),
    ]);
  });
}

async function viewAll(name, filter) {
  const out = [];
  for (let offset = 0; offset < 5000; offset += 500) {
    const r = await Orch.db.view(name, Object.assign({ limit: 500, offset }, filter ? { filter } : {})).catch(() => ({ rows: [] }));
    out.push(...(r.rows || []));
    if (!r.hasMore) break;
  }
  return out;
}
const kpi = (label, value, note) => el('div', { class: 'oc-card ap-kpi' }, [el('span', { class: 'oc-eyebrow' }, label), el('span', { class: 'ap-kpi__value' }, value), el('span', { class: 'oc-help' }, note)]);

/** One link per channel, so the page knows where each client came from. */
export function links(s) {
  const base = publicLink(s);
  const custom = el('input', { class: 'oc-input', maxlength: '30', placeholder: 'flyer, tiktok, partner…' });
  const row = (label, src) => {
    const url = src ? `${base}?src=${src}` : base;
    return el('li', { class: 'ap-row' }, [
      el('span', { class: 'ap-row__main' }, [el('span', label), el('code', { class: 'ap-row__sub ap-code' }, url)]),
      el('button', { type: 'button', class: 'oc-btn oc-btn--sm', onClick: () => copy(url, `${label} link copied.`) }, 'Copy'),
    ]);
  };
  return el('section', { class: 'oc-card oc-card--pad0' }, [
    el('h2', { class: 'oc-eyebrow ap-group' }, 'A link for each place you share it'),
    el('p', { class: 'oc-help ap-pad' }, 'The same booking page; the end of the link tells you where each booking came from.'),
    el('ul', { class: 'ap-rows' }, [row('Booking page', ''), row('Instagram', 'instagram'), row('Google Maps', 'google'), row('Website', 'web'), row('WhatsApp', 'whatsapp'), row('Newsletter', 'newsletter')]),
    el('div', { class: 'ap-inline ap-pad' }, [custom, el('button', { type: 'button', class: 'oc-btn oc-btn--sm', onClick: () => {
      const src = CORE.slug(custom.value);
      if (src) copy(`${base}?src=${src}`, 'Link copied.');
    } }, 'Copy a link for it')]),
  ]);
}
export { SCH };
