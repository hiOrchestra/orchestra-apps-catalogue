// Settings: the business (what clients see), the booking rules, the emails
// from Gmail, the marketplace fee for Sources, and the optional email
// assistant. One Save for all; pausing online booking is its own button.
import { A, CORE, INTEGRATIONS, act, browserZone, copy, field, head, input, publicLink, select, settings } from '../data.js';

const { el, router } = Orch;
const ZONES = ['Europe/Madrid', 'Atlantic/Canary', 'Europe/London', 'Europe/Lisbon', 'Europe/Paris', 'Europe/Berlin', 'America/Mexico_City', 'America/Bogota', 'America/Lima',
  'America/Santiago', 'America/Argentina/Buenos_Aires', 'America/Sao_Paulo', 'America/New_York', 'America/Chicago', 'America/Los_Angeles', 'UTC'];
const yes = (v) => el('input', { type: 'checkbox', checked: v === 'yes' });
const check = (box, label, help) => el('label', { class: 'ap-check ap-check--block' }, [box, el('span', { class: 'oc-stack oc-stack--tight' }, [el('span', label), help ? el('span', { class: 'oc-help' }, help) : null])]);

export function render() {
  const again = () => render();
  Orch.load('view', async () => {
    const s = await settings();
    const f = {
      business_name: input({ value: s.business_name || '', maxlength: '120' }),
      address: input({ value: s.address || '', maxlength: '200' }),
      phone: input({ value: s.phone || '', maxlength: '25', type: 'tel' }),
      timezone: select([...new Set([s.timezone || browserZone(), ...ZONES])].map((z) => [z, z]), s.timezone),
      currency: select(CORE.CURRENCIES.map((c) => [c, c]), s.currency || 'EUR'),
      default_language: select([['es', 'Spanish'], ['en', 'English']], s.default_language || 'es'),
      intro: el('textarea', { class: 'oc-textarea', rows: '2', maxlength: '300' }, s.intro || ''),
      slot_step_min: select([[10, 'Every 10 minutes'], [15, 'Every 15 minutes'], [20, 'Every 20 minutes'], [30, 'Every 30 minutes'], [60, 'Every hour']], s.slot_step_min || 15),
      min_notice_min: select([[0, 'No notice'], [30, '30 minutes'], [60, '1 hour'], [120, '2 hours'], [240, '4 hours'], [720, '12 hours'], [1440, '1 day'], [2880, '2 days']], s.min_notice_min || 0),
      window_days: select([[7, '1 week'], [14, '2 weeks'], [30, '1 month'], [60, '2 months'], [90, '3 months'], [180, '6 months']], s.window_days || 60),
      change_hours: select([[0, 'Up to the start'], [2, '2 hours before'], [4, '4 hours before'], [12, '12 hours before'], [24, '24 hours before'], [48, '48 hours before']], s.change_hours || 0),
      marketplaces: input({ value: s.marketplaces || '', maxlength: '200' }),
      marketplace_fee_pct: input({ value: String(s.marketplace_fee_pct === null || s.marketplace_fee_pct === undefined ? 20 : s.marketplace_fee_pct), type: 'number', min: '0', max: '100', step: '1' }),
      notify_telegram: input({ value: s.notify_telegram || '', maxlength: '40', placeholder: 'A chat id or @username' }),
    };
    const langs = new Set(String(s.languages || 'es,en').split(',').map((x) => x.trim()));
    const es = el('input', { type: 'checkbox', checked: langs.has('es') });
    const en = el('input', { type: 'checkbox', checked: langs.has('en') });
    const t = { emails_on: yes(s.emails_on), reminder_24h: yes(s.reminder_24h === 'no' ? 'no' : 'yes'), reminder_2h: yes(s.reminder_2h), inbox_on: yes(s.inbox_on), rebook_on: yes(s.rebook_on) };
    const gmail = s.gmail_status === 'ok' ? `Gmail connected${s.gmail_account ? `: ${s.gmail_account}` : ''}.`
      : s.gmail_status === 'not_connected' ? 'Gmail is not connected.' : s.gmail_status === 'error' ? `Gmail did not answer: ${s.gmail_note || 'try Check again'}.` : 'Gmail has not been checked yet.';
    const link = publicLink(s);
    const form = el('form', { class: 'oc-stack oc-stack--loose ap-form', onSubmit: async (e) => {
      e.preventDefault();
      const languages = [es.checked ? 'es' : '', en.checked ? 'en' : ''].filter(Boolean).join(',') || 'es';
      const fee = Math.max(0, Math.min(100, Math.round(Number(f.marketplace_fee_pct.value) || 0)));
      const data = Object.fromEntries(Object.entries(f).map(([k, n]) => [k, typeof n.value === 'string' ? n.value.trim() : n.value]));
      for (const k of ['slot_step_min', 'min_notice_min', 'window_days', 'change_hours']) data[k] = Number(data[k]);
      Object.assign(data, { languages, marketplace_fee_pct: fee }, Object.fromEntries(Object.entries(t).map(([k, b]) => [k, b.checked ? 'yes' : 'no'])));
      if (!languages.includes(data.default_language)) data.default_language = languages.split(',')[0];
      if (await act(A.settings, Object.assign({ id: s._id }, data), 'Saved.')) again();
    } }, [
      card('Your business', 'What clients see on the booking page and in their emails.', [
        el('div', { class: 'ap-two' }, [field('Business name', f.business_name), field('Phone', f.phone, 'Shown to clients who need to call, e.g. after the change deadline.')]),
        field('Address', f.address),
        el('div', { class: 'ap-two' }, [field('Time zone', f.timezone), field('Currency', f.currency)]),
        el('fieldset', { class: 'ap-fieldset' }, [el('legend', { class: 'oc-label' }, 'Languages of the booking page and the emails'), el('div', { class: 'ap-checks' }, [check(es, 'Spanish'), check(en, 'English')])]),
        field('Main language', f.default_language, 'The one a client gets when their browser speaks neither.'),
        field('A line on top of the booking page (optional)', f.intro),
      ]),
      card('Booking rules', 'They apply to the booking page and to the agent. At the desk you can always book anyway.', [
        el('div', { class: 'ap-two' }, [field('Start times', f.slot_step_min), field('Minimum notice', f.min_notice_min, 'How soon before a time clients can still book it online.')]),
        el('div', { class: 'ap-two' }, [field('How far ahead', f.window_days), field('Clients can cancel or move', f.change_hours, 'From their own link. After that, the page says to call you.')]),
      ]),
      card('Emails from your Gmail', gmail, [
        el('div', { class: 'oc-row' }, [s.gmail_status !== 'ok' ? el('a', { class: 'oc-btn', href: INTEGRATIONS, target: '_top' }, 'Connect Gmail in Integrations') : null,
          el('button', { type: 'button', class: 'oc-btn oc-btn--ghost', onClick: async () => { if (await act(A.checkGmail, {}, 'Checking Gmail… look again in a moment.')) setTimeout(again, 4000); } }, 'Check again')]),
        check(t.emails_on, 'Send emails to clients', 'Their confirmation, any change or cancellation, and reminders. They go on their own, because the client booked.'),
        check(t.reminder_24h, 'A reminder the day before'),
        check(t.reminder_2h, 'Another reminder 2 hours before'),
      ]),
      card('Marketplaces', 'For Sources: what booking direct saves against them.', [
        field('Marketplaces you use', f.marketplaces, 'Comma separated, e.g. Fresha, Booksy, Treatwell. They appear in "Came from" when you add an appointment.'),
        field('Their fee for a new client (%)', f.marketplace_fee_pct, 'What your marketplace charges on a new client\'s first appointment (Fresha 20%, Booksy around 30%). Sources uses it to estimate what you saved.'),
      ]),
      card('Email assistant (optional)', 'The agent can read booking requests that arrive at your Gmail and answer them. Off unless you turn it on.', [
        check(t.inbox_on, 'Book from emails', 'New, change or cancel requests within your rules are booked and confirmed on their own; anything else waits in Messages for your Approve.'),
        check(t.rebook_on, 'Invite clients who are due back', 'Once a week the agent drafts a short invitation for each client past their service\'s "Rebook after". You approve each one.'),
        field('Telegram for your notices (optional)', f.notify_telegram, 'A short message when a client books, moves or cancels online.'),
      ]),
      el('div', { class: 'oc-row' }, [el('button', { type: 'submit', class: 'oc-btn oc-btn--primary' }, 'Save settings')]),
    ]);
    return el('div', { class: 'oc-stack oc-stack--loose' }, [
      head('Settings', 'Your business, the rules of online booking, and emails.'),
      el('section', { class: 'oc-card oc-stack ap-form' }, [
        el('div', { class: 'oc-row oc-row--between' }, [el('h2', { class: 'oc-h2' }, 'Online booking'), el('span', { class: `oc-badge${s.paused === 'yes' ? ' oc-badge--warn' : ' oc-badge--good'}` }, s.paused === 'yes' ? 'Paused' : 'Open')]),
        el('div', { class: 'ap-code' }, [el('code', link), el('button', { type: 'button', class: 'oc-btn oc-btn--sm', onClick: () => copy(link, 'Booking link copied.') }, 'Copy')]),
        el('p', { class: 'oc-help' }, ['A link per channel (Instagram, Google…) is in ', router.link('/sources', 'Sources'), '. Pausing hides every time on the page; the desk keeps working.']),
        el('div', { class: 'oc-row' }, [el('button', { type: 'button', class: 'oc-btn', onClick: async () => {
          if (await act(s.paused === 'yes' ? A.resume : A.pause, { id: s._id }, s.paused === 'yes' ? 'Online booking is open.' : 'Online booking is paused.')) again();
        } }, s.paused === 'yes' ? 'Open online booking' : 'Pause online booking')]),
      ]),
      form,
    ]);
  });
}

const card = (title, lede, children) => el('section', { class: 'oc-card oc-stack' }, [el('h2', { class: 'oc-h2' }, title), lede ? el('p', { class: 'oc-help' }, lede) : null, ...children]);
