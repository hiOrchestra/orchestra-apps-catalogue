// Clients: everyone who has booked, built on its own from the bookings (no
// import needed). A client's panel: phone and email, where they first came
// from, their notes, what is coming up and their history with no-shows.
// "Due to rebook" lists who passed their service's rebook interval with
// nothing booked (Services → Rebook after).
import { A, CORE, SCH, T, V, act, badge, dayOf, every, field, head, hhmm, input, money, settings, shortDay } from '../data.js';

const { el, router } = Orch;
const when = (v, s) => (v ? `${shortDay(dayOf(v, s))}, ${hhmm(v, s)}` : '—');

export function render(_p, path) {
  const due = String(path || '').startsWith('/clients/due');
  Orch.load('view', async () => {
    const s = await settings();
    const host = el('div');
    const tabs = el('nav', { class: 'oc-tabs', 'aria-label': 'Which clients' }, [
      router.link('/clients', 'All clients', { class: `oc-tab${due ? '' : ' oc-tab--active'}`, 'aria-current': due ? null : 'page' }),
      router.link('/clients/due', 'Due to rebook', { class: `oc-tab${due ? ' oc-tab--active' : ''}`, 'aria-current': due ? 'page' : null }),
    ]);
    if (due) {
      const rows = (await Orch.db.view(V.rebook, { sort: 'due_on:asc', limit: 200 })).rows || [];
      host.append(rows.length ? el('ul', { class: 'ap-rows oc-card oc-card--pad0' }, rows.map((r) => el('li', { class: 'ap-row' }, [
        el('a', { class: 'ap-row__main', href: `#/clients?open=${r.client_id}` }, [el('span', r.name), el('span', { class: 'ap-row__sub' }, `${r.service} · every ${r.rebook_weeks} weeks`)]),
        el('span', { class: 'oc-value ap-row__fact' }, `Last ${shortDay(dayOf(r.last_at, s))}`),
        el('span', { class: 'ap-row__fact' }, r.invited_at ? 'Invited' : (r.phone || r.email || '')),
      ]))) : el('div', { class: 'oc-card oc-state' }, [el('p', { class: 'oc-state__title' }, 'Nobody is due.'),
        el('p', { class: 'oc-help' }, 'Set "Rebook after" on a service (in Services) and clients who passed it with nothing booked appear here.')]));
    } else {
      setTimeout(() => Orch.table({
        into: host, path: '/clients', query: path, view: V.clients, pageSize: 25, sort: 'last_at:desc', search: 'name', searchPlaceholder: 'Find by name',
        columns: [
          { key: 'name', label: 'Name', format: (v) => v || '—' },
          { key: 'phone', label: 'Phone', format: (v) => v || '—' },
          { key: 'visits', label: 'Visits', numeric: true },
          { key: 'no_shows', label: 'No-shows', numeric: true, format: (v) => (v ? String(v) : '—') },
          { key: 'next_at', label: 'Next', format: (v) => when(v, s) },
          { key: 'last_at', label: 'Last visit', format: (v) => when(v, s) },
        ],
        detail: { table: T.clients, title: 'Client', render: (row) => panel(row, s) },
        empty: 'No clients yet. Everyone who books (online, by phone or by email) appears here on their own.',
      }), 0);
    }
    return el('div', { class: 'oc-stack oc-stack--loose' }, [
      head('Clients', due ? 'Clients past the rebook interval of their service, with nothing booked.' : 'Everyone who has booked, with their history and notes.'),
      tabs, host,
    ]);
  });
}

async function panel(c, s) {
  const list = await every(T.bookings, { filter: { client_id: c._id }, sort: 'start_at:desc' });
  const now = new Date().toISOString();
  const coming = list.filter((b) => b.status === 'Booked' && b.start_at > now).reverse();
  const past = list.filter((b) => !(b.status === 'Booked' && b.start_at > now));
  const noShows = list.filter((b) => b.status === 'NoShow').length;
  const name = input({ value: c.name || '', maxlength: '120' });
  const phone = input({ type: 'tel', value: c.phone || '', maxlength: '25' });
  const email = input({ type: 'email', value: c.email || '', maxlength: '200' });
  const notes = el('textarea', { class: 'oc-textarea', rows: '3', maxlength: '2000' }, c.notes || '');
  const item = (b) => el('li', { class: 'ap-hist' }, [
    el('span', { class: 'oc-value' }, when(b.start_at, s)),
    el('span', `${b.service_name} · ${b.staff_name}`),
    b.status === 'Booked' ? el('span', { class: 'oc-value' }, money(b.price_minor, s)) : badge(b.status),
  ]);
  return el('div', { class: 'oc-stack' }, [
    el('p', { class: 'oc-help' }, [`First came from ${CORE.channelLabel(c.first_channel || c.source)}`, noShows ? ` · ${noShows} no-show${noShows > 1 ? 's' : ''}` : '', ` · since ${shortDay(dayOf(c.since || c._created_at, s))}`].join('')),
    el('section', { class: 'oc-stack oc-stack--tight' }, [el('h3', { class: 'oc-eyebrow' }, 'Coming up'),
      coming.length ? el('ul', { class: 'ap-hist__list' }, coming.map(item)) : el('p', { class: 'oc-help' }, 'Nothing booked.')]),
    el('form', { class: 'oc-stack', onSubmit: async (e) => {
      e.preventDefault();
      if (email.value.trim() && !CORE.isEmail(email.value)) { Orch.toast('That email does not look right.', { error: true }); return; }
      await act(A.client, { id: c._id, name: CORE.cleanName(name.value), phone: CORE.normPhone(phone.value), phone_key: CORE.phoneKey(phone.value),
        email: CORE.normEmail(email.value), notes: notes.value.trim() }, 'Saved.');
    } }, [
      field('Name', name),
      el('div', { class: 'ap-two' }, [field('Phone', phone), field('Email', email)]),
      field('Notes', notes, 'Allergies, preferences, the colour formula… Only your team sees them.'),
      el('div', { class: 'oc-row' }, [el('button', { type: 'submit', class: 'oc-btn' }, 'Save')]),
    ]),
    el('section', { class: 'oc-stack oc-stack--tight' }, [el('h3', { class: 'oc-eyebrow' }, `History · ${past.length}`),
      past.length ? el('ul', { class: 'ap-hist__list' }, past.slice(0, 40).map(item)) : el('p', { class: 'oc-help' }, 'No visits yet.')]),
  ]);
}
export { SCH };
