// One person: name, the services they do, their weekly hours with a break,
// an optional daily limit, and their days off. Hours are kept as
// {mon: [["09:00","14:00"],["15:00","20:00"]]}: the gap is the break.
import { A, SCH, act, every, field, head, input, settings, shortDay, today } from '../data.js';

const { el, router } = Orch;
const DAYS = [['mon', 'Monday'], ['tue', 'Tuesday'], ['wed', 'Wednesday'], ['thu', 'Thursday'], ['fri', 'Friday'], ['sat', 'Saturday'], ['sun', 'Sunday']];
const time = (v) => el('input', { class: 'oc-input', type: 'time', step: '300', value: v || '' });

export function render(params) {
  const again = () => render(params);
  Orch.load('view', async () => {
    const id = params && Number(params.id);
    const [s, people, services, offs] = await Promise.all([
      settings(), every('ap_staff', { sort: 'position:asc' }), every('ap_services', { sort: 'position:asc' }),
      id ? every('ap_time_off', { filter: { staff_id: id, active: 'yes' }, sort: 'day_from:asc' }) : [],
    ]);
    const p = id ? people.find((x) => Number(x._id) === id) : null;
    if (id && !p) return el('div', { class: 'oc-state' }, [el('p', 'This person is not in the team.'), router.link('/team', 'Back to the team')]);
    const hours = SCH.hoursOf(p ? p.hours : { mon: [['09:00', '14:00'], ['15:00', '19:00']], tue: [['09:00', '14:00'], ['15:00', '19:00']], wed: [['09:00', '14:00'], ['15:00', '19:00']], thu: [['09:00', '14:00'], ['15:00', '19:00']], fri: [['09:00', '14:00'], ['15:00', '19:00']] });
    const mine = new Set(p ? SCH.servicesOf(p) : services.filter((x) => x.active === 'yes').map((x) => Number(x._id)));
    const name = input({ value: p ? p.name : '', maxlength: '80', required: true });
    const limit = el('select', { class: 'oc-select' }, [0, 2, 3, 4, 5, 6, 8, 10, 12, 15].map((n) => el('option', { value: String(n), selected: n === (Number(p && p.max_per_day) || 0) }, n ? `At most ${n} a day` : 'No limit')));
    const checks = services.filter((x) => x.active === 'yes' || mine.has(Number(x._id))).map((x) => ({ x, box: el('input', { type: 'checkbox', checked: mine.has(Number(x._id)) }) }));
    const rows = DAYS.map(([k, label]) => {
      const r = hours[k] || [];
      const works = el('input', { type: 'checkbox', checked: r.length > 0 });
      const a = time(r.length ? r[0][0] : '09:00');
      const b = time(r.length ? r[r.length - 1][1] : '19:00');
      const ba = time(r.length > 1 ? r[0][1] : '');
      const bb = time(r.length > 1 ? r[1][0] : '');
      const sync = () => { for (const x of [a, b, ba, bb]) x.disabled = !works.checked; };
      works.addEventListener('change', sync);
      sync();
      return { k, works, a, b, ba, bb, node: el('div', { class: 'ap-hours__row' }, [
        el('label', { class: 'ap-check ap-hours__day' }, [works, el('span', label)]),
        el('span', { class: 'ap-hours__pair' }, [a, el('span', { class: 'oc-muted' }, 'to'), b]),
        el('span', { class: 'ap-hours__pair' }, [el('span', { class: 'oc-muted' }, 'break'), ba, el('span', { class: 'oc-muted' }, 'to'), bb]),
      ]) };
    });
    const read = () => {
      const out = {};
      for (const r of rows) {
        if (!r.works.checked) continue;
        const [a, b, ba, bb] = [r.a.value, r.b.value, r.ba.value, r.bb.value].map(SCH.hm);
        if (a === null || b === null || a >= b) throw new Error(`${r.k}: the day should end after it starts`);
        if ((ba === null) !== (bb === null)) throw new Error(`${r.k}: a break needs a start and an end`);
        if (ba !== null && !(a < ba && ba < bb && bb < b)) throw new Error(`${r.k}: the break should sit inside the day`);
        out[r.k] = ba === null ? [[SCH.clock(a), SCH.clock(b)]] : [[SCH.clock(a), SCH.clock(ba)], [SCH.clock(bb), SCH.clock(b)]];
      }
      return out;
    };
    const form = el('form', { class: 'oc-stack ap-form', onSubmit: async (e) => {
      e.preventDefault();
      let h;
      try { h = read(); } catch (err) { Orch.toast(err.message.replace(/^(\w{3})/, (m) => m[0].toUpperCase() + m.slice(1)), { error: true }); return; }
      const data = { name: name.value.trim(), hours: JSON.stringify(h), services: JSON.stringify(checks.filter((c) => c.box.checked).map((c) => Number(c.x._id))), max_per_day: Number(limit.value) };
      const r = p ? await act(A.updateStaff, Object.assign({ id: p._id }, data), 'Saved.') : await act(A.createStaff, Object.assign({ position: people.length + 1, email: '' }, data), 'Added to the team.');
      if (r) router.go(p ? `/team/${p._id}` : (r._id ? `/team/${r._id}` : '/team'));
      if (r && p) again();
    } }, [
      field('Name', name),
      el('fieldset', { class: 'ap-fieldset' }, [el('legend', { class: 'oc-label' }, 'Services they do'),
        checks.length ? el('div', { class: 'ap-checks' }, checks.map((c) => el('label', { class: 'ap-check' }, [c.box, el('span', c.x.name)])))
          : el('p', { class: 'oc-help' }, ['No services yet. ', router.link('/services', 'Add them in Services')])]),
      el('fieldset', { class: 'ap-fieldset' }, [el('legend', { class: 'oc-label' }, 'Weekly hours'), el('p', { class: 'oc-help' }, 'Leave the break empty when there is none. Clients can only book inside these hours.'),
        el('div', { class: 'ap-hours' }, rows.map((r) => r.node))]),
      field('Daily limit', limit, 'Optional: after this many appointments in a day, nobody can book them that day.'),
      el('div', { class: 'oc-row' }, [el('button', { type: 'submit', class: 'oc-btn oc-btn--primary' }, p ? 'Save' : 'Add to the team'),
        p ? el('button', { type: 'button', class: 'oc-btn oc-btn--ghost', onClick: async () => {
          if (await act(p.active === 'yes' ? A.staffOff : A.staffOn, { id: p._id }, p.active === 'yes' ? 'Not bookable any more. Their booked appointments stay.' : 'Bookable again.')) again();
        } }, p.active === 'yes' ? 'Stop taking bookings' : 'Take bookings again') : null]),
    ]);
    return el('div', { class: 'oc-stack oc-stack--loose' }, [
      router.link('/team', '← Team', { class: 'ap-back' }),
      head(p ? p.name : 'New person', p ? (p.active === 'yes' ? 'Takes appointments.' : 'Not taking appointments: clients cannot book them.') : 'Their hours and services decide what clients can book with them.'),
      form,
      p ? offPanel(p, offs.filter((o) => o.day_to >= today(s)), again) : null,
    ]);
  });
}

function offPanel(p, offs, again) {
  const from = el('input', { class: 'oc-input', type: 'date', required: true });
  const to = el('input', { class: 'oc-input', type: 'date' });
  const why = input({ maxlength: '80', placeholder: 'Holiday, course…' });
  return el('section', { class: 'oc-card oc-stack ap-form' }, [
    el('h2', { class: 'oc-h2' }, 'Days off'),
    el('p', { class: 'oc-help' }, `Nobody can book ${p.name} on these days. Appointments already on them stay: move them from Today.`),
    offs.length ? el('ul', { class: 'ap-rows' }, offs.map((o) => el('li', { class: 'ap-row' }, [
      el('span', { class: 'ap-row__main' }, [el('span', o.day_to !== o.day_from ? `${shortDay(o.day_from)} – ${shortDay(o.day_to)}` : shortDay(o.day_from)), el('span', { class: 'ap-row__sub' }, o.note || ' ')]),
      el('button', { type: 'button', class: 'oc-btn oc-btn--sm oc-btn--ghost', onClick: async () => { if (await act(A.removeOff, { id: o._id }, 'Removed.')) again(); } }, 'Remove'),
    ]))) : null,
    el('form', { class: 'ap-inline', onSubmit: async (e) => {
      e.preventDefault();
      if (!SCH.realDay(from.value) || (to.value && to.value < from.value)) { Orch.toast('Pick the first day (and a last day after it).', { error: true }); return; }
      if (await act(A.addOff, { staff_id: p._id, day_from: from.value, day_to: to.value || from.value, note: why.value.trim() }, 'Day off saved.')) again();
    } }, [field('From', from), field('To (optional)', to), field('Why (only your team sees it)', why), el('button', { type: 'submit', class: 'oc-btn' }, 'Add days off')]),
  ]);
}
