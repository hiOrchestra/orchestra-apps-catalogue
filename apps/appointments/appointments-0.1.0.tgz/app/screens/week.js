// Week: seven days side by side, each with its appointments in order (time,
// client, who). A day's name opens it on Today; an appointment opens its
// panel. ← → move a week; /week/<day> is the week of that day.
import { CORE, SCH, T, every, head, hhmm, ruleData, settings, shortDay, today as todayOf, zoneOf } from '../data.js';
import { openBooking } from './booking.js';

const { el, router } = Orch;

/** The Monday of the week a day is in. */
const monday = (day) => { const n = new Date(`${day}T12:00:00Z`).getUTCDay(); return SCH.addDays(day, -((n + 6) % 7)); };

export function render(params) {
  const again = () => render(params);
  Orch.load('view', async () => {
    const s = await settings();
    const tz = zoneOf(s);
    const now = todayOf(s);
    const first = monday(params && SCH.realDay(params.day) ? params.day : now);
    const last = SCH.addDays(first, 6);
    const from = new Date(SCH.localToUtc(first, '00:00', tz)).toISOString();
    const to = new Date(SCH.localToUtc(SCH.addDays(last, 1), '00:00', tz)).toISOString();
    const [d, rows] = await Promise.all([
      ruleData(s, first, last),
      every(T.bookings, { filter: { status: ['Booked', 'Arrived', 'NoShow'], start_at: { gte: from, lt: to } }, sort: 'start_at:asc' }),
    ]);
    const initials = new Map(d.staff.map((p) => [Number(p._id), p.name]));
    const total = rows.filter((b) => b.status !== 'NoShow').length;
    const income = rows.filter((b) => b.status !== 'NoShow').reduce((t, b) => t + (Number(b.price_minor) || 0), 0);
    const days = Array.from({ length: 7 }, (_, i) => SCH.addDays(first, i));
    return el('div', { class: 'oc-stack oc-stack--loose' }, [
      head('Week', `${shortDay(first)} – ${shortDay(last)} · ${total} ${total === 1 ? 'appointment' : 'appointments'} · ${CORE.money(income, s.currency || 'EUR', 'en')} booked`, [
        router.link(`/week/${SCH.addDays(first, -7)}`, '← Week before', { class: 'oc-btn oc-btn--ghost oc-btn--sm' }),
        first !== monday(now) ? router.link('/week', 'This week', { class: 'oc-btn oc-btn--ghost oc-btn--sm' }) : null,
        router.link(`/week/${SCH.addDays(first, 7)}`, 'Week after →', { class: 'oc-btn oc-btn--ghost oc-btn--sm' }),
      ]),
      el('div', { class: 'oc-scroll-x' }, el('div', { class: 'ap-week' }, days.map((day) => {
        const mine = rows.filter((b) => SCH.localDay(SCH.ms(b.start_at), tz) === day);
        const n = mine.filter((b) => b.status !== 'NoShow').length;
        const closed = SCH.isOff(0, day, d.offs) || !d.staff.some((p) => p.active === 'yes' && (SCH.hoursOf(p.hours)[SCH.weekday(day)] || []).length && !SCH.isOff(p._id, day, d.offs));
        return el('section', { class: `ap-week__day${day === now ? ' ap-week__day--today' : ''}` }, [
          el('a', { class: 'ap-week__head', href: `#/day/${day}` }, [el('span', shortDay(day)), el('span', { class: 'oc-eyebrow' }, n ? `${n} booked` : (closed ? 'Closed' : 'Free'))]),
          el('ul', { class: 'ap-week__list' }, mine.map((b) => el('li', {}, el('button', { type: 'button', class: `ap-week__item ap-week__item--${b.status.toLowerCase()}`,
            onClick: () => openBooking({ s, d, day, again }, b) }, [
            el('span', { class: 'oc-value' }, hhmm(b.start_at, s)),
            el('span', { class: 'ap-week__who' }, b.client_name),
            el('span', { class: 'ap-week__with' }, `${b.service_name} · ${(initials.get(Number(b.staff_id)) || b.staff_name || '').split(' ')[0]}`),
          ])))),
        ]);
      }))),
    ]);
  });
}
