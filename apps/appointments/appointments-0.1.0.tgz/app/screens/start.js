// Getting started, on top of Today: what a fresh install needs before a
// client can book. Each step is judged from the data every time it draws,
// never ticked by hand; Gmail is optional (bookings work without it, they
// just send no email). Hidden for good with Hide (kept in ap_settings).
import { A, INTEGRATIONS, SCH, act, browserZone, copy, field, input, publicLink, select } from '../data.js';

const { el, router } = Orch;
const ZONES = ['Europe/Madrid', 'Atlantic/Canary', 'Europe/London', 'Europe/Lisbon', 'Europe/Paris', 'America/Mexico_City', 'America/Bogota',
  'America/Lima', 'America/Santiago', 'America/Argentina/Buenos_Aires', 'America/New_York', 'America/Los_Angeles', 'UTC'];

const hasHours = (p) => Object.values(SCH.hoursOf(p.hours)).some((r) => r.length);
export function steps(s, d) {
  const team = d.staff.filter((p) => p.active === 'yes');
  return [
    { id: 'business', title: 'Your business', done: Boolean(String(s.business_name || '').trim() && s.timezone) },
    { id: 'services', title: 'Your services', done: d.services.some((x) => x.active === 'yes') },
    { id: 'team', title: 'Your team and their hours', done: team.some((p) => hasHours(p) && SCH.servicesOf(p).length) },
    { id: 'gmail', title: 'Emails from your Gmail (optional)', done: s.gmail_status === 'ok' && s.emails_on === 'yes', optional: true },
  ];
}

const WHY = {
  business: 'Clients see this name on the booking page and in their emails. Times are kept in this time zone.',
  services: 'What clients can book: each with its length, price and the minutes you need before or after it.',
  team: 'Who takes appointments, their weekly hours with breaks, and which services each one does. Their columns appear on Today.',
  gmail: 'Optional. With your Gmail connected, clients get their confirmation, a reminder the day before and any change, from your own address. Without it bookings work the same, with no emails.',
};

function body(x, s, again) {
  if (x.id === 'business') {
    const name = input({ value: s.business_name || '', maxlength: '120', required: true });
    const zone = select([...new Set([s.timezone || browserZone(), ...ZONES])].map((z) => [z, z]), s.timezone || browserZone());
    return el('form', { class: 'oc-stack ap-start__form', onSubmit: async (e) => {
      e.preventDefault();
      if (await act(A.settings, { id: s._id, business_name: name.value.trim(), timezone: zone.value }, 'Saved.')) again();
    } }, [el('div', { class: 'ap-two' }, [field('Business name', name), field('Time zone', zone)]), el('div', { class: 'oc-row' }, [el('button', { type: 'submit', class: 'oc-btn oc-btn--primary' }, 'Save')])]);
  }
  if (x.id === 'services') return el('div', { class: 'oc-row' }, [router.link('/services', 'Add your services', { class: 'oc-btn oc-btn--primary' })]);
  if (x.id === 'team') return el('div', { class: 'oc-row' }, [router.link('/team', 'Add your team', { class: 'oc-btn oc-btn--primary' })]);
  const state = s.gmail_status === 'ok' ? `Connected${s.gmail_account ? `: ${s.gmail_account}` : ''}.`
    : s.gmail_status === 'not_connected' ? 'Gmail is not connected yet.' : s.gmail_status === 'error' ? `Gmail did not answer: ${s.gmail_note || ''}` : 'Not checked yet.';
  return el('div', { class: 'oc-stack oc-stack--tight' }, [
    el('p', { class: 'ap-start__state' }, state),
    el('div', { class: 'oc-row' }, [
      s.gmail_status !== 'ok' ? el('a', { class: 'oc-btn', href: INTEGRATIONS, target: '_top' }, 'Connect Gmail in Integrations') : null,
      el('button', { type: 'button', class: 'oc-btn oc-btn--ghost', onClick: async () => { if (await act(A.checkGmail, {}, 'Checking Gmail… look again in a moment.')) setTimeout(again, 4000); } }, 'Check again'),
      s.gmail_status === 'ok' && s.emails_on !== 'yes'
        ? el('button', { type: 'button', class: 'oc-btn oc-btn--primary', onClick: async () => { if (await act(A.settings, { id: s._id, emails_on: 'yes' }, 'Emails are on.')) again(); } }, 'Send emails from it') : null,
    ]),
  ]);
}

/** The panel, or null once hidden. */
export function startPanel(s, d, again) {
  if (s.onboarding_dismissed_at) return null;
  const list = steps(s, d);
  const needed = list.filter((x) => !x.optional);
  const left = needed.filter((x) => !x.done).length;
  if (!left) {
    const link = publicLink(s);
    return el('section', { class: 'oc-card ap-start ap-start--done', 'aria-label': 'Getting started' }, [
      el('div', { class: 'ap-start__line' }, [
        el('span', { class: 'oc-eyebrow' }, 'Getting started · done'),
        el('p', { class: 'ap-start__said' }, list[3].done ? 'Clients can book from your page, and they get their emails.' : 'Clients can book from your page. Emails are optional: connect Gmail in Settings when you want them.'),
        el('button', { type: 'button', class: 'oc-btn oc-btn--sm', onClick: () => copy(link, 'Booking page link copied.') }, 'Copy booking link'),
        el('button', { type: 'button', class: 'oc-btn oc-btn--sm oc-btn--ghost', onClick: async () => { if (await act(A.dismissStart, { id: s._id })) again(); } }, 'Hide this'),
      ]),
    ]);
  }
  let open = (list.find((x) => !x.done) || list[0]).id;
  const host = el('ol', { class: 'ap-steps' });
  const draw = () => host.replaceChildren(...list.map((x, i) => {
    const isOpen = x.id === open;
    return el('li', { class: `ap-step${x.done ? ' ap-step--done' : ''}` }, [
      el('button', { type: 'button', class: 'ap-step__head', 'aria-expanded': String(isOpen), onClick: () => { open = isOpen ? '' : x.id; draw(); } }, [
        el('span', { class: 'oc-value ap-step__n' }, String(i + 1).padStart(2, '0')),
        el('span', { class: 'ap-step__title' }, x.title),
        el('span', { class: `oc-badge${x.done ? ' oc-badge--good' : ''}` }, x.done ? 'Done' : (x.optional ? 'Optional' : 'To do')),
      ]),
      isOpen ? el('div', { class: 'ap-step__body oc-stack' }, [el('p', { class: 'ap-step__why' }, WHY[x.id]), body(x, s, again)]) : null,
    ]);
  }));
  draw();
  return el('section', { class: 'oc-card oc-card--pad0 ap-start', 'aria-label': 'Getting started' }, [
    el('header', { class: 'ap-start__head' }, [el('h2', { class: 'oc-h2' }, 'Getting started'), el('span', { class: 'oc-eyebrow' }, `${needed.length - left} of ${needed.length} done`)]),
    el('p', { class: 'oc-help ap-start__lede' }, 'Three steps before clients can book online. Each one ticks itself when it is done.'),
    host,
  ]);
}
