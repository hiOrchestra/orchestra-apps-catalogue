// Services: what clients can book, thin rows grouped by category (length,
// price, buffers), and an editor in a dialog. Turning one off takes it off
// the booking page; appointments already booked stay.
import { A, CORE, act, every, field, head, input, mins, money, settings, sheet } from '../data.js';

const { el } = Orch;

export function render() {
  const again = () => render();
  Orch.load('view', async () => {
    const [s, list] = await Promise.all([settings(), every('ap_services', { sort: 'position:asc' })]);
    const groups = new Map();
    for (const x of list.sort((a, b) => (a.active === b.active ? 0 : a.active === 'yes' ? -1 : 1) || (a.position || 0) - (b.position || 0) || a._id - b._id)) {
      const k = x.category || '';
      if (!groups.has(k)) groups.set(k, []);
      groups.get(k).push(x);
    }
    return el('div', { class: 'oc-stack oc-stack--loose' }, [
      head('Services', 'What clients can book: its length, price, and the minutes you need before or after it.', [
        el('button', { type: 'button', class: 'oc-btn oc-btn--primary', onClick: () => edit(null, s, list, again) }, 'New service'),
      ]),
      list.length ? el('div', { class: 'oc-stack' }, [...groups].map(([cat, rows]) => el('section', { class: 'oc-card oc-card--pad0' }, [
        el('h2', { class: 'oc-eyebrow ap-group' }, cat || 'Services'),
        el('ul', { class: 'ap-rows' }, rows.map((x) => el('li', { class: `ap-row${x.active === 'yes' ? '' : ' ap-row--off'}` }, [
          el('button', { type: 'button', class: 'ap-row__main', onClick: () => edit(x, s, list, again) }, [
            el('span', x.name),
            el('span', { class: 'ap-row__sub' }, [x.buffer_before_min ? `${x.buffer_before_min} min before` : '', x.buffer_after_min ? `${x.buffer_after_min} min after` : '',
              x.rebook_weeks ? `rebook after ${x.rebook_weeks} weeks` : ''].filter(Boolean).join(' · ') || ' '),
          ]),
          el('span', { class: 'oc-value ap-row__fact' }, mins(Number(x.duration_min) || 0)),
          el('span', { class: 'oc-value ap-row__fact' }, money(x.price_minor, s)),
          x.active === 'yes' ? el('span', { class: 'ap-row__fact' }) : el('span', { class: 'oc-badge' }, 'Off'),
        ]))),
      ]))) : el('div', { class: 'oc-card oc-state' }, [
        el('p', { class: 'oc-state__title' }, 'No services yet.'),
        el('p', { class: 'oc-help' }, 'Add what you offer: a cut, a colour, a massage. Clients pick from this list on the booking page.'),
        el('button', { type: 'button', class: 'oc-btn', onClick: () => edit(null, s, list, again) }, 'Add the first service'),
      ]),
    ]);
  });
}

const LENGTHS = [10, 15, 20, 25, 30, 40, 45, 50, 60, 75, 90, 105, 120, 150, 180, 210, 240];
const BUFFERS = [0, 5, 10, 15, 20, 30, 45, 60];
const opts = (list, v, f) => [...new Set([...list, Number(v) || 0])].sort((a, b) => a - b).map((n) => el('option', { value: String(n), selected: n === (Number(v) || 0) }, f(n)));

function edit(x, s, all, again) {
  const name = input({ value: x ? x.name : '', maxlength: '80', required: true });
  const cat = input({ value: x ? x.category || '' : '', maxlength: '40', list: 'ap-cats', placeholder: 'Hair, Nails, Massage…' });
  const cats = el('datalist', { id: 'ap-cats' }, [...new Set(all.map((r) => r.category).filter(Boolean))].map((c) => el('option', { value: c })));
  const len = el('select', { class: 'oc-select' }, opts(LENGTHS, x ? x.duration_min : 30, (n) => (n >= 60 ? `${Math.floor(n / 60)} h ${n % 60 ? `${n % 60} min` : ''}`.trim() : `${n} min`)));
  const price = input({ value: x ? String(CORE.fromMinor(x.price_minor, s.currency)) : '', inputmode: 'decimal', maxlength: '12' });
  const before = el('select', { class: 'oc-select' }, opts(BUFFERS, x ? x.buffer_before_min : 0, (n) => (n ? `${n} min` : 'None')));
  const after = el('select', { class: 'oc-select' }, opts(BUFFERS, x ? x.buffer_after_min : 0, (n) => (n ? `${n} min` : 'None')));
  const rebook = el('select', { class: 'oc-select' }, opts([0, 2, 3, 4, 5, 6, 8, 10, 12], x ? x.rebook_weeks : 0, (n) => (n ? `${n} weeks` : 'No')));
  const desc = el('textarea', { class: 'oc-textarea', rows: '2', maxlength: '300' }, x ? x.description || '' : '');
  const form = el('form', { class: 'oc-stack', onSubmit: async (e) => {
    e.preventDefault();
    const minor = CORE.toMinor(price.value, s.currency);
    if (minor === null) { Orch.toast('The price should be a number, like 25 or 25,50.', { error: true }); return; }
    const data = { name: name.value.trim(), category: cat.value.trim(), description: desc.value.trim(), duration_min: Number(len.value), price_minor: minor,
      buffer_before_min: Number(before.value), buffer_after_min: Number(after.value), rebook_weeks: Number(rebook.value) };
    const ok = x ? await act(A.updateService, Object.assign({ id: x._id }, data), 'Saved.')
      : await act(A.createService, Object.assign({ position: all.length + 1 }, data), 'Added. Now say who does it, in Team.');
    if (ok) { d.close(); again(); }
  } }, [
    el('div', { class: 'ap-two' }, [field('Name', name), field('Category (optional)', cat)]), cats,
    el('div', { class: 'ap-two' }, [field('Length', len), field(`Price (${s.currency || 'EUR'})`, price)]),
    el('div', { class: 'ap-two' }, [field('Time before', before, 'Set-up the client does not see: the person is busy, the slot starts after it.'),
      field('Time after', after, 'Clean-up or drying: the next client can start only after it.')]),
    field('Rebook after', rebook, 'When a client is due again: they appear in Clients → Due to rebook.'),
    field('Description (optional)', desc, 'Shown under the name on the booking page.'),
    el('div', { class: 'oc-row' }, [
      el('button', { type: 'submit', class: 'oc-btn oc-btn--primary' }, x ? 'Save' : 'Add service'),
      x ? el('button', { type: 'button', class: 'oc-btn oc-btn--ghost', onClick: async () => {
        if (await act(x.active === 'yes' ? A.serviceOff : A.serviceOn, { id: x._id }, x.active === 'yes' ? 'Off the booking page. Booked appointments stay.' : 'Back on the booking page.')) { d.close(); again(); }
      } }, x.active === 'yes' ? 'Turn off' : 'Turn on') : null,
    ]),
  ]);
  const d = sheet(form, { title: x ? x.name : 'New service' });
}
