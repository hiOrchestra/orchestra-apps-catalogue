// The router and the bar. Today is home: the agenda of the day, one column per
// person. Week is the next days at a glance; Clients, Services and Team are
// the business's lists; Messages holds what waits for a person (emails to
// approve, ones that could not go); Settings the rest.
import { render as today } from './screens/today.js';
import { render as week } from './screens/week.js';
import { render as clients } from './screens/clients.js';
import { render as services } from './screens/services.js';
import { render as staff } from './screens/staff.js';
import { render as staffEdit } from './screens/staff-edit.js';
import { render as messages } from './screens/messages.js';
import { render as sources } from './screens/sources.js';
import { render as settings } from './screens/settings.js';
import { T } from './data.js';

const { el, router } = Orch;

router.define({
  '/': today,
  '/day/:day': today,
  '/week': week,
  '/week/:day': week,
  '/clients': clients,
  '/clients/due': clients,
  '/services': services,
  '/team': staff,
  '/team/new': staffEdit,
  '/team/:id': staffEdit,
  '/sources': sources,
  '/messages': messages,
  '/settings': settings,
}, () => Orch.mount('view', el('div', { class: 'oc-state' }, [el('p', 'There is no screen here.'), router.link('/', 'Go to today')]))).start();

const waiting = el('span', { class: 'oc-count', hidden: true });
Orch.mount('nav', [
  router.link('/', 'Today', { class: 'oc-tab' }),
  router.link('/week', 'Week', { class: 'oc-tab' }),
  router.link('/clients', 'Clients', { class: 'oc-tab' }),
  router.link('/services', 'Services', { class: 'oc-tab' }),
  router.link('/team', 'Team', { class: 'oc-tab' }),
  router.link('/sources', 'Sources', { class: 'oc-tab' }),
  router.link('/messages', ['Messages', waiting], { class: 'oc-tab' }),
  router.link('/settings', 'Settings', { class: 'oc-tab' }),
]);

// The number on Messages: emails waiting for a person's Approve or a retry.
async function count() {
  try {
    const n = await Orch.db.count(T.emails, { filter: { status: ['Review', 'Failed'] } });
    waiting.textContent = String(n);
    waiting.hidden = !n;
  } catch { waiting.hidden = true; }
}
count();
window.addEventListener('hashchange', count);
