'use strict';
/**
 * Appointments · the one door every booking goes through: the public page
 * (through intake.js), the desk's phone bookings and moves, the agent's tool
 * (book.js) and the email agent (inbox.js). Each change is judged by the
 * same slot rules (sched.js) on data read fresh, and written in ONE
 * transaction: the booking, its 5-minute holds (a unique index, so the same
 * person's time can never be given twice, whatever wrote first), the
 * request's verdict, the client's sealed link and the email the client asked
 * for (Queued: it goes out on its own, because they asked).
 *
 *   newBooking(req)   req: an ap_requests row (kind new)
 *   cancel(booking, {by, reason, deadline})
 *   move(booking, {start_at, staff_id, deadline, req})
 *   aftercare()       holds of finished bookings released, notices of desk
 *                     cancellations queued, every client link up to date
 */
const L = require('./lib');
const S = require('./sched');
const C = require('./aptcore');

const ids = (r) => { const j = S.json(r.service_ids, null); return (Array.isArray(j) && j.length ? j : [r.service_id]).map(Number).filter(Boolean); };
const clashOf = (e) => /UNIQUE|constraint/i.test(String(e && e.message));
const linkOf = (s, token) => (token && s.public_url ? `${s.public_url}#/c/${token}` : '');

/** Find the client by email, then phone; otherwise make one. Returns the id or '$c._id', and the ops. */
function clientOps(req, lang, channel) {
  const email = C.isEmail(req.email) ? C.normEmail(req.email) : '';
  const phone = C.normPhone(req.phone);
  const key = C.phoneKey(phone);
  let c = email ? L.one('SELECT * FROM ap_clients WHERE _deleted = 0 AND email = ? ORDER BY _id LIMIT 1', email) : null;
  // A phone finds a client only when the email does not say it is someone else.
  if (!c && key.length >= 6) c = L.one("SELECT * FROM ap_clients WHERE _deleted = 0 AND phone_key = ? AND (? = '' OR COALESCE(email, '') = '') ORDER BY _id LIMIT 1", key, email);
  const name = C.cleanName(req.name);
  if (c) {
    const data = {};
    if (email && !c.email) data.email = email;
    if (phone && !c.phone) Object.assign(data, { phone, phone_key: key });
    if (name && !c.name) data.name = name;
    if (channel && !c.first_channel) data.first_channel = channel;
    return { ref: c._id, name: c.name || name, email: c.email || email, ops: Object.keys(data).length ? [{ op: 'update', table: 'ap_clients', id: c._id, data }] : [] };
  }
  return { ref: '$c._id', name, email,
    ops: [{ op: 'insert', table: 'ap_clients', as: 'c', data: { name, email, phone, phone_key: key, notes: '', language: lang, source: req.source || 'online', first_channel: channel || null } }] };
}

/** The email the client asked for, queued (sent by send.js), when emails are on and there is an address. */
function emailOp(s, b, kind, { token, booking, thread, inbox, byUs } = {}) {
  if (s.emails_on !== 'yes' || !C.isEmail(b.email)) return [];
  const m = C.bookingEmail(kind, b, s, { link: kind === 'cancelled' ? '' : linkOf(s, token), byUs });
  return [{ op: 'insert', table: 'ap_emails', data: { booking_id: booking, client_id: b.client_id || null,
    inbox_id: inbox || null, purpose: kind, to_email: C.normEmail(b.email), subject: m.subject, body: m.body, status: 'Queued', thread_id: thread || null, drafted_by: 'script' } }];
}

/** Insert or replace the sealed page for a token. */
async function linkOps(s, token, booking, extra, { bookingId, requestId, last }) {
  if (!C.TOKEN.test(String(token || ''))) return [];
  const k = await C.linkKey(token);
  const snap = C.snapshot(booking, s, extra);
  // `last` (how the client's latest ask went) is sealed in but not part of the hash: tidying the links never erases it.
  const hash = C.fingerprint(snap);
  const box = await C.seal(token, last ? Object.assign({ last }, snap) : snap);
  const row = L.one('SELECT _id FROM ap_links WHERE _deleted = 0 AND k = ?', k);
  const data = { k, box, hash, booking_id: bookingId || null, request_id: requestId || null, built_at: L.sqlNow() };
  return [row ? { op: 'update', table: 'ap_links', id: row._id, data } : { op: 'insert', table: 'ap_links', data }];
}

/** How the client's own ask went, for the page that is waiting for it (it sent `visit`). */
const lastOf = (req, ok, more) => (req && req.visit ? Object.assign({ visit: String(req.visit), ok }, more || {}) : undefined);

/** Reminders a booking made too late for will never be sent: stamped now, so the send check rests. */
function reminderStamps(startAt, now) {
  const left = S.ms(startAt) - now.getTime();
  return { reminded_24_at: left < 20 * 3600000 ? 'not needed' : null, reminded_2_at: left < 3 * 3600000 ? 'not needed' : null };
}

function extraFor(s, b) { return { change_until: S.canChange(b, s, L.now().getTime()).until }; }

/** Free times near the one asked for, with names: what a failure offers. */
function around(d, serviceIds, staffId, at) {
  return S.nearest(d, serviceIds, staffId, S.ms(at), 6).map((x) => {
    const id = x.staff.length === 1 || Number(staffId) ? Number(staffId) || x.staff[0] : 0;
    const p = d.staff.find((q) => Number(q._id) === id);
    return { start_at: x.start_at, staff_id: id, staff_name: p ? p.name : '' };
  });
}

/**
 * A new booking from a request row. → {ok, booking_id} or {ok:false, code, clashes, alternatives}.
 * `override` counts only from the desk or the agent's tool, never the page.
 */
async function newBooking(req, { actor } = {}) {
  for (let attempt = 0; attempt < 2; attempt += 1) {
    const now = L.now();
    const d = L.data(now);
    const s = d.settings;
    const serviceIds = ids(req);
    const override = req.override === 'yes' && req.source !== 'online';
    const res = S.check(d, { service_ids: serviceIds, staff_id: Number(req.staff_id) || 0, start_at: req.start_at }, { override });
    if (!res.ok) return { ok: false, code: res.code, clashes: res.clashes || [], alternatives: around(d, serviceIds, req.staff_id, req.start_at) };
    const lang = C.langOf(req.language, s.default_language);
    const channel = C.channelOf(req.source || 'online', req.channel, s);
    const client = clientOps(req, lang, channel);
    const person = d.staff.find((p) => Number(p._id) === res.staff_id) || {};
    const token = C.TOKEN.test(String(req.token || '')) ? req.token : (client.email ? C.newToken() : '');
    const b = {
      client_id: client.ref, client_name: client.name, service_id: serviceIds[0], service_ids: JSON.stringify(serviceIds), service_name: res.combo.name,
      staff_id: res.staff_id, staff_name: person.name || '', any_staff: res.any ? 'yes' : 'no',
      start_at: res.start_at, end_at: res.end_at, busy_from: res.busy_from, busy_to: res.busy_to, price_minor: res.combo.price,
      status: 'Booked', source: req.source || 'online', channel, note: String(req.note || '').slice(0, 1000), language: lang,
      request_id: req._id || null, created_by: actor || req.created_by || req.source || 'online',
      override: res.warnings.length ? 'yes' : 'no', link_token: token || null, thread_id: req.thread_id || null,
      ...reminderStamps(res.start_at, now),
    };
    const live = res.warnings.length ? 'over' : 'yes';
    const ops = [...client.ops, { op: 'insert', table: 'ap_bookings', as: 'b', data: b },
      ...S.holdKeys(res.busy_from, res.busy_to).map((slot) => ({ op: 'insert', table: 'ap_holds', data: { booking_id: '$b._id', staff_id: res.staff_id, slot, live } }))];
    if (req._id) ops.push({ op: 'update', table: 'ap_requests', id: req._id, when: { status: 'New' }, data: { status: 'Booked', result_booking_id: '$b._id', reason: res.warnings.length ? `Booked over: ${res.warnings.join(', ')}` : null, clashes: null, processed_at: L.sqlNow() } });
    ops.push(...await linkOps(s, token, b, extraFor(s, b), { bookingId: '$b._id', requestId: req._id, last: lastOf(req, true) }));
    ops.push(...emailOp(s, Object.assign({}, b, { email: client.email }), 'confirm', { token, booking: '$b._id', thread: req.thread_id, inbox: req.inbox_id }));
    try {
      const out = L.write(ops);
      const id = (out.find((r) => r.table === 'ap_bookings') || {})._id;
      return { ok: true, booking_id: id, staff_id: res.staff_id, staff_name: person.name || '', start_at: res.start_at, end_at: res.end_at, service: res.combo.name, warnings: res.warnings, token };
    } catch (e) {
      // Someone took this person's time between our read and our write: judge again on fresh data.
      if (clashOf(e) && attempt === 0) continue;
      if (/precondition/.test(e.message)) return { ok: false, code: 'taken-meanwhile' };
      throw e;
    }
  }
  return { ok: false, code: 'clash', clashes: [] };
}

/** Cancel a booking. by: 'client' | 'business'. deadline: the client's own limit applies. */
async function cancel(b, { by = 'business', reason = '', deadline = false, req = null, actor = '' } = {}) {
  const s = L.settings();
  if (b.status !== 'Booked') return { ok: false, code: 'state' };
  if (deadline && !S.canChange(b, s, L.now().getTime()).ok) return { ok: false, code: 'deadline' };
  const holds = L.all("SELECT _id FROM ap_holds WHERE _deleted = 0 AND booking_id = ? AND live <> 'no'", b._id);
  const after = Object.assign({}, b, { status: 'Cancelled' });
  const email = (L.one('SELECT email FROM ap_clients WHERE _id = ?', b.client_id) || {}).email;
  const ops = [{ op: 'update', table: 'ap_bookings', id: b._id, when: { status: 'Booked' }, data: {
    status: 'Cancelled', cancelled_at: L.sqlNow(), cancelled_by: by, cancel_reason: String(reason || '').slice(0, 300), notice_status: 'Done', marked_by: actor || by } },
  ...holds.map((h) => ({ op: 'update', table: 'ap_holds', id: h._id, data: { live: 'no' } }))];
  if (req && req._id) ops.push({ op: 'update', table: 'ap_requests', id: req._id, when: { status: 'New' }, data: { status: 'Done', result_booking_id: b._id, processed_at: L.sqlNow() } });
  ops.push(...await linkOps(s, b.link_token, after, extraFor(s, after), { bookingId: b._id, last: lastOf(req, true) }));
  ops.push(...emailOp(s, Object.assign({}, after, { email }), 'cancelled', { booking: b._id, byUs: by !== 'client', thread: req && req.thread_id, inbox: req && req.inbox_id }));
  try { L.write(ops); } catch (e) { if (/precondition/.test(e.message)) return { ok: false, code: 'taken-meanwhile' }; throw e; }
  return { ok: true, booking_id: b._id };
}

/** Move a booking to another time (and maybe person), keeping its link. */
async function move(b, { start_at, staff_id, deadline = false, req = null, override = false } = {}) {
  for (let attempt = 0; attempt < 2; attempt += 1) {
    const d = L.data(L.now());
    const s = d.settings;
    if (b.status !== 'Booked') return { ok: false, code: 'state' };
    if (deadline && !S.canChange(b, s, d.now).ok) return { ok: false, code: 'deadline' };
    const serviceIds = ids(b);
    const who = staff_id === undefined || staff_id === null || staff_id === '' ? (b.any_staff === 'yes' ? 0 : b.staff_id) : Number(staff_id);
    const res = S.check(d, { service_ids: serviceIds, staff_id: who, start_at, ignore: b._id }, { override });
    if (!res.ok) return { ok: false, code: res.code, clashes: res.clashes || [], alternatives: around(d, serviceIds, who, start_at) };
    const person = d.staff.find((p) => Number(p._id) === res.staff_id) || {};
    const data = { start_at: res.start_at, end_at: res.end_at, busy_from: res.busy_from, busy_to: res.busy_to, staff_id: res.staff_id,
      staff_name: person.name || '', any_staff: res.any ? 'yes' : 'no', moved_at: L.sqlNow(), moved_by: req && req.source === 'online' ? 'client' : 'business', ...reminderStamps(res.start_at, L.now()),
      override: res.warnings.length ? 'yes' : (b.override || 'no') };
    const after = Object.assign({}, b, data);
    const email = (L.one('SELECT email FROM ap_clients WHERE _id = ?', b.client_id) || {}).email;
    const old = L.all("SELECT _id FROM ap_holds WHERE _deleted = 0 AND booking_id = ? AND live <> 'no'", b._id);
    const ops = [{ op: 'update', table: 'ap_bookings', id: b._id, when: { status: 'Booked', start_at: b.start_at, staff_id: b.staff_id }, data },
      ...old.map((h) => ({ op: 'update', table: 'ap_holds', id: h._id, data: { live: 'no' } })),
      ...S.holdKeys(res.busy_from, res.busy_to).map((slot) => ({ op: 'insert', table: 'ap_holds', data: { booking_id: b._id, staff_id: res.staff_id, slot, live: res.warnings.length ? 'over' : 'yes' } }))];
    if (req && req._id) ops.push({ op: 'update', table: 'ap_requests', id: req._id, when: { status: 'New' }, data: { status: 'Done', result_booking_id: b._id, processed_at: L.sqlNow() } });
    ops.push(...await linkOps(s, b.link_token, after, extraFor(s, after), { bookingId: b._id, last: lastOf(req, true) }));
    ops.push(...emailOp(s, Object.assign({}, after, { email }), 'changed', { token: b.link_token, booking: b._id, thread: req && req.thread_id, inbox: req && req.inbox_id }));
    try {
      L.write(ops);
      return { ok: true, booking_id: b._id, start_at: res.start_at, staff_id: res.staff_id, staff_name: person.name || '' };
    } catch (e) {
      if (clashOf(e) && attempt === 0) { b = L.one('SELECT * FROM ap_bookings WHERE _id = ?', b._id) || b; continue; }
      if (/precondition/.test(e.message)) return { ok: false, code: 'taken-meanwhile' };
      throw e;
    }
  }
  return { ok: false, code: 'clash', clashes: [] };
}

/**
 * What the desk changes directly (Arrived, No-show, Cancel) leaves for here:
 * holds released, the client told about a cancellation, links rewritten.
 */
async function aftercare() {
  const s = L.settings();
  const out = { released: 0, notices: 0, links: 0 };
  const stale = L.all(`SELECT h._id FROM ap_holds h JOIN ap_bookings b ON b._id = h.booking_id
    WHERE h._deleted = 0 AND h.live <> 'no' AND (b.status NOT IN ('Booked', 'Arrived') OR b._deleted = 1) LIMIT 2000`);
  if (stale.length) { L.write(stale.map((h) => ({ op: 'update', table: 'ap_holds', id: h._id, data: { live: 'no' } }))); out.released = stale.length; }
  for (const b of L.all("SELECT b.*, c.email AS email FROM ap_bookings b LEFT JOIN ap_clients c ON c._id = b.client_id WHERE b._deleted = 0 AND b.status = 'Cancelled' AND b.notice_status = 'Pending' LIMIT 50")) {
    const ops = [{ op: 'update', table: 'ap_bookings', id: b._id, when: { notice_status: 'Pending' }, data: { notice_status: 'Done' } },
      ...emailOp(s, b, 'cancelled', { booking: b._id, byUs: true })];
    try { L.write(ops); out.notices += ops.length - 1; } catch { /* changed meanwhile */ }
  }
  const since = new Date(L.now().getTime() - 2 * 86400000).toISOString();
  for (const b of L.all("SELECT * FROM ap_bookings WHERE _deleted = 0 AND COALESCE(link_token, '') <> '' AND end_at > ?", since)) {
    const k = await C.linkKey(b.link_token);
    const row = L.one('SELECT _id, hash FROM ap_links WHERE _deleted = 0 AND k = ?', k);
    if (row && row.hash === C.fingerprint(C.snapshot(b, s, extraFor(s, b)))) continue;
    L.write(await linkOps(s, b.link_token, b, extraFor(s, b), { bookingId: b._id }));
    out.links += 1;
  }
  return out;
}

module.exports = { lastOf, extraFor, ids, newBooking, cancel, move, aftercare, around, linkOps, linkOf, clientOps };
