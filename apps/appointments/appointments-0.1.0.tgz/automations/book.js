'use strict';
/**
 * Appointments · the agent's tool. Everything an agent does to the agenda goes
 * through here, and every booking through the same door as the public page
 * (engine.js): the same rules, the same holds, the same emails. It prints one
 * JSON line; a refusal exits 2 with the clashes and what to do about them.
 *
 *   node book.js today [--day YYYY-MM-DD]
 *   node book.js slots --service "corte" [--staff Ana|any] [--day YYYY-MM-DD]
 *   node book.js book --service "corte[,barba]" [--staff Ana|any] --at "YYYY-MM-DD HH:MM" --name "Lucía" [--phone …] [--email …] [--note …] [--from phone|walk-in|Fresha] [--override]
 *   node book.js move --id 12 --at "YYYY-MM-DD HH:MM" [--staff Ana|any] [--override]
 *   node book.js cancel --id 12 [--reason "…"]
 *   node book.js arrived --id 12      ·  node book.js noshow --id 12
 *   node book.js find --client "lucía"        (clients, their next and last appointments)
 *   node book.js noshows [--since YYYY-MM-DD]
 *   node book.js sources                       (this month vs last, and commission avoided, an estimate)
 *   node book.js due                           (clients due to rebook)
 * Times are the business's wall clock ("2026-10-08 18:30"), in its time zone.
 * --override books over a clash or outside the rules: only when the owner said so.
 */
const L = require('./lib');
const S = require('./sched');
const C = require('./aptcore');
const E = require('./engine');

const argv = process.argv.slice(2);
const opt = (k) => { const i = argv.indexOf(`--${k}`); return i >= 0 && argv[i + 1] && !argv[i + 1].startsWith('--') ? argv[i + 1] : null; };
const flag = (k) => argv.includes(`--${k}`);
const fold = (v) => String(v || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').trim();

function serviceIds(d, text) {
  return String(text || '').split(/[,+]/).map((p) => p.trim()).filter(Boolean).map((p) => {
    const list = d.services.filter((x) => x.active === 'yes');
    const hit = /^\d+$/.test(p) ? list.find((x) => Number(x._id) === Number(p)) : (list.find((x) => fold(x.name) === fold(p)) || list.find((x) => fold(x.name).includes(fold(p))));
    if (!hit) throw Object.assign(new Error(`No active service matches "${p}". Services: ${list.map((x) => x.name).join(', ')}`), { code: 'service' });
    return Number(hit._id);
  });
}
function staffId(d, text) {
  if (!text || /^(any|anyone|cualquiera)$/i.test(text)) return 0;
  const hit = /^\d+$/.test(text) ? d.staff.find((p) => Number(p._id) === Number(text)) : d.staff.find((p) => fold(p.name) === fold(text) || fold(p.name).startsWith(fold(text)));
  if (!hit) throw Object.assign(new Error(`Nobody in the team is called "${text}". Team: ${d.staff.map((p) => p.name).join(', ')}`), { code: 'staff' });
  return Number(hit._id);
}
function at(d, text) {
  const m = /^(\d{4}-\d{2}-\d{2})[ T](\d{1,2}:\d{2})$/.exec(String(text || '').trim());
  if (!m || !S.realDay(m[1]) || S.hm(m[2]) === null) throw Object.assign(new Error('--at takes the business\'s wall clock: "YYYY-MM-DD HH:MM"'), { code: 'time' });
  return S.iso(S.localToUtc(m[1], m[2], S.zone(d.settings.timezone)));
}
const local = (d, iso) => `${S.localDay(S.ms(iso), S.zone(d.settings.timezone))} ${S.localTime(S.ms(iso), S.zone(d.settings.timezone))}`;
const refused = (d, r) => ({ ok: false, code: r.code, clashes: (r.clashes || []).map((x) => ({ staff: x.staff, from: local(d, x.start_at), to: local(d, x.end_at), what: x.label })),
  said: r.code === 'clash' ? S.conflictText(r.clashes, 'en', d.settings.timezone) : `Refused: ${r.code}`, nearest: (r.alternatives || []).map((x) => ({ at: local(d, x.start_at), staff: x.staff_name || 'anyone' })),
  next: 'Offer one of `nearest`, or book anyway with --override only if the owner said so.' });

async function main() {
  const cmd = argv[0];
  const d = L.data(L.now());
  const tz = S.zone(d.settings.timezone);
  const row = (b) => ({ id: b._id, at: local(d, b.start_at), client: b.client_name, service: b.service_name, staff: b.staff_name, status: b.status, from: C.channelLabel(b.channel) });
  if (cmd === 'today') {
    const day = opt('day') || S.localDay(d.now, tz);
    const from = S.iso(S.localToUtc(day, '00:00', tz));
    const to = S.iso(S.localToUtc(S.addDays(day, 1), '00:00', tz));
    return { ok: true, day, appointments: L.all("SELECT * FROM ap_bookings WHERE _deleted = 0 AND status <> 'Cancelled' AND start_at >= ? AND start_at < ? ORDER BY staff_name, start_at", from, to).map(row) };
  }
  if (cmd === 'slots') {
    const ids = serviceIds(d, opt('service'));
    const day = opt('day') || S.localDay(d.now, tz);
    return { ok: true, day, free: S.slots(d, ids, staffId(d, opt('staff')), day).map((x) => ({ at: local(d, x.start_at), staff: x.staff.map((id) => (d.staff.find((p) => Number(p._id) === id) || {}).name) })) };
  }
  const held = L.lock('book', 30000);
  if (!held) return { ok: false, code: 'busy', said: 'Another booking is being written: try again in a minute.' };
  try {
    if (cmd === 'book') {
      const ids = serviceIds(d, opt('service'));
      const from = opt('from');
      const req = { source: 'agent', kind: 'new', service_id: ids[0], service_ids: JSON.stringify(ids), staff_id: staffId(d, opt('staff')), start_at: at(d, opt('at')),
        name: C.cleanName(opt('name')), email: C.isEmail(opt('email')) ? C.normEmail(opt('email')) : '', phone: C.normPhone(opt('phone')), note: opt('note') || '',
        language: C.langOf(opt('lang'), d.settings.default_language), override: flag('override') ? 'yes' : 'no', status: 'New', created_by: process.env.ORCHESTRA_AGENT_ID || 'agent',
        channel: from ? (/^(phone|walk-in)$/.test(from) ? from : `marketplace:${from}`) : 'phone' };
      if (!req.name) return { ok: false, code: 'details', said: '--name is needed' };
      const [ins] = L.write([{ op: 'insert', table: 'ap_requests', data: req }]);
      const r = await E.newBooking(Object.assign({ _id: ins._id }, req), { actor: req.created_by });
      if (!r.ok) { L.write([{ op: 'update', table: 'ap_requests', id: ins._id, when: { status: 'New' }, data: { status: 'Conflict', reason: r.code, clashes: JSON.stringify(r.clashes || []).slice(0, 4000), processed_at: L.sqlNow() } }]); return refused(d, r); }
      return { ok: true, booked: row(L.one('SELECT * FROM ap_bookings WHERE _id = ?', r.booking_id)), warnings: r.warnings };
    }
    const b = Number(opt('id')) ? L.one('SELECT * FROM ap_bookings WHERE _deleted = 0 AND _id = ?', Number(opt('id'))) : null;
    if (['move', 'cancel', 'arrived', 'noshow'].includes(cmd) && !b) return { ok: false, code: 'notfound', said: 'No appointment with that --id (see `today` or `find`).' };
    if (cmd === 'move') {
      const r = await E.move(b, { start_at: at(d, opt('at')), staff_id: opt('staff') ? staffId(d, opt('staff')) : null, override: flag('override') });
      return r.ok ? { ok: true, moved: row(L.one('SELECT * FROM ap_bookings WHERE _id = ?', b._id)) } : refused(d, r);
    }
    if (cmd === 'cancel') {
      const r = await E.cancel(b, { by: 'business', reason: opt('reason') || '', actor: process.env.ORCHESTRA_AGENT_ID || 'agent' });
      return r.ok ? { ok: true, cancelled: row(L.one('SELECT * FROM ap_bookings WHERE _id = ?', b._id)) } : refused(d, r);
    }
    if (cmd === 'arrived' || cmd === 'noshow') {
      const data = cmd === 'arrived' ? { status: 'Arrived', arrived_at: L.sqlNow() } : { status: 'NoShow', no_show_at: L.sqlNow() };
      try { L.write([{ op: 'update', table: 'ap_bookings', id: b._id, when: { status: 'Booked' }, data: Object.assign(data, { marked_by: process.env.ORCHESTRA_AGENT_ID || 'agent' }) }]); } catch { return { ok: false, code: 'state', said: `It is ${b.status}, not Booked.` }; }
      await E.aftercare();
      return { ok: true, marked: row(L.one('SELECT * FROM ap_bookings WHERE _id = ?', b._id)) };
    }
  } finally { held.release(); }
  if (cmd === 'find') {
    const q = `%${fold(opt('client'))}%`;
    return { ok: true, clients: L.all('SELECT * FROM ap_clients WHERE _deleted = 0 AND (lower(name) LIKE ? OR email LIKE ? OR phone LIKE ?) LIMIT 10', q, q, q).map((c) => ({
      id: c._id, name: c.name, phone: c.phone, email: c.email, notes: c.notes, first_came_from: C.channelLabel(c.first_channel),
      appointments: L.all('SELECT * FROM ap_bookings WHERE _deleted = 0 AND client_id = ? ORDER BY start_at DESC LIMIT 8', c._id).map(row) })) };
  }
  if (cmd === 'noshows') {
    const since = opt('since') || S.addDays(S.localDay(d.now, tz), -30);
    return { ok: true, since, noshows: L.all("SELECT * FROM ap_bookings WHERE _deleted = 0 AND status = 'NoShow' AND start_at >= ? ORDER BY start_at DESC LIMIT 100", `${since}T00:00:00Z`).map(row) };
  }
  if (cmd === 'sources') {
    const month = L.all(`SELECT COALESCE(NULLIF(channel, ''), source) AS channel, SUM(CASE WHEN _created_at >= datetime(?, 'start of month') THEN 1 ELSE 0 END) AS this_month,
      SUM(CASE WHEN _created_at < datetime(?, 'start of month') THEN 1 ELSE 0 END) AS last_month FROM ap_bookings WHERE _deleted = 0 AND status IN ('Booked', 'Arrived', 'NoShow')
      AND _created_at >= datetime(?, 'start of month', '-1 month') GROUP BY 1`, L.sqlNow(), L.sqlNow(), L.sqlNow());
    const fresh = L.all(`SELECT c.first_channel, (SELECT b.price_minor FROM ap_bookings b WHERE b._deleted = 0 AND b.client_id = c._id ORDER BY b._id LIMIT 1) AS first_price
      FROM ap_clients c WHERE c._deleted = 0 AND c._created_at >= datetime(?, 'start of month')`, L.sqlNow());
    const a = C.avoided(fresh, d.settings.marketplace_fee_pct);
    return { ok: true, by_source: month.map((r) => Object.assign(r, { channel: C.channelLabel(r.channel) })), new_clients_this_month: fresh.length,
      commission_avoided: { amount: C.money(a.minor, d.settings.currency, 'en'), clients: a.clients, fee_pct: Number(d.settings.marketplace_fee_pct) || 0, note: 'An estimate: new clients who came direct × their first appointment × the marketplace fee in Settings.' } };
  }
  if (cmd === 'due') {
    return { ok: true, due: L.all(`SELECT c._id AS client_id, c.name, c.phone, c.email, s.name AS service, MAX(b.start_at) AS last_at FROM ap_bookings b JOIN ap_clients c ON c._id = b.client_id
      JOIN ap_services s ON s._id = b.service_id WHERE b._deleted = 0 AND s.rebook_weeks > 0 AND b.status IN ('Arrived', 'Booked') AND b.start_at <= ?
      AND NOT EXISTS (SELECT 1 FROM ap_bookings f WHERE f._deleted = 0 AND f.client_id = c._id AND f.status = 'Booked' AND f.start_at > ?)
      GROUP BY c._id, s._id HAVING date(MAX(b.start_at), '+' || (s.rebook_weeks * 7) || ' days') <= date(?)`, L.isoZ(L.now()), L.isoZ(L.now()), L.isoZ(L.now()).slice(0, 10)) };
  }
  return { ok: false, said: 'Commands: today, slots, book, move, cancel, arrived, noshow, find, noshows, sources, due (see the top of book.js)' };
}

if (require.main === module) {
  main().then((o) => { L.done(o); if (o && o.ok === false) process.exitCode = 2; }, (e) => { L.done({ ok: false, code: e.code || 'error', said: e.message }); process.exitCode = 2; });
}
module.exports = { main };
