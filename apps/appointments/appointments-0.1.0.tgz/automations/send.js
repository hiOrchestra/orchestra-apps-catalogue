'use strict';
/**
 * Appointments · Send emails, from the business's Gmail (Composio), plain text.
 *
 * Two kinds go out:
 *   Queued    what the client asked for by booking: the confirmation, a
 *             change, a cancellation, and the reminders 24 h (and, if Settings
 *             say so, 2 h) before. They go on their own, only while "Send
 *             emails" is on in Settings.
 *   Approved  what the agent wrote outside those rules (an answer, free times
 *             offered, an invitation to come back): it waited in Review for a
 *             person's Approve.
 *
 * Each email is CLAIMED before Gmail is called (→ Sending, atomic), so none
 * leaves twice. One left Sending (a run that died, Gmail did not answer) is
 * Failed and says it may have gone out: never retried blind. A reminder or a
 * confirmation whose appointment has already started is Dropped, not sent late.
 *   node send.js [--auto|--now|--after-intake] [--dry-run]
 */
const L = require('./lib');
const S = require('./sched');
const C = require('./aptcore');
const G = require('./composio');
const E = require('./engine');

const STALE_MIN = 15;

/** The reminders that are due now, queued (and the booking stamped, atomically). */
function queueReminders(s, now, dry) {
  if (s.emails_on !== 'yes') return 0;
  const kinds = [{ col: 'reminded_24_at', hours: 24, early: 20, on: s.reminder_24h !== 'no' }, { col: 'reminded_2_at', hours: 2, early: 3, on: s.reminder_2h === 'yes' }];
  let n = 0;
  for (const k of kinds.filter((x) => x.on)) {
    const rows = L.all(`SELECT b.*, c.email AS email FROM ap_bookings b JOIN ap_clients c ON c._id = b.client_id
      WHERE b._deleted = 0 AND b.status = 'Booked' AND b.${k.col} IS NULL AND COALESCE(c.email, '') <> ''
        AND b.start_at > ? AND b.start_at <= ? AND datetime(COALESCE(b.moved_at, b._created_at)) <= datetime(b.start_at, '-${k.early} hours')
      ORDER BY b.start_at LIMIT 40`, L.isoZ(now), L.isoZ(new Date(now.getTime() + k.hours * 3600000)));
    for (const b of rows) {
      if (dry) { n += 1; continue; }
      const m = C.bookingEmail('reminder', b, s, { link: E.linkOf(s, b.link_token), soon: k.hours === 2 });
      try {
        L.write([{ op: 'update', table: 'ap_bookings', id: b._id, when: { [k.col]: null, status: 'Booked' }, data: { [k.col]: L.sqlNow() } },
          { op: 'insert', table: 'ap_emails', data: { booking_id: b._id, client_id: b.client_id, purpose: k.hours === 2 ? 'reminder2' : 'reminder24',
            to_email: C.normEmail(b.email), subject: m.subject, body: m.body, status: 'Queued', thread_id: b.thread_id || null, drafted_by: 'script' } }]);
        n += 1;
      } catch { /* moved or cancelled meanwhile */ }
    }
  }
  return n;
}

function readable(e) {
  const t = String(e.message || e);
  if (e.notConnected) return `Gmail is not connected: nothing went out. Connect it in Orchestra → Integrations, then Send again. (${t.slice(0, 160)})`;
  if (e.timeout) return `Gmail did not answer in time, so it may or may not have gone out. Look in Gmail's Sent folder before sending again. (${t.slice(0, 160)})`;
  return `Gmail did not take it: nothing went out. (${t.slice(0, 200)})`;
}

function run(mode = '--auto', { dry = false } = {}) {
  const held = dry ? { release() {} } : L.lock('send');
  if (!held) return { ok: true, mode, skipped: 'Another run is sending' };
  try {
    const s = L.settings();
    const now = L.now();
    const out = { ok: true, mode, reminders: queueReminders(s, now, dry), sent: 0, failed: 0, dropped: 0 };
    if (dry) return Object.assign(out, { dry: true, waiting: L.all("SELECT _id, purpose, to_email FROM ap_emails WHERE _deleted = 0 AND status IN ('Queued', 'Approved')") });
    const stale = L.all(`SELECT _id FROM ap_emails WHERE _deleted = 0 AND status = 'Sending' AND datetime(lock_at) <= datetime(?, '-${STALE_MIN} minutes')`, L.sqlNow());
    for (const m of stale) {
      try { L.write([{ op: 'update', table: 'ap_emails', id: m._id, when: { status: 'Sending' }, data: { status: 'Failed', error: 'The send did not finish, so it may or may not have gone out. Look in Gmail\'s Sent folder before sending again.' } }]); } catch { /* moved on */ }
    }
    const late = L.all(`SELECT e._id FROM ap_emails e JOIN ap_bookings b ON b._id = e.booking_id WHERE e._deleted = 0 AND e.status = 'Queued'
      AND (b.start_at <= ? OR (e.purpose IN ('reminder24', 'reminder2', 'confirm', 'changed') AND b.status <> 'Booked'))`, L.isoZ(now));
    for (const m of late) {
      try { L.write([{ op: 'update', table: 'ap_emails', id: m._id, when: { status: 'Queued' }, data: { status: 'Dropped', error: 'Not sent: the appointment had started or changed before it could go' } }]); out.dropped += 1; } catch { /* moved on */ }
    }
    const queue = L.all(`SELECT * FROM ap_emails WHERE _deleted = 0 AND (status = 'Approved' OR (status = 'Queued' AND ? = 'yes')) ORDER BY _id LIMIT 30`, s.emails_on || 'no');
    for (const m of queue) {
      const from = m.status;
      if (!C.isEmail(m.to_email) || !String(m.subject || '').trim() || !String(m.body || '').trim()) {
        try { L.write([{ op: 'update', table: 'ap_emails', id: m._id, when: { status: from }, data: { status: 'Failed', error: 'It has no valid address, subject or text: nothing went out.' } }]); } catch { /* moved */ }
        out.failed += 1;
        continue;
      }
      try { L.write([{ op: 'update', table: 'ap_emails', id: m._id, when: { status: from }, data: { status: 'Sending', lock_at: L.sqlNow(), error: null } }]); } catch { continue; }
      let res;
      try {
        res = m.thread_id ? G.reply({ thread: m.thread_id, to: m.to_email, body: m.body }) : G.send({ to: m.to_email, subject: m.subject, body: m.body });
      } catch (e) {
        L.write([{ op: 'update', table: 'ap_emails', id: m._id, data: { status: 'Failed', error: readable(e).slice(0, 500) } }]);
        if (e.notConnected) L.write([{ op: 'update', table: 'ap_settings', id: s._id, data: { gmail_status: 'not_connected', gmail_checked_at: L.sqlNow(), gmail_note: String(e.message).slice(0, 200) } }]);
        out.failed += 1;
        continue;
      }
      const ops = [{ op: 'update', table: 'ap_emails', id: m._id, data: { status: 'Sent', sent_at: L.sqlNow(), gmail_message_id: res.id, thread_id: res.threadId || m.thread_id || null, error: null } }];
      // The thread of the confirmation: a client's answer to it is read as theirs (mail.js).
      if (m.booking_id && res.threadId && !m.thread_id) ops.push({ op: 'update', table: 'ap_bookings', id: m.booking_id, data: { thread_id: res.threadId } });
      try { L.write(ops); } catch { L.write([ops[0]]); }
      out.sent += 1;
    }
    return out;
  } finally { held.release(); }
}

if (require.main === module) {
  const argv = process.argv.slice(2);
  try { L.done(run(argv.find((a) => ['--now', '--auto', '--after-intake'].includes(a)) || '--auto', { dry: argv.includes('--dry-run') })); } catch (e) { L.done({ ok: false, error: e.message }); process.exitCode = 1; }
}

module.exports = { run, queueReminders, readable, S };
