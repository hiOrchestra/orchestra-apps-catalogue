'use strict';
/**
 * What every Appointments script shares (Booking's and Helpdesk's lib.js,
 * the SDK the platform does not have yet): reading the project's database,
 * writing to it, talking to the instance as the workflow's agent, and the
 * one place the slot rules get their data from (`data()`).
 *
 * Reads go to the project's SQLite file directly, read-only and
 * parameterised. Every write goes through `orch-database batch`: one
 * transaction, `as` / `$name._id` to point at a row inserted just before, and
 * a `when` precondition checked inside the UPDATE.
 *
 * Locally (APPT_LOCAL=1) the same batch runs against APPT_DB with the same
 * semantics (unique indexes included), notices and workflow starts are
 * recorded, not sent. APPT_FAKE_COMPOSIO=1 answers Gmail from a JSON file
 * (composio.js). APPT_NOW pins the clock.
 */
const { DatabaseSync } = require('node:sqlite');
const { execFileSync } = require('child_process');
const fs = require('fs');
const os = require('os');
const path = require('path');

const PROJECT = process.env.APPT_PROJECT || (__dirname.match(/projects\/([^/]+)\/apps\/appointments/) || [])[1] || 'default';
const STATE = process.env.OPENCLAW_STATE_DIR || '/home/node/.openclaw';
const DB_PATH = process.env.APPT_DB || path.join(STATE, 'orchestra', 'projects', PROJECT, 'data', 'data.db');
const LOCAL = process.env.APPT_LOCAL === '1';
const record = (kind, data) => { if (process.env.APPT_RECORD) fs.appendFileSync(process.env.APPT_RECORD, `${JSON.stringify(Object.assign({ kind }, data))}\n`); };

// ── reading ──────────────────────────────────────────────────────────────
let reader = null;
function db() {
  if (!reader) {
    reader = new DatabaseSync(DB_PATH, { readOnly: true });
    reader.exec('PRAGMA busy_timeout = 5000');
  }
  return reader;
}
/** A fresh reader: after a write, the old one may hold an older snapshot. */
function reread() { if (reader) { try { reader.close(); } catch { /* closed */ } } reader = null; }
const all = (sql, ...params) => db().prepare(sql).all(...params);
const one = (sql, ...params) => db().prepare(sql).get(...params);

function settings() {
  const s = one('SELECT * FROM ap_settings WHERE _deleted = 0 ORDER BY _id LIMIT 1');
  if (!s) throw new Error('Appointments has no settings row: it is not installed in this project');
  return s;
}

/**
 * Everything the slot rules (sched.js) need, read fresh: services, staff,
 * time off, and the busy spans of the next weeks (bookings with their
 * buffers, blocked time). Bookings carry their client's name as the label
 * (only scripts and the desk see it, never the public page).
 */
function data(now) {
  const s = settings();
  const from = new Date(now.getTime() - 2 * 86400000).toISOString();
  const busy = [
    ...all(`SELECT staff_id, busy_from AS start_at, busy_to AS end_at, 'booking' AS kind, _id AS booking_id, client_name AS label
      FROM ap_bookings WHERE _deleted = 0 AND status IN ('Booked', 'Arrived') AND busy_to > ?`, from),
    ...all(`SELECT staff_id, start_at, end_at, 'block' AS kind, NULL AS booking_id, COALESCE(note, '') AS label
      FROM ap_blocks WHERE _deleted = 0 AND COALESCE(active, 'yes') = 'yes' AND end_at > ?`, from),
  ];
  return {
    settings: s,
    services: all('SELECT * FROM ap_services WHERE _deleted = 0'),
    staff: all('SELECT * FROM ap_staff WHERE _deleted = 0'),
    offs: all("SELECT staff_id, day_from, day_to FROM ap_time_off WHERE _deleted = 0 AND COALESCE(active, 'yes') = 'yes' AND day_to >= ?", from.slice(0, 10)),
    busy,
    now: now.getTime(),
  };
}

// ── writing ──────────────────────────────────────────────────────────────
/** One transaction (all or nothing); the ids of the rows inserted, in order. */
function write(ops) {
  const out = LOCAL ? localBatch(ops) : cliBatch(ops);
  reread();
  return out.results || [];
}

function cliBatch(ops) {
  let out;
  try {
    out = execFileSync('orch-database', ['--project', PROJECT, 'batch', '--ops', JSON.stringify(ops)],
      { encoding: 'utf8', timeout: 60000, maxBuffer: 16 << 20 });
  } catch (e) {
    let j = null;
    try { j = JSON.parse(String(e.stdout || '')); } catch { /* not JSON */ }
    throw new Error((j && j.error) || String(e.stderr || e.message).trim().slice(0, 300));
  }
  const j = JSON.parse(out);
  if (!j.ok) throw new Error(j.error || 'the write failed');
  return j;
}

/** orch-database's run_batch, for local tests: the same `as`/`$name._id`, `when`, all-or-none. */
function localBatch(ops) {
  const w = new DatabaseSync(DB_PATH);
  w.exec('PRAGMA busy_timeout = 5000');
  const now = sqlNow();
  const named = {};
  const deref = (v) => {
    if (typeof v !== 'string' || !/^\$[A-Za-z_]\w*\._id$/.test(v)) return v;
    const key = v.slice(1).split('.')[0];
    if (!named[key]) throw new Error(`reference ${v} names a step that has not run`);
    return named[key];
  };
  const results = [];
  w.exec('BEGIN IMMEDIATE');
  try {
    ops.forEach((op, i) => {
      const data = {};
      for (const [k, v] of Object.entries(op.data || {})) if (!k.startsWith('_')) data[k] = deref(v);
      if (op.op === 'insert') {
        const cols = [...Object.keys(data), '_created_at', '_updated_at'];
        const r = w.prepare(`INSERT INTO "${op.table}" (${cols.map((c) => `"${c}"`).join(', ')}) VALUES (${cols.map(() => '?').join(', ')})`)
          .run(...Object.values(data), now, now);
        const id = Number(r.lastInsertRowid);
        if (op.as) named[op.as] = id;
        results.push({ op: 'insert', table: op.table, _id: id });
      } else {
        const when = op.when || {};
        const id = deref(op.id);
        const r = w.prepare(`UPDATE "${op.table}" SET ${Object.keys(data).map((c) => `"${c}" = ?`).join(', ')}, _updated_at = ? `
          + `WHERE _id = ? AND _deleted = 0${Object.keys(when).map((c) => ` AND "${c}" IS ?`).join('')}`)
          .run(...Object.values(data), now, id, ...Object.values(when));
        if (!r.changes) throw new Error(`op ${i}: row ${id} changed meanwhile (precondition failed)`);
        results.push({ op: 'update', table: op.table, _id: id });
      }
    });
    w.exec('COMMIT');
  } catch (e) {
    try { w.exec('ROLLBACK'); } catch { /* nothing open */ }
    w.close();
    throw e;
  }
  w.close();
  return { ok: true, applied: results.length, results };
}

// ── one run at a time ────────────────────────────────────────────────────
const STALE_MS = 150000; // longer than a step may run (120 s): a file this old was left by a killed run
/**
 * A lock file per job, so a burst has one run doing the work. It saves work;
 * what keeps a time from being given twice is the unique ap_holds index.
 */
function lock(name, waitMs = 0) {
  let who = process.env.ORCHESTRA_AGENT_ID;
  if (!who) { try { who = os.userInfo().username; } catch { who = 'node'; } }
  const file = path.join(process.env.APPT_LOCK_DIR || os.tmpdir(), `orchestra-appointments-${PROJECT}-${who}-${name}.lock`);
  const held = { file, release() { try { fs.unlinkSync(file); } catch { /* gone */ } } };
  const until = Date.now() + waitMs;
  for (;;) {
    try {
      fs.writeFileSync(file, String(process.pid), { flag: 'wx' });
      return held;
    } catch (e) {
      if (e.code !== 'EEXIST') return { file: null, release() {} };
      let age = 0;
      try { age = Date.now() - fs.statSync(file).mtimeMs; } catch { continue; }
      if (age >= STALE_MS) { try { fs.unlinkSync(file); } catch { /* taken over */ } continue; }
      if (Date.now() >= until) return null;
      Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, 150);
    }
  }
}

// ── time ─────────────────────────────────────────────────────────────────
const now = () => (process.env.APPT_NOW ? new Date(process.env.APPT_NOW) : new Date());
/** 'YYYY-MM-DD HH:MM:SS' in UTC: how orch-database stamps rows. */
const sqlNow = (d = now()) => d.toISOString().slice(0, 19).replace('T', ' ');
const isoZ = (d) => `${d.toISOString().slice(0, 19)}Z`;
function toDate(v) {
  if (!v) return null;
  const s = String(v).trim();
  const x = s.includes('T') ? s : s.replace(' ', 'T');
  const d = new Date(/[zZ]|[+-]\d\d:?\d\d$/.test(x) ? x : `${x}Z`);
  return Number.isNaN(d.getTime()) ? null : d;
}

// ── the instance, as this workflow's agent ───────────────────────────────
function identityHeaders() {
  const id = process.env.ORCHESTRA_AGENT_ID;
  const token = process.env.ORCHESTRA_AGENT_TOKEN;
  if (id && token) return { 'x-orchestra-agent': id, 'x-orchestra-agent-token': token };
  const secret = process.env.HOOKS_TOKEN || process.env.OPENCLAW_GATEWAY_TOKEN || '';
  return secret ? { 'x-orchestra-secret': secret } : {};
}
/**
 * A call to the instance's api-server. Headers go to curl on stdin (-K -),
 * never argv. Never throws; a timeout says so (`timedOut`): the other side may
 * have acted.
 */
function api(method, route, body, seconds = 30) {
  const q = (v) => `"${String(v).replace(/[\\"]/g, '\\$&')}"`;
  const config = [
    `url = ${q(`http://127.0.0.1:${Number(process.env.API_SERVER_PORT || 3001)}${route}`)}`,
    `request = ${q(method)}`,
    'header = "Content-Type: application/json"',
    ...Object.entries(identityHeaders()).map(([k, v]) => `header = ${q(`${k}: ${v}`)}`),
    ...(body === undefined ? [] : [`data = ${q(JSON.stringify(body))}`]),
  ].join('\n');
  try {
    const out = execFileSync('curl', ['-sS', '-m', String(seconds), '-K', '-'], { input: config, timeout: (seconds + 5) * 1000, stdio: ['pipe', 'pipe', 'pipe'] }).toString();
    let j = null;
    try { j = JSON.parse(out); } catch { /* reported below */ }
    if (j && j.success) return { ok: true, data: j.data };
    return { ok: false, why: String((j && j.error && (j.error.message || j.error)) || out).trim().slice(0, 300) };
  } catch (e) {
    const why = String((e.stderr && e.stderr.toString()) || e.message).trim().slice(0, 300);
    return { ok: false, why, timedOut: /timed out|ETIMEDOUT|\(28\)/i.test(why) };
  }
}
/** One Composio action for this tenant's connected account: { ok, data } or { ok: false, why, timedOut }. */
function composio(slug, args, seconds = 60) {
  if (process.env.APPT_FAKE_COMPOSIO === '1') return require('./composio').fake(slug, args);
  const r = api('POST', '/api/composio/execute', { toolSlug: slug, arguments: args }, seconds);
  if (!r.ok) return r;
  const d = r.data || {};
  if (d.successful === false || d.error) return { ok: false, why: String(d.error || 'Composio said it did not work').slice(0, 300) };
  return { ok: true, data: d.data !== undefined ? d.data : d };
}

/** The workflow ids the installer recorded next to the scripts. */
function workflowIds() { try { return JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'workflows.json'), 'utf8')); } catch { return {}; } }
/** Start one of the app's workflows now (it carries only `mode`). */
function kick(key, mode = '--auto') {
  if (LOCAL || process.env.APPT_FAKE_KICK === '1') { record('kick', { workflow: key, mode }); return { started: true, fake: true }; }
  const id = workflowIds()[key];
  if (!id) return { started: false, why: `No ${key} workflow recorded (install Appointments again)` };
  const r = api('POST', `/api/platform/workflows/${encodeURIComponent(id)}/run`, { execute: true, argsJson: JSON.stringify({ mode }) });
  return r.ok ? { started: true } : { started: false, why: r.why };
}

// ── telling the owner ────────────────────────────────────────────────────
const TG_CHAT = /^(-?\d{5,20}|@[A-Za-z0-9_]{5,32})$/;
function telegram(to, text) {
  const chat = String(to || '').trim();
  if (!chat) return { sent: false, why: 'No Telegram chat in Settings' };
  if (!TG_CHAT.test(chat)) return { sent: false, why: 'The Telegram chat in Settings is not a chat id or @username' };
  const message = String(text || '').slice(0, 3800);
  if (LOCAL) { record('telegram', { to: chat, message }); return { sent: true, fake: true }; }
  const r = api('POST', '/api/channels/telegram/notify', { to: chat, message });
  return r.ok ? { sent: true } : { sent: false, why: r.why };
}

/** The agent's JSON, wherever it is: bare, fenced, or inside a step wrapper's `content`. */
function jsonIn(text) {
  const grab = (t) => {
    const s = String(t || '').replace(/```(?:json)?/gi, '');
    const a = s.indexOf('{');
    const b = s.lastIndexOf('}');
    if (a < 0 || b <= a) return null;
    try { return JSON.parse(s.slice(a, b + 1)); } catch { return null; }
  };
  const j = grab(text);
  if (j && typeof j.content === 'string') { const inner = grab(j.content); if (inner) return inner; }
  return j;
}

/** The one JSON line a workflow step leaves as its output. */
function done(result) {
  process.stdout.write(`${JSON.stringify(result)}\n`);
  return result;
}

module.exports = {
  PROJECT, DB_PATH, LOCAL, record, all, one, reread, settings, data, write, lock,
  now, sqlNow, isoZ, toDate, identityHeaders, api, composio, workflowIds, kick, telegram, jsonIn, done,
};
