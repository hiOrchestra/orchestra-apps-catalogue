'use strict';
/**
 * Appointments · Read booking emails: the two script steps around the agent's
 * turn (optional; "Book from emails" in Settings).
 *
 *   node inbox.js pick   claims up to 4 emails kept by mail.js (New → Working)
 *                        and prints what the agent needs, under 20k characters:
 *                        the services, the team, today, and each email with the
 *                        sender's upcoming appointments
 *   node inbox.js save   checks the agent's answer ($PRIOR, JSON only) and acts
 *                        through the one door (engine.js):
 *     new     the first free time inside the client's wishes, in order → booked,
 *             and the confirmation answers in their thread (Queued: they asked)
 *     change  the same, moving their own appointment, before the deadline
 *     cancel  their own appointment, before the deadline
 *     else    nothing is booked: the agent's answer (or free times offered)
 *             waits in Messages for the owner's Approve (Review)
 * The agent never writes. A claimed email the answer does not cover is Failed
 * with the reason and "Try again" in Messages. Each email is handled once.
 */
const L = require('./lib');
const S = require('./sched');
const C = require('./aptcore');
const E = require('./engine');

const MAX = 4;
const STUCK_MS = 30 * 60000;
const fold = (v) => String(v || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').trim();

function pick() {
  const now = L.now();
  for (const r of L.all("SELECT _id FROM ap_inbox WHERE _deleted = 0 AND status = 'Working' AND claimed_at < ?", L.sqlNow(new Date(now.getTime() - STUCK_MS)))) {
    try { L.write([{ op: 'update', table: 'ap_inbox', id: r._id, when: { status: 'Working' }, data: { status: 'Failed', why: 'The agent did not answer in time' } }]); } catch { /* moved */ }
  }
  const s = L.settings();
  if (s.inbox_on !== 'yes') return { skip: true, why: 'Book from emails is off' };
  const rows = L.all(`SELECT * FROM ap_inbox WHERE _deleted = 0 AND status = 'New' ORDER BY _id LIMIT ${MAX}`);
  const mine = [];
  for (const r of rows) { try { L.write([{ op: 'update', table: 'ap_inbox', id: r._id, when: { status: 'New' }, data: { status: 'Working', claimed_at: L.sqlNow() } }]); mine.push(r); } catch { /* another run */ } }
  if (!mine.length) return { skip: true, why: 'No booking email is waiting' };
  const d = L.data(now);
  const tz = S.zone(s.timezone);
  const local = (iso) => `${S.localDay(S.ms(iso), tz)} ${S.localTime(S.ms(iso), tz)}`;
  const out = {
    ids: mine.map((r) => r._id), today: S.localDay(now.getTime(), tz), weekday: S.weekday(S.localDay(now.getTime(), tz)), timezone: tz, business: s.business_name || '',
    services: d.services.filter((x) => x.active === 'yes').map((x) => ({ name: x.name, minutes: x.duration_min, price: C.money(x.price_minor, s.currency, 'en') })),
    team: d.staff.filter((p) => p.active === 'yes').map((p) => ({ name: p.name, does: S.servicesOf(p).map((id) => (d.services.find((x) => Number(x._id) === id) || {}).name).filter(Boolean) })),
    emails: mine.map((r) => {
      const c = L.one('SELECT * FROM ap_clients WHERE _deleted = 0 AND email = ?', r.from_email);
      return { id: r._id, from: r.from_email, name: r.from_name, subject: r.subject, text: String(r.body || '').slice(0, 1500),
        client: c ? { name: c.name, upcoming: L.all("SELECT * FROM ap_bookings WHERE _deleted = 0 AND client_id = ? AND status = 'Booked' AND start_at > ? ORDER BY start_at LIMIT 3", c._id, L.isoZ(now))
          .map((b) => ({ booking_id: b._id, when: local(b.start_at), service: b.service_name, staff: b.staff_name })) } : null };
    }),
  };
  while (JSON.stringify(out).length > 19000) for (const e of out.emails) e.text = e.text.slice(0, Math.floor(e.text.length * 0.8));
  return out;
}

function draft(s, r, purpose, subject, body, extra = {}) {
  return [{ op: 'insert', table: 'ap_emails', data: Object.assign({ inbox_id: r._id, purpose, to_email: r.from_email, subject, body, status: 'Review', thread_id: r.thread_id || null, drafted_by: 'agent' }, extra) },
    { op: 'update', table: 'ap_inbox', id: r._id, data: { status: 'Draft', done_at: L.sqlNow() } }];
}

async function handle(s, r, it) {
  const d = L.data(L.now());
  const lang = C.langOf(it.language, s.default_language);
  const finish = (status, why, data = {}) => L.write([{ op: 'update', table: 'ap_inbox', id: r._id, data: Object.assign({ status, why: String(why).slice(0, 300), intent: it.intent, done_at: L.sqlNow() }, data) }]);
  const svc = (Array.isArray(it.services) ? it.services : []).map((n) => {
    const hit = d.services.find((x) => x.active === 'yes' && (fold(x.name) === fold(n) || fold(x.name).includes(fold(n)) || String(x._id) === String(n)));
    return hit ? Number(hit._id) : null;
  });
  const staffName = fold(it.staff);
  const staff = !staffName || /^(any|anyone|cualquiera)$/.test(staffName) ? 0 : Number((d.staff.find((p) => fold(p.name).startsWith(staffName)) || {})._id || -1);
  const wishes = (Array.isArray(it.wishes) ? it.wishes : []).filter((w) => w && S.realDay(w.date)).slice(0, 6);
  const reply = String(it.reply || '').trim();
  const replyOk = reply && !C.draftProblems(reply).length;
  const own = it.booking_id ? L.one("SELECT b.* FROM ap_bookings b JOIN ap_clients c ON c._id = b.client_id WHERE b._id = ? AND b._deleted = 0 AND c.email = ?", Number(it.booking_id), r.from_email) : null;
  const req = { thread_id: r.thread_id, inbox_id: r._id };
  const offer = (ids, who, near) => {
    const times = E.around(d, ids, who, near).map((x) => ({ start_at: x.start_at, staff_name: x.staff_name }));
    const m = C.optionsEmail(lang, s, { name: it.name || r.from_name, service: ids.length ? S.combo(d.services, ids).name : '', times, page: s.public_url });
    L.write(draft(s, r, 'options', `Re: ${r.subject || m.subject}`.slice(0, 200), replyOk ? `${reply}\n\n${m.body.split('\n').slice(2).join('\n')}` : m.body));
    return 'Not free as asked: free times offered, waiting for your Approve';
  };
  if (it.intent === 'new') {
    if (!svc.length || svc.includes(null)) return finish('Failed', 'The agent named a service that is not offered');
    if (staff < 0) return finish('Failed', `Nobody in the team is called "${it.staff}"`);
    const hit = S.firstWish(d, svc, staff, wishes);
    if (!hit) return finish('Draft', offer(svc, staff, wishes.length ? S.localToUtc(wishes[0].date, wishes[0].from || '10:00', S.zone(s.timezone)) : null));
    const res = await E.newBooking(Object.assign({ source: 'email', channel: 'email', service_id: svc[0], service_ids: JSON.stringify(svc), staff_id: staff, start_at: hit.start_at,
      name: it.name || r.from_name || r.from_email, email: r.from_email, phone: it.phone || '', note: '', language: lang }, req), { actor: 'agent' });
    if (!res.ok) return finish('Draft', offer(svc, staff, S.ms(hit.start_at)));
    return finish('Done', `Booked ${res.service} with ${res.staff_name}`, { booking_id: res.booking_id });
  }
  if (it.intent === 'cancel' || it.intent === 'change') {
    if (!own) { if (replyOk) { L.write(draft(s, r, 'reply', `Re: ${r.subject || ''}`.slice(0, 200), reply)); return 'drafted'; } return finish('Failed', 'Which appointment it is about is not clear: answer them yourself'); }
    if (it.intent === 'cancel') {
      const res = await E.cancel(own, { by: 'client', deadline: true, req, actor: 'agent' });
      if (res.ok) return finish('Done', 'Cancelled, as they asked', { booking_id: own._id });
    } else {
      const ids = E.ids(own);
      const who = staff < 0 ? (own.any_staff === 'yes' ? 0 : own.staff_id) : (staff || (own.any_staff === 'yes' ? 0 : own.staff_id));
      const hit = S.firstWish(Object.assign({}, d, { ignore: own._id }), ids, who, wishes);
      if (hit) {
        const res = await E.move(own, { start_at: hit.start_at, staff_id: who, deadline: true, req });
        if (res.ok) return finish('Done', 'Moved, as they asked', { booking_id: own._id });
      } else if (S.canChange(own, s, d.now).ok) return finish('Draft', offer(ids, who, wishes.length ? S.localToUtc(wishes[0].date, wishes[0].from || '10:00', S.zone(s.timezone)) : S.ms(own.start_at)));
    }
    L.write(draft(s, r, 'reply', `Re: ${r.subject || ''}`.slice(0, 200), replyOk ? reply : C.WORDS[lang].call({ phone: s.phone }) || 'Please call us.'));
    return 'Too late to change it on their own: an answer waits for your Approve';
  }
  if (replyOk) { L.write(draft(s, r, 'reply', `Re: ${r.subject || ''}`.slice(0, 200), reply)); return 'An answer waits for your Approve'; }
  return finish('Done', 'Nothing to do');
}

async function save() {
  const picked = L.jsonIn(process.env.STEP_pick || '') || {};
  if (picked.skip || !Array.isArray(picked.ids)) return { ok: true, skipped: true };
  const answer = L.jsonIn(process.env.PRIOR || '') || {};
  const items = Array.isArray(answer.items) ? answer.items : [];
  const s = L.settings();
  const out = { ok: true, done: [] };
  const held = L.lock('book', 30000);
  try {
    for (const id of picked.ids) {
      const r = L.one("SELECT * FROM ap_inbox WHERE _id = ? AND status = 'Working'", id);
      if (!r) continue;
      const it = items.find((x) => Number(x && x.id) === Number(id));
      if (!it || !['new', 'change', 'cancel', 'question', 'other'].includes(it.intent)) {
        L.write([{ op: 'update', table: 'ap_inbox', id, data: { status: 'Failed', why: it ? `Unknown intent "${it.intent}"` : 'The agent gave no answer for it' } }]);
        out.done.push({ id, failed: true });
        continue;
      }
      try { out.done.push({ id, said: await handle(s, r, it) }); } catch (e) {
        L.write([{ op: 'update', table: 'ap_inbox', id, data: { status: 'Failed', why: e.message.slice(0, 300) } }]);
        out.done.push({ id, failed: e.message });
      }
    }
    await E.aftercare();
  } finally { if (held) held.release(); }
  return out;
}

if (require.main === module) {
  const cmd = process.argv[2];
  Promise.resolve(cmd === 'save' ? save() : pick()).then((o) => L.done(o), (e) => { L.done({ ok: false, error: e.message }); process.exitCode = 1; });
}
module.exports = { pick, save, handle };
