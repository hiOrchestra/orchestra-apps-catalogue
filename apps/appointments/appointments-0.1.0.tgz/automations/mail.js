'use strict';
/**
 * Appointments · Check Gmail (optional; only while "Book from emails" is on).
 * A script, no agent: reads what arrived at the business's Gmail since the
 * last look and keeps, once each (a unique index on the Gmail id), only what
 * looks like it is about an appointment: an answer in a thread the app wrote
 * in, or words like cita, turno, reserva, cancelar, appointment, book. The
 * rest is noted as Ignored with no content kept. If anything is new, it
 * starts the agent's workflow (inbox.js). With --now (Check again) it also
 * tells Settings whether Gmail answers, even with the assistant off.
 *   node mail.js [--auto|--now] [--dry-run]
 */
const L = require('./lib');
const G = require('./composio');

const ABOUT = /\b(cita|citas|turno|reserv\w*|hora para|pedir hora|cancel\w*|anul\w*|cambiar|mover|aplazar|llego tarde|appointment|book\w*|reschedul\w*|running late)\b/i;
const FIRST_LOOK_MS = 2 * 86400000;

function run(mode = '--auto', dry = false) {
  const s = L.settings();
  const out = { ok: true, mode, gmail: null, kept: 0, ignored: 0 };
  if (mode === '--now' || s.inbox_on === 'yes' || s.emails_on === 'yes') {
    try {
      const address = G.profile();
      out.gmail = 'ok';
      if (!dry) L.write([{ op: 'update', table: 'ap_settings', id: s._id, data: { gmail_status: 'ok', gmail_account: address, gmail_checked_at: L.sqlNow(), gmail_note: null } }]);
    } catch (e) {
      out.gmail = e.notConnected ? 'not_connected' : 'error';
      if (!dry) L.write([{ op: 'update', table: 'ap_settings', id: s._id, data: { gmail_status: out.gmail, gmail_checked_at: L.sqlNow(), gmail_note: String(e.message).slice(0, 200) } }]);
      return out;
    }
  }
  if (s.inbox_on !== 'yes') return Object.assign(out, { skipped: 'Book from emails is off' });
  const cursor = L.toDate(s.gmail_cursor);
  const since = cursor ? cursor.getTime() - 10 * 60000 : L.now().getTime() - FIRST_LOOK_MS;
  let page;
  try { page = G.fetch({ query: `in:inbox -from:me -category:promotions -category:social after:${Math.floor(since / 1000)}`, max: 25 }); } catch (e) { return Object.assign(out, { ok: false, error: e.message }); }
  const threads = new Set([...L.all("SELECT DISTINCT thread_id AS t FROM ap_emails WHERE COALESCE(thread_id, '') <> ''"), ...L.all("SELECT DISTINCT thread_id AS t FROM ap_bookings WHERE COALESCE(thread_id, '') <> ''")].map((r) => r.t));
  let newest = cursor;
  for (const m of page.messages) {
    if (m.at && (!newest || m.at > newest)) newest = m.at;
    if (L.one('SELECT 1 AS x FROM ap_inbox WHERE gmail_id = ?', m.id)) continue;
    const ours = threads.has(m.threadId);
    const keep = ours || ABOUT.test(`${m.subject}\n${m.text}`);
    const from = (m.from.match(/<([^>]+)>/) || [])[1] || m.from;
    const data = keep ? { gmail_id: m.id, thread_id: m.threadId, from_email: String(from).trim().toLowerCase().slice(0, 200), from_name: m.from.replace(/<[^>]+>/, '').replace(/"/g, '').trim().slice(0, 120),
      subject: m.subject.slice(0, 200), body: m.text.slice(0, 3000), received_at: m.at ? m.at.toISOString() : null, status: 'New', why: ours ? 'An answer in a thread with us' : null }
      : { gmail_id: m.id, status: 'Ignored', why: 'Not about an appointment' };
    if (dry) { out[keep ? 'kept' : 'ignored'] += 1; continue; }
    try { L.write([{ op: 'insert', table: 'ap_inbox', data }]); out[keep ? 'kept' : 'ignored'] += 1; } catch { /* read by another run */ }
  }
  if (!dry && newest && (!cursor || newest > cursor)) L.write([{ op: 'update', table: 'ap_settings', id: s._id, data: { gmail_cursor: newest.toISOString() } }]);
  const waiting = L.one("SELECT COUNT(*) AS n FROM ap_inbox WHERE _deleted = 0 AND status = 'New'").n;
  if (!dry && waiting && s.agent) out.agent = L.kick('read');
  return Object.assign(out, { waiting });
}

if (require.main === module) {
  const a = process.argv.slice(2);
  try { L.done(run(a.includes('--now') ? '--now' : '--auto', a.includes('--dry-run'))); } catch (e) { L.done({ ok: false, error: e.message }); process.exitCode = 1; }
}
module.exports = { run, ABOUT };
