'use strict';
/**
 * Appointments · Due to rebook (optional; weekly, "Invite clients who are
 * due back" in Settings). The two script steps around the agent's turn.
 *
 *   node rebook.js pick   up to 8 clients past their service's "Rebook after",
 *                         with an email, nothing booked, not invited since their
 *                         last visit: who, what, when, with whom
 *   node rebook.js save   the agent's short invitations ($PRIOR, JSON only):
 *                         each one without placeholders or links (the booking
 *                         link is added here) is kept, otherwise the plain
 *                         template is used; all wait in Messages for Approve.
 */
const L = require('./lib');
const S = require('./sched');
const C = require('./aptcore');

const MAX = 8;

function due() {
  const now = L.isoZ(L.now());
  return L.all(`SELECT * FROM (
    SELECT c._id AS client_id, c.name, c.email, c.language, s.name AS service, MAX(b.start_at) AS last_at,
      (SELECT b2.staff_name FROM ap_bookings b2 WHERE b2.client_id = c._id AND b2._deleted = 0 ORDER BY b2.start_at DESC LIMIT 1) AS staff
    FROM ap_bookings b JOIN ap_clients c ON c._id = b.client_id AND c._deleted = 0 JOIN ap_services s ON s._id = b.service_id
    WHERE b._deleted = 0 AND s.rebook_weeks > 0 AND b.status IN ('Arrived', 'Booked') AND b.start_at <= ? AND COALESCE(c.email, '') <> ''
      AND NOT EXISTS (SELECT 1 FROM ap_bookings f WHERE f._deleted = 0 AND f.client_id = c._id AND f.status = 'Booked' AND f.start_at > ?)
    GROUP BY c._id, s._id
    HAVING date(MAX(b.start_at), '+' || (s.rebook_weeks * 7) || ' days') <= date(?)
  ) g WHERE NOT EXISTS (SELECT 1 FROM ap_emails e WHERE e._deleted = 0 AND e.client_id = g.client_id AND e.purpose = 'rebook' AND e.status <> 'Dropped'
      AND datetime(e._created_at) >= datetime(g.last_at))
  ORDER BY last_at LIMIT ${MAX}`, now, now, now.slice(0, 10));
}

function pick() {
  const s = L.settings();
  if (s.rebook_on !== 'yes') return { skip: true, why: 'Invitations are off' };
  const tz = S.zone(s.timezone);
  const list = due();
  if (!list.length) return { skip: true, why: 'Nobody is due' };
  return { business: s.business_name || '', clients: list.map((c) => ({ client_id: c.client_id, name: c.name, language: C.langOf(c.language, s.default_language),
    service: c.service, last_visit: S.localDay(S.ms(c.last_at), tz), with: c.staff || '' })) };
}

function save() {
  const picked = L.jsonIn(process.env.STEP_pick || '') || {};
  const s = L.settings();
  if (picked.skip || !Array.isArray(picked.clients)) return { ok: true, skipped: true };
  const items = (L.jsonIn(process.env.PRIOR || '') || {}).items || [];
  const still = new Set(due().map((c) => c.client_id));
  const ops = [];
  const out = { ok: true, agent: 0, template: 0 };
  for (const c of picked.clients) {
    if (!still.has(c.client_id)) continue;
    const row = L.one('SELECT email FROM ap_clients WHERE _id = ?', c.client_id);
    const it = (Array.isArray(items) ? items : []).find((x) => x && Number(x.client_id) === Number(c.client_id));
    const w = C.WORDS[C.langOf(c.language, s.default_language)];
    const good = it && String(it.subject || '').trim() && !C.draftProblems(it.body).length && !C.draftProblems(it.subject).length;
    const m = good ? { subject: String(it.subject).trim().slice(0, 150), body: `${String(it.body).trim()}\n\n${w.book({ page: s.public_url })}` }
      : C.rebookEmail(c.language, s, { name: c.name, service: c.service, page: s.public_url });
    ops.push({ op: 'insert', table: 'ap_emails', data: { client_id: c.client_id, purpose: 'rebook', to_email: row.email, subject: m.subject, body: m.body, status: 'Review', drafted_by: good ? 'agent' : 'template' } });
    out[good ? 'agent' : 'template'] += 1;
  }
  ops.push({ op: 'update', table: 'ap_settings', id: s._id, data: { rebook_run_at: L.sqlNow() } });
  L.write(ops);
  return out;
}

if (require.main === module) {
  try { L.done(process.argv[2] === 'save' ? save() : pick()); } catch (e) { L.done({ ok: false, error: e.message }); process.exitCode = 1; }
}
module.exports = { pick, save, due };
