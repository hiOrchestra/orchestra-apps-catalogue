'use strict';
/**
 * Appointments · Take bookings. Every request still New (from the public
 * page, the client's link, the desk's phone bookings and moves) is judged
 * again here, the page is not trusted, and goes through the one door
 * (engine.js):
 *
 *   online   the bot trap, under 3 seconds, the same request twice, a name,
 *            an email and a phone; a paused page takes nothing new. A cancel
 *            or a move must carry the booking's own token and respect the
 *            deadline of Settings.
 *   desk     a name; "Book anyway" (override) is honoured.
 *
 * Booked → the booking, its holds, the client's link and the confirmation
 * (Queued). Not possible → Failed (online: the client's page shows why and
 * the nearest free times) or Conflict (desk: the clashes, and Book anyway).
 * Then the aftercare: holds of finished bookings, notices of the desk's
 * cancellations, every link up to date. One run at a time; the run holding
 * the lock looks once more before it lets go.
 *   node intake.js [--auto|--now] [--dry-run]
 */
const L = require('./lib');
const E = require('./engine');
const S = require('./sched');
const C = require('./aptcore');

const BATCH = 50;
const REASON = {
  service: 'That service is not offered any more', length: 'That service has no valid length', time: 'That is not a valid time',
  staff: 'That person does not do this service', past: 'That time has passed', notice: 'Too close to now: there is a minimum notice',
  window: 'Too far ahead: outside the booking window', off: 'That person is off that day', hours: 'Outside working hours',
  limit: 'That person is fully booked that day', clash: 'That time is taken', 'taken-meanwhile': 'It changed meanwhile',
  deadline: 'Too late to change it online: please call', state: 'That appointment is no longer active', notfound: 'That appointment was not found',
  paused: 'Online booking is paused',
};

/** What is wrong with a request before any time is looked at; null when nothing. */
function verdict(r, s) {
  if (!['new', 'cancel', 'reschedule'].includes(r.kind)) return { status: 'Failed', reason: 'Unknown kind of request' };
  if (r.source === 'online') {
    if (String(r.hp || '').trim()) return { status: 'Discarded', reason: 'A field only bots see was filled' };
    if (Number.isFinite(Number(r.ms)) && Number(r.ms) < 3000) return { status: 'Discarded', reason: 'Sent in under 3 seconds' };
    if (r.visit) {
      const twin = L.one("SELECT _id FROM ap_requests WHERE _deleted = 0 AND visit = ? AND _id < ? AND status IN ('Booked', 'Done') LIMIT 1", String(r.visit), r._id);
      if (twin) return { status: 'Discarded', reason: `Sent twice: the same request arrived before as #${twin._id}` };
    }
    if (r.kind === 'new' && s.paused === 'yes') return { status: 'Failed', reason: REASON.paused, code: 'paused' };
    if (r.kind === 'new' && (!C.cleanName(r.name) || !C.isEmail(r.email) || !C.normPhone(r.phone))) return { status: 'Failed', reason: 'A name, an email and a phone are needed', code: 'details' };
    if (!C.TOKEN.test(String(r.token || ''))) return { status: 'Discarded', reason: 'No valid link token' };
  } else if (r.kind === 'new' && !C.cleanName(r.name)) return { status: 'Failed', reason: 'A name is needed', code: 'details' };
  return null;
}

/** The booking a cancel or a move is about: by its own token (online), or by id (desk, agent). */
function bookingOf(r) {
  if (r.source === 'online') return L.one('SELECT * FROM ap_bookings WHERE _deleted = 0 AND link_token = ?', String(r.token || ''));
  return Number(r.booking_id) ? L.one('SELECT * FROM ap_bookings WHERE _deleted = 0 AND _id = ?', Number(r.booking_id)) : null;
}

async function failLink(s, r, code, alternatives) {
  if (r.source !== 'online') return [];
  if (r.kind === 'new') {
    return E.linkOps(s, r.token, null, { reason: code, service_ids: E.ids(r), staff_id: Number(r.staff_id) || 0, alternatives: alternatives || [] },
      { requestId: r._id, last: E.lastOf(r, false, { code }) });
  }
  const b = bookingOf(r);
  return b ? E.linkOps(s, b.link_token, b, E.extraFor(s, b), { bookingId: b._id, last: E.lastOf(r, false, { code, alternatives: alternatives || [] }) }) : [];
}

async function close(s, r, status, code, extra = {}) {
  const ops = [{ op: 'update', table: 'ap_requests', id: r._id, when: { status: 'New' }, data: Object.assign({
    status, reason: REASON[code] || code || null, processed_at: L.sqlNow() }, extra.clashes ? { clashes: JSON.stringify(extra.clashes).slice(0, 4000) } : {}) }];
  ops.push(...await failLink(s, r, code, extra.alternatives));
  try { L.write(ops); } catch { /* taken by another run meanwhile */ }
}

function tell(s, text) { if (s.notify_telegram) L.telegram(s.notify_telegram, text); }

async function handle(r, s, out, dry) {
  const v = verdict(r, s);
  if (dry) { out.would.push({ id: r._id, kind: r.kind, verdict: v ? v.status : 'judge' }); return; }
  if (v) { await close(s, r, v.status, v.code || v.reason); out[v.status.toLowerCase()] = (out[v.status.toLowerCase()] || 0) + 1; return; }
  let res;
  if (r.kind === 'new') res = await E.newBooking(r);
  else {
    const b = bookingOf(r);
    if (!b) res = { ok: false, code: 'notfound' };
    else if (r.kind === 'cancel') res = await E.cancel(b, { by: r.source === 'online' ? 'client' : 'business', reason: r.note, deadline: r.source === 'online', req: r, actor: r.created_by });
    else res = await E.move(b, { start_at: r.start_at, staff_id: r.staff_id === null || r.staff_id === undefined ? null : r.staff_id, deadline: r.source === 'online', req: r, override: r.override === 'yes' && r.source !== 'online' });
  }
  if (res.ok) {
    out.done += 1;
    if (r.source === 'online') {
      const b = L.one('SELECT * FROM ap_bookings WHERE _id = ?', res.booking_id) || {};
      const when = `${S.localDay(S.ms(b.start_at), s.timezone)} ${S.localTime(S.ms(b.start_at), s.timezone)}`;
      tell(s, r.kind === 'new' ? `New booking: ${b.client_name}, ${b.service_name} with ${b.staff_name}, ${when}`
        : r.kind === 'cancel' ? `Cancelled by the client: ${b.client_name}, ${b.service_name}, was ${when}` : `Moved by the client: ${b.client_name}, ${b.service_name}, now ${when}`);
    }
    return;
  }
  out.refused += 1;
  await close(s, r, r.source === 'online' ? 'Failed' : 'Conflict', res.code, { clashes: res.clashes, alternatives: res.alternatives });
}

async function run(mode = '--auto', dry = false) {
  const out = { ok: true, mode, done: 0, refused: 0, would: dry ? [] : undefined };
  for (let round = 0; round < 3; round += 1) {
    const held = dry ? { release() {} } : L.lock('book', 20000);
    if (!held) return Object.assign(out, { skipped: 'Another run is booking' });
    try {
      for (;;) {
        const s = L.settings();
        const rows = L.all(`SELECT * FROM ap_requests WHERE _deleted = 0 AND status = 'New' ORDER BY _id LIMIT ${BATCH}`);
        for (const r of rows) await handle(r, s, out, dry);
        if (dry || rows.length < BATCH) break;
      }
      if (!dry) out.aftercare = await E.aftercare();
    } finally { held.release(); }
    // What arrived while this run was finishing was left to it: look once more.
    if (dry || !L.one("SELECT 1 AS x FROM ap_requests WHERE _deleted = 0 AND status = 'New' LIMIT 1")) break;
  }
  if (!dry) { const s = L.settings(); L.write([{ op: 'update', table: 'ap_settings', id: s._id, data: { intake_at: L.sqlNow(), intake_note: `${out.done} done, ${out.refused} refused` } }]); }
  return out;
}

if (require.main === module) {
  const args = process.argv.slice(2);
  run(args.includes('--now') ? '--now' : '--auto', args.includes('--dry-run'))
    .then((o) => L.done(o), (e) => { L.done({ ok: false, error: e.message }); process.exitCode = 1; });
}

module.exports = { run, verdict, REASON };
