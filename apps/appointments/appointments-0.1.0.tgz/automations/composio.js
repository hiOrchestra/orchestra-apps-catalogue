'use strict';
/**
 * Every call Appointments makes to Composio (the business's Gmail), and
 * nothing else: the slugs, their arguments, and how each answer is read.
 * When Composio renames an argument, this is the only file to change.
 *
 *   profile()                   GMAIL_GET_PROFILE        the connected mailbox's address
 *   fetch({ query, pageToken })  GMAIL_FETCH_EMAILS       one page of messages (read only)
 *   send({ to, subject, body })  GMAIL_SEND_EMAIL         a new plain-text email
 *   reply({ thread, to, body })  GMAIL_REPLY_TO_THREAD    an answer inside the client's own thread
 *
 * Argument names follow the CRM's and Helpdesk's (checked on staging 10/2026)
 * except GMAIL_REPLY_TO_THREAD, which is to be checked with
 * `orch-composio schema --slug GMAIL_REPLY_TO_THREAD` before it goes live
 * (README). Calls go through the instance as the workflow's agent (lib.composio).
 *
 * APPT_FAKE_COMPOSIO=1 answers from APPT_FAKE_GMAIL, a JSON file:
 * { address, messages: [{messageId, threadId, messageTimestamp, sender, subject, messageText}],
 *   fail: "why" (every call fails), sent: [] }; every email "sent" is appended
 * to `sent`. An address starting with fail@ is refused, timeout@ never answers.
 */
const fs = require('fs');
const L = require('./lib');

const SLUG = { profile: 'GMAIL_GET_PROFILE', fetch: 'GMAIL_FETCH_EMAILS', send: 'GMAIL_SEND_EMAIL', reply: 'GMAIL_REPLY_TO_THREAD' };
const NOT_CONNECTED = /no connected account|not connected|connection.*(not found|expired|revoked)|connectedAccount|auth.*(expired|revoked)|invalid_grant/i;

function arrayAt(obj, key, depth = 0) {
  if (!obj || typeof obj !== 'object' || depth > 4) return null;
  if (Array.isArray(obj[key])) return obj[key];
  for (const v of Object.values(obj)) { const f = arrayAt(v, key, depth + 1); if (f) return f; }
  return null;
}
function valueAt(obj, key, depth = 0) {
  if (!obj || typeof obj !== 'object' || depth > 5) return undefined;
  if (obj[key] !== undefined && obj[key] !== null && typeof obj[key] !== 'object') return obj[key];
  for (const v of Object.values(obj)) { const f = valueAt(v, key, depth + 1); if (f !== undefined) return f; }
  return undefined;
}
function timeOf(v) {
  if (v === null || v === undefined || v === '') return null;
  const n = Number(v);
  const d = Number.isFinite(n) && String(v).trim() !== '' ? new Date(n < 1e12 ? n * 1000 : n) : new Date(String(v));
  return Number.isNaN(d.getTime()) ? null : d;
}
const fail = (r) => Object.assign(new Error(r.why), { timeout: !!r.timedOut, notConnected: NOT_CONNECTED.test(String(r.why || '')) });

/** The connected mailbox's address; throws (notConnected) when there is none. */
function profile() {
  const r = L.composio(SLUG.profile, { user_id: 'me' }, 30);
  if (!r.ok) throw fail(r);
  return String(valueAt(r.data, 'emailAddress') || valueAt(r.data, 'email_address') || '').toLowerCase();
}

/** One page of messages, newest first: { messages: [{ id, threadId, at, from, subject, text }], next }. */
function fetch({ query, pageToken, max = 25 }) {
  const args = { user_id: 'me', query, max_results: max, include_payload: true, verbose: true };
  if (pageToken) args.page_token = pageToken;
  const r = L.composio(SLUG.fetch, args, 60);
  if (!r.ok) throw fail(r);
  return {
    messages: (arrayAt(r.data, 'messages') || []).map((m) => ({
      id: String(m.messageId || m.id || ''),
      threadId: String(m.threadId || m.thread_id || ''),
      at: timeOf(m.messageTimestamp || m.internalDate || m.date),
      from: String(m.sender || m.from || ''),
      subject: String(m.subject || (m.preview && m.preview.subject) || ''),
      text: String(m.messageText || (m.preview && m.preview.body) || m.snippet || ''),
      labels: Array.isArray(m.labelIds) ? m.labelIds : [],
    })).filter((m) => m.id),
    next: String(valueAt(r.data, 'nextPageToken') || '') || null,
  };
}

/** A plain-text email from the connected account: { id, threadId }; throws (with .timeout when it may have gone). */
function send({ to, subject, body }) {
  const r = L.composio(SLUG.send, { user_id: 'me', recipient_email: to, subject, body, is_html: false }, 60);
  if (!r.ok) throw fail(r);
  return { id: String(valueAt(r.data, 'id') || '') || null, threadId: String(valueAt(r.data, 'threadId') || '') || null };
}

/** An answer inside the thread the client wrote in. */
function reply({ thread, to, body }) {
  const r = L.composio(SLUG.reply, { user_id: 'me', thread_id: thread, recipient_email: to, message_body: body, is_html: false }, 60);
  if (!r.ok) throw fail(r);
  return { id: String(valueAt(r.data, 'id') || '') || null, threadId: thread };
}

// ── the fake, for tests and the local harness ────────────────────────────
function fake(slug, args) {
  const file = process.env.APPT_FAKE_GMAIL;
  let d = {};
  try { d = JSON.parse(fs.readFileSync(file, 'utf8')); } catch { d = {}; }
  if (d.fail) return { ok: false, why: d.fail };
  if (slug === SLUG.profile) return { ok: true, data: { response_data: { emailAddress: d.address || 'salon@appointments-test.example' } } };
  if (slug === SLUG.fetch) {
    const after = Number((String(args.query).match(/after:(\d+)/) || [])[1] || 0) * 1000;
    const list = (d.messages || []).filter((m) => Number(m.messageTimestamp) >= after).sort((a, b) => Number(b.messageTimestamp) - Number(a.messageTimestamp));
    return { ok: true, data: { messages: list.slice(0, Number(args.max_results) || 25) } };
  }
  if (slug === SLUG.send || slug === SLUG.reply) {
    const to = String(args.recipient_email || '');
    if (/^fail@/.test(to)) return { ok: false, why: 'Invalid To header (fake)' };
    if (/^timeout@/.test(to)) return { ok: false, why: 'Operation timed out (28)', timedOut: true };
    d.sent = d.sent || [];
    d.sent.push(Object.assign({ slug }, args));
    if (file) fs.writeFileSync(file, JSON.stringify(d));
    return { ok: true, data: { response_data: { id: `fake-${d.sent.length}`, threadId: args.thread_id || `thread-${d.sent.length}` } } };
  }
  return { ok: false, why: `fake Composio has no ${slug}` };
}

module.exports = { SLUG, NOT_CONNECTED, profile, fetch, send, reply, fake, timeOf };
