// Settings: online booking (the link, pause), what is managed in Orchestra
// (the business, the booking rules, marketplaces, Telegram and the email
// assistant — Apps → Appointments → Ajustes), and the emails to clients
// through Gmail or Resend (emails.js), which stay here because turning them on
// needs a working sender. Nothing in the emails' save stops it: a switch that
// cannot be on yet stays off with a plain sentence. Opening it looks at which
// of Gmail and Resend is connected when the last look is old.
import { A, CORE, act, copy, head, lookAgain, lookIfStale, publicLink, settings } from '../data.js';
import { emailsCard } from './emails.js';

const { el, router } = Orch;
const yes = (v) => el('input', { type: 'checkbox', checked: v === 'yes' });
const check = (box, label, help) => el('label', { class: 'ap-check ap-check--block' }, [box, el('span', { class: 'oc-stack oc-stack--tight' }, [el('span', label), help ? el('span', { class: 'oc-help' }, help) : null])]);
const ago = (min) => { const n = Number(min) || 0; return n === 0 ? 'none' : n % 1440 === 0 ? `${n / 1440} day${n === 1440 ? '' : 's'}` : n % 60 === 0 ? `${n / 60} h` : `${n} min`; };

export function render() {
  const again = () => render();
  Orch.load('view', async () => {
    const s = await settings();
    lookIfStale(s, again);
    const t = { emails_on: yes(s.emails_on), reminder_24h: yes(s.reminder_24h === 'no' ? 'no' : 'yes'), reminder_2h: yes(s.reminder_2h) };
    const emails = emailsCard(s, t, check, again);
    const link = publicLink(s);
    const save = el('button', { type: 'submit', class: 'oc-btn oc-btn--primary' }, 'Save emails');
    const form = el('form', { class: 'oc-stack oc-stack--loose ap-form', onSubmit: async (e) => {
      e.preventDefault();
      const data = Object.fromEntries(Object.entries(t).map(([k, b]) => [k, b.checked ? 'yes' : 'no']));
      const mail = emails.take(data);
      if (mail.stop) { Orch.toast(mail.stop); if (mail.focus) mail.focus.focus(); return; }
      save.disabled = true;
      if (await act(A.settings, Object.assign({ id: s._id }, data), mail.note ? `Saved. ${mail.note}` : 'Saved.')) {
        if (mail.changed) await lookAgain(s, again, { quiet: true }); else again();
      }
      save.disabled = false;
    } }, [emails.card, el('div', { class: 'oc-row' }, [save])]);
    return el('div', { class: 'oc-stack oc-stack--loose' }, [
      head('Settings', 'Online booking, what is managed in Orchestra, and emails.'),
      el('section', { class: 'oc-card oc-stack ap-form' }, [
        el('div', { class: 'oc-row oc-row--between' }, [el('h2', { class: 'oc-h2' }, 'Online booking'), el('span', { class: `oc-badge${s.paused === 'yes' ? ' oc-badge--warn' : ' oc-badge--good'}` }, s.paused === 'yes' ? 'Paused' : 'Open')]),
        el('div', { class: 'ap-code' }, [el('code', link), el('button', { type: 'button', class: 'oc-btn oc-btn--sm', onClick: () => copy(link, 'Booking link copied.') }, 'Copy')]),
        el('p', { class: 'oc-help' }, ['A link per channel (Instagram, Google…) is in ', router.link('/sources', 'Sources'), '. Pausing hides every time on the page; the desk keeps working.']),
        el('div', { class: 'oc-row' }, [el('button', { type: 'button', class: 'oc-btn', onClick: async () => {
          if (await act(s.paused === 'yes' ? A.resume : A.pause, { id: s._id }, s.paused === 'yes' ? 'Online booking is open.' : 'Online booking is paused.')) again();
        } }, s.paused === 'yes' ? 'Open online booking' : 'Pause online booking')]),
      ]),
      managed(s),
      form,
    ]);
  });
}

// The business, the booking rules, marketplaces, Telegram and the email
// assistant are managed in Orchestra (Apps → Appointments → Ajustes): typed,
// next to the agent that reads booking emails and drafts invitations. Here,
// what they are now and a way there.
function managed(s) {
  const link = el('a', { class: 'oc-btn oc-btn--primary', target: '_blank', rel: 'noopener', hidden: true }, 'Open the settings in Orchestra');
  const where = el('p', { class: 'oc-help' }, 'In Orchestra: Apps → Appointments → Ajustes.');
  if (Orch.manageUrl) Orch.manageUrl('settings').then((url) => { if (url) { link.href = url; link.hidden = false; where.hidden = true; } });
  const facts = [
    ['Business', s.business_name || 'not named yet'],
    ['Time zone', s.timezone || 'Europe/Madrid'],
    ['Start times', `every ${ago(s.slot_step_min || 15)}`],
    ['Notice, how far ahead, changes', `${ago(s.min_notice_min)} · ${s.window_days || 60} days · ${Number(s.change_hours) ? `up to ${s.change_hours} h before` : 'up to the start'}`],
    ['Marketplaces', CORE.marketplacesOf(s).join(', ') || '—'],
    ['Telegram', s.notify_telegram ? 'on' : 'off'],
    ['Book from emails, invite clients due back', `${s.inbox_on === 'yes' ? 'on' : 'off'} · ${s.rebook_on === 'yes' ? 'on' : 'off'}`],
  ];
  return el('section', { class: 'oc-card oc-stack' }, [
    el('h2', { class: 'oc-h2' }, 'Your business and its rules'),
    el('p', { class: 'oc-help' }, 'What clients see, the booking rules, marketplaces, Telegram and the email assistant are managed in Orchestra.'),
    el('ul', { class: 'oc-stack oc-stack--tight' }, facts.map(([k, v]) => el('li', [el('b', `${k}: `), v]))),
    el('div', { class: 'oc-row' }, [link]), where,
  ]);
}
