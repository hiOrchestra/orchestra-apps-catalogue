---
name: app-appointments
version: 0.1.1
description: >-
  Work in the Appointments app of a salon, barber or clinic: the day's agenda
  per person, booking, moving and cancelling appointments, clients, no-shows,
  services and the team, and where clients come from. Load it when someone
  says "dame turno con Ana el jueves / book Lucía with Ana on Thursday",
  "agenda de hoy / who is coming today", "cancelá / cancela la cita de…",
  "mové / mueve a Pedro a las 6", "¿hay hueco para mechas mañana? / is there
  time for highlights tomorrow", "quién no vino / no-shows this month",
  "llegó Marta / mark her as arrived", "bloqueá la tarde de Javi",
  "¿de dónde vienen los clientes? / where do clients come from",
  "cuánto ahorré en comisiones / commission saved vs Fresha", "quién tiene que
  volver / who is due back". Needs Appointments installed in a project you
  work in.
metadata:
  openclaw:
    emoji: "📅"
---
# Appointments: the agenda of a salon or clinic

Clients book on a public page (one link per channel: Instagram, Google…), the
team works from the desk (Today, a column per person), and every booking,
from the page, the desk, an email or you, goes through **one door** that
applies the same rules and holds the person's time in the database: two
people can never get the same time.

```bash
ls -d ~/.openclaw/orchestra/projects/*/apps/appointments    # the directory name under projects/ is the project id
P=<project>; A=~/.openclaw/orchestra/projects/$P/apps/appointments/automations
orch-canvas url appointments            # the desk, for the person
orch-canvas url appointments-book       # the booking page to share
```

If nothing is listed, Appointments is not installed in a project you work in:
say so, and do not keep an agenda some other way.

## Your tool: `node $A/book.js` (always this, never raw writes)

It prints one JSON line. A refusal exits 2 with `code`, the `clashes` (who
holds the time) and `nearest` free times: offer those.

| To | Run |
|---|---|
| Today's (or a day's) agenda | `node $A/book.js today [--day 2026-10-08]` |
| Free times | `node $A/book.js slots --service "mechas" [--staff Ana\|any] --day 2026-10-08` |
| Book | `node $A/book.js book --service "mechas,corte" --staff Ana --at "2026-10-08 18:00" --name "Lucía Romero" --phone "600…" [--email …] [--note …] [--from phone\|walk-in\|Fresha]` |
| Move | `node $A/book.js move --id 12 --at "2026-10-09 10:00" [--staff any]` |
| Cancel | `node $A/book.js cancel --id 12 [--reason "…"]` |
| Arrived / no-show | `node $A/book.js arrived --id 12` · `node $A/book.js noshow --id 12` |
| A client: history, notes, first source | `node $A/book.js find --client "lucía"` |
| No-shows | `node $A/book.js noshows [--since 2026-09-01]` |
| Sources, commission avoided | `node $A/book.js sources` |
| Due back (rebook) | `node $A/book.js due` |

- Times are the business's wall clock, in its time zone (Settings). Several
  services one after the other: `--service "mechas,corte"` (the same person
  does both, lengths add up).
- `--staff any` gives it to the least booked person that day among those free.
- `--override` books over a clash or outside the rules (hours, notice). Use it
  **only** when the owner said so explicitly ("ponela igual / book it anyway").
- The client gets their confirmation, change or cancellation email on their
  own when emails are on (Settings): you do not write those.
- `--from` is where the client came from (phone by default; a walk-in, or the
  name of a marketplace from Settings). It feeds Sources.

## The model (tables `ap_*`, read with `orch-database --project $P query`, `_deleted = 0`)

| Table | One row per | Notes |
|---|---|---|
| `ap_settings` | one row | business, `timezone`, `currency`, rules (`slot_step_min`, `min_notice_min`, `window_days`, `change_hours`: until when clients can change it themselves), `emails_on`, `reminder_24h/2h`, `paused`, `marketplaces`, `marketplace_fee_pct`, the optional assistant (`inbox_on`, `rebook_on`) |
| `ap_services` | service | `duration_min`, `price_minor` (cents), `buffer_before_min/after_min`, `rebook_weeks`, `active` |
| `ap_staff` | person | `hours` JSON `{mon: [["09:00","14:00"],["15:00","20:00"]]}` (the gap is the break), `services` JSON ids, `max_per_day`, `active` |
| `ap_time_off` | days off | `staff_id` (0 = the business is closed), `day_from`, `day_to` |
| `ap_blocks` | blocked time | `staff_id`, `start_at`, `end_at`, `note`, `active` |
| `ap_clients` | client | `name`, `email`, `phone`, `notes`, `first_channel` |
| `ap_bookings` | appointment | `status` Booked, Arrived, NoShow, Cancelled; `start_at`/`end_at` UTC ISO; `busy_from`/`busy_to` with buffers; `channel` (`page`, `page:instagram`, `link`, `email`, `phone`, `walk-in`, `marketplace:Fresha`); `any_staff`, `link_token` (the client's private link) |
| `ap_holds` | 5 minutes of a person's time | unique while `live = 'yes'`: the guarantee against double booking. Never touch it |
| `ap_requests` | something asked of the door | from the page, the desk, the client's link; New → Booked/Done, Failed, Conflict, Discarded |
| `ap_emails` | email to a client | Queued (automatic, they asked) → Sent; Review (written outside the rules) → Approved by a person → Sent; Failed with the reason |
| `ap_inbox` | booking email read (optional) | New → Done / Draft / Failed |

## Recipes

- **"Dame turno con Ana el jueves después de las 6"**: `slots` for that day
  and person, pick the first at or after 18:00, `book`. Not free: say what is
  (`nearest`) and ask which one.
- **"Agenda de hoy" / "who is coming"**: `today`; group by person, times in
  order, say no-shows and arrivals.
- **"Cancelá la cita de Lucía"**: `find --client lucía` → its Booked id →
  confirm with the person ("¿la de mañana a las 10 con Ana?") → `cancel`.
- **"Quién no vino este mes"**: `noshows --since <first of month>`.
- **"¿De dónde vienen los clientes?" / "cuánto ahorré en comisiones"**:
  `sources`. The amount is an **estimate**: new clients who came direct × their
  first appointment × the marketplace fee in Settings. Say so.
- **"Who is due back"**: `due`; offer to draft invitations only if the owner
  wants (Settings → Invite clients who are due back makes the weekly drafts;
  they wait in Messages for Approve).

## The optional email assistant

Off unless the owner turns it on (Settings → Book from emails). Then a
workflow reads booking emails from the business's Gmail and asks you, as the
`delegate` step, for **JSON only** (intent, services, person, wished times as
exact dates, a reply only for questions). A script books within the rules and
answers in the client's thread; anything else waits for the owner's Approve.
In that step you contact nobody and write nothing.

## Never

- Write to `ap_*` with `orch-database` insert/update: everything goes through
  `book.js` or the desk (the holds and the client's link would be wrong).
- Book over a clash or outside the rules without the owner's explicit OK.
- Send a client anything yourself: their emails go from the app, and anything
  else waits in Messages for a person's Approve.
- Touch `ap_holds`, `ap_links` or a client's `link_token`.
