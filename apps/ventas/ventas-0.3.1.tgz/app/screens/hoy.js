// Hoy: what waits for you. "Qué pasa ahora" on top (the three steps, who does
// each and when), then the messages the agent drafted (approve, edit or
// reject each one), the ones that could not go out, the prospects that
// replied, and the next steps due — with the sending mode always in view.
import { C, V, A, T, act, badge, counts, dayOf, head, metric, modeBanner, nextStrip, section, settings, signalChips, live, plural } from '../data.js';
import { openMessage } from './mensaje.js';

const { el, router } = Orch;

export function render() {
  Orch.load('view', async () => {
    const s = await settings(true);
    const week = new Date(Date.now() - 7 * 86400000).toISOString().slice(0, 10);
    const [drafts, failed, ready, replied, due, newWeek, calls, c, approved, pitches] = await Promise.all([
      Orch.db.view(V.messages, { filter: { status: 'borrador' }, sort: '_id:asc', limit: 100 }),
      Orch.db.view(V.messages, { filter: { status: 'error' }, sort: '_id:desc', limit: 50 }),
      Orch.db.count(T.messages, { filter: { status: 'aprobado' } }),
      Orch.db.view(V.prospects, { filter: { stage: 'respondio' }, sort: 'updated_at:desc', limit: 50 }),
      Orch.db.view(V.prospects, { filter: { due_state: ['overdue', 'today'] }, sort: 'next_step_at:asc', limit: 50 }),
      Orch.db.count(T.prospects, { filter: { _created_at: { gte: week } } }),
      Orch.db.count(T.prospects, { filter: { stage: 'llamada' } }),
      counts(),
      Orch.db.view(V.messages, { filter: { status: 'aprobado' }, sort: 'approved_at:asc', limit: 100 }),
      Orch.db.view(V.pitches, { sort: '_id:asc', limit: 200 }),
    ]);
    const again = () => render();
    const all = drafts.rows || [];
    const asks = all.filter((m) => String(m.needs_person || '').trim());
    const d = all.filter((m) => !String(m.needs_person || '').trim());
    const byTeam = (approved.rows || []).filter((m) => C.approvedByTeam(m));
    const offers = (pitches.rows || []).map((p) => C.trustOffer(p, p.unchanged)).filter(Boolean);
    const r = replied.rows || [];
    return el('div', { class: 'oc-stack oc-stack--loose' }, [
      head('Hoy', 'Lo que espera tu visto bueno: los mensajes del agente, las respuestas y los próximos pasos.', null),
      nextStrip(c, { onHoy: true }),
      modeBanner(s, again),
      el('div', { class: 'oc-metrics' }, [
        metric('Nuevos esta semana', String(newWeek || 0), 'prospectos', '/prospectos/nuevo'),
        metric('Por aprobar', String(all.length), (failed.rows || []).length ? `${(failed.rows || []).length} con error` : 'sin errores'),
        metric('Respuestas', String(r.length), 'por atender', '/prospectos/respondio'),
        metric('Llamadas', String(calls || 0), 'agendadas', '/prospectos/llamada'),
      ]),
      ...offers.map((o) => offerCard(o, (pitches.rows || []).find((p) => p._id === o.pitch_id), s, again)),
      asks.length ? section('El equipo te pregunta', 'Borradores en los que el equipo necesita que decidas algo antes de que salgan.',
        asks.map((m) => messageRow(m, again))) : null,
      byTeam.length ? section('Saldrán solos', 'Primeros mensajes que el equipo aprobó por la regla de su pitch. Salen al acabar su margen si no los paras.',
        byTeam.map((m) => teamRow(m, s, again))) : null,
      el('div', { id: 've-aprobar', class: 've-anchor' }, section('Mensajes por aprobar', 'Borradores del agente a partir del pitch de cada vertical. Sale lo que apruebas tú, o lo que el equipo aprueba en los pitches donde le dejaste enviar solo.',
        d.map((m) => messageRow(m, again)), 'No hay ningún mensaje esperando.')),
      (failed.rows || []).length ? section('No salieron', 'Mensajes aprobados que Gmail no aceptó o que pudieron salir o no: revísalos uno a uno.',
        failed.rows.map((m) => messageRow(m, again))) : null,
      Number(ready) ? el('p', { class: 'oc-help' }, live(s)
        ? `${plural(ready, 'mensaje aprobado sale', 'mensajes aprobados salen')} en los próximos minutos (o mañana, si se llegó al límite diario).`
        : `${plural(ready, 'mensaje aprobado está listo', 'mensajes aprobados están listos')}: en ensayo no sale ninguno.`) : null,
      section('Respondieron', 'Prospectos que contestaron. El agente prepara el seguimiento; cuando se agenda una llamada, márcalo y el equipo lo pasa al CRM.',
        r.map((p) => replyRow(p, again)), 'Nadie ha respondido todavía.'),
      section('Próximos pasos', 'Lo que tocaba hacer hoy o ya se ha pasado.', (due.rows || []).map(stepRow), 'No hay nada para hoy.'),
    ]);
  });
}

function messageRow(m, again) {
  const open = el('button', { class: 'oc-btn oc-btn--sm', type: 'button' }, m.status === 'error' ? 'Arreglar' : 'Revisar');
  open.addEventListener('click', () => openMessage(m._id, again));
  return el('li', { class: 've-row' }, [
    el('div', { class: 've-row__main' }, [
      el('span', { class: 've-row__title' }, m.subject || '(sin asunto)'),
      el('span', { class: 'oc-small oc-muted' }, [m.prospect ? router.link(`/prospecto/${m.prospect_id}`, m.prospect) : '—', m.vertical ? ` · ${m.vertical}` : '', m.to_email ? ` · ${m.to_email}` : '']),
      m.needs_person ? el('span', { class: 'oc-help ve-next__note' }, `Pregunta: ${m.needs_person}`)
        : m.status === 'error' && m.error ? el('span', { class: 'oc-help' }, m.error) : m.fit_reason ? el('span', { class: 'oc-help' }, m.fit_reason) : null,
    ]),
    el('span', { class: 'oc-small oc-muted' }, m.kind === 'seguimiento' ? 'seguimiento' : 'primero'),
    badge(m.status),
    open,
  ]);
}

function teamRow(m, s, again) {
  const at = new Date(C.leavesAt(m, s));
  const stop = el('button', { class: 'oc-btn oc-btn--sm', type: 'button' }, 'Pararlo');
  stop.addEventListener('click', async () => { stop.disabled = true; if (await act(A.unapprove, { id: m._id }, 'Parado: vuelve a borrador para que lo revises.')) again(); stop.disabled = false; });
  const look = el('button', { class: 'oc-btn oc-btn--sm oc-btn--ghost', type: 'button' }, 'Ver');
  look.addEventListener('click', () => openMessage(m._id, again));
  return el('li', { class: 've-row' }, [
    el('div', { class: 've-row__main' }, [
      el('span', { class: 've-row__title' }, m.subject || '(sin asunto)'),
      el('span', { class: 'oc-small oc-muted' }, [m.prospect ? router.link(`/prospecto/${m.prospect_id}`, m.prospect) : '—', m.to_email ? ` · ${m.to_email}` : '']),
    ]),
    el('span', { class: 'oc-small oc-muted' }, !live(s) ? 'en ensayo' : at.getTime() > Date.now() ? `sale ${at.toLocaleTimeString('es-ES', { hour: '2-digit', minute: '2-digit' })}` : 'sale ya'),
    look,
    stop,
  ]);
}

/** Hoy's offer, once the person has approved enough of a pitch unchanged: let the team send it alone. */
function offerCard(o, pitch, s, again) {
  const yes = el('button', { class: 'oc-btn oc-btn--sm oc-btn--primary', type: 'button' }, 'Que lo envíe el equipo');
  const no = el('button', { class: 'oc-btn oc-btn--sm oc-btn--ghost', type: 'button' }, 'Ahora no');
  yes.addEventListener('click', async () => { yes.disabled = true; if (await act(A.allowTeam, { id: o.pitch_id }, 'Hecho: el equipo envía solo los primeros mensajes de este pitch.')) again(); yes.disabled = false; });
  no.addEventListener('click', async () => { if (await act(A.dismissOffer, { id: o.pitch_id }, 'De acuerdo: sigues aprobándolos tú. Puedes cambiarlo en Playbook.')) again(); });
  return el('div', { class: 've-offer' }, [
    el('p', { class: 'oc-stack oc-stack--tight' }, [el('strong', o.ask), el('span', { class: 'oc-help' }, C.teamRule(pitch, s))]),
    el('div', { class: 'oc-row' }, [yes, no]),
  ]);
}

function replyRow(p, again) {
  const call = el('button', { class: 'oc-btn oc-btn--sm oc-btn--primary', type: 'button' }, 'Llamada agendada');
  call.addEventListener('click', async () => { call.disabled = true; if (await act(A.call, { id: p._id, note: 'Llamada agendada' }, 'Marcado: llamada agendada.')) again(); call.disabled = false; });
  return el('li', { class: 've-row' }, [
    el('div', { class: 've-row__main' }, [
      router.link(`/prospecto/${p._id}`, p.name, { class: 've-row__title' }),
      el('span', { class: 'oc-small oc-muted' }, [p.vertical || '—', p.contact_name ? ` · ${p.contact_name}` : '', p.city ? ` · ${p.city}` : '']),
    ]),
    signalChips(p.signals, p.signals_checked_at),
    badge(p.stage),
    call,
  ]);
}

function stepRow(p) {
  return el('li', { class: 've-row' }, [
    el('div', { class: 've-row__main' }, [
      router.link(`/prospecto/${p._id}`, p.next_step || 'Próximo paso', { class: 've-row__title' }),
      el('span', { class: 'oc-small oc-muted' }, [p.name, p.vertical ? ` · ${p.vertical}` : '']),
    ]),
    el('span', { class: 'oc-value' }, dayOf(p.next_step_at)),
    p.due_state === 'overdue' ? badge('Atrasado', 'warn') : badge('Hoy', 'accent'),
    badge(p.stage),
  ]);
}
