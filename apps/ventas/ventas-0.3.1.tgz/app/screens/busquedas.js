// Búsquedas: where prospects come from. Each search is a vertical in an area
// (a city, a province, a country), on OpenStreetMap (free) or Google Places
// (with its key). An active one runs once a day; turning it on runs it now.
// Each says when it last ran, what it found and what was new.
import { C, T, V, A, act, badge, field, formDialog, head, input, select, stamp, verticals } from '../data.js';

const { el, fmt, router } = Orch;
const SOURCES = [['osm', 'OpenStreetMap (gratis)'], ['google_places', 'Google Places (con su clave)']];

export function render() {
  Orch.load('view', async () => {
    const [list, vs] = await Promise.all([Orch.db.view(V.searches, { sort: '_id:asc', limit: 100 }), verticals()]);
    const again = () => render();
    const rows = list.rows || [];
    const add = el('button', { class: 'oc-btn', type: 'button', disabled: !vs.length, onClick: () => edit({ active: 0, source: 'osm' }, vs, again) }, 'Nueva búsqueda');
    const now = el('button', { class: 'oc-btn oc-btn--primary', type: 'button', disabled: !rows.some((s) => Number(s.active) === 1), onClick: async () => {
      now.disabled = true;
      await act(A.searchNow, {}, 'Buscando ahora las búsquedas activas. Los prospectos nuevos aparecen en unos minutos.');
      setTimeout(again, 5000);
    } }, 'Buscar ahora');
    return el('div', { class: 'oc-stack oc-stack--loose' }, [
      head('Búsquedas', 'De dónde salen los prospectos: una vertical en una zona. Una búsqueda activa se repite una vez al día y solo añade lo nuevo.', [add, now]),
      el('section', { class: 'oc-card oc-card--pad0' }, rows.length ? el('ul', { class: 've-rows' }, rows.map((s) => row(s, vs, again)))
        : el('p', { class: 've-none oc-muted' }, 'No hay búsquedas. Añade una: una vertical y una zona.')),
      el('p', { class: 'oc-help' }, 'OpenStreetMap es gratuito y se consulta con calma: una petición cada vez. Google Places da más resultados con web y teléfono; necesita la clave GOOGLE_PLACES_KEY en Apps → Ventas.'),
    ]);
  });
}

function row(s, vs, again) {
  const on = Number(s.active) === 1;
  const toggle = el('button', { class: `oc-btn oc-btn--sm${on ? '' : ' oc-btn--primary'}`, type: 'button' }, on ? 'Desactivar' : 'Activar');
  toggle.addEventListener('click', async () => {
    toggle.disabled = true;
    if (await act(on ? A.searchOff : A.searchOn, { id: s._id }, on ? 'Desactivada.' : 'Activada: busca ahora y luego una vez al día.')) setTimeout(again, on ? 0 : 3000);
    toggle.disabled = false;
  });
  const tags = C.osmTags(s.osm_tags);
  return el('li', { class: 've-row ve-row--search' }, [
    el('div', { class: 've-row__main' }, [
      el('span', { class: 've-row__title' }, `${s.vertical || 'Sin vertical'} · ${s.area || '—'}`),
      el('span', { class: 'oc-small oc-muted' }, [s.source === 'google_places' ? 'Google Places' : `OpenStreetMap${tags.length ? ` · ${tags.map((t) => t.join('=')).join(', ')}` : ' · sin etiquetas'}`]),
      s.last_note ? el('span', { class: 'oc-help' }, s.last_note) : null,
    ]),
    el('span', { class: 'oc-small oc-muted' }, s.last_run_at ? `Última: ${stamp(s.last_run_at)}` : 'Nunca'),
    el('span', { class: 'oc-value' }, s.last_run_at ? `${fmt.number(s.last_found || 0)} / ${fmt.number(s.last_new || 0)} nuevos` : '—'),
    router.link(`/prospectos`, `${fmt.number(s.prospects || 0)} prospectos`, { class: 'oc-small' }),
    badge(on ? 'active' : 'off', on ? 'good' : ''),
    el('div', { class: 'oc-row' }, [toggle, el('button', { class: 'oc-btn oc-btn--sm oc-btn--ghost', type: 'button', onClick: () => edit(s, vs, again) }, 'Editar')]),
  ]);
}

function edit(s, vs, again) {
  const vertical = select(vs.map((v) => [v._id, v.name]), s.vertical_id || (vs[0] && vs[0]._id));
  const area = input(s.area || '', { required: true, maxlength: '120', placeholder: 'Barcelona, Girona, España…' });
  const source = select(SOURCES, s.source || 'osm');
  formDialog(s._id ? 'Editar la búsqueda' : 'Nueva búsqueda', [
    field('Vertical', vertical, 'Sus etiquetas de OpenStreetMap deciden qué se busca en el mapa.'),
    field('Zona', area, 'Una ciudad, una provincia o un país, como lo escribirías en un mapa.'),
    field('Dónde buscar', source),
  ], async () => {
    if (!area.value.trim()) return false;
    const data = { vertical_id: Number(vertical.value), area: area.value.trim(), source: source.value };
    const ok = await act(s._id ? A.editSearch : A.addSearch, s._id ? Object.assign({ id: s._id }, data) : Object.assign(data, { active: 0 }), s._id ? 'Guardada.' : 'Añadida. Actívala cuando quieras que empiece.');
    if (ok) again();
    return ok;
  });
}
