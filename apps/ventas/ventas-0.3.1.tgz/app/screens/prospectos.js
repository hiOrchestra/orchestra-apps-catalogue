// Prospectos: the pipeline by stage. "Qué pasa ahora" on top (signals read,
// who decides, what waits for approval), a tab per stage with how many are in
// it, a filter by vertical, and each prospect in a row with its signals, its
// one state (who has it now) and what comes next; the row opens its page.
import { C, T, V, A, act, counts, field, formDialog, head, input, nextStrip, select, signalChips, stateBadge, verticals, ago } from '../data.js';

const { el, fmt, router } = Orch;
const KEY = 've.prospectos.vertical';
const PAGE = 200;

export function render(params = {}) {
  const stage = params.stage && C.STAGE_LABEL[params.stage] ? params.stage : '';
  Orch.load('view', async () => {
    let vertical = '';
    try { vertical = localStorage.getItem(KEY) || ''; } catch { /* no storage */ }
    const vs = await verticals();
    if (vertical && !vs.some((v) => String(v._id) === vertical)) vertical = '';
    const filter = Object.assign({}, stage ? { stage } : {}, vertical ? { vertical_id: Number(vertical) } : {});
    const [list, groups, c] = await Promise.all([
      Orch.db.view(V.prospects, { filter, sort: stage ? 'updated_at:desc' : 'created_at:desc', limit: PAGE, count: true }),
      Orch.db.count(T.prospects, { filter: vertical ? { vertical_id: Number(vertical) } : {}, group: 'stage' }),
      counts(),
    ]);
    const n = Object.fromEntries(((groups && groups.groups) || []).map((g) => [g.value, g.count]));
    const all = Object.values(n).reduce((a, b) => a + b, 0);
    const pick = select([['', 'Todas las verticales'], ...vs.map((v) => [v._id, v.name])], vertical, { 'aria-label': 'Vertical' });
    pick.addEventListener('change', () => { try { localStorage.setItem(KEY, pick.value); } catch { /* no storage */ } render(params); });
    const add = el('button', { class: 'oc-btn', type: 'button', onClick: () => addProspect(vs, () => render(params)) }, 'Añadir prospecto');
    const rows = list.rows || [];
    return el('div', { class: 'oc-stack oc-stack--loose' }, [
      head('Prospectos', 'Cada negocio que encontraron las búsquedas, por etapa: qué señales tiene su web, si encaja y qué toca ahora.', [pick, add]),
      nextStrip(c),
      el('nav', { class: 'oc-tabs ve-tabs', 'aria-label': 'Etapas' }, [
        router.link('/prospectos', ['Todos', el('span', { class: 'oc-count' }, fmt.number(all))], { class: 'oc-tab', 'aria-current': stage ? null : 'page' }),
        ...C.STAGES.map(([k, label]) => router.link(`/prospectos/${k}`, [label, n[k] ? el('span', { class: 'oc-count' }, fmt.number(n[k])) : null],
          { class: 'oc-tab', 'aria-current': k === stage ? 'page' : null })),
      ]),
      el('section', { class: 'oc-card oc-card--pad0' }, rows.length ? [
        el('ul', { class: 've-rows' }, rows.map(row)),
        list.total > rows.length ? el('p', { class: 've-none oc-muted' }, `Se muestran los ${rows.length} más recientes de ${fmt.number(list.total)}.`) : null,
      ] : [el('p', { class: 've-none oc-muted' }, stage ? `No hay prospectos en ${C.STAGE_LABEL[stage].toLowerCase()}.` : 'Todavía no hay prospectos: activa una búsqueda en Búsquedas.')]),
    ]);
  });
}

function row(p) {
  return el('li', { class: 've-row ve-row--prospect' }, [
    el('div', { class: 've-row__main' }, [
      router.link(`/prospecto/${p._id}`, p.name, { class: 've-row__title' }),
      el('span', { class: 'oc-small oc-muted' }, [p.vertical || 'Sin vertical', p.city ? ` · ${p.city}` : '', p.website ? ` · ${C.domainOf(p.website)}` : ' · sin web']),
      p.next_step ? el('span', { class: 'oc-help' }, `Siguiente: ${p.next_step}`) : p.fit_reason ? el('span', { class: 'oc-help' }, p.fit_reason) : null,
    ]),
    p.website ? signalChips(p.signals, p.signals_checked_at) : el('span', { class: 'oc-small oc-muted' }, 'Sin web: nada que leer'),
    stateBadge(p),
    el('span', { class: 'oc-small oc-muted ve-when' }, ago(p.updated_at)),
  ]);
}

function addProspect(vs, again) {
  const name = input('', { required: true, maxlength: '160' });
  const website = input('', { placeholder: 'https://…', maxlength: '300' });
  const phone = input('', { maxlength: '40' });
  const email = input('', { type: 'email', maxlength: '160' });
  const city = input('', { maxlength: '80' });
  const vertical = select([['', '—'], ...vs.map((v) => [v._id, v.name])], vs.length === 1 ? vs[0]._id : '');
  formDialog('Añadir un prospecto', [field('Nombre', name), field('Web', website, 'Si tiene web, Ventas lee sus señales en unos minutos.'), field('Teléfono', phone), field('Correo', email), field('Ciudad', city), field('Vertical', vertical)], async () => {
    if (!name.value.trim()) return false;
    const ok = await act(A.addProspect, {
      name: name.value.trim(), website: C.siteUrl(website.value) || null, phone: phone.value.trim() || null,
      email: C.isEmail(email.value) ? C.normEmail(email.value) : null, city: city.value.trim() || null, vertical_id: vertical.value ? Number(vertical.value) : null,
    }, 'Añadido.');
    if (ok) again();
    return ok;
  }, 'Añadir');
}
