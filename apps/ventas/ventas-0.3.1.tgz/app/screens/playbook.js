// Playbook: who to look for and what to say. Verticals (the kind of business,
// who buys, the signals that say they need you, the OpenStreetMap tags that
// find them), use cases (the problem and what the agent does about it, with
// its proof), and pitches (a vertical × a use case: the angle, the opening,
// the case to cite, the offer). What is still a guess says "(hipótesis)" and
// starts as Borrador until you make it yours.
import { C, T, V, A, act, area, badge, field, formDialog, head, input, select, settings } from '../data.js';

const { el } = Orch;

const VERTICAL = [
  ['name', 'Nombre', 'line'], ['buyer', 'Quién compra', 'text'], ['signals', 'Señales de que te necesita', 'text'],
  ['where_to_find', 'Dónde encontrarlos', 'text'], ['pains', 'Qué les duele', 'text'], ['objections', 'Objeciones', 'text'],
  ['osm_tags', 'Etiquetas de OpenStreetMap', 'line', 'Las que encuentran estos negocios en el mapa, separadas por comas: office=estate_agent'],
];
const USE_CASE = [
  ['name', 'Nombre', 'line'], ['key', 'Clave', 'line', 'Corta, sin espacios: leads-anuncios'], ['problem', 'El problema', 'text'],
  ['what_agent_does', 'Qué hace el agente', 'text'], ['proof', 'La prueba', 'text', 'Un caso con números. Sin caso, se dice que es una hipótesis.'],
];
const PITCH = [
  ['angle', 'El ángulo', 'text'], ['opening', 'La apertura', 'text'], ['case_to_cite', 'El caso que se cita', 'text'], ['offer', 'La oferta', 'text'],
];
const STATUS = [['draft', 'Borrador'], ['active', 'Activa']];

export function render() {
  Orch.load('view', async () => {
    const [vs, us, ps, s] = await Promise.all([
      Orch.db.list(T.verticals, { sort: '_id:asc', limit: 100 }),
      Orch.db.list(T.useCases, { sort: '_id:asc', limit: 100 }),
      Orch.db.view(V.pitches, { sort: '_id:asc', limit: 200 }),
      settings(true),
    ]);
    const again = () => render();
    const verticals = vs.rows || [];
    const cases = us.rows || [];
    return el('div', { class: 'oc-stack oc-stack--loose' }, [
      head('Playbook', 'A quién buscar y qué decirle. El agente escribe cada mensaje a partir de aquí; lo que aún es una suposición dice (hipótesis).', null),
      group('Verticales', 'El tipo de negocio: quién compra, qué señales dicen que te necesita y cómo encontrarlo en el mapa.',
        verticals.map((v) => item(v.name, v.status, [['Quién compra', v.buyer], ['Señales', v.signals], ['Qué les duele', v.pains], ['Objeciones', v.objections], ['En el mapa', v.osm_tags]],
          () => editor('Vertical', VERTICAL, v, A.editVertical, again))),
        el('button', { class: 'oc-btn oc-btn--sm', type: 'button', onClick: () => editor('Nueva vertical', VERTICAL, { status: 'draft' }, A.addVertical, again) }, 'Añadir vertical')),
      group('Casos de uso', 'El problema que resuelves y qué hace el agente, con su prueba.',
        cases.map((u) => item(u.name, u.status, [['Clave', u.key], ['El problema', u.problem], ['Qué hace el agente', u.what_agent_does], ['La prueba', u.proof]],
          () => editor('Caso de uso', USE_CASE, u, A.editUseCase, again))),
        el('button', { class: 'oc-btn oc-btn--sm', type: 'button', onClick: () => editor('Nuevo caso de uso', USE_CASE, { status: 'draft' }, A.addUseCase, again) }, 'Añadir caso de uso')),
      group('Pitches', 'Una vertical con un caso de uso: el ángulo, cómo se abre, qué caso se cita y qué se ofrece. El agente usa el de la vertical del prospecto.',
        (ps.rows || []).map((p) => item(`${p.vertical || 'Sin vertical'} × ${p.use_case || 'sin caso'}`, p.status, [['El ángulo', p.angle], ['La apertura', p.opening], ['El caso', p.case_to_cite], ['La oferta', p.offer]],
          () => pitchEditor(p, verticals, cases, A.editPitch, again), teamSends(p, s, again))),
        el('button', { class: 'oc-btn oc-btn--sm', type: 'button', disabled: !verticals.length || !cases.length, onClick: () => pitchEditor({ status: 'draft' }, verticals, cases, A.addPitch, again) }, 'Añadir pitch')),
    ]);
  });
}

function group(title, help, items, add) {
  return el('section', { class: 'oc-stack' }, [
    el('div', { class: 've-panel__head ve-panel__head--flush' }, [el('div', { class: 'oc-stack oc-stack--tight' }, [el('h2', { class: 'oc-h2' }, title), el('p', { class: 'oc-help' }, help)]), add]),
    items.length ? el('div', { class: 've-cards' }, items) : el('p', { class: 'oc-muted' }, 'Nada todavía.'),
  ]);
}

/**
 * Who sends this pitch's first messages: the person (each one approved) or the
 * team on its own, under the rule (C.teamRule). Only a person changes it.
 */
function teamSends(p, s, again) {
  const on = Number(p.team_sends) === 1;
  const b = el('button', { class: `oc-btn oc-btn--sm${on ? '' : ' oc-btn--ghost'}`, type: 'button' }, on ? 'Volver a aprobarlos yo' : 'Que el equipo los envíe solo');
  b.addEventListener('click', async () => {
    b.disabled = true;
    if (await act(on ? A.stopTeam : A.allowTeam, { id: p._id }, on ? 'Hecho: vuelves a aprobar cada mensaje de este pitch.' : 'Hecho: el equipo envía solo los primeros mensajes de este pitch.')) again();
    b.disabled = false;
  });
  return el('div', { class: 'oc-stack oc-stack--tight ve-team' }, [
    el('p', { class: 'oc-eyebrow' }, on ? `El equipo envía solo${Number(p.team_sent) ? ` · ${p.team_sent} enviados así` : ''}` : `Los apruebas tú${Number(p.unchanged) ? ` · ${p.unchanged} aprobados sin cambios` : ''}`),
    el('p', { class: 'oc-help' }, on ? C.teamRule(p, s) : 'Cada primer mensaje de este pitch espera tu aprobación.'),
    el('div', { class: 'oc-row' }, b),
  ]);
}

function item(title, status, pairs, onEdit, extra) {
  return el('article', { class: 'oc-card oc-stack ve-play' }, [
    el('div', { class: 'oc-row oc-row--between' }, [el('h3', { class: 've-play__title' }, title), badge(status || 'draft')]),
    el('dl', { class: 've-facts ve-facts--stack' }, pairs.filter(([, v]) => v).flatMap(([k, v]) => [el('dt', k), el('dd', { class: /^\(hipótesis\)/.test(v) ? 've-guess' : null }, v)])),
    extra || null,
    el('div', { class: 'oc-row' }, el('button', { class: 'oc-btn oc-btn--sm oc-btn--ghost', type: 'button', onClick: onEdit }, 'Editar')),
  ]);
}

function controls(spec, row) {
  return spec.map(([k, label, kind, help]) => {
    const c = kind === 'line' ? input(row[k] || '', { maxlength: '200' }) : area(row[k] || '', 3, { maxlength: '2000' });
    return { k, c, f: field(label, c, help) };
  });
}

function editor(title, spec, row, action, again) {
  const cs = controls(spec, row);
  const status = select(STATUS, row.status || 'draft');
  formDialog(title, [...cs.map((x) => x.f), field('Estado', status, 'Borrador mientras sea una suposición; Activa cuando sea tuya.')], async () => {
    const data = Object.fromEntries(cs.map(({ k, c }) => [k, c.value.trim() || null]));
    if (!data.name) { Orch.toast('Le falta el nombre.', { error: true }); return false; }
    if (data.osm_tags !== undefined && data.osm_tags && C.osmTags(data.osm_tags).bad.length) { Orch.toast(`No entiendo estas etiquetas: ${C.osmTags(data.osm_tags).bad.join(', ')}`, { error: true }); return false; }
    const ok = await act(action, Object.assign(row._id ? { id: row._id } : {}, data, { status: status.value }), 'Guardado.');
    if (ok) again();
    return ok;
  });
}

function pitchEditor(row, verticals, cases, action, again) {
  const v = select(verticals.map((x) => [x._id, x.name]), row.vertical_id);
  const u = select(cases.map((x) => [x._id, x.name]), row.use_case_id);
  const cs = controls(PITCH, row);
  const status = select(STATUS, row.status || 'draft');
  formDialog(row._id ? 'Pitch' : 'Nuevo pitch', [field('Vertical', v), field('Caso de uso', u), ...cs.map((x) => x.f), field('Estado', status)], async () => {
    const data = Object.fromEntries(cs.map(({ k, c }) => [k, c.value.trim() || null]));
    const ok = await act(action, Object.assign(row._id ? { id: row._id } : {}, data, { vertical_id: Number(v.value), use_case_id: Number(u.value), status: status.value }), 'Guardado.');
    if (ok) again();
    return ok;
  });
}
