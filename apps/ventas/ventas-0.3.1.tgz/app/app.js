// The router and the bar. Hoy is home: the messages waiting for your OK, the
// replies, and the next steps due. Prospectos is the pipeline by stage, each
// prospect on its own page; Playbook is who to look for and what to say;
// Búsquedas is where prospects come from.
import { render as hoy } from './screens/hoy.js';
import { render as prospectos } from './screens/prospectos.js';
import { render as prospecto } from './screens/prospecto.js';
import { render as playbook } from './screens/playbook.js';
import { render as busquedas } from './screens/busquedas.js';

const { el, router } = Orch;

router.define({
  '/': hoy,
  '/prospectos': prospectos,
  '/prospectos/:stage': prospectos,
  '/prospecto/:id': prospecto,
  '/playbook': playbook,
  '/busquedas': busquedas,
}, () => Orch.mount('view', el('div', { class: 'oc-state' }, [
  el('p', 'Aquí no hay ninguna pantalla.'), router.link('/', 'Ir a Hoy'),
]))).start();

Orch.mount('nav', [
  router.link('/', 'Hoy', { class: 'oc-tab' }),
  router.link('/prospectos', 'Prospectos', { class: 'oc-tab' }),
  router.link('/playbook', 'Playbook', { class: 'oc-tab' }),
  router.link('/busquedas', 'Búsquedas', { class: 'oc-tab' }),
]);
