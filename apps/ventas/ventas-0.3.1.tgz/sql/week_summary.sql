SELECT 1 AS _id,
  (SELECT COUNT(*) FROM ve_messages m WHERE m._deleted = 0 AND m.status = 'enviado' AND date(m.sent_at) = date('now')) AS sent_today,
  (SELECT COUNT(*) FROM ve_messages m WHERE m._deleted = 0 AND m.status = 'enviado' AND date(m.sent_at) >= date('now', '-6 days')) AS sent_week,
  (SELECT COUNT(*) FROM ve_messages m WHERE m._deleted = 0 AND m.status = 'enviado' AND m.approved_as = 'equipo' AND date(m.sent_at) >= date('now', '-6 days')) AS team_sent_week,
  (SELECT COUNT(*) FROM ve_prospects p WHERE p._deleted = 0 AND date(p._created_at) >= date('now', '-6 days')) AS found_week,
  (SELECT COUNT(*) FROM ve_activity a WHERE a._deleted = 0 AND a.kind = 'encaja' AND date(COALESCE(a.at, a._created_at)) >= date('now', '-6 days')) AS fit_week,
  (SELECT COUNT(*) FROM ve_activity a WHERE a._deleted = 0 AND a.kind = 'respuesta' AND date(COALESCE(a.at, a._created_at)) >= date('now', '-6 days')) AS replies_week,
  (SELECT COUNT(*) FROM ve_prospects p WHERE p._deleted = 0 AND p.stage = 'respondio') AS replied_open,
  (SELECT COUNT(*) FROM ve_prospects p WHERE p._deleted = 0 AND p.stage = 'llamada') AS calls
