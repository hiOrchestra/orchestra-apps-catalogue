SELECT s._id AS _id, s.vertical_id AS vertical_id, v.name AS vertical, v.osm_tags AS osm_tags, s.area AS area, s.source AS source,
  s.active AS active, s.last_run_at AS last_run_at, s.last_found AS last_found, s.last_new AS last_new, s.last_note AS last_note,
  (SELECT COUNT(*) FROM ve_prospects p WHERE p._deleted = 0 AND p.search_id = s._id) AS prospects
FROM ve_searches s
LEFT JOIN ve_verticals v ON v._id = s.vertical_id AND v._deleted = 0
WHERE s._deleted = 0
