SELECT a._id AS _id, a.prospect_id AS prospect_id, p.name AS prospect, v.name AS vertical, a.kind AS kind, a.note AS note,
  COALESCE(a.at, a._created_at) AS at, a.author AS author
FROM ve_activity a
LEFT JOIN ve_prospects p ON p._id = a.prospect_id AND p._deleted = 0
LEFT JOIN ve_verticals v ON v._id = p.vertical_id AND v._deleted = 0
WHERE a._deleted = 0
