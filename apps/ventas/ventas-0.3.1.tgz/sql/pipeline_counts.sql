SELECT 1 AS _id,
  COALESCE(SUM(CASE WHEN COALESCE(p.website, '') <> '' AND COALESCE(p.stage, 'nuevo') NOT IN ('descartado', 'crm') THEN 1 ELSE 0 END), 0) AS with_web,
  COALESCE(SUM(CASE WHEN COALESCE(p.website, '') <> '' AND COALESCE(p.stage, 'nuevo') NOT IN ('descartado', 'crm') AND p.signals_checked_at IS NOT NULL THEN 1 ELSE 0 END), 0) AS read_web,
  COALESCE(SUM(CASE WHEN COALESCE(p.stage, 'nuevo') = 'nuevo' AND COALESCE(p.fit, 'pending') = 'pending' THEN 1 ELSE 0 END), 0) AS pending,
  COALESCE(SUM(CASE WHEN COALESCE(p.stage, 'nuevo') = 'nuevo' AND COALESCE(p.fit, 'pending') = 'pending' AND COALESCE(p.website, '') <> '' AND p.signals_checked_at IS NOT NULL THEN 1 ELSE 0 END), 0) AS judgeable,
  COALESCE(SUM(CASE WHEN COALESCE(p.stage, 'nuevo') = 'nuevo' AND COALESCE(p.fit, 'pending') = 'pending' AND COALESCE(p.website, '') = '' THEN 1 ELSE 0 END), 0) AS no_web,
  (SELECT COUNT(*) FROM ve_messages m WHERE m._deleted = 0 AND m.status = 'borrador') AS drafts
FROM ve_prospects p
WHERE p._deleted = 0
