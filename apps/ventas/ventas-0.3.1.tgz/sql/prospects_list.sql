SELECT p._id AS _id, p.name AS name, p.website AS website, p.phone AS phone, p.email AS email, p.address AS address, p.city AS city,
  p.vertical_id AS vertical_id, v.name AS vertical, p.source AS source, p.fit AS fit, p.fit_reason AS fit_reason, p.stage AS stage,
  p.contact_name AS contact_name, p.contact_role AS contact_role, p.contact_email AS contact_email,
  p.signals AS signals, p.signals_checked_at AS signals_checked_at, p.next_step AS next_step, p.next_step_at AS next_step_at,
  p._created_at AS created_at, p._updated_at AS updated_at,
  CASE WHEN p.next_step_at IS NULL OR p.next_step_at = '' THEN 'none'
       WHEN date(p.next_step_at) < date('now') THEN 'overdue'
       WHEN date(p.next_step_at) = date('now') THEN 'today'
       ELSE 'later' END AS due_state,
  (SELECT m.status FROM ve_messages m WHERE m._deleted = 0 AND m.prospect_id = p._id ORDER BY m._id DESC LIMIT 1) AS last_message
FROM ve_prospects p
LEFT JOIN ve_verticals v ON v._id = p.vertical_id AND v._deleted = 0
WHERE p._deleted = 0
