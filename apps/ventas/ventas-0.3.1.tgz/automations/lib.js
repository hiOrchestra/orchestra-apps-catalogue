'use strict';
/**
 * What every Ventas script shares (the CRM's lib.js, the SDK the platform does
 * not have yet): reading the company database, writing to it, one run at a
 * time, and the one JSON line a step leaves.
 *
 * Reads go to the SQLite file directly, read-only and parameterised. Every
 * write goes through `orch-database batch`, the platform's own writer: one
 * transaction, and a `when` precondition checked inside the UPDATE, so
 * "this message is mine now" is atomic.
 *
 * Ventas installs once for the company (ORCHESTRA_COMPANY=1): the company
 * database, orch-database without --project.
 *
 * Locally (VE_LOCAL=1) the same batch runs against VE_DB with the same
 * semantics, so every script is tested off the instance.
 */
const { DatabaseSync } = require('node:sqlite');
const { execFileSync } = require('child_process');
const fs = require('fs');
const os = require('os');
const path = require('path');
const C = require('./vecore');

const STATE = process.env.OPENCLAW_STATE_DIR || '/home/node/.openclaw';
const DB_PATH = process.env.VE_DB || path.join(STATE, 'orchestra', 'data', 'company.db');
const LOCAL = process.env.VE_LOCAL === '1';

// ── reading ──────────────────────────────────────────────────────────────
let reader = null;
function db() {
  if (!reader) {
    reader = new DatabaseSync(DB_PATH, { readOnly: true });
    reader.exec('PRAGMA busy_timeout = 5000');
  }
  return reader;
}
/** A fresh reader: after a write in this process, the old one may hold an older snapshot. */
function reread() { if (reader) { try { reader.close(); } catch { /* closed */ } } reader = null; }
const all = (sql, ...params) => db().prepare(sql).all(...params);
const one = (sql, ...params) => db().prepare(sql).get(...params);

function settings() {
  const s = one('SELECT * FROM ve_settings WHERE _deleted = 0 ORDER BY _id LIMIT 1');
  if (!s) throw new Error('Ventas has no settings row: it is not installed');
  return s;
}

function jsonOf(text, fallback) {
  if (text === null || text === undefined || text === '') return fallback;
  if (typeof text === 'object') return text;
  try { return JSON.parse(text); } catch { return fallback; }
}

// ── writing ──────────────────────────────────────────────────────────────
/** One transaction per chunk (an argv over 128 KB is refused by the kernel), all or nothing; the results in order. */
function write(ops) {
  const chunks = [];
  let cur = [];
  let size = 0;
  for (const op of ops) {
    const n = JSON.stringify(op).length;
    if (cur.length && size + n > 90000) { chunks.push(cur); cur = []; size = 0; }
    cur.push(op);
    size += n;
  }
  if (cur.length) chunks.push(cur);
  const results = [];
  for (const chunk of chunks) results.push(...((LOCAL ? localBatch(chunk) : cliBatch(chunk)).results || []));
  reread();
  return results;
}

function cliBatch(ops) {
  let out;
  try {
    out = execFileSync('orch-database', ['batch', '--ops', JSON.stringify(ops)], { encoding: 'utf8', timeout: 60000, maxBuffer: 16 << 20 });
  } catch (e) {
    let j = null;
    try { j = JSON.parse(String(e.stdout || '')); } catch { /* not JSON */ }
    throw new Error((j && j.error) || String(e.stderr || e.message).trim().slice(0, 300));
  }
  const j = JSON.parse(out);
  if (!j.ok) throw new Error(j.error || 'the write failed');
  return j;
}

/** orch-database's run_batch, for local tests: same `when`, same all-or-none, same results. */
function localBatch(ops) {
  const w = new DatabaseSync(DB_PATH);
  w.exec('PRAGMA busy_timeout = 5000');
  const now = sqlNow();
  const results = [];
  w.exec('BEGIN IMMEDIATE');
  try {
    ops.forEach((op, i) => {
      const data = {};
      for (const [k, v] of Object.entries(op.data || {})) if (!k.startsWith('_')) data[k] = v;
      if (op.op === 'insert') {
        const cols = [...Object.keys(data), '_created_at', '_updated_at'];
        const r = w.prepare(`INSERT INTO "${op.table}" (${cols.map((c) => `"${c}"`).join(', ')}) VALUES (${cols.map(() => '?').join(', ')})`)
          .run(...Object.values(data), now, now);
        results.push({ op: 'insert', table: op.table, _id: Number(r.lastInsertRowid) });
      } else {
        const when = op.when || {};
        const r = w.prepare(`UPDATE "${op.table}" SET ${Object.keys(data).map((c) => `"${c}" = ?`).join(', ')}, _updated_at = ? `
          + `WHERE _id = ? AND _deleted = 0${Object.keys(when).map((c) => ` AND "${c}" IS ?`).join('')}`)
          .run(...Object.values(data), now, op.id, ...Object.values(when));
        if (!r.changes) throw new Error(`op ${i}: row ${op.id} changed meanwhile (precondition failed)`);
        results.push({ op: 'update', table: op.table, _id: op.id });
      }
    });
    w.exec('COMMIT');
  } catch (e) {
    w.exec('ROLLBACK');
    w.close();
    throw e;
  }
  w.close();
  return { ok: true, applied: results.length, results };
}

// ── one run at a time ────────────────────────────────────────────────────
const STALE_MS = 360000; // longer than a step may run (300 s): a file this old was left by a run that was killed

/**
 * A lock file, so two runs of the same job (the schedule and a button) do not
 * work the same rows at once. It saves work; what keeps a message from going
 * out twice is the `when` on its claim.
 *   lock('enviar') -> { release() }, or null when another run holds it
 */
function lock(name) {
  let who;
  try { who = os.userInfo().username; } catch { who = String(process.getuid ? process.getuid() : 'node'); }
  const file = path.join(process.env.VE_LOCK_DIR || os.tmpdir(), `orchestra-ventas-${who}-${name}.lock`);
  const held = { file, release() { try { fs.unlinkSync(file); } catch { /* already gone */ } } };
  for (let i = 0; i < 2; i += 1) {
    try {
      fs.writeFileSync(file, String(process.pid), { flag: 'wx' });
      return held;
    } catch (e) {
      if (e.code !== 'EEXIST') return { file: null, release() {} };
      let age;
      try { age = Date.now() - fs.statSync(file).mtimeMs; } catch { continue; }
      if (age < STALE_MS) return null;
      try { fs.unlinkSync(file); } catch { /* another run took it over first */ }
    }
  }
  return null;
}

// ── time ─────────────────────────────────────────────────────────────────
/** 'YYYY-MM-DD HH:MM:SS' in UTC: the format orch-database stamps rows with. VE_NOW pins the clock in tests. */
const nowDate = () => (process.env.VE_NOW ? new Date(process.env.VE_NOW) : new Date());
const sqlNow = (d = nowDate()) => d.toISOString().slice(0, 19).replace('T', ' ');
/** The same clock as SQLite should see it ('now' unless the tests pin it). */
const sqlClock = () => (process.env.VE_NOW ? sqlNow() : 'now');

// ── the instance ─────────────────────────────────────────────────────────
/** An app's steps run as the platform: HOOKS_TOKEN is in their environment. */
function identityHeaders() {
  const id = process.env.ORCHESTRA_AGENT_ID;
  const token = process.env.ORCHESTRA_AGENT_TOKEN;
  if (id && token) return { 'x-orchestra-agent': id, 'x-orchestra-agent-token': token };
  const secret = process.env.HOOKS_TOKEN || process.env.OPENCLAW_GATEWAY_TOKEN || '';
  return secret ? { 'x-orchestra-secret': secret } : {};
}

/** The one JSON line a workflow step leaves as its output. */
function done(result) {
  process.stdout.write(`${JSON.stringify(result)}\n`);
  return result;
}

const clean = (v, n) => String(v === null || v === undefined ? '' : v).replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, '').trim().slice(0, n);
const sleep = (ms) => new Promise((r) => { setTimeout(r, ms); });

module.exports = { C, DB_PATH, LOCAL, all, one, settings, jsonOf, write, reread, lock, sqlNow, sqlClock, nowDate, identityHeaders, done, clean, sleep };
