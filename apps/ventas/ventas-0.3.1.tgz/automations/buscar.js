'use strict';
/**
 * Ventas · Buscar — the businesses of a vertical in an area, as prospects.
 *
 * For one active search that is due (never run, or not in the last 20 hours;
 * with --now, the active ones in turn, up to three): the area is found by
 * name in OpenStreetMap (Nominatim, once: its area id is kept on the search),
 * then one Overpass query asks for every place with the vertical's tags
 * there. When the search's source is google_places and GOOGLE_PLACES_KEY is
 * set, Places API (New) Text Search is asked instead ("<vertical> en <area>").
 *
 * What comes back is matched against the prospects already there — the same
 * place, else the same website domain, else the same phone, is the same
 * business: its empty fields are filled, nothing else changes — and the new
 * ones are added as Nuevo, fit pending. No agent turn; nobody is contacted.
 *
 * Usage policy of the free OSM services: one request at a time, our name in
 * the User-Agent, modest timeouts, and a busy answer (429, 504) is left for
 * the next run, never retried in a loop.
 *   node buscar.js [--auto|--now]
 */
const L = require('./lib');
const N = require('./net');

const { C } = L;
const NOMINATIM = process.env.VE_NOMINATIM_URL || 'https://nominatim.openstreetmap.org/search';
const OVERPASS = process.env.VE_OVERPASS_URL || 'https://overpass-api.de/api/interpreter';
const PLACES = 'https://places.googleapis.com/v1/places:searchText';
const MAX_NEW = 500;

async function run(mode = '--auto') {
  const held = L.lock('buscar');
  if (!held) return { ok: true, mode, skipped: 'Otra búsqueda está en marcha' };
  try {
    L.settings();
    const due = L.all(`SELECT * FROM ve_searches WHERE _deleted = 0 AND active = 1
      ${mode === '--now' ? '' : `AND (last_run_at IS NULL OR datetime(last_run_at) <= datetime('${L.sqlClock()}', '-20 hours'))`}
      ORDER BY (last_run_at IS NOT NULL), datetime(last_run_at), _id LIMIT ${mode === '--now' ? 3 : 1}`);
    if (!due.length) return { ok: true, mode, skipped: 'Ninguna búsqueda activa toca ahora' };
    const out = { ok: true, mode, searches: [] };
    for (const [i, s] of due.entries()) {
      if (i) await L.sleep(Number(process.env.VE_PAUSE_MS || 5000)); // one query at a time, and a breath between
      out.searches.push(await one(s));
    }
    return out;
  } finally {
    held.release();
  }
}

async function one(s) {
  const v = s.vertical_id ? L.one('SELECT * FROM ve_verticals WHERE _id = ? AND _deleted = 0', s.vertical_id) : null;
  const say = (note, extra = {}, ran = true) => {
    L.write([{ op: 'update', table: 've_searches', id: s._id, data: Object.assign(ran ? { last_run_at: L.sqlNow() } : {}, { last_note: note.slice(0, 400) }, extra) }]);
    return Object.assign({ id: s._id, note }, extra);
  };
  if (!v) return say('La búsqueda no tiene vertical (o se borró): elige una.');
  const area = String(s.area || '').trim();
  if (!area) return say('La búsqueda no dice dónde: escribe una zona (Barcelona, España…).');

  let found;
  let via = 'osm';
  let areaRef = s.area_ref || null;
  try {
    if (s.source === 'google_places' && process.env.GOOGLE_PLACES_KEY) {
      via = 'google_places';
      found = await places(`${v.name} en ${area}`, { vertical_id: v._id, area });
    } else {
      const tags = C.osmTags(v.osm_tags);
      if (!tags.length) return say(`La vertical "${v.name}" no tiene etiquetas de OpenStreetMap (por ejemplo office=estate_agent): sin ellas no se puede buscar en el mapa.`);
      if (!areaRef) {
        areaRef = await areaOf(area);
        if (!areaRef) return say(`No encuentro "${area}" como zona en OpenStreetMap: prueba con el nombre de la ciudad, la provincia o el país.`);
        await L.sleep(Number(process.env.VE_PAUSE_MS || 1500));
      }
      found = await osm(areaRef, tags, { vertical_id: v._id, area });
    }
  } catch (e) {
    const busy = e.status === 429 || e.status === 504 || e.timeout;
    const who = via === 'google_places' ? 'Google Places' : 'OpenStreetMap';
    // Busy: tried again on the next hourly check, never in a loop here.
    return say(busy ? `${who} está ocupado o no contestó (${e.message}); se vuelve a intentar en la próxima hora.` : `${who} no contestó bien: ${e.message}`, areaRef ? { area_ref: String(areaRef) } : {}, !busy);
  }

  found = found.filter(Boolean); // a place with no name is no prospect
  const existing = L.all('SELECT _id, website, phone, email, address, city, source_ref FROM ve_prospects WHERE _deleted = 0');
  const p = C.plan(found, existing);
  const fresh = p.inserts.slice(0, MAX_NEW);
  const ops = [
    ...fresh.map((x) => ({ op: 'insert', table: 've_prospects', data: Object.assign({}, x, { search_id: s._id, fit: 'pending', stage: 'nuevo' }) })),
    ...p.updates.map((u) => ({ op: 'update', table: 've_prospects', id: u.id, data: u.data })),
  ];
  if (ops.length) L.write(ops);
  const fallback = s.source === 'google_places' && via === 'osm' ? ' Sin GOOGLE_PLACES_KEY, se buscó en OpenStreetMap.' : '';
  const note = `${found.length} encontrados, ${fresh.length} nuevos${p.updates.length ? `, ${p.updates.length} completados` : ''}${p.inserts.length > MAX_NEW ? ` (como mucho ${MAX_NEW} nuevos por vez: el resto, la próxima)` : ''}.${fallback}`;
  return say(note, Object.assign({ last_found: found.length, last_new: fresh.length }, areaRef ? { area_ref: String(areaRef) } : {}));
}

/** The Overpass area id of a place name, from Nominatim (the first result that is an area). */
async function areaOf(name) {
  const url = `${NOMINATIM}?${new URLSearchParams({ q: name, format: 'jsonv2', limit: '5', 'accept-language': 'es' })}`;
  const list = await N.json(url, { timeoutMs: 20000 });
  for (const r of Array.isArray(list) ? list : []) {
    const id = C.areaId(r.osm_type, r.osm_id);
    if (id) return id;
  }
  return null;
}

async function osm(area, tags, ctx) {
  const q = C.overpassQuery(area, tags, { max: 2000, timeout: 90 });
  const j = await N.json(OVERPASS, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: `data=${encodeURIComponent(q)}`, timeoutMs: 100000, maxBytes: 20000000 });
  return (j.elements || []).map((e) => C.fromOsm(e, ctx));
}

async function places(text, ctx) {
  const out = [];
  let token = null;
  for (let page = 0; page < 3; page += 1) {
    if (page) await L.sleep(Number(process.env.VE_PAUSE_MS || 2000));
    const body = { textQuery: text, languageCode: 'es', regionCode: 'ES', pageSize: 20 };
    if (token) body.pageToken = token;
    const j = await N.json(PLACES, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Goog-Api-Key': process.env.GOOGLE_PLACES_KEY,
        'X-Goog-FieldMask': 'places.id,places.displayName,places.formattedAddress,places.websiteUri,places.nationalPhoneNumber,places.internationalPhoneNumber,places.addressComponents,nextPageToken',
      },
      body: JSON.stringify(body),
      timeoutMs: 20000,
    });
    out.push(...(j.places || []).map((p) => C.fromPlace(p, ctx)));
    token = j.nextPageToken || null;
    if (!token) break;
  }
  return out;
}

if (require.main === module) {
  const mode = process.argv.includes('--now') ? '--now' : '--auto';
  run(mode).then((r) => L.done(r)).catch((e) => { L.done({ ok: false, error: e.message }); process.exitCode = 1; });
}

module.exports = { run };
