SELECT m._id AS _id, m.prospect_id AS prospect_id, m.pitch_id AS pitch_id, m.kind AS kind, m.to_email AS to_email, m.subject AS subject,
  m.body AS body, m.status AS status, m.note AS note, m.error AS error, m.created_by AS created_by, m.approved_by AS approved_by,
  m.approved_at AS approved_at, m.approved_as AS approved_as, m.needs_person AS needs_person, m.sent_at AS sent_at, m._created_at AS created_at,
  COALESCE(m.channel, 'email') AS channel, m.review AS review, m.edited AS edited, m.body_original AS body_original,
  p.name AS prospect, p.stage AS stage, p.contact_name AS contact_name, p.fit_reason AS fit_reason, p.phone AS phone, p.website AS website,
  p.email AS prospect_email, p.email_source AS email_source, p.email_check AS email_check, p.unsubscribed_at AS unsubscribed_at,
  v.name AS vertical, pi.angle AS angle
FROM ve_messages m
LEFT JOIN ve_prospects p ON p._id = m.prospect_id AND p._deleted = 0
LEFT JOIN ve_verticals v ON v._id = p.vertical_id AND v._deleted = 0
LEFT JOIN ve_pitches pi ON pi._id = m.pitch_id AND pi._deleted = 0
WHERE m._deleted = 0
