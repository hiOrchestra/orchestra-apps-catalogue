'use strict';
/**
 * Every request Ventas makes to the open web, and nothing else: one at a time
 * (the scripts await each), with our name in the User-Agent, a timeout, and a
 * cap on what is read (a page bigger than that is cut, never read whole).
 *
 *   request(url, { method, headers, body, timeoutMs, maxBytes }) → { status, headers, text, url, cut }
 *   json(url, opts) → the parsed body (throws with the status when it is not 2xx)
 *
 *   mx(domain) → true (it receives mail) | false (no mail server: NXDOMAIN or no MX/A) | null (could not tell)
 *
 * VE_FAKE_NET (a JSON file { routes: [{ match, method?, status?, body, headers?, error? }] })
 * answers instead of the network: the first route whose `match` is part of the
 * URL; a body that is an object is sent as JSON. Every request is written to
 * VE_FAKE_NET_LOG, one JSON a line. The tests never reach the web.
 */
const fs = require('fs');

const UA = 'OrchestraVentas/0.1 (+https://hiorchestra.com/bots; prospecting, one request at a time)';
const FAKE = process.env.VE_FAKE_NET || '';

async function request(url, { method = 'GET', headers = {}, body, timeoutMs = 15000, maxBytes = 1500000 } = {}) {
  const h = { 'User-Agent': UA, 'Accept-Language': 'es,en;q=0.8', ...headers };
  if (FAKE) return fake(url, method, h, body, maxBytes);
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), timeoutMs);
  try {
    const res = await fetch(url, { method, headers: h, body, redirect: 'follow', signal: ctl.signal });
    const chunks = [];
    let size = 0;
    let cut = false;
    if (res.body) {
      for await (const chunk of res.body) {
        size += chunk.length;
        if (size > maxBytes) { chunks.push(chunk.slice(0, chunk.length - (size - maxBytes))); cut = true; break; }
        chunks.push(chunk);
      }
    }
    if (cut) { try { ctl.abort(); } catch { /* done */ } }
    return { status: res.status, headers: Object.fromEntries(res.headers), text: Buffer.concat(chunks.map((c) => Buffer.from(c))).toString('utf8'), url: res.url || url, cut };
  } catch (e) {
    if (e.name === 'AbortError') throw Object.assign(new Error(`no answer in ${Math.round(timeoutMs / 1000)} s`), { timeout: true });
    throw new Error(String((e.cause && e.cause.code) || e.message).slice(0, 200));
  } finally {
    clearTimeout(timer);
  }
}

async function json(url, opts = {}) {
  const r = await request(url, { ...opts, headers: { Accept: 'application/json', ...(opts.headers || {}) } });
  let j = null;
  try { j = JSON.parse(r.text); } catch { /* reported below */ }
  if (r.status < 200 || r.status >= 300) {
    const why = (j && ((j.error && (j.error.message || j.error)) || j.remark)) || r.text.slice(0, 200);
    throw Object.assign(new Error(`${r.status}: ${String(why).slice(0, 240)}`), { status: r.status });
  }
  if (j === null) throw new Error(`the answer is not JSON (${r.text.slice(0, 120)})`);
  return j;
}

/**
 * Whether a domain receives mail: its MX records, else an A record (mail
 * falls back to it). One lookup per domain per run. Offline (VE_FAKE_NET),
 * a domain with "nomx" in it does not receive mail and every other one does.
 */
const mxCache = new Map();
async function mx(domain, { timeoutMs = 6000 } = {}) {
  const d = String(domain || '').toLowerCase().trim();
  if (!d) return null;
  if (FAKE) return !/nomx/.test(d);
  if (mxCache.has(d)) return mxCache.get(d);
  const dns = require('dns').promises;
  const within = (p) => Promise.race([p, new Promise((_, ko) => setTimeout(() => ko(Object.assign(new Error('timeout'), { code: 'ETIMEOUT' })), timeoutMs))]);
  let ok = null;
  try {
    const recs = await within(dns.resolveMx(d));
    ok = recs.some((r) => r && r.exchange && r.exchange !== '.');
  } catch (e) {
    if (e.code === 'ENOTFOUND' || e.code === 'ENODATA') {
      try { ok = (await within(dns.resolve4(d))).length > 0; } catch (e2) { ok = e2.code === 'ENOTFOUND' || e2.code === 'ENODATA' ? false : null; }
    } else ok = null;
  }
  mxCache.set(d, ok);
  return ok;
}

function fake(url, method, headers, body, maxBytes) {
  if (process.env.VE_FAKE_NET_LOG) fs.appendFileSync(process.env.VE_FAKE_NET_LOG, `${JSON.stringify({ url, method, ua: headers['User-Agent'], body: body ? String(body).slice(0, 2000) : undefined, headers })}\n`);
  const routes = (JSON.parse(fs.readFileSync(FAKE, 'utf8')).routes) || [];
  const r = routes.find((x) => url.includes(x.match) && (!x.method || x.method === method));
  if (!r) return Promise.resolve({ status: 404, headers: {}, text: '', url, cut: false });
  if (r.error) return Promise.reject(Object.assign(new Error(r.error), { timeout: /answer/.test(r.error) }));
  const text = typeof r.body === 'string' ? r.body : JSON.stringify(r.body === undefined ? '' : r.body);
  return Promise.resolve({ status: r.status || 200, headers: r.headers || {}, text: text.slice(0, maxBytes), url, cut: text.length > maxBytes });
}

module.exports = { request, json, mx, UA };
