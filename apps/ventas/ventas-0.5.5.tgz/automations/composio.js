'use strict';
/**
 * The one call Ventas makes to Composio: send one plain-text email from the
 * Gmail connection chosen for it (GMAIL_SEND_EMAIL), the way the CRM sends.
 *
 * Scripts reach Composio through the instance (POST 127.0.0.1:3001
 * /api/composio/execute {toolSlug, arguments, account}); the platform key
 * never enters the container. Installed for the company, the connection
 * chosen in Orchestra comes as ORCHESTRA_ACCOUNT_GMAIL and wins over the name
 * kept in ve_settings.sender_account.
 *
 * VE_FAKE_COMPOSIO=1 writes every email "sent" to VE_FAKE_OUTBOX, one JSON a
 * line: the tests never reach Gmail. An address starting with fail@ is
 * refused, timeout@ never answers.
 */
const http = require('http');
const fs = require('fs');
const { identityHeaders } = require('./lib');

const FAKE = process.env.VE_FAKE_COMPOSIO === '1';

function execute(slug, args, { account, timeoutMs = 45000 } = {}) {
  account = process.env.ORCHESTRA_ACCOUNT_GMAIL || account || undefined;
  if (FAKE) return fake(slug, args, account);
  return new Promise((resolve, reject) => {
    const body = JSON.stringify(Object.assign({ toolSlug: slug, arguments: args }, account ? { account } : {}));
    const req = http.request({
      hostname: '127.0.0.1', port: Number(process.env.API_SERVER_PORT || 3001), path: '/api/composio/execute', method: 'POST', agent: false,
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body), ...identityHeaders() },
    }, (res) => {
      let b = '';
      res.on('data', (c) => { b += c; });
      res.on('end', () => {
        let j;
        try { j = JSON.parse(b); } catch { return reject(new Error(`Composio answered ${res.statusCode}: ${b.slice(0, 200)}`)); }
        if (j && j.success && j.data && j.data.successful !== false) return resolve(j.data.data !== undefined ? j.data.data : j.data);
        const why = (j && j.data && j.data.error) || (j && j.error && (j.error.message || j.error)) || `HTTP ${res.statusCode}`;
        return reject(new Error(String(why).slice(0, 300)));
      });
    });
    req.on('error', reject);
    req.setTimeout(timeoutMs, () => req.destroy(Object.assign(new Error(`Gmail did not answer in ${timeoutMs / 1000}s`), { timeout: true })));
    req.end(body);
  });
}

function valueAt(obj, key, depth = 0) {
  if (!obj || typeof obj !== 'object' || depth > 5) return undefined;
  if (obj[key] !== undefined && obj[key] !== null && typeof obj[key] !== 'object') return obj[key];
  for (const v of Object.values(obj)) {
    const found = valueAt(v, key, depth + 1);
    if (found !== undefined) return found;
  }
  return undefined;
}

/** One plain-text email from the connected account: { id, threadId }. */
async function gmailSend({ to, subject, body, account }) {
  const r = await execute('GMAIL_SEND_EMAIL', { user_id: 'me', recipient_email: to, subject, body, is_html: false }, { account });
  return { id: String(valueAt(r, 'id') || ''), threadId: String(valueAt(r, 'threadId') || '') };
}

/**
 * A follow-up as a reply in the first message's Gmail thread (GMAIL_REPLY_TO_THREAD):
 * it reads as the same conversation, which is what works for a second touch. { id, threadId }.
 */
async function gmailReply({ threadId, to, body, account }) {
  const r = await execute('GMAIL_REPLY_TO_THREAD', { user_id: 'me', thread_id: threadId, recipient_email: to, message_body: body, is_html: false }, { account });
  return { id: String(valueAt(r, 'id') || ''), threadId: String(valueAt(r, 'threadId') || threadId) };
}

let n = 0;
function fake(slug, args, account) {
  const to = String(args.recipient_email || '');
  if (slug === 'GMAIL_REPLY_TO_THREAD' && /^nothread@/i.test(to)) return Promise.reject(new Error('Requested entity was not found (thread)'));
  if (/^timeout@/i.test(to)) return Promise.reject(Object.assign(new Error('Gmail did not answer in 45s'), { timeout: true }));
  if (/^fail@/i.test(to)) return Promise.reject(new Error('Invalid To header'));
  n += 1;
  const id = `fake-${process.pid}-${n}`;
  if (process.env.VE_FAKE_OUTBOX) fs.appendFileSync(process.env.VE_FAKE_OUTBOX, `${JSON.stringify({ slug, account: account || null, ...args, id })}\n`);
  return Promise.resolve({ id, threadId: args.thread_id || `t-${id}` });
}

module.exports = { gmailSend, gmailReply };
