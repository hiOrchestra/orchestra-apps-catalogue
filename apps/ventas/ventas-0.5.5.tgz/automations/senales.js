'use strict';
/**
 * Ventas · Señales — what each prospect's website says about how it sells.
 *
 * For prospects with a website not looked at in 30 days (and not discarded or
 * in the CRM), one at a time: its robots.txt first (a site that asks robots
 * not to read its home page is not read), then the home page (a timeout, at
 * most 1.5 MB read). From the HTML it records: GoHighLevel, Meta's pixel,
 * Google Ads, a Google tag, a lead form, WhatsApp links, and the emails and
 * phones it shows (vecore.signals). With no address of the business's own
 * domain on the home page, it reads up to three pages the home page links to
 * where Spain's LSSI makes a business publish its email — the legal notice,
 * then contact and privacy (vecore.legalLinks) — and Cloudflare-hidden
 * addresses are read as people see them. An empty email or phone on the
 * prospect is filled from what the site shows, with the page it came from
 * (email_source) and whether its domain receives mail (email_check: propio,
 * gratuito, otro_dominio, or sin_mx); nothing else is changed. A prospect
 * read before these pages were (no email, signals without `pages`) is read
 * once more. With
 * META_AD_LIBRARY_TOKEN set, the Meta Ad Library is asked for active ads
 * under the business's name (best effort: a name match, said as such).
 *
 * No agent turn; nobody is contacted. Hourly while some wait.
 *   node senales.js [--auto|--now]
 */
const L = require('./lib');
const N = require('./net');

const { C } = L;
const PER_RUN = Number(process.env.VE_SIGNALS_PER_RUN || C.SIGNALS_PER_RUN);
const BUDGET_MS = Number(process.env.VE_SIGNALS_BUDGET_MS || 240000); // the step's timeout is 300 s
const ADS = 'https://graph.facebook.com/v21.0/ads_archive';
// Read before the legal pages were: no email found and nothing says those pages were looked at. Read once more.
const NO_EMAIL_YET = "COALESCE(email, '') = '' AND COALESCE(contact_email, '') = '' AND COALESCE(fit, 'pending') <> 'no' AND json_valid(signals) AND json_extract(signals, '$.pages') IS NULL AND json_extract(signals, '$.robots') IS NULL";

async function run(mode = '--auto') {
  const held = L.lock('senales');
  if (!held) return { ok: true, mode, skipped: 'Otra lectura de señales está en marcha' };
  const started = Date.now();
  try {
    L.settings();
    const list = L.all(`SELECT _id, name, website, email, phone FROM ve_prospects WHERE _deleted = 0
      AND COALESCE(website, '') <> '' AND COALESCE(stage, 'nuevo') NOT IN ('descartado', 'crm')
      AND (signals_checked_at IS NULL OR datetime(signals_checked_at) <= datetime('${L.sqlClock()}', '-30 days')
        OR (${NO_EMAIL_YET}))
      ORDER BY (signals_checked_at IS NOT NULL), _id LIMIT ${PER_RUN}`);
    if (!list.length) return { ok: true, mode, skipped: 'Ningún prospecto espera' };
    const out = { ok: true, mode, checked: [] };
    const robots = new Map();
    for (const [i, p] of list.entries()) {
      if (Date.now() - started > BUDGET_MS) { out.left = list.length - i; break; }
      if (i) await L.sleep(Number(process.env.VE_PAUSE_MS || 1000));
      const sig = await look(p, robots);
      const data = { signals: JSON.stringify(sig), signals_checked_at: L.sqlNow() };
      const domain = C.domainOf(p.website);
      if (!p.email && sig.emails && sig.emails.length) {
        data.email = sig.emails.find((e) => domain && e.endsWith(`@${domain}`)) || sig.emails[0];
        data.email_source = (sig.email_sources && sig.email_sources[data.email]) || C.siteUrl(p.website);
        const receives = await N.mx(data.email.split('@')[1]);
        data.email_check = receives === false ? 'sin_mx' : C.emailKind(data.email, domain);
      }
      if (!p.phone && sig.phones && sig.phones.length) data.phone = `+${sig.phones[0]}`;
      try {
        L.write([{ op: 'update', table: 've_prospects', id: p._id, data }]);
      } catch { continue; } // deleted meanwhile
      out.checked.push({ id: p._id, on: C.signalsOn(sig), error: sig.error || undefined });
    }
    return out;
  } finally {
    held.release();
  }
}

/** The signals of one prospect: what its home page shows, or why it was not read. */
async function look(p, robotsCache) {
  const url = C.siteUrl(p.website);
  if (!url) return { error: 'La web no es una dirección válida.' };
  const u = new URL(url);
  const sig = {};
  try {
    if (!robotsCache.has(u.origin)) {
      let txt = '';
      try {
        const r = await N.request(`${u.origin}/robots.txt`, { timeoutMs: 8000, maxBytes: 200000 });
        txt = r.status >= 200 && r.status < 300 ? r.text : '';
      } catch { txt = ''; }
      robotsCache.set(u.origin, txt);
    }
    if (!C.robotsAllows(robotsCache.get(u.origin), N.UA, u.pathname || '/')) {
      Object.assign(sig, { robots: 'blocked', error: 'Su robots.txt pide que los robots no lean la página: no se leyó.' });
    } else {
      const r = await N.request(url, { timeoutMs: 12000, maxBytes: 1500000, headers: { Accept: 'text/html,application/xhtml+xml' } });
      if (r.status >= 400) sig.error = `La web contestó ${r.status}.`;
      else if (r.headers['content-type'] && !/html/i.test(r.headers['content-type'])) sig.error = 'La web no devolvió una página.';
      else {
        const domain = C.domainOf(r.url || url);
        Object.assign(sig, C.signals(r.text, { domain }), r.cut ? { cut: true } : {});
        sig.email_sources = Object.fromEntries((sig.emails || []).map((e) => [e, r.url || url]));
        if (!(sig.emails || []).some((e) => domain && e.endsWith(`@${domain}`))) await legalPages(sig, r.text, r.url || url, robotsCache.get(u.origin), domain);
      }
    }
  } catch (e) {
    sig.error = `No se pudo leer la web: ${e.message}`;
  }
  if (process.env.META_AD_LIBRARY_TOKEN) sig.meta_ads = await metaAds(p.name);
  if (!sig.pages) sig.pages = []; // read in this version: the legal-pages pass (NO_EMAIL_YET) never repeats it
  return sig;
}

/**
 * The legal notice, contact and privacy pages the home page links to (at most
 * three, robots.txt respected): their addresses join the home page's, each
 * with the page it was read on. `sig.pages` says which were read.
 */
async function legalPages(sig, html, pageUrl, robotsTxt, domain) {
  sig.pages = [];
  const seen = new Set(sig.emails || []);
  for (const link of C.legalLinks(html, pageUrl, 3)) {
    const lu = new URL(link);
    if (!C.robotsAllows(robotsTxt, N.UA, lu.pathname || '/')) continue;
    await L.sleep(Number(process.env.VE_PAUSE_MS || 1000));
    try {
      const r = await N.request(link, { timeoutMs: 12000, maxBytes: 800000, headers: { Accept: 'text/html,application/xhtml+xml' } });
      sig.pages.push(link);
      if (r.status >= 400) continue;
      for (const e of C.signals(r.text, { domain }).emails) {
        if (seen.has(e)) continue;
        seen.add(e);
        sig.emails.push(e);
        sig.email_sources[e] = link;
      }
    } catch { /* a page that does not answer is skipped */ }
  }
  sig.emails = sig.emails
    .sort((a, b) => Number(!!domain && b.endsWith(`@${domain}`)) - Number(!!domain && a.endsWith(`@${domain}`)))
    .slice(0, 5);
}

/** Active ads in the Meta Ad Library under a page whose name matches the business's (best effort). */
async function metaAds(name) {
  const plain = (s) => String(s || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9]+/g, ' ').trim();
  const want = plain(name);
  if (!want) return { active: 0 };
  try {
    const q = new URLSearchParams({
      search_terms: name, ad_reached_countries: '["ES"]', ad_active_status: 'ACTIVE', ad_type: 'ALL',
      fields: 'page_name,ad_delivery_start_time', limit: '25', access_token: process.env.META_AD_LIBRARY_TOKEN,
    });
    const j = await N.json(`${ADS}?${q}`, { timeoutMs: 15000 });
    const hits = (j.data || []).filter((a) => { const pn = plain(a.page_name); return pn && (pn.includes(want) || want.includes(pn)); });
    return { active: hits.length, pages: [...new Set(hits.map((a) => a.page_name))].slice(0, 3), since: hits.map((a) => a.ad_delivery_start_time).filter(Boolean).sort()[0] || undefined, match: 'name' };
  } catch (e) {
    return { error: String(e.message).replace(/access_token=[^&\s]+/g, 'access_token=…').slice(0, 200) };
  }
}

if (require.main === module) {
  const mode = process.argv.includes('--now') ? '--now' : '--auto';
  run(mode).then((r) => L.done(r)).catch((e) => { L.done({ ok: false, error: e.message }); process.exitCode = 1; });
}

module.exports = { run };
