/**
 * Ventas' rules that the desk and the automations must agree on, in one file:
 * the stages and states, addresses and phones as one key, the OpenStreetMap
 * tags a vertical names, a map result or a Places result as a prospect, the
 * dedupe, what a homepage says about the business (signals), robots.txt,
 * what happens next (who is reviewed first, the next steps, a prospect's
 * state), and what may be sent today. Pure functions: no database, no network, no DOM.
 * test/sync.js copies this file to app/ and automations/, and a test fails if
 * a copy is stale.
 */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.VeCore = api;
}(typeof self !== 'undefined' ? self : this, () => {
  'use strict';

  // ── stages and states ─────────────────────────────────────────────────
  const STAGES = [
    ['nuevo', 'Nuevo'], ['cualificado', 'Cualificado'], ['mensaje', 'Mensaje en borrador'], ['aprobado', 'Aprobado'],
    ['enviado', 'Enviado'], ['respondio', 'Respondió'], ['llamada', 'Llamada'], ['crm', 'En el CRM'], ['descartado', 'Descartado'],
  ];
  const STAGE_LABEL = Object.fromEntries(STAGES);
  const MESSAGE_STATUS = { borrador: 'Borrador', aprobado: 'Aprobado', enviando: 'Enviando', enviado: 'Enviado', rechazado: 'Rechazado', error: 'Error' };
  const SEND_MODES = ['rehearsal', 'live'];
  const SIGNAL_LABEL = {
    ghl: 'GoHighLevel', meta_pixel: 'Píxel de Meta', google_ads: 'Google Ads', gtag: 'Google tag', lead_form: 'Formulario de contacto',
    whatsapp: 'WhatsApp', meta_ads: 'Anuncios activos en Meta',
  };

  // ── addresses and phones ─────────────────────────────────────────────
  const EMAIL_RE = /^[^\s@<>()",;:]+@[^\s@<>()",;:]+\.[a-z]{2,}$/i;
  const isEmail = (v) => EMAIL_RE.test(String(v || '').trim());
  const normEmail = (v) => String(v || '').trim().toLowerCase();

  /** The site's host without www., lowercase: "https://www.Pisos-Sol.es/contacto" → "pisos-sol.es". '' when there is none. */
  function domainOf(url) {
    let s = String(url || '').trim();
    if (!s) return '';
    if (!/^[a-z][a-z0-9+.-]*:\/\//i.test(s)) s = `http://${s}`;
    try {
      const h = new URL(s).hostname.toLowerCase().replace(/^www\d?\./, '').replace(/\.$/, '');
      return /\./.test(h) ? h : '';
    } catch { return ''; }
  }

  /** A website as a URL we can fetch, or '' (only http and https). */
  function siteUrl(url) {
    let s = String(url || '').trim();
    if (!s) return '';
    if (!/^[a-z][a-z0-9+.-]*:\/\//i.test(s)) s = `https://${s}`;
    try {
      const u = new URL(s);
      if (!/^https?:$/.test(u.protocol) || !/\./.test(u.hostname)) return '';
      return `${u.protocol}//${u.host}${u.pathname === '' ? '/' : u.pathname}`;
    } catch { return ''; }
  }

  /** A phone as digits with its country code (Spain by default): "+34 93 123 45 67" and "931234567" are both "34931234567". */
  function phoneKey(v, country = '34') {
    let d = String(v || '').split(/[;,/]| o /)[0].replace(/[^\d+]/g, '');
    if (!d) return '';
    if (d.startsWith('+')) d = d.slice(1);
    else if (d.startsWith('00')) d = d.slice(2);
    else if (country === '34' && /^[6789]\d{8}$/.test(d)) d = `34${d}`;
    d = d.replace(/\D/g, '');
    return d.length >= 8 && d.length <= 15 ? d : '';
  }

  // ── OpenStreetMap ────────────────────────────────────────────────────
  const TAG_KEY = /^[a-z][a-z0-9_:]{0,40}$/;
  const TAG_VALUE = /^[A-Za-z0-9_:;. -]{1,60}$/;
  /**
   * The tags a vertical names, one per line or separated by commas:
   * "office=estate_agent, shop=*" → [['office','estate_agent'], ['shop','*']].
   * What does not look like key=value is left out (and said in `bad`).
   */
  function osmTags(text) {
    const tags = [];
    const bad = [];
    for (const raw of String(text || '').split(/[\n,]+/)) {
      const t = raw.trim();
      if (!t) continue;
      const m = t.match(/^([^=\s]+)\s*=\s*(.+)$/);
      if (!m || !TAG_KEY.test(m[1]) || !(m[2].trim() === '*' || TAG_VALUE.test(m[2].trim()))) { bad.push(t); continue; }
      tags.push([m[1], m[2].trim()]);
    }
    return Object.assign(tags, { bad });
  }

  /** The Overpass area id of an OSM relation or way (Nominatim gives those): relation 347950 → 3600347950. */
  function areaId(osmType, osmId) {
    const id = Number(osmId);
    if (!Number.isInteger(id) || id <= 0) return null;
    if (/^r/i.test(osmType)) return 3600000000 + id;
    if (/^w/i.test(osmType)) return 2400000000 + id;
    return null;
  }

  /** One Overpass QL query: every node, way and relation with one of the tags inside the area, with their centre, at most `max`. */
  function overpassQuery(area, tags, { max = 500, timeout = 60 } = {}) {
    const q = (s) => `"${String(s).replace(/["\\]/g, '')}"`;
    const parts = tags.map(([k, v]) => `  nwr[${q(k)}${v === '*' ? '' : `=${q(v)}`}](area.a);`);
    return `[out:json][timeout:${timeout}];\narea(id:${Number(area)})->.a;\n(\n${parts.join('\n')}\n);\nout center tags ${Number(max)};`;
  }

  const clip = (v, n) => String(v === null || v === undefined ? '' : v).replace(/[\u0000-\u001f\u007f]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, n);
  const firstOf = (tags, keys) => { for (const k of keys) if (tags[k]) return String(tags[k]); return ''; };

  /** A map result (an Overpass element) as a prospect; null when it has no name. */
  function fromOsm(e, { vertical_id = null, area = '' } = {}) {
    const t = (e && e.tags) || {};
    const name = clip(t.name || t.brand || t['name:es'], 160);
    if (!name || !e.type || !e.id) return null;
    const street = [t['addr:street'], t['addr:housenumber']].filter(Boolean).join(' ');
    const address = [street, t['addr:postcode']].filter(Boolean).join(', ');
    const website = siteUrl(firstOf(t, ['website', 'contact:website', 'url']));
    const email = normEmail(firstOf(t, ['email', 'contact:email']).split(/[;,\s]/)[0]);
    return {
      name,
      website: website || null,
      phone: clip(firstOf(t, ['phone', 'contact:phone', 'contact:mobile']).split(';')[0], 40) || null,
      email: isEmail(email) ? email : null,
      address: clip(address, 200) || null,
      city: clip(t['addr:city'] || area, 80) || null,
      vertical_id,
      source: 'osm',
      source_ref: `osm:${e.type}/${e.id}`,
    };
  }

  /** A Google Places (New) result as a prospect; null when it has no id or name. */
  function fromPlace(p, { vertical_id = null, area = '' } = {}) {
    const name = clip(p && p.displayName && (p.displayName.text || p.displayName), 160);
    if (!p || !p.id || !name) return null;
    const comp = (type) => ((p.addressComponents || []).find((c) => (c.types || []).includes(type)) || {}).longText || '';
    return {
      name,
      website: siteUrl(p.websiteUri) || null,
      phone: clip(p.internationalPhoneNumber || p.nationalPhoneNumber, 40) || null,
      email: null,
      address: clip(p.formattedAddress, 200) || null,
      city: clip(comp('locality') || area, 80) || null,
      vertical_id,
      source: 'google_places',
      source_ref: `gplaces:${p.id}`,
    };
  }

  /**
   * What to write for what a search found, given the prospects already there:
   * the same place (source_ref), else the same website domain, else the same
   * phone, is the same business — its empty fields are filled, nothing a
   * person or the agent wrote is changed. Two finds of one business in the
   * same run are one.
   *   plan(found, existing) → { inserts: [prospect], updates: [{ id, data }], same: n }
   */
  const FILL = ['website', 'phone', 'email', 'address', 'city'];
  function plan(found, existing) {
    const byRef = new Map();
    const byDomain = new Map();
    const byPhone = new Map();
    const index = (p, row) => {
      if (p.source_ref) byRef.set(p.source_ref, row);
      const d = domainOf(p.website);
      if (d && !byDomain.has(d)) byDomain.set(d, row);
      const ph = phoneKey(p.phone);
      if (ph && !byPhone.has(ph)) byPhone.set(ph, row);
    };
    for (const e of existing || []) index(e, { id: e._id, row: e });
    const inserts = [];
    const updates = new Map();
    let same = 0;
    for (const f of found || []) {
      if (!f) continue;
      const hit = byRef.get(f.source_ref) || byDomain.get(domainOf(f.website)) || byPhone.get(phoneKey(f.phone));
      if (!hit) {
        const row = { id: null, row: f };
        inserts.push(f);
        index(f, row);
        continue;
      }
      same += 1;
      if (hit.id === null) continue; // found twice in this run
      const cur = Object.assign({}, hit.row, (updates.get(hit.id) || {}));
      const data = {};
      for (const k of FILL) if ((cur[k] === null || cur[k] === undefined || cur[k] === '') && f[k]) data[k] = f[k];
      if (Object.keys(data).length) updates.set(hit.id, Object.assign(updates.get(hit.id) || {}, data));
    }
    return { inserts, updates: [...updates].map(([id, data]) => ({ id, data })), same };
  }

  // ── what a homepage says ─────────────────────────────────────────────
  const FREE_MAIL = /@(gmail|googlemail|hotmail|outlook|live|yahoo|icloud|me|protonmail|proton)\./i;
  const JUNK_MAIL = /\.(png|jpe?g|gif|svg|webp|css|js)$|@(example|sentry|wixpress|domain|email)\.|^(u00|x00)/i;

  /**
   * The signals a homepage shows, from its HTML:
   *   ghl          GoHighLevel (leadconnectorhq, msgsndr, gohighlevel)
   *   meta_pixel   Meta's pixel (fbq('init'), connect.facebook.net … fbevents)
   *   google_ads   Google Ads (googleadservices, an AW- tag)
   *   gtag         a Google tag or Analytics (gtag/js, googletagmanager)
   *   lead_form    a form that asks for an email or a phone
   *   whatsapp     a WhatsApp link (wa.me, api.whatsapp.com)
   *   emails, phones   what it shows (at most 5 each)
   */
  function signals(html, { domain = '' } = {}) {
    const h = String(html || '');
    const low = h.toLowerCase();
    const out = {
      ghl: /leadconnectorhq\.com|msgsndr\.com|gohighlevel\.com|link\.msgsndr|widgets\.leadconnectorhq/.test(low),
      meta_pixel: /fbq\(\s*['"]init['"]|connect\.facebook\.net\/[a-z_]+\/fbevents\.js|facebook\.com\/tr\?id=/.test(low),
      google_ads: /googleadservices\.com|googleads\.g\.doubleclick\.net|['"]aw-\d{6,}/.test(low),
      gtag: /googletagmanager\.com\/(gtag\/js|gtm\.js)|google-analytics\.com\/(analytics|ga)\.js/.test(low),
      lead_form: false,
      whatsapp: /wa\.me\/|api\.whatsapp\.com\/send|web\.whatsapp\.com\/send|whatsapp:\/\/send/.test(low),
      emails: [],
      phones: [],
    };
    for (const f of low.match(/<form[\s\S]{0,6000}?<\/form>/g) || []) {
      if (/type=["']?(email|tel)|name=["']?[^"'>]*(email|correo|phone|tel[eé]fono|telefono|mail)/.test(f)) { out.lead_form = true; break; }
    }
    if (!out.lead_form && /hsforms|hbspt\.forms|typeform\.com\/to|forms\.gle|calendly\.com|wpcf7|gform_wrapper|elementor-form/.test(low)) out.lead_form = true;
    const emails = new Set();
    for (const m of h.matchAll(/mailto:([^"'?\s>]+)/gi)) emails.add(normEmail(decodeURIComponent(m[1])));
    for (const m of h.replace(/<script[\s\S]*?<\/script>/gi, ' ').matchAll(/[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}/gi)) emails.add(normEmail(m[0]));
    out.emails = [...emails].filter((e) => isEmail(e) && !JUNK_MAIL.test(e))
      .sort((a, b) => Number(!!domain && b.endsWith(`@${domain}`)) - Number(!!domain && a.endsWith(`@${domain}`)) || Number(FREE_MAIL.test(a)) - Number(FREE_MAIL.test(b)))
      .slice(0, 5);
    const phones = new Set();
    for (const m of h.matchAll(/tel:([+\d\s().-]{8,24})/gi)) { const k = phoneKey(m[1]); if (k) phones.add(k); }
    for (const m of h.matchAll(/wa\.me\/(\d{8,15})/gi)) phones.add(m[1]);
    out.phones = [...phones].slice(0, 5);
    return out;
  }

  /** The names of the signals that are on, in a fixed order ("ghl", "meta_pixel", …). */
  const ON = ['ghl', 'meta_pixel', 'google_ads', 'gtag', 'lead_form', 'whatsapp', 'meta_ads'];
  function signalsOn(sig) {
    const s = typeof sig === 'string' ? (() => { try { return JSON.parse(sig); } catch { return {}; } })() : (sig || {});
    return ON.filter((k) => (k === 'meta_ads' ? Number(s.meta_ads && s.meta_ads.active) > 0 : s[k] === true));
  }

  /**
   * Whether robots.txt lets our agent read `path`: the group for our name, else
   * the one for *; the longest matching rule wins, Allow on a tie. An empty or
   * missing file allows everything.
   */
  function robotsAllows(txt, agent, pathname = '/') {
    const groups = [];
    let cur = null;
    let lastWasAgent = false;
    for (const raw of String(txt || '').split(/\r?\n/)) {
      const line = raw.replace(/#.*/, '').trim();
      const m = line.match(/^([A-Za-z-]+)\s*:\s*(.*)$/);
      if (!m) continue;
      const key = m[1].toLowerCase();
      const val = m[2].trim();
      if (key === 'user-agent') {
        if (!lastWasAgent) { cur = { agents: [], rules: [] }; groups.push(cur); }
        cur.agents.push(val.toLowerCase());
        lastWasAgent = true;
      } else {
        lastWasAgent = false;
        if (cur && (key === 'allow' || key === 'disallow')) cur.rules.push({ allow: key === 'allow', path: val });
      }
    }
    const name = String(agent || '').toLowerCase().split('/')[0];
    const mine = groups.filter((g) => g.agents.some((a) => a !== '*' && name.includes(a)));
    const rules = (mine.length ? mine : groups.filter((g) => g.agents.includes('*'))).flatMap((g) => g.rules);
    let best = null;
    for (const r of rules) {
      if (!r.path) continue; // "Disallow:" with nothing allows all
      const re = new RegExp(`^${r.path.replace(/[.+?^${}()|[\]\\]/g, '\\$&').replace(/\*/g, '.*').replace(/\\\$$/, '$')}`);
      if (!re.test(pathname)) continue;
      if (!best || r.path.length > best.path.length || (r.path.length === best.path.length && r.allow)) best = r;
    }
    return !best || best.allow;
  }

  // ── what happens next ────────────────────────────────────────────────
  /**
   * How much a prospect's site says it buys leads, for who is reviewed first:
   * 3 GoHighLevel · 2 Meta's pixel, Google Ads or active Meta ads · 1 a lead
   * form or WhatsApp · 0 the rest (nothing on, or the site was not read). The
   * suggested task "revisar-prospectos" orders by the same tiers in SQL
   * (json_extract over the stored signals); a test holds the two together.
   */
  function richness(sig) {
    const on = new Set(signalsOn(sig));
    if (on.has('ghl')) return 3;
    if (on.has('meta_pixel') || on.has('google_ads') || on.has('meta_ads')) return 2;
    if (on.has('lead_form') || on.has('whatsapp')) return 1;
    return 0;
  }

  /** The minute of the hour Ventas · Señales runs at (app.json's cron; a test holds them together). */
  const SIGNALS_MINUTE = 17;
  const SIGNALS_PER_RUN = 25;

  /** The next time the clock shows :`minute` after `now` (local time), as a Date. */
  function nextAtMinute(minute, now = new Date()) {
    const d = new Date(now.getTime());
    d.setSeconds(0, 0);
    d.setMinutes(minute);
    if (d.getTime() <= now.getTime()) d.setHours(d.getHours() + 1);
    return d;
  }
  const hhmm = (d) => `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;

  /**
   * "Qué pasa ahora": the three steps a prospect goes through, each with its
   * numbers and who does it when. `c` is the pipeline_counts view's row:
   *   with_web, read_web (of those), pending, judgeable (pending with web and signals), no_web (pending without), drafts
   * → [{ n, title, line, who, note?, to? }]
   */
  function nextSteps(c = {}, now = new Date()) {
    const k = (v) => Math.max(0, Number(v) || 0);
    const withWeb = k(c.with_web);
    const read = Math.min(k(c.read_web), withWeb);
    const pending = k(c.pending);
    const judgeable = k(c.judgeable);
    const noWeb = k(c.no_web);
    const drafts = k(c.drafts);
    const left = withWeb - read;
    return [
      {
        n: 1, key: 'senales', title: 'Señales',
        line: withWeb ? `${read} de ${withWeb} webs leídas` : 'Ningún prospecto con web todavía',
        who: !withWeb ? 'Ventas lee la web de cada prospecto que la tenga.'
          : left ? `Ventas lee ${SIGNALS_PER_RUN} cada hora: siguiente tanda a las ${hhmm(nextAtMinute(SIGNALS_MINUTE, now))}.`
            : 'Todas leídas. Ventas lee las nuevas cada hora.',
      },
      {
        n: 2, key: 'cualificar', title: 'Cualificar',
        line: `${pending} por decidir (${judgeable} con web y señales)`,
        who: 'El agente Comercial revisa 20 cada laborable a las 9:00, empezando por las webs con más señales (si creaste su tarea en Apps → Ventas → Tareas).',
        note: noWeb ? `${noWeb} sin web: no se pueden cualificar solos (a mano, o con Google Places).` : null,
      },
      {
        n: 3, key: 'mensajes', title: 'Mensajes',
        line: `${drafts} por aprobar`,
        who: 'Tú, en Hoy: sale lo que apruebas, o lo que el equipo envía solo en los pitches donde le dejaste.',
        to: 'aprobar',
      },
    ];
  }

  /**
   * A prospect's one state, in words, for its row and its page: where it is and
   * who has it now. → { key, label, tone, title }
   */
  function prospectState(p = {}) {
    const stage = p.stage || 'nuevo';
    const fit = p.fit || 'pending';
    const reason = String(p.fit_reason || '').trim();
    if (stage === 'descartado') return { key: 'descartado', label: fit === 'no' ? 'No encaja' : 'Descartado', tone: '', title: reason || 'Descartado: no se le escribe.' };
    if (fit === 'pending' && stage === 'nuevo') {
      if (!String(p.website || '').trim()) return { key: 'sin_web', label: 'Sin web · a mano', tone: 'warn', title: 'Sin web, el agente no puede juzgarlo solo: decide tú en su página, o búscalo con Google Places.' };
      if (!p.signals_checked_at) return { key: 'por_leer', label: 'Por decidir · señales por leer', tone: '', title: 'Ventas lee su web en la próxima tanda; después lo revisa el agente.' };
      return { key: 'por_decidir', label: 'Por decidir · lo revisa el agente', tone: 'accent', title: 'El agente Comercial decide si encaja, con su razón.' };
    }
    if (stage === 'nuevo' || stage === 'cualificado') {
      if (fit === 'no') return { key: 'no_encaja', label: 'No encaja', tone: '', title: reason };
      return { key: 'encaja', label: 'Encaja', tone: 'good', title: reason };
    }
    return { key: stage, label: STAGE_LABEL[stage] || stage, tone: null, title: reason };
  }

  // ── sending ──────────────────────────────────────────────────────────
  /** The body as it goes out: the sign-off under it, once. */
  function finalBody(body, signOff) {
    const b = String(body || '').replace(/\r\n/g, '\n').trim();
    const s = String(signOff || '').replace(/\r\n/g, '\n').trim();
    if (!s || b.endsWith(s)) return b;
    return `${b}\n\n${s}`;
  }

  /** Who approved it is a person: an agent's approval ("agent:<id>", as the platform stamps it) never sends. */
  const approvedByPerson = (who) => !!String(who || '').trim() && !/^agent:/i.test(String(who).trim());

  /** Approved by the team under a pitch's rule (send_as_team), not by a person. */
  const approvedByTeam = (m) => !!m && !approvedByPerson(m.approved_by) && m.approved_as === 'equipo';

  /** Why one approved message cannot go out, or null. A team approval is judged by teamCheck too. */
  function cannotSend(m, prospect) {
    if (!approvedByPerson(m.approved_by) && !approvedByTeam(m)) return 'Lo aprobó un agente: solo una persona aprueba un mensaje. Vuelve a borrador para que alguien lo revise.';
    if (!prospect) return 'Su prospecto ya no está.';
    if (prospect.stage === 'descartado') return 'El prospecto está descartado: no se envía.';
    if (prospect.stage === 'crm') return 'El prospecto ya pasó al CRM: lo que se le escriba sale desde allí.';
    if (!isEmail(m.to_email)) return 'No tiene una dirección válida: no salió nada. Edítalo y apruébalo de nuevo.';
    if (!String(m.subject || '').trim() || !String(m.body || '').trim()) return 'Le falta el asunto o el texto: no salió nada.';
    return null;
  }

  // ── what the team may send on its own ─────────────────────────────────
  // A person approves every message, unless a pitch's rule lets the team
  // send its FIRST messages alone ("El equipo envía solo", granted by a
  // person on the pitch (Configuración), from an approval, or when Resumen offers it after
  // TEAM.EARN_AFTER approvals left unchanged). Narrow on purpose: one pitch,
  // first messages, prospects judged a fit, the address found on their
  // website, never twice to the same person, at most team_daily_limit a day
  // (inside daily_limit), each one held hold_minutes so a person can stop it.
  // Follow-ups, anything the team asks about and anything the check below
  // does not like go to the person. Rehearsal stays rehearsal.
  const TEAM = { HOLD_MIN: 60, DAILY: 10, EARN_AFTER: 5 };
  const PLACEHOLDER = /\{\{|\}\}|\[(?:nombre|name|empresa|company|ciudad|city|x+)\]|<\s*(?:nombre|name|empresa|company)\s*>|\bTODO\b|\bTBD\b|hip[oó]tesis|lorem ipsum/i;
  const teamHold = (s) => Math.max(0, Math.min(1440, s && s.hold_minutes != null && s.hold_minutes !== '' ? Number(s.hold_minutes) || 0 : TEAM.HOLD_MIN));
  const teamDaily = (s) => Math.max(0, Math.min(500, s && s.team_daily_limit != null && s.team_daily_limit !== '' ? Number(s.team_daily_limit) || 0 : TEAM.DAILY));

  /**
   * Why a message the team approved cannot go out on its own — it goes back
   * to the person with this reason — or null.
   *   teamCheck(m, { pitch, prospect, contactedBefore }) — contactedBefore:
   *   other messages to this address or prospect already approved or sent.
   */
  function teamCheck(m, { pitch, prospect, contactedBefore = 0 } = {}) {
    if (m.kind !== 'primero') return 'Los seguimientos los apruebas tú: el equipo solo envía primeros mensajes.';
    if (!pitch || Number(pitch.team_sends) !== 1) return 'Su pitch no deja que el equipo envíe solo: lo apruebas tú.';
    if (String(m.needs_person || '').trim()) return `El equipo te pregunta: ${clip(m.needs_person, 300)}`;
    if (!prospect || prospect.fit !== 'yes') return 'El prospecto no está marcado como que encaja: lo apruebas tú.';
    const to = normEmail(m.to_email);
    if (![prospect.contact_email, prospect.email].map(normEmail).filter(Boolean).includes(to)) return 'La dirección no es la que se encontró en su web: la revisas tú.';
    if (Number(contactedBefore) > 0) return 'A esta dirección o a este prospecto ya se le escribió: lo revisas tú.';
    if (PLACEHOLDER.test(String(m.subject || '')) || PLACEHOLDER.test(String(m.body || ''))) return 'Tiene un marcador, una hipótesis o algo sin rellenar: lo revisas tú.';
    const len = String(m.body || '').trim().length;
    if (len < 80 || len > 1500) return 'Es demasiado corto o demasiado largo para salir solo: lo revisas tú.';
    if (String(m.subject || '').trim().length > 120) return 'El asunto es demasiado largo para salir solo: lo revisas tú.';
    return null;
  }

  /** When a team approval may leave (ms since epoch): its approval plus the hold. */
  function leavesAt(m, s) {
    const t = Date.parse(String(m.approved_at || '').replace(' ', 'T').replace(/(T\d\d:\d\d:\d\d)$/, '$1Z'));
    return (Number.isFinite(t) ? t : 0) + teamHold(s) * 60000;
  }

  /**
   * Of the approved queue, what may go out now: a person's approvals as they
   * are; the team's once their hold is over and while the team's own daily
   * limit has room (the rest wait). Checks (teamCheck) are the caller's.
   *   teamQueue({ queue, settings, teamSentToday, now }) → { ready: [...], held: [...], capped: n }
   */
  function teamQueue({ queue = [], settings: s = {}, teamSentToday = 0, now = Date.now() }) {
    const ready = []; const held = [];
    let room = Math.max(0, teamDaily(s) - (Number(teamSentToday) || 0));
    let capped = 0;
    for (const m of queue) {
      if (!approvedByTeam(m)) { ready.push(m); continue; }
      if (leavesAt(m, s) > now) { held.push(m); continue; }
      if (room <= 0) { capped++; continue; }
      room--; ready.push(m);
    }
    return { ready, held, capped };
  }

  /** A pitch by its name: its vertical and use case (pitches_list), else its angle without the (hipótesis) mark. */
  function pitchName(p) {
    if (!p) return 'este pitch';
    if (p.vertical || p.use_case) return clip([p.vertical, p.use_case].filter(Boolean).join(' · '), 80);
    const a = clip(String(p.angle || '').replace(/\(hip[oó]tesis\)\s*/gi, ''), 60);
    return a ? (String(p.angle).length > 60 ? `${a}…` : a) : 'este pitch';
  }

  /** The rule as a person reads it. */
  function teamRule(pitch, s) {
    const what = pitch ? `«${pitchName(pitch)}»` : 'este pitch';
    const hold = teamHold(s);
    return `El equipo envía solo los primeros mensajes de ${what} a prospectos que encajan, a la dirección encontrada en su web y nunca dos veces a la misma persona; como mucho ${teamDaily(s)} al día${hold ? `, y cada uno espera ${hold} min por si lo paras` : ''}. Los seguimientos y lo que el equipo no tenga claro te llegan a ti.`;
  }

  /**
   * Hoy's offer for a pitch the person keeps approving unchanged, or null.
   *   trustOffer(pitch, unchanged) — unchanged: its first messages a person
   *   approved without editing and that went out.
   */
  function trustOffer(pitch, unchanged) {
    const n = Number(unchanged) || 0;
    if (!pitch || Number(pitch.team_sends) === 1 || pitch.team_offer_dismissed_at || n < TEAM.EARN_AFTER) return null;
    return { pitch_id: pitch._id, ask: `Has aprobado ${n} primeros mensajes de «${pitchName(pitch)}» sin cambiarlos. ¿Dejas que el equipo envíe solo los de este pitch?` };
  }

  /**
   * What a send run may do: in rehearsal nothing goes out; live, at most what
   * is left of the daily limit, oldest approval first.
   *   sendPlan({ mode, limit, sentToday, queue }) → { send: [...], wait: n, why }
   */
  function sendPlan({ mode, limit, sentToday = 0, queue = [] }) {
    const cap = Math.max(1, Math.min(500, Number(limit) || 15));
    if (mode !== 'live') return { send: [], wait: queue.length, why: 'ensayo' };
    const room = Math.max(0, cap - (Number(sentToday) || 0));
    if (!queue.length) return { send: [], wait: 0, why: 'nada aprobado' };
    if (!room) return { send: [], wait: queue.length, why: `límite diario de ${cap} alcanzado` };
    return { send: queue.slice(0, room), wait: Math.max(0, queue.length - room), why: null };
  }

  /**
   * Going live while approved messages wait: they would go out minutes later,
   * approved back when nothing could leave. So the switch asks, with two
   * answers, and the safe one is the default: back to draft (each one is read
   * again before it is approved again).
   *   goLiveQuestion(waiting) → null (nothing waits) | { ask, choices: [{ key, label, default? }] }
   *   goLiveSteps(waiting, choice) → what to do, in order: ['to_draft', 'live'] or ['live']
   */
  function goLiveQuestion(waiting) {
    const n = Math.max(0, Number(waiting) || 0);
    if (!n) return null;
    return {
      ask: n === 1 ? 'Hay 1 mensaje aprobado esperando: ¿enviarlo o devolverlo a borrador?' : `Hay ${n} mensajes aprobados esperando: ¿enviarlos o devolverlos a borrador?`,
      choices: [
        { key: 'draft', label: n === 1 ? 'Devolverlo a borrador (lo revisas otra vez antes de que salga)' : 'Devolverlos a borrador (los revisas otra vez antes de que salgan)', default: true },
        { key: 'send', label: n === 1 ? 'Enviarlo: sale en los próximos minutos' : `Enviarlos: salen en los próximos minutos, como mucho el límite diario` },
      ],
    };
  }
  function goLiveSteps(waiting, choice) {
    if (!(Number(waiting) > 0)) return ['live'];
    return choice === 'send' ? ['live'] : ['to_draft', 'live'];
  }

  return {
    STAGES, STAGE_LABEL, MESSAGE_STATUS, SEND_MODES, SIGNAL_LABEL, ON,
    isEmail, normEmail, domainOf, siteUrl, phoneKey,
    osmTags, areaId, overpassQuery, fromOsm, fromPlace, plan,
    signals, signalsOn, robotsAllows,
    finalBody, approvedByPerson, approvedByTeam, cannotSend, sendPlan,
    TEAM, teamCheck, teamQueue, teamRule, trustOffer, pitchName, leavesAt, teamHold, teamDaily, goLiveQuestion, goLiveSteps, clip,
    richness, SIGNALS_MINUTE, SIGNALS_PER_RUN, nextAtMinute, hhmm, nextSteps, prospectState,
  };
}));
