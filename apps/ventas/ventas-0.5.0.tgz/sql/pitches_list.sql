SELECT pi._id AS _id, pi.vertical_id AS vertical_id, v.name AS vertical, pi.use_case_id AS use_case_id, u.name AS use_case,
  pi.angle AS angle, pi.opening AS opening, pi.case_to_cite AS case_to_cite, pi.offer AS offer, pi.channel AS channel, pi.status AS status,
  COALESCE(pi.team_sends, 0) AS team_sends, pi.team_sends_by AS team_sends_by, pi.team_sends_at AS team_sends_at, pi.team_offer_dismissed_at AS team_offer_dismissed_at,
  (SELECT COUNT(*) FROM ve_messages m WHERE m._deleted = 0 AND m.pitch_id = pi._id AND m.kind = 'primero' AND m.status = 'enviado'
     AND COALESCE(m.approved_as, 'persona') = 'persona' AND m.approved_by NOT LIKE 'agent:%' AND COALESCE(m.edited, 0) = 0) AS unchanged,
  (SELECT COUNT(*) FROM ve_messages m WHERE m._deleted = 0 AND m.pitch_id = pi._id AND m.status = 'enviado' AND m.approved_as = 'equipo') AS team_sent,
  (SELECT COUNT(*) FROM ve_messages m WHERE m._deleted = 0 AND m.pitch_id = pi._id AND m.kind = 'primero' AND m.status = 'enviado') AS sent,
  (SELECT COUNT(*) FROM ve_messages m WHERE m._deleted = 0 AND m.pitch_id = pi._id AND m.kind = 'primero' AND m.status = 'enviado' AND COALESCE(m.edited, 0) = 1) AS edited,
  (SELECT COUNT(DISTINCT m.prospect_id) FROM ve_messages m JOIN ve_prospects p ON p._id = m.prospect_id AND p._deleted = 0
     WHERE m._deleted = 0 AND m.pitch_id = pi._id AND m.status = 'enviado' AND p.reply_kind IN ('interesado', 'ahora_no', 'persona_equivocada')) AS replies,
  (SELECT COUNT(DISTINCT m.prospect_id) FROM ve_messages m JOIN ve_prospects p ON p._id = m.prospect_id AND p._deleted = 0
     WHERE m._deleted = 0 AND m.pitch_id = pi._id AND m.status = 'enviado' AND COALESCE(p.unsubscribed_at, '') <> '') AS opted_out
FROM ve_pitches pi
LEFT JOIN ve_verticals v ON v._id = pi.vertical_id AND v._deleted = 0
LEFT JOIN ve_use_cases u ON u._id = pi.use_case_id AND u._deleted = 0
WHERE pi._deleted = 0
