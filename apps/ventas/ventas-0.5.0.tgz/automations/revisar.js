'use strict';
/**
 * Ventas · Revisar — every draft is reviewed before a person sees it.
 *
 * For each message in Borrador whose text changed since it was last reviewed
 * (review_at older than _updated_at, or never reviewed): vecore.reviewDraft
 * lists what is wrong with it — too long, a link in the first message, the
 * technology instead of the service, a stock phrase, no question, a
 * signature in the body, an address whose domain receives no mail, a
 * prospect who asked for no more messages — and the list is kept on the
 * message (review, a JSON array; [] = nothing to fix). The agent fixes what it
 * lists (edit_message, which reviews it again); the desk shows it to the
 * person; the team never sends a draft whose review is not empty (teamCheck).
 *
 * No agent turn; nothing is sent. Started by draft_message, draft_by_hand,
 * draft_follow_up and edit_message, and every 10 minutes while a draft waits.
 *   node revisar.js [--auto|--now]
 */
const L = require('./lib');

const { C } = L;

async function run(mode = '--auto') {
  const held = L.lock('revisar');
  if (!held) return { ok: true, mode, skipped: 'Otra revisión está en marcha' };
  try {
    const list = L.all(`SELECT * FROM ve_messages WHERE _deleted = 0 AND status = 'borrador'
      AND (review_at IS NULL OR datetime(review_at) < datetime(_updated_at)) ORDER BY _id LIMIT 200`);
    if (!list.length) return { ok: true, mode, skipped: 'Ningún borrador espera revisión' };
    const out = { ok: true, mode, reviewed: [] };
    for (const m of list) {
      const p = m.prospect_id ? L.one('SELECT * FROM ve_prospects WHERE _id = ? AND _deleted = 0', m.prospect_id) : null;
      const problems = C.reviewDraft(m, { prospect: p });
      const at = L.sqlNow();
      // review_at a second ahead of the write's own _updated_at, so this write does not count as a change to review again.
      const ahead = new Date(Date.parse(`${at.replace(' ', 'T')}Z`) + 1000).toISOString().replace('T', ' ').slice(0, 19);
      try {
        L.write([{ op: 'update', table: 've_messages', id: m._id, when: { status: 'borrador' }, data: { review: JSON.stringify(problems), review_at: ahead } }]);
      } catch { continue; } // approved or changed meanwhile
      out.reviewed.push({ id: m._id, problems: problems.map((x) => x.code) });
    }
    return out;
  } finally {
    held.release();
  }
}

if (require.main === module) {
  const mode = process.argv.includes('--now') ? '--now' : '--auto';
  run(mode).then((r) => L.done(r)).catch((e) => { L.done({ ok: false, error: e.message }); process.exitCode = 1; });
}

module.exports = { run };
