'use strict';
/**
 * Ventas · Enviar — the messages a person approved, from the Gmail connection
 * chosen for Ventas, in plain text with the sign-off under them.
 *
 * In rehearsal (send_mode = rehearsal, the default) nothing is sent: approved
 * messages stay Aprobado — ready — and their prospect shows Aprobado. Live,
 * at most daily_limit leave each day (UTC), oldest approval first; the rest
 * wait for the next day.
 *
 * What a PERSON approved goes out. What the TEAM approved (send_as_team) goes
 * out only under its pitch's rule ("El equipo envía solo") and once teamCheck
 * passes — first message, a fit, the address found on their website, nobody
 * written to twice, nothing left to fill in — after its hold (hold_minutes,
 * so a person can stop it) and within team_daily_limit; otherwise it goes
 * back to Borrador with the reason, for the person. Any other approval
 * stamped by an agent ("agent:<id>") goes back to Borrador, never out. Each one is
 * CLAIMED before Gmail is called (Aprobado → Enviando, atomic), so a message
 * rejected meanwhile never leaves and none leaves twice. One left Enviando (a
 * run that died, or Gmail did not answer) becomes Error and says it may have
 * gone out: never retried blind. A person retries, edits or marks it sent.
 *
 * Who it sends from: the Gmail connection chosen for Ventas in Orchestra
 * (Apps → Ventas → Resumen → Conexiones), which the platform passes as
 * ORCHESTRA_ACCOUNT_GMAIL (its name). ve_settings.sender_account is only where
 * an older team install kept it and is normally empty. Live with neither, nothing
 * is tried: the approved messages stay Aprobado with the reason in their error and
 * in send_note, and go out on their own once the connection is chosen (ORC-273).
 * After a send, send_note says which account it went out from.
 *
 * Never written to: an address that asked for no more messages (anywhere in
 * Ventas: the opt-out follows the address), or one whose domain receives no
 * mail. Only email leaves here — a call, a visit or a message by hand is the
 * person's. A follow-up goes as a reply in the Gmail thread of what was sent
 * before (thread_id), so it reads as the same conversation; with no thread, as
 * a new email.
 *
 * No agent turn. Approving starts it; a check every 5 minutes picks up what
 * waits while live.
 *   node enviar.js [--auto|--now]
 */
const L = require('./lib');
const X = require('./composio');
const N = require('./net');

const { C } = L;
const STALE_MIN = 15;
const NO_GMAIL = 'Gmail no está conectado para Ventas: elígelo en Apps → Ventas → Conexiones. Lo aprobado sigue listo y saldrá en cuanto lo elijas.';

async function run(mode = '--auto') {
  const held = L.lock('enviar');
  if (!held) return { ok: true, mode, skipped: 'Otro envío está en marcha' };
  try {
    const s = L.settings();
    const now = L.sqlClock();
    const out = { ok: true, mode, send_mode: s.send_mode === 'live' ? 'live' : 'rehearsal', sent: [], failed: [], back: [] };

    // What was claimed and never finished: it may have gone out.
    const stale = L.all(`SELECT _id FROM ve_messages WHERE _deleted = 0 AND status = 'enviando' AND datetime(lock_at) <= datetime('${now}', '-${STALE_MIN} minutes')`);
    for (const r of stale) {
      try {
        L.write([{ op: 'update', table: 've_messages', id: r._id, when: { status: 'enviando' }, data: {
          status: 'error', error: 'El envío no terminó: puede que haya salido o no. Mira en Enviados de Gmail antes de reintentar.' } }]);
      } catch { /* finished meanwhile */ }
    }
    if (stale.length) out.unfinished = stale.length;

    stages();

    // Only email goes out from here: a call, a visit or a message by hand is the person's to do (draft_by_hand).
    const approved = L.all("SELECT * FROM ve_messages WHERE _deleted = 0 AND status = 'aprobado' AND COALESCE(channel, 'email') = 'email' ORDER BY datetime(approved_at), _id LIMIT 200");
    const sentToday = L.one(`SELECT COUNT(*) AS n FROM ve_messages WHERE _deleted = 0 AND status IN ('enviando', 'enviado')
      AND date(COALESCE(sent_at, lock_at)) = date('${now}')`).n;
    const teamSentToday = L.one(`SELECT COUNT(*) AS n FROM ve_messages WHERE _deleted = 0 AND status IN ('enviando', 'enviado') AND approved_as = 'equipo'
      AND date(COALESCE(sent_at, lock_at)) = date('${now}')`).n;
    const queue = approved.filter((m) => !C.approvedByTeam(m) || teamOk(m, out));
    const team = C.teamQueue({ queue, settings: s, teamSentToday, now: Date.now() });
    if (team.held.length) out.held = team.held.length;
    const plan = C.sendPlan({ mode: out.send_mode, limit: s.daily_limit, sentToday, queue: team.ready });
    plan.wait += team.capped;
    if (out.send_mode !== 'live') {
      note(s, queue.length ? `Ensayo: ${queue.length} ${queue.length === 1 ? 'mensaje aprobado está listo' : 'mensajes aprobados están listos'}; no sale ninguno hasta pasar a envío real.` : 'Ensayo: no sale nada.');
      return Object.assign(out, { skipped: 'Ensayo: no se envía nada', ready: queue.length });
    }
    if (!plan.send.length && !plan.wait && team.held.length) {
      note(s, `${team.held.length === 1 ? '1 mensaje del equipo espera' : `${team.held.length} mensajes del equipo esperan`} su margen para que puedas pararlos; luego salen solos.`);
      return Object.assign(out, { skipped: 'Lo del equipo espera su margen', held: team.held.length });
    }
    if (!plan.send.length) {
      if (queue.length) note(s, `Límite diario de ${Number(s.daily_limit) || 15} alcanzado: ${queue.length} aprobados esperan a mañana.`);
      return Object.assign(out, { skipped: plan.why, waiting: plan.wait });
    }

    // Who it sends from. Live with no Gmail connection resolved, nothing is tried.
    const account = process.env.ORCHESTRA_ACCOUNT_GMAIL || s.sender_account || null;
    let noConnection = 0;

    for (const m of plan.send) {
      const p = m.prospect_id ? L.one('SELECT * FROM ve_prospects WHERE _id = ? AND _deleted = 0', m.prospect_id) : null;
      const to = C.normEmail(m.to_email || (p && (p.contact_email || p.email)));
      const why = C.cannotSend(Object.assign({}, m, { to_email: to }), p) || await refused(to, p);
      if (why) {
        if (!C.approvedByPerson(m.approved_by)) {
          try { L.write([{ op: 'update', table: 've_messages', id: m._id, when: { status: 'aprobado' }, data: { status: 'borrador', approved_by: null, approved_at: null, approved_as: null, error: why } }]); } catch { /* changed */ }
          out.back.push({ id: m._id, why });
        } else fail(m, why, out, 'aprobado');
        continue;
      }
      if (!account) {
        try { L.write([{ op: 'update', table: 've_messages', id: m._id, when: { status: 'aprobado' }, data: { error: NO_GMAIL } }]); } catch { /* changed meanwhile */ }
        noConnection++;
        continue;
      }
      try {
        L.write([{ op: 'update', table: 've_messages', id: m._id, when: { status: 'aprobado' }, data: { status: 'enviando', lock_at: L.sqlNow(), to_email: to, error: null } }]);
      } catch { continue; } // rejected or taken meanwhile
      let res;
      const body = C.finalBody(m.body, s.sign_off);
      // A follow-up goes as a reply in the thread of what was sent to them before; with no thread known, as a new email.
      const thread = m.kind === 'seguimiento' && p ? L.one(`SELECT thread_id FROM ve_messages WHERE _deleted = 0 AND prospect_id = ? AND status = 'enviado'
        AND COALESCE(thread_id, '') <> '' ORDER BY datetime(sent_at) DESC, _id DESC LIMIT 1`, p._id) : null;
      try {
        res = thread
          ? await X.gmailReply({ threadId: thread.thread_id, to, body, account }).catch((e) => {
            if (e.timeout) throw e;
            return X.gmailSend({ to, subject: m.subject, body, account }); // the thread is gone or not allowed: a new email
          })
          : await X.gmailSend({ to, subject: m.subject, body, account });
      } catch (e) {
        fail(m, e.timeout
          ? `Gmail no contestó a tiempo: puede que haya salido o no. Mira en Enviados de Gmail antes de reintentar. (${e.message})`
          : `Gmail no lo aceptó: no salió nada. ${readable(e.message)}`, out, 'enviando');
        continue;
      }
      sent(m, p, to, res, out);
    }
    if (noConnection) {
      note(s, NO_GMAIL);
      return Object.assign(out, { skipped: 'Gmail no está conectado para Ventas', no_connection: true, waiting: noConnection + (plan.wait || 0) });
    }
    if (plan.wait) note(s, `Límite diario de ${Number(s.daily_limit) || 15}: ${plan.wait} aprobados esperan a mañana. Sale desde ${account}.`);
    else if (out.sent.length) note(s, `Sale desde ${account}: ${out.sent.length} ${out.sent.length === 1 ? 'mensaje enviado' : 'mensajes enviados'} en el último envío.`);
    out.account = account;
    return out;
  } finally {
    held.release();
  }
}

/**
 * Why an address may not be written to, beyond cannotSend: someone at it (or
 * this prospect) asked for no more messages — an opt-out is honoured for the
 * address everywhere in Ventas — or its domain receives no mail. null = fine.
 */
async function refused(to, p) {
  const out = L.one(`SELECT name FROM ve_prospects WHERE _deleted = 0 AND COALESCE(unsubscribed_at, '') <> ''
    AND (lower(email) = ? OR lower(contact_email) = ?) LIMIT 1`, to, to);
  if (out || (p && p.unsubscribed_at)) return 'Esta dirección pidió no recibir más mensajes: no se le escribe más.';
  if (await N.mx(to.split('@')[1]) === false) return 'El dominio de esta dirección no recibe correo: no salió nada. Busca otra dirección o descártalo.';
  return null;
}

/**
 * A team approval that may go out under its pitch's rule, or false — and then
 * it is back in Borrador with the reason, waiting for the person.
 */
function teamOk(m, out) {
  const p = m.prospect_id ? L.one('SELECT * FROM ve_prospects WHERE _id = ? AND _deleted = 0', m.prospect_id) : null;
  const pitch = m.pitch_id ? L.one('SELECT * FROM ve_pitches WHERE _id = ? AND _deleted = 0', m.pitch_id) : null;
  const to = C.normEmail(m.to_email);
  const contactedBefore = L.one(`SELECT COUNT(*) AS n FROM ve_messages WHERE _deleted = 0 AND _id <> ?
    AND status IN ('aprobado', 'enviando', 'enviado') AND (lower(to_email) = ? OR prospect_id = ?)`, m._id, to, m.prospect_id || -1).n;
  const why = C.teamCheck(Object.assign({}, m, { to_email: to }), { pitch, prospect: p, contactedBefore });
  if (!why) return true;
  try {
    L.write([{ op: 'update', table: 've_messages', id: m._id, when: { status: 'aprobado' }, data: { status: 'borrador', approved_by: null, approved_at: null, approved_as: null, error: why } }]);
  } catch { /* changed meanwhile */ }
  out.back.push({ id: m._id, why });
  return false;
}

/** A prospect whose first message is approved shows Aprobado; one whose approval was undone goes back to Mensaje. */
function stages() {
  const up = L.all(`SELECT DISTINCT p._id FROM ve_prospects p JOIN ve_messages m ON m.prospect_id = p._id AND m._deleted = 0
    WHERE p._deleted = 0 AND p.stage = 'mensaje' AND m.kind = 'primero' AND m.status = 'aprobado'`);
  const down = L.all(`SELECT p._id FROM ve_prospects p WHERE p._deleted = 0 AND p.stage = 'aprobado'
    AND NOT EXISTS (SELECT 1 FROM ve_messages m WHERE m._deleted = 0 AND m.prospect_id = p._id AND m.kind = 'primero' AND m.status IN ('aprobado', 'enviando', 'enviado'))`);
  const ops = [
    ...up.map((r) => ({ op: 'update', table: 've_prospects', id: r._id, when: { stage: 'mensaje' }, data: { stage: 'aprobado' } })),
    ...down.map((r) => ({ op: 'update', table: 've_prospects', id: r._id, when: { stage: 'aprobado' }, data: { stage: 'mensaje' } })),
  ];
  for (const op of ops) { try { L.write([op]); } catch { /* moved meanwhile */ } }
}

function readable(why) {
  const t = String(why || '');
  if (/not connected|no active connection|connected account|auth/i.test(t)) return `Gmail no está conectado para Ventas: conéctalo en Orchestra (Integraciones) y elígelo en Apps → Ventas, luego reintenta. (${t.slice(0, 200)})`;
  if (/invalid to|recipient|address/i.test(t)) return `La dirección fue rechazada: revísala, edítala y apruébalo de nuevo. (${t.slice(0, 200)})`;
  return `(${t.slice(0, 240)})`;
}

function fail(m, error, out, from) {
  try { L.write([{ op: 'update', table: 've_messages', id: m._id, when: { status: from }, data: { status: 'error', error: error.slice(0, 500) } }]); } catch { /* changed meanwhile */ }
  out.failed.push({ id: m._id, error: error.slice(0, 200) });
}

function sent(m, p, to, res, out) {
  const at = L.sqlNow();
  const ops = [{ op: 'update', table: 've_messages', id: m._id, data: { status: 'enviado', sent_at: at, gmail_message_id: res.id || null, thread_id: res.threadId || null, error: null } }];
  if (p) {
    const by = C.approvedByTeam(m) ? ' (lo envió el equipo, por la regla del pitch)' : '';
    ops.push({ op: 'insert', table: 've_activity', data: { prospect_id: p._id, kind: 'enviado', note: L.clean(`${m.subject} → ${to}${by}`, 300), at, author: m.approved_by || null } });
    if (m.kind !== 'seguimiento' && ['nuevo', 'cualificado', 'mensaje', 'aprobado'].includes(p.stage)) {
      ops.push({ op: 'update', table: 've_prospects', id: p._id, data: { stage: 'enviado' } });
    }
  }
  try {
    L.write(ops);
  } catch {
    // It went out: say so on the message even if the rest could not be written.
    L.write([{ op: 'update', table: 've_messages', id: m._id, data: { status: 'enviado', sent_at: at, gmail_message_id: res.id || null, thread_id: res.threadId || null } }]);
  }
  out.sent.push({ id: m._id, to, gmail: res.id || null });
}

function note(s, text) {
  if (s.send_note === text) return;
  try { L.write([{ op: 'update', table: 've_settings', id: s._id, data: { send_note: text.slice(0, 300) } }]); } catch { /* the note can wait */ }
}

if (require.main === module) {
  const mode = process.argv.includes('--now') ? '--now' : '--auto';
  run(mode).then((r) => L.done(r)).catch((e) => { L.done({ ok: false, error: e.message }); process.exitCode = 1; });
}

module.exports = { run };
