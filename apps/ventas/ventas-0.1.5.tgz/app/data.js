// What Ventas reads, the only things it writes, and what the screens share.
// Tables give rows, views do the joins, and every write is a declared action
// (A). Searching, reading signals and sending run as processes on the
// instance; the screens start them and show what they left. vecore.js holds
// the rules the scripts share.
import './vecore.js';

export const C = self.VeCore;
const { el, fmt, router } = Orch;

export const T = {
  settings: 've_settings', verticals: 've_verticals', useCases: 've_use_cases', pitches: 've_pitches',
  searches: 've_searches', prospects: 've_prospects', messages: 've_messages', activity: 've_activity',
};
export const V = { prospects: 'prospects_list', messages: 'messages_queue', searches: 'searches_list', pitches: 'pitches_list', counts: 'pipeline_counts' };
export const A = {
  settings: 'update_settings', sendMode: 'set_send_mode',
  addVertical: 'add_vertical', editVertical: 'edit_vertical', addUseCase: 'add_use_case', editUseCase: 'edit_use_case', addPitch: 'add_pitch', editPitch: 'edit_pitch',
  addSearch: 'add_search', editSearch: 'edit_search', searchOn: 'turn_search_on', searchOff: 'turn_search_off', searchNow: 'search_now',
  addProspect: 'add_prospect', editProspect: 'edit_prospect', signalsAgain: 'check_signals_again', fitYes: 'set_fit_yes', fitNo: 'set_fit_no',
  contact: 'set_contact', nextStep: 'set_next_step', note: 'add_note',
  draft: 'draft_message', followUp: 'draft_follow_up', editMessage: 'edit_message', approve: 'approve_message', reject: 'reject_message',
  retry: 'retry_message', backToDraft: 'back_to_draft', unapprove: 'unapprove_message', toDraft: 'return_approved_to_draft', markSent: 'mark_sent_by_hand',
  replied: 'mark_replied', call: 'mark_call_booked', discard: 'mark_discarded', toCrm: 'mark_handed_to_crm',
};

/** Run a declared action, say how it went, and hand back its result (null on failure). */
export async function act(name, params, done) {
  try {
    const r = await Orch.action(name, params);
    if (done) Orch.toast(done);
    return r || {};
  } catch (e) {
    Orch.toast(e.status === 409 ? 'Ha cambiado mientras tanto: vuelve a mirarlo.' : (e.message || 'No ha funcionado.'), { error: true });
    return null;
  }
}

/** Where Ventas is managed in Orchestra (its settings and connection), or null. */
export const manage = (section) => (Orch.manageUrl ? Orch.manageUrl(section) : Promise.resolve(null));

let kept = null;
/** The one settings row. */
export async function settings(fresh) {
  if (!kept || fresh) kept = (await Orch.db.list(T.settings, { sort: '_id:asc', limit: 1 })).rows[0] || {};
  return kept;
}
export const live = (s) => s.send_mode === 'live';

// States: gold waits on a person, green done, red broken.
const TONE = {
  borrador: 'warn', aprobado: 'accent', enviando: 'accent', enviado: 'good', rechazado: '', error: 'bad',
  nuevo: '', cualificado: 'accent', mensaje: 'warn', respondio: 'good', llamada: 'good', crm: 'good', descartado: '',
  pending: 'warn', yes: 'good', no: '', draft: 'warn', active: 'good',
};
const WORD = Object.assign({}, C.MESSAGE_STATUS, C.STAGE_LABEL, { pending: 'Por decidir', yes: 'Encaja', no: 'No encaja', draft: 'Borrador', active: 'Activa', off: 'Inactiva' });
export const badge = (key, tone) => el('span', { class: `oc-badge${(tone || TONE[key]) ? ` oc-badge--${tone || TONE[key]}` : ''}` }, WORD[key] || key || '—');

/** '2026-10-03 10:00:00' (UTC, as rows are stamped), ISO, or a bare day, as a Date. */
export function when(v) {
  if (!v) return null;
  const s = String(v).trim();
  const d = new Date(/^\d{4}-\d\d-\d\d$/.test(s) ? `${s}T12:00:00Z` : /[zZ]|[+-]\d\d:?\d\d$/.test(s) ? s : `${s.replace(' ', 'T')}Z`);
  return Number.isNaN(d.getTime()) ? null : d;
}
export const ago = (v) => (v ? fmt.ago(when(v).toISOString()) : '—');
export const dayOf = (v) => { const d = when(v); return d ? d.toLocaleDateString('es', { day: 'numeric', month: 'short' }) : '—'; };
export const stamp = (v) => { const d = when(v); return d ? d.toLocaleString('es', { dateStyle: 'medium', timeStyle: 'short' }) : '—'; };
export const today = (offset = 0) => new Date(Date.now() + offset * 86400000).toISOString().slice(0, 10);
export const plural = (n, one, many) => `${fmt.number(n || 0)} ${Number(n) === 1 ? one : many}`;

/** A dialog that closes when the screen changes. */
export function sheet(content, opts) {
  const d = Orch.dialog(content, opts);
  window.addEventListener('hashchange', () => { try { d.close(); } catch { /* already closed */ } }, { once: true });
  return d;
}

export function field(label, control, help) {
  return el('label', { class: 'oc-field' }, [el('span', { class: 'oc-label' }, label), control, help ? el('span', { class: 'oc-help' }, help) : null]);
}
export const input = (value, attrs = {}) => el('input', Object.assign({ class: 'oc-input', value: value === null || value === undefined ? '' : String(value) }, attrs));
export const area = (value, rows = 4, attrs = {}) => el('textarea', Object.assign({ class: 'oc-textarea', rows: String(rows) }, attrs), value || '');
export function select(options, value, attrs = {}) {
  return el('select', Object.assign({ class: 'oc-select' }, attrs), options.map((o) => {
    const [v, label] = Array.isArray(o) ? o : [o, o];
    return el('option', { value: v === null ? '' : String(v), selected: String(v === null ? '' : v) === String(value === null || value === undefined ? '' : value) }, label);
  }));
}

/** A form in a dialog: fields, one primary button, the action's result. */
export function formDialog(title, fields, submit, label = 'Guardar') {
  const save = el('button', { class: 'oc-btn oc-btn--primary', type: 'submit' }, label);
  const form = el('form', { class: 'oc-stack ve-form' }, [...fields, el('div', { class: 'oc-row oc-row--end' }, save)]);
  const d = sheet(form, { title });
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    save.disabled = true;
    const ok = await submit();
    save.disabled = false;
    if (ok) d.close();
  });
  return d;
}

/** The verticals to choose from. */
export async function verticals() {
  const r = await Orch.db.list(T.verticals, { sort: 'name:asc', limit: 200 });
  return r.rows || [];
}

/** A stat-strip cell. */
export const metric = (label, value, note, href) => el('div', { class: 'oc-metric oc-metric--compact' }, [
  el('span', { class: 'oc-kpi__label' }, label), el('span', { class: 'oc-kpi__value' }, value),
  href ? router.link(href, note, { class: 'oc-metric__link' }) : el('span', { class: 'oc-kpi__delta' }, note || ''),
]);

/** A screen's head: the title, one line on what it is for, its tools at the right. */
export function head(title, lede, tools) {
  return el('header', { class: 've-head' }, [
    el('div', { class: 'oc-stack oc-stack--tight' }, [el('h1', { class: 'oc-h1 oc-h1--collection' }, title), lede ? el('p', { class: 'oc-lede' }, lede) : null]),
    tools ? el('div', { class: 'oc-row' }, tools) : null,
  ]);
}

/** A card of thin rows with a head; `empty` when there are none. */
export function section(title, help, rows, empty, tools) {
  return el('section', { class: 'oc-card oc-card--pad0' }, [
    el('div', { class: 've-panel__head' }, [
      el('div', { class: 'oc-stack oc-stack--tight' }, [el('h2', { class: 'oc-h2' }, title), help ? el('p', { class: 'oc-help' }, help) : null]),
      tools || null,
    ]),
    rows && rows.length ? el('ul', { class: 've-rows' }, rows) : el('p', { class: 've-none oc-muted' }, empty),
  ]);
}

/** The pipeline's counts in one row (sql/pipeline_counts.sql): webs read, prospects to decide, drafts. */
export async function counts() {
  const r = await Orch.db.view(V.counts, { limit: 1 });
  return (r && r.rows && r.rows[0]) || {};
}

/**
 * "Qué pasa ahora": the three steps (C.nextSteps), each with its number, what
 * there is and who does it when. On Hoy the third one scrolls to the messages
 * to approve; elsewhere it opens Hoy.
 */
export function nextStrip(c, { onHoy = false } = {}) {
  return el('section', { class: 've-next', 'aria-label': 'Qué pasa ahora' }, [
    el('h2', { class: 've-next__head oc-small' }, 'Qué pasa ahora'),
    el('ol', { class: 've-next__steps' }, C.nextSteps(c).map((s) => {
      let line = el('strong', { class: 've-next__line' }, s.line);
      if (s.to) {
        line = onHoy
          ? el('a', { class: 've-next__line', href: '#', onClick: (e) => { e.preventDefault(); const t = document.getElementById('ve-aprobar'); if (t) t.scrollIntoView({ behavior: 'smooth', block: 'start' }); } }, s.line)
          : router.link('/', s.line, { class: 've-next__line' });
      }
      return el('li', { class: 've-next__step' }, [
        el('span', { class: 've-next__n', 'aria-hidden': 'true' }, String(s.n)),
        el('div', { class: 've-next__body' }, [
          el('span', { class: 've-next__title' }, s.title),
          line,
          el('span', { class: 'oc-small oc-muted' }, s.who),
          s.note ? el('span', { class: 'oc-small ve-next__note' }, s.note) : null,
        ]),
      ]);
    })),
  ]);
}

/** A prospect's one state (C.prospectState) as a badge, its reason on hover. */
export function stateBadge(p) {
  const s = C.prospectState(p);
  const tone = s.tone === null ? TONE[s.key] : s.tone;
  return el('span', { class: `oc-badge${tone ? ` oc-badge--${tone}` : ''}`, title: s.title || null }, s.label);
}

/** The signals a prospect's site showed, as chips (none read yet, or why it was not read). */
export function signalChips(raw, checkedAt) {
  const s = typeof raw === 'string' ? (() => { try { return JSON.parse(raw); } catch { return {}; } })() : (raw || {});
  if (!checkedAt) return el('span', { class: 'oc-small oc-muted' }, 'Señales: por leer');
  const on = C.signalsOn(s);
  if (!on.length) return el('span', { class: 'oc-small oc-muted' }, s.error ? 'Señales: web no leída' : 'Sin señales');
  return el('span', { class: 've-chips' }, on.map((k) => el('span', { class: `ve-chip${k === 'ghl' || k === 'meta_ads' || k === 'google_ads' ? ' ve-chip--hot' : ''}` }, C.SIGNAL_LABEL[k])));
}

/** Every approved message back to draft, in pages of 500 (the bulk limit); false when one page failed. */
async function toDraft() {
  for (let page = 0; page < 20; page += 1) {
    const r = await Orch.db.list(T.messages, { filter: { status: 'aprobado' }, sort: '_id:asc', limit: 500 });
    const ids = (r.rows || []).map((m) => m._id);
    if (!ids.length) return true;
    if (!(await act(A.toDraft, { ids }))) return false;
    if (ids.length < 500) return true;
  }
  return false;
}

/** The banner on every screen while rehearsal is on, and the switch (two steps to go live). */
export function modeBanner(s, again) {
  const on = !live(s);
  const b = el('button', { type: 'button', class: `oc-btn oc-btn--sm${on ? ' oc-btn--primary' : ''}` }, on ? 'Pasar a envío real…' : 'Volver a ensayo');
  b.addEventListener('click', async () => {
    if (!on) { if (await act(A.sendMode, { id: s._id, send_mode: 'rehearsal' }, 'Ensayo: a partir de ahora no sale nada.')) again(); return; }
    const waiting = Number(await Orch.db.count(T.messages, { filter: { status: 'aprobado' } })) || 0;
    // Approved messages that waited in rehearsal would go out minutes after the switch: ask what to do
    // with them, back to draft by default (C.goLiveQuestion / C.goLiveSteps, tested in core.test.js).
    const q = C.goLiveQuestion(waiting);
    let choice = q ? q.choices.find((c) => c.default).key : null;
    const choices = q ? el('fieldset', { class: 've-choices' }, [
      el('legend', { class: 've-warn' }, q.ask),
      ...q.choices.map((c) => {
        const r = el('input', { type: 'radio', name: 've-golive', value: c.key, checked: !!c.default });
        r.addEventListener('change', () => { if (r.checked) choice = c.key; });
        return el('label', { class: 've-check' }, [r, el('span', c.label)]);
      }),
    ]) : null;
    const ack = el('input', { type: 'checkbox' });
    const go = el('button', { type: 'button', class: 'oc-btn oc-btn--primary', disabled: true }, 'Pasar a envío real');
    ack.addEventListener('change', () => { go.disabled = !ack.checked; });
    const body = el('div', { class: 'oc-stack' }, [
      el('p', `A partir de ahora, cada mensaje que apruebes sale desde la cuenta de Gmail elegida para Ventas, como mucho ${Number(s.daily_limit) || 15} al día.`),
      choices,
      el('label', { class: 've-check' }, [ack, el('span', 'Entiendo: lo aprobado llegará a personas reales.')]),
      el('div', { class: 'oc-row' }, go),
    ]);
    const d = sheet(body, { title: '¿Pasar a envío real?' });
    go.addEventListener('click', async () => {
      go.disabled = true;
      for (const step of C.goLiveSteps(waiting, choice)) {
        if (step === 'to_draft' && !(await toDraft())) { go.disabled = false; return; }
        if (step === 'live') {
          const ok = await act(A.sendMode, { id: s._id, send_mode: 'live' }, choice === 'draft' && waiting ? 'Envío real. Los aprobados volvieron a borrador: revísalos en Hoy.' : 'Envío real: lo aprobado sale.');
          d.close();
          if (ok) again();
        }
      }
    });
  });
  return el('div', { class: `ve-mode${on ? ' ve-mode--rehearsal' : ''}` }, [
    el('div', { class: 'oc-stack oc-stack--tight' }, [
      el('strong', on ? 'Ensayo' : `Envío real · hasta ${Number(s.daily_limit) || 15} al día`),
      el('span', { class: 'oc-small' }, on ? 'Lo que apruebas queda listo, pero no sale nada. Cambia el modo cuando quieras (aquí o en Ajustes).' : (s.send_note || 'Lo que apruebas sale desde Gmail en unos minutos.')),
    ]),
    b,
  ]);
}
