SELECT pi._id AS _id, pi.vertical_id AS vertical_id, v.name AS vertical, pi.use_case_id AS use_case_id, u.name AS use_case,
  pi.angle AS angle, pi.opening AS opening, pi.case_to_cite AS case_to_cite, pi.offer AS offer, pi.channel AS channel, pi.status AS status
FROM ve_pitches pi
LEFT JOIN ve_verticals v ON v._id = pi.vertical_id AND v._deleted = 0
LEFT JOIN ve_use_cases u ON u._id = pi.use_case_id AND u._deleted = 0
WHERE pi._deleted = 0
