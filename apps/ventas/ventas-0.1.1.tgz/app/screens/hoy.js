// Hoy: what waits for you. The messages the agent drafted (approve, edit or
// reject each one), the ones that could not go out, the prospects that
// replied, and the next steps due — with the sending mode always in view.
import { V, A, T, act, badge, dayOf, head, metric, modeBanner, section, settings, signalChips, live, plural } from '../data.js';
import { openMessage } from './mensaje.js';

const { el, router } = Orch;

export function render() {
  Orch.load('view', async () => {
    const s = await settings(true);
    const week = new Date(Date.now() - 7 * 86400000).toISOString().slice(0, 10);
    const [drafts, failed, ready, replied, due, newWeek, calls] = await Promise.all([
      Orch.db.view(V.messages, { filter: { status: 'borrador' }, sort: '_id:asc', limit: 100 }),
      Orch.db.view(V.messages, { filter: { status: 'error' }, sort: '_id:desc', limit: 50 }),
      Orch.db.count(T.messages, { filter: { status: 'aprobado' } }),
      Orch.db.view(V.prospects, { filter: { stage: 'respondio' }, sort: 'updated_at:desc', limit: 50 }),
      Orch.db.view(V.prospects, { filter: { due_state: ['overdue', 'today'] }, sort: 'next_step_at:asc', limit: 50 }),
      Orch.db.count(T.prospects, { filter: { _created_at: { gte: week } } }),
      Orch.db.count(T.prospects, { filter: { stage: 'llamada' } }),
    ]);
    const again = () => render();
    const d = drafts.rows || [];
    const r = replied.rows || [];
    return el('div', { class: 'oc-stack oc-stack--loose' }, [
      head('Hoy', 'Lo que espera tu visto bueno: los mensajes del agente, las respuestas y los próximos pasos.', null),
      modeBanner(s, again),
      el('div', { class: 'oc-metrics' }, [
        metric('Nuevos esta semana', String(newWeek || 0), 'prospectos', '/prospectos/nuevo'),
        metric('Por aprobar', String(d.length), (failed.rows || []).length ? `${(failed.rows || []).length} con error` : 'sin errores'),
        metric('Respuestas', String(r.length), 'por atender', '/prospectos/respondio'),
        metric('Llamadas', String(calls || 0), 'agendadas', '/prospectos/llamada'),
      ]),
      section('Mensajes por aprobar', 'Borradores del agente a partir del pitch de cada vertical. Nada sale sin tu aprobación.',
        d.map((m) => messageRow(m, again)), 'No hay ningún mensaje esperando.'),
      (failed.rows || []).length ? section('No salieron', 'Mensajes aprobados que Gmail no aceptó o que pudieron salir o no: revísalos uno a uno.',
        failed.rows.map((m) => messageRow(m, again))) : null,
      Number(ready) ? el('p', { class: 'oc-help' }, live(s)
        ? `${plural(ready, 'mensaje aprobado sale', 'mensajes aprobados salen')} en los próximos minutos (o mañana, si se llegó al límite diario).`
        : `${plural(ready, 'mensaje aprobado está listo', 'mensajes aprobados están listos')}: en ensayo no sale ninguno.`) : null,
      section('Respondieron', 'Prospectos que contestaron. El agente prepara el seguimiento; cuando se agenda una llamada, márcalo y el equipo lo pasa al CRM.',
        r.map((p) => replyRow(p, again)), 'Nadie ha respondido todavía.'),
      section('Próximos pasos', 'Lo que tocaba hacer hoy o ya se ha pasado.', (due.rows || []).map(stepRow), 'No hay nada para hoy.'),
    ]);
  });
}

function messageRow(m, again) {
  const open = el('button', { class: 'oc-btn oc-btn--sm', type: 'button' }, m.status === 'error' ? 'Arreglar' : 'Revisar');
  open.addEventListener('click', () => openMessage(m._id, again));
  return el('li', { class: 've-row' }, [
    el('div', { class: 've-row__main' }, [
      el('span', { class: 've-row__title' }, m.subject || '(sin asunto)'),
      el('span', { class: 'oc-small oc-muted' }, [m.prospect ? router.link(`/prospecto/${m.prospect_id}`, m.prospect) : '—', m.vertical ? ` · ${m.vertical}` : '', m.to_email ? ` · ${m.to_email}` : '']),
      m.status === 'error' && m.error ? el('span', { class: 'oc-help' }, m.error) : m.fit_reason ? el('span', { class: 'oc-help' }, m.fit_reason) : null,
    ]),
    el('span', { class: 'oc-small oc-muted' }, m.kind === 'seguimiento' ? 'seguimiento' : 'primero'),
    badge(m.status),
    open,
  ]);
}

function replyRow(p, again) {
  const call = el('button', { class: 'oc-btn oc-btn--sm oc-btn--primary', type: 'button' }, 'Llamada agendada');
  call.addEventListener('click', async () => { call.disabled = true; if (await act(A.call, { id: p._id, note: 'Llamada agendada' }, 'Marcado: llamada agendada.')) again(); call.disabled = false; });
  return el('li', { class: 've-row' }, [
    el('div', { class: 've-row__main' }, [
      router.link(`/prospecto/${p._id}`, p.name, { class: 've-row__title' }),
      el('span', { class: 'oc-small oc-muted' }, [p.vertical || '—', p.contact_name ? ` · ${p.contact_name}` : '', p.city ? ` · ${p.city}` : '']),
    ]),
    signalChips(p.signals, p.signals_checked_at),
    badge(p.stage),
    call,
  ]);
}

function stepRow(p) {
  return el('li', { class: 've-row' }, [
    el('div', { class: 've-row__main' }, [
      router.link(`/prospecto/${p._id}`, p.next_step || 'Próximo paso', { class: 've-row__title' }),
      el('span', { class: 'oc-small oc-muted' }, [p.name, p.vertical ? ` · ${p.vertical}` : '']),
    ]),
    el('span', { class: 'oc-value' }, dayOf(p.next_step_at)),
    p.due_state === 'overdue' ? badge('Atrasado', 'warn') : badge('Hoy', 'accent'),
    badge(p.stage),
  ]);
}
