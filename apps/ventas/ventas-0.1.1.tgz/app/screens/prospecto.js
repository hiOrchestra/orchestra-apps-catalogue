// One prospect: who they are, what their website shows (the signals), whether
// they fit and why, the person to talk to, every message and what happened.
// Every way forward is a button here: fit or not, replied, call booked,
// handed to the CRM, discarded, the next step and a note.
import { C, T, A, act, area, badge, field, formDialog, input, select, stamp, dayOf, today, verticals, settings } from '../data.js';
import { openMessage } from './mensaje.js';

const { el, router } = Orch;
const KIND = {
  encaja: 'Encaja', no_encaja: 'No encaja', nota: 'Nota', enviado: 'Enviado', respuesta: 'Respondió', llamada: 'Llamada',
  descartado: 'Descartado', al_crm: 'Al CRM',
};

export function render(params = {}) {
  const id = Number(params.id);
  Orch.load('view', async () => {
    const p = await Orch.db.get(T.prospects, id);
    if (!p) return el('div', { class: 'oc-state' }, [el('p', 'Ese prospecto ya no está.'), router.link('/prospectos', 'Ir a Prospectos')]);
    const [vs, msgs, acts] = await Promise.all([
      verticals(),
      Orch.db.list(T.messages, { filter: { prospect_id: id }, sort: '_id:desc', limit: 50 }),
      Orch.db.list(T.activity, { filter: { prospect_id: id }, sort: '_id:desc', limit: 100 }),
      settings(),
    ]);
    const v = vs.find((x) => x._id === p.vertical_id);
    const again = () => render(params);
    const sig = (() => { try { return JSON.parse(p.signals || '{}'); } catch { return {}; } })();
    return el('div', { class: 'oc-stack oc-stack--loose' }, [
      el('header', { class: 've-head' }, [
        el('div', { class: 'oc-stack oc-stack--tight' }, [
          router.link('/prospectos', '← Prospectos', { class: 'oc-small' }),
          el('h1', { class: 'oc-h1 ve-title' }, p.name),
          el('div', { class: 'oc-row' }, [badge(p.stage), badge(p.fit), el('span', { class: 'oc-small oc-muted' }, [v ? v.name : 'Sin vertical', p.city ? ` · ${p.city}` : ''])]),
        ]),
        el('div', { class: 'oc-row ve-actions' }, actions(p, vs, again)),
      ]),
      el('div', { class: 've-two' }, [
        el('div', { class: 'oc-stack' }, [
          card('Por qué encaja', [p.fit_reason ? el('p', { class: 've-text' }, p.fit_reason) : el('p', { class: 'oc-muted' }, p.fit === 'pending' ? 'El agente aún no lo ha decidido.' : '—'),
            p.next_step ? el('p', { class: 'oc-help' }, `Siguiente: ${p.next_step}${p.next_step_at ? ` (${dayOf(p.next_step_at)})` : ''}`) : null]),
          card('Señales de su web', signalsList(p, sig, again)),
          card('Mensajes', msgs.rows && msgs.rows.length ? el('ul', { class: 've-rows ve-rows--flush' }, msgs.rows.map((m) => el('li', { class: 've-row ve-row--3' }, [
            el('div', { class: 've-row__main' }, [el('span', { class: 've-row__title' }, m.subject || '(sin asunto)'), el('span', { class: 'oc-small oc-muted' }, `${m.kind === 'seguimiento' ? 'Seguimiento' : 'Primer mensaje'} · ${stamp(m.sent_at || m._created_at)}`)]),
            badge(m.status),
            el('button', { class: 'oc-btn oc-btn--sm', type: 'button', onClick: () => openMessage(m._id, again) }, m.status === 'borrador' ? 'Revisar' : 'Abrir'),
          ]))) : el('p', { class: 'oc-muted' }, 'Todavía no hay mensajes. El agente escribe el primero cuando decide que encaja.')),
        ]),
        el('div', { class: 'oc-stack' }, [
          card('Datos', el('dl', { class: 've-facts' }, facts([
            ['Web', p.website ? el('a', { href: p.website, target: '_blank', rel: 'noopener' }, C.domainOf(p.website)) : '—'],
            ['Teléfono', p.phone || '—'], ['Correo', p.email || '—'], ['Dirección', p.address || '—'],
            ['Origen', p.source === 'osm' ? 'OpenStreetMap' : p.source === 'google_places' ? 'Google Places' : p.source === 'manual' ? 'A mano' : (p.source || '—')],
          ]))),
          card('Con quién hablar', el('dl', { class: 've-facts' }, facts([
            ['Nombre', p.contact_name || '—'], ['Cargo', p.contact_role || '—'], ['Correo', p.contact_email || '—'],
          ]))),
          card('Historial', acts.rows && acts.rows.length ? el('ul', { class: 've-timeline' }, acts.rows.map((a) => el('li', { class: 've-timeline__row' }, [
            el('span', { class: 'oc-value oc-muted' }, stamp(a.at || a._created_at)),
            el('span', { class: 'oc-small' }, KIND[a.kind] || a.kind),
            el('span', { class: 've-timeline__what' }, [a.note || '', a.author ? el('span', { class: 'oc-small oc-muted' }, String(a.author).startsWith('agent:') ? ' · el agente' : ` · ${a.author}`) : null]),
          ]))) : el('p', { class: 'oc-muted' }, 'Nada todavía.')),
        ]),
      ]),
    ]);
  });
}

const card = (title, body) => el('section', { class: 'oc-card oc-stack' }, [el('h2', { class: 'oc-h2' }, title), body]);
const facts = (pairs) => pairs.flatMap(([k, v]) => [el('dt', k), el('dd', v)]);

function signalsList(p, sig, again) {
  const again2 = el('button', { class: 'oc-btn oc-btn--sm oc-btn--ghost', type: 'button', onClick: async () => { if (await act(A.signalsAgain, { id: p._id }, 'Se leerá su web en unos minutos.')) again(); } }, 'Leer de nuevo');
  if (!p.signals_checked_at) return el('div', { class: 'oc-stack' }, [el('p', { class: 'oc-muted' }, p.website ? 'Su web se lee en la próxima hora.' : 'Sin web: no hay señales que leer.'), p.website ? again2 : null]);
  const yes = (k) => el('li', { class: `ve-signal${C.signalsOn(sig).includes(k) ? ' ve-signal--on' : ''}` }, [el('span', C.SIGNAL_LABEL[k]), el('span', { class: 'oc-value' }, C.signalsOn(sig).includes(k) ? 'sí' : 'no')]);
  const keys = ['ghl', 'meta_pixel', 'google_ads', 'gtag', 'lead_form', 'whatsapp', ...(sig.meta_ads ? ['meta_ads'] : [])];
  return el('div', { class: 'oc-stack' }, [
    sig.error ? el('p', { class: 've-error' }, sig.error) : el('ul', { class: 've-signals' }, keys.map(yes)),
    sig.meta_ads && sig.meta_ads.active ? el('p', { class: 'oc-help' }, `Meta: ${sig.meta_ads.active} anuncios activos de ${(sig.meta_ads.pages || []).join(', ')} (coincidencia por nombre).`) : null,
    (sig.emails || []).length ? el('p', { class: 'oc-help' }, ['Correos en la web: ', sig.emails.join(', ')]) : null,
    (sig.phones || []).length ? el('p', { class: 'oc-help' }, ['Teléfonos en la web: ', sig.phones.map((x) => `+${x}`).join(', ')]) : null,
    el('div', { class: 'oc-row' }, [el('span', { class: 'oc-small oc-muted' }, `Leída ${stamp(p.signals_checked_at)}`), again2]),
  ]);
}

function actions(p, vs, again) {
  const btn = (label, onClick, primary) => el('button', { class: `oc-btn oc-btn--sm${primary ? ' oc-btn--primary' : ''}`, type: 'button', onClick }, label);
  const withNote = (title, action, said, label, extra = {}) => () => {
    const note = area('', 3, { maxlength: '600' });
    formDialog(title, [field('Nota', note, 'Queda en el historial.')], async () => {
      const ok = await act(action, Object.assign({ id: p._id, note: note.value.trim() || null }, extra), said);
      if (ok) again();
      return ok;
    }, label);
  };
  const fit = (yes) => () => {
    const why = area(p.fit_reason || '', 3, { required: true, maxlength: '400' });
    formDialog(yes ? 'Encaja' : 'No encaja', [field('Por qué', why, 'Una línea: lo que viste.')], async () => {
      if (!why.value.trim()) return false;
      const ok = await act(yes ? A.fitYes : A.fitNo, { id: p._id, fit_reason: why.value.trim() }, yes ? 'Cualificado.' : 'Descartado: no encaja.');
      if (ok) again();
      return ok;
    }, 'Guardar');
  };
  const next = () => {
    const what = input(p.next_step || '', { maxlength: '200' });
    const on = input(p.next_step_at ? String(p.next_step_at).slice(0, 10) : today(2), { type: 'date' });
    formDialog('Próximo paso', [field('Qué', what), field('Cuándo', on)], async () => {
      const ok = await act(A.nextStep, { id: p._id, next_step: what.value.trim() || null, next_step_at: what.value.trim() ? on.value : null }, 'Guardado.');
      if (ok) again();
      return ok;
    });
  };
  const contact = () => {
    const name = input(p.contact_name || '', { maxlength: '120' });
    const role = input(p.contact_role || '', { maxlength: '120' });
    const mail = input(p.contact_email || '', { type: 'email', maxlength: '160' });
    formDialog('Con quién hablar', [field('Nombre', name), field('Cargo', role), field('Correo', mail)], async () => {
      const ok = await act(A.contact, { id: p._id, contact_name: name.value.trim() || null, contact_role: role.value.trim() || null, contact_email: C.isEmail(mail.value) ? C.normEmail(mail.value) : null }, 'Guardado.');
      if (ok) again();
      return ok;
    });
  };
  const edit = () => {
    const name = input(p.name, { required: true, maxlength: '160' });
    const website = input(p.website || '', { maxlength: '300' });
    const phone = input(p.phone || '', { maxlength: '40' });
    const email = input(p.email || '', { type: 'email', maxlength: '160' });
    const address = input(p.address || '', { maxlength: '200' });
    const city = input(p.city || '', { maxlength: '80' });
    const vertical = select([['', '—'], ...vs.map((x) => [x._id, x.name])], p.vertical_id);
    formDialog('Editar', [field('Nombre', name), field('Web', website), field('Teléfono', phone), field('Correo', email), field('Dirección', address), field('Ciudad', city), field('Vertical', vertical)], async () => {
      const ok = await act(A.editProspect, { id: p._id, name: name.value.trim(), website: C.siteUrl(website.value) || null, phone: phone.value.trim() || null,
        email: C.isEmail(email.value) ? C.normEmail(email.value) : null, address: address.value.trim() || null, city: city.value.trim() || null, vertical_id: vertical.value ? Number(vertical.value) : null }, 'Guardado.');
      if (ok) again();
      return ok;
    });
  };
  const out = [];
  if (p.fit !== 'yes') out.push(btn('Encaja…', fit(true), p.fit === 'pending'));
  if (p.stage !== 'descartado') out.push(btn('No encaja…', fit(false)));
  if (p.stage === 'enviado') out.push(btn('Respondió…', withNote('Respondió', A.replied, 'Marcado: respondió.', 'Guardar'), true));
  if (['respondio', 'enviado'].includes(p.stage)) out.push(btn('Llamada agendada…', withNote('Llamada agendada', A.call, 'Marcado: llamada agendada.', 'Guardar'), p.stage === 'respondio'));
  if (p.stage === 'llamada') out.push(btn('Pasó al CRM…', withNote('Pasó al CRM', A.toCrm, 'Marcado: en el CRM.', 'Guardar'), true));
  out.push(btn('Próximo paso', next), btn('Contacto', contact), btn('Nota', withNote('Nota', A.note, 'Anotado.', 'Anotar', { prospect_id: p._id })), btn('Editar', edit));
  if (!['descartado', 'crm'].includes(p.stage)) out.push(btn('Descartar…', withNote('Descartar', A.discard, 'Descartado.', 'Descartar')));
  return out;
}
