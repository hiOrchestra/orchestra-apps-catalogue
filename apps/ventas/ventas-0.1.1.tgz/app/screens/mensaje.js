// One message, in its own panel, with every way out of its state:
//   borrador   edit it, approve it, or reject it (with a reason the agent reads)
//   aprobado   ready: it goes out while sending is live, or waits in rehearsal; undo the approval
//   error      what happened in plain words, then retry / back to draft / mark as sent
// Nothing leaves without the Approve button, pressed by a person.
import { C, T, A, act, badge, field, input, area, sheet, stamp, settings, live } from '../data.js';

const { el, router } = Orch;

export async function openMessage(id, after) {
  const row = await Orch.db.get(T.messages, id);
  if (!row) { Orch.toast('Ese mensaje ya no está.', { error: true }); return; }
  const s = await settings(true);
  const box = el('div', { class: 'oc-stack' });
  const d = sheet(box, { title: row.subject || 'Mensaje', drawer: true });
  const done = () => { d.close(); if (after) after(); };
  Orch.mount(box, await panel(row, s, done));
}

async function panel(m, s, done) {
  const p = m.prospect_id ? await Orch.db.get(T.prospects, m.prospect_id) : null;
  const pitch = m.pitch_id ? await Orch.db.get(T.pitches, m.pitch_id) : null;
  const top = el('div', { class: 'oc-stack oc-stack--tight' }, [
    el('div', { class: 'oc-row' }, [badge(m.status), el('span', { class: 'oc-small oc-muted' }, m.kind === 'seguimiento' ? 'Seguimiento' : 'Primer mensaje')]),
    el('p', { class: 'oc-small oc-muted' }, [
      p ? ['Para ', router.link(`/prospecto/${p._id}`, p.name)] : 'Sin prospecto',
      p && p.contact_name ? ` (${p.contact_name}${p.contact_role ? `, ${p.contact_role}` : ''})` : '',
      ` · escrito por ${String(m.created_by || '').startsWith('agent:') ? 'el agente' : (m.created_by || '—')} ${stamp(m._created_at)}`,
    ]),
    p && p.fit_reason ? el('p', { class: 'oc-help' }, ['Por qué encaja: ', p.fit_reason]) : null,
    pitch ? el('p', { class: 'oc-help' }, ['Pitch: ', pitch.angle || '—']) : null,
  ]);
  if (m.status === 'borrador') return draft(m, p, s, top, done);
  if (m.status === 'error') return failed(m, top, done);
  const say = {
    aprobado: live(s) ? 'Aprobado: sale desde Gmail en unos minutos (o al día siguiente si se alcanzó el límite diario).' : 'Aprobado y listo. Ventas está en ensayo: no sale hasta pasar a envío real.',
    enviando: 'Saliendo ahora.', enviado: `Enviado ${stamp(m.sent_at)}.`, rechazado: `Rechazado${m.note ? `: ${m.note}` : ''}. No se envió.`,
  }[m.status] || '';
  const undo = m.status === 'aprobado' ? el('button', { class: 'oc-btn oc-btn--ghost', type: 'button', onClick: async () => { if (await act(A.unapprove, { id: m._id }, 'Vuelve a borrador.')) done(); } }, 'Deshacer la aprobación') : null;
  return el('div', { class: 'oc-stack' }, [top, el('p', { class: 'oc-help' }, say), readOnly(m, s), undo ? el('div', { class: 'oc-row' }, undo) : null]);
}

function readOnly(m, s) {
  return el('div', { class: 'oc-stack oc-stack--tight ve-mail' }, [
    el('p', { class: 'oc-eyebrow' }, `Para ${m.to_email || '—'}`), el('p', { class: 've-mail__subject' }, m.subject || '—'),
    el('pre', { class: 've-mail__body' }, C.finalBody(m.body, s.sign_off)),
  ]);
}

function editors(m, p) {
  const to = input(m.to_email || (p && (p.contact_email || p.email)) || '', { type: 'email', required: true });
  const subject = input(m.subject, { required: true, maxlength: '160' });
  const body = area(m.body, 12, { required: true });
  const values = () => ({ id: m._id, to_email: C.normEmail(to.value), subject: subject.value.trim(), body: body.value.replace(/\r\n/g, '\n').trim() });
  const valid = (v) => {
    if (!C.isEmail(v.to_email)) { Orch.toast('La dirección no parece correcta.', { error: true }); return false; }
    if (!v.subject || !v.body) { Orch.toast('Le falta el asunto o el texto.', { error: true }); return false; }
    return true;
  };
  return { fields: [field('Para', to), field('Asunto', subject), field('Mensaje', body, 'Texto plano. La firma de Ajustes se añade debajo al enviarlo.')], values, valid };
}

function draft(m, p, s, top, done) {
  const e = editors(m, p);
  const approve = el('button', { class: 'oc-btn oc-btn--primary', type: 'button' }, live(s) ? 'Aprobar y enviar' : 'Aprobar');
  const save = el('button', { class: 'oc-btn', type: 'button' }, 'Guardar cambios');
  const reject = el('button', { class: 'oc-btn oc-btn--ghost', type: 'button' }, 'Rechazar…');
  approve.addEventListener('click', async () => {
    const v = e.values();
    if (!e.valid(v)) return;
    approve.disabled = true;
    if (await act(A.approve, v, live(s) ? 'Aprobado: sale en unos minutos.' : 'Aprobado. En ensayo, queda listo sin salir.')) done();
    approve.disabled = false;
  });
  save.addEventListener('click', async () => { const v = e.values(); if (e.valid(v) && await act(A.editMessage, v, 'Guardado. Sigue esperando tu aprobación.')) done(); });
  reject.addEventListener('click', () => {
    const why = area('', 3, { maxlength: '400', placeholder: 'Demasiado largo; no cita lo que vimos en su web…' });
    const go = el('button', { class: 'oc-btn oc-btn--primary', type: 'button' }, 'Rechazar');
    const d = sheet(el('div', { class: 'oc-stack' }, [field('Por qué', why, 'El agente lo lee para el siguiente borrador.'), el('div', { class: 'oc-row' }, go)]), { title: 'Rechazar el mensaje' });
    go.addEventListener('click', async () => { if (await act(A.reject, { id: m._id, note: why.value.trim() || null }, 'Rechazado: no se enviará.')) { d.close(); done(); } });
  });
  return el('div', { class: 'oc-stack' }, [
    top,
    m.error ? el('p', { class: 've-error' }, m.error) : null,
    !live(s) ? el('p', { class: 'oc-help ve-warn' }, 'Ensayo: lo que apruebas queda listo, pero no sale nada.') : null,
    ...e.fields,
    el('div', { class: 'oc-row' }, [approve, save, reject]),
  ]);
}

function failed(m, top, done) {
  const maybe = /puede que haya salido/i.test(m.error || '');
  const retry = el('button', { class: 'oc-btn oc-btn--primary', type: 'button' }, 'Enviar de nuevo');
  retry.addEventListener('click', async () => {
    if (maybe && !(await Orch.confirm('Puede que ya haya salido. ¿Has mirado en Enviados de Gmail y no está?', { yes: 'No está: enviar de nuevo' }))) return;
    if (await act(A.retry, { id: m._id }, 'Aprobado de nuevo.')) done();
  });
  const back = el('button', { class: 'oc-btn', type: 'button', onClick: async () => { if (await act(A.backToDraft, { id: m._id }, 'Vuelve a borrador.')) done(); } }, 'Volver a borrador');
  const sent = el('button', { class: 'oc-btn oc-btn--ghost', type: 'button', onClick: async () => { if (await act(A.markSent, { id: m._id }, 'Marcado como enviado.')) done(); } }, 'Sí salió: marcar como enviado');
  return el('div', { class: 'oc-stack' }, [top, el('p', { class: 've-error' }, m.error || 'No salió.'), el('div', { class: 'oc-row' }, [retry, back, sent]), readOnly(m, {})]);
}
