'use strict';
/**
 * Ventas · Enviar — the messages a person approved, from the Gmail connection
 * chosen for Ventas, in plain text with the sign-off under them.
 *
 * In rehearsal (send_mode = rehearsal, the default) nothing is sent: approved
 * messages stay Aprobado — ready — and their prospect shows Aprobado. Live,
 * at most daily_limit leave each day (UTC), oldest approval first; the rest
 * wait for the next day.
 *
 * Only what a PERSON approved goes out: an approval stamped by an agent
 * ("agent:<id>") goes back to Borrador with the reason, never out. Each one is
 * CLAIMED before Gmail is called (Aprobado → Enviando, atomic), so a message
 * rejected meanwhile never leaves and none leaves twice. One left Enviando (a
 * run that died, or Gmail did not answer) becomes Error and says it may have
 * gone out: never retried blind. A person retries, edits or marks it sent.
 *
 * No agent turn. Approving starts it; a check every 5 minutes picks up what
 * waits while live.
 *   node enviar.js [--auto|--now]
 */
const L = require('./lib');
const X = require('./composio');

const { C } = L;
const STALE_MIN = 15;

async function run(mode = '--auto') {
  const held = L.lock('enviar');
  if (!held) return { ok: true, mode, skipped: 'Otro envío está en marcha' };
  try {
    const s = L.settings();
    const now = L.sqlClock();
    const out = { ok: true, mode, send_mode: s.send_mode === 'live' ? 'live' : 'rehearsal', sent: [], failed: [], back: [] };

    // What was claimed and never finished: it may have gone out.
    const stale = L.all(`SELECT _id FROM ve_messages WHERE _deleted = 0 AND status = 'enviando' AND datetime(lock_at) <= datetime('${now}', '-${STALE_MIN} minutes')`);
    for (const r of stale) {
      try {
        L.write([{ op: 'update', table: 've_messages', id: r._id, when: { status: 'enviando' }, data: {
          status: 'error', error: 'El envío no terminó: puede que haya salido o no. Mira en Enviados de Gmail antes de reintentar.' } }]);
      } catch { /* finished meanwhile */ }
    }
    if (stale.length) out.unfinished = stale.length;

    stages();

    const queue = L.all("SELECT * FROM ve_messages WHERE _deleted = 0 AND status = 'aprobado' ORDER BY datetime(approved_at), _id LIMIT 200");
    const sentToday = L.one(`SELECT COUNT(*) AS n FROM ve_messages WHERE _deleted = 0 AND status IN ('enviando', 'enviado')
      AND date(COALESCE(sent_at, lock_at)) = date('${now}')`).n;
    const plan = C.sendPlan({ mode: out.send_mode, limit: s.daily_limit, sentToday, queue });
    if (out.send_mode !== 'live') {
      note(s, queue.length ? `Ensayo: ${queue.length} ${queue.length === 1 ? 'mensaje aprobado está listo' : 'mensajes aprobados están listos'}; no sale ninguno hasta pasar a envío real.` : 'Ensayo: no sale nada.');
      return Object.assign(out, { skipped: 'Ensayo: no se envía nada', ready: queue.length });
    }
    if (!plan.send.length) {
      if (queue.length) note(s, `Límite diario de ${Number(s.daily_limit) || 15} alcanzado: ${queue.length} aprobados esperan a mañana.`);
      return Object.assign(out, { skipped: plan.why, waiting: plan.wait });
    }

    for (const m of plan.send) {
      const p = m.prospect_id ? L.one('SELECT * FROM ve_prospects WHERE _id = ? AND _deleted = 0', m.prospect_id) : null;
      const to = C.normEmail(m.to_email || (p && (p.contact_email || p.email)));
      const why = C.cannotSend(Object.assign({}, m, { to_email: to }), p);
      if (why) {
        if (!C.approvedByPerson(m.approved_by)) {
          try { L.write([{ op: 'update', table: 've_messages', id: m._id, when: { status: 'aprobado' }, data: { status: 'borrador', approved_by: null, approved_at: null, error: why } }]); } catch { /* changed */ }
          out.back.push({ id: m._id, why });
        } else fail(m, why, out, 'aprobado');
        continue;
      }
      try {
        L.write([{ op: 'update', table: 've_messages', id: m._id, when: { status: 'aprobado' }, data: { status: 'enviando', lock_at: L.sqlNow(), to_email: to, error: null } }]);
      } catch { continue; } // rejected or taken meanwhile
      let res;
      try {
        res = await X.gmailSend({ to, subject: m.subject, body: C.finalBody(m.body, s.sign_off), account: s.sender_account || undefined });
      } catch (e) {
        fail(m, e.timeout
          ? `Gmail no contestó a tiempo: puede que haya salido o no. Mira en Enviados de Gmail antes de reintentar. (${e.message})`
          : `Gmail no lo aceptó: no salió nada. ${readable(e.message)}`, out, 'enviando');
        continue;
      }
      sent(m, p, to, res, out);
    }
    if (plan.wait) note(s, `Límite diario de ${Number(s.daily_limit) || 15}: ${plan.wait} aprobados esperan a mañana.`);
    return out;
  } finally {
    held.release();
  }
}

/** A prospect whose first message is approved shows Aprobado; one whose approval was undone goes back to Mensaje. */
function stages() {
  const up = L.all(`SELECT DISTINCT p._id FROM ve_prospects p JOIN ve_messages m ON m.prospect_id = p._id AND m._deleted = 0
    WHERE p._deleted = 0 AND p.stage = 'mensaje' AND m.kind = 'primero' AND m.status = 'aprobado'`);
  const down = L.all(`SELECT p._id FROM ve_prospects p WHERE p._deleted = 0 AND p.stage = 'aprobado'
    AND NOT EXISTS (SELECT 1 FROM ve_messages m WHERE m._deleted = 0 AND m.prospect_id = p._id AND m.kind = 'primero' AND m.status IN ('aprobado', 'enviando', 'enviado'))`);
  const ops = [
    ...up.map((r) => ({ op: 'update', table: 've_prospects', id: r._id, when: { stage: 'mensaje' }, data: { stage: 'aprobado' } })),
    ...down.map((r) => ({ op: 'update', table: 've_prospects', id: r._id, when: { stage: 'aprobado' }, data: { stage: 'mensaje' } })),
  ];
  for (const op of ops) { try { L.write([op]); } catch { /* moved meanwhile */ } }
}

function readable(why) {
  const t = String(why || '');
  if (/not connected|no active connection|connected account|auth/i.test(t)) return `Gmail no está conectado para Ventas: conéctalo en Orchestra (Integraciones) y elígelo en Apps → Ventas, luego reintenta. (${t.slice(0, 200)})`;
  if (/invalid to|recipient|address/i.test(t)) return `La dirección fue rechazada: revísala, edítala y apruébalo de nuevo. (${t.slice(0, 200)})`;
  return `(${t.slice(0, 240)})`;
}

function fail(m, error, out, from) {
  try { L.write([{ op: 'update', table: 've_messages', id: m._id, when: { status: from }, data: { status: 'error', error: error.slice(0, 500) } }]); } catch { /* changed meanwhile */ }
  out.failed.push({ id: m._id, error: error.slice(0, 200) });
}

function sent(m, p, to, res, out) {
  const at = L.sqlNow();
  const ops = [{ op: 'update', table: 've_messages', id: m._id, data: { status: 'enviado', sent_at: at, gmail_message_id: res.id || null, error: null } }];
  if (p) {
    ops.push({ op: 'insert', table: 've_activity', data: { prospect_id: p._id, kind: 'enviado', note: L.clean(`${m.subject} → ${to}`, 300), at, author: m.approved_by || null } });
    if (m.kind !== 'seguimiento' && ['nuevo', 'cualificado', 'mensaje', 'aprobado'].includes(p.stage)) {
      ops.push({ op: 'update', table: 've_prospects', id: p._id, data: { stage: 'enviado' } });
    }
  }
  try {
    L.write(ops);
  } catch {
    // It went out: say so on the message even if the rest could not be written.
    L.write([{ op: 'update', table: 've_messages', id: m._id, data: { status: 'enviado', sent_at: at, gmail_message_id: res.id || null } }]);
  }
  out.sent.push({ id: m._id, to, gmail: res.id || null });
}

function note(s, text) {
  if (s.send_note === text) return;
  try { L.write([{ op: 'update', table: 've_settings', id: s._id, data: { send_note: text.slice(0, 300) } }]); } catch { /* the note can wait */ }
}

if (require.main === module) {
  const mode = process.argv.includes('--now') ? '--now' : '--auto';
  run(mode).then((r) => L.done(r)).catch((e) => { L.done({ ok: false, error: e.message }); process.exitCode = 1; });
}

module.exports = { run };
