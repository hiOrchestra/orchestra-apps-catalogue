// The applicants list, used by a role's page (fixed to that role) and by
// Applicants (everyone). Ranked by the agent's score; a row opens the person.
// Moving people is a person's decision: bulk Shortlist / Reject, or the stage
// in the panel.
import { V, T, A, STAGES, VERDICT, badge, verdictBadge } from '../data.js';
import { panel } from './applicant.js';

const { el, fmt } = Orch;

export function applicantsTable({ into, path, query, filter, showRole, empty }) {
  let ctl = null;
  const reload = () => ctl && ctl.reload();
  ctl = Orch.table({
    into, path, query, view: V.applicants, filter, pageSize: 50, sort: 'score:desc',
    search: ['name', 'email'],
    columns: [
      { key: 'name', label: 'Applicant', format: 'text' },
      ...(showRole ? [{ key: 'role', label: 'Role', format: 'text' }] : []),
      { key: 'score', label: 'Score', numeric: true, render: (r) => (r.score === null || r.score === undefined ? '—' : fmt.number(r.score)) },
      { key: 'verdict', label: 'Suggestion', render: (r) => (r.screening === 'Screened' ? verdictBadge(r.verdict) : badge(r.screening)) },
      { key: 'stage', label: 'Stage', render: (r) => badge(r.stage) },
      { key: 'applied_at', label: 'Applied', format: 'date' },
    ],
    filters: [
      { key: 'stage', label: 'Stage', options: STAGES },
      { key: 'verdict', label: 'Suggestion', options: Object.entries(VERDICT).map(([value, label]) => ({ value, label })) },
    ],
    detail: { title: 'Applicant', table: T.applications, render: (row) => panel(row, reload) },
    bulk: [
      { label: 'Shortlist', action: A.move, params: { stage: 'Shortlist' }, confirm: 'Shortlist {n}?', done: '{n} shortlisted' },
      { label: 'Reject', action: A.move, params: { stage: 'Rejected' }, confirm: 'Reject {n}? Nobody is told: this only moves them.', done: '{n} rejected' },
      { label: 'Screen again', action: A.screenAgain, confirm: 'Have the agent screen {n} again?', done: '{n} back in line for screening' },
    ],
    empty: empty || 'Nobody has applied yet.',
  });
  return ctl;
}
