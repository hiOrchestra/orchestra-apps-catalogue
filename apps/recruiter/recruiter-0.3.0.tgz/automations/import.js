#!/usr/bin/env node
'use strict';
/**
 * Recruiter · Import roles: the two script steps around the agent's turn.
 *
 *   node import.js fetch   claims the oldest waiting import (hr_imports), checks
 *                          its link (https, a public host: never this instance,
 *                          localhost or a private address), downloads that one
 *                          page and reduces it to readable text with its
 *                          posting links numbered in place. That is the handoff.
 *   node import.js save    reads the agent's answer ($PRIOR), checks every role
 *                          and saves it as a Draft keyed by its link. A role the
 *                          person edited after an import is left as it is.
 *
 * One path for every careers page: no list of job systems to keep up. The
 * agent reads the listing (and up to 20 postings for their text); it never
 * writes to the database. Nothing here is public: a draft shows nowhere until
 * a person opens it.
 */
const crypto = require('crypto');
const dns = require('dns');
const https = require('https');
const net = require('net');
const zlib = require('zlib');
const L = require('./lib');

const MAX_PAGE = 3 << 20;        // bytes read from the page, at most
const TIMEOUT_MS = 20000;
const MAX_TEXT = 30000;          // characters of page text handed to the agent
const MAX_LINKS = 200;
const MAX_ROLES = 150;           // roles one import saves, at most
const STALE_MIN = 30;
const RUNNING = ['Waiting', 'Working', 'Reading'];
const NOTHING = 'No roles found on that page. If it lists jobs, paste the link of the jobs list itself.';

// ── the link: only a public https page ───────────────────────────────────
/** True for an address no import may reach: loopback, private, link-local, metadata, reserved. */
function isPrivateIp(ip) {
  const a = String(ip || '').toLowerCase().replace(/^\[|\]$/g, '');
  if (net.isIPv4(a)) {
    const [x, y] = a.split('.').map(Number);
    return x === 0 || x === 10 || x === 127 || x >= 224 || (x === 100 && y >= 64 && y <= 127) || (x === 169 && y === 254)
      || (x === 172 && y >= 16 && y <= 31) || (x === 192 && y === 168) || (x === 192 && y === 0) || (x === 198 && (y === 18 || y === 19));
  }
  if (net.isIPv6(a)) {
    const mapped = a.match(/^::ffff:(\d+\.\d+\.\d+\.\d+)$/);
    if (mapped) return isPrivateIp(mapped[1]);
    if (/^::ffff:[0-9a-f]+:[0-9a-f]+$/.test(a)) return true; // a mapped v4 written in hex: refuse rather than decode
    return a === '::' || a === '::1' || /^f[cd]/.test(a) || /^fe[89ab]/.test(a) || a.startsWith('64:ff9b:') || a.startsWith('2001:db8') || a.startsWith('ff');
  }
  return true; // not an address at all: refuse
}

/** This instance's own names: an import never calls home. */
function instanceHosts(env = process.env) {
  return [env.RAILWAY_PUBLIC_DOMAIN, env.RAILWAY_PRIVATE_DOMAIN, env.RAILWAY_STATIC_URL, env.ORCHESTRA_INSTANCE_HOST]
    .filter(Boolean).map((h) => String(h).replace(/^https?:\/\//, '').replace(/[/:].*$/, '').toLowerCase());
}

/** The link as a URL, or why it cannot be read. Checked again on every redirect. */
function checkUrl(raw, env = process.env) {
  let u;
  try { u = new URL(String(raw || '').trim()); } catch { return { error: 'it is not a web address' }; }
  if (u.protocol !== 'https:') return { error: 'only https:// links can be imported' };
  if (u.username || u.password) return { error: 'a link with a user name or password in it cannot be imported' };
  if (u.port && u.port !== '443') return { error: 'only links on the standard https port can be imported' };
  const host = u.hostname.toLowerCase().replace(/\.$/, '');
  if (net.isIP(host.replace(/^\[|\]$/g, ''))) {
    if (isPrivateIp(host)) return { error: 'that address is private' };
  } else {
    if (!host.includes('.')) return { error: 'that is not a public site' };
    if (host === 'localhost' || /\.(localhost|local|internal|lan|home\.arpa|intranet)$/.test(host)) return { error: 'that is not a public site' };
    if (instanceHosts(env).some((h) => host === h || host.endsWith(`.${h}`))) return { error: 'that is this instance, not a careers page' };
  }
  u.hash = '';
  return { url: u };
}

/** dns.lookup, refusing a name that resolves to a private address (checked at connect time, so a rebinding name fails too). */
function guardedLookup(lookup = dns.lookup) {
  return (hostname, options, cb) => {
    if (typeof options === 'function') { cb = options; options = {}; }
    lookup(hostname, { ...options, all: true }, (err, list) => {
      if (err) return cb(err);
      const addrs = Array.isArray(list) ? list : [{ address: list, family: net.isIPv6(list) ? 6 : 4 }];
      const bad = addrs.find((x) => isPrivateIp(x.address));
      if (!addrs.length || bad) return cb(Object.assign(new Error(`${hostname} points to a private address`), { code: 'EPRIVATE' }));
      if (options && options.all) return cb(null, addrs);
      return cb(null, addrs[0].address, addrs[0].family);
    });
  };
}

/** One GET, no redirects followed: { status, headers, body (Buffer, at most MAX_PAGE) }. */
function httpsGet(url, { lookup } = {}) {
  return new Promise((resolve, reject) => {
    const req = https.get(url, {
      lookup: guardedLookup(lookup), timeout: TIMEOUT_MS,
      headers: { 'user-agent': 'Mozilla/5.0 (compatible; OrchestraRecruiter/0.3; +https://hiorchestra.com)', accept: 'text/html,application/xhtml+xml;q=0.9,*/*;q=0.5', 'accept-encoding': 'gzip, deflate, br' },
    }, (res) => {
      const enc = String(res.headers['content-encoding'] || '').toLowerCase();
      const stream = enc === 'gzip' ? res.pipe(zlib.createGunzip()) : enc === 'deflate' ? res.pipe(zlib.createInflate()) : enc === 'br' ? res.pipe(zlib.createBrotliDecompress()) : res;
      const chunks = [];
      let size = 0;
      let done = false;
      const finish = () => { if (!done) { done = true; resolve({ status: res.statusCode, headers: res.headers, body: Buffer.concat(chunks) }); } };
      stream.on('data', (c) => {
        size += c.length;
        if (size > MAX_PAGE) { chunks.push(c.subarray(0, c.length - (size - MAX_PAGE))); finish(); req.destroy(); return; }
        chunks.push(c);
      });
      stream.on('end', finish);
      stream.on('error', (e) => (done ? null : reject(e)));
    });
    req.on('timeout', () => req.destroy(new Error('the page took too long to answer')));
    req.on('error', reject);
  });
}

/** The page's HTML, following up to three redirects, each checked like the first link. */
async function fetchPage(raw, { get = httpsGet, env = process.env } = {}) {
  let c = checkUrl(raw, env);
  for (let hop = 0; hop < 4; hop += 1) {
    if (c.error) throw new Error(c.error);
    const r = await get(c.url.href);
    if (r.status >= 300 && r.status < 400 && r.headers && r.headers.location) {
      c = checkUrl(new URL(r.headers.location, c.url).href, env);
      continue;
    }
    if (r.status !== 200) throw new Error(`the site answered ${r.status}`);
    const type = String((r.headers && r.headers['content-type']) || 'text/html').toLowerCase();
    if (!/html|xml|text\/plain/.test(type)) throw new Error('that link is not a web page');
    return { url: c.url.href, html: Buffer.isBuffer(r.body) ? r.body.toString('utf8') : String(r.body || '') };
  }
  throw new Error('too many redirects');
}

// ── the page, reduced ────────────────────────────────────────────────────
const ENTITIES = { amp: '&', lt: '<', gt: '>', quot: '"', apos: "'", nbsp: ' ', ndash: '–', mdash: '—', rsquo: '’', lsquo: '‘', ldquo: '“', rdquo: '”', hellip: '…', bull: '•', middot: '·', euro: '€', pound: '£', copy: '©', reg: '®', trade: '™' };
const decode = (s) => String(s || '').replace(/&(#x[0-9a-f]+|#\d+|[a-z]+);/gi, (m, e) => {
  if (e[0] === '#') { const n = e[1].toLowerCase() === 'x' ? parseInt(e.slice(2), 16) : Number(e.slice(1)); return n > 0 && n < 0x110000 ? String.fromCodePoint(n) : ''; }
  return ENTITIES[e.toLowerCase()] !== undefined ? ENTITIES[e.toLowerCase()] : m;
});
const tagless = (s) => decode(String(s || '').replace(/<[^>]*>/g, ' ')).replace(/\s+/g, ' ').trim();

/** "acme.com" for jobs.acme.com, "acme.co.uk" for careers.acme.co.uk: what "the same site" means. */
function siteOf(host) {
  const parts = String(host || '').toLowerCase().replace(/^www\./, '').split('.');
  const n = parts.length >= 3 && parts[parts.length - 1].length === 2 && parts[parts.length - 2].length <= 3 ? 3 : 2;
  return parts.slice(-n).join('.');
}

/** A link worth the agent's time: a page deeper than the list, or one whose words say job. */
const JOB_HOST = /^(jobs|careers|apply|boards|job-boards)\./i;
const POSTING_WORDS = /job|career|position|opening|vacanc|posting|role|stelle|empleo|oferta|vaga|emploi|offre|lavor|werk|apply/i;
function postingLike(u, page) {
  const path = u.pathname.replace(/\/+$/, '');
  const base = page.pathname.replace(/\/+$/, '');
  if (u.href === page.href || path === base || !path) return false;
  if (/\.(pdf|png|jpe?g|gif|svg|css|js|xml|ico|zip)$/i.test(path)) return false;
  if (base && path.startsWith(`${base}/`)) return true;
  return POSTING_WORDS.test(path) || JOB_HOST.test(u.hostname);
}

/** Without the bits that only add bytes: tracking, the fragment, a trailing slash. */
function normalizeUrl(raw) {
  let u;
  try { u = new URL(String(raw || '').trim()); } catch { return null; }
  if (!/^https?:$/.test(u.protocol) || u.username || u.password) return null;
  u.hash = '';
  for (const k of [...u.searchParams.keys()]) if (/^(utm_|ref$|source$|src$|gclid|fbclid)/i.test(k)) u.searchParams.delete(k);
  u.hostname = u.hostname.toLowerCase();
  if (u.pathname.length > 1) u.pathname = u.pathname.replace(/\/+$/, '');
  return u.href;
}

/**
 * The handoff: the page as readable text, with each posting link replaced by
 * [n] and its words, so a listing's title, place and team stay together.
 * Scripts, styles and inline JSON go; so does every other link's address.
 */
function reduce(html, pageUrl) {
  const page = new URL(pageUrl);
  const title = tagless((String(html).match(/<title[^>]*>([\s\S]*?)<\/title>/i) || [])[1]).slice(0, 200);
  let h = String(html)
    .replace(/<!--[\s\S]*?-->/g, ' ')
    .replace(/<(script|style|noscript|svg|template|iframe|head|select|button|form)\b[\s\S]*?<\/\1\s*>/gi, ' ');
  const home = siteOf(page.hostname);
  const links = [];
  const seen = new Map();
  h = h.replace(/<a\b([^>]*)>([\s\S]*?)<\/a\s*>/gi, (m, attrs, inner) => {
    const href = (attrs.match(/\bhref\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s>]+))/i) || []).slice(1).find((x) => x !== undefined);
    const words = tagless(inner.replace(/<\/(p|div|li|h[1-6])>/gi, ' · ')).replace(/(\s*·\s*)+/g, ' · ').replace(/^[\s·]+|[\s·]+$/g, '');
    let u = null;
    try { u = href ? new URL(decode(href), page) : null; } catch { u = null; }
    if (!u || !/^https?:$/.test(u.protocol) || !postingLike(u, page)) return ` ${words} `;
    // Off the page's site, only a link that itself says job (an embedded job board's posting).
    if (siteOf(u.hostname) !== home && !(JOB_HOST.test(u.hostname) || POSTING_WORDS.test(u.pathname))) return ` ${words} `;
    const key = normalizeUrl(u.href);
    if (!key) return ` ${words} `;
    if (!seen.has(key)) {
      if (links.length >= MAX_LINKS) return ` ${words} `;
      seen.set(key, links.length + 1);
      links.push({ n: links.length + 1, url: key, text: words.slice(0, 160) });
    }
    return `\n[${seen.get(key)}] ${words}\n`;
  });
  const text = decode(h
    .replace(/<li\b[^>]*>/gi, '\n- ')
    .replace(/<br\s*\/?>/gi, '\n')
    .replace(/<\/?(p|div|section|article|header|footer|main|nav|aside|ul|ol|li|tr|table|h[1-6]|dl|dt|dd|blockquote)\b[^>]*>/gi, '\n')
    .replace(/<[^>]*>/g, ' '))
    .split('\n').map((l) => l.replace(/[ \t ]+/g, ' ').trim()).filter((l) => l && l !== '-')
    .join('\n');
  const cut = text.length > MAX_TEXT;
  return {
    title,
    text: cut ? `${text.slice(0, MAX_TEXT)}\n[…the page goes on]` : text,
    links,
    thin: text.replace(/\[\d+\]/g, '').replace(/\s+/g, ' ').length < 400,
  };
}

// ── step 1: fetch ────────────────────────────────────────────────────────
/** Imports left running by a run that died: Failed, with the way out. */
function sweep() {
  const stale = L.all(`SELECT _id, status FROM hr_imports WHERE _deleted = 0 AND status IN ('Working', 'Reading')
    AND datetime(_updated_at) <= datetime('now', '-${STALE_MIN} minutes')`);
  for (const r of stale) {
    try { L.write([{ op: 'update', table: 'hr_imports', id: r._id, when: { status: r.status }, data: { status: 'Failed', note: 'That import did not finish. Press Import to try again.', finished_at: L.sqlNow() } }]); } catch { /* moved on */ }
  }
}

const ANSWER = { roles: [{ title: 'Account Executive', location: 'London, UK', workplace: 'Hybrid', contract: 'Full-time', department: 'Sales', source_url: 'https://…/the-posting', summary: '', tasks: '- …', requirements: '- …', benefits: '- …' }] };

async function fetchStep({ get } = {}) {
  sweep();
  const w = L.one("SELECT _id, url FROM hr_imports WHERE _deleted = 0 AND status = 'Waiting' ORDER BY _id LIMIT 1");
  if (!w) return { skip: true, why: 'No import is waiting' };
  try {
    L.write([{ op: 'update', table: 'hr_imports', id: w._id, when: { status: 'Waiting' }, data: { status: 'Working' } }]);
  } catch { return { skip: true, why: 'Another run took that import' }; }
  const fail = (note) => {
    L.write([{ op: 'update', table: 'hr_imports', id: w._id, data: { status: 'Failed', note, finished_at: L.sqlNow() } }]);
    return { skip: true, import_id: w._id, why: note };
  };
  const ok = checkUrl(w.url);
  if (ok.error) return fail(`That link cannot be imported: ${ok.error}.`);
  let page;
  try { page = await fetchPage(ok.url.href, get ? { get } : {}); } catch (e) { return fail(`That page could not be opened: ${String(e.message || e).slice(0, 160)}.`); }
  const r = reduce(page.html, page.url);
  if (!r.thin && !r.links.length && !/job|career|role|position|stelle|empleo|vacan/i.test(r.text)) return fail(NOTHING);
  L.write([{ op: 'update', table: 'hr_imports', id: w._id, data: { status: 'Reading', note: 'The agent is reading the page.' } }]);
  return {
    import_id: w._id, url: page.url, title: r.title, thin: r.thin,
    ...(r.thin ? { note: 'This page\'s HTML has almost no text: it is built by JavaScript. Open the url with your browser tool and read the listing there.' } : {}),
    links: r.links.map((l) => ({ n: l.n, url: l.url })), text: r.text, answer: ANSWER,
  };
}

// ── step 3: save ─────────────────────────────────────────────────────────
const WORKPLACES = [[/remote|anywhere|distributed|telework|teletrabajo/i, 'Remote'], [/hybrid|híbrid|hibrid/i, 'Hybrid'], [/on[- ]?site|office|in[- ]person|presencial/i, 'On-site']];
const CONTRACTS = [[/intern|trainee|práctica|praktik|stage\b/i, 'Internship'], [/freelanc/i, 'Freelance'], [/part[- ]?time|teilzeit|media jornada/i, 'Part-time'],
  [/full[- ]?time|permanent|vollzeit|jornada completa|indefinid/i, 'Full-time'], [/contract|temporary|fixed[- ]term|befristet|temporal/i, 'Contract']];
const pickOf = (table, v) => { const s = String(v || ''); const hit = table.find(([rx]) => rx.test(s)); return hit ? hit[1] : ''; };

/** Plain text, at most `max` characters, cut at a line when it can be. */
function plain(v, max) {
  let s = String(v == null ? '' : v).replace(/<[^>]*>/g, ' ').replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, '')
    .split('\n').map((l) => l.replace(/[ \t]+/g, ' ').trim()).join('\n').replace(/\n{3,}/g, '\n\n').trim();
  if (s.length > max) { const cut = s.lastIndexOf('\n', max); s = s.slice(0, cut > max * 0.6 ? cut : max).trim(); }
  return s;
}

const CONTENT = ['title', 'department', 'location', 'workplace', 'employment', 'summary', 'tasks', 'requirements', 'benefits'];
/** The fingerprint of what an import wrote: a row whose content no longer matches it was edited by a person. */
const hashOf = (r) => crypto.createHash('sha256').update(JSON.stringify(CONTENT.map((k) => String(r[k] == null ? '' : r[k]).trim()))).digest('hex').slice(0, 32);

/**
 * One role of the agent's answer, checked: { role } or { drop: why }. Its link
 * must be on the imported page's site, or one of the links handed to the agent
 * (or on the same host as one: an embedded job board's postings).
 */
function checkRole(x, allowed) {
  if (!x || typeof x !== 'object') return { drop: 'not a role' };
  const title = plain(x.title, 140).replace(/\n/g, ' ');
  if (!title) return { drop: 'no title' };
  const url = normalizeUrl(x.source_url || x.url || x.apply_url);
  if (!url) return { drop: 'no link' };
  const u = new URL(url);
  if (u.protocol !== 'https:' && !allowed.urls.has(url)) return { drop: 'not an https link' };
  if (!(siteOf(u.hostname) === allowed.site || allowed.hosts.has(u.hostname) || allowed.urls.has(url))) return { drop: `the link is not on ${allowed.site}` };
  return { role: {
    title, source_url: url,
    department: plain(x.department || x.team, 80).replace(/\n/g, ' '),
    location: plain(x.location, 120).replace(/\n/g, ' '),
    workplace: pickOf(WORKPLACES, x.workplace),
    employment: pickOf(CONTRACTS, x.contract || x.employment || x.type),
    summary: plain(x.summary || x.description, 3000),
    tasks: plain(x.tasks, 4000),
    requirements: plain(x.requirements, 4000),
    benefits: plain(x.benefits, 3000),
  } };
}

/** Insert new roles as drafts, refresh ones the import wrote and nobody touched since, leave the rest. */
function upsert(roles, from) {
  const tally = { created: 0, updated: 0, unchanged: 0, edited: 0, removed: 0 };
  const now = L.sqlNow();
  const ops = [];
  for (const role of roles) {
    const hash = hashOf(role);
    const have = L.one('SELECT * FROM hr_roles WHERE source_url = ? ORDER BY _deleted, _id LIMIT 1', role.source_url);
    if (!have) {
      ops.push({ op: 'insert', table: 'hr_roles', data: { ...role, status: 'Draft', imported_from: from, imported_hash: hash, imported_at: now } });
      tally.created += 1;
    } else if (have._deleted) tally.removed += 1;
    else if (hashOf(have) !== have.imported_hash) tally.edited += 1;
    else if (hash === have.imported_hash) tally.unchanged += 1;
    else {
      ops.push({ op: 'update', table: 'hr_roles', id: have._id, when: { imported_hash: have.imported_hash }, data: { ...role, imported_hash: hash, imported_at: now } });
      tally.updated += 1;
    }
  }
  // Fifty at a time; a chunk that fails is tried one by one, so one bad row costs only itself.
  for (let i = 0; i < ops.length; i += 50) {
    const chunk = ops.slice(i, i + 50);
    try { L.write(chunk); } catch {
      for (const op of chunk) {
        try { L.write([op]); } catch { tally[op.op === 'insert' ? 'created' : 'updated'] -= 1; tally.edited += op.op === 'update' ? 1 : 0; }
      }
    }
  }
  return tally;
}

const plural = (n, one, many) => `${n} ${n === 1 ? one : many}`;
function noteOf(found, t, dropped) {
  if (!found) return NOTHING;
  const parts = [];
  if (t.created) parts.push(`Imported ${plural(t.created, 'role', 'roles')} as drafts — review them below.`);
  if (t.updated) parts.push(`Updated ${plural(t.updated, 'role', 'roles')} from the page.`);
  if (t.edited) parts.push(`Left ${plural(t.edited, 'role', 'roles')} you edited as ${t.edited === 1 ? 'it is' : 'they are'}.`);
  if (t.removed) parts.push(`Skipped ${plural(t.removed, 'role', 'roles')} you deleted.`);
  if (!t.created && !t.updated && t.unchanged) parts.push(`Nothing new: ${t.unchanged === 1 ? 'that role is' : `those ${t.unchanged} roles are`} already here.`);
  else if (t.unchanged) parts.push(`${t.unchanged} unchanged.`);
  if (dropped) parts.push(`${plural(dropped, 'link was', 'links were')} not on that site and left out.`);
  return parts.join(' ') || NOTHING;
}

function saveStep() {
  const f = L.parse(process.env.STEP_fetch);
  if (!f || f.skip || !f.import_id) return { ok: true, skipped: (f && f.why) || 'Nothing was fetched' };
  const id = Number(f.import_id);
  const row = L.one('SELECT * FROM hr_imports WHERE _id = ? AND _deleted = 0', id);
  if (!row || row.status !== 'Reading') return { ok: true, skipped: 'That import is no longer being read' };
  const finish = (data) => { L.write([{ op: 'update', table: 'hr_imports', id, when: { status: 'Reading' }, data: { ...data, finished_at: L.sqlNow() } }]); return { ok: true, import_id: id, ...data }; };
  const answer = L.parse(process.env.PRIOR);
  if (!answer || !Array.isArray(answer.roles)) return finish({ status: 'Failed', note: 'The agent\'s answer could not be read. Press Import to try again.' });

  const page = new URL(f.url || row.url);
  const handed = (Array.isArray(f.links) ? f.links : []).map((l) => normalizeUrl(l && l.url)).filter(Boolean);
  const allowed = { site: siteOf(page.hostname), urls: new Set([normalizeUrl(page.href), ...handed]), hosts: new Set(handed.map((u) => new URL(u).hostname)) };
  const roles = new Map();
  let dropped = 0;
  for (const x of answer.roles.slice(0, MAX_ROLES * 2)) {
    const c = checkRole(x, allowed);
    if (c.drop) { if (/not on|https/.test(c.drop)) dropped += 1; continue; }
    if (!roles.has(c.role.source_url) && roles.size < MAX_ROLES) roles.set(c.role.source_url, c.role);
  }
  const t = upsert([...roles.values()], normalizeUrl(page.href));
  return finish({ status: 'Done', found: roles.size, created: t.created, updated: t.updated, skipped: t.edited + t.removed, note: noteOf(roles.size, t, dropped) });
}

if (require.main === module) {
  const step = process.argv[2];
  (step === 'fetch' ? fetchStep() : Promise.resolve(step === 'save' ? saveStep() : { ok: false, error: 'node import.js fetch|save' }))
    .then((out) => L.done(out))
    .catch((e) => { process.stderr.write(`import: ${e.message}\n`); process.exit(1); });
}

module.exports = { isPrivateIp, checkUrl, guardedLookup, fetchPage, reduce, siteOf, normalizeUrl, checkRole, hashOf, upsert, noteOf, fetchStep, saveStep, NOTHING };
