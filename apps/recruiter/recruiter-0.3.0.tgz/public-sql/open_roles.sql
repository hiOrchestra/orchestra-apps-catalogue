SELECT _id, title, department, location, workplace, employment,
       salary_min, salary_max, currency, salary_period,
       summary, tasks, requirements, benefits, opened_at
FROM hr_roles
WHERE status = 'Open'
