// Recruiter, installed on this instance: tables, seed, the screening
// automation (scripts + workflow + schedule), importing roles from a careers
// page (a workflow the desk's Import starts), the hiring desk (`recruiter`,
// members) and the public careers page (`careers`: an admin sets it Public,
// approves its two public views and publishes it). Idempotent: run it again
// after a change and it converges. Runs as `node` (gosu).
//   node install.js <bundle-dir> [--fixtures] [--agent <id>]
// --agent: who reads the applications in the screening step and the careers
// page in the import (default leila).
// It must be a member of the `default` project to reach the database.
'use strict';
const { execFileSync } = require('child_process');
const { DatabaseSync } = require('node:sqlite');
const fs = require('fs');
const path = require('path');

const B = process.argv[2];
const FIXTURES = process.argv.includes('--fixtures');
const AGENT = (process.argv[process.argv.indexOf('--agent') + 1] && process.argv.includes('--agent'))
  ? process.argv[process.argv.indexOf('--agent') + 1] : 'leila';
const PROJECT = 'default';
const HOME = '/home/node/.openclaw/orchestra/projects/default';
const AUTO = path.join(HOME, 'apps', 'recruiter', 'automations');
const read = (f) => fs.readFileSync(path.join(B, f), 'utf8');
const json = (f) => JSON.parse(read(f));
const say = (...a) => console.log(...a);

function cli(bin, args) {
  let out;
  try {
    out = execFileSync(bin, args, { encoding: 'utf8', timeout: 180000, maxBuffer: 32 << 20 });
  } catch (e) {
    out = String(e.stdout || '') || String(e.stderr || e.message);
    say(`   ! ${bin} ${args.slice(0, 3).join(' ')}: ${out.trim().slice(0, 300)}`);
  }
  try { return JSON.parse(out); } catch { return { raw: String(out).trim().slice(0, 600) }; }
}
const db = (...a) => cli('orch-database', ['--project', PROJECT, ...a]);
const canvas = (...a) => cli('orch-canvas', a);
const wf = (...a) => cli('orch-workflows', a);
const short = (o, keys) => JSON.stringify(Object.fromEntries(keys.filter((k) => o && o[k] !== undefined).map((k) => [k, o[k]]))).slice(0, 400);

// ── 1. automation scripts ────────────────────────────────────────────────
say('== automations');
fs.mkdirSync(AUTO, { recursive: true });
for (const f of fs.readdirSync(path.join(B, 'automations'))) fs.copyFileSync(path.join(B, 'automations', f), path.join(AUTO, f));
say('  ', fs.readdirSync(AUTO).join(' '));

// ── 2. tables and indexes ────────────────────────────────────────────────
say('== tables');
const schema = json('schema.json');
for (const [table, cols] of Object.entries(schema.tables)) {
  say(`   ${table}: ${short(db('ensure-table', table, '--columns', ...cols), ['ok', 'action', 'created', 'added', 'error', 'raw'])}`);
}
say('== indexes');
{
  const conn = new DatabaseSync(path.join(HOME, 'data', 'data.db'));
  conn.exec('PRAGMA busy_timeout = 8000');
  for (const sql of schema.indexes) {
    try { conn.exec(sql); say(`   ok ${sql.slice(0, 90)}`); } catch (e) { say(`   ! ${e.message} :: ${sql.slice(0, 90)}`); }
  }
  conn.close();
}

// ── 3. seed, only into empty tables ──────────────────────────────────────
say('== seed');
const count = (t) => ((db('query', `SELECT COUNT(*) AS n FROM ${t} WHERE _deleted = 0`).rows || [{}])[0] || {}).n;
for (const [table, rows] of Object.entries(json('seed.json'))) {
  if (count(table) > 0) { say(`   ${table}: has rows, left as is`); continue; }
  say(`   ${table}: ${short(db('insert-many', table, '--data', JSON.stringify(rows)), ['ok', 'count', 'inserted', 'error'])}`);
}
if (FIXTURES) {
  say('== test fixtures');
  const have = ((db('query', "SELECT COUNT(*) AS n FROM hr_applications WHERE _deleted = 0 AND source = 'Recruiter install test'").rows || [{}])[0] || {}).n;
  if (have) say('   already there');
  else {
    const t = json('instance-test.json');
    const r = db('insert-many', 'hr_roles', '--data', JSON.stringify(t.hr_roles));
    const ids = ((db('query', `SELECT _id FROM hr_roles WHERE _deleted = 0 ORDER BY _id DESC LIMIT ${t.hr_roles.length}`).rows) || []).map((x) => x._id).reverse();
    // The fixture's role_id is its position in the fixture (1-based): map it to the new ids.
    const apps = t.hr_applications.map((a) => ({ ...a, role_id: ids[a.role_id - 1] || null }));
    say(`   roles: ${short(r, ['ok', 'count', 'error'])} → ${ids.join(', ')}`);
    say(`   applications: ${short(db('insert-many', 'hr_applications', '--data', JSON.stringify(apps)), ['ok', 'count', 'error'])}`);
  }
}

// ── 4. the workflows: screening, and importing roles from a careers page ─
say('== workflows');
const existing = wf('list').workflows || [];
const WF = {};
for (const key of ['screen', 'import']) {
  const spec = JSON.parse(read(`workflows/${key}.json`).replace(/"\$AGENT"/g, JSON.stringify(AGENT)));
  const tmpSpec = path.join(B, 'workflows', `${key}.resolved.json`);
  fs.writeFileSync(tmpSpec, JSON.stringify(spec, null, 1));
  const found = existing.find((w) => w.name === spec.name);
  const created = found ? wf('update', found.id, '--file', tmpSpec) : wf('create', '--file', tmpSpec);
  WF[key] = found ? found.id : ((created.workflow && created.workflow.id) || created.id || created.workflowId);
  say(`   ${spec.name}: ${WF[key]} ${found ? 'updated' : 'created'} (agent ${AGENT}) ${short(created, ['ok', 'error', 'raw'])}`);
}
const WF_SCREEN = WF.screen;

// ── 5. apps ──────────────────────────────────────────────────────────────
function ensureApp(id, init) {
  let app = (canvas('list').apps || []).find((a) => a.id === id);
  if (!app) {
    say(`   init ${id}: ${short(canvas('init', id, ...init, '--project', PROJECT, '--confirmed'), ['ok', 'dir', 'url', 'error', 'raw'])}`);
    app = (canvas('list').apps || []).find((a) => a.id === id);
  }
  return app;
}
/** Files as the source has them: the starter's leftovers are removed. */
function copyFiles(app, from) {
  const DIR = path.join('/home/node/.openclaw/orchestra', app.dir);
  const src = path.join(B, from);
  const top = fs.readdirSync(src).filter((f) => fs.statSync(path.join(src, f)).isFile());
  for (const f of top) fs.copyFileSync(path.join(src, f), path.join(DIR, f));
  const screens = fs.existsSync(path.join(src, 'screens')) ? fs.readdirSync(path.join(src, 'screens')) : [];
  if (screens.length) {
    fs.mkdirSync(path.join(DIR, 'screens'), { recursive: true });
    for (const f of screens) fs.copyFileSync(path.join(src, 'screens', f), path.join(DIR, 'screens', f));
  }
  // The starter's own files (its data.js, its README) are not ours: what the
  // app serves is exactly the source.
  for (const f of fs.readdirSync(DIR)) {
    const full = path.join(DIR, f);
    if (!f.startsWith('.') && f !== 'screens' && fs.statSync(full).isFile() && !top.includes(f)) { fs.unlinkSync(full); say(`   removed starter ${f}`); }
  }
  if (fs.existsSync(path.join(DIR, 'screens'))) {
    for (const f of fs.readdirSync(path.join(DIR, 'screens'))) if (!screens.includes(f)) fs.unlinkSync(path.join(DIR, 'screens', f));
    if (!screens.length) fs.rmSync(path.join(DIR, 'screens'), { recursive: true, force: true });
  }
  say(`   files: ${top.join(' ')}${screens.length ? ` + screens/${screens.join(' screens/')}` : ''}`);
}
function addAction(appId, a) {
  canvas('action', 'remove', appId, '--name', a.name);
  const args = ['action', 'add', appId, '--name', a.name, '--type', a.type];
  if (a.table) args.push('--table', a.table);
  if (a.fields) args.push('--fields', a.fields.join(','));
  if (a.defaults) args.push('--defaults', JSON.stringify(a.defaults));
  if (a.bulk) args.push('--bulk');
  if (a.access) args.push('--access', a.access);
  const sub = (v) => (typeof v === 'string' && v.startsWith('$WF_') ? WF[v.slice(4).toLowerCase()] : v);
  if (a.workflow) args.push('--workflow', sub(a.workflow));
  if (a.args) args.push('--args', JSON.stringify(a.args));
  if (a.trigger) args.push('--trigger-workflow', sub(a.trigger));
  say(`   ${a.name}: ${short(canvas(...args), ['ok', 'action', 'error', 'raw'])}`);
}

say('== the desk: recruiter');
const desk = ensureApp('recruiter', ['--name', 'Recruiter', '--icon', '🧑‍💼', '--pattern', 'list',
  '--desc', 'The hiring desk: roles for the careers page, their applicants ranked by the agent\'s screening, moved through the stages by a person',
  '--user', 'Whoever hires: writes the roles, opens and closes them, decides who moves on',
  '--frequency', 'Daily while a role is open',
  '--question', 'Who applied to this role, and who should I talk to first?', '--question', 'Why did the agent suggest them?',
  '--question', 'Which roles are open, and how many people are waiting?',
  '--primary-action', 'Open a role, read the ranked applicants and move the right ones to Shortlist']);
copyFiles(desk, 'app');
say(`   grants: ${short(canvas('grants', 'set', 'recruiter', '--grant', ...Object.keys(schema.tables).map((t) => `${t}:action`)), ['ok', 'grants', 'pendingApproval', 'error', 'raw'])}`);
const describe = { roles: 'Each role with how many applied, are new, were suggested and are shortlisted', applicants: 'Every application with its role, stage and the agent\'s screening' };
for (const f of fs.readdirSync(path.join(B, 'sql'))) {
  const name = f.replace(/\.sql$/, '');
  say(`   view ${name}: ${short(canvas('view', 'add', 'recruiter', '--name', name, '--sql-file', path.join(B, 'sql', f), '--description', describe[name] || name), ['ok', 'reads', 'pendingApproval', 'error', 'raw'])}`);
}
for (const a of json('actions.json')) addAction('recruiter', a);
say(`   brand: ${short(canvas('brand', 'set', 'recruiter', '--preset', 'orchestra'), ['ok', 'error', 'raw'])}`);
say(`   brief: ${short(canvas('brief', 'set', 'recruiter', '--density', 'compact', '--variety', 'focused', '--confirmed'), ['ok', 'error', 'raw'])}`);

say('== the careers page: careers');
const careers = ensureApp('careers', ['--name', 'Careers', '--icon', '💼', '--pattern', 'list',
  '--desc', 'The public careers page: the company, its open roles, and the application form',
  '--user', 'Anyone looking for a job with this company, from a link or a job post',
  '--frequency', 'Once or twice, when they apply',
  '--question', 'What roles are open, and is one for me?', '--question', 'What would I do, and what do they offer?',
  '--primary-action', 'Read a role and send an application']);
copyFiles(careers, 'careers');
const publicDescribe = { open_roles: 'Open roles for the careers page: title, where, contract, pay and the ad text. Never the screening notes.', company: 'The company\'s public facts for the careers page header' };
for (const f of fs.readdirSync(path.join(B, 'public-sql'))) {
  const name = f.replace(/\.sql$/, '');
  say(`   public view ${name}: ${short(canvas('view', 'add', 'careers', '--name', name, '--access', 'public', '--sql-file', path.join(B, 'public-sql', f), '--description', publicDescribe[name] || name), ['ok', 'access', 'publicApproval', 'error', 'raw'])}`);
}
addAction('careers', json('careers-action.json'));
say(`   brand: ${short(canvas('brand', 'set', 'careers', '--preset', 'orchestra'), ['ok', 'error', 'raw'])}`);

// ── 6. the schedule ──────────────────────────────────────────────────────
say('== schedule');
for (const s of (wf('schedules', WF_SCREEN).schedules || [])) say(`   unschedule ${s.jobId}: ${short(wf('unschedule', s.jobId), ['ok', 'error'])}`);
say(`   screen */10: ${short(wf('schedule', WF_SCREEN, '--cron', '*/10 * * * *', '--timezone', 'UTC', '--name', 'Recruiter · screen applicants',
  '--table', 'hr_settings', '--where', read('workflows/screen.where'), '--limit', '1'), ['ok', 'jobId', 'schedule', 'error', 'raw'])}`);

say('== done', JSON.stringify({ desk: desk && desk.dir, careers: careers && careers.dir, workflows: WF, agent: AGENT }));
say('First install only, in the portal (an admin): approve the desk\'s table grants; set Careers to Public and approve its two public views; publish both apps. After a reinstall: publish what changed.');
// The last line, read by the apps catalogue installer: what a person still has to do.
console.log(JSON.stringify({ step: 'done', project: PROJECT, a_person_still_has_to: [
  'Approve the tables the hiring desk asks for, hr_imports too since 0.3.0 (Canvas → Recruiter → who gets in)',
  'Set Careers to Public and approve its two public lists, open_roles and company (Canvas → Careers)',
  'Publish both apps (Canvas → the app → History)',
  'Follow Getting started on Recruiter\'s first screen: your company, then your first open role',
] }));
