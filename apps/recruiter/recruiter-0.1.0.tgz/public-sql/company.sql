SELECT name, tagline, about, website, linkedin, industry, size, privacy_url
FROM hr_company
ORDER BY _id
LIMIT 1
