// Roles: every position, its status, and how many applied — new ones and the
// agent's shortlist suggestions first, since those are what wait for you.
import { V, badge, head } from '../data.js';

const { el, router, fmt } = Orch;

export function render(_params, path) {
  const list = el('div');
  Orch.mount('view', [
    head('Roles', 'Open a role to show it on your careers page. People apply there; the agent screens them against what you ask for.',
      [router.link('/roles/new', 'New role', { class: 'oc-btn oc-btn--primary' })]),
    list,
  ]);
  Orch.table({
    into: list, path: '/', query: path, view: V.roles, search: ['title', 'department', 'location'], pageSize: 50,
    sort: 'status:desc',
    columns: [
      { key: 'title', label: 'Role', render: (r) => router.link(`/roles/${r._id}`, r.title || 'Untitled role') },
      { key: 'status', label: 'Status', render: (r) => badge(r.status) },
      { key: 'department', label: 'Team', format: 'text' },
      { key: 'location', label: 'Location', format: 'text' },
      { key: 'applicants', label: 'Applied', numeric: true, format: 'number' },
      { key: 'new_count', label: 'New', numeric: true, render: (r) => (r.new_count ? el('span', { class: 'rc-strong' }, fmt.number(r.new_count)) : '—') },
      { key: 'suggested', label: 'Suggested', numeric: true, render: (r) => (r.suggested ? fmt.number(r.suggested) : '—') },
      { key: 'shortlisted', label: 'Shortlisted', numeric: true, format: 'number' },
    ],
    filters: [{ key: 'status', label: 'Status', options: ['Open', 'Draft', 'Closed'] }],
    empty: 'No roles yet. Write the first one: New role.',
  });
}
