// What Recruiter reads, the only things it writes, and the words it shows.
// Tables give rows, two views do the counting and the joining, and every write
// is a declared action (A). Screening runs as a workflow on the instance: this
// app starts it ("Screen now") and shows what it concluded.
const { el } = Orch;

export const T = { roles: 'hr_roles', applications: 'hr_applications', company: 'hr_company', settings: 'hr_settings' };
export const V = { roles: 'roles', applicants: 'applicants' };
export const A = {
  createRole: 'create_role', updateRole: 'update_role', openRole: 'open_role', closeRole: 'close_role',
  move: 'move_applicants', note: 'note_applicant', screenAgain: 'screen_again', addApplicant: 'add_applicant',
  saveCompany: 'save_company', saveSettings: 'save_settings', screenNow: 'screen_now',
};

export const STAGES = ['New', 'Shortlist', 'Interview', 'Offer', 'Hired', 'Rejected'];
export const WORKPLACES = ['On-site', 'Hybrid', 'Remote'];
export const EMPLOYMENTS = ['Full-time', 'Part-time', 'Contract', 'Internship', 'Freelance'];
export const VERDICT = { shortlist: 'Shortlist', maybe: 'Maybe', no: 'Not a fit' };

const TONE = {
  Open: 'good', Draft: 'warn', Closed: '', New: 'accent', Shortlist: 'good', Interview: 'accent', Offer: 'accent', Hired: 'good', Rejected: 'bad',
  shortlist: 'good', maybe: 'warn', no: 'bad', Screening: 'accent', Waiting: '', Failed: 'bad',
};
export const badge = (value, text) => el('span', { class: 'oc-badge' + (TONE[value] ? ` oc-badge--${TONE[value]}` : '') }, text || value || '—');
export const verdictBadge = (v) => (v ? badge(v, VERDICT[v] || v) : el('span', { class: 'oc-muted' }, '—'));

/** The careers page, on this same instance: what a candidate opens. */
export const careersUrl = (path = '') => `${location.origin}/canvas/a/careers/${path ? `#${path}` : ''}`;

/** Run a declared action, say how it went, and hand back its result (null on failure). */
export async function act(name, params, done) {
  try {
    const r = await Orch.action(name, params);
    if (done) Orch.toast(done);
    window.dispatchEvent(new CustomEvent('recruiter:changed'));
    return r || {};
  } catch (e) {
    Orch.toast(e.status === 409 ? 'It changed meanwhile: look again.' : (e.message || 'That did not work.'), { error: true });
    return null;
  }
}

/**
 * The page head every screen starts with. A screen of many ("Roles") is titled
 * in the body face; one that names a single thing (a role) passes `named`.
 */
export const head = (title, lede, actions, named) => el('header', { class: 'rc-head' }, [
  el('div', {}, [el('h1', { class: named ? 'oc-h1' : 'oc-h1 oc-h1--collection' }, title), lede ? el('p', { class: 'oc-lede' }, lede) : null]),
  actions ? el('div', { class: 'rc-actions' }, actions) : null,
]);
