---
name: app-recruiter
version: 0.3.4
description: >-
  Run hiring in the Recruiter app: roles, a public careers page, applicants,
  and the agent's screening of each one. Use when someone asks "who applied /
  quién se postuló", "who should I call / a quién llamo", "candidates to
  review / candidatos para revisar", "screen the applicants / evalúa a los
  candidatos", "move her to interview / pásala a entrevista", "reject him /
  descártalo", "open the role / publica la vacante", "close the role / cierra
  la vacante", "import our jobs from this page / importa las ofertas de esta
  web", "new role / nueva vacante". Needs the Recruiter app installed in a
  project you work in.
metadata:
  openclaw:
    emoji: "🧑‍💼"
---
# Recruiter — roles, a careers page, applicants screened by an agent

People apply on a public careers page; an agent reads each application
against the role and suggests a verdict; a person decides who moves on.
Two apps share the tables: `recruiter` (the desk, members) and `careers`
(the public page).

## Is it installed

```bash
ls -d ~/.openclaw/orchestra/projects/*/apps/recruiter    # today always projects/default
orch-database --project default tables                    # hr_roles, hr_applications, ...
orch-workflows list            # "Recruiter · Screen applicants", "Recruiter · Import roles": note their ids
orch-canvas url recruiter      # the desk · orch-canvas url careers: the public page
```

If none of that is there, say Recruiter is not installed. Do not improvise a
hiring pipeline some other way. Below, `P=default`.

## The model

| Table | A row is |
|---|---|
| `hr_company` | one row: what the careers page says (name, tagline, about, website, logo_url, privacy_url…) |
| `hr_settings` | one row: `screening` on/off, `screen_per_run` (default 8, max 20), `notify_telegram` |
| `hr_roles` | a role: the ad (title, department, location, workplace, employment, salary_*, summary, tasks, requirements, benefits), `screening_notes` (only the agent reads them, never public), `status` |
| `hr_applications` | one person on one role (`role_id` empty = open application): contact, cv_url, linkedin, message, `consent`, `source`, `stage`, `notes`, and the screening: `verdict`, `score`, `reasons`, `screen_status`, `screen_note` |
| `hr_imports` | one "import from a URL": `url`, `status`, found / created / updated / skipped, a `note` |

Role `status`: `Draft` (new or imported; shows nowhere) → `Open` (on the
careers page, `opened_at` set; applicants get screened) → `Closed`
(`closed_at` set; off the page). A closed role can be opened again.

Applicant `stage`: `New`, `Shortlist`, `Interview`, `Offer`, `Hired`,
`Rejected`. Every application starts `New` (`source` = `Careers page` or
`Added by hand`). Only a person moves stages; screening never does. Nobody is
told anything when a stage changes: the app sends no email at all.

Screening (`screen_status`): empty = waiting → `Screening` (claimed by a run;
back in line after 2 hours) → `Screened` with `verdict` `shortlist` / `maybe`
/ `no` (the desk shows "Not a fit"), `score` 0–100 or empty when nothing could
be read, and `reasons`. A bad answer three times → `Failed` until "Screen
again". Only applicants of an Open role with `consent = 'yes'` are screened.
The agent screening sees links and the message, never email or phone.

Import `status`: `Waiting` → `Working` → `Reading` → `Done` or `Failed` (the
`note` says why). Imported roles land as `Draft`, keyed by `source_url`; a
re-import never touches a role the person edited or deleted, nor any status.

One person can apply once per role (a unique index on role and email).

## How you act

- Prefer the workflows: they validate and claim rows safely. Both run as the
  app's screening agent (default `leila`); you may run them only if that is
  you or an agent you hand work to, otherwise ask the person to press the
  button in the desk (Screen now, Import).
- Where only a table write does it, use `orch-database --project default`
  and set exactly the fields the desk's own action sets (listed per recipe).
  Never write `verdict`, `score`, `reasons`, `screened_at`, `imported_hash`.
- Opening a role publishes it to anyone with the careers link: only with the
  person's explicit yes in this conversation. Same for company facts.
- Nothing goes to a candidate without the person's OK. Rejecting is only a
  stage; if they want the candidate told, draft the message and show it.
- Deleting a role or an applicant, or rejecting several at once: name what
  is lost (who, which role) and wait for a clear yes.
- `orch-database` timestamps: the desk writes ISO, `$(date -u +%Y-%m-%dT%H:%M:%S.000Z)`.

## Recipes

Candidates to review ("who applied, who is worth a call"):
```bash
orch-database --project default query "SELECT a._id, a.name, r.title AS role, a.stage, a.verdict, a.score, a.reasons, a.screen_status, a._created_at FROM hr_applications a LEFT JOIN hr_roles r ON r._id = a.role_id WHERE a._deleted = 0 AND a.stage = 'New' ORDER BY (a.verdict = 'shortlist') DESC, a.score DESC"
```
Quote the reasons as written. The verdict is a suggestion; say so. For one
role add `AND a.role_id = N`; for roles at a glance, `SELECT _id, title,
status FROM hr_roles WHERE _deleted = 0`.

Screen applicants now (even when screening is off in Settings):
```bash
orch-workflows run <screen-wf-id> --args '{"mode":"--force"}'
orch-workflows runs --limit 5 ; orch-workflows status <run-id>
```
Or the `workflow_run` tool with the same args for the result this turn.
Otherwise the schedule runs it every 10 minutes when someone waits.
Screen again (Failed, or after the role changed): set
`{"screen_status":"","screen_attempts":0,"screen_note":""}` on that
application: `orch-database --project default update hr_applications --id N --data …`.

Move a candidate (only what the person asked):
```bash
orch-database --project default update hr_applications --id 42 --data '{"stage":"Interview"}'
```
A note: `--data '{"notes":"…"}'` (keep the existing text, append to it).

Reject a candidate: the same update with `"stage":"Rejected"`. Confirm the
name and role first. No email exists in the app; never send one yourself
without the person approving the exact text.

Open or close a role (opening = publishing; ask first):
```bash
orch-database --project default update hr_roles --id 7 --data "{\"status\":\"Open\",\"opened_at\":\"$(date -u +%Y-%m-%dT%H:%M:%S.000Z)\",\"closed_at\":\"\"}"
orch-database --project default update hr_roles --id 7 --data "{\"status\":\"Closed\",\"closed_at\":\"$(date -u +%Y-%m-%dT%H:%M:%S.000Z)\"}"
```
Before opening an imported draft, show the person its text: imports fill
title, place, contract and a scraped summary, not tasks or requirements.

New role / edit a role: insert into `hr_roles` only these fields: title,
department, location, workplace (`On-site`, `Hybrid`, `Remote`), employment
(`Full-time`, `Part-time`, `Contract`, `Internship`, `Freelance`),
salary_min, salary_max, currency (EUR, USD, GBP, CHF, MXN, ARS, BRL, COP,
CLP), salary_period (`year`, `month`, `hour`), summary, tasks, requirements,
benefits, screening_notes; plus `"status":"Draft"` on insert (`insert hr_roles --data`, or `update hr_roles --id N --data` to edit). Then open it
only when the person says so.

Import roles from a careers page URL (what the desk's Import does):
```bash
orch-database --project default insert hr_imports --data "{\"url\":\"https://example.com/careers\",\"status\":\"Waiting\",\"requested_at\":\"$(date -u +%Y-%m-%dT%H:%M:%S.000Z)\"}"
orch-workflows run <import-wf-id>
orch-database --project default query "SELECT status, found, created, updated, skipped, note FROM hr_imports WHERE _deleted = 0 ORDER BY _id DESC LIMIT 1"
```
Only public https pages; it imports the oldest waiting link, up to 150
roles, all as Draft. Tell the person to review them in the desk.

Add an applicant the person gives you: insert into `hr_applications` role_id,
name, email, phone, linkedin, cv_url, message, with `"stage":"New"`,
`"source":"Added by hand"`, `"consent":"yes"` — only when the person
confirms the candidate agreed to be on file.

## Other Orchestra apps

None is wired to Recruiter in code: no shared tables, no calls. Moving a hire
to the CRM, emailing candidates through Outreach, or a booking link for an
interview is by hand today, each with the person's OK.

## Never

- Open a role, change the company facts, or touch the careers app without the person's yes.
- Send a candidate anything, or tell them their stage, without approval of the exact text.
- Change a stage the person did not ask for, or treat the verdict as a decision.
- Write `verdict`, `score` or `reasons` yourself, or edit `screening_notes` into public fields.
- Put an applicant's email or phone into a workflow, a link or another agent's task.
- Approve grants, set Careers public, approve its views or publish an app: an admin does that in the portal.
