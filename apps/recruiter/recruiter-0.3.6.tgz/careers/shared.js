// What both screens of the careers page share: the two public views it reads
// (approved by an admin for the internet, with their exact SQL), and how a
// role's facts and texts are written out. The page reads nothing else and
// writes only through the public `apply` action.
const { el } = Orch;

export const VIEWS = { roles: 'open_roles', company: 'company' };

let company = null;
/** The company's public facts: one row, read once per visit. */
export async function companyOf() {
  if (!company) {
    try { company = ((await Orch.db.view(VIEWS.company, { limit: 1 })).rows || [])[0] || {}; } catch { company = {}; }
  }
  return company;
}

const money = (n, cur) => {
  try { return new Intl.NumberFormat(undefined, { style: 'currency', currency: cur || 'EUR', maximumFractionDigits: 0 }).format(n); } catch { return `${n} ${cur || ''}`.trim(); }
};

/** "70.000 € – 85.000 € a year", or null when no range was given. */
export function salary(r) {
  const lo = Number(r.salary_min) || 0;
  const hi = Number(r.salary_max) || 0;
  if (!lo && !hi) return null;
  const per = { year: 'a year', month: 'a month', hour: 'an hour' }[r.salary_period] || '';
  const range = lo && hi && lo !== hi ? `${money(lo, r.currency)} – ${money(hi, r.currency)}` : money(hi || lo, r.currency);
  return `${range}${per ? ` ${per}` : ''}`;
}

/** Where and how: "Barcelona, Spain (Hybrid)", "Full-time", the team. */
export function facts(r) {
  const where = [r.location, r.workplace ? `(${r.workplace})` : ''].filter(Boolean).join(' ');
  return [where, r.employment, r.department].filter(Boolean);
}

/**
 * A text the hiring team wrote: lines starting with "- " become a list, the
 * rest paragraphs. Built with nodes, so what they typed is never markup.
 */
export function prose(text) {
  const out = [];
  let list = null;
  for (const raw of String(text || '').split('\n')) {
    const line = raw.trim();
    if (!line) { list = null; continue; }
    const item = line.match(/^[-*•]\s+(.*)$/);
    if (item) {
      if (!list) { list = el('ul', { class: 'cr-list' }); out.push(list); }
      list.append(el('li', item[1]));
    } else {
      list = null;
      out.push(el('p', line));
    }
  }
  return out;
}
