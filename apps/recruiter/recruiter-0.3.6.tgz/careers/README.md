# Careers — the public careers page

Map of this app (source: orchestra-ops/apps/recruiter, installed by install.js).

| File | Is |
|---|---|
| `app.js` | router, company header, open positions with team / place filters |
| `role.js` | a role's page and the application form (also the open application) |
| `shared.js` | the two public views it reads, salary and facts, the ad text as paragraphs and lists |

Public: it reads ONLY the public views `open_roles` and `company` (approved by
an admin for their exact SQL) and writes ONLY through the public action
`apply` (an insert; the server sets stage and source).
