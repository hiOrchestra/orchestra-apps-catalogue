// A role's page, and the application form (for a role, or an open
// application). Sending runs the one public action, `apply`: it adds the
// application and nothing else. The server sets its stage and source.
import { VIEWS, companyOf, facts, salary, prose } from './shared.js';

const { el, router, mount } = Orch;
const URL_RE = /^https?:\/\/\S+\.\S+/i;
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

const back = () => router.link('/', '← All open positions', { class: 'cr-back' });

export async function renderRole(params) {
  mount('view', el('p', { class: 'cr-muted' }, 'Loading…'));
  let role = null;
  try {
    role = ((await Orch.db.view(VIEWS.roles, { filter: { _id: Number(params.id) }, limit: 1 })).rows || [])[0] || null;
  } catch { /* said below */ }
  if (!role) {
    mount('view', [back(), el('h2', { class: 'cr-h2' }, 'This position is no longer open'), el('p', { class: 'cr-muted' }, 'It may have been filled. Have a look at the other open positions.')]);
    return;
  }
  document.title = role.title;
  const pay = salary(role);
  const section = (title, text) => (String(text || '').trim() ? el('section', { class: 'cr-section' }, [el('h3', { class: 'cr-h3' }, title), ...prose(text)]) : null);
  const form = el('div', { id: 'apply' });
  mount('view', [
    back(),
    el('h2', { class: 'cr-title' }, role.title),
    el('p', { class: 'cr-facts' }, [...facts(role), pay].filter(Boolean).join(' · ')),
    el('a', { class: 'oc-btn oc-btn--primary cr-apply-top', href: '#', onClick: (e) => { e.preventDefault(); form.scrollIntoView({ behavior: 'smooth' }); } }, 'Apply for this position'),
    section('About the role', role.summary),
    section('What you will do', role.tasks),
    section('What we are looking for', role.requirements),
    section('What we offer', role.benefits),
    form,
  ]);
  applyForm(form, role);
}

export async function renderApply() {
  const form = el('div');
  mount('view', [
    back(),
    el('h2', { class: 'cr-title' }, 'Open application'),
    el('p', { class: 'cr-facts' }, 'Tell us who you are and what you would like to do. We read every one.'),
    form,
  ]);
  applyForm(form, null);
}

async function applyForm(host, role) {
  const c = await companyOf();
  const who = c.name || 'the company';
  const field = (label, input, help) => el('label', { class: 'oc-field' }, [el('span', { class: 'oc-label' }, label), input, help ? el('span', { class: 'oc-help' }, help) : null]);
  const name = el('input', { class: 'oc-input', name: 'name', autocomplete: 'name', required: true, maxlength: '120' });
  const email = el('input', { class: 'oc-input', name: 'email', type: 'email', autocomplete: 'email', required: true, maxlength: '200' });
  const phone = el('input', { class: 'oc-input', name: 'phone', type: 'tel', autocomplete: 'tel', maxlength: '40' });
  const linkedin = el('input', { class: 'oc-input', name: 'linkedin', type: 'url', placeholder: 'https://www.linkedin.com/in/…', maxlength: '300' });
  const cv = el('input', { class: 'oc-input', name: 'cv_url', type: 'url', placeholder: 'https://…', maxlength: '500' });
  const message = el('textarea', { class: 'oc-textarea', name: 'message', rows: '6', maxlength: '4000' });
  const consent = el('input', { type: 'checkbox', name: 'consent' });
  const error = el('p', { class: 'cr-error', role: 'alert', hidden: true });
  const send = el('button', { class: 'oc-btn oc-btn--primary', type: 'submit' }, 'Send application');
  const privacy = c.privacy_url ? el('a', { href: c.privacy_url, target: '_blank', rel: 'noopener' }, 'privacy policy') : null;

  const fail = (text) => { error.textContent = text; error.hidden = false; };
  const form = el('form', { class: 'cr-form', novalidate: true }, [
    el('h3', { class: 'cr-h3' }, role ? 'Apply for this position' : 'Your application'),
    field('Full name', name),
    field('Email', email, `${who} will answer you here.`),
    field('Phone (optional)', phone),
    field('LinkedIn profile', linkedin),
    field('Link to your CV', cv, 'A link anyone can open: Google Drive, Dropbox, your own site. Give this, your LinkedIn, or both.'),
    field(role ? 'Why this role? (optional)' : 'What would you like to do?', message),
    el('label', { class: 'cr-consent' }, [consent, el('span', [
      `I agree that ${who} keeps my application to consider me${role ? ' for this position' : ''}`,
      ...(privacy ? [', as its ', privacy, ' describes.'] : ['.']),
    ])]),
    error,
    el('div', {}, [send]),
  ]);
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    error.hidden = true;
    const v = { name: name.value.trim(), email: email.value.trim().toLowerCase(), phone: phone.value.trim(), linkedin: linkedin.value.trim(), cv_url: cv.value.trim(), message: message.value.trim() };
    if (!v.name) return fail('Write your full name.');
    if (!EMAIL_RE.test(v.email)) return fail('Write an email address we can answer you at.');
    if (!v.linkedin && !v.cv_url) return fail('Give a link to your CV or to your LinkedIn profile.');
    if ((v.linkedin && !URL_RE.test(v.linkedin)) || (v.cv_url && !URL_RE.test(v.cv_url))) return fail('Links start with https:// — copy them from your browser.');
    if (!role && !v.message) return fail('Tell us briefly what you would like to do.');
    if (!consent.checked) return fail(`Tick the box so ${who} may keep your application.`);
    send.disabled = true;
    send.textContent = 'Sending…';
    try {
      await Orch.action('apply', { ...Object.fromEntries(Object.entries(v).filter(([, x]) => x)), consent: 'yes', ...(role ? { role_id: role._id } : {}) });
      mount(host, el('div', { class: 'cr-done' }, [
        el('h3', { class: 'cr-h3' }, 'Application sent'),
        el('p', {}, `Thank you, ${v.name.split(' ')[0]}. ${who} will read it and answer you at ${v.email}.`),
        router.link('/', 'See the other open positions'),
      ]));
      host.scrollIntoView({ behavior: 'smooth' });
    } catch (err) {
      send.disabled = false;
      send.textContent = 'Send application';
      const text = String((err && err.message) || '');
      if (/UNIQUE/i.test(text)) fail(`You already applied${role ? ' for this position' : ''} with ${v.email}. ${who} has it.`);
      else if (err && err.status === 429) fail('Many people are applying right now. Wait a minute and send it again.');
      else fail('It did not go through. Send it again in a minute; nothing was saved.');
    }
  });
  mount(host, form);
}
