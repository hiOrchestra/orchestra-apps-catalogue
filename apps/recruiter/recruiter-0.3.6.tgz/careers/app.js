// The careers page: the company, its open positions (filtered by team and
// place), each role's page and the application form. Public: anyone with the
// link, no sign-in. It shows only what the two approved public views return.
import { VIEWS, companyOf, facts } from './shared.js';
import { renderRole, renderApply } from './role.js';

const { el, router, mount } = Orch;

async function header() {
  const c = await companyOf();
  document.title = c.name ? `Jobs at ${c.name}` : 'Careers';
  const about = c.about ? el('p', { class: 'cr-about' }, c.about) : null;
  const links = [
    c.website ? el('a', { class: 'cr-chip', href: c.website, target: '_blank', rel: 'noopener' }, 'Website') : null,
    c.linkedin ? el('a', { class: 'cr-chip', href: c.linkedin, target: '_blank', rel: 'noopener' }, 'LinkedIn') : null,
  ].filter(Boolean);
  mount('company', [
    /^https:\/\//.test(c.logo_url || '')
      ? el('img', { class: 'cr-mark cr-mark--logo', src: c.logo_url, alt: '' })
      : el('div', { class: 'cr-mark', 'aria-hidden': 'true' }, (c.name || '·').trim().charAt(0).toUpperCase()),
    el('h1', { class: 'cr-name' }, c.name || 'Careers'),
    c.tagline || c.industry || c.size
      ? el('p', { class: 'cr-meta' }, [c.tagline, c.industry, c.size ? `${c.size} people` : ''].filter(Boolean).join(' · '))
      : null,
    about,
    links.length ? el('div', { class: 'cr-chips' }, links) : null,
  ]);
  mount('foot', c.privacy_url ? el('a', { href: c.privacy_url, target: '_blank', rel: 'noopener' }, 'Privacy policy') : null);
}

/** Every open role once, for the two filters' options. A careers page has tens of roles, not thousands. */
let optionsCache = null;
async function options() {
  if (!optionsCache) {
    const rows = (await Orch.db.view(VIEWS.roles, { limit: 200 })).rows || [];
    const uniq = (k) => [...new Set(rows.map((r) => r[k]).filter(Boolean))].sort();
    optionsCache = { department: uniq('department'), location: uniq('location') };
  }
  return optionsCache;
}

async function list(_params, path) {
  const q = new URLSearchParams(String(path || '').split('?')[1] || '');
  const pick = { department: q.get('department') || '', location: q.get('location') || '' };
  mount('view', el('p', { class: 'cr-muted' }, 'Loading open positions…'));
  let rows;
  let opts;
  try {
    const filter = Object.fromEntries(Object.entries(pick).filter(([, v]) => v));
    [rows, opts] = await Promise.all([
      Orch.db.view(VIEWS.roles, { filter, sort: 'title:asc', limit: 200 }).then((r) => r.rows || []),
      options(),
    ]);
  } catch (e) {
    mount('view', el('p', { class: 'cr-muted' }, e && e.status === 403
      ? 'This page is not showing positions yet. Come back soon.'
      : 'The open positions could not be loaded. Reload the page in a minute.'));
    return;
  }
  const go = () => {
    const next = new URLSearchParams(Object.entries(pick).filter(([, v]) => v));
    router.go(`/${next.toString() ? `?${next}` : ''}`);
  };
  const select = (key, label) => {
    const s = el('select', { class: 'oc-select', 'aria-label': label }, [
      el('option', { value: '' }, `All ${label.toLowerCase()}s`),
      ...opts[key].map((v) => el('option', { value: v, selected: v === pick[key] ? true : null }, v)),
    ]);
    s.addEventListener('change', () => { pick[key] = s.value; go(); });
    return el('label', { class: 'cr-filter' }, [el('span', { class: 'oc-label' }, label), s]);
  };
  const filtered = pick.department || pick.location;
  mount('view', [
    el('h2', { class: 'cr-h2' }, ['Open positions ', el('span', { class: 'cr-count' }, String(rows.length))]),
    opts.department.length > 1 || opts.location.length > 1
      ? el('div', { class: 'cr-filters' }, [
        opts.department.length > 1 ? select('department', 'Department') : null,
        opts.location.length > 1 ? select('location', 'Location') : null,
      ])
      : null,
    rows.length
      ? el('ul', { class: 'cr-roles' }, rows.map((r) => el('li', {}, router.link(`/roles/${r._id}`, [
        el('span', { class: 'cr-role__title' }, r.title),
        el('span', { class: 'cr-role__facts' }, facts(r).join(' · ')),
      ], { class: 'cr-role' }))))
      : el('p', { class: 'cr-muted' }, filtered ? 'No open position matches. Try all departments and locations.' : 'There are no open positions right now.'),
    el('div', { class: 'cr-open' }, [
      el('div', {}, [
        el('p', { class: 'cr-role__title' }, 'Open application'),
        el('p', { class: 'cr-role__facts' }, 'Nothing that fits yet? Tell us about you and we will keep you in mind.'),
      ]),
      router.link('/apply', 'Apply', { class: 'oc-btn' }),
    ]),
  ]);
}

router.define({
  '/': list,
  '/roles/:id': renderRole,
  '/apply': renderApply,
}, () => mount('view', el('p', { class: 'cr-muted' }, 'This page does not exist.'))).start();

// Each route starts at the top of the page, like a real page would.
window.addEventListener('hashchange', () => window.scrollTo(0, 0));
header();
