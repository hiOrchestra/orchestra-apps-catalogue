#!/usr/bin/env node
'use strict';
/**
 * Screening, step 3: write what the agent concluded.
 *
 * Reads the applicants step 1 claimed ($STEP_step_1) and the agent's answer
 * ($PRIOR). A result is written only when it is well formed: a verdict of
 * shortlist, maybe or no, a score from 0 to 100 (or none, when there was
 * nothing to read), and at least one reason. The verdict is a SUGGESTION: the
 * stage never changes here, a person moves people.
 *
 * An applicant with no usable result goes back in line. After three tries it
 * is marked Failed with the reason, and waits for "Screen again": a run that
 * keeps failing must not cost an agent turn every ten minutes forever.
 */
const L = require('./lib');

const VERDICTS = new Set(['shortlist', 'maybe', 'no']);
const MAX_TRIES = 3;

/** The agent's result for one applicant, cleaned, or the reason it cannot be used. */
function clean(r) {
  if (!r || typeof r !== 'object') return { why: 'no result for this applicant' };
  const verdict = String(r.verdict || '').toLowerCase().trim();
  if (!VERDICTS.has(verdict)) return { why: `verdict "${r.verdict}" is not shortlist, maybe or no` };
  let score = null;
  if (r.score !== null && r.score !== undefined && r.score !== '') {
    score = Math.round(Number(r.score));
    if (!Number.isFinite(score) || score < 0 || score > 100) return { why: `score "${r.score}" is not 0 to 100` };
  }
  const reasons = (Array.isArray(r.reasons) ? r.reasons : [r.reasons]).map((x) => String(x || '').trim()).filter(Boolean).slice(0, 6);
  if (!reasons.length) return { why: 'no reason given' };
  const read = (Array.isArray(r.read) ? r.read : []).map(String).filter((x) => ['cv', 'linkedin', 'message'].includes(x));
  return { verdict, score, reasons: reasons.map((x) => x.slice(0, 400)).join('\n'), note: read.length ? `Read: ${read.join(', ')}` : 'Read: nothing but the application' };
}

function main() {
  const claimed = (L.parse(process.env.STEP_step_1) || {}).applicants || [];
  const answer = L.parse(process.env.PRIOR);
  const out = { ok: true, ran: 'screening', claimed: claimed.length, screened: [], back_in_line: [], failed: [] };
  const ids = claimed.map((a) => Number(a.id)).filter(Boolean);
  if (!ids.length) return L.done(out);

  const results = new Map((answer && Array.isArray(answer.results) ? answer.results : []).map((r) => [Number(r && r.id), r]));
  const unreadable = !answer || !Array.isArray(answer.results);
  const now = L.sqlNow();
  const tally = { shortlist: 0, maybe: 0, no: 0 };
  for (const id of ids) {
    const got = unreadable ? { why: 'the agent\'s answer could not be read' } : clean(results.get(id));
    let data;
    if (!got.why) {
      data = { screen_status: 'Screened', verdict: got.verdict, score: got.score, reasons: got.reasons, screen_note: got.note, screened_at: now };
    } else {
      const row = L.one('SELECT screen_attempts FROM hr_applications WHERE _id = ?', id) || {};
      const tries = (Number(row.screen_attempts) || 0) + 1;
      data = tries >= MAX_TRIES
        ? { screen_status: 'Failed', screen_attempts: tries, screen_note: `Not screened after ${tries} tries: ${got.why}. Press "Screen again" to retry.` }
        : { screen_status: '', screen_attempts: tries, screen_note: `Try ${tries} failed: ${got.why}` };
    }
    try {
      L.write([{ op: 'update', table: 'hr_applications', id, when: { screen_status: 'Screening' }, data }]);
      if (data.screen_status === 'Screened') { out.screened.push({ id, verdict: got.verdict, score: got.score }); tally[got.verdict] += 1; }
      else (data.screen_status === 'Failed' ? out.failed : out.back_in_line).push({ id, why: got.why });
    } catch (e) {
      out.back_in_line.push({ id, why: `not written: ${e.message}` });
    }
  }
  if (out.screened.length) {
    out.telegram = L.notify(L.settings(), `Recruiter: screened ${out.screened.length} `
      + `(${tally.shortlist} to shortlist, ${tally.maybe} maybe, ${tally.no} no). Open Recruiter to decide.`);
  }
  return L.done(out);
}

try {
  main();
} catch (e) {
  process.stderr.write(`screening: ${e.message}\n`);
  process.exit(1);
}
