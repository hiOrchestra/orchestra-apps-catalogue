#!/usr/bin/env node
'use strict';
/**
 * Screening, step 1: pick the applicants to screen and claim them.
 *
 * Applicants of an OPEN role that were never screened (or were sent back with
 * "Screen again"), oldest first, up to "per run" from Settings. Each is marked
 * Screening before the agent looks, so the next run does not pick it again.
 * One left Screening for two hours belongs to a run that died: it goes back in
 * line. Open applications (no role) are not screened: there is nothing to
 * screen them against. Nor is anyone who did not tick the consent box (the
 * form requires it; a call around the form does not): nobody reads their CV.
 *
 * Prints what the agent needs and nothing more: the roles' requirements, and
 * for each applicant the links and the message. Not the email or the phone.
 *   node screen-pick.js [--force|--scheduled]
 * --force (the "Screen now" button) runs even when screening is off in Settings.
 */
const L = require('./lib');

const WAITING = "(a.screen_status IS NULL OR a.screen_status = '')";

function main() {
  const s = L.settings();
  const force = process.argv.includes('--force');
  if (s.screening !== 'on' && !force) return L.done({ roles: {}, applicants: [], skipped: 'Screening is off in Settings' });
  const per = Math.max(1, Math.min(20, Number(s.screen_per_run) || 8));

  const stale = L.all(`SELECT _id FROM hr_applications WHERE _deleted = 0 AND screen_status = 'Screening'
    AND datetime(screened_at) <= datetime('now', '-2 hours')`);
  for (const r of stale) {
    try { L.write([{ op: 'update', table: 'hr_applications', id: r._id, when: { screen_status: 'Screening' }, data: { screen_status: '' } }]); } catch { /* moved on */ }
  }

  const picked = L.all(`SELECT a._id, a.role_id, a.name, a.linkedin, a.cv_url, a.message, a.screen_status
    FROM hr_applications a JOIN hr_roles r ON r._id = a.role_id AND r._deleted = 0 AND r.status = 'Open'
    WHERE a._deleted = 0 AND a.consent = 'yes' AND ${WAITING}
    ORDER BY a._id LIMIT ?`, per);

  const applicants = [];
  const roles = {};
  for (const a of picked) {
    try {
      L.write([{ op: 'update', table: 'hr_applications', id: a._id, when: { screen_status: a.screen_status },
        data: { screen_status: 'Screening', screened_at: L.sqlNow() } }]);
    } catch { continue; /* someone else took it */ }
    applicants.push({ id: a._id, role_id: a.role_id, name: a.name || null, cv_url: a.cv_url || null, linkedin: a.linkedin || null, message: a.message || null });
    if (!roles[a.role_id]) {
      const r = L.one('SELECT title, location, workplace, employment, summary, tasks, requirements, screening_notes FROM hr_roles WHERE _id = ?', a.role_id);
      roles[a.role_id] = Object.fromEntries(Object.entries(r || {}).filter(([, v]) => v !== null && v !== ''));
    }
  }
  return L.done({ roles, applicants });
}

try {
  main();
} catch (e) {
  process.stderr.write(`screening: ${e.message}\n`);
  process.exit(1);
}
