SELECT a._id, a.role_id, COALESCE(r.title, CASE WHEN a.role_id IS NULL THEN 'Open application' ELSE 'A deleted role' END) AS role,
       a.name, a.email, a.phone, a.linkedin, a.cv_url, a.message, a.source,
       a.stage, a.notes, a.score, a.verdict, a.reasons,
       CASE WHEN a.role_id IS NULL OR COALESCE(a.consent, '') <> 'yes' THEN 'Not screened' ELSE COALESCE(NULLIF(a.screen_status, ''), 'Waiting') END AS screening, a.screen_note, a.screened_at,
       a._created_at AS applied_at
FROM hr_applications a
LEFT JOIN hr_roles r ON r._id = a.role_id AND r._deleted = 0
WHERE a._deleted = 0
