SELECT r._id, r.title, r.department, r.location, r.workplace, r.employment, r.status,
       r.opened_at, r.closed_at, r._created_at AS created_at, r.source_url, r.imported_from,
       (SELECT COUNT(*) FROM hr_applications a WHERE a._deleted = 0 AND a.role_id = r._id) AS applicants,
       (SELECT COUNT(*) FROM hr_applications a WHERE a._deleted = 0 AND a.role_id = r._id AND a.stage = 'New') AS new_count,
       (SELECT COUNT(*) FROM hr_applications a WHERE a._deleted = 0 AND a.role_id = r._id AND a.stage = 'Shortlist') AS shortlisted,
       (SELECT COUNT(*) FROM hr_applications a WHERE a._deleted = 0 AND a.role_id = r._id AND a.verdict = 'shortlist' AND a.stage = 'New') AS suggested
FROM hr_roles r
WHERE r._deleted = 0
