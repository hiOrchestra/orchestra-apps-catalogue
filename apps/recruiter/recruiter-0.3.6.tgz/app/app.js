// The router and the rail. Roles is home: every position, its status and how
// many people applied. A role's page is where the work is: its applicants,
// ranked by the agent's screening, moved through the stages by a person.
// Applicants lists everyone, open applications included. Company is what the
// careers page says about you, and whether screening runs.
import { render as roles } from './screens/roles.js';
import { render as role } from './screens/role.js';
import { render as roleForm } from './screens/role-form.js';
import { render as applicants } from './screens/applicants.js';
import { render as company } from './screens/company.js';
import { V, careersUrl } from './data.js';

const { el, router, fmt } = Orch;

const NAV = [['/', 'Roles'], ['/applicants', 'Applicants'], ['/company', 'Company']];

router.define({
  '/': roles, '/roles/new': roleForm, '/roles/:id': role, '/roles/:id/edit': roleForm,
  '/applicants': applicants, '/company': company,
}, () => Orch.mount('view', el('p', { class: 'oc-state' }, 'This screen does not exist.'))).start();

const counts = {};
Orch.mount('nav', NAV.map(([path, label]) => {
  counts[path] = el('span', { class: 'oc-count' });
  return router.link(path, [el('span', label), counts[path]], { class: 'oc-tab', 'data-path': path });
}));

const sectionOf = (p) => (p.startsWith('/roles') ? '/' : p.replace(/^(\/[^/?]*).*$/, '$1'));
function mark() {
  const here = sectionOf(router.path().split('?')[0]);
  for (const a of document.querySelectorAll('#nav .oc-tab')) a.setAttribute('aria-current', a.dataset.path === here ? 'page' : 'false');
}

/** The rail's counts, and a line with the link candidates open. */
async function pulse() {
  try {
    const [open, fresh] = await Promise.all([
      Orch.db.view(V.roles, { filter: { status: 'Open' }, count: true, limit: 1 }),
      Orch.db.view(V.applicants, { filter: { stage: 'New' }, count: true, limit: 1 }),
    ]);
    counts['/'].textContent = open.total ? fmt.number(open.total) : '';
    counts['/applicants'].textContent = fresh.total ? fmt.number(fresh.total) : '';
    Orch.mount('note', [
      open.total ? `${fmt.number(open.total)} open ${open.total === 1 ? 'role' : 'roles'} on ` : 'Open a role to show it on ',
      el('a', { href: careersUrl(), target: '_blank', rel: 'noopener' }, 'your careers page ↗'),
    ]);
  } catch { /* the rail stays quiet; each screen says its own errors */ }
}

// A row's panel is a modal on <body>, and the runtime leaves it open when the
// screen changes (opening one only changes the query). Leaving a screen removes it.
let screen = router.path().split('?')[0];
window.addEventListener('hashchange', () => {
  const now = router.path().split('?')[0];
  if (now !== screen) document.querySelectorAll('dialog[data-orch-detail]').forEach((d) => d.remove());
  screen = now;
  mark();
});
window.addEventListener('recruiter:changed', pulse);
mark();
pulse();
