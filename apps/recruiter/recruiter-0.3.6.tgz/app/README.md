# Recruiter — the hiring desk

Map of this app (source: orchestra-ops/apps/recruiter, installed by install.js).

| File | Is |
|---|---|
| `app.js` | router and rail: Roles (home), a role, its form, Applicants, Company |
| `data.js` | tables, views (`roles`, `applicants`), actions, stages, badges, `act()` |
| `screens/roles.js` | every role with applied / new / suggested / shortlisted |
| `screens/role.js` | one role: open, close, Screen now, its applicants |
| `screens/role-form.js` | write a role; `screening_notes` only the agent reads |
| `screens/applicants-table.js` | the ranked list both screens use, with bulk Shortlist / Reject / Screen again |
| `screens/applicant.js` | the panel: contact, what they sent, the agent's reasons, stage, notes |
| `screens/applicants.js` | everyone, open applications included |
| `screens/company.js` | the careers page header, screening on/off, Telegram |

Writes only through declared actions. Screening is the workflow
"Recruiter · Screen applicants"; this app starts it and shows its results.
