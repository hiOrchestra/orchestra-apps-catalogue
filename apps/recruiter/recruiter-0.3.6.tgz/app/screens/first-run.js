// First run: one card on top of Roles with the two things a fresh install
// needs before its careers page looks like anyone's (the `onboarding` list of
// listing.json). Each step is checked from the data every time it draws.
// Hide stamps hr_settings.onboarding_hidden_at, so it holds on every device.
import { T, A, V, act, careersUrl } from '../data.js';
import { focusImport } from './import.js';

const { el, router } = Orch;

/** The seed's company name: while it is still there, the careers page is not yours yet. */
export const PLACEHOLDER = 'Your company';

/** The card, or null once it was hidden (or Recruiter is not set up). `again` draws Roles again. */
export async function firstRunCard(again) {
  const [c, s, open] = await Promise.all([
    Orch.db.list(T.company, { limit: 1, sort: '_id:asc' }).then((r) => (r.rows || [])[0]),
    Orch.db.list(T.settings, { limit: 1, sort: '_id:asc' }).then((r) => (r.rows || [])[0]),
    Orch.db.view(V.roles, { filter: { status: 'Open' }, count: true, limit: 1 }).then((r) => Number(r.total) || 0),
  ]);
  if (!c || !s || s.onboarding_hidden_at) return null;
  const name = String(c.name || '').trim();
  const companyDone = Boolean(name) && name !== PLACEHOLDER;
  const roleDone = open > 0;

  const input = (value, attrs) => el('input', { class: 'oc-input', value: value == null ? '' : String(value), ...attrs });
  const f = {
    name: input(companyDone ? name : '', { maxlength: '120', placeholder: 'Acme', required: true, 'aria-label': 'Company name' }),
    tagline: input(c.tagline === 'One line on what you do' ? '' : c.tagline, { maxlength: '160', placeholder: 'One line on what you do', 'aria-label': 'One line on what you do' }),
    logo_url: input(c.logo_url, { type: 'url', placeholder: 'https://… (optional)', 'aria-label': 'Logo URL, optional' }),
  };
  const saveCompany = async (e) => {
    e.preventDefault();
    const data = Object.fromEntries(Object.entries(f).map(([k, i]) => [k, i.value.trim()]));
    if (!data.name || data.name === PLACEHOLDER) { Orch.toast('Write your company name.', { error: true }); return; }
    if (await act(A.saveCompany, { id: c._id, ...data }, 'Saved: your careers page shows it now.')) again();
  };

  const url = careersUrl();
  const copy = el('button', { class: 'oc-btn oc-btn--sm', type: 'button', onClick: async () => {
    try { await navigator.clipboard.writeText(url); Orch.toast('Link copied.'); } catch { Orch.toast('Copy it from the line above.', { error: true }); }
  } }, 'Copy');

  const step = (n, title, done, body) => el('li', { class: `rc-step${done ? ' rc-step--done' : ''}` }, [
    el('div', { class: 'rc-step__head' }, [
      el('span', { class: 'rc-step__n' }, n),
      el('span', { class: 'rc-step__title' }, title),
      el('span', { class: `oc-badge${done ? ' oc-badge--good' : ''}` }, done ? 'Done' : 'To do'),
    ]),
    body ? el('div', { class: 'rc-step__body' }, body) : null,
  ]);

  return el('section', { class: 'rc-card rc-first', 'aria-label': 'Getting started' }, [
    el('div', { class: 'rc-first__head' }, [
      el('h2', { class: 'oc-h3' }, 'Getting started'),
      el('button', { class: 'oc-btn oc-btn--sm oc-btn--ghost', type: 'button', onClick: async () => {
        if (await act(A.hideOnboarding, { id: s._id })) again();
      } }, 'Hide'),
    ]),
    el('ol', { class: 'rc-steps' }, [
      step('01', 'Your company', companyDone, companyDone ? null : [
        el('p', {}, 'What candidates see at the top of your careers page.'),
        el('form', { class: 'rc-step__form', onSubmit: saveCompany }, [
          f.name, f.tagline, f.logo_url,
          el('button', { class: 'oc-btn oc-btn--primary oc-btn--sm', type: 'submit' }, 'Save'),
        ]),
      ]),
      step('02', 'Your first role', roleDone, roleDone
        ? [
          el('p', {}, 'Your careers page is live with it. Share the link:'),
          el('p', {}, el('a', { href: url, target: '_blank', rel: 'noopener' }, url)),
          copy,
        ]
        : [
          el('p', {}, 'Write it and open it: open roles are the only ones the careers page shows.'),
          router.link('/roles/new', 'New role', { class: 'oc-btn oc-btn--sm' }),
          el('button', { class: 'rc-quiet', type: 'button', onClick: focusImport }, 'Already have a jobs page? Import it'),
        ]),
    ]),
  ]);
}
