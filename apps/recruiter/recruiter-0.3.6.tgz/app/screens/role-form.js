// Writing a role: what the careers page shows (title, where, how, pay, and
// the four texts) and, apart, what only the agent reads (screening notes).
// A new role starts as a draft: nothing is public until you open it.
import { T, A, WORKPLACES, EMPLOYMENTS, act, head } from '../data.js';

const { el, router } = Orch;

const input = (name, value, attrs = {}) => el('input', { class: 'oc-input', name, value: value == null ? '' : String(value), ...attrs });
const select = (name, value, options) => el('select', { class: 'oc-select', name }, [
  el('option', { value: '' }, '—'), ...options.map((o) => el('option', { value: o, selected: o === value ? true : null }, o)),
]);
const area = (name, value, rows, placeholder) => { const t = el('textarea', { class: 'oc-textarea', name, rows: String(rows), placeholder }); t.value = value || ''; return t; };
const field = (label, control, help) => el('label', { class: 'oc-field' }, [el('span', { class: 'oc-label' }, label), control, help ? el('span', { class: 'oc-help' }, help) : null]);

export async function render(params) {
  const role = params && params.id ? await Orch.db.get(T.roles, params.id) : null;
  if (params && params.id && !role) { Orch.mount('view', el('p', { class: 'oc-state' }, 'This role does not exist.')); return; }
  const r = role || { currency: 'EUR', salary_period: 'year' };
  const f = {
    title: input('title', r.title, { required: true, maxlength: '140', placeholder: 'Senior Backend Engineer' }),
    department: input('department', r.department, { maxlength: '80', placeholder: 'Engineering' }),
    location: input('location', r.location, { maxlength: '120', placeholder: 'Barcelona, Spain' }),
    workplace: select('workplace', r.workplace, WORKPLACES),
    employment: select('employment', r.employment, EMPLOYMENTS),
    salary_min: input('salary_min', r.salary_min, { type: 'number', min: '0', step: '1000' }),
    salary_max: input('salary_max', r.salary_max, { type: 'number', min: '0', step: '1000' }),
    currency: select('currency', r.currency, ['EUR', 'USD', 'GBP', 'CHF', 'MXN', 'ARS', 'BRL', 'COP', 'CLP']),
    salary_period: select('salary_period', r.salary_period, ['year', 'month', 'hour']),
    summary: area('summary', r.summary, 3, 'Two or three sentences: the team, the job, why it matters.'),
    tasks: area('tasks', r.tasks, 6, '- One task per line, starting with a dash'),
    requirements: area('requirements', r.requirements, 6, '- 5+ years of backend development\n- Solid SQL'),
    benefits: area('benefits', r.benefits, 4, '- Flexible hours'),
    screening_notes: area('screening_notes', r.screening_notes, 3, 'Must have been on-call for a production system.'),
  };
  const save = async () => {
    const data = {};
    for (const [k, c] of Object.entries(f)) data[k] = c.value.trim();
    if (!data.title) { Orch.toast('A role needs a title.', { error: true }); f.title.focus(); return; }
    for (const k of ['salary_min', 'salary_max']) data[k] = data[k] === '' ? '' : Math.max(0, Math.round(Number(data[k]) || 0));
    if (data.salary_min && data.salary_max && data.salary_min > data.salary_max) { Orch.toast('The lowest salary is above the highest.', { error: true }); return; }
    const out = await act(role ? A.updateRole : A.createRole, role ? { id: role._id, ...data } : data, role ? 'Saved.' : 'Saved as a draft. Open it when it is ready.');
    if (out) router.go(`/roles/${role ? role._id : out._id}`);
  };
  Orch.mount('view', [
    router.link(role ? `/roles/${role._id}` : '/', role ? `← ${role.title}` : '← Roles', { class: 'rc-back' }),
    head(role ? 'Edit role' : 'New role', role && role.status === 'Open' ? 'This role is open: what you save shows on your careers page at once.' : 'Nothing is public until you open the role.'),
    el('form', { class: 'rc-form', onSubmit: (e) => { e.preventDefault(); save(); } }, [
      el('fieldset', { class: 'rc-fieldset' }, [
        el('legend', {}, 'On the careers page'),
        field('Title', f.title),
        el('div', { class: 'rc-grid' }, [field('Team', f.department), field('Location', f.location), field('Workplace', f.workplace), field('Contract', f.employment)]),
        el('div', { class: 'rc-grid' }, [field('Salary from', f.salary_min), field('Salary to', f.salary_max), field('Currency', f.currency), field('Per', f.salary_period)]),
        field('About the role', f.summary),
        field('What they will do', f.tasks, 'Lines starting with a dash show as a list.'),
        field('What you are looking for', f.requirements, 'The agent screens every applicant against this.'),
        field('What you offer', f.benefits),
      ]),
      el('fieldset', { class: 'rc-fieldset' }, [
        el('legend', {}, 'Only for screening'),
        field('Must-haves for the agent', f.screening_notes, 'Never shown to candidates. Anything the agent should weigh that the ad does not say.'),
      ]),
      el('div', { class: 'rc-actions' }, [el('button', { class: 'oc-btn oc-btn--primary', type: 'submit' }, role ? 'Save changes' : 'Save as draft')]),
    ]),
  ]);
}
