// Roles: every position, its status, and how many applied — new ones and the
// agent's shortlist suggestions first, since those are what wait for you.
// One line imports the roles of an existing jobs page as drafts.
import { V, badge, head, safeUrl } from '../data.js';
import { firstRunCard } from './first-run.js';
import { importLine } from './import.js';

const { el, router, fmt } = Orch;

export function render(_params, path) {
  const list = el('div');
  const first = el('div');
  let table = null;
  firstRunCard(() => render(_params, path)).then((card) => first.replaceChildren(...(card ? [card] : []))).catch(() => {});
  Orch.mount('view', [
    first,
    head('Roles', 'Open a role to show it on your careers page. People apply there; the agent screens them against what you ask for.',
      [router.link('/roles/new', 'New role', { class: 'oc-btn oc-btn--primary' })]),
    importLine(() => { if (table) table.reload(); window.dispatchEvent(new CustomEvent('recruiter:changed')); }),
    list,
  ]);
  table = Orch.table({
    into: list, path: '/', query: path, view: V.roles, search: ['title', 'department', 'location'], pageSize: 50,
    sort: 'status:desc',
    columns: [
      { key: 'title', label: 'Role', render: (r) => el('span', { class: 'rc-role' }, [
        router.link(`/roles/${r._id}`, r.title || 'Untitled role'),
        r.imported_from ? el('span', { class: 'rc-tag' }, 'Imported') : null,
        safeUrl(r.source_url) ? el('a', { class: 'rc-orig', href: safeUrl(r.source_url), target: '_blank', rel: 'noopener noreferrer', title: 'The original posting' }, 'Original ↗') : null,
      ]) },
      { key: 'status', label: 'Status', render: (r) => badge(r.status) },
      { key: 'department', label: 'Team', format: 'text' },
      { key: 'location', label: 'Location', format: 'text' },
      { key: 'applicants', label: 'Applied', numeric: true, format: 'number' },
      { key: 'new_count', label: 'New', numeric: true, render: (r) => (r.new_count ? el('span', { class: 'rc-strong' }, fmt.number(r.new_count)) : '—') },
      { key: 'suggested', label: 'Suggested', numeric: true, render: (r) => (r.suggested ? fmt.number(r.suggested) : '—') },
      { key: 'shortlisted', label: 'Shortlisted', numeric: true, format: 'number' },
    ],
    filters: [{ key: 'status', label: 'Status', options: ['Open', 'Draft', 'Closed'] }],
    empty: 'No roles yet. Write the first one: New role.',
  });
}
