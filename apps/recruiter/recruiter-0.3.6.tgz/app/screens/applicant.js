// One applicant, in the panel a row opens: how to reach them, what they sent,
// what the agent concluded and why, and the two things a person does here —
// move them to a stage, and keep a note. Nothing here writes to the applicant.
import { A, STAGES, act, badge, verdictBadge } from '../data.js';

const { el, fmt } = Orch;

const link = (href, text) => (href ? el('a', { href, target: '_blank', rel: 'noopener' }, text) : null);
const row = (label, value) => (value ? el('div', { class: 'rc-kv' }, [el('span', { class: 'oc-label' }, label), el('div', {}, value)]) : null);

function screening(a) {
  if (!a.role_id) return el('p', { class: 'oc-muted' }, 'An open application: there is no role to screen it against.');
  if (a.consent !== 'yes') return el('p', { class: 'rc-bad' }, 'Sent without the consent box ticked, so the agent does not read it. Ask them before you keep it.');
  if (a.screen_status === 'Screened') {
    return el('div', { class: 'rc-screen' }, [
      el('div', { class: 'rc-inline' }, [verdictBadge(a.verdict), a.score !== null && a.score !== undefined ? el('span', `${fmt.number(a.score)} / 100`) : null]),
      el('ul', { class: 'rc-reasons' }, String(a.reasons || '').split('\n').filter(Boolean).map((r) => el('li', r))),
      el('p', { class: 'oc-small oc-muted' }, `${a.screen_note || ''}${a.screened_at ? ` · ${fmt.date(a.screened_at)}` : ''}. A suggestion: you decide.`),
    ]);
  }
  if (a.screen_status === 'Failed') return el('p', { class: 'rc-bad' }, a.screen_note || 'The agent could not screen this applicant.');
  if (a.screen_status === 'Screening') return el('p', { class: 'oc-muted' }, 'The agent is reading this application now.');
  return el('p', { class: 'oc-muted' }, a.screen_note || 'Waiting for the agent. It screens new applicants every ten minutes.');
}

export function panel(a, reload) {
  const stage = el('select', { class: 'oc-select', 'aria-label': 'Stage' }, STAGES.map((s) => el('option', { value: s, selected: s === a.stage ? true : null }, s)));
  stage.addEventListener('change', async () => {
    if (await act(A.move, { ids: [a._id], stage: stage.value }, `Moved to ${stage.value}.`)) reload();
  });
  const notes = el('textarea', { class: 'oc-textarea', rows: '4', placeholder: 'Only your team sees this.' });
  notes.value = a.notes || '';
  const again = el('button', { class: 'oc-btn oc-btn--ghost oc-btn--sm', type: 'button' }, 'Screen again');
  again.addEventListener('click', async () => {
    if (await act(A.screenAgain, { ids: [a._id] }, 'Back in line: the agent screens it within ten minutes.')) reload();
  });
  return el('div', { class: 'rc-panel' }, [
    el('div', {}, [el('h2', { class: 'oc-h2' }, a.name || a.email), el('div', { class: 'rc-inline' }, [badge(a.stage), el('span', { class: 'oc-muted' }, `Applied ${fmt.date(a._created_at)} · ${a.source || ''}`)])]),
    row('Email', link(`mailto:${a.email}`, a.email)),
    row('Phone', a.phone ? link(`tel:${a.phone}`, a.phone) : null),
    row('CV', link(a.cv_url, a.cv_url)),
    row('LinkedIn', link(a.linkedin, a.linkedin)),
    row('Message', a.message ? el('p', { class: 'rc-message' }, a.message) : null),
    el('section', { class: 'rc-section' }, [el('h3', { class: 'oc-h3' }, 'Screening'), screening(a), a.role_id ? again : null]),
    el('section', { class: 'rc-section' }, [
      el('label', { class: 'oc-field' }, [el('span', { class: 'oc-label' }, 'Stage'), stage]),
      el('label', { class: 'oc-field' }, [el('span', { class: 'oc-label' }, 'Notes'), notes]),
      el('button', { class: 'oc-btn oc-btn--sm', type: 'button', onClick: () => act(A.note, { id: a._id, notes: notes.value }, 'Note saved.') }, 'Save note'),
    ]),
  ]);
}
