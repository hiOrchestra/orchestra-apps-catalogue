// Import from a URL: one line on Roles. Paste a careers page, press Import,
// and the roles it lists arrive as drafts to review. The work runs as a
// workflow on the instance (import_roles inserts the request and starts it);
// this line shows the last import's state and asks again until it is done.
import { T, A, act } from '../data.js';

const { el } = Orch;

const RUNNING = ['Waiting', 'Working', 'Reading'];
const STALE_MS = 30 * 60 * 1000;
export const IMPORT_FIELD = 'rc-import-url';

/** Put the cursor in the import field (the first-run card's quiet alternative). */
export function focusImport() {
  const i = document.getElementById(IMPORT_FIELD);
  if (!i) return;
  i.scrollIntoView({ block: 'center', behavior: 'smooth' });
  i.focus();
}

const since = (v) => { const d = new Date(/[zZ]|[+-]\d\d:?\d\d$/.test(String(v)) ? v : `${String(v || '').replace(' ', 'T')}Z`); return Number.isNaN(d.getTime()) ? 0 : Date.now() - d.getTime(); };
const running = (r) => r && RUNNING.includes(r.status) && since(r.requested_at || r._created_at) < STALE_MS;

/** The line: the field, the button, and the last import under them. `changed` reloads the roles once one finishes. */
export function importLine(changed) {
  const input = el('input', { class: 'oc-input', id: IMPORT_FIELD, type: 'url', inputmode: 'url', required: true, maxlength: '600',
    placeholder: 'https://yourcompany.com/careers', 'aria-label': 'Link to your jobs page' });
  const button = el('button', { class: 'oc-btn', type: 'submit' }, 'Import');
  const status = el('p', { class: 'rc-import__status', 'aria-live': 'polite' });
  let timer = null;
  let wasRunning = false;

  const show = (r) => {
    const busy = running(r);
    button.disabled = busy;
    status.className = 'rc-import__status';
    if (!r) { status.textContent = 'Paste the page that lists your jobs. Each one becomes a draft here; nothing is published until you open it.'; return busy; }
    if (busy) status.textContent = r.status === 'Reading' ? 'Importing: the agent is reading the page. This takes a few minutes.' : 'Importing: opening the page…';
    else if (RUNNING.includes(r.status)) { status.textContent = 'That import did not finish. Press Import to try again.'; status.classList.add('rc-bad'); }
    else {
      status.textContent = r.note || (r.status === 'Done' ? 'Imported.' : 'That import did not work. Press Import to try again.');
      if (r.status === 'Failed') status.classList.add('rc-bad');
    }
    return busy;
  };

  const look = async () => {
    clearTimeout(timer);
    if (!status.isConnected && wasRunning) return; // the screen changed: stop asking
    let r = null;
    try { r = ((await Orch.db.list(T.imports, { limit: 1, sort: '_id:desc' })).rows || [])[0] || null; } catch { return; }
    const busy = show(r);
    if (wasRunning && !busy && changed) changed();
    wasRunning = busy;
    if (busy) timer = setTimeout(look, 4000);
  };

  const submit = async (e) => {
    e.preventDefault();
    let url = input.value.trim();
    if (url && !/^[a-z]+:\/\//i.test(url)) url = `https://${url}`;
    if (!/^https:\/\/[^\s/]+\.[^\s]+$/i.test(url)) { Orch.toast('Paste an https:// link to the page that lists your jobs.', { error: true }); input.focus(); return; }
    button.disabled = true;
    if (await act(A.importRoles, { url }, 'Importing: drafts appear below in a few minutes.')) { input.value = ''; wasRunning = true; }
    look();
  };

  look();
  return el('section', { class: 'rc-import', 'aria-label': 'Import from a URL' }, [
    el('form', { class: 'rc-import__row', onSubmit: submit }, [el('label', { class: 'rc-import__label', for: IMPORT_FIELD }, 'Import from a URL'), input, button]),
    status,
  ]);
}
