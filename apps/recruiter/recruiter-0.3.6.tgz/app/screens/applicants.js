// Applicants: everyone who applied, to any role or to none (an open
// application), ranked by the agent's score.
import { head } from '../data.js';
import { applicantsTable } from './applicants-table.js';

const { el } = Orch;

export function render(_params, path) {
  const list = el('div');
  Orch.mount('view', [head('Applicants', 'Everyone who applied, to a role or with an open application. Open a person to move them or keep a note.'), list]);
  applicantsTable({ into: list, path: '/applicants', query: path, showRole: true });
}
