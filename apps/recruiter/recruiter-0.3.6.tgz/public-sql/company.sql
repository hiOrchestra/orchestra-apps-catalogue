SELECT name, tagline, about, website, linkedin, industry, size, privacy_url, logo_url
FROM hr_company
WHERE _deleted = 0
ORDER BY _id
LIMIT 1
