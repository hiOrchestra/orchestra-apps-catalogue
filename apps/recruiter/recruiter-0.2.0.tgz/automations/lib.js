'use strict';
/**
 * Recruiter automations: what the screening scripts share. The same shape as
 * Outreach's lib.js, cut to what screening needs.
 *
 * Reads go to the project's SQLite file directly, read-only and
 * parameterised. Every write goes through `orch-database batch`, the
 * platform's own writer: one transaction, and a `when` precondition checked
 * inside the UPDATE, so a claim ("this applicant is being screened") is atomic.
 *
 * Locally (RECRUITER_LOCAL=1) the same batch runs against RECRUITER_DB with the
 * same semantics, and a Telegram message is only recorded, never sent.
 */
const { DatabaseSync } = require('node:sqlite');
const { execFileSync } = require('child_process');
const path = require('path');

const PROJECT = process.env.RECRUITER_PROJECT || 'default';
const STATE = process.env.OPENCLAW_STATE_DIR || '/home/node/.openclaw';
const DB_PATH = process.env.RECRUITER_DB || path.join(STATE, 'orchestra', 'projects', PROJECT, 'data', 'data.db');
const LOCAL = process.env.RECRUITER_LOCAL === '1';

// ── reading ──────────────────────────────────────────────────────────────
let reader = null;
function db() {
  if (!reader) {
    reader = new DatabaseSync(DB_PATH, { readOnly: true });
    reader.exec('PRAGMA busy_timeout = 5000');
  }
  return reader;
}
const all = (sql, ...params) => db().prepare(sql).all(...params);
const one = (sql, ...params) => db().prepare(sql).get(...params);

function settings() {
  const s = one('SELECT * FROM hr_settings WHERE _deleted = 0 ORDER BY _id LIMIT 1');
  if (!s) throw new Error('Recruiter has no settings row: it is not installed');
  return s;
}

// ── writing ──────────────────────────────────────────────────────────────
/** One transaction, all or nothing. */
function write(ops) {
  return (LOCAL ? localBatch(ops) : cliBatch(ops)).applied;
}

function cliBatch(ops) {
  let out;
  try {
    out = execFileSync('orch-database', ['--project', PROJECT, 'batch', '--ops', JSON.stringify(ops)],
      { encoding: 'utf8', timeout: 120000, maxBuffer: 16 << 20 });
  } catch (e) {
    let j = null;
    try { j = JSON.parse(String(e.stdout || '')); } catch { /* not JSON */ }
    throw new Error((j && j.error) || String(e.stderr || e.message).trim().slice(0, 300));
  }
  const j = JSON.parse(out);
  if (!j.ok) throw new Error(j.error || 'the write failed');
  return j;
}

/** orch-database's run_batch, for local tests: same `when`, same all-or-none. */
function localBatch(ops) {
  const w = new DatabaseSync(DB_PATH);
  w.exec('PRAGMA busy_timeout = 5000');
  const now = sqlNow();
  let applied = 0;
  w.exec('BEGIN IMMEDIATE');
  try {
    ops.forEach((op, i) => {
      const data = Object.fromEntries(Object.entries(op.data || {}).filter(([k]) => !k.startsWith('_')));
      const when = op.when || {};
      const r = w.prepare(`UPDATE "${op.table}" SET ${Object.keys(data).map((c) => `"${c}" = ?`).join(', ')}, _updated_at = ? `
        + `WHERE _id = ? AND _deleted = 0${Object.keys(when).map((c) => ` AND "${c}" IS ?`).join('')}`)
        .run(...Object.values(data), now, op.id, ...Object.values(when));
      if (!r.changes) throw new Error(`op ${i}: row ${op.id} changed meanwhile (precondition failed)`);
      applied += 1;
    });
    w.exec('COMMIT');
  } catch (e) {
    w.exec('ROLLBACK');
    w.close();
    throw e;
  }
  w.close();
  return { ok: true, applied };
}

/** 'YYYY-MM-DD HH:MM:SS' in UTC: the format orch-database stamps rows with. */
const sqlNow = (d = new Date()) => d.toISOString().slice(0, 19).replace('T', ' ');

// ── the agent's answer ───────────────────────────────────────────────────
/** A step's output as JSON: bare, inside prose, or wrapped as { content }. */
function parse(text) {
  const t = String(text || '').trim();
  const tries = [t];
  const a = t.indexOf('{');
  const b = t.lastIndexOf('}');
  if (a >= 0 && b > a) tries.push(t.slice(a, b + 1));
  for (const x of tries) {
    try {
      const j = JSON.parse(x);
      if (j && typeof j === 'object') {
        if (typeof j.content === 'string' && !j.results && !j.applicants) return parse(j.content);
        return j;
      }
    } catch { /* next */ }
  }
  return null;
}

// ── who is calling ───────────────────────────────────────────────────────
// A workflow's commands run as its agent (ORC-181 §6): every call to the
// instance goes out with that agent's identity. The platform secret is only a
// fallback for running a script by hand as node.
function identityHeaders() {
  const id = process.env.ORCHESTRA_AGENT_ID;
  const token = process.env.ORCHESTRA_AGENT_TOKEN;
  if (id && token) return { 'x-orchestra-agent': id, 'x-orchestra-agent-token': token };
  const secret = process.env.HOOKS_TOKEN || process.env.OPENCLAW_GATEWAY_TOKEN || '';
  return secret ? { 'x-orchestra-secret': secret } : {};
}

// ── telling the person ───────────────────────────────────────────────────
// The Telegram chat in Settings gets one line from the instance's bot (no
// agent turn). Headers go to curl on stdin, never argv. Never throws: the run's
// output says whether it went.
const TG_CHAT = /^(-?\d{5,20}|@[A-Za-z0-9_]{5,32})$/;
function notify(s, text) {
  const to = String((s && s.notify_telegram) || '').trim();
  if (!to) return { sent: false, why: 'No Telegram chat in Settings' };
  if (!TG_CHAT.test(to)) return { sent: false, why: 'The Telegram chat in Settings is not a chat id or @username' };
  const message = String(text || '').slice(0, 3800);
  if (LOCAL) return { sent: true, to, fake: true, text: message };
  const q = (v) => `"${String(v).replace(/[\\"]/g, '\\$&')}"`;
  const config = [
    `url = ${q(`http://127.0.0.1:${Number(process.env.API_SERVER_PORT || 3001)}/api/channels/telegram/notify`)}`,
    'request = "POST"',
    'header = "Content-Type: application/json"',
    ...Object.entries(identityHeaders()).map(([k, v]) => `header = ${q(`${k}: ${v}`)}`),
    `data = ${q(JSON.stringify({ to, message }))}`,
  ].join('\n');
  try {
    const out = execFileSync('curl', ['-sS', '-m', '30', '-K', '-'], { input: config, timeout: 35000, stdio: ['pipe', 'pipe', 'pipe'] }).toString();
    let j = null;
    try { j = JSON.parse(out); } catch { /* reported below */ }
    if (j && j.success) return { sent: true, to };
    return { sent: false, to, why: String((j && j.error && (j.error.message || j.error)) || out).trim().slice(0, 200) };
  } catch (e) {
    return { sent: false, to, why: String((e.stderr && e.stderr.toString()) || e.message).trim().slice(0, 200) };
  }
}

/** Print the run's one-line result (the workflow step's output) and stop. */
function done(result) {
  process.stdout.write(`${JSON.stringify(result)}\n`);
  return result;
}

module.exports = { PROJECT, DB_PATH, all, one, settings, write, sqlNow, parse, identityHeaders, notify, done };
