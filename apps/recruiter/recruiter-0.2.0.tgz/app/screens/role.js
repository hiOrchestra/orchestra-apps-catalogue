// A role's page: its status and the one action that changes it (open, close,
// open again), a link to how candidates see it, and its applicants ranked by
// the agent's score.
import { T, A, act, badge, head, careersUrl } from '../data.js';
import { applicantsTable } from './applicants-table.js';

const { el, router } = Orch;

export async function render(params, path) {
  const role = await Orch.db.get(T.roles, params.id);
  if (!role) { Orch.mount('view', el('p', { class: 'oc-state' }, 'This role does not exist.')); return; }
  const flip = async (name, text, confirm) => {
    if (confirm && !(await Orch.confirm(confirm, { yes: text }))) return;
    // The same route does not re-render on router.go: draw it again here.
    if (await act(name, { id: role._id }, text === 'Open it' ? 'Open: it is on your careers page now.' : 'Closed: it is off your careers page.')) render(params, path);
  };
  const actions = [
    router.link(`/roles/${role._id}/edit`, 'Edit', { class: 'oc-btn' }),
    role.status === 'Open'
      ? el('button', { class: 'oc-btn', type: 'button', onClick: () => flip(A.closeRole, 'Close it', 'Close this role? It leaves your careers page; its applicants stay here.') }, 'Close')
      : el('button', { class: 'oc-btn oc-btn--primary', type: 'button', onClick: () => flip(A.openRole, 'Open it', role.status === 'Draft' ? 'Open this role? It appears on your careers page and people can apply.' : 'Open it again on your careers page?') }, role.status === 'Draft' ? 'Open' : 'Open again'),
    role.status === 'Open' ? el('button', { class: 'oc-btn oc-btn--ghost', type: 'button', onClick: async () => {
      if (await act(A.screenNow, {}, 'Screening started: results appear here in a few minutes.')) setTimeout(() => ctl.reload(), 1500);
    } }, 'Screen now') : null,
  ].filter(Boolean);
  const facts = [role.department, role.location, role.workplace, role.employment].filter(Boolean).join(' · ');
  const list = el('div');
  Orch.mount('view', [
    router.link('/', '← Roles', { class: 'rc-back' }),
    head(role.title || 'Untitled role', null, actions, true),
    el('div', { class: 'rc-inline' }, [
      badge(role.status),
      facts ? el('span', { class: 'oc-muted' }, facts) : null,
      role.status === 'Open' ? el('a', { href: careersUrl(`/roles/${role._id}`), target: '_blank', rel: 'noopener' }, 'See it as candidates do ↗') : null,
    ]),
    role.status === 'Open' && !String(role.requirements || '').trim()
      ? el('p', { class: 'rc-warn' }, 'This role has no requirements written: the agent has nothing to screen against. Edit it and add them.')
      : null,
    el('h2', { class: 'oc-h2 rc-sub' }, 'Applicants'),
    list,
  ]);
  const ctl = applicantsTable({
    into: list, path: `/roles/${role._id}`, query: path, filter: { role_id: role._id },
    empty: role.status === 'Open' ? 'Nobody has applied yet. Share the role\'s link from your careers page.' : 'Nobody has applied. Open the role to show it on your careers page.',
  });
}
