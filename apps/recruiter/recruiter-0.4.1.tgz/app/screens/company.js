// Company: what your careers page says about you and where it lives. Whether the
// agent screens new applicants on its own, and where it tells you, are managed in
// Orchestra (Apps → Recruiter → Ajustes): what they are now, and a way there.
import { T, A, act, head, careersUrl } from '../data.js';

const { el } = Orch;

const field = (label, control, help) => el('label', { class: 'oc-field' }, [el('span', { class: 'oc-label' }, label), control, help ? el('span', { class: 'oc-help' }, help) : null]);
const input = (value, attrs = {}) => el('input', { class: 'oc-input', value: value == null ? '' : String(value), ...attrs });

export async function render() {
  const [c, s] = await Promise.all([
    Orch.db.list(T.company, { limit: 1, sort: '_id:asc' }).then((r) => (r.rows || [])[0]),
    Orch.db.list(T.settings, { limit: 1, sort: '_id:asc' }).then((r) => (r.rows || [])[0]),
  ]);
  if (!c || !s) { Orch.mount('view', el('p', { class: 'oc-state' }, 'Recruiter is not set up on this workspace yet.')); return; }
  const f = {
    name: input(c.name, { maxlength: '120' }), tagline: input(c.tagline, { maxlength: '160' }),
    industry: input(c.industry, { maxlength: '80' }), size: input(c.size, { maxlength: '40', placeholder: '11-50' }),
    website: input(c.website, { type: 'url', placeholder: 'https://' }), linkedin: input(c.linkedin, { type: 'url', placeholder: 'https://www.linkedin.com/company/…' }),
    privacy_url: input(c.privacy_url, { type: 'url', placeholder: 'https://' }),
    logo_url: input(c.logo_url, { type: 'url', placeholder: 'https://… (optional)' }),
  };
  const about = el('textarea', { class: 'oc-textarea', rows: '5' });
  about.value = c.about || '';
  const saveCompany = () => {
    const data = { about: about.value.trim() };
    for (const [k, i] of Object.entries(f)) data[k] = i.value.trim();
    if (!data.name) { Orch.toast('Your careers page needs the company name.', { error: true }); return; }
    act(A.saveCompany, { id: c._id, ...data }, 'Saved: your careers page shows it now.');
  };

  const manage = el('a', { class: 'oc-btn', target: '_blank', rel: 'noopener', hidden: true }, 'Open the settings in Orchestra');
  const where = el('p', { class: 'oc-small oc-muted' }, 'In Orchestra: Apps → Recruiter → Ajustes.');
  if (Orch.manageUrl) Orch.manageUrl('settings').then((u) => { if (u) { manage.href = u; manage.hidden = false; where.hidden = true; } });

  const url = careersUrl();
  Orch.mount('view', [
    head('Company', 'What your careers page says about you.'),
    el('section', { class: 'rc-card' }, [
      el('h2', { class: 'oc-h3' }, 'Your careers page'),
      el('p', {}, [el('a', { href: url, target: '_blank', rel: 'noopener' }, url)]),
      el('p', { class: 'oc-small oc-muted' }, 'Put this link on your website and in your job posts. It lists every open role, and people apply from it. An admin makes it public once, in Canvas → Careers: sets who can open it to Public, approves the two lists it shows, and publishes it.'),
      el('button', { class: 'oc-btn oc-btn--sm', type: 'button', onClick: async () => {
        try { await navigator.clipboard.writeText(url); Orch.toast('Link copied.'); } catch { Orch.toast('Copy it from the line above.', { error: true }); }
      } }, 'Copy the link'),
    ]),
    el('form', { class: 'rc-form', onSubmit: (e) => { e.preventDefault(); saveCompany(); } }, [
      el('fieldset', { class: 'rc-fieldset' }, [
        el('legend', {}, 'On the careers page'),
        el('div', { class: 'rc-grid' }, [field('Company name', f.name), field('One line on what you do', f.tagline), field('Industry', f.industry), field('People', f.size), field('Logo URL', f.logo_url)]),
        field('About', about, 'A few sentences on the company and how you work.'),
        el('div', { class: 'rc-grid' }, [field('Website', f.website), field('LinkedIn', f.linkedin), field('Privacy policy', f.privacy_url, 'Linked next to the consent box on every application.')]),
      ]),
      el('div', { class: 'rc-actions' }, [el('button', { class: 'oc-btn oc-btn--primary', type: 'submit' }, 'Save')]),
    ]),
    el('section', { class: 'rc-card' }, [
      el('h2', { class: 'oc-h3' }, 'Screening'),
      el('p', {}, s.screening === 'on'
        ? 'On: the agent screens new applicants of open roles every ten minutes. It suggests; it never moves or writes to anyone.'
        : 'Off: nobody is screened on its own. Screen now on a role still works.'),
      el('p', { class: 'oc-small oc-muted' }, s.notify_telegram ? 'It tells a Telegram chat when it has screened someone.' : 'It tells nobody on Telegram.'),
      el('p', { class: 'oc-small oc-muted' }, 'Managed in Orchestra, with the agent that does the screening.'),
      el('div', { class: 'rc-actions' }, [manage]), where,
    ]),
  ]);
}
