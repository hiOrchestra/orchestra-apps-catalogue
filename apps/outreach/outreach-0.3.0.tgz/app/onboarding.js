// Getting started, the pure part (no Orch, so a test can import it): the two
// things a fresh install needs before an email can go out, each read from the
// data every time Campaigns draws, never ticked by hand.
//   resend  Resend answered through Composio (check-resend.js, or any email
//           that left), and its last check did not fail
//   sender  Settings name the address the emails come from
export const STEPS = [
  { id: 'resend', title: 'Connect Resend' },
  { id: 'sender', title: 'Your sender' },
];

export function onboarding(s, { left = 0 } = {}) {
  const done = {
    resend: Boolean(s && s.resend_ok_at && !s.resend_error) || (Number(left) > 0 && !(s && s.resend_error)),
    sender: Boolean(s && String(s.from_email || '').trim()),
  };
  const all = done.resend && done.sender;
  return { done, count: Number(done.resend) + Number(done.sender), show: Boolean(s) && !s.onboarding_hidden_at && !all };
}
