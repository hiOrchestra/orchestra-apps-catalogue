// What Outreach reads, the only things it writes, and the rules it shares with
// the automations. Tables give rows, views do the joins, every write is a
// declared action (A). Writing, sending, counting, importing and checking
// bounces run as workflows on the instance: this app starts them and shows
// their work. What an email looks like is mailcore.js, the same file the
// automations send with.
import './mailcore.js';

export const MC = self.OutreachMail;

export const T = {
  contacts: 'outreach_contacts', audiences: 'outreach_audiences', templates: 'outreach_templates',
  campaigns: 'outreach_campaigns', sends: 'outreach_sends', settings: 'outreach_settings',
  fields: 'outreach_fields', noContact: 'outreach_suppressions', imports: 'outreach_imports',
};
export const V = {
  campaigns: 'campaigns', goingOut: 'going_out', review: 'to_review', sent: 'sent',
  contacts: 'contacts', audiences: 'audiences', templates: 'templates', noContact: 'no_contact', lists: 'lists',
};
export const A = {
  setStage: 'set_stage', setTags: 'set_tags', block: 'block_contacts', unblock: 'unblock_contacts', unsubscribe: 'unsubscribe_contacts',
  lookUpAgain: 'look_up_again', addContact: 'add_contact', editContact: 'edit_contact',
  createAudience: 'create_audience', updateAudience: 'update_audience', archiveAudience: 'archive_audience',
  createTemplate: 'create_template', updateTemplate: 'update_template', archiveTemplate: 'archive_template',
  createCampaign: 'create_campaign', updateCampaign: 'update_campaign', setRecipients: 'set_recipients', countRecipients: 'count_recipients',
  testSend: 'test_send', startCampaign: 'start_campaign', resumeCampaign: 'resume_campaign', pauseCampaign: 'pause_campaign',
  finishCampaign: 'finish_campaign', sendBroadcast: 'send_broadcast', scheduleBroadcast: 'schedule_broadcast',
  unscheduleBroadcast: 'unschedule_broadcast', pauseBroadcast: 'pause_broadcast', resumeBroadcast: 'resume_broadcast',
  finishBroadcast: 'finish_broadcast', listFromCampaign: 'list_from_campaign',
  cancelSends: 'cancel_sends', approve: 'approve_drafts', discard: 'discard_drafts', editDraft: 'edit_draft',
  markReplied: 'mark_replied', retry: 'retry_failed', retryBroadcast: 'retry_broadcast', editFailed: 'edit_failed', markSent: 'mark_sent', drop: 'drop_failed',
  updateSettings: 'update_settings', pauseSending: 'pause_sending', resumeSending: 'resume_sending',
  addNoContact: 'add_no_contact', removeNoContact: 'remove_no_contact',
  addImportPart: 'add_import_part', runImport: 'run_import',
  queueNow: 'queue_now', sendNow: 'send_now', findEmailsNow: 'find_emails_now', checkBouncesNow: 'check_bounces_now', broadcastNow: 'send_broadcasts_now',
  checkResend: 'check_resend', hideStart: 'hide_onboarding',
};

/** Where Resend is connected: the portal's Integrations. The app is served from
 *  the instance, not the portal, so a relative link would 404; the portal is
 *  where the person came from (the referrer), else Orchestra's address. */
const PORTAL_ORIGIN = (() => {
  try {
    const o = document.referrer ? new URL(document.referrer).origin : '';
    if (/^https:\/\/([a-z0-9-]+\.)*(hiorchestra\.com|orchestra-portal[a-z0-9-]*\.up\.railway\.app)$/.test(o)) return o;
  } catch { /* no referrer */ }
  return 'https://hiorchestra.com';
})();
export const INTEGRATIONS = `${PORTAL_ORIGIN}/portal/integrations`;

const { el } = Orch;

const TONE = {
  Active: 'good', Sending: 'accent', Sent: 'good', Scheduled: 'accent', Paused: 'warn', Replied: 'good', Bounced: 'bad', Failed: 'bad',
  Queued: 'accent', Retry: 'accent', 'In review': 'warn', 'Has email': 'good', 'Not found': 'warn', Unsubscribed: 'warn', Complained: 'bad', Blocked: 'bad',
};
const SHOWN = { Complained: 'Marked as spam', Retry: 'Sending again' };
export const badge = (text) => el('span', { class: 'oc-badge' + (TONE[text] ? ` oc-badge--${TONE[text]}` : '') }, SHOWN[text] || text || '—');
export const modeLabel = (m) => (m === 'review' ? 'Review first' : 'Automatic');
export const kindLabel = (k) => (k === 'broadcast' ? 'Broadcast' : 'Sequence');
export const isBroadcast = (k) => k && k.kind === 'broadcast';
export const plural = (n, one, many) => `${Orch.fmt.number(n)} ${Number(n) === 1 ? one : many}`;

/** Run a declared action, say how it went, and hand back its result (null on failure). */
export async function act(name, params, done) {
  try {
    const r = await Orch.action(name, params);
    if (done) Orch.toast(done);
    // The side rail counts what is going out and waiting: tell it something moved.
    window.dispatchEvent(new CustomEvent('outreach:changed'));
    return r || {};
  } catch (e) {
    Orch.toast(e.status === 409 ? 'It changed meanwhile: look again.' : (e.message || 'That did not work.'), { error: true });
    return null;
  }
}

/** Ask twice for what cannot be undone: the button stays inert until the box that names the cost is ticked. */
export function confirmTwice({ title, text, ack, yes, danger = true }) {
  return new Promise((resolve) => {
    const box = el('input', { type: 'checkbox' });
    const go = el('button', { class: `oc-btn ${danger ? 'oc-btn--danger' : 'oc-btn--primary'}`, type: 'button', disabled: true }, yes);
    box.addEventListener('change', () => { go.disabled = !box.checked; });
    const cancel = el('button', { class: 'oc-btn oc-btn--ghost', type: 'button' }, 'Cancel');
    const dlg = Orch.dialog(el('div', { class: 'ox-form' }, [
      text ? el('p', {}, text) : null,
      el('label', { class: 'ox-choice' }, [box, ` ${ack}`]),
    ]), { title, foot: [cancel, go], onClose: (v) => resolve(v === 'yes') });
    cancel.addEventListener('click', () => dlg.close('no'));
    go.addEventListener('click', () => dlg.close('yes'));
  });
}

/** Who an email is to: the name, and the organisation only when it says something more. */
export function who(r) {
  const name = String(r.name || r.email || '').trim();
  const org = String(r.organization || '').trim();
  return org && org.toLowerCase() !== name.toLowerCase() ? `${name} · ${org}` : name;
}

/** Close the open panel and show the list again with its filters: it reloads. */
export function backToList() {
  // The drawer is the table's own: closing it runs the table's close, which
  // drops open= and reloads the list. Changing the route alone would leave it.
  const drawer = document.querySelector('[data-orch-detail]');
  if (drawer && typeof drawer.close === 'function' && drawer.open) { drawer.close(); return; }
  if (drawer) drawer.remove();
  const [p, q = ''] = Orch.router.path().split('?');
  const params = new URLSearchParams(q);
  params.delete('open');
  const rest = params.toString();
  Orch.router.go(rest ? `${p}?${rest}` : p);
}

// Why an email did not go out, in words a person can act on. The raw error
// (Resend's, or the send script's) is kept for whoever needs it.
const REASONS = [
  [/bounced/i, 'The address bounced', 'The address does not exist or refuses mail. Fix the address in Contacts; this email cannot be sent again.'],
  [/may or may not have gone out|stuck sending|did not finish/i, 'It may have gone out', 'The send stopped halfway, so it may have left. Look for it in your Sent folder or in Resend: if it is there, mark it as sent; if not, send it again.'],
  [/unsubscribed/i, 'They unsubscribed', 'They unsubscribed before it left, so it was not sent.'],
  [/sender|domain|not verified/i, 'The sender was refused', 'Resend refused the sender address. Check the campaign\'s sender or Settings, then send it again.'],
  [/not valid|invalid/i, 'The address is not valid', 'Fix the address, then send it again.'],
  [/resend|prepare|unavailable|no result|time(d)? ?out|network/i, 'Resend could not take it', 'Resend did not accept the email at that moment, so nothing went out. Send it again.'],
];
export function failure(row) {
  const raw = String(row.error || '').trim();
  for (const [re, short, long] of REASONS) if (re.test(raw)) return { short, long, raw };
  return { short: raw || 'It did not go out', long: raw ? 'It did not go out. Open the details below, fix what it says, then send it again or drop it.' : 'It did not go out.', raw };
}

// ── settings ─────────────────────────────────────────────────────────────
export async function settings() {
  const r = await Orch.db.list(T.settings, { limit: 1, sort: '_id:asc' });
  return (r.rows || [])[0] || null;
}
export function list(text) {
  try { const v = JSON.parse(text || '[]'); return Array.isArray(v) ? v.map(String) : []; } catch { return []; }
}
export async function fields() {
  return (await Orch.db.list(T.fields, { sort: 'position:asc', limit: 50 })).rows || [];
}
/** The sender a campaign uses: its own, else Settings. */
export function senderOf(k, s) {
  const email = String((k && k.from_email) || (s && s.from_email) || '').trim();
  const name = String((k && k.from_email ? k.from_name : '') || (k && k.from_name) || (s && s.from_name) || '').trim();
  const reply = String((k && k.reply_to) || (s && s.reply_to) || '').trim();
  return { email, name, reply, own: !!(k && k.from_email), text: email ? (name ? `${name} <${email}>` : email) : '' };
}

/** How many sequence emails left today (the daily cap counts sequences only). */
export async function sequenceSentToday(sinceSql) {
  const r = await Orch.db.view(V.sent, { filter: { kind: 'sequence', status: ['Sent', 'Replied', 'Bounced'], sent_at: { gte: sinceSql } }, count: true, limit: 1 });
  return r.total || 0;
}

// ── templates and emails: the same rendering as the automations ──────────
export const variables = (text) => MC.variables(text);
export const render = (text, contact) => MC.render(text, contact);
/** The email as a contact would get it, with a stand-in unsubscribe link. */
export function preview(k, s, contact) {
  const base = String((s && s.unsubscribe_url) || '').split('#')[0] || 'https://example.com/unsubscribe';
  const link = Number(k.unsubscribe_link) === 1 ? `${base}#t=preview` : null;
  return MC.compose({ format: k.format, subject: k.subject, body: k.body, contact: contact || {}, settings: s || {}, unsubUrl: link, brand: senderOf(k, s).name });
}
/**
 * An iframe that shows an email's HTML without letting it run anything: no
 * allow-scripts, so its own origin is harmless (and lets it paint everywhere).
 */
export function htmlFrame(html, title) {
  const frame = el('iframe', { class: 'ox-frame', title: title || 'The email', sandbox: 'allow-same-origin', referrerpolicy: 'no-referrer' });
  frame.srcdoc = html;
  return frame;
}

// ── audiences: the data API's own filter, edited as rules ────────────────
export const OPS = [
  { op: 'is', label: 'is' }, { op: 'any', label: 'is one of' }, { op: 'not', label: 'is not' },
  { op: 'has', label: 'contains' }, { op: 'set', label: 'is filled in' }, { op: 'unset', label: 'is empty' },
  { op: 'tag', label: 'is in the list' },
];

// ── lists: kept as "|Newsletter|Customers|", so a list matches whole ──────
// ("Customers" never matches "Former customers"). The lists on offer are the
// registry in Settings (the column is still called tags).
export const tagsOf = (text) => String(text || '').split('|').map((t) => t.trim()).filter(Boolean);
export const tagsText = (tags) => {
  const clean = [...new Set(tags.map((t) => String(t).replace(/\|/g, '/').trim()).filter(Boolean))];
  return clean.length ? `|${clean.join('|')}|` : '';
};
export const tagFilter = (tag) => ({ like: `|${tag}|` });
export function rulesOf(filterText) {
  let f = {};
  try { f = JSON.parse(filterText || '{}') || {}; } catch { f = {}; }
  const rules = [];
  for (const [field, v] of Object.entries(f)) {
    if (Array.isArray(v)) rules.push({ field, op: 'any', value: v.join(', ') });
    else if (v && typeof v === 'object') {
      for (const [op, val] of Object.entries(v)) {
        const text = String(val ?? '');
        if (op === 'like' && /^\|.+\|$/.test(text)) { rules.push({ field, op: 'tag', value: text.slice(1, -1) }); continue; }
        rules.push({ field, op: { like: 'has', ne: 'not', notnull: 'set', isnull: 'unset' }[op] || 'is', value: text });
      }
    } else rules.push({ field, op: 'is', value: String(v) });
  }
  return rules;
}
export function filterOf(rules) {
  const f = {};
  for (const r of rules) {
    if (!r.field) continue;
    const value = String(r.value || '').trim();
    if (r.op === 'set') f[r.field] = { notnull: '1' };
    else if (r.op === 'unset') f[r.field] = { isnull: '1' };
    else if (!value) continue;
    else if (r.op === 'any') f[r.field] = value.split(',').map((x) => x.trim()).filter(Boolean);
    else if (r.op === 'has') f[r.field] = { like: value };
    else if (r.op === 'tag') f[r.field] = tagFilter(value);
    else if (r.op === 'not') f[r.field] = { ne: value };
    else f[r.field] = value;
  }
  return f;
}

// ── a workflow's answer, written to a row ────────────────────────────────
/**
 * Actions that start a workflow return at once; the workflow writes its
 * result to a row. Wait for `read()` to give something new (up to `seconds`).
 */
export async function waitFor(read, isNew, seconds = 30) {
  const until = Date.now() + seconds * 1000;
  while (Date.now() < until) {
    await new Promise((r) => setTimeout(r, 1200));
    try {
      const v = await read();
      if (isNew(v)) return v;
    } catch { /* try again */ }
  }
  return null;
}

// ── CSV ──────────────────────────────────────────────────────────────────
/** Rows of a view or table as a CSV file, paged 500 at a time from the server. */
export async function downloadCsv({ view, table, filter, columns, name }) {
  const rows = [];
  for (let offset = 0; offset < 100000; offset += 500) {
    const res = view ? await Orch.db.view(view, { filter, limit: 500, offset, sort: '_id:asc' })
      : await Orch.db.list(table, { filter, limit: 500, offset, sort: '_id:asc' });
    rows.push(...(res.rows || []));
    if (!res.hasMore) break;
  }
  const cols = columns || (rows[0] ? Object.keys(rows[0]).filter((c) => !c.startsWith('_')) : []);
  const cell = (v) => {
    if (v === null || v === undefined) return '';
    const t = String(v);
    const safe = /^[=+\-@]/.test(t) ? `'${t}` : t;
    return /[",\n\r]/.test(safe) ? `"${safe.replace(/"/g, '""')}"` : safe;
  };
  const csv = `﻿${[cols.map(cell).join(','), ...rows.map((r) => cols.map((c) => cell(r[c])).join(','))].join('\r\n')}`;
  const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' }));
  const a = el('a', { href: url, download: `${name || 'outreach'}.csv` });
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 5000);
  return rows.length;
}
