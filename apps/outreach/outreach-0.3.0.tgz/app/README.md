# Outreach

Email campaigns for one sender, a small Sendy: contacts with a status and their
own fields, lists, audiences (conditions on contacts), templates, and
campaigns of two kinds, sent through Resend.

- **Broadcast**: one email to lists and audiences, sent once, now or at a set
  time, in batches of 100.
- **Sequence**: writes to each new contact of its recipients, one email at a
  time at a set pace, optionally reviewed first.

An agent looks up the email of contacts that have none. What changes between
companies (stages, contact fields, lists, templates, the sender) is data in
Settings, not code.

## Brief
Whoever sends the company's newsletters, announcements and outreach, a few
times a week: keeps lists, sends a newsletter or an announcement to them, runs
outreach to hand-picked people, and sees what went out and what came of it.
Questions it answers:
- Who gets this, and who is left out and why?
- What went out, and who opened, replied, unsubscribed or bounced?
- What is going out next?

Main action: write an email, pick its lists and audiences, send yourself a
test, then send or schedule it (or start a sequence).

## Screens
- `/` Campaigns (`screens/campaigns.js`): both kinds, with status, progress
  and results; what needs attention; New campaign asks the kind, the name and
  where the email starts. On a fresh install, Getting started on top
  (`screens/start.js`, its rules in `onboarding.js`): connect Resend (Check the
  connection asks Resend for one email, nothing is sent) and set the sender in
  Settings. It ticks itself and goes when both are done; Hide keeps it away.
- `/campaigns/:id/email` (`screens/compose.js`), step 1 of a draft: name,
  sender, subject, format, text with variables, the unsubscribe link, and a
  live preview for a real contact.
- `/campaigns/:id/recipients` (`screens/send-to.js`), step 2 of a draft:
  lists and audiences in and out, the exact count with why the rest are left
  out, a test send, the checks, and Send now / Schedule (or Start).
- `/campaigns/:id` (`screens/campaign.js`): the controls its state allows
  (pause, resume, finish, cancel a schedule, duplicate), progress and the
  report.
- `/campaigns/:id/<who>`: the people behind one number of the report, with
  "Add these to a list" and "Export CSV".
- `/review`, `/queue`, `/sent` (`screens/review.js`, `queue.js`, `sent.js`):
  the emails across campaigns. A failed one is fixed from its own panel.
- `/contacts` (`screens/contacts.js`, `contact-form.js`): status tabs,
  filters, lists, stages, unsubscribe, block, allow again, export.
- `/contacts/import` (`screens/import.js`): file → columns → list → result,
  with the skipped lines.
- `/lists` (`screens/lists.js`): each list's health.
- `/audiences`, `/templates` (`screens/audiences.js`, `templates.js`).
- `/settings` (`screens/settings.js`, `no-contact.js`): sender, footer and
  unsubscribe page, broadcast limit, sequence pace, email lookup, stages,
  no-contact list, automations.

## Data
Tables:
- `outreach_contacts` (`status`, lists in `tags`)
- `outreach_audiences` (a `filter` in the data API's own filter language)
- `outreach_templates`
- `outreach_campaigns` (`kind`, its own `subject` / `body` / `format` /
  sender, `recipients` JSON, `estimate`, `test_result`)
- `outreach_sends` (one row per email; a broadcast's rows have no body)
- `outreach_settings` (one row)
- `outreach_fields` (custom contact fields)
- `outreach_suppressions` (the no-contact list)
- `outreach_imports` (an uploaded CSV, in parts)

Views: `campaigns`, `going_out`, `to_review`, `sent`, `contacts`, `lists`,
`audiences`, `templates`, `no_contact`. Every write is a declared action (see
`orch-canvas action list outreach`).

`mailcore.js` is the automations' own rendering (a copy: keep it identical).

## Known limits
- Replies are marked by hand: nothing reads the inbox yet.
- Sequences have one step: no follow-ups yet.
- No one-click unsubscribe (RFC 8058) and no Resend webhooks: both need a
  public endpoint that takes a raw POST. Deliveries, opens and clicks are read
  from Resend 1, 24 and 72 hours after a broadcast starts.
- An audience holds one condition per field.
