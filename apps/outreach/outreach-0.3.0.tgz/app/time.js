// Time in the sending time zone: when the next emails leave, and dates said
// the way a person reads them. The same window rules as automations/lib.js,
// which is what actually sends — keep the two in step.
export function toDate(v) {
  if (!v) return null;
  const s = String(v).trim();
  const iso = (s.includes('T') ? s : s.replace(' ', 'T')).replace(/([+-]\d\d)$/, '$1:00');
  const d = new Date(/[zZ]|[+-]\d\d:?\d\d$/.test(iso) ? iso : iso + 'Z');
  return Number.isNaN(d.getTime()) ? null : d;
}
const WD = { Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6, Sun: 7 };
function partsIn(date, tz) {
  const p = {};
  const f = new Intl.DateTimeFormat('en-GB', { timeZone: tz, hourCycle: 'h23', weekday: 'short', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit' });
  for (const x of f.formatToParts(date)) p[x.type] = x.value;
  return { y: +p.year, m: +p.month, d: +p.day, hh: +p.hour, mm: +p.minute, wd: WD[p.weekday] };
}
function instantIn(tz, y, m, d, hh, mm) {
  const want = Date.UTC(y, m - 1, d, hh, mm);
  let guess = want;
  for (let i = 0; i < 3; i += 1) {
    const p = partsIn(new Date(guess), tz);
    const seen = Date.UTC(p.y, p.m - 1, p.d, p.hh, p.mm);
    if (seen === want) break;
    guess += want - seen;
  }
  return new Date(guess);
}
const minutes = (t) => { const [h, m] = String(t || '').split(':').map(Number); return (h || 0) * 60 + (m || 0); };
export function schedule(s) {
  let tz = (s && s.timezone) || 'UTC';
  try { new Intl.DateTimeFormat('en-GB', { timeZone: tz }); } catch { tz = 'UTC'; }
  const days = String((s && s.send_days) || '1,2,3,4,5').split(',').map(Number).filter((n) => n >= 1 && n <= 7);
  return {
    tz, start: minutes(s && s.window_start || '09:00'), end: minutes(s && s.window_end || '18:00'),
    days: days.length ? days : [1, 2, 3, 4, 5],
    every: Math.max(5, Number(s && s.send_every_minutes) || 30), cap: Math.max(1, Number(s && s.daily_cap) || 20),
  };
}
const inWindow = (date, sch) => { const p = partsIn(date, sch.tz); const t = p.hh * 60 + p.mm; return sch.days.includes(p.wd) && t >= sch.start && t < sch.end; };
function nextOpen(date, sch) {
  if (inWindow(date, sch)) return date;
  if (sch.end <= sch.start) return null;
  const p = partsIn(date, sch.tz);
  for (let i = 0; i < 9; i += 1) {
    const c = new Date(Date.UTC(p.y, p.m - 1, p.d + i));
    const open = instantIn(sch.tz, c.getUTCFullYear(), c.getUTCMonth() + 1, c.getUTCDate(), Math.floor(sch.start / 60), sch.start % 60);
    if (open > date && sch.days.includes(partsIn(open, sch.tz).wd)) return open;
  }
  return null;
}
const dayKey = (date, tz) => { const p = partsIn(date, tz); return `${p.y}-${p.m}-${p.d}`; };
export function dayStart(date, tz) { const p = partsIn(date, tz); return instantIn(tz, p.y, p.m, p.d, 0, 0); }
/** 'YYYY-MM-DD HH:MM:SS' in UTC, the stored format, for filters. */
export const sqlTime = (d) => d.toISOString().slice(0, 19).replace('T', ' ');

/**
 * When the next `count` emails leave: one per "every" minutes inside the
 * window, at most the daily cap per day, from next_send_at. The send workflow
 * checks every ten minutes, so each time is rounded up to the next ten.
 */
export function leaveTimes(count, s, sentToday = 0, now = new Date()) {
  if (!s || Number(s.paused) === 1) return [];
  const sch = schedule(s);
  const out = [];
  let t = toDate(s.next_send_at);
  if (!t || t < now) t = now;
  let day = null;
  let used = 0;
  for (let i = 0; i < count; i += 1) {
    let open = nextOpen(t, sch);
    if (!open) break;
    if (dayKey(open, sch.tz) !== day) { used = day === null ? sentToday : 0; day = dayKey(open, sch.tz); }
    if (used >= sch.cap) {
      const p = partsIn(open, sch.tz);
      const c = new Date(Date.UTC(p.y, p.m - 1, p.d + 1));
      open = nextOpen(instantIn(sch.tz, c.getUTCFullYear(), c.getUTCMonth() + 1, c.getUTCDate(), 0, 0), sch);
      if (!open) break;
      day = dayKey(open, sch.tz);
      used = 0;
    }
    out.push(new Date(Math.ceil(open.getTime() / 600000) * 600000));
    used += 1;
    t = new Date(open.getTime() + sch.every * 60000);
  }
  return out;
}

/** 'today 16:30', 'tomorrow 09:00', 'Mon 29 Sep 09:00' — in the sending time zone. */
export function clock(date, tz) {
  if (!date) return '—';
  const zone = tz || 'UTC';
  const hm = new Intl.DateTimeFormat('en-GB', { timeZone: zone, hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }).format(date);
  const days = Math.round((dayStart(date, zone) - dayStart(new Date(), zone)) / 86400000);
  if (days === 0) return `today ${hm}`;
  if (days === 1) return `tomorrow ${hm}`;
  return `${new Intl.DateTimeFormat('en-GB', { timeZone: zone, weekday: 'short', day: 'numeric', month: 'short' }).format(date)} ${hm}`;
}
export function ago(v) {
  const d = toDate(v);
  if (!d) return '—';
  const mins = Math.round((Date.now() - d) / 60000);
  if (mins < 60) return mins <= 1 ? 'just now' : `${mins} min ago`;
  // Days and hours on the viewer's own clock: "today 09:30" is their 09:30.
  const midnight = (x) => new Date(x.getFullYear(), x.getMonth(), x.getDate()).getTime();
  const days = Math.round((midnight(new Date()) - midnight(d)) / 86400000);
  const hhmm = d.toLocaleTimeString('en-GB', { hour: '2-digit', minute: '2-digit' });
  if (days <= 0) return `today ${hhmm}`;
  if (days === 1) return `yesterday ${hhmm}`;
  return days < 30 ? `${days} days ago` : d.toLocaleDateString('en-GB', { day: 'numeric', month: 'short', year: 'numeric' });
}
export const pct = (part, whole) => (whole ? `${Math.round((100 * part) / whole)}%` : '—');
/** A stored time on the viewer's own clock: 'today 16:30', 'tomorrow 09:00', 'Mon 29 Sep 09:00'. */
export const localClock = (v) => clock(toDate(v), Intl.DateTimeFormat().resolvedOptions().timeZone);
/** The instant a wall clock (YYYY-MM-DD, HH:MM) in `tz` names, or null. */
export function zonedInstant(date, time, tz) {
  const [y, m, d] = String(date || '').split('-').map(Number);
  const [hh, mm] = String(time || '').split(':').map(Number);
  if (!y || !m || !d || !Number.isFinite(hh)) return null;
  let zone = tz || 'UTC';
  try { new Intl.DateTimeFormat('en-GB', { timeZone: zone }); } catch { zone = 'UTC'; }
  return instantIn(zone, y, m, d, hh, mm || 0);
}
