// Step 1 of a draft: the email. Name, sender (Settings' unless the campaign
// has its own), subject, format, text with variables, the unsubscribe link,
// and a preview for a real contact, drawn by the same mailcore that sends.
// Nothing is sent from here; "Continue" saves and goes to the recipients.
import { V, T, A, MC, act, fields, preview, htmlFrame, senderOf, variables } from '../data.js';

const { el, router } = Orch;

const FORMAT_HELP = {
  text: 'Plain text, as you write it. Reads like a personal email: best for outreach to people you picked.',
  simple: 'Your text in a light, one-column layout, with links and the footer; a plain-text copy goes along.',
  html: 'Your own HTML, as it is. Values are escaped into it; the footer is added before </body> unless it has {{unsubscribe_url}}.',
};

export async function compose(host, k, s, tabs) {
  const fs = await fields();
  const cols = ['name', 'email', 'organization', 'website', 'stage', 'country', 'title', 'city', ...fs.map((f) => f.key)];
  const known = [...new Set([...cols, 'first_name', 'last_name', 'unsubscribe_url'])];
  const people = (await Orch.db.list(T.contacts, { filter: { email: { notnull: '1' }, status: 'Active' }, sort: 'name:asc', limit: 30 })).rows || [];
  const sender = senderOf({}, s);

  const input = (name, value, attrs = {}) => el('input', { class: 'oc-input', name, value: value == null ? '' : String(value), ...attrs });
  const field = (label, control, help) => el('label', { class: 'oc-field' }, [el('span', { class: 'oc-label' }, label), control, help ? el('span', { class: 'oc-help' }, help) : null]);

  const name = input('name', k.name, { required: true, maxlength: '120' });
  const subject = input('subject', k.subject, { required: true, maxlength: '300' });
  const body = el('textarea', { class: 'oc-textarea', name: 'body', rows: '18', spellcheck: 'true' });
  body.value = k.body || '';
  const own = el('input', { type: 'checkbox', checked: k.from_email ? true : null });
  const fromName = input('from_name', k.from_name || sender.name, { maxlength: '120' });
  const fromEmail = input('from_email', k.from_email || sender.email, { type: 'email' });
  const replyTo = input('reply_to', k.reply_to || '', { type: 'email', placeholder: sender.reply || 'The same address' });
  const ownBox = el('div', { class: 'ox-grid2', hidden: !k.from_email }, [field('Name', fromName), field('Address', fromEmail), field('Replies go to', replyTo)]);
  own.addEventListener('change', () => { ownBox.hidden = !own.checked; changed(); });
  const formatOf = () => (host.querySelector('input[name="format"]:checked') || {}).value || 'text';
  const formats = el('div', { class: 'ox-segment', role: 'radiogroup', 'aria-label': 'Format' }, MC.FORMATS.map((f) => el('label', { class: 'ox-segment__item' }, [
    el('input', { type: 'radio', name: 'format', value: f, checked: (k.format || 'text') === f ? true : null }), el('span', MC.FORMAT_LABEL[f]),
  ])));
  const formatHelp = el('p', { class: 'oc-help' });
  const unsub = el('input', { type: 'checkbox', checked: Number(k.unsubscribe_link) === 1 ? true : null });
  const unsubNote = el('p', { class: 'oc-help' });

  // Variables, inserted where the cursor is (subject or text).
  let focused = body;
  subject.addEventListener('focus', () => { focused = subject; });
  body.addEventListener('focus', () => { focused = body; });
  const insert = (v) => {
    const f = focused;
    const at = f.selectionStart ?? f.value.length;
    f.value = `${f.value.slice(0, at)}{{${v}}}${f.value.slice(f.selectionEnd ?? at)}`;
    f.focus();
    f.selectionStart = f.selectionEnd = at + v.length + 4;
    changed();
  };

  // ── the preview ────────────────────────────────────────────────────────
  const whoSel = el('select', { class: 'oc-select', 'aria-label': 'Preview it for' },
    [el('option', { value: '' }, 'Nobody in particular (fallbacks)'), ...people.map((c, i) => el('option', { value: String(i) }, `${c.name || c.email}${c.organization ? ` · ${c.organization}` : ''}`))]);
  if (people.length) whoSel.value = '0';
  let view = 'email';
  const viewBtns = el('div', { class: 'ox-segment ox-segment--sm', role: 'radiogroup', 'aria-label': 'Show' }, [['email', 'Email'], ['text', 'Plain text']].map(([v, l]) => {
    const i = el('input', { type: 'radio', name: 'pv', value: v, checked: v === 'email' ? true : null });
    i.addEventListener('change', () => { view = v; draw(); });
    return el('label', { class: 'ox-segment__item' }, [i, el('span', l)]);
  }));
  const pv = el('div', { class: 'ox-preview__body' });
  const draft = () => ({
    ...k, subject: subject.value, body: body.value, format: formatOf(), unsubscribe_link: unsub.checked ? 1 : 0,
    from_name: own.checked ? fromName.value : '', from_email: own.checked ? fromEmail.value : '', reply_to: own.checked ? replyTo.value : '',
  });
  const draw = () => {
    const d = draft();
    formatHelp.textContent = FORMAT_HELP[d.format];
    unsubNote.textContent = d.unsubscribe_link ? 'A link at the bottom that unsubscribes them from every campaign, and the List-Unsubscribe header mail apps show.'
      : (k.kind === 'broadcast' ? 'Without it, people who want out can only reply or mark it as spam, which hurts every later email. Keep it for a broadcast.' : 'A one-to-one email usually goes without it; replies are the way out.');
    unsubNote.className = !d.unsubscribe_link && k.kind === 'broadcast' ? 'ox-note ox-note--warn' : 'oc-help';
    viewBtns.hidden = d.format === 'text';
    const c = whoSel.value === '' ? {} : people[Number(whoSel.value)];
    const unknown = [...new Set([...variables(d.subject), ...variables(d.body)])].filter((v) => !known.includes(v));
    const e = preview(d, s, c);
    const from = senderOf(d, s);
    Orch.mount(pv, [
      unknown.length ? el('p', { class: 'ox-note ox-note--bad' }, `${unknown.map((v) => `{{${v}}}`).join(', ')}: not a contact field. Nothing is sent until it is fixed.`) : null,
      c && c.email && e.missing.length ? el('p', { class: 'ox-note ox-note--warn' }, `${c.name || 'This contact'} has no ${e.missing.join(', ')}: they would be left out. Add a fallback, like {{${e.missing[0]}|…}}.`) : null,
      el('dl', { class: 'oc-dl ox-dl--tight' }, [
        ['From', from.text || 'No sender: set it here or in Settings'], ['To', c && c.email ? c.email : '—'], ['Subject', e.subject || '(no subject)'],
      ].map(([a, b]) => el('div', { class: 'oc-dl__row' }, [el('dt', a), el('dd', b)]))),
      e.html && view === 'email' ? htmlFrame(e.html, 'Preview') : el('pre', { class: 'ox-mail' }, e.text || ' '),
    ]);
  };

  // ── saving ─────────────────────────────────────────────────────────────
  let dirty = false;
  const state = el('span', { class: 'oc-small oc-muted' });
  let timer = null;
  function changed() {
    dirty = true;
    state.textContent = 'Not saved yet';
    clearTimeout(timer);
    timer = setTimeout(draw, 200);
  }
  [name, subject, body, fromName, fromEmail, replyTo, unsub].forEach((x) => x.addEventListener('input', changed));
  unsub.addEventListener('change', changed);
  formats.addEventListener('change', changed);
  whoSel.addEventListener('change', draw);

  async function save(quiet) {
    if (!name.value.trim()) { Orch.toast('Give it a name.', { error: true }); return false; }
    if (own.checked && !MC.EMAIL.test(fromEmail.value.trim())) { Orch.toast('The sender address is not valid.', { error: true }); return false; }
    const d = draft();
    const ok = await act(A.updateCampaign, {
      id: k._id, name: name.value.trim(), subject: d.subject.trim(), body: d.body, format: d.format, unsubscribe_link: d.unsubscribe_link,
      from_name: own.checked ? fromName.value.trim() : '', from_email: own.checked ? fromEmail.value.trim().toLowerCase() : '',
      reply_to: own.checked ? replyTo.value.trim().toLowerCase() : '',
    }, quiet ? null : 'Saved.');
    if (ok) { dirty = false; state.textContent = 'Saved'; Object.assign(k, d, { name: name.value.trim() }); }
    return !!ok;
  }
  // The step tabs save first: nothing written here is lost by moving on.
  if (tabs) {
    tabs.querySelectorAll('a[data-step="recipients"]').forEach((a) => a.addEventListener('click', async (ev) => {
      if (!dirty) return;
      ev.preventDefault();
      if (await save(true)) router.go(`/campaigns/${k._id}/recipients`);
    }));
  }

  const fromLine = el('p', { class: 'oc-small oc-muted' }, sender.text ? `From ${sender.text}${sender.reply ? `, replies to ${sender.reply}` : ''} (Settings)` : 'Settings have no sender yet.');
  Orch.mount(host, el('div', { class: 'ox-compose' }, [
    el('div', { class: 'ox-form' }, [
      field('Name (only you see it)', name),
      el('div', { class: 'oc-field' }, [
        el('span', { class: 'oc-label' }, 'From'), fromLine,
        el('label', { class: 'ox-choice' }, [own, ' A different sender for this campaign']), ownBox,
      ]),
      field('Subject', subject),
      el('div', { class: 'oc-field' }, [el('span', { class: 'oc-label' }, 'Format'), formats, formatHelp]),
      field(k.format === 'html' ? 'HTML' : 'Text', body),
      el('div', { class: 'oc-stack oc-stack--tight' }, [
        el('span', { class: 'oc-label' }, 'Variables: click to insert. After a bar, what to write when a contact has none: {{first_name|there}}'),
        el('div', { class: 'ox-vars' }, known.map((v) => el('button', { class: 'oc-btn oc-btn--sm ox-var', type: 'button', onClick: () => insert(v) }, `{{${v}}}`))),
      ]),
      el('div', { class: 'oc-field' }, [el('label', { class: 'ox-choice' }, [unsub, ' An unsubscribe link at the bottom']), unsubNote]),
      el('div', { class: 'ox-actions' }, [
        el('button', { class: 'oc-btn oc-btn--primary', type: 'button', onClick: async () => {
          if (await save(true)) router.go(`/campaigns/${k._id}/recipients`);
        } }, 'Save and continue'),
        el('button', { class: 'oc-btn', type: 'button', onClick: () => save(false) }, 'Save'),
        el('button', { class: 'oc-btn oc-btn--ghost', type: 'button', onClick: () => fromTemplate(k, subject, body, host, changed) }, 'Start from a template…'),
        el('button', { class: 'oc-btn oc-btn--ghost', type: 'button', onClick: () => asTemplate(draft(), name.value) }, 'Save as a template…'),
        state,
      ]),
    ]),
    el('aside', { class: 'ox-preview', 'aria-label': 'Preview' }, [
      el('div', { class: 'ox-inline ox-inline--between' }, [el('h2', { class: 'oc-h3' }, 'Preview'), viewBtns]),
      el('label', { class: 'oc-field' }, [el('span', { class: 'oc-label' }, 'For'), whoSel]),
      pv,
    ]),
  ]));
  draw();
}

/** Replace the subject and text with a template's (asks first when there is text). */
async function fromTemplate(k, subject, body, host, changed) {
  const tpl = await Orch.db.view(V.templates, { sort: 'name:asc', limit: 200 });
  if (!(tpl.rows || []).length) { Orch.toast('There is no template yet: write one in Templates.', { error: true }); return; }
  const sel = el('select', { class: 'oc-select', name: 'template' }, tpl.rows.map((t) => el('option', { value: String(t._id) }, t.name)));
  const form = el('form', { class: 'ox-form' }, [
    el('label', { class: 'oc-field' }, [el('span', { class: 'oc-label' }, 'Template'), sel]),
    el('p', { class: 'oc-help' }, 'Its subject, text and format replace what is written here. The template itself does not change later emails: the campaign keeps its own copy.'),
    el('div', { class: 'ox-actions' }, [el('button', { class: 'oc-btn oc-btn--primary', type: 'submit' }, 'Use it')]),
  ]);
  const dlg = Orch.dialog(form, { title: 'Start from a template' });
  Orch.onSubmit(form, async (d) => {
    const t = await Orch.db.get(T.templates, Number(d.template));
    if (!t) return;
    if ((subject.value.trim() || body.value.trim()) && !(await Orch.confirm('Replace the subject and text written here?', { yes: 'Replace' }))) return;
    subject.value = t.subject || '';
    body.value = t.body || '';
    const radio = host.querySelector(`input[name="format"][value="${t.format || 'text'}"]`);
    if (radio) radio.checked = true;
    dlg.close();
    changed();
  });
}

async function asTemplate(d, fallbackName) {
  const nameIn = el('input', { class: 'oc-input', name: 'name', required: true, maxlength: '120', value: fallbackName || '' });
  const form = el('form', { class: 'ox-form' }, [
    el('label', { class: 'oc-field' }, [el('span', { class: 'oc-label' }, 'Template name'), nameIn]),
    el('div', { class: 'ox-actions' }, [el('button', { class: 'oc-btn oc-btn--primary', type: 'submit' }, 'Save the template')]),
  ]);
  const dlg = Orch.dialog(form, { title: 'Save as a template' });
  Orch.onSubmit(form, async (v) => {
    if (await act(A.createTemplate, { name: v.name.trim(), subject: d.subject, body: d.body, format: d.format }, 'Template saved.')) dlg.close();
  });
}
