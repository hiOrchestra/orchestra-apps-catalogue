// The no-contact list, a section of Settings: addresses and whole domains
// that no campaign ever writes to. Bounces and spam complaints land here on
// their own (the Bounces automation); a person adds the rest.
import { V, A, act } from '../data.js';

const { el } = Orch;
const field = (label, control) => el('label', { class: 'oc-field' }, [el('span', { class: 'oc-label' }, label), control]);
const input = (name, attrs = {}) => el('input', { class: 'oc-input', name, value: '', ...attrs });

export function noContactList(host, path) {
  const table = el('div');
  Orch.mount(host, el('section', { class: 'ox-section' }, [
    el('h2', { class: 'oc-h2' }, 'No contact'),
    el('p', { class: 'oc-help' }, 'Addresses and whole domains (write @example.com) that never get an email from any campaign. Bounces and spam complaints are added on their own.'),
    addForm(),
    table,
  ]));
  Orch.table({
    into: table, view: V.noContact, path: '/settings', query: path, sort: 'added_at:desc', pageSize: 25,
    empty: 'Nobody is on the list.',
    columns: [{ key: 'email', label: 'Address or domain' }, { key: 'reason', label: 'Why' }, { key: 'note', label: 'Note', clamp: true },
      { key: 'added_at', label: 'Added', format: 'date' }],
    bulk: [{ label: 'Take off the list', action: A.removeNoContact, confirm: 'Take {n} off the no-contact list? Campaigns can write to them again.', done: '{n} taken off' }],
  });
}

function addForm() {
  const form = el('form', { class: 'ox-inline' }, [
    field('Address or @domain', input('email', { required: true, placeholder: 'name@example.com', maxlength: '254' })),
    field('Why', el('select', { class: 'oc-select', name: 'reason' }, ['Asked not to be contacted', 'Manual'].map((r) => el('option', { value: r }, r)))),
    field('Note', input('note', { maxlength: '200' })),
    el('button', { class: 'oc-btn', type: 'submit' }, 'Add to the list'),
  ]);
  Orch.onSubmit(form, async (d) => {
    const email = d.email.trim().toLowerCase();
    if (!/^(@[^\s@]+\.[^\s@]+|[^\s@]+@[^\s@]+\.[^\s@]+)$/.test(email)) { Orch.toast('Write an address, or a domain starting with @.', { error: true }); return; }
    if (await act(A.addNoContact, { email, reason: d.reason, note: d.note.trim() }, `${email} is on the list.`)) Orch.router.go('/settings');
  });
  return form;
}
