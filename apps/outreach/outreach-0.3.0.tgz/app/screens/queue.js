// Going out: every email that is written and waiting to leave, in the order
// it leaves, with when. One leaves every "every" minutes inside the sending
// window (Settings). A row opens the email exactly as it will go out; ticked
// rows can be held back. An email of a paused campaign keeps its place and
// says so. "Send the next one now" skips the wait, never the window or cap.
import { V, T, A, settings, act, who, sequenceSentToday } from '../data.js';
import { showMail } from './sent.js';
import { leaveTimes, clock, dayStart, sqlTime, schedule, ago } from '../time.js';

const { el, fmt } = Orch;

export async function render(_params, path) {
  const table = el('div');
  const line = el('p', { class: 'oc-help' });
  const next = el('button', { class: 'oc-btn', type: 'button', onClick: sendNext }, 'Send the next one now');
  Orch.mount('view', el('div', { class: 'ox-page' }, [
    el('header', { class: 'ox-head' }, [
      el('div', { class: 'ox-head__text' }, [
        el('h1', { class: 'oc-h1 oc-h1--collection' }, 'Going out'),
        el('p', { class: 'oc-lede' }, 'The sequences\' emails, written and waiting to leave, in the order they leave. Open one to read it as it will be sent. (A broadcast shows its progress on its own page.)'),
      ]),
      next,
    ]),
    line,
    table,
  ]));

  const [s, campaigns, waiting] = await Promise.all([settings(), Orch.db.view(V.campaigns, { sort: 'name:asc', limit: 200 }),
    Orch.db.view(V.goingOut, { count: true, limit: 1 })]);
  if (!waiting.total) { next.disabled = true; next.title = 'Nothing is waiting to go out'; }
  const sch = schedule(s || {});
  const sentToday = s ? await sequenceSentToday(sqlTime(dayStart(new Date(), sch.tz))) : 0;
  const times = leaveTimes(500, s, sentToday);
  line.textContent = !s ? 'Outreach has no settings yet.'
    : Number(s.paused) === 1 ? 'Sending is paused in Settings: nothing leaves until it is resumed.'
      : `One every ${sch.every} minutes, ${String(s.window_start)}–${String(s.window_end)} (${sch.tz}), at most ${sch.cap} a day. ${fmt.number(sentToday)} sent today.`;

  Orch.pattern('queue', {
    into: table, path: '/queue', query: path, view: V.goingOut, sort: 'position:asc', pageSize: 50,
    empty: 'Nothing is waiting to go out. An active campaign writes the email of each new contact in its audience.',
    search: ['name', 'organization', 'email'], searchLabel: 'Search', searchPlaceholder: 'Name, organisation or address',
    filters: [{ key: 'campaign_id', label: 'Campaign', all: 'All campaigns',
      options: (campaigns.rows || []).map((k) => ({ value: String(k._id), label: k.name })) }],
    columns: [
      // A plain first column: the table makes it the link that opens the email.
      { key: 'name', label: 'To', format: (v, r) => who(r) },
      { key: 'subject', label: 'Subject', clamp: true, sortable: false },
      { key: 'campaign', label: 'Campaign' },
      { key: 'position', label: 'Leaves around', render: (r) => (r.campaign_status !== 'Active' ? `${r.campaign_status}: it waits`
        : clock(times[Number(r.position) - 1] || null, sch.tz)) },
      { key: 'queued_at', label: 'Written', format: (v) => ago(v) },
    ],
    bulk: [{ label: 'Don’t send', action: A.cancelSends, danger: true,
      confirm: 'Hold back {n}? They are cancelled: those contacts do not get this campaign’s email.', done: '{n} cancelled' }],
    detail: {
      title: 'The email', table: T.sends,
      render: (row) => {
        const mail = el('div', {}, el('p', { class: 'oc-muted' }, 'Loading the email…'));
        showMail(mail, row);
        return el('div', { class: 'oc-stack' }, [
          el('dl', { class: 'oc-dl' }, [
            ['To', `${row.name || ''} <${row.email}>`], ['From', row.from_address || '—'], ['Subject', row.subject || '—'],
          ].map(([k, v]) => el('div', { class: 'oc-dl__row' }, [el('dt', k), el('dd', v)]))),
          mail,
        ]);
      },
    },
  });
}

async function sendNext() {
  const yes = await Orch.confirm('Send the next email now, without waiting for its turn? The sending window, the daily cap and a pause still apply.', { yes: 'Send it' });
  if (!yes) return;
  await act(A.sendNow, {}, 'Sending the next one: it shows under Sent within a minute.');
}
