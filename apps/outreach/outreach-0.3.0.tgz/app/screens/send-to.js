// Step 2 of a draft, Sendy's "Define recipients & send": the lists and
// audiences it goes to, the ones it leaves out, the exact count (the
// Count recipients workflow runs the same code that will send, so this is
// the number that goes out) with why the others are left out, a test to
// yourself, the checks, and Send now / Schedule — or Start, for a sequence.
import { V, T, A, MC, act, list, settings, confirmTwice, waitFor, senderOf, plural } from '../data.js';
import { localClock, zonedInstant, toDate } from '../time.js';

const { el, router, fmt } = Orch;

export async function sendTo(host, k, s) {
  const [lists, auds] = await Promise.all([
    Orch.db.view(V.lists, { sort: 'position:asc', limit: 200 }),
    Orch.db.view(V.audiences, { sort: 'name:asc', limit: 200 }),
  ]);
  const rec = MC.parseRecipients(k) || { lists: [], audiences: [], exclude_lists: [], exclude_audiences: [] };
  const listRows = lists.rows || [];
  const audRows = auds.rows || [];
  const count = el('div', { class: 'ox-count-box', 'aria-live': 'polite' });
  const checks = el('ul', { class: 'ox-checks' });
  const sendBox = el('div', { class: 'ox-actions' });
  let estimate = parse(k.estimate);
  // While a count runs, what the last one said is not shown: it may be about
  // an email or recipients that have changed since.
  let counting = false;
  const ms = (v) => { const d = toDate(v); return d ? d.getTime() : 0; };
  /** A count that no longer describes this campaign: old, or older than its last change. */
  const stale = (e) => !e || !e.at || Date.now() - ms(e.at) > 10 * 60000
    // The email or the recipients changed after it was counted (the count's own write is within a second).
    || ms(k._updated_at) - ms(e.at) > 5000
    || (!!e.content && /no subject or text/.test(e.content) && !!String(k.subject || '').trim() && !!String(k.body || '').trim());

  // ── who ────────────────────────────────────────────────────────────────
  const boxes = [];
  const option = (group, value, label, sub, checked) => {
    const i = el('input', { type: 'checkbox', checked: checked ? true : null });
    i.dataset.group = group;
    i.dataset.value = String(value);
    i.addEventListener('change', changed);
    boxes.push(i);
    return el('label', { class: 'ox-pick' }, [i, el('span', {}, [el('span', {}, label), sub ? el('span', { class: 'oc-small oc-muted' }, ` ${sub}`) : null])]);
  };
  const listOpts = (group, chosen) => (listRows.length ? listRows.map((l) => option(group, l.name, l.name, `${fmt.number(l.reachable)} can be emailed`, chosen.includes(l.name)))
    : [el('p', { class: 'oc-muted' }, ['No list yet. ', router.link('/lists', 'Make one'), ' or import contacts into one.'])]);
  const audOpts = (group, chosen) => (audRows.length ? audRows.map((a) => option(group, a._id, a.name, a.description || '', chosen.includes(a._id)))
    : [el('p', { class: 'oc-muted' }, ['No audience yet. ', router.link('/audiences/new', 'Make one'), '.'])]);
  const skip = el('input', { type: 'checkbox', checked: Number(k.skip_contacted) !== 0 ? true : null });
  skip.addEventListener('change', changed);
  const mode = k.kind === 'sequence' ? el('fieldset', { class: 'oc-field ox-plain' }, [
    el('legend', { class: 'oc-label' }, 'Before each email goes out'),
    ...[['auto', ' Send it: each email is written and queued without review'], ['review', ' Let me review it: each one waits in To review, where I can edit it']]
      .map(([v, t]) => {
        const i = el('input', { type: 'radio', name: 'mode', value: v, checked: (k.mode || 'auto') === v ? true : null });
        i.addEventListener('change', () => act(A.updateCampaign, { id: k._id, mode: v }).then((r) => { if (r) k.mode = v; }));
        return el('label', { class: 'ox-choice' }, [i, t]);
      }),
  ]) : null;

  function picked() {
    const out = { lists: [], audiences: [], exclude_lists: [], exclude_audiences: [] };
    for (const b of boxes) if (b.checked) out[b.dataset.group].push(b.dataset.group.endsWith('audiences') ? Number(b.dataset.value) : b.dataset.value);
    return out;
  }
  let timer = null;
  function changed() {
    clearTimeout(timer);
    counting = true;
    paintChecks();
    Orch.mount(count, el('p', { class: 'oc-muted' }, 'Counting…'));
    timer = setTimeout(saveAndCount, 700);
  }
  async function saveAndCount() {
    const before = estimate && estimate.at;
    const r = await act(A.setRecipients, { id: k._id, recipients: JSON.stringify(picked()), skip_contacted: skip.checked ? 1 : 0 });
    if (!r) return;
    k.recipients = JSON.stringify(picked());
    k.skip_contacted = skip.checked ? 1 : 0;
    await recount(before);
  }
  async function recount(before) {
    counting = true;
    Orch.mount(count, el('p', { class: 'oc-muted' }, 'Counting…'));
    paintChecks();
    const row = await waitFor(() => Orch.db.get(T.campaigns, k._id), (x) => x && x.estimate && parse(x.estimate).at !== before, 40);
    counting = false;
    if (!row) {
      Orch.mount(count, el('p', { class: 'ox-note ox-note--warn' }, ['The count did not come back in time. ', el('button', { class: 'oc-btn oc-btn--sm', type: 'button', onClick: () => startCount() }, 'Count again')]));
      paintChecks();
      return;
    }
    estimate = parse(row.estimate);
    k._updated_at = row._updated_at;
    paint();
  }
  async function startCount() {
    const before = estimate && estimate.at;
    if (await act(A.countRecipients, { id: k._id })) await recount(before);
    else { counting = false; paint(); }
  }

  // ── the count, the checks, the button ──────────────────────────────────
  const REASON_ORDER = ['excluded', 'Unsubscribed', 'Bounced', 'Complained', 'Blocked', 'no_email', 'invalid', 'suppressed', 'duplicate', 'written', 'contacted', 'pending', 'missing'];
  function paint() {
    const e = estimate;
    if (counting) {
      Orch.mount(count, el('p', { class: 'oc-muted' }, 'Counting…'));
    } else if (!e) {
      Orch.mount(count, el('p', { class: 'oc-muted' }, 'Pick who gets it: the count shows here.'));
    } else if (e.problem) {
      Orch.mount(count, el('p', { class: 'ox-note ox-note--warn' }, e.problem));
    } else {
      const out = REASON_ORDER.filter((r) => e.counts && e.counts[r]).map((r) => el('li', {}, [
        el('span', {}, r === 'missing' ? `${MC.REASONS[r]}${Object.keys(e.missing || {}).length ? ` (${Object.entries(e.missing).map(([v, n]) => `{{${v}}}: ${n}`).join(', ')})` : ''}` : MC.REASONS[r]),
        el('span', { class: 'ox-count' }, fmt.number(e.counts[r])),
      ]));
      Orch.mount(count, [
        el('p', { class: 'ox-count-box__n' }, [el('span', { class: 'ox-num ox-num--big' }, fmt.number(e.count)), ` ${e.count === 1 ? 'person gets it' : 'people get it'}`]),
        el('p', { class: 'oc-small oc-muted' }, `${plural(e.in_scope, 'contact is', 'contacts are')} in what you picked · counted ${localClock(e.at)}`),
        out.length ? el('details', { class: 'ox-why' }, [el('summary', `${plural(e.in_scope - e.count, 'is', 'are')} left out, and why`), el('ul', { class: 'ox-rows ox-rows--tight' }, out)]) : null,
      ]);
    }
    paintChecks();
  }

  const unsubPage = { public: null };
  async function checkPage() {
    const url = String(s && s.unsubscribe_url || '').split('#')[0];
    if (!url || Number(k.unsubscribe_link) !== 1) return;
    try {
      const html = await (await fetch(url, { credentials: 'omit', cache: 'no-store' })).text();
      unsubPage.public = /name="outreach-unsubscribe"/.test(html);
    } catch { unsubPage.public = false; }
    paintChecks();
  }

  function paintChecks() {
    const e = counting ? null : estimate;
    const from = senderOf(k, s);
    const items = [];
    const add = (ok, text, fix) => items.push(el('li', { class: `ox-check ox-check--${ok === true ? 'ok' : ok === false ? 'bad' : 'warn'}` }, [
      el('span', { class: 'ox-check__mark', 'aria-hidden': 'true' }, ok === true ? '✓' : ok === false ? '✕' : '!'), el('span', {}, [text, fix ? ' ' : null, fix || null]),
    ]));
    add(!!(k.subject && String(k.body || '').trim()), k.subject ? `Subject: “${k.subject}”` : 'The email has no subject or text.', router.link(`/campaigns/${k._id}/email`, 'Edit the email'));
    add(!!from.email, from.email ? `From ${from.text}` : 'No sender: set one in the email or in Settings.');
    // The two lines above already say it when the text or the sender is missing.
    if (e && e.content && !/no subject or text|no sender address/.test(e.content)) add(false, e.content);
    if (counting) add(null, 'Counting who gets it…');
    else add(e && !e.problem ? e.count > 0 : null, e && !e.problem ? `${plural(e.count, 'person gets', 'people get')} it.` : 'Nobody is picked yet.');
    if (k.kind === 'broadcast') {
      add(Number(k.unsubscribe_link) === 1 ? true : null, Number(k.unsubscribe_link) === 1 ? 'It has an unsubscribe link.' : 'It has no unsubscribe link.', Number(k.unsubscribe_link) === 1 ? null : router.link(`/campaigns/${k._id}/email`, 'Add it'));
      if (Number(k.unsubscribe_link) === 1) {
        if (unsubPage.public === false) add(null, 'The unsubscribe page is not public yet, so the link opens a sign-in. An admin sets Canvas → Unsubscribe to Public and publishes it.');
        if (unsubPage.public === true) add(true, 'The unsubscribe page is public.');
      }
      add(s && s.postal_address ? true : null, s && s.postal_address ? 'The footer has your postal address.' : 'No postal address in the footer: the law asks for one in most countries.', s && s.postal_address ? null : router.link('/settings', 'Add it in Settings'));
      const cap = Number(s && s.broadcast_daily_cap) || 500;
      if (e && e.count > cap) add(null, `${fmt.number(e.count)} is more than the daily limit of ${fmt.number(cap)}: it goes out over ${Math.ceil(e.count / cap)} days.`, router.link('/settings', 'Change the limit'));
    }
    Orch.mount(checks, items);
    paintSend();
  }

  function blockers() {
    const e = estimate;
    if (!k.subject || !String(k.body || '').trim()) return 'Write the email first.';
    if (!senderOf(k, s).email) return 'Set a sender first.';
    if (counting) return 'Counting who gets it…';
    if (!e) return 'Pick who gets it first.';
    if (e.problem || e.content) return e.problem || e.content;
    if (!e.count) return 'Nobody would get it.';
    return null;
  }

  function paintSend() {
    const why = blockers();
    const b = (label, onClick, kind) => el('button', { class: `oc-btn${kind ? ` oc-btn--${kind}` : ''}`, type: 'button', disabled: why ? true : null, title: why || null, onClick }, label);
    if (k.kind === 'broadcast') {
      Orch.mount(sendBox, [
        b('Send now…', sendNow, 'primary'),
        b('Schedule…', schedule),
        why ? el('span', { class: 'oc-small oc-muted' }, why) : null,
      ]);
    } else {
      Orch.mount(sendBox, [
        b(k.status === 'Paused' ? 'Resume…' : 'Start…', start, 'primary'),
        why ? el('span', { class: 'oc-small oc-muted' }, why) : null,
      ]);
    }
  }

  async function sendNow() {
    const n = estimate.count;
    const yes = await confirmTwice({
      title: `Send “${k.name}” now?`,
      text: `It goes to ${plural(n, 'person', 'people')} now, in batches of 100. A sent email cannot be taken back; you can pause what has not left yet.`,
      ack: `Yes, send it to ${plural(n, 'person', 'people')} now`, yes: 'Send it', danger: false,
    });
    if (!yes) return;
    if (await act(A.sendBroadcast, { id: k._id }, 'Sending: the first batch leaves within a minute.')) router.go(`/campaigns/${k._id}`);
  }

  async function schedule() {
    const tz = (s && s.timezone) || 'UTC';
    const tomorrow = new Date(Date.now() + 86400000);
    const date = el('input', { class: 'oc-input', type: 'date', name: 'date', required: true, value: tomorrow.toISOString().slice(0, 10) });
    const time = el('input', { class: 'oc-input', type: 'time', name: 'time', required: true, value: (s && s.window_start) || '09:00' });
    const form = el('form', { class: 'ox-form' }, [
      el('div', { class: 'ox-grid2' }, [
        el('label', { class: 'oc-field' }, [el('span', { class: 'oc-label' }, 'Day'), date]),
        el('label', { class: 'oc-field' }, [el('span', { class: 'oc-label' }, `Time (${tz})`), time]),
      ]),
      el('p', { class: 'oc-help' }, `It goes to whoever is in its recipients at that time (about ${plural(estimate.count, 'person', 'people')} today). Until then you can cancel the schedule, and it is a draft again.`),
      el('div', { class: 'ox-actions' }, [el('button', { class: 'oc-btn oc-btn--primary', type: 'submit' }, 'Schedule it')]),
    ]);
    const dlg = Orch.dialog(form, { title: `Schedule “${k.name}”` });
    Orch.onSubmit(form, async (d) => {
      const at = zonedInstant(d.date, d.time, tz);
      if (!at || at <= new Date()) { Orch.toast('Pick a time in the future.', { error: true }); return; }
      if (await act(A.scheduleBroadcast, { id: k._id, scheduled_at: at.toISOString() }, `Scheduled for ${localClock(at.toISOString())}.`)) {
        dlg.close();
        router.go(`/campaigns/${k._id}`);
      }
    });
  }

  async function start() {
    const resume = k.status === 'Paused';
    const text = k.mode === 'review'
      ? `${resume ? 'Resume' : 'Start'} it? Its emails are written now for ${plural(estimate.count, 'person', 'people')} and wait in To review until you approve them.`
      : `${resume ? 'Resume' : 'Start'} it? Its emails are written now for ${plural(estimate.count, 'person', 'people')} and go out one at a time, at the pace set in Settings, without review.`;
    if (!(await Orch.confirm(text, { yes: resume ? 'Resume' : 'Start' }))) return;
    if (await act(resume ? A.resumeCampaign : A.startCampaign, { id: k._id }, resume ? 'Resumed.' : 'Started: its emails are being written.')) router.go(`/campaigns/${k._id}`);
  }

  // ── test ───────────────────────────────────────────────────────────────
  const testTo = el('input', { class: 'oc-input', name: 'to', type: 'text', value: (s && s.from_email) || '', placeholder: 'you@example.com, a colleague' });
  const testLine = el('p', { class: 'oc-small oc-muted' }, testText(parse(k.test_result)));
  const testBtn = el('button', { class: 'oc-btn', type: 'button', onClick: async () => {
    const before = (parse(k.test_result) || {}).at;
    testBtn.disabled = true;
    testLine.textContent = 'Sending the test…';
    if (await act(A.testSend, { id: k._id, to: testTo.value })) {
      const row = await waitFor(() => Orch.db.get(T.campaigns, k._id), (x) => x && x.test_result && (parse(x.test_result) || {}).at !== before, 60);
      k.test_result = row ? row.test_result : k.test_result;
      testLine.textContent = row ? testText(parse(row.test_result)) : 'The test did not report back in time: look in your inbox.';
    }
    testBtn.disabled = false;
  } }, 'Send a test');

  Orch.mount(host, el('div', { class: 'ox-sendto' }, [
    el('div', { class: 'ox-form' }, [
      el('section', { class: 'ox-section ox-section--first' }, [
        el('h2', { class: 'oc-h3' }, 'Send to'),
        el('p', { class: 'oc-help' }, 'Everyone in any of these. A contact in two of them gets it once.'),
        el('div', { class: 'ox-picks' }, [el('p', { class: 'oc-label' }, 'Lists'), ...listOpts('lists', rec.lists)]),
        el('div', { class: 'ox-picks' }, [el('p', { class: 'oc-label' }, 'Audiences'), ...audOpts('audiences', rec.audiences)]),
      ]),
      el('details', { class: 'ox-section', open: rec.exclude_lists.length || rec.exclude_audiences.length ? true : null }, [
        el('summary', { class: 'oc-h3' }, 'Leave out'),
        el('p', { class: 'oc-help' }, 'Whoever is in any of these does not get it, even when they are in what it goes to.'),
        el('div', { class: 'ox-picks' }, [el('p', { class: 'oc-label' }, 'Lists'), ...listOpts('exclude_lists', rec.exclude_lists)]),
        el('div', { class: 'ox-picks' }, [el('p', { class: 'oc-label' }, 'Audiences'), ...audOpts('exclude_audiences', rec.exclude_audiences)]),
      ]),
      el('section', { class: 'ox-section' }, [
        el('label', { class: 'ox-choice' }, [skip, ' Skip anyone another campaign already wrote to']),
        el('p', { class: 'oc-help' }, 'Never written to, whatever you pick: unsubscribed, bounced, marked as spam and blocked contacts, and the no-contact list in Settings.'),
        mode,
      ]),
    ]),
    el('aside', { class: 'ox-sendbox' }, [
      count,
      el('section', { class: 'ox-section' }, [
        el('h2', { class: 'oc-h3' }, 'Send yourself a test'),
        el('div', { class: 'ox-inline' }, [el('label', { class: 'oc-field ox-grow' }, [el('span', { class: 'oc-label' }, 'To (up to five)'), testTo]), testBtn]),
        testLine,
      ]),
      el('section', { class: 'ox-section' }, [el('h2', { class: 'oc-h3' }, 'Before it goes'), checks]),
      el('section', { class: 'ox-section' }, [sendBox]),
    ]),
  ]));
  // A first count, or one the email or recipients have outgrown: ask again
  // (it runs the same code that sends), and show nothing of the old one meanwhile.
  const recountNow = MC.hasRecipients(rec) && stale(estimate);
  if (recountNow) counting = true;
  paint();
  checkPage();
  if (recountNow) startCount();
}

function parse(text) {
  try { return text ? JSON.parse(text) : null; } catch { return null; }
}
function testText(t) {
  if (!t) return 'Not tested yet.';
  if (t.error && !(t.sent || []).length) return `The test did not go: ${t.error}`;
  return `Test sent ${localClock(t.at)} to ${(t.sent || []).join(', ')}${t.sample ? `, written for ${t.sample}` : ''}.${t.error ? ` Not to: ${t.error}` : ''}`;
}
