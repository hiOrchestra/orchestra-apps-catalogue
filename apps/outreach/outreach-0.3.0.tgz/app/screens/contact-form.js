// The dialogs of the Contacts screen: add or edit one contact, put ticked
// contacts on a list (or take them off), move them to a stage. Custom fields
// come from Settings (outreach_fields); lists are stored in the tags column.
import { T, A, settings, fields, list, act, tagsOf, tagsText } from '../data.js';

const { el } = Orch;

/** Add (row = null) or edit a contact. */
export async function editContact(row, fsIn, stagesIn) {
  const [fs, s] = await Promise.all([fsIn || fields(), settings()]);
  const stages = stagesIn || list((s || {}).stages);
  const known = list((s || {}).tags);
  const r = row || {};
  const input = (name, label, attrs = {}) => el('label', { class: 'oc-field' }, [el('span', { class: 'oc-label' }, label),
    el('input', { class: 'oc-input', name, value: r[name] || '', ...attrs })]);
  const select = (name, label, options) => {
    const sel = el('select', { class: 'oc-select', name }, [el('option', { value: '' }, '—'), ...options.map((o) => el('option', { value: o }, o))]);
    sel.value = r[name] || '';
    return el('label', { class: 'oc-field' }, [el('span', { class: 'oc-label' }, label), sel]);
  };
  const custom = fs.map((f) => (f.kind === 'list' ? select(f.key, f.label, list(f.options)) : input(f.key, f.label)));
  const notes = el('textarea', { class: 'oc-textarea', name: 'notes', rows: '3' });
  notes.value = r.notes || '';
  const mine = new Set(tagsOf(r.tags));
  const boxes = [...new Set([...known, ...mine])].map((name) => el('label', { class: 'ox-pick' }, [
    el('input', { type: 'checkbox', name: `list:${name}`, checked: mine.has(name) ? true : null }), el('span', name),
  ]));
  const form = el('form', { class: 'ox-form' }, [
    el('div', { class: 'ox-grid2' }, [
      input('name', 'Name', { required: true, maxlength: '200' }), input('email', 'Email', { type: 'email', maxlength: '254' }),
      input('organization', 'Organisation', { maxlength: '200' }), input('website', 'Website', { type: 'url', placeholder: 'https://' }),
      stages.length ? select('stage', 'Stage', stages) : null, ...custom,
    ]),
    el('fieldset', { class: 'oc-field ox-plain' }, [el('legend', { class: 'oc-label' }, 'Lists'),
      boxes.length ? el('div', { class: 'ox-picks ox-picks--inline' }, boxes) : el('p', { class: 'oc-muted' }, 'No list yet: make one in Lists.')]),
    el('label', { class: 'oc-field' }, [el('span', { class: 'oc-label' }, 'Notes'), notes]),
    el('p', { class: 'oc-help' }, 'Leave the email empty and, in a stage that is looked up, the agent looks for it.'),
    el('div', { class: 'ox-actions' }, [el('button', { class: 'oc-btn oc-btn--primary', type: 'submit' }, row ? 'Save' : 'Add')]),
  ]);
  const dlg = Orch.dialog(form, { title: row ? `Edit ${r.name || 'contact'}` : 'Add a contact' });
  Orch.onSubmit(form, async (d) => {
    const data = {};
    const lists = [];
    for (const [k, v] of Object.entries(d)) {
      if (k.startsWith('list:')) { if (v) lists.push(k.slice(5)); continue; }
      data[k] = typeof v === 'string' ? v.trim() : v;
    }
    data.tags = tagsText(lists);
    // Empty, not null: an action writes only the fields it is given, and null is "not given".
    const email = (data.email || '').toLowerCase();
    data.email = email;
    if (email !== (r.email || '')) data.email_status = email ? 'Manual' : '';
    try {
      const res = await Orch.action(row ? A.editContact : A.addContact, row ? { id: row._id, ...data } : data);
      Orch.toast(row ? 'Saved.' : 'Added.');
      dlg.close();
      Orch.router.go(`/contacts?open=${row ? row._id : res._id}`);
    } catch (e) {
      Orch.toast(/UNIQUE/i.test(e.message) ? 'Another contact already has this email.' : e.message, { error: true });
    }
  });
}

/**
 * Put the ticked contacts on a list, or take them off. A contact keeps its
 * other lists, so contacts that end with the same lists are written together:
 * one bulk write per distinct result, not one per contact.
 */
export async function listDialog(table, s) {
  const ids = table ? table.selection : [];
  if (!ids.length) { Orch.toast('Tick the contacts first.', { error: true }); return; }
  const known = list(s && s.tags);
  const name = el('input', { class: 'oc-input', name: 'list', required: true, maxlength: '80', list: 'ox-known-lists', placeholder: known[0] || 'Newsletter' });
  const add = el('input', { type: 'radio', name: 'how', value: 'add', checked: true });
  const form = el('form', { class: 'ox-form' }, [
    el('label', { class: 'oc-field' }, [el('span', { class: 'oc-label' }, 'List (a new name makes a new list)'), name]),
    el('datalist', { id: 'ox-known-lists' }, known.map((k) => el('option', { value: k }))),
    el('fieldset', { class: 'oc-field ox-plain' }, [el('legend', { class: 'oc-label' }, `${ids.length} ${ids.length === 1 ? 'contact' : 'contacts'}`),
      el('label', { class: 'ox-choice' }, [add, ' Add them to it']),
      el('label', { class: 'ox-choice' }, [el('input', { type: 'radio', name: 'how', value: 'remove' }), ' Take them off it'])]),
    el('div', { class: 'ox-actions' }, [el('button', { class: 'oc-btn oc-btn--primary', type: 'submit' }, 'Apply')]),
  ]);
  const dlg = Orch.dialog(form, { title: 'Lists' });
  Orch.onSubmit(form, async (d) => {
    const listName = String(d.list || '').replace(/\|/g, '/').trim();
    if (!listName) return;
    const rows = await Orch.db.lookup(T.contacts, ids, { select: ['tags'] });
    const groups = new Map();
    for (const id of ids) {
      const now = tagsOf((rows[id] || {}).tags);
      const next = tagsText(d.how === 'remove' ? now.filter((x) => x !== listName) : [...now, listName]);
      if (!groups.has(next)) groups.set(next, []);
      groups.get(next).push(id);
    }
    for (const [tags, group] of groups) {
      if (!(await act(A.setTags, { ids: group, tags }))) return;
    }
    if (d.how !== 'remove') await remember([listName]);
    Orch.toast(`${d.how === 'remove' ? `Taken off “${listName}”` : `Added to “${listName}”`}: ${ids.length} ${ids.length === 1 ? 'contact' : 'contacts'}.`);
    dlg.close();
    table.reload();
  });
}

/** Move the ticked contacts to one stage. */
export function stageDialog(table, stages) {
  const ids = table ? table.selection : [];
  if (!ids.length) { Orch.toast('Tick the contacts first.', { error: true }); return; }
  const sel = el('select', { class: 'oc-select', name: 'stage' }, stages.map((st) => el('option', { value: st }, st)));
  const form = el('form', { class: 'ox-form' }, [
    el('label', { class: 'oc-field' }, [el('span', { class: 'oc-label' }, `Move ${ids.length} ${ids.length === 1 ? 'contact' : 'contacts'} to`), sel]),
    el('div', { class: 'ox-actions' }, [el('button', { class: 'oc-btn oc-btn--primary', type: 'submit' }, 'Move them')]),
  ]);
  const dlg = Orch.dialog(form, { title: 'Stage' });
  Orch.onSubmit(form, async (d) => {
    if (await act(A.setStage, { ids, stage: d.stage }, `${ids.length} moved to ${d.stage}.`)) { dlg.close(); table.reload(); }
  });
}

/** New lists join the ones Settings offers (the registry the Lists screen shows). */
export async function remember(names) {
  const s = await settings();
  if (!s) return;
  const known = list(s.tags);
  const fresh = names.filter((t) => t && !known.includes(t));
  if (fresh.length) await act(A.updateSettings, { id: s._id, tags: JSON.stringify([...known, ...fresh].sort((a, b) => a.localeCompare(b))) });
}
