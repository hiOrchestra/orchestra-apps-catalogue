// Import contacts from a CSV, like Sendy's: pick the file, say which column
// is which (guessed from the headers), pick the list they join, import. The
// file is read here, in the browser, and uploaded in parts of about 50 KB (an
// action takes at most 100 KB); the Import contacts workflow does the rest and reports what
// it added, what it completed and each line it skipped, with why.
import { T, A, act, settings, fields, list, waitFor, plural } from '../data.js';
import { remember } from './contact-form.js';

const { el, router, fmt } = Orch;
// An action's body is at most 100 KB; the rows travel as an escaped JSON string
// inside it, and an accent is two bytes. Half of that leaves room for both.
const PART_BYTES = 50000;

export async function render(_params, path) {
  const query = new URLSearchParams(String(path || '').split('?')[1] || '');
  const [s, fs] = await Promise.all([settings(), fields()]);
  const lists = list(s && s.tags);
  const targets = [
    ['', 'Leave out'], ['email', 'Email'], ['name', 'Name'], ['first_name', 'First name'], ['last_name', 'Last name'],
    ['organization', 'Organisation'], ['title', 'Title'], ['website', 'Website'], ['country', 'Country'], ['city', 'City'],
    ['linkedin', 'LinkedIn'], ['stage', 'Stage'], ['notes', 'Notes'],
    ...fs.filter((f) => !['country'].includes(f.key)).map((f) => [f.key, f.label]),
  ];
  const step = el('div');
  const file = el('input', { type: 'file', accept: '.csv,text/csv,.tsv,text/tab-separated-values', class: 'oc-input' });
  const listName = el('input', { class: 'oc-input', name: 'list', maxlength: '80', list: 'ox-import-lists', value: query.get('list') || '', placeholder: 'Newsletter' });
  const overwrite = el('input', { type: 'checkbox' });
  Orch.mount('view', el('div', { class: 'ox-page' }, [
    el('header', { class: 'ox-head' }, [el('div', { class: 'ox-head__text' }, [
      router.link('/contacts', '← Contacts', { class: 'ox-crumb' }),
      el('h1', { class: 'oc-h1 oc-h1--collection' }, 'Import contacts'),
      el('p', { class: 'oc-lede' }, 'A CSV with a header row. One contact per address: an address already here keeps its contact, joins the list, and gets its empty fields filled.'),
    ])]),
    el('div', { class: 'ox-form ox-narrow' }, [
      el('label', { class: 'oc-field' }, [el('span', { class: 'oc-label' }, 'File'), file,
        el('span', { class: 'oc-help' }, 'Exported from a spreadsheet, Sendy, Mailchimp, a CRM: comma, semicolon or tab separated.')]),
      el('label', { class: 'oc-field' }, [el('span', { class: 'oc-label' }, 'They join the list (a new name makes a new list)'), listName,
        el('datalist', { id: 'ox-import-lists' }, lists.map((x) => el('option', { value: x })))]),
      el('label', { class: 'ox-choice' }, [overwrite, ' Replace values contacts already have with the file\'s (otherwise only empty ones are filled)']),
    ]),
    step,
  ]));

  file.addEventListener('change', async () => {
    const f = file.files && file.files[0];
    if (!f) return;
    if (f.size > 25 * 1024 * 1024) { Orch.toast('The file is over 25 MB: split it and import the parts.', { error: true }); return; }
    const text = await f.text();
    const rows = parseCsv(text);
    if (rows.length < 2) { Orch.mount(step, el('p', { class: 'ox-note ox-note--bad' }, 'The file has no rows under its header.')); return; }
    mapping(step, f.name, rows, targets, () => ({ list: listName.value, overwrite: overwrite.checked }));
  });
}

/** Which column is which, guessed from the headers; the first rows as they read. */
function mapping(host, fileName, rows, targets, options) {
  const [header, ...data] = rows;
  const guess = (h) => {
    const k = String(h || '').toLowerCase().replace(/[^a-z]/g, '');
    const table = { email: ['email', 'emailaddress', 'mail', 'correo', 'correoelectronico', 'emailadresse'], name: ['name', 'fullname', 'nombre', 'contact', 'contactname'],
      first_name: ['firstname', 'givenname', 'vorname', 'nombrepila'], last_name: ['lastname', 'surname', 'familyname', 'apellido', 'nachname'],
      organization: ['organization', 'organisation', 'company', 'companyname', 'empresa', 'firma', 'fund'], title: ['title', 'jobtitle', 'position', 'role', 'cargo'],
      website: ['website', 'web', 'url', 'site'], country: ['country', 'pais', 'land'], city: ['city', 'ciudad', 'stadt'], linkedin: ['linkedin', 'linkedinurl'], notes: ['notes', 'note', 'notas'], stage: ['stage'] };
    for (const [target, names] of Object.entries(table)) if (names.includes(k)) return target;
    const custom = targets.find(([key, label]) => key && (key.toLowerCase() === k || String(label).toLowerCase().replace(/[^a-z]/g, '') === k));
    return custom ? custom[0] : '';
  };
  const selects = header.map((h) => {
    const sel = el('select', { class: 'oc-select', 'aria-label': `Column ${h}` }, targets.map(([v, l]) => el('option', { value: v }, l)));
    sel.value = guess(h);
    return sel;
  });
  const sample = (i) => data.slice(0, 3).map((r) => r[i]).filter((v) => v !== undefined && String(v).trim() !== '').join(' · ');
  const summary = el('p', { class: 'oc-help' });
  const go = el('button', { class: 'oc-btn oc-btn--primary', type: 'button' }, 'Import');
  const result = el('div');
  const check = () => {
    const chosen = selects.map((x) => x.value).filter(Boolean);
    const dup = chosen.find((v, i) => chosen.indexOf(v) !== i);
    const e = selects.findIndex((x) => x.value === 'email');
    const withEmail = e < 0 ? 0 : data.filter((r) => /@/.test(String(r[e] || ''))).length;
    summary.textContent = e < 0 ? 'Say which column is the email.' : dup ? `Two columns are “${targets.find(([v]) => v === dup)[1]}”: pick one.`
      : `${plural(data.length, 'line', 'lines')} under the header; ${fmt.number(withEmail)} look like an address.`;
    go.disabled = e < 0 || !!dup;
  };
  selects.forEach((x) => x.addEventListener('change', check));
  go.addEventListener('click', () => upload(result, fileName, header, data, selects.map((x) => x.value), options(), go));
  Orch.mount(host, el('section', { class: 'ox-section' }, [
    el('h2', { class: 'oc-h3' }, `${fileName}: which column is which`),
    el('div', { class: 'oc-scroll-x' }, el('table', { class: 'oc-table' }, [
      el('thead', {}, el('tr', {}, ['Column in the file', 'First values', 'Goes to'].map((t) => el('th', { scope: 'col' }, t)))),
      el('tbody', {}, header.map((h, i) => el('tr', {}, [el('td', {}, h || `Column ${i + 1}`), el('td', { class: 'oc-cell--clamp oc-muted' }, sample(i) || '—'), el('td', {}, selects[i])]))),
    ])),
    summary,
    el('div', { class: 'ox-actions' }, [go]),
    result,
  ]));
  check();
}

/** The mapped rows, in parts, then the workflow; then what it did. */
async function upload(host, fileName, header, data, map, opts, go) {
  const list = String(opts.list || '').replace(/\|/g, '/').trim();
  const rows = data.map((r, i) => {
    const o = { _line: i + 2 };
    map.forEach((target, c) => {
      if (!target) return;
      const v = String(r[c] ?? '').trim();
      if (v) o[target] = v;
    });
    if (!o.name && (o.first_name || o.last_name)) o.name = [o.first_name, o.last_name].filter(Boolean).join(' ');
    delete o.first_name;
    delete o.last_name;
    return o;
  }).filter((o) => Object.keys(o).length > 1);
  const parts = [];
  let cur = [];
  let size = 0;
  for (const r of rows) {
    const n = new TextEncoder().encode(JSON.stringify(r)).length + 1;
    if (cur.length && size + n > PART_BYTES) { parts.push(cur); cur = []; size = 0; }
    cur.push(r);
    size += n;
  }
  if (cur.length) parts.push(cur);
  const key = `imp-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
  go.disabled = true;
  const say = el('p', { class: 'oc-muted' }, 'Uploading…');
  Orch.mount(host, say);
  for (let i = 0; i < parts.length; i += 1) {
    say.textContent = `Uploading part ${i + 1} of ${parts.length}…`;
    const ok = await act(A.addImportPart, { import_key: key, part: i + 1, parts: parts.length, file_name: fileName, list_name: list, overwrite: opts.overwrite ? 1 : 0, rows: JSON.stringify(parts[i]) });
    if (!ok) { say.textContent = 'The upload stopped: import the file again.'; go.disabled = false; return; }
  }
  if (list) await remember([list]);
  say.textContent = 'Importing…';
  if (!(await act(A.runImport, { import_key: key }))) { go.disabled = false; return; }
  const first = await waitFor(async () => ((await Orch.db.list(T.imports, { filter: { import_key: key, part: 1 }, limit: 1 })).rows || [])[0],
    (x) => x && (x.status === 'Done' || x.status === 'Failed'), 300);
  if (!first) { say.textContent = 'The import is still running: its contacts show in Contacts when it is done.'; return; }
  let res = {};
  try { res = JSON.parse(first.result || '{}'); } catch { res = {}; }
  if (first.status === 'Failed') { Orch.mount(host, el('p', { class: 'ox-note ox-note--bad' }, `The import failed: ${res.error || 'no reason given'}`)); go.disabled = false; return; }
  const skipped = res.skipped_rows || [];
  Orch.mount(host, el('div', { class: 'oc-stack' }, [
    el('p', { class: 'ox-note' }, [
      `${plural(res.added || 0, 'contact', 'contacts')} added, ${fmt.number(res.updated || 0)} completed, ${fmt.number(res.unchanged || 0)} already as in the file`,
      res.skipped ? `, ${fmt.number(res.skipped)} ${res.skipped === 1 ? 'line' : 'lines'} skipped` : '', '.',
      res.not_active ? ` ${plural(res.not_active, 'of them is', 'of them are')} unsubscribed, bounced or blocked, and stay so.` : '',
    ]),
    list ? router.link(`/contacts?tags=${encodeURIComponent(`|${list}|`)}`, `See the list “${list}”`) : router.link('/contacts', 'See the contacts'),
    skipped.length ? el('details', { class: 'ox-why' }, [
      el('summary', `The skipped lines${res.skipped > skipped.length ? ` (the first ${fmt.number(skipped.length)})` : ''}`),
      el('ul', { class: 'ox-rows ox-rows--tight' }, skipped.slice(0, 50).map((x) => el('li', {}, [el('span', `Line ${x.line}: ${x.email || '(no address)'}`), el('span', { class: 'oc-muted' }, x.reason)]))),
      el('button', { class: 'oc-btn oc-btn--sm', type: 'button', onClick: () => downloadSkipped(fileName, skipped) }, 'Download them (CSV)'),
    ]) : null,
  ]));
}

function downloadSkipped(fileName, skipped) {
  const cell = (v) => { const t = String(v ?? ''); return /[",\n\r]/.test(t) ? `"${t.replace(/"/g, '""')}"` : t; };
  const csv = `﻿${['line,email,reason', ...skipped.map((x) => [x.line, x.email, x.reason].map(cell).join(','))].join('\r\n')}`;
  const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' }));
  const a = el('a', { href: url, download: `${fileName.replace(/\.[^.]+$/, '')} - skipped.csv` });
  document.body.appendChild(a);
  a.click();
  a.remove();
}

/** RFC 4180-ish: quotes, doubled quotes, line breaks inside quotes; comma, semicolon or tab, guessed from the header. */
export function parseCsv(text) {
  const src = String(text || '').replace(/^﻿/, '');
  const firstLine = src.split(/\r?\n/, 1)[0] || '';
  const count = (ch) => firstLine.split(ch).length - 1;
  const delim = [',', ';', '\t'].sort((a, b) => count(b) - count(a))[0];
  const rows = [];
  let row = [];
  let field = '';
  let quoted = false;
  for (let i = 0; i < src.length; i += 1) {
    const c = src[i];
    if (quoted) {
      if (c === '"' && src[i + 1] === '"') { field += '"'; i += 1; } else if (c === '"') quoted = false; else field += c;
    } else if (c === '"' && field === '') quoted = true;
    else if (c === delim) { row.push(field); field = ''; } else if (c === '\n' || c === '\r') {
      if (c === '\r' && src[i + 1] === '\n') i += 1;
      row.push(field); field = '';
      if (row.some((x) => x.trim() !== '')) rows.push(row);
      row = [];
    } else field += c;
  }
  row.push(field);
  if (row.some((x) => x.trim() !== '')) rows.push(row);
  return rows;
}
