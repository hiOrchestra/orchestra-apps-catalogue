// To review: emails of review-first campaigns, written and waiting for a yes.
// Reviewing means being able to change them: a row opens the email with its
// subject and text editable; save, then send it (it joins the end of the
// queue) or discard it. Ticked rows can be approved or discarded together.
import { V, T, A, act, who } from '../data.js';
import { ago } from '../time.js';

const { el } = Orch;

export async function render(_params, path) {
  const table = el('div');
  Orch.mount('view', el('div', { class: 'ox-page' }, [
    el('header', { class: 'ox-head' }, [el('div', { class: 'ox-head__text' }, [
      el('h1', { class: 'oc-h1 oc-h1--collection' }, 'To review'),
      el('p', { class: 'oc-lede' }, 'Written by campaigns that ask for review. Open one to read and edit it; approved emails join the end of the queue.'),
    ])]),
    table,
  ]));
  const campaigns = await Orch.db.view(V.campaigns, { filter: { mode: 'review' }, sort: 'name:asc', limit: 200 });
  const t = Orch.pattern('queue', {
    into: table, path: '/review', query: path, view: V.review, sort: 'written_at:asc', pageSize: 50,
    empty: 'Nothing is waiting for review.',
    search: ['name', 'organization', 'email', 'subject'], searchLabel: 'Search', searchPlaceholder: 'Name, organisation, address or subject',
    filters: [{ key: 'campaign_id', label: 'Campaign', all: 'All campaigns',
      options: (campaigns.rows || []).map((k) => ({ value: String(k._id), label: k.name })) }],
    columns: [
      // A plain first column: the table makes it the link that opens the email.
      { key: 'name', label: 'To', format: (v, r) => who(r) },
      { key: 'subject', label: 'Subject', clamp: true },
      { key: 'campaign', label: 'Campaign' },
      { key: 'written_at', label: 'Written', format: (v) => ago(v) },
    ],
    bulk: [
      { label: 'Approve', action: A.approve, confirm: 'Send {n} as they are? They join the end of the queue.', done: '{n} approved' },
      { label: 'Discard', action: A.discard, danger: true, confirm: 'Discard {n}? Those contacts do not get this campaign’s email.', done: '{n} discarded' },
    ],
    detail: { title: 'Review the email', table: T.sends, render: (row) => editor(row, () => t.reload()) },
  });
}

function editor(row, reload) {
  if (row.status !== 'In review') {
    return el('p', { class: 'oc-muted' }, `This email is no longer waiting for review: it is ${String(row.status || '').toLowerCase()}.`);
  }
  const subject = el('input', { class: 'oc-input', name: 'subject', required: true, maxlength: '300', value: row.subject || '' });
  const body = el('textarea', { class: 'oc-textarea', name: 'body', required: true, rows: '16' });
  body.value = row.body || '';
  const close = () => { const d = document.querySelector(`dialog[data-orch-detail="${row._id}"]`); if (d) d.close(); };
  const save = async () => {
    if (subject.value.trim() === (row.subject || '') && body.value === (row.body || '')) return true;
    const ok = await act(A.editDraft, { id: row._id, subject: subject.value.trim(), body: body.value });
    if (ok) { row.subject = subject.value.trim(); row.body = body.value; }
    return !!ok;
  };
  const form = el('form', { class: 'ox-form' }, [
    el('p', { class: 'oc-small oc-muted' }, `To ${row.name || ''} <${row.email}> · from ${row.from_address || '—'}`),
    el('label', { class: 'oc-field' }, [el('span', { class: 'oc-label' }, 'Subject'), subject]),
    el('label', { class: 'oc-field' }, [el('span', { class: 'oc-label' }, 'Text'), body]),
    el('div', { class: 'ox-actions' }, [
      el('button', { class: 'oc-btn oc-btn--primary', type: 'button', onClick: async () => {
        if (!(await save())) return;
        if (await act(A.approve, { ids: [row._id] }, 'Approved: it joins the queue.')) { close(); reload(); }
      } }, 'Save and send'),
      el('button', { class: 'oc-btn', type: 'submit' }, 'Save'),
      el('button', { class: 'oc-btn oc-btn--ghost', type: 'button', onClick: async () => {
        if (!(await Orch.confirm('Discard this email? This contact does not get this campaign’s email.', { yes: 'Discard', danger: true }))) return;
        if (await act(A.discard, { ids: [row._id] }, 'Discarded.')) { close(); reload(); }
      } }, 'Discard'),
    ]),
  ]);
  Orch.onSubmit(form, async () => { if (await save()) { Orch.toast('Saved.'); reload(); } });
  return form;
}
