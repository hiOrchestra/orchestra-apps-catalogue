// Audiences: who a campaign writes to, kept as conditions on contacts
// ("Stage is Shortlisted", "Type is one of Customer, Partner"), never as a fixed list:
// whoever meets them today is in, including contacts added tomorrow. The
// editor shows how many meet them and who, as you change them.
import { V, T, A, MC, fields, settings, list, act, OPS, rulesOf, filterOf } from '../data.js';

const { el, router, fmt } = Orch;
const BASE = [['tags', 'Lists'], ['stage', 'Stage'], ['organization', 'Organisation'], ['email', 'Email'], ['country', 'Country'], ['source', 'Came from']];

const PAGE = 50;

export async function render(params, path) {
  const id = params && params.id;
  const query = new URLSearchParams(String(path || '').split('?')[1] || '');
  const offset = Math.max(0, parseInt(query.get('offset'), 10) || 0);
  const side = el('div');
  const main = el('div');
  Orch.mount('view', el('div', { class: 'ox-page' }, [
    el('header', { class: 'ox-head' }, [
      el('div', { class: 'ox-head__text' }, [
        el('h1', { class: 'oc-h1 oc-h1--collection' }, 'Audiences'),
        el('p', { class: 'oc-lede' }, 'Conditions on contacts (“in the list Newsletter and in Spain”), not fixed lists: whoever meets them is in, including contacts added later.'),
      ]),
      router.link('/audiences/new', 'New audience', { class: 'oc-btn oc-btn--primary' }),
    ]),
    el('div', { class: 'ox-two' }, [side, main]),
  ]));
  const [aud, fs, s] = await Promise.all([Orch.db.view(V.audiences, { sort: 'name:asc', limit: PAGE, offset, count: true }), fields(), settings()]);
  const rows = aud.rows || [];
  const counts = await Promise.all(rows.map((a) => Orch.db.count(T.contacts, { filter: JSON.parse(a.filter || '{}') }).catch(() => null)));
  const pager = Orch.pager({ offset, limit: PAGE, total: aud.total, hasMore: aud.hasMore },
    (next) => router.go(`/audiences${id ? `/${id}` : ''}?offset=${next}`));
  Orch.mount(side, rows.length ? [el('ul', { class: 'ox-rows' }, rows.map((a, i) => el('li', {}, [
    el('div', {}, [
      router.link(`/audiences/${a._id}`, a.name, { 'aria-current': String(a._id) === String(id) ? 'true' : 'false' }),
      el('p', { class: 'oc-small oc-muted' }, a.used_by ? `Used by ${a.used_by}` : 'No campaign uses it'),
    ]),
    el('span', { class: 'ox-count' }, counts[i] === null ? '—' : fmt.number(counts[i])),
  ]))), pager] : el('p', { class: 'oc-muted' }, 'No audience yet.'));

  if (!id) { Orch.mount(main, el('p', { class: 'oc-muted' }, rows.length ? 'Pick an audience to see who is in it and change it.' : 'Make the first one.')); return; }
  const current = id === 'new' ? null : rows.find((a) => String(a._id) === String(id))
    || ((await Orch.db.view(V.audiences, { filter: { _id: id }, limit: 1 })).rows || [])[0];
  if (id !== 'new' && !current) { Orch.mount(main, el('p', { class: 'oc-muted' }, 'This audience does not exist.')); return; }
  const start = current ? rulesOf(current.filter)
    : [...query.keys()].filter((k) => k !== 'q' && k !== 'offset').map((k) => (k === 'tags'
      ? { field: k, op: 'tag', value: query.get(k).replace(/^\||\|$/g, '') }
      : { field: k, op: k === 'country' ? 'has' : 'is', value: query.get(k) }));
  editor(main, current, start.length ? start : [{ field: 'tags', op: 'tag', value: '' }], fs, list(s && s.stages), list(s && s.tags));
}

function editor(host, current, rules, fs, stages, tags) {
  const choices = [...BASE, ...fs.filter((f) => !BASE.some(([k]) => k === f.key)).map((f) => [f.key, f.label])];
  const optionsFor = { stage: stages, tags: tags, ...Object.fromEntries(fs.filter((f) => f.kind === 'list').map((f) => [f.key, list(f.options)])) };
  const name = el('input', { class: 'oc-input', required: true, maxlength: '120', value: current ? current.name : '', placeholder: 'Shortlisted VCs' });
  const description = el('input', { class: 'oc-input', maxlength: '300', value: current ? current.description || '' : '' });
  const box = el('div', { class: 'oc-stack' });
  const preview = el('div');
  let timer = null;
  const refresh = () => { clearTimeout(timer); timer = setTimeout(() => show(preview, filterOf(rules)), 350); };

  const draw = () => {
    Orch.mount(box, rules.map((r, i) => {
      const field = el('select', { class: 'oc-select', 'aria-label': 'Field' }, choices.map(([k, l]) => el('option', { value: k }, l)));
      field.value = r.field;
      const op = el('select', { class: 'oc-select', 'aria-label': 'Condition' }, OPS.map((o) => el('option', { value: o.op }, o.label)));
      op.value = r.op;
      const value = el('input', { class: 'oc-input', 'aria-label': 'Value', value: r.value || '', list: `ox-values-${r.field}`,
        placeholder: r.op === 'any' ? 'Several, separated by commas' : '', disabled: r.op === 'set' || r.op === 'unset' });
      field.addEventListener('change', () => {
        r.field = field.value; r.value = '';
        if (r.field === 'tags') r.op = 'tag'; else if (r.op === 'tag') r.op = 'is';
        draw(); refresh();
      });
      op.addEventListener('change', () => { r.op = op.value; draw(); refresh(); });
      value.addEventListener('input', () => { r.value = value.value; refresh(); });
      return el('div', { class: 'ox-rule' }, [
        el('label', { class: 'oc-field' }, [el('span', { class: 'oc-label' }, i ? 'and' : 'Contacts whose'), field]),
        op, value,
        el('button', { class: 'oc-btn oc-btn--ghost oc-btn--icon', type: 'button', 'aria-label': 'Remove this condition',
          onClick: () => { rules.splice(i, 1); draw(); refresh(); } }, '×'),
      ]);
    }));
  };
  draw();
  show(preview, filterOf(rules));

  const save = async () => {
    const filter = filterOf(rules);
    if (!name.value.trim()) { Orch.toast('Give it a name.', { error: true }); return; }
    const data = { name: name.value.trim(), description: description.value.trim(), filter: JSON.stringify(filter) };
    const r = await act(current ? A.updateAudience : A.createAudience, current ? { id: current._id, ...data } : data, 'Saved.');
    if (r) router.go(`/audiences/${current ? current._id : r._id}`);
  };
  const lists = Object.entries(optionsFor).map(([k, opts]) => el('datalist', { id: `ox-values-${k}` }, opts.map((o) => el('option', { value: o }))));
  Orch.mount(host, el('div', { class: 'ox-form' }, [
    el('div', { class: 'ox-grid2' }, [
      el('label', { class: 'oc-field' }, [el('span', { class: 'oc-label' }, 'Name'), name]),
      el('label', { class: 'oc-field' }, [el('span', { class: 'oc-label' }, 'What it is for'), description]),
    ]),
    box,
    ...lists,
    el('div', { class: 'ox-actions' }, [
      el('button', { class: 'oc-btn', type: 'button', onClick: () => { rules.push({ field: 'tags', op: 'tag', value: '' }); draw(); } }, 'Add a condition'),
      el('button', { class: 'oc-btn oc-btn--primary', type: 'button', onClick: save }, current ? 'Save changes' : 'Create the audience'),
      current && !current.campaigns ? el('button', { class: 'oc-btn oc-btn--ghost', type: 'button', onClick: async () => {
        if (!(await Orch.confirm(`Remove “${current.name}”? No campaign uses it.`, { yes: 'Remove', danger: true }))) return;
        if (await act(A.archiveAudience, { id: current._id }, 'Removed.')) router.go('/audiences');
      } }, 'Remove') : null,
    ]),
    current && current.campaigns ? el('p', { class: 'oc-help' }, `Used by ${current.used_by}: a change applies to the emails it writes from now on.`) : null,
    el('p', { class: 'oc-help' }, 'Never written to, whatever the conditions say: unsubscribed, bounced, marked-as-spam and blocked contacts, and the no-contact list in Settings. A campaign can also leave out a list or an audience.'),
    preview,
  ]));
}

const PER = 50;
// What a member's row says on the right: its address, or why it has none.
const reach = (c) => (MC.statusOf(c) !== 'Active' ? MC.STATUS_LABEL[MC.statusOf(c)].toLowerCase()
  : c.email || ({ 'Not found': 'email not found', Searching: 'being looked up' }[c.email_status] || 'no email yet'));

/** Everyone who meets the conditions today, 50 at a time; each opens its contact. */
async function show(host, filter, offset = 0) {
  try {
    const [res, withEmail] = await Promise.all([
      Orch.db.list(T.contacts, { filter, sort: 'name:asc', limit: PER, offset, count: true }),
      Orch.db.count(T.contacts, { filter: { ...filter, email: { notnull: '1' }, status: 'Active' } }),
    ]);
    Orch.mount(host, el('div', { class: 'ox-section' }, [
      el('h2', { class: 'oc-h3' }, `${fmt.number(res.total)} ${res.total === 1 ? 'contact meets' : 'contacts meet'} this · ${fmt.number(withEmail)} can be emailed`),
      (res.rows || []).length ? el('ul', { class: 'ox-rows' }, res.rows.map((c) => el('li', {}, [
        el('span', {}, [
          router.link(`/contacts?open=${c._id}`, c.name || '—'),
          c.organization && c.organization !== c.name ? el('span', { class: 'oc-muted' }, ` · ${c.organization}`) : null,
          c.stage ? el('span', { class: 'oc-muted' }, ` · ${c.stage}`) : null,
        ]),
        el('span', { class: 'oc-small oc-muted' }, reach(c)),
      ]))) : null,
      Orch.pager({ offset, limit: PER, total: res.total, hasMore: res.hasMore }, (next) => show(host, filter, next)),
    ]));
  } catch (e) {
    Orch.mount(host, el('p', { class: 'ox-note ox-note--bad' }, `These conditions cannot be read: ${e.message}`));
  }
}
