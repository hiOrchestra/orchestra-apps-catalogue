// Sent: every email that left, or that will not: sent, replied, bounced,
// failed and cancelled, newest first, by campaign and status. A failed email
// says why in words a person can act on, and its panel fixes it: send it
// again, edit it first, mark it as sent when it did leave, or drop it.
// Replies are marked here by hand (nothing reads the inbox yet). The panel
// shows the email as it left: a broadcast's is drawn from its campaign.
import { V, T, A, MC, badge, act, who, failure, backToList, settings, preview, htmlFrame, kindLabel } from '../data.js';
import { ago } from '../time.js';

const { el } = Orch;
const STATUSES = ['Sent', 'Replied', 'Bounced', 'Failed', 'Cancelled', 'Sending', 'Retry'];
const trouble = (r) => r.status === 'Failed' || r.status === 'Bounced';
const EVENT = { delivered: 'delivered', opened: 'opened', clicked: 'clicked', complained: 'marked as spam', bounced: 'bounced', delivery_delayed: 'delayed' };

export async function render(_params, path) {
  const table = el('div');
  Orch.mount('view', el('div', { class: 'ox-page' }, [
    el('header', { class: 'ox-head' }, [el('div', { class: 'ox-head__text' }, [
      el('h1', { class: 'oc-h1 oc-h1--collection' }, 'Sent'),
      el('p', { class: 'oc-lede' }, 'Every email that went out, and the ones that did not, with why. Open a failed one to send it again, fix it, or drop it.'),
    ])]),
    table,
  ]));
  const campaigns = await Orch.db.view(V.campaigns, { sort: 'name:asc', limit: 200 });
  Orch.pattern('queue', {
    into: table, path: '/sent', query: path, view: V.sent, sort: 'at:desc', pageSize: 50,
    empty: 'Nothing here yet.',
    search: ['name', 'organization', 'email', 'subject'], searchLabel: 'Search', searchPlaceholder: 'Name, organisation, address or subject',
    filters: [
      { key: 'campaign_id', label: 'Campaign', all: 'All campaigns', options: (campaigns.rows || []).map((k) => ({ value: String(k._id), label: k.name })) },
      { key: 'status', label: 'Status', all: 'Any status', options: STATUSES.map((x) => ({ value: x, label: x === 'Retry' ? 'Sending again' : x })) },
    ],
    columns: [
      // A plain first column: the table makes it the link that opens the email.
      { key: 'name', label: 'To', format: (v, r) => who(r) },
      { key: 'subject', label: 'Subject', clamp: true },
      { key: 'campaign', label: 'Campaign' },
      { key: 'status', label: 'Status', render: (r) => el('span', {}, [badge(r.status),
        trouble(r) ? el('span', { class: 'oc-small oc-muted' }, ` ${failure(r).short}`)
          : r.unsubscribed === 'yes' ? el('span', { class: 'oc-small oc-muted' }, ' unsubscribed')
            : EVENT[r.last_event] && r.last_event !== 'delivered' ? el('span', { class: 'oc-small oc-muted' }, ` ${EVENT[r.last_event]}`) : null]) },
      { key: 'at', label: 'When', format: (v) => ago(v) },
    ],
    bulk: [
      { label: 'Send again', action: A.retry, confirm: 'Send {n} failed emails again? All of them must be failed ones.', done: '{n} back in line' },
      { label: 'Mark as replied', action: A.markReplied, confirm: 'Mark {n} as replied?', done: '{n} marked as replied' },
      { label: 'Drop', action: A.drop, danger: true, confirm: 'Drop {n} failed emails? They are not sent, and they stop showing as failed. All must be failed ones.', done: '{n} dropped' },
    ],
    detail: { title: 'The email', table: T.sends, render: panel },
  });
}

/** One email: what happened, the way out when it failed, and the email as it left. */
export function panel(row) {
  const f = trouble(row) ? failure(row) : null;
  const facts = [
    ['To', `${who(row)} <${row.email}>`], ['From', row.from_address], ['Subject', row.subject], ['Status', row.status === 'Retry' ? 'Sending again' : row.status],
    ['Sent', row.sent_at && ago(row.sent_at)], ['Resend says', EVENT[row.last_event] || row.last_event], ['Unsubscribed', row.unsubscribed_at && ago(row.unsubscribed_at)],
    ['Replied', row.replied_at && ago(row.replied_at)], ['Reply', row.reply_status], ['Follow up', row.followup_due_at], ['Notes', row.notes],
  ].filter(([, v]) => v !== null && v !== undefined && String(v).trim() !== '');
  const mail = el('div', {}, el('p', { class: 'oc-muted' }, 'Loading the email…'));
  showMail(mail, row);
  return el('div', { class: 'oc-stack' }, [
    f ? el('div', { class: `ox-note ${row.status === 'Failed' ? 'ox-note--bad' : 'ox-note--warn'}` }, [
      el('p', { class: 'ox-note__title' }, f.short), el('p', {}, f.long),
      f.raw && f.raw !== f.short ? el('p', { class: 'oc-small oc-muted' }, `What was recorded: ${f.raw}`) : null,
    ]) : null,
    row.status === 'Failed' ? fixes(row, f) : null,
    el('dl', { class: 'oc-dl' }, facts.map(([k, v]) => el('div', { class: 'oc-dl__row' }, [el('dt', k), el('dd', String(v))]))),
    mail,
    row.status === 'Sent' ? el('div', { class: 'ox-actions' }, [
      el('button', { class: 'oc-btn', type: 'button', onClick: () => then(A.markReplied, { ids: [row._id] }, 'Marked as replied.') }, 'Mark as replied'),
    ]) : null,
  ]);
}

/** The email as it left: its own text, or its campaign's written for this contact. */
export async function showMail(host, row) {
  try {
    const [k, c, s] = await Promise.all([
      row.campaign_id ? Orch.db.get(T.campaigns, row.campaign_id).catch(() => null) : null,
      row.contact_id ? Orch.db.get(T.contacts, row.contact_id).catch(() => null) : null,
      settings(),
    ]);
    const e = preview({ ...(k || {}), subject: row.subject || (k && k.subject), body: row.body != null ? row.body : (k && k.body) || '' }, s, c || { name: row.name, email: row.email });
    Orch.mount(host, [
      k ? el('p', { class: 'oc-small oc-muted' }, `${kindLabel(k.kind)} · ${MC.FORMAT_LABEL[k.format] || 'Plain text'}`) : null,
      e.html ? htmlFrame(e.html) : el('pre', { class: 'ox-mail' }, e.text || 'This email has no text.'),
    ]);
  } catch (err) {
    Orch.mount(host, el('pre', { class: 'ox-mail' }, row.body || 'This email has no text.'));
  }
}

function fixes(row, f) {
  const mayHaveLeft = f.short === 'It may have gone out';
  const again = async () => {
    const k = row.campaign_id ? await Orch.db.get(T.campaigns, row.campaign_id).catch(() => null) : null;
    // A broadcast's failed email goes out on its own (Retry), even when the broadcast has finished.
    return k && k.kind === 'broadcast' ? A.retryBroadcast : A.retry;
  };
  const markSent = el('button', { class: 'oc-btn', type: 'button', onClick: async () => {
    if (!(await Orch.confirm('Mark it as sent? Only if it is in your Sent folder or in Resend: it will not be sent again.', { yes: 'It went out' }))) return;
    then(A.markSent, { ids: [row._id] }, 'Marked as sent.');
  } }, 'It went out: mark as sent');
  return el('div', { class: 'ox-actions' }, [
    el('button', { class: 'oc-btn oc-btn--primary', type: 'button', onClick: async () => then(await again(), { ids: [row._id] }, 'Back in line: it leaves at the next turn.') }, 'Send it again'),
    el('button', { class: 'oc-btn', type: 'button', onClick: () => editThenSend(row, again) }, 'Edit, then send'),
    // Only when it may have left: otherwise it plainly did not.
    mayHaveLeft ? markSent : null,
    el('button', { class: 'oc-btn oc-btn--ghost', type: 'button', onClick: async () => {
      if (!(await Orch.confirm('Drop this email? It is not sent, and it stops showing as failed.', { yes: 'Drop it' }))) return;
      then(A.drop, { ids: [row._id] }, 'Dropped.');
    } }, 'Drop it'),
  ]);
}

async function then(name, params, msg) {
  if (await act(name, params, msg)) backToList();
}

async function editThenSend(row, again) {
  const field = (label, control) => el('label', { class: 'oc-field' }, [el('span', { class: 'oc-label' }, label), control]);
  // A broadcast's email has no text of its own: start from the campaign's, written for this contact.
  let text = row.body;
  if (text == null) {
    const [k, c] = await Promise.all([Orch.db.get(T.campaigns, row.campaign_id).catch(() => null), Orch.db.get(T.contacts, row.contact_id).catch(() => null)]);
    text = k ? MC.render(k.body || '', c || { name: row.name, email: row.email }, { keep: ['unsubscribe_url'], html: k.format === 'html' }).text : '';
  }
  const body = el('textarea', { class: 'oc-textarea', name: 'body', rows: '12' });
  body.value = text || '';
  const form = el('form', { class: 'ox-form' }, [
    field('To', el('input', { class: 'oc-input', name: 'email', type: 'email', required: true, value: row.email || '' })),
    field('Subject', el('input', { class: 'oc-input', name: 'subject', required: true, maxlength: '300', value: row.subject || '' })),
    field('Text', body),
    el('p', { class: 'oc-help' }, 'This changes this email only. To fix the contact for later campaigns, edit it in Contacts.'),
    el('div', { class: 'ox-actions' }, [el('button', { class: 'oc-btn oc-btn--primary', type: 'submit' }, 'Save and send again')]),
  ]);
  const dlg = Orch.dialog(form, { title: 'Edit, then send again' });
  Orch.onSubmit(form, async (d) => {
    const saved = await act(A.editFailed, { id: row._id, email: String(d.email).trim().toLowerCase(), subject: String(d.subject).trim(), body: String(d.body) });
    if (!saved) return null;
    dlg.close();
    return then(await again(), { ids: [row._id] }, 'Saved and back in line.');
  });
}
