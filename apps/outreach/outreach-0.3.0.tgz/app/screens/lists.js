// Lists: the groups contacts are in, like Sendy's lists, with how healthy each
// one is — how many can be written to, how many unsubscribed, how many
// bounced or marked it as spam. A contact can be in several; unsubscribing is
// from everything. A list is filled by ticking contacts, by an import, or from
// a campaign's report. A campaign goes to lists and audiences.
import { V, A, act, settings, list, plural } from '../data.js';
import { remember } from './contact-form.js';

const { el, router, fmt } = Orch;

export async function render() {
  Orch.load('view', async () => {
    const [res, s] = await Promise.all([Orch.db.view(V.lists, { sort: 'name:asc', limit: 500 }), settings()]);
    const rows = res.rows || [];
    const pctOf = (n, of) => (of ? `${Math.round((100 * n) / of)}%` : '—');
    return el('div', { class: 'ox-page' }, [
      el('header', { class: 'ox-head' }, [
        el('div', { class: 'ox-head__text' }, [
          el('h1', { class: 'oc-h1 oc-h1--collection' }, 'Lists'),
          el('p', { class: 'oc-lede' }, 'Groups of contacts a campaign can go to. A contact can be in several; an unsubscribe is from all of them.'),
        ]),
        el('div', { class: 'ox-actions' }, [
          router.link('/contacts/import', 'Import into a list', { class: 'oc-btn' }),
          el('button', { class: 'oc-btn oc-btn--primary', type: 'button', onClick: () => newList(s) }, 'New list'),
        ]),
      ]),
      rows.length ? el('div', { class: 'ox-table-wrap' }, el('table', { class: 'oc-table ox-lists' }, [
        el('thead', {}, el('tr', {}, ['List', 'Can be emailed', 'Unsubscribed', 'Bounced or spam', 'In it', ''].map((h, i) => el('th', { class: i && i < 5 ? 'oc-num' : null, scope: 'col' }, h)))),
        el('tbody', {}, rows.map((l) => el('tr', {}, [
          el('td', {}, router.link(`/contacts?tags=${encodeURIComponent(`|${l.name}|`)}`, l.name)),
          el('td', { class: 'oc-num' }, fmt.number(l.reachable)),
          el('td', { class: 'oc-num' }, l.unsubscribed ? `${fmt.number(l.unsubscribed)} · ${pctOf(l.unsubscribed, l.total)}` : '0'),
          el('td', { class: 'oc-num' }, l.bounced ? `${fmt.number(l.bounced)} · ${pctOf(l.bounced, l.total)}` : '0'),
          el('td', { class: 'oc-num' }, fmt.number(l.total)),
          el('td', { class: 'ox-row-actions' }, [
            router.link(`/contacts/import?list=${encodeURIComponent(l.name)}`, 'Import', { class: 'oc-btn oc-btn--sm oc-btn--ghost' }),
            l.total ? null : el('button', { class: 'oc-btn oc-btn--sm oc-btn--ghost', type: 'button', onClick: () => removeList(s, l.name) }, 'Remove'),
          ]),
        ]))),
      ])) : el('p', { class: 'oc-state' }, 'No list yet. Make one, import a file into one, or tick contacts and add them to one.'),
      el('p', { class: 'oc-help' }, `${plural(rows.length, 'list', 'lists')}. “Can be emailed” is Active with an address; the rest of “In it” have no address yet or are blocked. A new campaign picks its lists in its second step.`),
    ]);
  });
}

function newList(s) {
  const name = el('input', { class: 'oc-input', name: 'name', required: true, maxlength: '80', placeholder: 'Newsletter' });
  const form = el('form', { class: 'ox-form' }, [
    el('label', { class: 'oc-field' }, [el('span', { class: 'oc-label' }, 'Name'), name]),
    el('p', { class: 'oc-help' }, 'It starts empty: import a file into it, or tick contacts and add them.'),
    el('div', { class: 'ox-actions' }, [el('button', { class: 'oc-btn oc-btn--primary', type: 'submit' }, 'Make the list')]),
  ]);
  const dlg = Orch.dialog(form, { title: 'New list' });
  Orch.onSubmit(form, async (d) => {
    const n = String(d.name || '').replace(/\|/g, '/').trim();
    if (!n) return;
    if (list(s && s.tags).includes(n)) { Orch.toast('There is a list with that name.', { error: true }); return; }
    await remember([n]);
    Orch.toast(`“${n}” made.`);
    dlg.close();
    render();
  });
}

async function removeList(s, name) {
  if (!(await Orch.confirm(`Remove “${name}”? Nobody is in it.`, { yes: 'Remove' }))) return;
  const fresh = await settings();
  const next = list(fresh && fresh.tags).filter((x) => x !== name);
  if (await act(A.updateSettings, { id: fresh._id, tags: JSON.stringify(next) }, 'Removed.')) render();
}
