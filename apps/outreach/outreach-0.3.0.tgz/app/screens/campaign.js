// One campaign. A draft is edited in two steps, like Sendy: the email
// (/campaigns/:id/email), then who gets it and sending it (/recipients).
// Anything else shows how far it got, the one control its state allows, and
// its report: every number opens the people behind it (/campaigns/:id/<who>),
// who can join a list or be exported. A paused sequence can be edited too.
import { V, T, A, MC, badge, kindLabel, modeLabel, act, settings, preview, htmlFrame, senderOf, confirmTwice, downloadCsv, plural } from '../data.js';
import { ago, pct, localClock } from '../time.js';
import { compose } from './compose.js';
import { sendTo } from './send-to.js';
import { panel as emailPanel } from './sent.js';

const { el, router, fmt } = Orch;

// The numbers of a report, and the emails each one stands for (sent view).
const METRICS = {
  all: { label: 'Recipients', filter: {} },
  sent: { label: 'Sent', filter: { status: ['Sent', 'Replied', 'Bounced'] } },
  delivered: { label: 'Delivered', filter: { delivered: 'yes' }, tracked: true },
  opened: { label: 'Opened', filter: { opened: 'yes' }, tracked: true },
  not_opened: { label: 'Not opened', filter: { not_opened: 'yes' }, tracked: true },
  clicked: { label: 'Clicked', filter: { clicked: 'yes' }, tracked: true },
  replied: { label: 'Replied', filter: { status: 'Replied' } },
  not_replied: { label: 'No reply yet', filter: { status: 'Sent' } },
  unsubscribed: { label: 'Unsubscribed', filter: { unsubscribed: 'yes' } },
  bounced: { label: 'Bounced', filter: { bounced: 'yes' } },
  complained: { label: 'Marked as spam', filter: { complained: 'yes' } },
  failed: { label: 'Failed', filter: { status: 'Failed' } },
};
const STEPS = ['email', 'recipients'];

export function render({ id, who }, path) {
  Orch.load('view', async () => {
    const [res, full, s] = await Promise.all([Orch.db.view(V.campaigns, { filter: { _id: id }, limit: 1 }),
      Orch.db.get(T.campaigns, id).catch(() => null), settings()]);
    const row = (res.rows || [])[0];
    if (!row || !full) return el('div', { class: 'oc-state' }, [el('p', 'This campaign does not exist.'), router.link('/', 'All campaigns')]);
    // The view's counts and dates, with the row's own text (the view leaves the body out).
    const k = { ...full, ...row, body: full.body || '' };
    const editable = k.status === 'Draft' || (k.kind === 'sequence' && k.status === 'Paused');
    if (editable && (STEPS.includes(who) || (k.status === 'Draft' && !who))) {
      return editor(k, s, STEPS.includes(who) ? who : 'email');
    }
    return overview(k, s, METRICS[who] ? who : null, path);
  });
}

/** The two steps of a draft, one header. */
function editor(k, s, step) {
  const body = el('div');
  const tabs = el('nav', { class: 'ox-steps', 'aria-label': 'Steps' }, [
    router.link(`/campaigns/${k._id}/email`, ['1', el('span', 'The email')], { class: 'ox-step', 'aria-current': step === 'email' ? 'step' : 'false', 'data-step': 'email' }),
    router.link(`/campaigns/${k._id}/recipients`, ['2', el('span', k.kind === 'broadcast' ? 'Recipients and send' : 'Recipients and start')],
      { class: 'ox-step', 'aria-current': step === 'recipients' ? 'step' : 'false', 'data-step': 'recipients' }),
  ]);
  const page = el('div', { class: 'ox-page' }, [
    el('header', { class: 'ox-head' }, [
      el('div', { class: 'ox-head__text' }, [
        router.link(k.status === 'Draft' ? '/' : `/campaigns/${k._id}`, k.status === 'Draft' ? '← Campaigns' : '← The campaign', { class: 'ox-crumb' }),
        el('h1', { class: 'oc-h1' }, k.name || 'Untitled'),
        el('p', { class: 'oc-small oc-muted' }, `${kindLabel(k.kind)} · ${k.status === 'Draft' ? 'draft' : 'paused: changes apply to the emails it writes from now on'}`),
      ]),
      el('div', { class: 'ox-actions' }, [
        el('button', { class: 'oc-btn oc-btn--ghost', type: 'button', onClick: () => duplicate(k) }, 'Duplicate'),
        badge(k.status),
      ]),
    ]),
    tabs,
    body,
  ]);
  if (step === 'email') compose(body, k, s, tabs);
  else sendTo(body, k, s);
  return page;
}

/** How far it got, its control, and its report. */
function overview(k, s, who, path) {
  const reload = () => render({ id: k._id, who: who || undefined }, path);
  const sender = senderOf(k, s);
  const fact = (label, value, sub) => el('div', { class: 'ox-fact' }, [
    el('p', { class: 'oc-label' }, label), el('p', {}, value), sub ? el('p', { class: 'oc-small oc-muted' }, sub) : null,
  ]);
  const people = el('div');
  const page = el('div', { class: 'ox-page' }, [
    el('header', { class: 'ox-head' }, [
      el('div', { class: 'ox-head__text' }, [
        router.link('/', '← Campaigns', { class: 'ox-crumb' }),
        el('h1', { class: 'oc-h1' }, k.name || 'Untitled'),
        el('p', { class: 'oc-small oc-muted' }, stateLine(k)),
      ]),
      el('div', { class: 'ox-actions' }, [...controls(k, s, reload), badge(k.status)]),
    ]),
    k.problem ? el('p', { class: 'ox-note ox-note--bad' }, k.problem) : null,
    k.note ? el('p', { class: 'ox-note' }, k.note) : null,
    progressBar(k),
    el('div', { class: 'ox-facts' }, [
      fact('Recipients', recipientsText(k), k.kind === 'broadcast' ? null : `${modeLabel(k.mode)}${Number(k.skip_contacted) ? ' · skips the contacted' : ''}`),
      fact('The email', el('button', { class: 'ox-linkish', type: 'button', onClick: () => readIt(k, s) }, k.subject || '(no subject)'), MC.FORMAT_LABEL[k.format] || 'Plain text'),
      fact('From', sender.text || '—', sender.reply ? `Replies to ${sender.reply}` : null),
      fact(k.kind === 'broadcast' ? 'Sent' : 'Started', dates(k)),
    ]),
    numbers(k, who),
    trackingHelp(k),
    people,
  ]);
  if (who) whoList(people, k, who, path);
  // A broadcast on its way: the numbers move, so look again every few seconds.
  if (k.kind === 'broadcast' && (k.status === 'Sending' || (k.status === 'Scheduled' && new Date(`${String(k.scheduled_at).replace(' ', 'T')}Z`) <= new Date()))) {
    const at = location.hash;
    setTimeout(() => { if (location.hash === at && !document.querySelector('dialog[open]')) reload(); }, 5000);
  }
  return page;
}

function stateLine(k) {
  const kind = kindLabel(k.kind);
  if (k.kind === 'broadcast') {
    if (k.status === 'Scheduled') return `${kind} · goes out ${localClock(k.scheduled_at)}; counted again then`;
    if (k.status === 'Sending') return `${kind} · sending now, in batches of 100`;
    if (k.status === 'Paused') return `${kind} · paused: nothing more leaves until you resume it`;
    if (k.status === 'Sent') return `${kind} · sent ${k.finished_at ? ago(k.finished_at) : ''}`;
  }
  if (k.status === 'Active') return `${kind} · active: new contacts who join its recipients get their email within half an hour`;
  if (k.status === 'Paused') return `${kind} · paused: nothing of it goes out, and nobody new is written to`;
  if (k.status === 'Finished') return `${kind} · finished: it writes and sends nothing more`;
  return kind;
}

function dates(k) {
  if (k.kind === 'broadcast') {
    if (k.finished_at) return ago(k.finished_at);
    if (k.started_at) return `Started ${ago(k.started_at)}`;
    if (k.scheduled_at) return `Goes out ${localClock(k.scheduled_at)}`;
    return 'Not yet';
  }
  return k.activated_at ? ago(k.activated_at) : 'Not yet';
}

/** "Newsletter, Broadcast test · leaving out Customers", audiences by name once read. */
function recipientsText(k) {
  const r = MC.parseRecipients(k) || { lists: [], audiences: [], exclude_lists: [], exclude_audiences: [] };
  const say = (lists, auds, name) => [...lists, ...auds.map((a) => (name ? name(a) : `audience #${a}`))].join(', ');
  const holder = el('span', {});
  const paint = (name) => {
    const inc = say(r.lists, r.audiences, name);
    const exc = say(r.exclude_lists, r.exclude_audiences, name);
    Orch.mount(holder, [inc || 'None yet', exc ? el('span', { class: 'oc-small oc-muted' }, [el('br'), `Leaving out ${exc}`]) : null]);
  };
  paint(null);
  const ids = [...r.audiences, ...r.exclude_audiences];
  if (ids.length) Orch.db.lookup(T.audiences, ids).then((m) => paint((id) => (m[id] && m[id].name) || `#${id}`)).catch(() => {});
  return holder;
}

function progressBar(k) {
  if (k.kind !== 'broadcast' || !['Sending', 'Paused'].includes(k.status) || !k.total) return null;
  const done = Number(k.sent) + Number(k.failed) + Number(k.cancelled);
  return el('div', { class: 'ox-progress' }, [
    el('div', { class: 'ox-progress__bar', role: 'progressbar', 'aria-valuemin': '0', 'aria-valuemax': String(k.total), 'aria-valuenow': String(done) },
      el('span', { style: `width:${Math.min(100, Math.round((100 * done) / k.total))}%` })),
    el('p', { class: 'oc-small oc-muted' }, `${fmt.number(k.sent)} of ${fmt.number(k.total)} sent${k.failed ? `, ${fmt.number(k.failed)} failed` : ''}${k.queued ? ` · ${fmt.number(k.queued)} to go` : ''}`),
  ]);
}

/** The controls a state allows. Finishing asks twice and names what it costs. */
function controls(k, s, reload) {
  const btn = (label, onClick, kind) => el('button', { class: `oc-btn${kind ? ` oc-btn--${kind}` : ''}`, type: 'button', onClick }, label);
  const run = async (name, done) => { if (await act(name, { id: k._id }, done)) reload(); };
  const out = [];
  if (k.kind === 'broadcast') {
    if (k.status === 'Scheduled') out.push(btn('Cancel the schedule', async () => {
      if (await Orch.confirm('Cancel the schedule? It goes back to being a draft, and nothing is sent.', { yes: 'Cancel it' })) run(A.unscheduleBroadcast, 'Back to draft.');
    }));
    if (k.status === 'Sending') out.push(btn('Pause', () => run(A.pauseBroadcast, 'Paused: the batch in flight finishes, then it stops.')));
    if (k.status === 'Paused') {
      out.push(btn('Resume', () => run(A.resumeBroadcast, 'Resumed: it carries on within a minute.'), 'primary'));
      out.push(btn('Finish…', async () => {
        const waiting = Number(k.queued) || 0;
        const yes = await confirmTwice({
          title: `Finish “${k.name}”?`, text: 'A finished broadcast sends nothing more and cannot be resumed.',
          ack: waiting ? `Yes, finish it, and never send the ${plural(waiting, 'email', 'emails')} still waiting` : 'Yes, finish it', yes: 'Finish it',
        });
        if (yes) run(A.finishBroadcast, 'Finished.');
      }, 'ghost'));
    }
  } else {
    if (k.status === 'Active') out.push(btn('Pause', () => run(A.pauseCampaign, 'Paused.')));
    if (k.status === 'Paused') {
      out.push(router.link(`/campaigns/${k._id}/email`, 'Edit', { class: 'oc-btn' }));
      out.push(btn('Resume', () => run(A.resumeCampaign, 'Resumed.'), 'primary'));
    }
    if (k.status === 'Active' || k.status === 'Paused') out.push(btn('Finish…', async () => {
      const waiting = (Number(k.queued) || 0) + (Number(k.in_review) || 0);
      const yes = await confirmTwice({
        title: `Finish “${k.name}”?`, text: 'A finished sequence writes and sends nothing more, and cannot be started again.',
        ack: waiting ? `Yes, finish it, and cancel the ${plural(waiting, 'email', 'emails')} still waiting to go out` : 'Yes, finish it', yes: 'Finish it',
      });
      if (yes) run(A.finishCampaign, 'Finished.');
    }, 'ghost'));
  }
  out.push(btn('Duplicate', () => duplicate(k), 'ghost'));
  return out;
}

/** The report: each number opens the emails behind it. */
function numbers(k, who) {
  const tracked = Number(k.delivered) + Number(k.opened) + Number(k.clicked) > 0;
  const n = {
    all: k.kind === 'broadcast' ? Number(k.total) || 0 : Number(k.sent) + Number(k.failed) + Number(k.cancelled),
    sent: k.sent, delivered: k.delivered, opened: k.opened, clicked: k.clicked, replied: k.replied,
    not_opened: Math.max(0, Number(k.sent) - Number(k.opened) - Number(k.bounced) - Number(k.complained)),
    not_replied: Math.max(0, Number(k.sent) - Number(k.replied) - Number(k.bounced)),
    unsubscribed: k.unsubscribed, bounced: k.bounced, complained: k.complained, failed: k.failed,
  };
  const keys = k.kind === 'broadcast'
    ? ['all', 'sent', ...(tracked ? ['delivered', 'opened', 'not_opened', 'clicked'] : []), 'replied', 'unsubscribed', 'bounced', 'complained', 'failed']
    : ['sent', ...(tracked ? ['opened', 'clicked'] : []), 'replied', 'not_replied', 'unsubscribed', 'bounced', 'failed'];
  const cell = (key) => {
    const value = Number(n[key]) || 0;
    const share = key !== 'all' && key !== 'sent' && Number(k.sent) ? pct(value, k.sent) : null;
    return router.link(who === key ? `/campaigns/${k._id}` : `/campaigns/${k._id}/${key}`, [
      el('span', { class: 'oc-label' }, METRICS[key].label),
      el('span', { class: 'ox-num' }, fmt.number(value)),
      share ? el('span', { class: 'oc-small oc-muted' }, share) : null,
    ], { class: 'ox-metric', 'aria-current': who === key ? 'true' : 'false' });
  };
  const extra = k.kind === 'sequence' ? [
    router.link(`/review?campaign_id=${k._id}`, [el('span', { class: 'oc-label' }, 'To review'), el('span', { class: 'ox-num' }, fmt.number(k.in_review))], { class: 'ox-metric' }),
    router.link(`/queue?campaign_id=${k._id}`, [el('span', { class: 'oc-label' }, 'Going out'), el('span', { class: 'ox-num' }, fmt.number(k.queued))], { class: 'ox-metric' }),
  ] : [];
  return el('nav', { class: 'ox-metrics', 'aria-label': 'Report' }, [...extra, ...keys.map(cell)]);
}

function trackingHelp(k) {
  if (!Number(k.sent) || Number(k.delivered) + Number(k.opened) + Number(k.clicked) > 0) return null;
  return el('p', { class: 'oc-help' }, 'Deliveries, opens and clicks show here once Resend reports them: Outreach asks 1, 24 and 72 hours after a broadcast starts (a sequence email: 30 minutes, 6 hours and 2 days after it leaves). Opens and clicks need open and click tracking turned on for your domain in Resend.');
}

/** The people behind one number: a list, "Add these to a list", Export. */
function whoList(host, k, key, path) {
  const m = METRICS[key];
  const table = el('div');
  const filter = { campaign_id: k._id, ...m.filter };
  Orch.mount(host, el('section', { class: 'ox-section' }, [
    el('div', { class: 'ox-inline ox-inline--between' }, [
      el('h2', { class: 'oc-h2' }, m.label),
      el('div', { class: 'ox-actions' }, [
        el('button', { class: 'oc-btn', type: 'button', onClick: () => toList(k, key, m) }, 'Add these to a list…'),
        el('button', { class: 'oc-btn oc-btn--ghost', type: 'button', onClick: async () => {
          const n = await downloadCsv({ view: V.sent, filter, name: `${k.name} - ${m.label}`,
            columns: ['name', 'organization', 'email', 'status', 'last_event', 'sent_at', 'replied_at', 'unsubscribed_at', 'error'] });
          Orch.toast(`${plural(n, 'row', 'rows')} exported.`);
        } }, 'Export CSV'),
      ]),
    ]),
    table,
  ]));
  Orch.table({
    into: table, view: V.sent, path: `/campaigns/${k._id}/${key}`, query: path, filter, sort: 'at:desc', pageSize: 50,
    search: ['name', 'organization', 'email'], searchPlaceholder: 'Name, organisation or address',
    empty: 'Nobody here.',
    columns: [
      { key: 'name', label: 'To', format: (v, r) => `${r.name || r.email}${r.organization && r.organization !== r.name ? ` · ${r.organization}` : ''}` },
      { key: 'email', label: 'Address' },
      { key: 'status', label: 'Status', render: (r) => el('span', {}, [badge(r.status), r.last_event && r.last_event !== 'delivered' ? el('span', { class: 'oc-small oc-muted' }, ` ${r.last_event}`) : null]) },
      { key: 'at', label: 'When', format: (v) => ago(v) },
    ],
    detail: { title: 'The email', table: T.sends, render: emailPanel },
  });
}

async function toList(k, key, m) {
  const s = await settings();
  const known = s ? JSON.parse(s.tags || '[]') : [];
  const name = el('input', { class: 'oc-input', name: 'list', required: true, maxlength: '80', list: 'ox-known-lists', value: `${k.name} · ${m.label}` });
  const form = el('form', { class: 'ox-form' }, [
    el('p', {}, `The contacts behind “${m.label}” join this list; a new name makes a new list. Nobody leaves another list.`),
    el('label', { class: 'oc-field' }, [el('span', { class: 'oc-label' }, 'List'), name]),
    el('datalist', { id: 'ox-known-lists' }, known.map((x) => el('option', { value: x }))),
    el('div', { class: 'ox-actions' }, [el('button', { class: 'oc-btn oc-btn--primary', type: 'submit' }, 'Add them')]),
  ]);
  const dlg = Orch.dialog(form, { title: 'Add to a list' });
  Orch.onSubmit(form, async (d) => {
    const list = String(d.list || '').replace(/\|/g, '/').trim();
    if (!list) return;
    const which = key === 'all' ? 'all' : key;
    if (await act(A.listFromCampaign, { id: k._id, which, list }, `Adding them to “${list}”: it takes a few seconds.`)) dlg.close();
  });
}

/** The email as a recipient reads it, for one of them. */
async function readIt(k, s) {
  const one = await Orch.db.view(V.sent, { filter: { campaign_id: k._id }, limit: 1 });
  const c = (one.rows || [])[0] ? await Orch.db.get(T.contacts, one.rows[0].contact_id).catch(() => null) : null;
  const e = preview(k, s, c || {});
  Orch.dialog(el('div', { class: 'oc-stack' }, [
    el('p', { class: 'oc-small oc-muted' }, c ? `As ${c.name || c.email} got it` : 'With the fallbacks, as nobody in particular'),
    el('p', {}, e.subject || '(no subject)'),
    e.html ? htmlFrame(e.html) : el('pre', { class: 'ox-mail' }, e.text),
  ]), { title: 'The email' });
}

/** A new draft with the same email, sender and recipients. */
async function duplicate(k) {
  const full = await Orch.db.get(T.campaigns, k._id);
  const params = {
    kind: full.kind || 'sequence', name: `${full.name} (copy)`.slice(0, 120), description: full.description || '',
    subject: full.subject || '', body: full.body || '', format: full.format || 'text',
    from_name: full.from_name || '', from_email: full.from_email || '', reply_to: full.reply_to || '',
    mode: full.mode || 'auto', recipients: full.recipients || '{}',
    skip_contacted: Number(full.skip_contacted ?? (full.kind === 'broadcast' ? 0 : 1)), unsubscribe_link: Number(full.unsubscribe_link || 0),
  };
  if (full.template_id) params.template_id = full.template_id;
  const r = await act(A.createCampaign, params, 'Duplicated: a new draft.');
  if (r) router.go(`/campaigns/${r._id}/email`);
}
