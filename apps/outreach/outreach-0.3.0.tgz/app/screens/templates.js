// Templates: where an email can start. A campaign copies one when it is made
// (or from "Start from a template"), so changing a template never changes a
// campaign. Subject, format and text with variables ({{first_name|there}}: a
// fallback after the bar), previewed for a real contact by the same mailcore
// that sends.
import { V, T, A, MC, act, fields, settings, variables, preview, htmlFrame } from '../data.js';

const { el, router, fmt } = Orch;
const PAGE = 50;

export async function render(params, path) {
  const id = params && params.id;
  const offset = Math.max(0, parseInt(new URLSearchParams(String(path || '').split('?')[1] || '').get('offset'), 10) || 0);
  const side = el('div');
  const main = el('div');
  Orch.mount('view', el('div', { class: 'ox-page' }, [
    el('header', { class: 'ox-head' }, [
      el('div', { class: 'ox-head__text' }, [
        el('h1', { class: 'oc-h1 oc-h1--collection' }, 'Templates'),
        el('p', { class: 'oc-lede' }, 'Where an email can start. A campaign takes a copy: changing a template never changes a campaign.'),
      ]),
      router.link('/templates/new', 'New template', { class: 'oc-btn oc-btn--primary' }),
    ]),
    el('div', { class: 'ox-two' }, [side, main]),
  ]));
  const [res, fs, s] = await Promise.all([Orch.db.view(V.templates, { sort: 'name:asc', limit: PAGE, offset, count: true }), fields(), settings()]);
  const rows = res.rows || [];
  const pager = Orch.pager({ offset, limit: PAGE, total: res.total, hasMore: res.hasMore },
    (next) => router.go(`/templates${id ? `/${id}` : ''}?offset=${next}`));
  Orch.mount(side, rows.length ? [el('ul', { class: 'ox-rows' }, rows.map((t) => el('li', {}, [
    el('div', {}, [
      router.link(`/templates/${t._id}`, t.name, { 'aria-current': String(t._id) === String(id) ? 'true' : 'false' }),
      el('p', { class: 'oc-small oc-muted' }, `${MC.FORMAT_LABEL[t.format] || 'Plain text'}${t.campaigns ? ` · ${fmt.number(t.campaigns)} ${t.campaigns === 1 ? 'campaign' : 'campaigns'} started from it` : ''}`),
    ]),
  ]))), pager] : el('p', { class: 'oc-muted' }, 'No template yet.'));
  if (!id) { Orch.mount(main, el('p', { class: 'oc-muted' }, rows.length ? 'Pick a template to read or change it.' : 'Write the first one.')); return; }
  let current = null;
  if (id !== 'new') {
    current = await Orch.db.get(T.templates, id);
    if (!current || current.archived) { Orch.mount(main, el('p', { class: 'oc-muted' }, 'This template does not exist.')); return; }
  }
  editor(main, current, fs, s);
}

async function editor(host, current, fs, s) {
  const known = [...new Set(['name', 'first_name', 'last_name', 'organization', 'email', 'website', 'country', 'title', 'stage', ...fs.map((f) => f.key), 'unsubscribe_url'])];
  const name = el('input', { class: 'oc-input', required: true, maxlength: '120', value: current ? current.name : '' });
  const subject = el('input', { class: 'oc-input', required: true, maxlength: '300', value: current ? current.subject || '' : '' });
  const body = el('textarea', { class: 'oc-textarea', name: 'body', rows: '16', required: true });
  body.value = current ? current.body || '' : 'Hi {{first_name|there}},\n\n\n\n';
  const format = el('div', { class: 'ox-segment', role: 'radiogroup', 'aria-label': 'Format' }, MC.FORMATS.map((f) => el('label', { class: 'ox-segment__item' }, [
    el('input', { type: 'radio', name: 'tformat', value: f, checked: ((current && current.format) || 'text') === f ? true : null }), el('span', MC.FORMAT_LABEL[f]),
  ])));
  const formatOf = () => (host.querySelector('input[name="tformat"]:checked') || {}).value || 'text';
  let focused = body;
  subject.addEventListener('focus', () => { focused = subject; });
  body.addEventListener('focus', () => { focused = body; });
  const insert = (v) => {
    const f = focused;
    const at = f.selectionStart ?? f.value.length;
    f.value = `${f.value.slice(0, at)}{{${v}}}${f.value.slice(f.selectionEnd ?? at)}`;
    f.focus();
    f.selectionStart = f.selectionEnd = at + v.length + 4;
    draw();
  };
  const people = (await Orch.db.list(T.contacts, { filter: { email: { notnull: '1' } }, sort: 'name:asc', limit: 30 })).rows || [];
  const who = el('select', { class: 'oc-select', 'aria-label': 'Preview it for' }, people.map((c, i) => el('option', { value: String(i) }, `${c.name || c.email}${c.organization ? ` · ${c.organization}` : ''}`)));
  const pv = el('div');
  const draw = () => {
    const unknown = [...new Set([...variables(subject.value), ...variables(body.value)])].filter((v) => !known.includes(v));
    const c = people[Number(who.value) || 0] || {};
    const e = preview({ subject: subject.value, body: body.value, format: formatOf(), unsubscribe_link: 1 }, s, c);
    Orch.mount(pv, [
      unknown.length ? el('p', { class: 'ox-note ox-note--bad' }, `${unknown.map((v) => `{{${v}}}`).join(', ')}: not a contact field. A campaign with it stops until it is fixed.`) : null,
      c.email && e.missing.length ? el('p', { class: 'ox-note ox-note--warn' }, `${c.name || 'This contact'} has no ${e.missing.join(', ')}: they would be left out. Add a fallback, like {{${e.missing[0]}|…}}.`) : null,
      el('p', { class: 'oc-small oc-muted' }, c.email ? `To ${c.email}` : 'No contact with an email to preview it with.'),
      el('p', {}, e.subject || '(no subject)'),
      e.html ? htmlFrame(e.html, 'Preview') : el('pre', { class: 'ox-mail' }, e.text),
    ]);
  };
  [subject, body].forEach((x) => x.addEventListener('input', draw));
  format.addEventListener('change', draw);
  who.addEventListener('change', draw);
  draw();

  const save = async () => {
    if (!name.value.trim() || !subject.value.trim() || !body.value.trim()) { Orch.toast('A template needs a name, a subject and a text.', { error: true }); return; }
    const data = { name: name.value.trim(), subject: subject.value.trim(), body: body.value, format: formatOf() };
    const r = await act(current ? A.updateTemplate : A.createTemplate, current ? { id: current._id, ...data } : data, 'Saved.');
    if (r) router.go(`/templates/${current ? current._id : r._id}`);
  };
  Orch.mount(host, el('div', { class: 'ox-form' }, [
    el('label', { class: 'oc-field' }, [el('span', { class: 'oc-label' }, 'Name'), name]),
    el('label', { class: 'oc-field' }, [el('span', { class: 'oc-label' }, 'Subject'), subject]),
    el('div', { class: 'oc-field' }, [el('span', { class: 'oc-label' }, 'Format'), format]),
    el('label', { class: 'oc-field' }, [el('span', { class: 'oc-label' }, 'Text'), body]),
    el('div', { class: 'oc-stack oc-stack--tight' }, [
      el('span', { class: 'oc-label' }, 'Variables: click to insert. After a bar, what to write when a contact has none'),
      el('div', { class: 'ox-vars' }, known.map((v) => el('button', { class: 'oc-btn oc-btn--sm ox-var', type: 'button', onClick: () => insert(v) }, `{{${v}}}`))),
    ]),
    el('div', { class: 'ox-actions' }, [
      el('button', { class: 'oc-btn oc-btn--primary', type: 'button', onClick: save }, current ? 'Save changes' : 'Create the template'),
      current ? el('button', { class: 'oc-btn oc-btn--ghost', type: 'button', onClick: async () => {
        if (!(await Orch.confirm(`Remove “${current.name}”? Campaigns made from it keep their own copy.`, { yes: 'Remove', danger: true }))) return;
        if (await act(A.archiveTemplate, { id: current._id }, 'Removed.')) router.go('/templates');
      } }, 'Remove') : null,
    ]),
    el('div', { class: 'ox-section' }, [
      el('div', { class: 'ox-inline' }, [el('h2', { class: 'oc-h3' }, 'Preview for'), who]),
      pv,
    ]),
  ]));
}
