/**
 * What an email looks like, in one place: variables, the three formats, the
 * footer with the unsubscribe link, and how a campaign names its recipients.
 * Pure functions, no database. The automations require() it; the app loads the
 * identical copy in app/mailcore.js (a test fails if the two differ), so the
 * preview on screen is exactly what goes out.
 *
 * Formats:
 *   text    the text as written, plus the footer lines.
 *   simple  the text in a light, minimal layout (paragraphs, links), plus a
 *           plain-text part.
 *   html    the person's own HTML; values are escaped into it, the footer is
 *           added before </body> unless it already has {{unsubscribe_url}}.
 */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.OutreachMail = api;
}(typeof self !== 'undefined' ? self : this, () => {
  'use strict';

  const FORMATS = ['text', 'simple', 'html'];
  const FORMAT_LABEL = { text: 'Plain text', simple: 'Simple layout', html: 'Custom HTML' };
  const STATUSES = ['Active', 'Unsubscribed', 'Bounced', 'Complained', 'Blocked'];
  const STATUS_LABEL = { Active: 'Active', Unsubscribed: 'Unsubscribed', Bounced: 'Bounced', Complained: 'Marked as spam', Blocked: 'Blocked' };
  // Variables that are not contact columns.
  const SPECIAL = ['first_name', 'last_name', 'unsubscribe_url'];

  const EMAIL = /^[^\s@<>(),;:"]+@[^\s@<>(),;:"]+\.[a-z]{2,}$/i;
  const normEmail = (e) => String(e == null ? '' : e).trim().toLowerCase();
  const statusOf = (c) => (c && STATUSES.includes(c.status) ? c.status : 'Active');

  // ── variables ──────────────────────────────────────────────────────────
  const VAR = /\{\{\s*([A-Za-z_][A-Za-z0-9_]*)\s*(?:\|([^}]*))?\}\}/g;
  function variables(text) {
    const out = [];
    for (const m of String(text || '').matchAll(VAR)) out.push(m[1]);
    return out;
  }
  function valueOf(contact, key, vars) {
    if (vars && Object.prototype.hasOwnProperty.call(vars, key)) return vars[key] == null ? '' : String(vars[key]);
    const name = String((contact && contact.name) || '').trim();
    if (key === 'first_name') return name.split(/\s+/)[0] || '';
    if (key === 'last_name') return name.split(/\s+/).slice(1).join(' ');
    const v = contact ? contact[key] : undefined;
    return v === null || v === undefined ? '' : String(v).trim();
  }
  /**
   * {{first_name|there}}: the value, else the fallback after the bar. A value
   * missing with no fallback is reported, never sent as a hole. `html` escapes
   * the values (not the template); `keep` leaves those variables as written.
   */
  function render(text, contact, opts) {
    const o = opts || {};
    const missing = [];
    const out = String(text || '').replace(VAR, (m, key, fallback) => {
      if (o.keep && o.keep.includes(key)) return m;
      const v = valueOf(contact, key, o.vars);
      if (v) return o.html ? esc(v) : v;
      if (fallback !== undefined) return o.html ? esc(fallback.trim()) : fallback.trim();
      missing.push(key);
      return '';
    });
    return { text: out, missing };
  }
  /** Names a template may use: the contact's columns and the special ones. */
  function knownVariables(columns) {
    return [...new Set([...(columns || []).filter((c) => !String(c).startsWith('_')), ...SPECIAL])];
  }

  // ── html ───────────────────────────────────────────────────────────────
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const URL_RE = /\bhttps?:\/\/[^\s<>"']+/g;
  function linkify(escaped) {
    return escaped.replace(URL_RE, (u) => {
      const trail = (u.match(/[.,;:!?)\]]+$/) || [''])[0];
      const href = trail ? u.slice(0, -trail.length) : u;
      return `<a href="${href}" style="color:#1a4fa3">${href}</a>${trail}`;
    });
  }
  /** Plain text to paragraphs: a blank line starts one, a single line break stays. */
  function textToHtml(text) {
    return String(text || '').replace(/\r\n/g, '\n').trim().split(/\n{2,}/)
      .map((b) => `<p style="margin:0 0 16px">${linkify(esc(b)).replace(/\n/g, '<br>')}</p>`).join('\n');
  }
  const ENT = { amp: '&', lt: '<', gt: '>', quot: '"', '#39': "'", apos: "'", nbsp: ' ' };
  const decode = (s) => s.replace(/&(amp|lt|gt|quot|#39|apos|nbsp);/g, (m, k) => ENT[k]).replace(/&#(\d+);/g, (m, n) => String.fromCharCode(Number(n)));
  /** The plain-text part of an HTML email: links kept as "text (url)". */
  function htmlToText(html) {
    let s = String(html || '');
    s = s.replace(/<(script|style|head|title)[\s\S]*?<\/\1>/gi, '');
    s = s.replace(/<a\s[^>]*href=["']([^"']+)["'][^>]*>([\s\S]*?)<\/a>/gi, (m, href, inner) => {
      const t = decode(inner.replace(/<[^>]+>/g, '')).trim();
      const h = decode(href);
      return t && t !== h ? `${t} (${h})` : h;
    });
    s = s.replace(/<br\s*\/?>/gi, '\n').replace(/<li[^>]*>/gi, '- ')
      .replace(/<\/(p|div|h[1-6]|li|tr|table|blockquote|section)>/gi, '\n\n').replace(/<[^>]+>/g, '');
    return decode(s).replace(/[ \t]+\n/g, '\n').replace(/\n[ \t]+/g, '\n').replace(/\n{3,}/g, '\n\n').trim();
  }

  const FONT = "-apple-system,BlinkMacSystemFont,'Segoe UI',Helvetica,Arial,sans-serif";
  /** The simple layout: light, one column, the footer small and grey under the card. */
  function layout({ subject, bodyHtml, footerHtml, logoUrl, brand }) {
    const logo = logoUrl ? `<img src="${esc(logoUrl)}" alt="${esc(brand || '')}" style="display:block;max-height:40px;max-width:200px;margin:0 0 24px;border:0">` : '';
    return `<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">`
      + `<title>${esc(subject || '')}</title></head>`
      + `<body style="margin:0;padding:0;background:#f5f5f3">`
      + `<table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0" style="background:#f5f5f3"><tr><td align="center" style="padding:32px 16px">`
      + `<table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0" style="max-width:600px;background:#ffffff;border:1px solid #e7e5e0;border-radius:8px">`
      + `<tr><td style="padding:32px 36px 16px;font-family:${FONT};font-size:16px;line-height:1.6;color:#1f1f1f">${logo}${bodyHtml}</td></tr></table>`
      + (footerHtml ? `<table role="presentation" width="100%" cellspacing="0" cellpadding="0" border="0" style="max-width:600px"><tr><td style="padding:16px 36px;font-family:${FONT};font-size:12px;line-height:1.5;color:#8a8883;text-align:center">${footerHtml}</td></tr></table>` : '')
      + '</td></tr></table></body></html>';
  }

  // ── the footer ─────────────────────────────────────────────────────────
  /**
   * The lines under an email: the footer always; the postal address and the
   * unsubscribe link together, only in an email that carries the link (the
   * legal footer of a campaign to many — a one-to-one email stays as written).
   */
  function footerParts(settings, unsubUrl) {
    const s = settings || {};
    const lines = [String(s.footer || '').trim(), unsubUrl ? String(s.postal_address || '').trim() : ''].filter(Boolean);
    const label = String(s.unsubscribe_text || '').trim() || 'Unsubscribe';
    return { lines, label, url: unsubUrl || null };
  }
  function footerText(parts) {
    const out = [...parts.lines];
    if (parts.url) out.push(`${parts.label}: ${parts.url}`);
    return out.join('\n');
  }
  function footerHtml(parts, color) {
    const out = parts.lines.map((l) => esc(l).replace(/\n/g, '<br>'));
    if (parts.url) out.push(`<a href="${esc(parts.url)}" style="color:${color || '#8a8883'}">${esc(parts.label)}</a>`);
    return out.join('<br>');
  }

  /**
   * The email as it leaves: subject, text, and html unless the format is text.
   * `subject` and `body` are the campaign's (or the email's own, when a person
   * edited it); `contact` fills the variables; `unsubUrl` is null when the
   * campaign has no unsubscribe link. `missing` lists variables the contact
   * has no value for and the text has no fallback.
   */
  function compose({ format, subject, body, contact, settings, unsubUrl, brand }) {
    const f = FORMATS.includes(format) ? format : 'text';
    const vars = { unsubscribe_url: unsubUrl || '' };
    const subj = render(subject, contact, { vars });
    const parts = footerParts(settings, unsubUrl);
    const out = { format: f, subject: subj.text.replace(/\s+/g, ' ').trim(), missing: [...subj.missing] };
    if (f === 'html') {
      const b = render(body, contact, { vars, html: true });
      out.missing.push(...b.missing);
      let html = b.text;
      // A line already in the email (written into it before v2) is not added twice.
      const hasLink = unsubUrl && html.includes(esc(unsubUrl));
      const extra = footerHtml({ ...parts, lines: parts.lines.filter((l) => !html.includes(esc(l))), url: hasLink ? null : parts.url });
      if (extra) {
        const block = `<div style="margin:24px 0 0;font-family:${FONT};font-size:12px;line-height:1.5;color:#8a8883;text-align:center">${extra}</div>`;
        html = /<\/body>/i.test(html) ? html.replace(/<\/body>/i, `${block}</body>`) : `${html}\n${block}`;
      }
      out.html = html;
      out.text = htmlToText(html);
    } else {
      const b = render(body, contact, { vars });
      out.missing.push(...b.missing);
      const text = b.text.replace(/\s+$/, '');
      const hasLink = unsubUrl && text.includes(unsubUrl);
      const here = { ...parts, lines: parts.lines.filter((l) => !text.includes(l)), url: hasLink ? null : parts.url };
      const foot = footerText(here);
      out.text = foot ? `${text}\n\n${foot}` : text;
      if (f === 'simple') {
        out.html = layout({ subject: out.subject, bodyHtml: textToHtml(text), footerHtml: footerHtml(here), logoUrl: settings && settings.html_logo_url, brand });
      }
    }
    out.missing = [...new Set(out.missing)];
    return out;
  }

  // ── recipients ─────────────────────────────────────────────────────────
  /**
   * A campaign's recipients: lists and audiences to include, lists and
   * audiences to leave out. Campaigns from before v2 name one audience.
   */
  function parseRecipients(campaign) {
    const k = campaign || {};
    let r;
    try { r = k.recipients ? JSON.parse(k.recipients) : {}; } catch { return null; }
    if (!r || typeof r !== 'object') return null;
    const names = (v) => [...new Set((Array.isArray(v) ? v : []).map((x) => String(x).trim()).filter(Boolean))];
    const ids = (v) => [...new Set((Array.isArray(v) ? v : []).map(Number).filter((n) => Number.isInteger(n) && n > 0))];
    const out = { lists: names(r.lists), audiences: ids(r.audiences), exclude_lists: names(r.exclude_lists), exclude_audiences: ids(r.exclude_audiences) };
    if (!k.recipients && k.audience_id) out.audiences = [Number(k.audience_id)];
    return out;
  }
  const hasRecipients = (r) => !!(r && (r.lists.length || r.audiences.length));

  // Why a contact in scope does not get the email, in the order they are checked.
  const REASONS = {
    excluded: 'Left out by an exclusion', Unsubscribed: 'Unsubscribed', Bounced: 'Bounced', Complained: 'Marked as spam',
    Blocked: 'Blocked', no_email: 'No email', invalid: 'Address not valid', suppressed: 'On the no-contact list',
    duplicate: 'Same address as another contact', written: 'Already written by this campaign',
    contacted: 'Another campaign already wrote to them', pending: 'An email of another campaign is pending', missing: 'No value for a variable without fallback',
  };

  return {
    FORMATS, FORMAT_LABEL, STATUSES, STATUS_LABEL, SPECIAL, EMAIL, REASONS,
    normEmail, statusOf, variables, render, knownVariables, esc, linkify, textToHtml, htmlToText, layout,
    footerParts, footerText, footerHtml, compose, parseRecipients, hasRecipients,
  };
}));
