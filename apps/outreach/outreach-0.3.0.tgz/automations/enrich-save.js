#!/usr/bin/env node
'use strict';
/**
 * Find emails, step 3: write what the agent found.
 *
 * Reads the contacts step 1 claimed ($STEP_step_1) and the agent's answer
 * ($PRIOR). Only an address with a source page is written (Found); a contact
 * the agent looked for and did not find is Not found. When web search itself
 * failed, or the answer cannot be read, NOTHING is marked: every claimed
 * contact goes back in line for the next run. An address another contact
 * already has is not copied onto a second one (one email per address).
 *
 * When some contact was looked up and Settings name a Telegram chat (none by
 * default), that chat is told who and what was found. Not when search failed:
 * nothing was looked up then.
 */
const L = require('./lib');

function summary(found, missing) {
  const n = found.length + missing.length;
  const names = [...found.map((f) => f.name), ...missing].join(', ');
  const emails = found.map((f) => `${f.name} <${f.email}>`).join('; ');
  return `Outreach looked up ${n} ${n === 1 ? 'contact' : 'contacts'}: ${names}. `
    + `Emails found (${found.length})${emails ? `: ${emails}` : ''}. `
    + `No email (${missing.length})${missing.length ? `: ${missing.join(', ')}` : ''}.`;
}

function parse(text) {
  const t = String(text || '').trim();
  const tries = [t];
  const a = t.indexOf('{');
  const b = t.lastIndexOf('}');
  if (a >= 0 && b > a) tries.push(t.slice(a, b + 1));
  for (const x of tries) {
    try {
      const j = JSON.parse(x);
      if (j && typeof j === 'object') {
        // The engine hands over the agent's `content`; if it came wrapped, unwrap it.
        if (typeof j.content === 'string' && !j.results) return parse(j.content);
        return j;
      }
    } catch { /* next */ }
  }
  return null;
}

function main() {
  const claimed = (parse(process.env.STEP_step_1) || {}).contacts || [];
  const answer = parse(process.env.PRIOR);
  const out = { ok: true, ran: 'find emails', looked_for: claimed.length, found: [], not_found: [], released: 0 };
  const release = (ids, why) => {
    for (const id of ids) {
      try {
        L.write([{ op: 'update', table: 'outreach_contacts', id, when: { email_status: 'Searching' }, data: { email_status: null } }]);
        out.released += 1;
      } catch { /* moved on */ }
    }
    out.why = why;
  };
  const ids = claimed.map((c) => Number(c.id)).filter(Boolean);
  if (!ids.length) return L.done(out);
  if (!answer || !Array.isArray(answer.results)) { release(ids, 'The answer could not be read; they go back in line.'); return L.done(out); }
  if (answer.search_ok === false) { release(ids, 'Web search failed; they go back in line.'); return L.done(out); }

  const byId = new Map(answer.results.map((r) => [Number(r && r.id), r]));
  const nameOf = new Map(claimed.map((c) => [Number(c.id), c.name || c.organization || `#${c.id}`]));
  const told = { found: [], missing: [] };
  const now = L.sqlNow();
  const untouched = [];
  for (const id of ids) {
    const r = byId.get(id);
    if (!r) { untouched.push(id); continue; }
    const email = L.normEmail(r.email);
    const source = typeof r.source === 'string' && /^https?:\/\//.test(r.source.trim()) ? r.source.trim().slice(0, 500) : null;
    let data;
    if (email && L.EMAIL.test(email) && source) {
      const other = L.one(`SELECT _id, name FROM outreach_contacts WHERE _deleted = 0 AND _id <> ? AND LOWER(TRIM(email)) = ?`, id, email);
      data = other
        ? { email_status: 'Not found', email_source: `Same address as ${other.name || '#' + other._id}: ${email}`, email_checked_at: now }
        : { email, email_status: 'Found', email_source: source, email_checked_at: now };
      (other ? out.not_found : out.found).push(email);
    } else {
      data = { email_status: 'Not found', email_checked_at: now, email_source: r.note ? `Not found: ${String(r.note).slice(0, 300)}` : null };
      out.not_found.push(id);
    }
    try {
      L.write([{ op: 'update', table: 'outreach_contacts', id, when: { email_status: 'Searching' }, data }]);
      if (data.email_status === 'Found') told.found.push({ name: nameOf.get(id), email: data.email });
      else told.missing.push(nameOf.get(id));
    } catch (e) {
      out.errors = (out.errors || []).concat({ id, error: String(e.message).slice(0, 200) });
    }
  }
  if (untouched.length) release(untouched, 'The agent did not answer for these; they go back in line.');
  if (told.found.length + told.missing.length) out.telegram = L.notify(L.settings(), summary(told.found, told.missing));
  return L.done(out);
}

try {
  main();
} catch (e) {
  process.stderr.write(`find emails: ${e.message}\n`);
  process.exit(1);
}
