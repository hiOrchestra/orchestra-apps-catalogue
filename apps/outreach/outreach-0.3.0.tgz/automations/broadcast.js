#!/usr/bin/env node
'use strict';
/**
 * Broadcast: one email to many, sent as fast as Resend and the daily limit
 * allow. Each run:
 *
 * 1. A broadcast Scheduled for now or earlier becomes Sending ("Send now"
 *    schedules it for now and starts this workflow).
 * 2. A Sending broadcast not yet frozen is frozen: every recipient on its list
 *    right now (lib.recipientsOf, the same count the screen showed) gets an
 *    email row, Queued, with its subject. The text is not copied: it is the
 *    campaign's, and a campaign that is sending cannot be edited.
 * 3. Then, for about two minutes, batches of up to 100: claimed (Queued →
 *    Sending, so no email leaves twice), written for each contact (mailcore:
 *    format, footer, the unsubscribe link naming that email), sent in one call
 *    with an idempotency key, and recorded Sent with Resend's id.
 *
 * Between batches it stops for a pause (the campaign's or the global one) and
 * at the daily limit (Settings), which resumes the next day on its own. A
 * contact who unsubscribed, bounced or was blocked after the freeze is
 * cancelled, not sent. When nothing is left the broadcast is Sent.
 *
 * When Resend refuses a whole batch for one address, the batch is sent one by
 * one so only that address fails. When Resend does not answer, the batch may
 * have gone out: it is marked Failed with those words and the broadcast
 * pauses — never re-sent blind. A failed email a person sends again waits as
 * Retry and goes out on the next run, even when its broadcast has finished.
 */
const L = require('./lib');

const BUDGET_MS = Number(process.env.OUTREACH_BROADCAST_BUDGET_MS || 110000);
const BATCH = Math.max(1, Math.min(100, Number(process.env.OUTREACH_BATCH || 100)));
const BROADCAST = "k.kind = 'broadcast'";

async function main() {
  const started = Date.now();
  const s = L.settings();
  const out = { ok: true, ran: 'broadcast', campaigns: [] };

  // What a finished broadcast left queued never goes out; a failed email sent
  // again after it finished (queued since) is a retry, and goes.
  const leftovers = L.all(`SELECT s._id, CASE WHEN datetime(s.queued_at) > datetime(k.finished_at) THEN 1 ELSE 0 END AS retry
    FROM outreach_sends s JOIN outreach_campaigns k ON k._id = s.campaign_id
    WHERE s._deleted = 0 AND ${BROADCAST} AND k.status = 'Sent' AND s.status = 'Queued'`);
  const dead = leftovers.filter((r) => !r.retry);
  if (dead.length) {
    L.write(dead.map((r) => ({ op: 'update', table: 'outreach_sends', id: r._id, when: { status: 'Queued' },
      data: { status: 'Cancelled', error: 'The broadcast was finished before it went out' } })));
    out.cancelled = dead.length;
  }
  const again = leftovers.filter((r) => r.retry);
  if (again.length) {
    L.write(again.map((r) => ({ op: 'update', table: 'outreach_sends', id: r._id, when: { status: 'Queued' }, data: { status: 'Retry' } })));
  }
  // A batch left Sending by a run that died: it may have gone out. Never re-sent blind.
  const stale = L.all(`SELECT s._id FROM outreach_sends s JOIN outreach_campaigns k ON k._id = s.campaign_id
    WHERE s._deleted = 0 AND ${BROADCAST} AND s.status = 'Sending' AND datetime(s.lock_at) <= datetime('now', '-15 minutes')`);
  if (stale.length) {
    L.write(stale.map((r) => ({ op: 'update', table: 'outreach_sends', id: r._id, when: { status: 'Sending' },
      data: { status: 'Failed', error: 'The send did not finish, so it may or may not have gone out. Check Resend before retrying it.' } })));
    out.unfinished = stale.length;
  }
  if (Number(s.paused) === 1) return L.done({ ...out, skipped: 'Sending is paused in Settings' });

  for (const k of L.all(`SELECT _id FROM outreach_campaigns k WHERE _deleted = 0 AND ${BROADCAST} AND status = 'Scheduled'
      AND datetime(scheduled_at) <= datetime('now')`)) {
    try {
      L.write([{ op: 'update', table: 'outreach_campaigns', id: k._id, when: { status: 'Scheduled' },
        data: { status: 'Sending', started_at: L.sqlNow(), problem: null } }]);
    } catch { /* another run took it */ }
  }

  const tz = L.schedule(s).tz;
  const cap = Math.max(1, Number(s.broadcast_daily_cap) || 500);
  let used = L.one(`SELECT COUNT(*) AS n FROM outreach_sends s JOIN outreach_campaigns k ON k._id = s.campaign_id
    WHERE s._deleted = 0 AND ${BROADCAST} AND s.status IN ('Sending', 'Sent', 'Replied', 'Bounced')
    AND datetime(COALESCE(s.sent_at, s.lock_at)) >= datetime(?)`, L.sqlNow(L.dayStart(new Date(), tz))).n;
  let capped = false;

  for (const k0 of L.all(`SELECT * FROM outreach_campaigns k WHERE _deleted = 0 AND ${BROADCAST} AND status = 'Sending'
      ORDER BY datetime(started_at), _id`)) {
    let k = k0;
    const report = { campaign: k.name, id: k._id };
    out.campaigns.push(report);
    const pause = (problem) => {
      try {
        L.write([{ op: 'update', table: 'outreach_campaigns', id: k._id, when: { status: 'Sending' }, data: { status: 'Paused', problem } }]);
      } catch { /* changed meanwhile */ }
      report.paused = problem;
    };
    const content = L.contentOf(k);
    const problem = L.contentProblem(k, s, content);
    if (problem) { pause(problem); continue; }

    if (!k.frozen_at) {
      const who = L.recipientsOf(k, { content });
      if (who.problem) { pause(who.problem); continue; }
      const sender = L.senderOf(k, s);
      try {
        L.write(who.ok.map((c) => ({
          op: 'insert', table: 'outreach_sends',
          data: {
            campaign_id: k._id, contact_id: c._id, email: L.normEmail(c.email), name: c.name || null, organization: c.organization || null,
            subject: L.render(content.subject, c, { keep: ['unsubscribe_url'] }).text.replace(/\s+/g, ' ').trim(), body: null,
            from_address: sender.from, reply_to: sender.replyTo, status: 'Queued', queued_at: L.sqlNow(),
          },
        })));
      } catch (e) {
        // Another run is freezing it too (the unique index refused a second
        // row for one contact): it finishes, or the next run completes it.
        report.freezing = String(e.message || e).slice(0, 160);
        continue;
      }
      const total = L.one('SELECT COUNT(*) AS n FROM outreach_sends WHERE _deleted = 0 AND campaign_id = ?', k._id).n;
      const notes = [];
      for (const [key, n] of Object.entries(who.missingVars)) notes.push(`${n} left out: no ${key.replace(/_/g, ' ')} and no fallback`);
      L.write([{ op: 'update', table: 'outreach_campaigns', id: k._id, data: {
        frozen_at: L.sqlNow(), total, checks: 0, note: notes.join('; ') || null,
        next_check_at: L.sqlNow(new Date((L.toDate(k.started_at) || new Date()).getTime() + 3600000)),
      } }]);
      report.frozen = total;
      k = L.one('SELECT * FROM outreach_campaigns WHERE _id = ?', k._id);
    }

    report.sent = 0;
    report.failed = 0;
    while (Date.now() - started < BUDGET_MS) {
      const now = L.one('SELECT status FROM outreach_campaigns WHERE _id = ?', k._id);
      if (!now || now.status !== 'Sending') { report.stopped = now ? now.status : 'deleted'; break; }
      if (Number((L.one('SELECT paused FROM outreach_settings WHERE _id = ?', s._id) || {}).paused) === 1) { report.stopped = 'paused in Settings'; break; }
      if (used >= cap) { capped = true; break; }
      const rows = L.all(`SELECT * FROM outreach_sends WHERE _deleted = 0 AND campaign_id = ? AND status = 'Queued' ORDER BY _id LIMIT ?`,
        k._id, Math.min(BATCH, cap - used));
      if (!rows.length) break;
      const r = await sendBatch(s, k, content, rows, 'Queued', report);
      used += r.sent;
      if (r.stop) break;
    }

    const left = L.one(`SELECT COUNT(*) AS n FROM outreach_sends WHERE _deleted = 0 AND campaign_id = ? AND status IN ('Queued', 'Sending')`, k._id).n;
    report.left = left;
    if (!left && L.one('SELECT status FROM outreach_campaigns WHERE _id = ?', k._id).status === 'Sending') {
      try {
        L.write([{ op: 'update', table: 'outreach_campaigns', id: k._id, when: { status: 'Sending' }, data: { status: 'Sent', finished_at: L.sqlNow() } }]);
        report.done = true;
        const n = L.one(`SELECT SUM(status IN ('Sent', 'Replied', 'Bounced')) AS sent, SUM(status = 'Failed') AS failed
          FROM outreach_sends WHERE _deleted = 0 AND campaign_id = ?`, k._id);
        report.telegram = L.notify(s, `Outreach: the broadcast "${k.name}" went out to ${n.sent || 0} ${n.sent === 1 ? 'person' : 'people'}`
          + `${n.failed ? `; ${n.failed} failed (see Sent)` : ''}.`);
      } catch { /* changed meanwhile */ }
    }
  }

  // Failed emails a person sent again ("Retry"): they go out whatever state
  // their broadcast is in, under the same daily limit.
  for (const k of L.all(`SELECT DISTINCT k.* FROM outreach_campaigns k JOIN outreach_sends s ON s.campaign_id = k._id
      WHERE k._deleted = 0 AND ${BROADCAST} AND s._deleted = 0 AND s.status = 'Retry' ORDER BY k._id`)) {
    const report = { campaign: k.name, id: k._id, retry: true, sent: 0, failed: 0 };
    out.campaigns.push(report);
    const content = L.contentOf(k);
    while (Date.now() - started < BUDGET_MS && !capped) {
      if (used >= cap) { capped = true; break; }
      const rows = L.all(`SELECT * FROM outreach_sends WHERE _deleted = 0 AND campaign_id = ? AND status = 'Retry' ORDER BY _id LIMIT ?`,
        k._id, Math.min(BATCH, cap - used));
      if (!rows.length) break;
      const r = await sendBatch(s, k, content, rows, 'Retry', report);
      used += r.sent;
      if (r.stop) break;
    }
  }

  // The daily limit: the schedule rests until tomorrow, then carries on.
  if (capped) {
    const next = L.nextDay(new Date(), tz);
    L.write([{ op: 'update', table: 'outreach_settings', id: s._id, data: { broadcast_next_at: L.sqlNow(next) } }]);
    out.limit = `The daily limit of ${cap} is reached: it carries on at ${L.sqlNow(next)} UTC`;
  } else if (s.broadcast_next_at) {
    L.write([{ op: 'update', table: 'outreach_settings', id: s._id, data: { broadcast_next_at: null } }]);
  }
  return L.done(out);
}

/**
 * One batch: claimed, written for each contact as it is now, sent in one call,
 * recorded. Returns how many left and whether this broadcast must stop for now.
 */
async function sendBatch(s, k, content, rows, from, report) {
  const key = `outreach-${k._id}-${rows[0]._id}-${rows[rows.length - 1]._id}-${rows.length}-${from}`;
  const claimed = claim(rows, key, from);
  if (!claimed.length) return { sent: 0 };
  const pause = (problem) => {
    try {
      L.write([{ op: 'update', table: 'outreach_campaigns', id: k._id, when: { status: 'Sending' }, data: { status: 'Paused', problem } }]);
    } catch { /* not sending: a retry of a finished one */ }
    report.paused = problem;
  };
  const sender = L.senderOf(k, s);
  const byId = new Map(L.all(`SELECT * FROM outreach_contacts WHERE _id IN (${claimed.map(() => '?').join(',')})`,
    ...claimed.map((r) => r.contact_id || 0)).map((c) => [c._id, c]));
  const sup = L.suppressionIndex();
  const ready = [];
  const messages = [];
  const cancel = [];
  for (const r of claimed) {
    const c = byId.get(r.contact_id);
    const status = c && L.M.statusOf(c);
    if (!c || c._deleted) cancel.push([r, 'The contact was deleted']);
    else if (status !== 'Active') cancel.push([r, `The contact is ${L.M.STATUS_LABEL[status].toLowerCase()}`]);
    else if (sup.has(L.normEmail(r.email))) cancel.push([r, 'On the no-contact list']);
    else {
      const link = Number(k.unsubscribe_link) === 1 ? L.unsubUrl(s, r._id) : null;
      // An email a person edited (after it failed) keeps its own text.
      const email = L.M.compose({ format: content.format, subject: r.subject || content.subject, body: r.body != null ? r.body : content.body,
        contact: c, settings: s, unsubUrl: link, brand: sender.brand });
      messages.push(L.resendMessage({ from: sender.from, to: L.normEmail(r.email), replyTo: sender.replyTo, email, unsubscribe: link }));
      ready.push(r);
    }
  }
  if (cancel.length) {
    L.write(cancel.map(([r, why]) => ({ op: 'update', table: 'outreach_sends', id: r._id, when: { status: 'Sending' }, data: { status: 'Cancelled', error: why } })));
    report.cancelled = (report.cancelled || 0) + cancel.length;
  }
  if (!messages.length) return { sent: 0 };

  const sent = (r, id) => ({ op: 'update', table: 'outreach_sends', id: r._id, data: {
    status: 'Sent', sent_at: L.sqlNow(), provider_id: id ? String(id) : null, error: null, from_address: sender.from, reply_to: sender.replyTo } });
  const failed = (r, why) => ({ op: 'update', table: 'outreach_sends', id: r._id, data: { status: 'Failed', error: String(why).slice(0, 300), from_address: sender.from } });
  let result = null;
  let error = null;
  try {
    result = await L.composio('RESEND_SEND_BATCH_EMAILS', { emails: messages, 'Idempotency-Key': key }, 90000);
  } catch (e) {
    error = String(e.message || e);
  }
  if (result) {
    const ids = L.idsOf(result);
    L.write(ready.map((r, i) => sent(r, ids[i])));
    report.sent += ready.length;
    if (ids.length !== ready.length) report.warning = `Resend answered ${ids.length} ids for ${ready.length} emails`;
    return { sent: ready.length };
  }
  if (/did not answer|timed? ?out|ECONNRESET|socket hang up|HTTP 5\d\d|50[234]/i.test(error)) {
    L.write(ready.map((r) => failed(r, `Resend did not answer for this batch, so it may or may not have gone out: ${error}`)));
    report.failed += ready.length;
    pause('Resend did not answer a batch, so those emails may have gone out. Check Resend, fix them in Sent, then resume.');
    return { sent: 0, stop: true };
  }
  if (/429|rate limit|too many/i.test(error)) {
    // Nothing left: they go back in line and the next run takes them.
    L.write(ready.map((r) => ({ op: 'update', table: 'outreach_sends', id: r._id, when: { status: 'Sending' }, data: { status: from, lock_at: null, batch_key: null } })));
    report.stopped = 'Resend asked to slow down';
    return { sent: 0, stop: true };
  }
  if (/domain|sender|from|verif|api key|unauthori|forbidden|403|401/i.test(error)) {
    L.write(ready.map((r) => failed(r, error)));
    report.failed += ready.length;
    pause(`Resend refused the sender: ${L.readable(error)}. Fix it in the campaign or Settings, send the failed ones again, then resume.`);
    return { sent: 0, stop: true };
  }
  // Refused for something in it: one by one, so only the bad ones fail.
  let n = 0;
  for (let i = 0; i < ready.length; i += 1) {
    try {
      const one = await L.composio('RESEND_SEND_EMAIL', messages[i]);
      L.write([sent(ready[i], L.pick(one, 'id'))]);
      n += 1;
      report.sent += 1;
    } catch (e) {
      L.write([failed(ready[i], e.message || e)]);
      report.failed += 1;
    }
  }
  return { sent: n };
}

/** Queued (or Retry) → Sending for the batch, all at once; one by one when one changed meanwhile. */
function claim(rows, key, from) {
  const data = { status: 'Sending', lock_at: L.sqlNow(), batch_key: key };
  try {
    L.write(rows.map((r) => ({ op: 'update', table: 'outreach_sends', id: r._id, when: { status: from }, data })));
    return rows;
  } catch {
    const got = [];
    for (const r of rows) {
      try { L.write([{ op: 'update', table: 'outreach_sends', id: r._id, when: { status: from }, data }]); got.push(r); } catch { /* taken */ }
    }
    return got;
  }
}

main().catch((e) => {
  process.stderr.write(`broadcast: ${e.message}\n`);
  process.exit(1);
});
