#!/usr/bin/env node
'use strict';
/**
 * Test send: the campaign's email, exactly as a recipient would get it, to up
 * to five addresses, with "[Test]" before the subject. It is written for the
 * first contact that would get it (or, before there is one, with the
 * fallbacks), and its unsubscribe link is a test link that unsubscribes
 * nobody. The result goes to the campaign's `test_result` for the screen.
 *   node test-send.js <campaign id> <address[,address…]>
 */
const L = require('./lib');

async function main() {
  const id = Number(process.argv[2]);
  const to = [...new Set(String(process.argv[3] || '').split(/[\s,;]+/).map(L.normEmail).filter((e) => L.EMAIL.test(e)))].slice(0, 5);
  if (!Number.isInteger(id) || id <= 0) throw new Error('which campaign? pass its id');
  const s = L.settings();
  const k = L.one('SELECT * FROM outreach_campaigns WHERE _deleted = 0 AND _id = ?', id);
  if (!k) throw new Error(`there is no campaign ${id}`);
  const record = (result) => {
    L.write([{ op: 'update', table: 'outreach_campaigns', id, data: { test_result: JSON.stringify({ at: L.sqlNow(), to, ...result }) } }]);
    return L.done({ ok: !result.error, ran: 'test send', campaign: id, to, ...result });
  };
  if (!to.length) return record({ error: 'Write at least one valid address to send the test to.' });
  const content = L.contentOf(k);
  const problem = L.contentProblem(k, s, content);
  if (problem && !/unsubscribe page/.test(problem)) return record({ error: problem });
  const who = L.recipientsOf(k, { content });
  const sample = (who.ok && who.ok[0]) || { name: '', email: to[0] };
  const { from, replyTo, brand } = L.senderOf(k, s);
  const base = String(s.unsubscribe_url || '').split('#')[0];
  const link = Number(k.unsubscribe_link) === 1 ? `${base || 'https://example.com/unsubscribe'}#t=test` : null;
  const email = L.M.compose({ format: content.format, subject: content.subject, body: content.body, contact: sample, settings: s, unsubUrl: link, brand });
  email.subject = `[Test] ${email.subject}`;
  const sent = [];
  const failed = [];
  for (const address of to) {
    try {
      const res = await L.composio('RESEND_SEND_EMAIL', L.resendMessage({ from, to: address, replyTo, email, unsubscribe: link }));
      sent.push({ to: address, id: L.pick(res, 'id') || null });
    } catch (e) {
      failed.push({ to: address, error: L.readable(e.message || e) });
    }
  }
  return record({
    sample: sample._id ? `${sample.name || sample.email}` : null,
    sent: sent.map((x) => x.to), error: failed.length ? failed.map((x) => `${x.to}: ${x.error}`).join('; ') : null,
  });
}

main().catch((e) => {
  process.stderr.write(`test send: ${e.message}\n`);
  process.exit(1);
});
