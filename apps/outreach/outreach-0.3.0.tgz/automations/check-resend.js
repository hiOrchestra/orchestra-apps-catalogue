#!/usr/bin/env node
'use strict';
/**
 * Check Resend: asks Resend for its latest email (one read, nothing is sent)
 * and notes in Settings whether it answered, for Getting started. Resend is
 * connected in the portal (Integrations), which this app cannot see; Resend
 * answering through Composio is how it knows.
 *   node check-resend.js
 */
const L = require('./lib');

async function main() {
  try {
    await L.composio('RESEND_LIST_EMAILS', { limit: 1 });
    return L.done({ ok: true, ran: 'check resend', connected: true });
  } catch (e) {
    const why = L.readable(e.message || e);
    L.noteResend(why);
    return L.done({ ok: true, ran: 'check resend', connected: false, why });
  }
}

main().catch((e) => {
  process.stderr.write(`check resend: ${e.message}\n`);
  process.exit(1);
});
