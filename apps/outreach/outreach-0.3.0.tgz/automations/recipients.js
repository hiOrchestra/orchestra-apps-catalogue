#!/usr/bin/env node
'use strict';
/**
 * Count recipients: who a campaign would write to right now, and why the
 * others would not get it, written to the campaign's `estimate` for the
 * screen. The same lib.recipientsOf that freezes a broadcast and queues a
 * sequence, so the number shown is the number that goes out.
 *   node recipients.js <campaign id>
 */
const L = require('./lib');

function main() {
  const id = Number(process.argv[2]);
  if (!Number.isInteger(id) || id <= 0) throw new Error('which campaign? pass its id');
  const s = L.settings();
  const k = L.one('SELECT * FROM outreach_campaigns WHERE _deleted = 0 AND _id = ?', id);
  if (!k) throw new Error(`there is no campaign ${id}`);
  const content = L.contentOf(k);
  const usable = content && String(content.subject || '').trim() && String(content.body || '').trim() ? content : null;
  const who = L.recipientsOf(k, { content: usable && !L.unknownVariables(usable).length ? usable : null });
  const estimate = {
    at: L.sqlNow(),
    problem: who.problem || null,
    content: L.contentProblem(k, s, content),
    in_scope: who.inScope || 0,
    count: who.ok ? who.ok.length : 0,
    counts: who.counts || {},
    missing: who.missingVars || {},
  };
  L.write([{ op: 'update', table: 'outreach_campaigns', id, data: { estimate: JSON.stringify(estimate) } }]);
  return L.done({ ok: true, ran: 'count recipients', campaign: id, ...estimate });
}

try {
  main();
} catch (e) {
  process.stderr.write(`count recipients: ${e.message}\n`);
  process.exit(1);
}
