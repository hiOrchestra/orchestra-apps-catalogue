#!/usr/bin/env node
'use strict';
/**
 * Write emails, for SEQUENCES: every active sequence writes the email of each
 * of its recipients it has not written to yet. In a review-first sequence they
 * wait In review; otherwise they go straight to the queue, where "Send" takes
 * them one at a time. (Broadcasts are written and sent by broadcast.js.)
 *
 * Who gets one is lib.recipientsOf: the lists and audiences the campaign
 * names, minus its exclusions, only Active contacts with a valid address that
 * is not on the no-contact list, never twice, one pending email per person,
 * and nobody another campaign reached when it skips the contacted (the
 * default). Who goes first: an audience's stages in the order it lists them,
 * then priority (High, Medium, Low).
 *
 * The email is written from the campaign's own subject and text. Its
 * unsubscribe link is filled in when it leaves: the link names the email,
 * which has no number yet.
 *
 * Finished campaigns keep nothing pending: what is left of them is cancelled.
 */
const L = require('./lib');

const LIMIT = Number(process.env.OUTREACH_QUEUE_LIMIT || 500); // per campaign per run
// --dry-run: what each active OR PAUSED sequence would write now, in order;
// nothing is written. For "what happens if I resume it?".
const DRY = process.argv.includes('--dry-run');
const write = (ops) => (DRY ? 0 : L.write(ops));
const SEQUENCE = "COALESCE(kind, 'sequence') = 'sequence'";

function main() {
  const s = L.settings();
  const cols = L.columnsOf('outreach_contacts');
  const report = [];

  const leftovers = L.all(`SELECT s._id, s.status FROM outreach_sends s JOIN outreach_campaigns k ON k._id = s.campaign_id
    WHERE s._deleted = 0 AND k._deleted = 0 AND k.status = 'Finished' AND s.status IN ('Queued', 'In review')`);
  if (leftovers.length && !DRY) {
    L.write(leftovers.map((r) => ({
      op: 'update', table: 'outreach_sends', id: r._id,
      data: { status: 'Cancelled', error: 'The campaign was finished before it went out' }, when: { status: r.status },
    })));
    report.push({ cancelled: leftovers.length, why: 'finished campaigns' });
  }

  const states = DRY ? "('Active', 'Paused')" : "('Active')";
  for (const k of L.all(`SELECT * FROM outreach_campaigns WHERE _deleted = 0 AND ${SEQUENCE} AND status IN ${states} ORDER BY _id`)) {
    const flag = (problem, note) => {
      if ((k.problem || null) !== (problem || null) || (note !== undefined && (k.note || null) !== (note || null))) {
        const data = { problem: problem || null };
        if (note !== undefined) data.note = note || null;
        write([{ op: 'update', table: 'outreach_campaigns', id: k._id, data }]);
      }
    };
    const sender = L.senderOf(k, s);
    const content = L.contentOf(k);
    let blocker = L.contentProblem(k, s, content);
    // Who goes first: the stages of its first audience that lists several, in
    // that order ("Shortlisted, Researching": shortlisted first), then High priority.
    const order = [];
    const orderParams = [];
    if (!blocker) {
      const rec = L.M.parseRecipients(k) || { audiences: [] };
      for (const id of rec.audiences) {
        const a = L.one('SELECT filter FROM outreach_audiences WHERE _deleted = 0 AND _id = ?', id);
        let f = {};
        try { f = JSON.parse((a && a.filter) || '{}'); } catch { f = {}; }
        if (Array.isArray(f.stage) && f.stage.length > 1) {
          order.push(`CASE c.stage ${f.stage.map(() => 'WHEN ? THEN ?').join(' ')} ELSE ? END`);
          f.stage.forEach((st, i) => orderParams.push(String(st), i));
          orderParams.push(f.stage.length);
          break;
        }
      }
      if (cols.has('priority')) order.push("CASE c.priority WHEN 'High' THEN 0 WHEN 'Medium' THEN 1 WHEN 'Low' THEN 2 ELSE 3 END");
      order.push('c._id');
    }
    const who = blocker ? null : L.recipientsOf(k, { content, order: order.join(', '), orderParams });
    if (who && who.problem) blocker = who.problem;
    if (blocker) {
      flag(blocker);
      report.push({ campaign: k.name, problem: blocker });
      continue;
    }

    const ops = [];
    for (const c of who.ok.slice(0, LIMIT)) {
      const subject = L.render(content.subject, c, { keep: ['unsubscribe_url'] });
      const body = L.render(content.body, c, { keep: ['unsubscribe_url'] });
      ops.push({
        op: 'insert', table: 'outreach_sends',
        data: {
          campaign_id: k._id, template_id: k.template_id || null, contact_id: c._id, email: L.normEmail(c.email),
          name: c.name || null, organization: c.organization || null,
          subject: subject.text.replace(/\s+/g, ' ').trim(), body: body.text,
          from_address: sender.from, reply_to: sender.replyTo,
          status: k.mode === 'review' ? 'In review' : 'Queued', queued_at: L.sqlNow(),
        },
      });
    }
    write(ops);

    // Only what a person would want to know: the written, the pending and the
    // exclusions are the campaign working as asked.
    const notes = [];
    for (const [key, n] of Object.entries(who.missingVars)) notes.push(`${n} skipped: no ${key.replace(/_/g, ' ')} for the email and no fallback`);
    if (who.counts.invalid) notes.push(`${who.counts.invalid} skipped: the address is not valid`);
    write([{ op: 'update', table: 'outreach_campaigns', id: k._id, data: { last_queued_at: L.sqlNow() } }]);
    flag(null, notes.join('; '));
    report.push({
      campaign: k.name, [DRY ? 'would_write' : 'written']: ops.length, as: k.mode === 'review' ? 'In review' : 'Queued', skipped: notes,
      ...(DRY ? { first: ops.slice(0, 12).map((o) => `${o.data.name} <${o.data.email}>`) } : {}),
    });
  }
  return L.done({ ok: true, ran: DRY ? 'queue (dry run)' : 'queue', campaigns: report });
}

try {
  main();
} catch (e) {
  process.stderr.write(`queue: ${e.message}\n`);
  process.exit(1);
}
