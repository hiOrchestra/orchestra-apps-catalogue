#!/usr/bin/env node
'use strict';
/**
 * Import contacts: a CSV the screen already read and mapped, uploaded in
 * parts (an action takes under 100 KB), becomes contacts.
 *
 * One contact per address. An address already in Outreach keeps its contact:
 * it joins the list, and its empty fields are filled (all of them with
 * "overwrite"); its status does not change, so an unsubscribed contact stays
 * unsubscribed. A new address becomes an Active contact on the list, unless
 * it is on the no-contact list. Skipped, each with the line and why: no
 * address, an address that is not valid, the same address twice in the file,
 * an address on the no-contact list. The result, and up to 2,000 skipped
 * lines, go to the import's first part for the screen; the parts' rows are
 * emptied after, so the file does not live twice in the database.
 *   node import.js <import key>
 */
const L = require('./lib');

// Columns an import may write. Status, lists and the lookup's own columns are not the file's to set.
const NEVER = new Set(['status', 'status_at', 'status_note', 'tags', 'do_not_contact', 'email_status', 'email_source', 'email_checked_at', 'legacy_target_id']);

function main() {
  const key = String(process.argv[2] || '').trim();
  if (!/^[A-Za-z0-9_-]{6,64}$/.test(key)) throw new Error('which import? pass its key');
  const parts = L.all('SELECT * FROM outreach_imports WHERE _deleted = 0 AND import_key = ? ORDER BY part', key);
  if (!parts.length) throw new Error(`there is no import ${key}`);
  const first = parts[0];
  if (first.status === 'Done') return L.done({ ok: true, ran: 'import', import: key, skipped: 'already imported' });
  const expected = Number(first.parts) || parts.length;
  if (parts.length < expected) {
    L.write([{ op: 'update', table: 'outreach_imports', id: first._id, data: { status: 'Failed', result: JSON.stringify({ error: `Only ${parts.length} of ${expected} parts of the file arrived: import it again.` }) } }]);
    return L.done({ ok: false, ran: 'import', import: key, error: 'parts missing' });
  }
  try {
    L.write([{ op: 'update', table: 'outreach_imports', id: first._id, when: { status: first.status }, data: { status: 'Importing' } }]);
  } catch {
    return L.done({ ok: true, ran: 'import', import: key, skipped: 'another run is importing it' });
  }

  try {
    return run(parts, first, key);
  } catch (e) {
    L.write([{ op: 'update', table: 'outreach_imports', id: first._id, data: { status: 'Failed', result: JSON.stringify({ error: String(e.message || e).slice(0, 300) }) } }]);
    throw e;
  }
}

function run(parts, first, key) {
  const cols = L.columnsOf('outreach_contacts');
  const writable = (k) => cols.has(k) && !k.startsWith('_') && !NEVER.has(k);
  const list = String(first.list_name || '').replace(/\|/g, '/').trim().slice(0, 80);
  const overwrite = Number(first.overwrite) === 1;
  const source = `Import: ${String(first.file_name || 'a file').slice(0, 120)}`;
  const tagsOf = (t) => String(t || '').split('|').map((x) => x.trim()).filter(Boolean);

  const existing = new Map();
  for (const c of L.all(`SELECT * FROM outreach_contacts WHERE _deleted = 0 AND email IS NOT NULL AND TRIM(email) <> ''`)) existing.set(L.normEmail(c.email), c);
  const sup = L.suppressionIndex();
  const seen = new Set();
  const ops = [];
  const skipped = [];
  const tally = { added: 0, updated: 0, unchanged: 0, not_active: 0, skipped: 0 };
  const skip = (line, email, reason) => { tally.skipped += 1; if (skipped.length < 2000) skipped.push({ line, email: email || '', reason }); };

  let line = 1; // the header is line 1
  for (const p of parts) {
    let rows = [];
    try { rows = JSON.parse(p.rows || '[]'); } catch { rows = []; }
    for (const raw of rows) {
      line += 1;
      const row = raw && typeof raw === 'object' ? raw : {};
      const at = Number(row._line) || line;
      const email = L.normEmail(row.email);
      if (!email) { skip(at, '', 'No email address'); continue; }
      if (!L.EMAIL.test(email)) { skip(at, email, 'Not a valid address'); continue; }
      if (seen.has(email)) { skip(at, email, 'The same address is higher up in the file'); continue; }
      seen.add(email);
      const values = {};
      for (const [k, v] of Object.entries(row)) {
        if (k === 'email' || !writable(k)) continue;
        const text = v === null || v === undefined ? '' : String(v).trim();
        if (text) values[k] = text.slice(0, 2000);
      }
      const c = existing.get(email);
      if (c) {
        const data = {};
        for (const [k, v] of Object.entries(values)) {
          const had = c[k] === null || c[k] === undefined ? '' : String(c[k]).trim();
          if (!had || (overwrite && had !== v)) data[k] = v;
        }
        const tags = tagsOf(c.tags);
        if (list && !tags.includes(list)) data.tags = `|${[...tags, list].join('|')}|`;
        if (L.M.statusOf(c) !== 'Active') tally.not_active += 1;
        if (Object.keys(data).length) { ops.push({ op: 'update', table: 'outreach_contacts', id: c._id, data }); tally.updated += 1; } else tally.unchanged += 1;
        continue;
      }
      if (sup.has(email)) { skip(at, email, 'On the no-contact list'); continue; }
      ops.push({ op: 'insert', table: 'outreach_contacts', data: {
        ...values, email, name: values.name || null, email_status: 'Imported', status: 'Active',
        tags: list ? `|${list}|` : null, source: values.source || source,
      } });
      tally.added += 1;
    }
  }
  L.write(ops);

  const s = L.settings();
  const known = L.jsonList(s.tags);
  if (list && !known.includes(list)) {
    L.write([{ op: 'update', table: 'outreach_settings', id: s._id, data: { tags: JSON.stringify([...known, list].sort((a, b) => a.localeCompare(b))) } }]);
  }
  const result = { ...tally, list: list || null, rows: line - 1, skipped_rows: skipped, at: L.sqlNow() };
  L.write([
    { op: 'update', table: 'outreach_imports', id: first._id, data: { status: 'Done', result: JSON.stringify(result), rows: '[]' } },
    ...parts.slice(1).map((p) => ({ op: 'update', table: 'outreach_imports', id: p._id, data: { rows: '[]', status: 'Done' } })),
  ]);
  return L.done({ ok: true, ran: 'import', import: key, ...tally, list: list || null });
}

try {
  main();
} catch (e) {
  process.stderr.write(`import: ${e.message}\n`);
  process.exit(1);
}
