#!/usr/bin/env node
'use strict';
/**
 * Unsubscribe: someone pressed the button on the public unsubscribe page. The
 * token names the email the link came in and is signed with the secret in
 * Settings; anything else is ignored (bots, typos, the test link).
 *
 * Unsubscribing is global: the contact becomes Unsubscribed, the address goes
 * on the no-contact list, the email is marked (the campaign's report counts
 * it), and whatever was still waiting for them in any campaign is cancelled.
 * Pressing it twice changes nothing more.
 *   node unsubscribe.js <token>
 */
const L = require('./lib');

function main() {
  const token = String(process.argv[2] || '');
  const s = L.settings();
  if (token === 'test') return L.done({ ok: true, ran: 'unsubscribe', ignored: 'the test link unsubscribes nobody' });
  const id = L.unsubSendId(token, s.unsubscribe_secret);
  if (!id) return L.done({ ok: true, ran: 'unsubscribe', ignored: 'not one of our links' });
  const send = L.one('SELECT * FROM outreach_sends WHERE _id = ?', id);
  if (!send) return L.done({ ok: true, ran: 'unsubscribe', ignored: `email ${id} does not exist` });
  const email = L.normEmail(send.email);
  const k = L.one('SELECT name FROM outreach_campaigns WHERE _id = ?', send.campaign_id) || {};
  const why = `Unsubscribed from the link in "${k.name || `campaign ${send.campaign_id}`}"`;
  const ops = [];
  if (!send.unsubscribed_at) ops.push({ op: 'update', table: 'outreach_sends', id, data: { unsubscribed_at: L.sqlNow() } });
  const contacts = L.all(`SELECT _id, status FROM outreach_contacts WHERE _deleted = 0 AND (_id = ? OR LOWER(TRIM(email)) = ?)`, send.contact_id || 0, email);
  for (const c of contacts) {
    if (L.M.statusOf(c) === 'Active') ops.push({ op: 'update', table: 'outreach_contacts', id: c._id, data: { status: 'Unsubscribed', status_at: L.sqlNow(), status_note: why } });
  }
  ops.push(...L.suppressOps(email, 'Unsubscribed', why));
  const pending = L.all(`SELECT _id, status FROM outreach_sends WHERE _deleted = 0 AND status IN ('Queued', 'In review')
    AND (LOWER(TRIM(email)) = ?${contacts.length ? ` OR contact_id IN (${contacts.map(() => '?').join(',')})` : ''})`, email, ...contacts.map((c) => c._id));
  for (const p of pending) ops.push({ op: 'update', table: 'outreach_sends', id: p._id, when: { status: p.status }, data: { status: 'Cancelled', error: 'They unsubscribed' } });
  L.write(ops);
  return L.done({ ok: true, ran: 'unsubscribe', email: send._id, contacts: contacts.map((c) => c._id), cancelled: pending.length });
}

try {
  main();
} catch (e) {
  process.stderr.write(`unsubscribe: ${e.message}\n`);
  process.exit(1);
}
