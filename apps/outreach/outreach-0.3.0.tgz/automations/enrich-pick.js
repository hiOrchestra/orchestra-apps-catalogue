#!/usr/bin/env node
'use strict';
/**
 * Find emails, step 1: pick the contacts to look up and claim them.
 *
 * Contacts without an address, never looked up, in the stages Settings lists
 * (in that order: the first stage goes first), up to "per run". Each is marked
 * Searching before anyone looks, so the next run does not pick it again; one
 * left Searching for two hours was dropped by a run that died and goes back
 * in line. Prints the list as JSON for the agent step that follows.
 */
const L = require('./lib');

function main() {
  const s = L.settings();
  const stages = L.jsonList(s.enrich_stages);
  const per = Math.max(1, Math.min(25, Number(s.enrich_per_run) || 10));

  const stale = L.all(`SELECT _id FROM outreach_contacts WHERE _deleted = 0 AND email_status = 'Searching'
    AND datetime(email_checked_at) <= datetime('now', '-2 hours')`);
  for (const r of stale) {
    try { L.write([{ op: 'update', table: 'outreach_contacts', id: r._id, data: { email_status: null }, when: { email_status: 'Searching' } }]); } catch { /* moved on */ }
  }

  const picked = [];
  for (const stage of stages) {
    if (picked.length >= per) break;
    picked.push(...L.all(`SELECT _id, name, organization, website, country, kind, focus, email_status FROM outreach_contacts
      WHERE _deleted = 0 AND stage = ? AND (email IS NULL OR TRIM(email) = '')
        AND (email_status IS NULL OR email_status = '') AND COALESCE(status, 'Active') = 'Active'
      ORDER BY _id LIMIT ?`, stage, per - picked.length));
  }

  const claimed = [];
  for (const c of picked) {
    try {
      L.write([{ op: 'update', table: 'outreach_contacts', id: c._id, when: { email_status: c.email_status },
        data: { email_status: 'Searching', email_checked_at: L.sqlNow() } }]);
      claimed.push({
        id: c._id, name: c.name || null, organization: c.organization || null, website: c.website || null,
        country: c.country || null, kind: c.kind || null, focus: c.focus || null,
      });
    } catch { /* someone else took it */ }
  }
  return L.done({ contacts: claimed });
}

try {
  main();
} catch (e) {
  process.stderr.write(`find emails: ${e.message}\n`);
  process.exit(1);
}
