#!/usr/bin/env node
'use strict';
/**
 * Send, for SEQUENCES: the oldest queued email of an active sequence, through
 * Resend, one per run — and only when Settings allow it: not paused, inside the sending window
 * (days, hours, time zone), under the daily cap, and at least "every" minutes
 * after the previous one. Whatever it decides, it writes when the next one is
 * due (settings.next_send_at), which is what its schedule checks: runs happen
 * when a send is due, not every tick.
 *
 * A send is CLAIMED before Resend is called (Queued → Sending, atomic), so an
 * email cancelled meanwhile never leaves and no email leaves twice. A send left
 * Sending by a run that died is marked Failed with what is known — never
 * retried blind, because it may have gone out.
 *
 * The email leaves in the campaign's format, with the footer from Settings
 * and, when the campaign has one, its unsubscribe link (and the
 * List-Unsubscribe header). Broadcasts are sent by broadcast.js.
 *
 *   --force   ignore "not due yet" (a person pressed Send now); the window,
 *             the cap and the pause still hold.
 */
const L = require('./lib');

const FORCE = process.argv.includes('--force');

async function main() {
  const s = L.settings();
  const sch = L.schedule(s);
  const now = new Date();
  const out = { ok: true, ran: 'send' };
  const setNext = (when, sent) => {
    const data = { next_send_at: when ? L.sqlNow(when) : null };
    if (sent) data.last_sent_at = L.sqlNow();
    L.write([{ op: 'update', table: 'outreach_settings', id: s._id, data }]);
    out.next = data.next_send_at;
  };

  const stale = L.all(`SELECT s._id FROM outreach_sends s JOIN outreach_campaigns k ON k._id = s.campaign_id
    WHERE s._deleted = 0 AND COALESCE(k.kind, 'sequence') = 'sequence' AND s.status = 'Sending'
    AND datetime(s.lock_at) <= datetime('now', '-15 minutes')`);
  if (stale.length) {
    L.write(stale.map((r) => ({
      op: 'update', table: 'outreach_sends', id: r._id, when: { status: 'Sending' },
      data: { status: 'Failed', error: 'The send did not finish, so it may or may not have gone out. Check Resend before retrying it.' },
    })));
    out.unfinished = stale.length;
  }

  if (Number(s.paused) === 1) return L.done({ ...out, skipped: 'Sending is paused in Settings' });
  if (!L.fromAddress(s)) return L.done({ ...out, skipped: 'No sender address in Settings' });

  const due = L.toDate(s.next_send_at);
  if (!FORCE && due && due > now) return L.done({ ...out, skipped: `Not due until ${s.next_send_at} UTC` });
  if (!L.inWindow(now, sch)) {
    setNext(L.nextOpen(now, sch));
    return L.done({ ...out, skipped: 'Outside the sending window' });
  }
  // The daily cap counts sequences only: a broadcast has its own.
  const today = L.one(`SELECT COUNT(*) AS n FROM outreach_sends s JOIN outreach_campaigns k ON k._id = s.campaign_id
    WHERE s._deleted = 0 AND COALESCE(k.kind, 'sequence') = 'sequence'
    AND s.status IN ('Sending', 'Sent', 'Replied', 'Bounced')
    AND datetime(COALESCE(s.sent_at, s.lock_at)) >= datetime(?)`, L.sqlNow(L.dayStart(now, sch.tz))).n;
  if (today >= sch.cap) {
    setNext(L.nextOpen(L.nextDay(now, sch.tz), sch));
    return L.done({ ...out, skipped: `The daily cap of ${sch.cap} is reached` });
  }

  for (let attempt = 0; attempt < 10; attempt += 1) {
    const r = L.one(`SELECT s.* FROM outreach_sends s JOIN outreach_campaigns k ON k._id = s.campaign_id
      WHERE s._deleted = 0 AND k._deleted = 0 AND s.status = 'Queued' AND k.status = 'Active' AND COALESCE(k.kind, 'sequence') = 'sequence'
      ORDER BY datetime(s.queued_at), s._id LIMIT 1`);
    if (!r) return L.done({ ...out, skipped: 'Nothing is queued' });

    // Checked again here: an address may have been listed since it was queued.
    let blocked = L.suppressedWhy(r.email);
    const contact = r.contact_id ? L.one('SELECT * FROM outreach_contacts WHERE _id = ? AND _deleted = 0', r.contact_id) : null;
    if (!blocked && contact && L.M.statusOf(contact) !== 'Active') {
      blocked = `The contact is ${L.M.STATUS_LABEL[L.M.statusOf(contact)].toLowerCase()}`;
    }
    if (!blocked && !L.EMAIL.test(L.normEmail(r.email))) blocked = 'The address is not valid';
    if (!blocked && L.one(`SELECT 1 AS x FROM outreach_sends WHERE _deleted = 0 AND campaign_id = ? AND _id <> ?
      AND status IN ('Sending', 'Sent', 'Replied', 'Bounced') AND LOWER(TRIM(email)) = ?`, r.campaign_id, r._id, L.normEmail(r.email))) {
      blocked = 'This campaign already wrote to this address';
    }
    if (blocked) {
      try {
        L.write([{ op: 'update', table: 'outreach_sends', id: r._id, when: { status: 'Queued' }, data: { status: 'Cancelled', error: blocked } }]);
      } catch { /* taken meanwhile */ }
      out.cancelled = (out.cancelled || []).concat({ id: r._id, why: blocked });
      continue;
    }

    try {
      L.write([{ op: 'update', table: 'outreach_sends', id: r._id, when: { status: 'Queued' }, data: { status: 'Sending', lock_at: L.sqlNow() } }]);
    } catch {
      continue; // cancelled or taken meanwhile: the next one
    }

    // The sender as the campaign and Settings say NOW, not as they were when
    // the email was written: fixing the sender and sending a failed email
    // again must work. The row records what actually went out.
    const k = L.one('SELECT * FROM outreach_campaigns WHERE _id = ?', r.campaign_id) || {};
    const { from, replyTo, brand } = L.senderOf(k, s);
    const link = Number(k.unsubscribe_link) === 1 ? L.unsubUrl(s, r._id) : null;
    const email = L.M.compose({
      format: k.format, subject: r.subject, body: r.body, contact: contact || { name: r.name, email: r.email }, settings: s, unsubUrl: link, brand,
    });
    const args = L.resendMessage({ from, to: L.normEmail(r.email), replyTo, email, unsubscribe: link });
    try {
      const res = await L.composio('RESEND_SEND_EMAIL', args);
      const id = L.pick(res, 'id');
      L.write([{ op: 'update', table: 'outreach_sends', id: r._id, data: {
        status: 'Sent', sent_at: L.sqlNow(), provider_id: id ? String(id) : null, error: null, from_address: from, reply_to: replyTo,
      } }]);
      out.sent = { id: r._id, to: args.to, provider_id: id || null };
    } catch (e) {
      L.write([{ op: 'update', table: 'outreach_sends', id: r._id, data: { status: 'Failed', error: String(e.message || e).slice(0, 300), from_address: from } }]);
      out.failed = { id: r._id, to: args.to, error: String(e.message || e).slice(0, 300) };
    }
    // On the minute: a run starts a few seconds after its tick, so "sent + every"
    // to the second would be due just after the tick it means, and the email would
    // wait a whole extra tick (every 40 minutes instead of 30).
    const next = new Date(Date.now() + sch.every * 60000);
    next.setUTCSeconds(0, 0);
    setNext(L.nextOpen(next, sch), true);
    return L.done(out);
  }
  return L.done(out);
}

main().catch((e) => {
  process.stderr.write(`send: ${e.message}\n`);
  process.exit(1);
});
