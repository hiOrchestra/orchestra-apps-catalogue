#!/usr/bin/env node
'use strict';
/**
 * Add to a list: the people behind one number of a campaign's report ("the
 * ones who replied", "the ones who did not open") join a list, so the next
 * campaign can write to them. The list is created when it is new.
 *   node make-list.js <campaign id> <which> <list name>
 * which: sent, replied, not_replied, delivered, opened, not_opened, clicked,
 *        bounced, complained, unsubscribed, failed, all
 */
const L = require('./lib');

const WHICH = {
  all: "1 = 1",
  sent: "s.status IN ('Sent', 'Replied', 'Bounced')",
  replied: "s.status = 'Replied'",
  not_replied: "s.status = 'Sent'",
  delivered: "s.status IN ('Sent', 'Replied') AND s.last_event IN ('delivered', 'opened', 'clicked')",
  opened: "s.last_event IN ('opened', 'clicked')",
  not_opened: "s.status IN ('Sent', 'Replied') AND COALESCE(s.last_event, '') NOT IN ('opened', 'clicked', 'bounced', 'complained')",
  clicked: "s.last_event = 'clicked'",
  bounced: "(s.status = 'Bounced' OR s.last_event = 'bounced')",
  complained: "s.last_event = 'complained'",
  unsubscribed: 's.unsubscribed_at IS NOT NULL',
  failed: "s.status = 'Failed'",
};

function main() {
  const id = Number(process.argv[2]);
  const which = String(process.argv[3] || '');
  const list = String(process.argv[4] || '').replace(/\|/g, '/').trim().slice(0, 80);
  if (!Number.isInteger(id) || id <= 0) throw new Error('which campaign? pass its id');
  if (!WHICH[which]) throw new Error(`"${which}" is not one of ${Object.keys(WHICH).join(', ')}`);
  if (!list) throw new Error('name the list');
  const rows = L.all(`SELECT DISTINCT c._id, c.tags FROM outreach_sends s JOIN outreach_contacts c ON c._id = s.contact_id
    WHERE s._deleted = 0 AND c._deleted = 0 AND s.campaign_id = ? AND ${WHICH[which]}`, id);
  const tagsOf = (t) => String(t || '').split('|').map((x) => x.trim()).filter(Boolean);
  const ops = [];
  for (const c of rows) {
    const now = tagsOf(c.tags);
    if (now.includes(list)) continue;
    ops.push({ op: 'update', table: 'outreach_contacts', id: c._id, data: { tags: `|${[...now, list].join('|')}|` } });
  }
  L.write(ops);
  const s = L.settings();
  const known = L.jsonList(s.tags);
  if (!known.includes(list)) {
    L.write([{ op: 'update', table: 'outreach_settings', id: s._id, data: { tags: JSON.stringify([...known, list].sort((a, b) => a.localeCompare(b))) } }]);
  }
  return L.done({ ok: true, ran: 'add to a list', campaign: id, which, list, matched: rows.length, added: ops.length });
}

try {
  main();
} catch (e) {
  process.stderr.write(`add to a list: ${e.message}\n`);
  process.exit(1);
}
