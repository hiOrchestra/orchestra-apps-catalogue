// The public unsubscribe page of Outreach. The link in an email carries a
// signed token after the # (never sent to a server log); pressing the button
// runs the declared public action, which starts the Unsubscribe workflow. The
// page itself reads nothing: it cannot say whose address it is, only what
// happens. A button, not a visit, unsubscribes: mail scanners open links.
const { el, mount } = Orch;

const hash = String(location.hash || '').replace(/^#\/?\??/, '');
const token = new URLSearchParams(hash).get('t') || '';

function show(title, text, extra) {
  mount('view', el('div', { class: 'un-card' }, [el('h1', { class: 'oc-h1' }, title), el('p', { class: 'un-text' }, text), extra || null]));
}

function ask() {
  const button = el('button', { class: 'oc-btn oc-btn--primary', type: 'button' }, 'Unsubscribe');
  button.addEventListener('click', async () => {
    button.disabled = true;
    button.textContent = 'Unsubscribing…';
    try {
      await Orch.action('unsubscribe', { token });
      show('You are unsubscribed', 'You will not get more of these emails. It can take a minute to reach every list.');
    } catch (e) {
      button.disabled = false;
      button.textContent = 'Unsubscribe';
      Orch.toast(e && e.status === 429 ? 'Too many tries: wait a minute and press it again.' : 'That did not work. Press it again in a minute.', { error: true });
    }
  });
  show('Unsubscribe?', 'You will stop getting these emails, from every campaign.', el('div', { class: 'un-actions' }, [button]));
}

if (!token) show('This link is incomplete', 'Open it again from the email, or reply to the email and ask to be taken off.');
else if (token === 'test') show('This is a test link', 'It comes from a test email, so it unsubscribes nobody.');
else ask();
