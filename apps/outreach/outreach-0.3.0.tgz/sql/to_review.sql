SELECT s._id AS _id, s.campaign_id AS campaign_id, k.name AS campaign, s.contact_id AS contact_id,
  s.name AS name, s.organization AS organization, s.email AS email, s.subject AS subject,
  datetime(s.queued_at) AS written_at
FROM outreach_sends s
JOIN outreach_campaigns k ON k._id = s.campaign_id
WHERE s.status = 'In review'
