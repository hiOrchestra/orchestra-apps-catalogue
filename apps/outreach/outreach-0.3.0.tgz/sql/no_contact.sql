SELECT p._id AS _id, p.email AS email, p.reason AS reason, p.note AS note, datetime(p._created_at) AS added_at
FROM outreach_suppressions p
WHERE COALESCE(p.active, 1) = 1
