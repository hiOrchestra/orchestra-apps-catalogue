SELECT k._id AS _id, k.name AS name, COALESCE(NULLIF(k.kind, ''), 'sequence') AS kind, k.status AS status, k.mode AS mode,
  k.description AS description, COALESCE(NULLIF(k.format, ''), 'text') AS format, k.subject AS subject, k.recipients AS recipients,
  COALESCE(k.unsubscribe_link, 0) AS unsubscribe_link,
  COALESCE(k.skip_contacted, CASE WHEN k.kind = 'broadcast' THEN 0 ELSE 1 END) AS skip_contacted,
  k.from_name AS from_name, k.from_email AS from_email, k.reply_to AS reply_to, k.template_id AS template_id,
  k.problem AS problem, k.note AS note, k.estimate AS estimate, k.test_result AS test_result, k.total AS total,
  datetime(k.scheduled_at) AS scheduled_at, datetime(k.started_at) AS started_at, datetime(k.finished_at) AS finished_at,
  datetime(k.activated_at) AS activated_at, datetime(k.last_queued_at) AS last_queued_at, datetime(k._created_at) AS created_at,
  CASE k.status WHEN 'Sending' THEN 1 WHEN 'Active' THEN 1 WHEN 'Scheduled' THEN 2 WHEN 'Paused' THEN 3 WHEN 'Draft' THEN 4 ELSE 5 END AS rank,
  COALESCE(n.in_review, 0) AS in_review, COALESCE(n.queued, 0) AS queued, COALESCE(n.sent, 0) AS sent,
  COALESCE(n.replied, 0) AS replied, COALESCE(n.failed, 0) AS failed, COALESCE(n.bounced, 0) AS bounced,
  COALESCE(n.complained, 0) AS complained, COALESCE(n.unsubscribed, 0) AS unsubscribed, COALESCE(n.delivered, 0) AS delivered,
  COALESCE(n.opened, 0) AS opened, COALESCE(n.clicked, 0) AS clicked, COALESCE(n.cancelled, 0) AS cancelled,
  n.last_sent_at AS last_sent_at,
  COALESCE(n.last_sent_at, datetime(k.scheduled_at), datetime(k._updated_at)) AS at,
  a.name AS audience, a.filter AS audience_filter, t.name AS template
FROM outreach_campaigns k
LEFT JOIN outreach_audiences a ON a._id = k.audience_id
LEFT JOIN outreach_templates t ON t._id = k.template_id
LEFT JOIN (
  SELECT campaign_id,
    SUM(status = 'In review') AS in_review,
    SUM(status IN ('Queued', 'Sending', 'Retry')) AS queued,
    SUM(status IN ('Sent', 'Replied', 'Bounced')) AS sent,
    SUM(status = 'Replied') AS replied,
    SUM(status = 'Failed') AS failed,
    SUM(status = 'Bounced' OR last_event = 'bounced') AS bounced,
    SUM(last_event = 'complained') AS complained,
    SUM(unsubscribed_at IS NOT NULL) AS unsubscribed,
    SUM(last_event IN ('delivered', 'opened', 'clicked')) AS delivered,
    SUM(last_event IN ('opened', 'clicked')) AS opened,
    SUM(last_event = 'clicked') AS clicked,
    SUM(status = 'Cancelled') AS cancelled,
    datetime(MAX(sent_at)) AS last_sent_at
  FROM outreach_sends GROUP BY campaign_id
) n ON n.campaign_id = k._id
