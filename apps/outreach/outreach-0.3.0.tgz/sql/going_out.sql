SELECT s._id AS _id, s.campaign_id AS campaign_id, k.name AS campaign, k.status AS campaign_status,
  s.contact_id AS contact_id, s.name AS name, s.organization AS organization, s.email AS email, s.subject AS subject,
  datetime(s.queued_at) AS queued_at,
  CASE WHEN k.status = 'Active'
    THEN ROW_NUMBER() OVER (PARTITION BY k.status = 'Active' ORDER BY datetime(s.queued_at), s._id) END AS position
FROM outreach_sends s
JOIN outreach_campaigns k ON k._id = s.campaign_id
WHERE s.status = 'Queued' AND COALESCE(NULLIF(k.kind, ''), 'sequence') = 'sequence'
