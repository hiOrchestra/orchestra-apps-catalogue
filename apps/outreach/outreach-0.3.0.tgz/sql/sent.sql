SELECT s._id AS _id, s.campaign_id AS campaign_id, k.name AS campaign, COALESCE(NULLIF(k.kind, ''), 'sequence') AS kind,
  s.contact_id AS contact_id, s.name AS name, s.organization AS organization, s.email AS email, s.subject AS subject,
  s.status AS status, s.error AS error, s.last_event AS last_event, s.reply_status AS reply_status,
  CASE WHEN s.last_event IN ('delivered', 'opened', 'clicked') THEN 'yes' ELSE 'no' END AS delivered,
  CASE WHEN s.last_event IN ('opened', 'clicked') THEN 'yes' ELSE 'no' END AS opened,
  CASE WHEN s.last_event = 'clicked' THEN 'yes' ELSE 'no' END AS clicked,
  CASE WHEN s.last_event = 'complained' THEN 'yes' ELSE 'no' END AS complained,
  CASE WHEN s.status = 'Bounced' OR s.last_event = 'bounced' THEN 'yes' ELSE 'no' END AS bounced,
  CASE WHEN s.status IN ('Sent', 'Replied') AND COALESCE(s.last_event, '') NOT IN ('opened', 'clicked', 'bounced', 'complained') THEN 'yes' ELSE 'no' END AS not_opened,
  CASE WHEN s.unsubscribed_at IS NOT NULL THEN 'yes' ELSE 'no' END AS unsubscribed,
  datetime(COALESCE(s.sent_at, s._updated_at)) AS at, datetime(s.sent_at) AS sent_at,
  datetime(s.replied_at) AS replied_at, datetime(s.unsubscribed_at) AS unsubscribed_at
FROM outreach_sends s
LEFT JOIN outreach_campaigns k ON k._id = s.campaign_id
WHERE s.status IN ('Sending', 'Retry', 'Sent', 'Replied', 'Bounced', 'Failed', 'Cancelled')
