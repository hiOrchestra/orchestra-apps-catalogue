// Outreach, installed into one project of this instance: tables and indexes,
// the seed (settings, contact fields, a starter template, two audiences, only
// into empty tables), the automations (scripts, workflows, the schedules that
// only run when there is work), the desk (`outreach`) and its public
// unsubscribe page (`outreach-unsubscribe`) with their grants, views, actions,
// brand and brief, and the settings that name where the page lives.
// Converges: run it again after a change and it ends in the same state.
//
//   node install.js <bundle dir> --project <p> --agent <id> [--only files,tables,…]
//
// The apps catalogue runs it as node (openclaw-railway services/apps-catalogue.js)
// and then, with the admin's consent, approves the tables, opens the
// unsubscribe page to the public and publishes both apps. The team can run it
// the same way over ssh (`gosu node node …`). Every workflow runs as --agent,
// and the email lookup asks that same agent. Prints one JSON line per step,
// and at the end what a person still has to do.
'use strict';
const { execFileSync } = require('child_process');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const B = path.resolve(process.argv[2] || __dirname);
const flag = (name, fallback) => { const i = process.argv.indexOf(`--${name}`); return i > 0 && process.argv[i + 1] ? process.argv[i + 1] : fallback; };
const PROJECT = flag('project', 'default');
const AGENT = flag('agent', '');
const ONLY = new Set((flag('only', 'files,tables,seed,workflows,schedule,desk,public,settings')).split(','));
const STATE = process.env.OPENCLAW_STATE_DIR || '/home/node/.openclaw';
const HOME = path.join(STATE, 'orchestra', 'projects', PROJECT);
const AUTO = path.join(HOME, 'apps', 'outreach', 'automations');
const DESK = 'outreach';
const PAGE = 'outreach-unsubscribe';
const read = (f) => fs.readFileSync(path.join(B, f), 'utf8');
const json = (f) => JSON.parse(read(f));
const todo = [];
const out = (step, data) => console.log(JSON.stringify(Object.assign({ step }, data)));

function cli(bin, args, { soft = false } = {}) {
  let text;
  try {
    text = execFileSync(bin, args, { encoding: 'utf8', timeout: 100000, maxBuffer: 32 << 20 });
  } catch (e) {
    text = String(e.stdout || '') || String(e.stderr || e.message);
    if (!soft) out('warn', { bin, args: args.slice(0, 3), said: text.trim().slice(0, 300) });
  }
  try { return JSON.parse(text); } catch { return { raw: String(text).trim().slice(0, 600) }; }
}
const db = (...a) => cli('orch-database', ['--project', PROJECT, ...a]);
const canvas = (...a) => cli('orch-canvas', a);
const wf = (...a) => cli('orch-workflows', a);
const pick = (o, keys) => Object.fromEntries(keys.filter((k) => o && o[k] !== undefined).map((k) => [k, o[k]]));
const ids = () => { try { return JSON.parse(fs.readFileSync(path.join(AUTO, '..', 'workflows.json'), 'utf8')); } catch { return {}; } };
const settingsRow = () => (db('query', 'SELECT * FROM outreach_settings WHERE _deleted = 0 ORDER BY _id LIMIT 1').rows || [])[0];

if ((ONLY.has('workflows') || ONLY.has('seed') || ONLY.has('settings')) && !AGENT) {
  throw new Error('--agent <id> names the agent the workflows run as and that looks up missing emails (a member of the project)');
}

// ── 1. the automation scripts ────────────────────────────────────────────
if (ONLY.has('files')) {
  fs.mkdirSync(AUTO, { recursive: true });
  for (const f of fs.readdirSync(path.join(B, 'automations'))) fs.copyFileSync(path.join(B, 'automations', f), path.join(AUTO, f));
  out('files', { dir: AUTO, files: fs.readdirSync(AUTO) });
}

// ── 2. tables and indexes ────────────────────────────────────────────────
const schema = json('schema.json');
if (ONLY.has('tables')) {
  for (const [table, cols] of Object.entries(schema.tables)) {
    out('table', Object.assign({ table }, pick(db('ensure-table', table, '--columns', ...cols), ['ok', 'action', 'created', 'added', 'error', 'raw'])));
  }
  // Partial and expression indexes (one pending email per contact, one contact
  // per address) straight on the project's database, as node; through the CLI
  // when this process cannot open it.
  let conn = null;
  try {
    const { DatabaseSync } = require('node:sqlite');
    conn = new DatabaseSync(path.join(HOME, 'data', 'data.db'));
    conn.exec('PRAGMA busy_timeout = 8000');
  } catch { conn = null; }
  for (const sql of schema.indexes) {
    if (conn) {
      try { conn.exec(sql); out('index', { sql: sql.slice(0, 80), ok: true }); } catch (e) { out('index', { sql: sql.slice(0, 80), ok: false, error: e.message }); }
    } else out('index', Object.assign({ sql: sql.slice(0, 80) }, pick(db('sql', sql, '--confirm'), ['ok', 'error', 'raw'])));
  }
  if (conn) conn.close();
}

// ── 3. seed, only into empty tables ──────────────────────────────────────
if (ONLY.has('seed')) {
  const count = (t) => (((db('query', `SELECT COUNT(*) AS n FROM ${t} WHERE _deleted = 0`).rows || [{}])[0]) || {}).n;
  for (const [table, rows] of Object.entries(json('seed.json'))) {
    if (count(table) > 0) { out('seed', { table, left: 'it has rows' }); continue; }
    const data = rows.map((r) => Object.assign({}, r));
    if (table === 'outreach_settings') Object.assign(data[0], { enrich_agent: AGENT, unsubscribe_secret: crypto.randomBytes(32).toString('hex') });
    out('seed', Object.assign({ table }, pick(db('insert-many', table, '--data', JSON.stringify(data)), ['ok', 'count', 'inserted', 'error', 'raw'])));
  }
}

// ── 4. workflows (by name: created once, updated after) ─────────────────
const KEYS = ['queue', 'send', 'enrich', 'status', 'broadcast', 'recipients', 'test', 'import', 'makelist', 'unsubscribe', 'check'];
if (ONLY.has('workflows')) {
  const existing = wf('list').workflows || [];
  const WF = {};
  const tmp = fs.mkdtempSync(path.join(require('os').tmpdir(), 'outreach-wf-'));
  for (const key of KEYS) {
    // runsAs: the scripts run as this agent (orch-as), so it must be a member of the project to reach its database.
    const spec = Object.assign(JSON.parse(read(`workflows/${key}.json`).replace(/__AUTO__/g, AUTO).replace(/__AGENT__/g, AGENT)),
      { project: PROJECT, runsAs: AGENT });
    const file = path.join(tmp, `${key}.json`);
    fs.writeFileSync(file, JSON.stringify(spec));
    const found = existing.find((w) => w.name === spec.name);
    const r = found ? wf('update', found.id, '--file', file) : wf('create', '--file', file);
    WF[key] = found ? found.id : ((r.workflow && r.workflow.id) || r.id || r.workflowId);
    out('workflow', { name: spec.name, id: WF[key], did: found ? 'updated' : 'created', ok: r.ok !== false && !!WF[key], error: r.error || undefined });
  }
  fs.rmSync(tmp, { recursive: true, force: true });
  fs.writeFileSync(path.join(AUTO, '..', 'workflows.json'), JSON.stringify(WF, null, 1));
}

// ── 5. schedules: a fan-out over the settings row, true only when there is work ──
// An idle tick creates no run. Nothing goes out on its own: a broadcast is
// sent or scheduled by a person, a sequence is started by a person.
if (ONLY.has('schedule')) {
  const WF = ids();
  for (const [key, cron, name] of [
    ['broadcast', '*/5 * * * *', 'Outreach · Broadcast (every 5 minutes, while one is due or sending)'],
    ['queue', '5,35 * * * *', 'Outreach · Write emails (half-hourly, while a sequence is active)'],
    ['send', '*/10 * * * *', 'Outreach · Send (every 10 minutes, when a sequence email is due)'],
    ['status', '20 * * * *', 'Outreach · Bounces (hourly, when a sent email is due a check)'],
    ['enrich', '15,45 * * * *', 'Outreach · Find emails (half-hourly, when contacts have none)'],
  ]) {
    if (!WF[key]) { out('schedule', { workflow: key, ok: false, error: 'not created yet: run --only workflows first' }); continue; }
    for (const s of (wf('schedules', WF[key]).schedules || [])) out('unschedule', pick(wf('unschedule', s.jobId), ['ok', 'error']));
    out('schedule', Object.assign({ workflow: key }, pick(wf('schedule', WF[key], '--cron', cron, '--timezone', 'UTC', '--name', name,
      '--table', 'outreach_settings', '--where', read(`workflows/${key}.where`), '--limit', '1'), ['ok', 'jobId', 'schedule', 'error', 'raw'])));
  }
}

// ── 6. the apps ──────────────────────────────────────────────────────────
function app(id, src, brief) {
  let a = (canvas('list').apps || []).find((x) => x.id === id);
  if (!a) {
    out('init', Object.assign({ app: id }, pick(canvas('init', id, '--project', PROJECT, '--pattern', 'list', '--confirmed', ...brief), ['ok', 'dir', 'url', 'error', 'raw'])));
    a = (canvas('list').apps || []).find((x) => x.id === id);
  }
  if (!a) throw new Error(`The app ${id} could not be created`);
  const dir = path.join(STATE, 'orchestra', a.dir);
  const ours = new Set();
  const copy = (from, to) => {
    for (const f of fs.readdirSync(from)) {
      const s = path.join(from, f);
      const d = path.join(to, f);
      if (fs.statSync(s).isDirectory()) { fs.mkdirSync(d, { recursive: true }); copy(s, d); } else { fs.copyFileSync(s, d); ours.add(path.relative(dir, d)); }
    }
  };
  copy(path.join(B, src), dir);
  // What the starter wrote and Outreach does not use goes, so the app is exactly the source.
  const sweep = (d) => {
    for (const f of fs.readdirSync(d)) {
      const p = path.join(d, f);
      const rel = path.relative(dir, p);
      if (rel.startsWith('_') || rel.startsWith('.')) continue;
      if (fs.statSync(p).isDirectory()) sweep(p); else if (!ours.has(rel)) { fs.unlinkSync(p); out('removed', { app: id, file: rel }); }
    }
  };
  sweep(dir);
  out('files', { app: id, dir, count: ours.size });
  return a;
}

function actions(id, list) {
  const WF = ids();
  const sub = (v) => (typeof v === 'string' && v.startsWith('$WF_') ? WF[v.slice(4).toLowerCase()] : v);
  for (const a of list) {
    const args = ['action', 'add', id, '--name', a.name, '--type', a.type, '--access', a.access || 'members'];
    if (a.table) args.push('--table', a.table);
    if (a.fields) args.push('--fields', a.fields.join(','));
    if (a.defaults) args.push('--defaults', JSON.stringify(a.defaults));
    if (a.precondition) args.push('--precondition', JSON.stringify(a.precondition));
    if (a.bulk) args.push('--bulk');
    if (a.workflow) args.push('--workflow', sub(a.workflow));
    if (a.args) args.push('--args', JSON.stringify(a.args));
    if (a.trigger) args.push('--trigger-workflow', sub(a.trigger));
    out('action', Object.assign({ app: id, name: a.name }, pick(canvas(...args), ['ok', 'error', 'raw'])));
  }
}

function brand(id, spec) {
  const args = ['brand', 'set', id, '--preset', spec.preset];
  for (const [k, v] of Object.entries(spec.brand || {})) args.push(`--${k}`, v);
  out('brand', Object.assign({ app: id }, pick(canvas(...args), ['ok', 'error', 'raw'])));
}

const VIEWS = {
  campaigns: 'Each campaign with its recipients, progress and results', going_out: 'Queued sequence emails in the order they leave, with their place',
  to_review: 'Emails of review-first sequences waiting for a yes', sent: 'Every email that left, or will not, with why',
  contacts: 'Contacts with their status, where their email stands and their last email', audiences: 'Audiences with the campaigns using them',
  templates: 'Templates with the campaigns made from them', no_contact: 'The no-contact list',
  lists: 'Each list with how many can be written to, unsubscribed and bounced',
};

if (ONLY.has('desk')) {
  app(DESK, 'app', ['--name', 'Outreach', '--icon', '✉️', '--desc', 'Newsletters and email campaigns sent through Resend: contacts, lists, audiences, templates, broadcasts and sequences',
    '--user', 'Whoever sends the company\'s newsletters, announcements and outreach: marketing, sales, the founder',
    '--frequency', 'A few times a week',
    '--question', 'Who gets this email, and who is left out and why?',
    '--question', 'What went out, and who opened, replied, unsubscribed or bounced?',
    '--question', 'What is going out next?',
    '--primary-action', 'Write an email, pick its lists and audiences, send yourself a test, then send or schedule it (or start a sequence)']);
  const grants = Object.keys(schema.tables).map((t) => `${t}:${t === 'outreach_fields' ? 'read' : 'action'}`);
  // One --grant with every table: the flag is nargs="*", so repeating it keeps only the last.
  const g = canvas('grants', 'set', DESK, '--grant', ...grants);
  out('grants', Object.assign({ app: DESK }, pick(g, ['ok', 'grants', 'pendingApproval', 'error', 'raw'])));
  if ((g.pendingApproval || []).length) todo.push(`Approve the tables Outreach asks for: ${g.pendingApproval.map((x) => x.table || x).join(', ')} (Canvas → Outreach → who gets in)`);
  for (const f of fs.readdirSync(path.join(B, 'sql'))) {
    const name = f.replace(/\.sql$/, '');
    const r = canvas('view', 'add', DESK, '--name', name, '--sql-file', path.join(B, 'sql', f), '--description', VIEWS[name] || name.replace(/_/g, ' '));
    out('view', Object.assign({ app: DESK, name }, pick(r, ['ok', 'reads', 'pending', 'error', 'raw'])));
  }
  actions(DESK, json('actions.json'));
  brand(DESK, json('brand.json')[DESK]);
  out('brief', pick(canvas('brief', 'set', DESK, '--density', 'compact', '--variety', 'focused', '--confirmed'), ['ok', 'error', 'raw']));
}

if (ONLY.has('public')) {
  app(PAGE, 'unsubscribe', ['--name', 'Unsubscribe', '--icon', '✉️', '--desc', 'The public page an Outreach email links to: one button that unsubscribes the reader from every campaign',
    '--user', 'Anyone who got an Outreach email and wants no more',
    '--frequency', 'Once, from a link in an email',
    '--question', 'Do I want to stop getting these emails?',
    '--primary-action', 'Press Unsubscribe: they are taken off every campaign']);
  actions(PAGE, [{ name: 'unsubscribe', type: 'workflow.run', workflow: '$WF_UNSUBSCRIBE', access: 'public' }]);
  brand(PAGE, json('brand.json')[PAGE]);
  todo.push('Set Unsubscribe (outreach-unsubscribe) to Public, and publish both apps (Canvas → the app → History)');
}

// ── 7. settings: where the unsubscribe page lives, the agent, the version ──
if (ONLY.has('settings')) {
  const s = settingsRow();
  if (s) {
    const url = (id) => { const u = canvas('url', id).url || ''; return u.endsWith('/') ? u : (u ? `${u}/` : ''); };
    const data = { enrich_agent: AGENT, installed_version: read('VERSION').trim() };
    if (!s.unsubscribe_secret) data.unsubscribe_secret = crypto.randomBytes(32).toString('hex');
    if (!s.unsubscribe_url) {
      const domain = String(process.env.RAILWAY_PUBLIC_DOMAIN || '').trim();
      data.unsubscribe_url = url(PAGE) || (domain ? `https://${domain}/canvas/a/${PAGE}/` : '');
    }
    const r = db('update', 'outreach_settings', '--id', String(s._id), '--data', JSON.stringify(data));
    out('settings', Object.assign({ enrich_agent: data.enrich_agent, installed_version: data.installed_version, unsubscribe_url: data.unsubscribe_url, secret: data.unsubscribe_secret ? 'created' : 'kept' }, pick(r, ['ok', 'error'])));
    if (!s.resend_ok_at) todo.push('Connect Resend in the portal (Integrations) and verify your sending domain in Resend: Outreach sends nothing until then');
    if (!String(s.from_email || '').trim()) todo.push('Set who the emails come from, a name and an address on that domain (Outreach → Settings → Sender)');
  }
}

out('done', { project: PROJECT, agent: AGENT, a_person_still_has_to: todo });
