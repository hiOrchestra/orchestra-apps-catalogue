---
name: app-outreach
version: 0.3.1
description: >-
  Work with the Outreach app (newsletters, campaigns and prospecting sequences
  sent through the workspace's Resend): contacts, lists, CSV import, missing
  emails, campaign drafts, what goes out, replies, unsubscribes. Use when
  someone says "add these people to the newsletter / añade estos contactos a
  la lista", "import this CSV / importa este CSV", "find their emails / busca
  los emails que faltan", "draft a campaign / arma una campaña", "what goes out
  next / qué sale hoy", "what is waiting for review / qué hay para revisar",
  "who replied / quién respondió", "how did the newsletter do / cómo le fue a
  la campaña", "unsubscribe X / dar de baja a X". Needs the Outreach app
  installed in a project you work in.
metadata:
  openclaw:
    emoji: "✉️"
---
# Outreach: contacts, lists, campaigns, review-first sending

Outreach keeps contacts (one per address), lists, audiences, templates and
campaigns in a project's database, and sends through the workspace's Resend.
A person sends; you prepare, count, look up and report.

```bash
A=$(ls -d ~/.openclaw/orchestra/projects/*/apps/outreach 2>/dev/null | head -1)
P=$(basename "$(dirname "$(dirname "$A")")")   # the project id
D="$A/automations"                              # the app's scripts
orch-canvas url outreach                        # the app's link; screens are #/campaigns/<id>, #/review, #/queue, #/sent, #/contacts
```

If `$A` is empty, Outreach is not installed in a project you work in: say so
and do not improvise a mailing some other way. If several projects have it,
ask which one. Workflow ids: `node -p "require('$A/workflows.json').<key>"`
(keys: enrich, recipients, test, import, makelist, status, queue, send,
broadcast, unsubscribe, check). Read with
`orch-database --project "$P" query "SELECT …"`, always `_deleted = 0`.

## The model

| Table | A row is |
|---|---|
| `outreach_contacts` | One person, one address (unique). `tags` holds its lists as `\|Newsletter\|Customers\|`. `stage` is one of `outreach_settings.stages`. |
| `outreach_campaigns` | A `broadcast` (one email to lists/audiences) or a `sequence` (one email per new recipient, paced). It owns its `subject`, `body`, `format` (`text`, `simple`, `html`), sender and `recipients`. |
| `outreach_sends` | One email to one contact of one campaign, with its status and Resend's `last_event`. |
| `outreach_suppressions` | The no-contact list: an address or a whole `@domain`; `active = 1` counts. |
| `outreach_audiences` / `outreach_templates` | Saved conditions on contacts / starting texts (copied into a campaign, not linked). |
| `outreach_settings` | One row: sender, window, caps, `paused`, list registry `tags`, `stages`, `enrich_stages`. `outreach_imports`: a CSV in parts. |

Contact `status`: `Active` (the only one that gets email), `Unsubscribed`,
`Bounced`, `Complained` (shown "Marked as spam"), `Blocked`. The public
unsubscribe page and the Bounces check set the first three and put the address
on the no-contact list. `email_status` is only the lookup: `Imported`,
`Searching`, `Found` (with `email_source`, the page it was read on), `Not found`.

Campaign `status`: a sequence goes Draft → Active ⇄ Paused → Finished; a
broadcast Draft → Scheduled (back to Draft) → Sending ⇄ Paused → Sent. A
sequence's `mode` is `auto` (queued straight away) or `review` (each email
waits In review). `problem` says what stops it.

Send `status`: `In review`, `Queued`, `Sending` (claimed), `Sent`, `Replied`,
`Bounced`, `Failed`, `Cancelled` (`error` says why), `Retry` (a failed
broadcast email sent again). `last_event`: delivered, opened, clicked,
bounced, complained. `Replied` is set by hand (Sent → Mark as replied):
Outreach does not read the inbox.

Recipients = included lists and audiences minus the excluded, then minus: not
Active, no or bad address, no-contact list, duplicate address, already written
by this campaign, reached by another (`skip_contacted`), another email pending
(sequences), a `{{variable}}` with no value or fallback.

## How you act

- Use the scripts (`node "$D/<script>" …`): `import.js`, `recipients.js`,
  `make-list.js`, `queue.js --dry-run`; and the workflows for the lookup,
  bounces and test sends. Raw writes only where a recipe says, those fields only.
- Nothing goes out without a person: they Send now, Schedule, Start, Resume
  and approve drafts in the app. You never move a campaign out of Draft,
  never approve, retry or re-queue an email, never unpause sending.
- Deleting, archiving or dropping drafts needs an explicit OK naming what is lost.

## Recipes

Add contacts to a list (a CSV, a pasted list, or one person). Always through
an import: it keeps one contact per address, never changes an existing
contact's status, skips addresses on the no-contact list, and registers the list.
1. Build rows keyed by contact columns: `email` (required), `name`,
   `organization`, `title`, `website`, `country`, `city`, `stage`, `notes`, and
   any custom field key from `outreach_fields`. Add `_line` (the CSV line).
   `status`, `tags` and `email_status` are ignored.
2. Insert one part per ~80 KB of rows, then run it:
   ```bash
   K=agent$(date +%s)
   orch-database --project "$P" insert outreach_imports --data "$(node -e '
     const rows = require("/tmp/rows.json");
     console.log(JSON.stringify({import_key: process.argv[1], part: 1, parts: 1, file_name: "contacts.csv",
       list_name: "Newsletter", overwrite: 0, rows: JSON.stringify(rows), status: "Uploaded"}))' "$K")"
   node "$D/import.js" "$K"     # added, updated, unchanged, not_active, skipped
   ```
   `overwrite: 1` replaces values contacts already have; ask first. Skipped
   lines and why: `SELECT result FROM outreach_imports WHERE import_key = '<K>' AND part = 1`.

Find missing emails. Every :15 and :45 the Find emails workflow takes up to
`enrich_per_run` Active contacts with no email and no lookup yet, in the stages
of `enrich_stages` (first stage first), and the project agent reads a source
page for each. To include someone, set `stage` to one of those stages
(`orch-database --project "$P" update outreach_contacts --id N --data '{"stage":"Shortlisted"}'`).
To look again at a `Not found`, set its `email_status` to null (only those).
To run it now: `orch-workflows run "$(node -p "require('$A/workflows.json').enrich")"`.
An address the person gives you: update `email` (and `email_status: "Found"`, `email_source`).

Draft a campaign (never send or start it):
1. Insert it as the app does:
   ```bash
   orch-database --project "$P" insert outreach_campaigns --data '{"kind":"broadcast","name":"October news",
     "subject":"News, {{first_name|there}}","body":"Hi {{first_name|there}},\n…","format":"simple","status":"Draft",
     "mode":"auto","skip_contacted":0,"unsubscribe_link":1,
     "recipients":"{\"lists\":[\"Newsletter\"],\"audiences\":[],\"exclude_lists\":[],\"exclude_audiences\":[]}"}'
   ```
   A sequence: `"kind":"sequence"`, `"format":"text"`, `"skip_contacted":1`,
   `"unsubscribe_link":0`, `"mode":"review"` unless told otherwise. Audiences
   go by `_id`. Leave `from_*` empty to use Settings. Variables: any contact
   column, `first_name`, `last_name`, `{{x|fallback}}`, and `{{unsubscribe_url}}`
   (needs `unsubscribe_link: 1`).
2. `node "$D/recipients.js" <id>`: the exact count, why the others are out, and
   `content` (what still blocks it, e.g. no sender).
3. Give the person the link (`#/campaigns/<id>`) and say it is a draft: they
   send a test, then send, schedule or start it in the app. A test from you:
   `orch-workflows run <test id> --args '{"id":"<id>","to":"<their address>"}'`, only on their yes.

What is going out / waiting for review:
- Sequence emails queued: `SELECT s._id, k.name AS campaign, s.name, s.email, s.subject FROM outreach_sends s JOIN outreach_campaigns k ON k._id = s.campaign_id WHERE s._deleted = 0 AND s.status = 'Queued' AND k.status = 'Active' ORDER BY datetime(s.queued_at), s._id`. Pace: `paused`, `next_send_at`, `window_start`–`window_end`, `send_days`, `timezone`, `daily_cap` in `outreach_settings`.
- Broadcasts: campaigns with `kind = 'broadcast'` and status `Scheduled` (`scheduled_at`) or `Sending` (`total`).
- To review: sends with `status = 'In review'`. The person approves or discards them at `#/review`. If asked to rewrite one, update only its `subject` and `body`, and only while it is In review.
- "What would resuming write?": `node "$D/queue.js" --dry-run` (writes nothing).

Who replied, how a campaign did. Per campaign, from `outreach_sends`
(`_deleted = 0`): sent = status in (Sent, Replied, Bounced); replied =
Replied; opened = `last_event` in (opened, clicked); clicked; bounced;
complained; unsubscribed = `unsubscribed_at` not null; failed; cancelled.
Quote names from the rows; never guess who replied. If the person says
someone replied: on that `Sent` row set `status` to `Replied` and `replied_at`
to now (UTC `YYYY-MM-DD HH:MM:SS`). To keep a group for the next campaign:
`node "$D/make-list.js" <campaign id> <which> "<list>"` (which: sent, replied,
not_replied, delivered, opened, not_opened, clicked, bounced, complained,
unsubscribed, failed, all). Fresh bounce data: run the `status` workflow.

Someone asks to be unsubscribed (when the person tells you):
1. Contact: `status: "Unsubscribed"`, `status_at`: now, `status_note`: why.
2. No-contact list, if not already active there: insert into
   `outreach_suppressions` `{"email":"<lowercase>","reason":"Asked not to be contacted","note":"…","active":1}`.
3. Their pending emails: `Queued` or `In review` → `status: "Cancelled"`, `error: "They unsubscribed"`.

An Unsubscribed, Bounced or Complained address stays out: only the person, in the app, can "Allow again".

## Other apps

No Orchestra app reads or writes Outreach's tables, and Outreach reads none.
CRM: prospecting lives in Outreach; when a reply becomes a conversation, the
CRM contact or deal is made by hand today (with the CRM app), and the Outreach
contact can move to the `In conversation` stage if `stages` has it.

## Never

- Send, schedule, start, resume, approve, retry or Send now; or unpause sending.
- Send a test without a yes, or to anyone the person did not name (it is real email).
- Guess an email or build one from a pattern.
- Reactivate an unsubscribed, bounced or complained address, or lift a suppression.
- Touch `outreach_settings` (sender, secret, caps), or delete rows without an explicit OK.
- Insert contacts straight into `outreach_contacts`; use the import.
