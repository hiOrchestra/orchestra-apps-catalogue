#!/usr/bin/env node
'use strict';
/**
 * Unsubscribe: someone pressed the button on the public unsubscribe page. The
 * token names the email the link came in and is signed with the secret in
 * Settings; anything else is ignored (bots, typos, the test link).
 *
 * Unsubscribing is global (lib.unsubscribeOps, the same rule as Unsubscribe in
 * the app): the contact becomes Unsubscribed, the address goes on the
 * no-contact list, and whatever was still waiting for them in any campaign is
 * cancelled. The email is marked too (the campaign's report counts it).
 * Pressing it twice changes nothing more.
 *   node unsubscribe.js <token>
 */
const L = require('./lib');

function main() {
  const token = String(process.argv[2] || '');
  const s = L.settings();
  if (token === 'test') return L.done({ ok: true, ran: 'unsubscribe', ignored: 'the test link unsubscribes nobody' });
  const id = L.unsubSendId(token, s.unsubscribe_secret);
  if (!id) return L.done({ ok: true, ran: 'unsubscribe', ignored: 'not one of our links' });
  const send = L.one('SELECT * FROM outreach_sends WHERE _id = ?', id);
  if (!send) return L.done({ ok: true, ran: 'unsubscribe', ignored: `email ${id} does not exist` });
  const email = L.normEmail(send.email);
  const k = L.one('SELECT name FROM outreach_campaigns WHERE _id = ?', send.campaign_id) || {};
  const why = `Unsubscribed from the link in "${k.name || `campaign ${send.campaign_id}`}"`;
  const ops = [];
  // A deleted email row still went out: its link is honoured, only not marked.
  if (!send.unsubscribed_at && !Number(send._deleted)) ops.push({ op: 'update', table: 'outreach_sends', id, data: { unsubscribed_at: L.sqlNow() } });
  const u = L.unsubscribeOps({ email, contactIds: [send.contact_id], why });
  ops.push(...u.ops);
  L.write(ops);
  return L.done({ ok: true, ran: 'unsubscribe', email: send._id, contacts: u.contacts, cancelled: u.cancelled });
}

try {
  main();
} catch (e) {
  process.stderr.write(`unsubscribe: ${e.message}\n`);
  process.exit(1);
}
