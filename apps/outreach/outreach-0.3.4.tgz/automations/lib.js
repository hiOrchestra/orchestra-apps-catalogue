'use strict';
/**
 * Outreach automations: what every one of them shares.
 *
 * Reads go to the project's SQLite file directly, read-only and
 * parameterised. Every write goes through `orch-database batch`, the
 * platform's own writer: one transaction, and a `when` precondition checked
 * inside the UPDATE, so a claim ("this send is mine now") is atomic and a row
 * somebody cancelled meanwhile is never sent.
 *
 * Locally (OUTREACH_LOCAL=1) the same batch runs against OUTREACH_DB with the
 * same semantics, and OUTREACH_FAKE_COMPOSIO=1 answers Composio calls the way
 * Resend's test addresses behave, so every script is tested off the instance.
 */
const { DatabaseSync } = require('node:sqlite');
const { execFileSync } = require('child_process');
const http = require('http');
const path = require('path');

// The project is the one these scripts were installed into (projects/<p>/apps/outreach/automations).
const PROJECT = process.env.OUTREACH_PROJECT || (__dirname.match(/projects\/([^/]+)\/apps\/outreach/) || [])[1] || 'default';
const STATE = process.env.OPENCLAW_STATE_DIR || '/home/node/.openclaw';
const DB_PATH = process.env.OUTREACH_DB || path.join(STATE, 'orchestra', 'projects', PROJECT, 'data', 'data.db');
const LOCAL = process.env.OUTREACH_LOCAL === '1';

// ── reading ──────────────────────────────────────────────────────────────
let reader = null;
function db() {
  if (!reader) {
    reader = new DatabaseSync(DB_PATH, { readOnly: true });
    reader.exec('PRAGMA busy_timeout = 5000');
  }
  return reader;
}
const all = (sql, ...params) => db().prepare(sql).all(...params);
const one = (sql, ...params) => db().prepare(sql).get(...params);
const columnsOf = (table) => new Set(all(`PRAGMA table_info("${table}")`).map((c) => c.name));

function settings() {
  const s = one('SELECT * FROM outreach_settings WHERE _deleted = 0 ORDER BY _id LIMIT 1');
  if (!s) throw new Error('Outreach has no settings row: it is not installed');
  return s;
}

/** A JSON list kept in a text column (stages, enrich_stages). */
function jsonList(text) {
  try {
    const v = JSON.parse(text || '[]');
    return Array.isArray(v) ? v.map(String).filter(Boolean) : [];
  } catch {
    return [];
  }
}

// ── writing ──────────────────────────────────────────────────────────────
/**
 * One transaction, all or nothing. Big inserts are split by size: a single
 * argv string over 128 KB is refused by the kernel before the CLI ever runs.
 */
function write(ops) {
  const chunks = [];
  let cur = [];
  let size = 0;
  for (const op of ops) {
    const n = JSON.stringify(op).length;
    if (cur.length && size + n > 90000) { chunks.push(cur); cur = []; size = 0; }
    cur.push(op);
    size += n;
  }
  if (cur.length) chunks.push(cur);
  let applied = 0;
  for (const chunk of chunks) applied += (LOCAL ? localBatch(chunk) : cliBatch(chunk)).applied;
  return applied;
}

function cliBatch(ops) {
  let out;
  try {
    out = execFileSync('orch-database', ['--project', PROJECT, 'batch', '--ops', JSON.stringify(ops)],
      { encoding: 'utf8', timeout: 120000, maxBuffer: 16 << 20 });
  } catch (e) {
    let j = null;
    try { j = JSON.parse(String(e.stdout || '')); } catch { /* not JSON */ }
    throw new Error((j && j.error) || String(e.stderr || e.message).trim().slice(0, 300));
  }
  const j = JSON.parse(out);
  if (!j.ok) throw new Error(j.error || 'the write failed');
  return j;
}

/** orch-database's run_batch, for local tests: same `when`, same all-or-none. */
function localBatch(ops) {
  const w = new DatabaseSync(DB_PATH);
  w.exec('PRAGMA busy_timeout = 5000');
  const now = sqlNow();
  const named = {};
  const deref = (v) => (typeof v === 'string' && v.startsWith('$') ? named[v.slice(1).split('.')[0]]._id : v);
  let applied = 0;
  w.exec('BEGIN IMMEDIATE');
  try {
    ops.forEach((op, i) => {
      const data = {};
      for (const [k, v] of Object.entries(op.data || {})) if (!k.startsWith('_')) data[k] = deref(v);
      if (op.op === 'insert') {
        const cols = [...Object.keys(data), '_created_at', '_updated_at'];
        const r = w.prepare(`INSERT INTO "${op.table}" (${cols.map((c) => `"${c}"`).join(', ')}) VALUES (${cols.map(() => '?').join(', ')})`)
          .run(...Object.values(data), now, now);
        if (op.as) named[op.as] = { _id: Number(r.lastInsertRowid) };
      } else {
        const when = op.when || {};
        const r = w.prepare(`UPDATE "${op.table}" SET ${Object.keys(data).map((c) => `"${c}" = ?`).join(', ')}, _updated_at = ? `
          + `WHERE _id = ? AND _deleted = 0${Object.keys(when).map((c) => ` AND "${c}" IS ?`).join('')}`)
          .run(...Object.values(data), now, deref(op.id), ...Object.values(when));
        if (!r.changes) throw new Error(`op ${i}: row ${op.id} changed meanwhile (precondition failed)`);
      }
      applied += 1;
    });
    w.exec('COMMIT');
  } catch (e) {
    w.exec('ROLLBACK');
    w.close();
    throw e;
  }
  w.close();
  return { ok: true, applied };
}

// ── time ─────────────────────────────────────────────────────────────────
/** 'YYYY-MM-DD HH:MM:SS' in UTC: the format orch-database stamps rows with. */
const sqlNow = (d = new Date()) => d.toISOString().slice(0, 19).replace('T', ' ');

/**
 * Stored dates come as '2026-09-26 17:40:00' (UTC) or '2026-09-26T17:40:00.000Z';
 * Resend's as '2026-09-29 19:36:59.741000+00' (an offset of hours only).
 */
function toDate(v) {
  if (!v) return null;
  const s = String(v).trim();
  const iso = (s.includes('T') ? s : s.replace(' ', 'T')).replace(/([+-]\d\d)$/, '$1:00');
  const d = new Date(/[zZ]|[+-]\d\d:?\d\d$/.test(iso) ? iso : iso + 'Z');
  return Number.isNaN(d.getTime()) ? null : d;
}

const WEEKDAY = { Mon: 1, Tue: 2, Wed: 3, Thu: 4, Fri: 5, Sat: 6, Sun: 7 };

/** The wall clock in `tz` at `date`. */
function partsIn(date, tz) {
  const f = new Intl.DateTimeFormat('en-GB', {
    timeZone: tz, hourCycle: 'h23', weekday: 'short',
    year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit',
  });
  const p = {};
  for (const x of f.formatToParts(date)) p[x.type] = x.value;
  return { y: +p.year, m: +p.month, d: +p.day, hh: +p.hour, mm: +p.minute, wd: WEEKDAY[p.weekday] };
}

/** The instant at which the wall clock in `tz` reads y-m-d hh:mm. */
function instantIn(tz, y, m, d, hh, mm) {
  const want = Date.UTC(y, m - 1, d, hh, mm);
  let guess = want;
  for (let i = 0; i < 3; i += 1) {
    const p = partsIn(new Date(guess), tz);
    const seen = Date.UTC(p.y, p.m - 1, p.d, p.hh, p.mm);
    if (seen === want) break;
    guess += want - seen;
  }
  return new Date(guess);
}

const minutes = (hhmm) => {
  const [h, m] = String(hhmm || '').split(':').map(Number);
  return (Number.isFinite(h) ? h : 0) * 60 + (Number.isFinite(m) ? m : 0);
};

/** The sending rules, from Settings. */
function schedule(s) {
  let tz = s.timezone || 'UTC';
  try { new Intl.DateTimeFormat('en-GB', { timeZone: tz }); } catch { tz = 'UTC'; }
  const days = String(s.send_days || '1,2,3,4,5').split(',').map(Number).filter((n) => n >= 1 && n <= 7);
  return {
    tz,
    start: minutes(s.window_start || '09:00'),
    end: minutes(s.window_end || '18:00'),
    days: days.length ? days : [1, 2, 3, 4, 5],
    every: Math.max(5, Number(s.send_every_minutes) || 30),
    cap: Math.max(1, Number(s.daily_cap) || 20),
  };
}

function inWindow(date, sch) {
  const p = partsIn(date, sch.tz);
  const t = p.hh * 60 + p.mm;
  return sch.days.includes(p.wd) && t >= sch.start && t < sch.end;
}

/** The first moment at or after `date` inside the window (null if the window is empty). */
function nextOpen(date, sch) {
  if (inWindow(date, sch)) return date;
  if (sch.end <= sch.start) return null;
  const p = partsIn(date, sch.tz);
  for (let i = 0; i < 9; i += 1) {
    const cal = new Date(Date.UTC(p.y, p.m - 1, p.d + i));
    const open = instantIn(sch.tz, cal.getUTCFullYear(), cal.getUTCMonth() + 1, cal.getUTCDate(), Math.floor(sch.start / 60), sch.start % 60);
    if (open > date && sch.days.includes(partsIn(open, sch.tz).wd)) return open;
  }
  return null;
}

/** Midnight in `tz` of the day `date` falls on. */
function dayStart(date, tz) {
  const p = partsIn(date, tz);
  return instantIn(tz, p.y, p.m, p.d, 0, 0);
}

/** Midnight in `tz` of the day after. */
function nextDay(date, tz) {
  const p = partsIn(date, tz);
  const cal = new Date(Date.UTC(p.y, p.m - 1, p.d + 1));
  return instantIn(tz, cal.getUTCFullYear(), cal.getUTCMonth() + 1, cal.getUTCDate(), 0, 0);
}

// ── contacts and templates ───────────────────────────────────────────────
// Variables, formats and the footer live in mailcore.js, shared with the app.
const M = require('./mailcore');
const { EMAIL, normEmail, variables, render } = M;

/** "Name <address>" as Resend takes it, or null when no sender is set. */
function fromAddress(s) {
  const email = normEmail(s.from_email);
  if (!EMAIL.test(email)) return null;
  const name = String(s.from_name || '').replace(/[<>"]/g, '').trim();
  return name ? `${name} <${email}>` : email;
}

/**
 * Who a campaign's emails come from: its own sender when it has one, else
 * Settings. Read when the email leaves, so fixing a sender and sending again
 * works; the row records what actually went out.
 */
function senderOf(k, s) {
  const own = k && normEmail(k.from_email);
  const from = own ? fromAddress({ from_email: own, from_name: k.from_name || s.from_name }) : fromAddress(s);
  const reply = normEmail((k && k.reply_to) || s.reply_to);
  return { from, replyTo: EMAIL.test(reply) ? reply : null, brand: String((k && k.from_name) || s.from_name || '').trim() };
}

function withFooter(body, footer) {
  const f = String(footer || '').trim();
  return f ? `${String(body).replace(/\s+$/, '')}\n\n${f}` : String(body);
}

/**
 * An audience is the data API's own filter object, as the app built it:
 * {col: v} equals, {col: [a, b]} one of, {col: {op: v}} for the rest. The
 * SQL mirrors the server's (canvas-actions FILTER_OPS / NULL_OPS), so the
 * members the app shows are exactly the ones queued.
 */
function filterSql(filter, columns, alias) {
  const where = [];
  const params = [];
  const q = (c) => `${alias ? alias + '.' : ''}"${c}"`;
  const like = (v) => String(v).replace(/[\\%_]/g, (m) => '\\' + m);
  for (const [col, v] of Object.entries(filter || {})) {
    if (!columns.has(col) || col.startsWith('_')) throw new Error(`it filters on "${col}", which contacts do not have`);
    if (Array.isArray(v)) {
      const list = v.map(String).filter((x) => x !== '');
      if (list.length) { where.push(`${q(col)} IN (${list.map(() => '?').join(', ')})`); params.push(...list); }
      continue;
    }
    if (v && typeof v === 'object') {
      for (const [op, val] of Object.entries(v)) {
        if (op === 'isnull') where.push(`(${q(col)} IS NULL OR ${q(col)} = '')`);
        else if (op === 'notnull') where.push(`(${q(col)} IS NOT NULL AND ${q(col)} <> '')`);
        else if (op === 'like') { where.push(`${q(col)} LIKE ('%' || ? || '%') ESCAPE '\\'`); params.push(like(val)); }
        else if (op === 'starts') { where.push(`${q(col)} LIKE (? || '%') ESCAPE '\\'`); params.push(like(val)); }
        else if (op === 'in') {
          const list = String(val).split(',').filter((x) => x !== '');
          if (list.length) { where.push(`${q(col)} IN (${list.map(() => '?').join(', ')})`); params.push(...list); }
        } else if (['eq', 'ne', 'gt', 'gte', 'lt', 'lte'].includes(op)) {
          where.push(`${q(col)} ${{ eq: '=', ne: '<>', gt: '>', gte: '>=', lt: '<', lte: '<=' }[op]} ?`);
          params.push(String(val));
        } else throw new Error(`it uses "${op}", which is not a filter`);
      }
      continue;
    }
    if (v === null || v === undefined || v === '') continue;
    where.push(`${q(col)} = ?`);
    params.push(String(v));
  }
  return { sql: where.length ? where.join(' AND ') : '1 = 1', params };
}

/** Why an address must not get mail, or null. Domains are listed as '@example.com'. */
function suppressedWhy(email) {
  const e = normEmail(email);
  const at = e.slice(e.indexOf('@'));
  const row = one(`SELECT reason FROM outreach_suppressions WHERE _deleted = 0 AND COALESCE(active, 1) = 1
    AND (LOWER(TRIM(email)) = ? OR LOWER(TRIM(email)) = ?) LIMIT 1`, e, at);
  return row ? `On the no-contact list (${row.reason || 'added by hand'})` : null;
}

function suppressOps(email, reason, note) {
  const e = normEmail(email);
  if (!e || one(`SELECT 1 AS x FROM outreach_suppressions WHERE _deleted = 0 AND COALESCE(active, 1) = 1 AND LOWER(TRIM(email)) = ?`, e)) return [];
  return [{ op: 'insert', table: 'outreach_suppressions', data: { email: e, reason, note: note || null, active: 1 } }];
}

/**
 * Unsubscribing, from the public link or from the app: one rule for both.
 * Each contact (by id, or by the address) that is Active or Blocked becomes
 * Unsubscribed (a bounce or a complaint keeps its own status), the address goes
 * on the no-contact list, and whatever was still waiting for them in any
 * campaign (Queued, In review, Retry) is cancelled. `seen` dedupes the
 * no-contact rows of one batch. Run it twice and the second run changes nothing.
 */
function unsubscribeOps({ email, contactIds = [], why, seen = new Set() }) {
  const e = normEmail(email);
  const ids = contactIds.map(Number).filter((n) => Number.isInteger(n) && n > 0);
  const where = [ids.length ? `_id IN (${ids.map(() => '?').join(',')})` : null, e ? 'LOWER(TRIM(email)) = ?' : null].filter(Boolean);
  if (!where.length) return { ops: [], contacts: [], cancelled: 0 };
  const contacts = all(`SELECT _id, status FROM outreach_contacts WHERE _deleted = 0 AND (${where.join(' OR ')})`, ...ids, ...(e ? [e] : []));
  const ops = [];
  for (const c of contacts) {
    const st = M.statusOf(c);
    if (st === 'Active' || st === 'Blocked') ops.push({ op: 'update', table: 'outreach_contacts', id: c._id, when: { status: c.status }, data: { status: 'Unsubscribed', status_at: sqlNow(), status_note: why } });
  }
  if (e && EMAIL.test(e) && !seen.has(e)) { seen.add(e); ops.push(...suppressOps(e, 'Unsubscribed', why)); }
  const cids = contacts.map((c) => c._id);
  const or = [e ? 'LOWER(TRIM(email)) = ?' : null, cids.length ? `contact_id IN (${cids.map(() => '?').join(',')})` : null].filter(Boolean);
  const pending = or.length ? all(`SELECT _id, status FROM outreach_sends WHERE _deleted = 0 AND status IN ('Queued', 'In review', 'Retry')
    AND (${or.join(' OR ')})`, ...(e ? [e] : []), ...cids) : [];
  for (const p of pending) ops.push({ op: 'update', table: 'outreach_sends', id: p._id, when: { status: p.status }, data: { status: 'Cancelled', error: 'They unsubscribed' } });
  return { ops, contacts: cids, cancelled: pending.length };
}

// ── recipients ───────────────────────────────────────────────────────────
const likeEsc = (v) => String(v).replace(/[\\%_]/g, (m) => '\\' + m);

/** The no-contact list, loaded once: exact addresses and whole domains (@example.com). */
function suppressionIndex() {
  const emails = new Set();
  const domains = [];
  for (const r of all(`SELECT LOWER(TRIM(email)) AS e FROM outreach_suppressions WHERE _deleted = 0 AND COALESCE(active, 1) = 1`)) {
    if (!r.e) continue;
    if (r.e.startsWith('@')) domains.push(r.e); else emails.add(r.e);
  }
  return { has: (email) => emails.has(email) || domains.some((d) => email.endsWith(d)) };
}

/** A campaign's subject, text and format: its own, or (before v2) its template's. */
function contentOf(k) {
  const fmt = (f) => (M.FORMATS.includes(f) ? f : 'text');
  if (k.subject || k.body) return { subject: k.subject || '', body: k.body || '', format: fmt(k.format) };
  const t = k.template_id ? one('SELECT subject, body, format FROM outreach_templates WHERE _deleted = 0 AND _id = ?', k.template_id) : null;
  return t ? { subject: t.subject || '', body: t.body || '', format: fmt(t.format) } : null;
}

/** Variables the content uses that are neither a contact column nor a special one. */
function unknownVariables(content) {
  const known = new Set(M.knownVariables([...columnsOf('outreach_contacts')]));
  return [...new Set([...variables(content.subject), ...variables(content.body)])].filter((v) => !known.has(v));
}

/**
 * What stops a campaign's email from being written, in words to act on, or
 * null: no subject or text, no sender, a variable contacts do not have, or
 * {{unsubscribe_url}} in a campaign without the link.
 */
function contentProblem(k, s, content) {
  if (!content || !String(content.subject || '').trim() || !String(content.body || '').trim()) return 'Its email has no subject or text: write it.';
  if (!senderOf(k, s).from) return 'There is no sender address: set it in the campaign or in Settings.';
  const unknown = unknownVariables(content);
  if (unknown.length) return `Its email uses ${unknown.map((v) => `{{${v}}}`).join(', ')}, which contacts do not have.`;
  const uses = [...variables(content.subject), ...variables(content.body)].includes('unsubscribe_url');
  if (uses && Number(k.unsubscribe_link) !== 1) return 'Its email uses {{unsubscribe_url}} but the campaign has no unsubscribe link: turn it on.';
  if (Number(k.unsubscribe_link) === 1 && !unsubUrl(s, 1)) return 'The unsubscribe page is not set: set it in Settings, Unsubscribe.';
  return null;
}

/**
 * Who a campaign writes to, and why each of the others does not get it.
 * In scope: contacts in any included list or audience. Then, checked in this
 * order: left out by an exclusion, not Active, no or invalid address, on the
 * no-contact list, a second contact with the same address, already written by
 * this campaign, reached by another campaign (when it skips the contacted), an
 * email of another campaign still pending (sequences: one pending email per
 * person), and a variable with no value and no fallback (when `content` is
 * given). The count on screen, a broadcast's frozen list and a sequence's
 * queue all come from here, so the three agree.
 */
function recipientsOf(k, { content = null, order = null, orderParams = [] } = {}) {
  const rec = M.parseRecipients(k);
  if (!rec) return { problem: 'Its recipients cannot be read: pick them again.' };
  if (!M.hasRecipients(rec)) return { problem: 'It has no recipients: pick a list or an audience.' };
  const cols = columnsOf('outreach_contacts');
  const clauses = (lists, audiences, what) => {
    const sql = [];
    const params = [];
    for (const name of lists) { sql.push("c.tags LIKE ? ESCAPE '\\'"); params.push(`%|${likeEsc(name)}|%`); }
    for (const id of audiences) {
      const a = one('SELECT name, filter FROM outreach_audiences WHERE _deleted = 0 AND _id = ?', id);
      if (!a) throw new Error(`An audience it ${what} no longer exists (#${id}): pick the recipients again.`);
      let f;
      try { f = JSON.parse(a.filter || '{}'); } catch { throw new Error(`The audience "${a.name}" cannot be read.`); }
      let w;
      try { w = filterSql(f, cols, 'c'); } catch (e) { throw new Error(`The audience "${a.name}": ${e.message}.`); }
      sql.push(`(${w.sql})`);
      params.push(...w.params);
    }
    return { sql, params };
  };
  let inc;
  let exc;
  try {
    inc = clauses(rec.lists, rec.audiences, 'writes to');
    exc = clauses(rec.exclude_lists, rec.exclude_audiences, 'leaves out');
  } catch (e) {
    return { problem: e.message };
  }
  const rows = all(`SELECT c.*, ${exc.sql.length ? `CASE WHEN (${exc.sql.join(' OR ')}) THEN 1 ELSE 0 END` : '0'} AS _excluded
    FROM outreach_contacts c WHERE c._deleted = 0 AND (${inc.sql.join(' OR ')})
    ORDER BY ${order || 'c._id'}`, ...exc.params, ...inc.params, ...orderParams);

  const kind = k.kind === 'broadcast' ? 'broadcast' : 'sequence';
  const skip = Number(k.skip_contacted ?? (kind === 'broadcast' ? 0 : 1)) !== 0;
  const sup = suppressionIndex();
  const mine = new Set();
  for (const r of all('SELECT contact_id, LOWER(TRIM(email)) AS e FROM outreach_sends WHERE _deleted = 0 AND campaign_id = ?', k._id || 0)) {
    if (r.contact_id) mine.add(`c${r.contact_id}`);
    if (r.e) mine.add(r.e);
  }
  const pending = new Set();
  const contacted = new Set();
  for (const r of all(`SELECT contact_id, LOWER(TRIM(email)) AS e, status FROM outreach_sends WHERE _deleted = 0 AND campaign_id <> ?
      AND status IN ('Queued', 'In review', 'Sending', 'Sent', 'Replied', 'Bounced')`, k._id || 0)) {
    if (r.e && ['Queued', 'In review', 'Sending'].includes(r.status)) pending.add(r.e);
    if (r.e) contacted.add(r.e);
    if (r.contact_id) contacted.add(`c${r.contact_id}`);
  }
  const seen = new Set();
  const counts = {};
  const missingVars = {};
  const ok = [];
  for (const c of rows) {
    const email = normEmail(c.email);
    let why = null;
    if (c._excluded) why = 'excluded';
    else if (M.statusOf(c) !== 'Active') why = M.statusOf(c);
    else if (!email) why = 'no_email';
    else if (!EMAIL.test(email)) why = 'invalid';
    else if (sup.has(email)) why = 'suppressed';
    else if (seen.has(email)) why = 'duplicate';
    else if (mine.has(`c${c._id}`) || mine.has(email)) why = 'written';
    else if (skip && (contacted.has(email) || contacted.has(`c${c._id}`))) why = 'contacted';
    else if (kind === 'sequence' && pending.has(email)) why = 'pending';
    else if (content) {
      const miss = new Set([...render(content.subject, c, { keep: ['unsubscribe_url'] }).missing,
        ...render(content.body, c, { keep: ['unsubscribe_url'] }).missing]);
      if (miss.size) {
        why = 'missing';
        for (const m of miss) missingVars[m] = (missingVars[m] || 0) + 1;
      }
    }
    if (why) counts[why] = (counts[why] || 0) + 1;
    else { seen.add(email); ok.push(c); }
  }
  return { ok, inScope: rows.length, counts, missingVars, kind, skip };
}

// ── unsubscribe links ────────────────────────────────────────────────────
// The link names the email it came in (so the report can say which campaign
// lost them) and carries a signature, so nobody can unsubscribe someone else
// by guessing numbers. The secret lives in Settings, never in a public page.
const crypto = require('crypto');
function unsubToken(sendId, secret) {
  const sig = crypto.createHmac('sha256', String(secret)).update(`unsubscribe:${sendId}`).digest('base64url').slice(0, 22);
  return `${sendId}.${sig}`;
}
/** The email a token names, or null when it is not one of ours. */
function unsubSendId(token, secret) {
  const m = /^(\d{1,12})\.([A-Za-z0-9_-]{22})$/.exec(String(token || '').trim());
  if (!m || !secret) return null;
  const want = Buffer.from(unsubToken(m[1], secret).split('.')[1]);
  const got = Buffer.from(m[2]);
  return want.length === got.length && crypto.timingSafeEqual(want, got) ? Number(m[1]) : null;
}
/** The unsubscribe link of one email, or null when Settings have no page or secret. */
function unsubUrl(s, sendId) {
  const base = String(s.unsubscribe_url || '').trim();
  if (!/^https?:\/\//.test(base) || !s.unsubscribe_secret || !sendId) return null;
  return `${base.split('#')[0]}#t=${unsubToken(sendId, s.unsubscribe_secret)}`;
}

/** One email as Resend takes it. */
function resendMessage({ from, to, replyTo, email, unsubscribe }) {
  const m = { from, to, subject: email.subject };
  if (email.text) m.text = email.text;
  if (email.html) m.html = email.html;
  if (replyTo) m.reply_to = replyTo;
  if (unsubscribe) m.headers = { 'List-Unsubscribe': `<${unsubscribe}>` };
  return m;
}

/** The ids Resend gave a batch, in order ({data: [{id}]} however deep Composio wraps it). */
function idsOf(result) {
  const walk = (v) => {
    if (Array.isArray(v)) {
      if (v.length && v.every((x) => x && typeof x === 'object' && x.id !== undefined)) return v.map((x) => String(x.id));
      for (const x of v) { const f = walk(x); if (f) return f; }
      return null;
    }
    if (v && typeof v === 'object') for (const x of Object.values(v)) { const f = walk(x); if (f) return f; }
    return null;
  };
  return walk(result) || [];
}

// ── who is calling ───────────────────────────────────────────────────────
// A workflow's commands run as its agent, with that agent's own identity and
// none of the platform's credentials (ORC-181 §6, 2026-09-27). Every call to
// the instance goes out as that agent; the platform secret is only a fallback
// for running this by hand as node.
function identityHeaders() {
  const id = process.env.ORCHESTRA_AGENT_ID;
  const token = process.env.ORCHESTRA_AGENT_TOKEN;
  if (id && token) return { 'x-orchestra-agent': id, 'x-orchestra-agent-token': token };
  const secret = process.env.HOOKS_TOKEN || process.env.OPENCLAW_GATEWAY_TOKEN || '';
  return secret ? { 'x-orchestra-secret': secret } : {};
}

// ── telling the person ───────────────────────────────────────────────────
// The Telegram chat in Settings gets a short message from the instance's bot
// through POST /api/channels/telegram/notify: no agent turn, and only a chat
// the instance's Telegram is set up for. Headers go to curl on stdin (-K -),
// never argv, so the token is not in the process list. Never throws: a message
// that cannot go out is reported in the run's output, and the work it reports
// on stands.
const TG_CHAT = /^(-?\d{5,20}|@[A-Za-z0-9_]{5,32})$/;
function notify(s, text) {
  const to = String((s && s.notify_telegram) || '').trim();
  if (!to) return { sent: false, why: 'No Telegram chat in Settings' };
  if (!TG_CHAT.test(to)) return { sent: false, why: 'The Telegram chat in Settings is not a chat id or @username' };
  const message = String(text || '').slice(0, 3800);
  if (LOCAL || process.env.OUTREACH_FAKE_NOTIFY === '1') return { sent: true, to, fake: true, text: message };
  const q = (v) => `"${String(v).replace(/[\\"]/g, '\\$&')}"`;
  const config = [
    `url = ${q(`http://127.0.0.1:${Number(process.env.API_SERVER_PORT || 3001)}/api/channels/telegram/notify`)}`,
    'request = "POST"',
    'header = "Content-Type: application/json"',
    ...Object.entries(identityHeaders()).map(([k, v]) => `header = ${q(`${k}: ${v}`)}`),
    `data = ${q(JSON.stringify({ to, message }))}`,
  ].join('\n');
  try {
    const out = execFileSync('curl', ['-sS', '-m', '30', '-K', '-'], { input: config, timeout: 35000, stdio: ['pipe', 'pipe', 'pipe'] }).toString();
    let j = null;
    try { j = JSON.parse(out); } catch { /* reported below */ }
    if (j && j.success) return { sent: true, to };
    return { sent: false, to, why: String((j && j.error && (j.error.message || j.error)) || out).trim().slice(0, 200) };
  } catch (e) {
    return { sent: false, to, why: String((e.stderr && e.stderr.toString()) || e.message).trim().slice(0, 200) };
  }
}

// ── Composio (Resend) ────────────────────────────────────────────────────
/**
 * A Composio action for this tenant, the way the workflow engine calls it.
 * The first Resend call that works in a run is noted in Settings
 * (resend_ok_at), for Getting started: the app cannot see the portal's
 * Integrations, so it learns Resend is connected from Resend answering.
 */
function composio(slug, args, timeoutMs = 60000) {
  const call = process.env.OUTREACH_FAKE_COMPOSIO === '1' ? fakeComposio(slug, args) : composioCall(slug, args, timeoutMs);
  return call.then((r) => { if (/^RESEND_/.test(slug)) noteResend(null); return r; });
}

let resendNoted = false;
/** Settings say whether Resend answered: ok (error null) or why not. Never throws. */
function noteResend(error) {
  if (resendNoted && !error) return;
  resendNoted = !error;
  try {
    const s = settings();
    const data = error
      ? { resend_error: String(error).slice(0, 300), resend_checked_at: sqlNow() }
      : (s.resend_ok_at && !s.resend_error ? null : { resend_ok_at: sqlNow(), resend_error: null, resend_checked_at: sqlNow() });
    if (data) write([{ op: 'update', table: 'outreach_settings', id: s._id, data }]);
  } catch { /* a note, not the work */ }
}

function composioCall(slug, args, timeoutMs) {
  return new Promise((resolve, reject) => {
    const body = JSON.stringify({ toolSlug: slug, arguments: args });
    const req = http.request({
      hostname: '127.0.0.1', port: Number(process.env.API_SERVER_PORT || 3001), path: '/api/composio/execute',
      method: 'POST', agent: false,
      headers: {
        'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body),
        ...identityHeaders(),
      },
    }, (res) => {
      let b = '';
      res.on('data', (c) => { b += c; });
      res.on('end', () => {
        let j;
        try { j = JSON.parse(b); } catch { return reject(new Error(`Composio answered ${res.statusCode}: ${b.slice(0, 200)}`)); }
        if (j && j.success && j.data && j.data.successful !== false) return resolve(j.data.data);
        const why = (j && j.data && j.data.error) || (j && j.error && (j.error.message || j.error)) || `HTTP ${res.statusCode}`;
        return reject(new Error(readable(why)));
      });
    });
    req.on('error', reject);
    req.setTimeout(timeoutMs, () => req.destroy(new Error(`Composio did not answer in ${timeoutMs / 1000}s`)));
    req.end(body);
  });
}

/** Resend answers errors as JSON ({"statusCode":403,"message":"…"}): keep the sentence. */
function readable(why) {
  const text = String(why || '');
  try {
    const j = JSON.parse(text);
    if (j && typeof j.message === 'string') return j.message.slice(0, 300);
  } catch { /* plain text already */ }
  return text.slice(0, 300);
}

/**
 * Resend's test addresses, as the fake sees them: bounced@… bounces,
 * complained@… complains, opened@… and clicked@… are read, fail@… is refused.
 * OUTREACH_FAKE_OUTBOX names a file that gets every message, one JSON a line,
 * so a test can read what went out.
 */
function fakeKind(to) {
  const local = String(to).split('@')[0];
  return ['bounced', 'complained', 'opened', 'clicked'].includes(local) ? local : 'delivered';
}
function fakeOutbox(msg) {
  if (process.env.OUTREACH_FAKE_OUTBOX) require('fs').appendFileSync(process.env.OUTREACH_FAKE_OUTBOX, `${JSON.stringify(msg)}\n`);
}
function fakeComposio(slug, args) {
  if (process.env.OUTREACH_FAKE_NOT_CONNECTED === '1') return Promise.reject(new Error('No connected account found for toolkit resend (fake)'));
  const newId = (to) => `fake-${fakeKind(to)}-${Math.random().toString(36).slice(2, 10)}`;
  if (slug === 'RESEND_SEND_EMAIL') {
    const to = String(args.to);
    if (/^fail@/.test(to)) return Promise.reject(new Error('Resend refused the message (fake)'));
    if (/unverified/.test(String(args.from))) return Promise.reject(new Error('The domain is not verified (fake)'));
    fakeOutbox(args);
    return Promise.resolve({ data: { id: newId(to) } });
  }
  if (slug === 'RESEND_SEND_BATCH_EMAILS') {
    const emails = Array.isArray(args.emails) ? args.emails : [];
    if (!emails.length || emails.length > 100) return Promise.reject(new Error('A batch holds 1 to 100 emails (fake)'));
    if (emails.some((m) => /^fail@/.test(String(m.to)))) return Promise.reject(new Error('Resend refused the batch: one address is not valid (fake)'));
    if (emails.some((m) => /unverified/.test(String(m.from)))) return Promise.reject(new Error('The domain is not verified (fake)'));
    if (process.env.OUTREACH_FAKE_BATCH_TIMEOUT === '1') return Promise.reject(new Error('Composio did not answer in 60s'));
    emails.forEach(fakeOutbox);
    return Promise.resolve({ data: { data: emails.map((m) => ({ id: newId(m.to) })) } });
  }
  if (slug === 'RESEND_RETRIEVE_EMAIL') {
    const kind = String(args.email_id).split('-')[1] || 'delivered';
    return Promise.resolve({ data: { id: args.email_id, last_event: kind } });
  }
  if (slug === 'RESEND_LIST_EMAILS') {
    // What this database says was sent, newest first, the way Resend pages it.
    const rows = all(`SELECT provider_id AS id, sent_at FROM outreach_sends WHERE provider_id LIKE 'fake-%' ORDER BY datetime(sent_at) DESC, _id DESC`);
    let from = 0;
    if (args.after) from = rows.findIndex((r) => r.id === args.after) + 1;
    const limit = Math.min(100, Number(args.limit) || 20);
    const page = rows.slice(from, from + limit).map((r) => ({
      id: r.id, created_at: `${String(r.sent_at).replace('T', ' ').slice(0, 19)}.000000+00`, last_event: String(r.id).split('-')[1] || 'delivered',
    }));
    return Promise.resolve({ data: { object: 'list', has_more: from + limit < rows.length, data: page } });
  }
  return Promise.reject(new Error(`fake Composio has no ${slug}`));
}

/** The first scalar under `key` anywhere in a nested result. */
function pick(obj, key) {
  if (!obj || typeof obj !== 'object') return undefined;
  if (Object.prototype.hasOwnProperty.call(obj, key) && obj[key] !== null && typeof obj[key] !== 'object') return obj[key];
  for (const v of Object.values(obj)) {
    const f = pick(v, key);
    if (f !== undefined) return f;
  }
  return undefined;
}

/** Print the run's one-line result (the workflow step's output) and stop. */
function done(result) {
  process.stdout.write(`${JSON.stringify(result)}\n`);
  return result;
}

module.exports = {
  PROJECT, DB_PATH, M, all, one, columnsOf, settings, jsonList, write,
  sqlNow, toDate, partsIn, instantIn, schedule, inWindow, nextOpen, dayStart, nextDay,
  EMAIL, normEmail, fromAddress, senderOf, variables, render, withFooter, filterSql, suppressedWhy, suppressOps, unsubscribeOps,
  suppressionIndex, contentOf, unknownVariables, contentProblem, recipientsOf, unsubToken, unsubSendId, unsubUrl, resendMessage, idsOf,
  composio, noteResend, readable, pick, done, notify,
};
