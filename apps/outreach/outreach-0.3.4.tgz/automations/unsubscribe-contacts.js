#!/usr/bin/env node
'use strict';
/**
 * Unsubscribe in the app (one contact, or the ticked ones): the same as the
 * public link (lib.unsubscribeOps). Each becomes Unsubscribed (a bounce or a
 * complaint keeps its status), the address goes on the no-contact list, and
 * whatever was waiting for them in any campaign (Queued, In review, Retry) is
 * cancelled. Running it twice changes nothing more.
 *   node unsubscribe-contacts.js <contact ids: 12,15,40>
 */
const L = require('./lib');

function main() {
  const ids = [...new Set(String(process.argv[2] || '').split(/[^0-9]+/).map(Number).filter((n) => Number.isInteger(n) && n > 0))].slice(0, 500);
  if (!ids.length) return L.done({ ok: false, ran: 'unsubscribe-contacts', error: 'Name the contacts: their ids, separated by commas' });
  const rows = L.all(`SELECT _id, email FROM outreach_contacts WHERE _deleted = 0 AND _id IN (${ids.map(() => '?').join(',')})`, ...ids);
  const ops = [];
  const seen = new Set();
  let cancelled = 0;
  for (const c of rows) {
    const u = L.unsubscribeOps({ email: c.email, contactIds: [c._id], why: 'Unsubscribed in the app', seen });
    ops.push(...u.ops);
    cancelled += u.cancelled;
  }
  if (ops.length) L.write(ops);
  return L.done({ ok: true, ran: 'unsubscribe-contacts', contacts: rows.map((c) => c._id), missing: ids.filter((i) => !rows.some((c) => c._id === i)), cancelled });
}

try {
  main();
} catch (e) {
  process.stderr.write(`unsubscribe-contacts: ${e.message}\n`);
  process.exit(1);
}
