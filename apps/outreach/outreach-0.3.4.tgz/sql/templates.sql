SELECT t._id AS _id, t.name AS name, t.subject AS subject, COALESCE(NULLIF(t.format, ''), 'text') AS format,
  (SELECT COUNT(*) FROM outreach_campaigns k WHERE k._deleted = 0 AND k.template_id = t._id) AS campaigns,
  (SELECT group_concat(k.name, ' · ') FROM outreach_campaigns k WHERE k._deleted = 0 AND k.template_id = t._id AND k.status IN ('Active', 'Paused', 'Draft', 'Scheduled', 'Sending')) AS used_by,
  datetime(t._updated_at) AS updated_at
FROM outreach_templates t
WHERE t._deleted = 0 AND COALESCE(t.archived, 0) = 0
