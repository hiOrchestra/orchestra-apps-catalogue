SELECT c.*,
  COALESCE(NULLIF(c.status, ''), 'Active') AS state,
  CASE
    WHEN c.email IS NOT NULL AND TRIM(c.email) <> '' THEN 'Has email'
    WHEN c.email_status = 'Searching' THEN 'Searching'
    WHEN c.email_status = 'Not found' THEN 'Not found'
    WHEN instr((SELECT enrich_stages FROM outreach_settings WHERE _deleted = 0 ORDER BY _id LIMIT 1), '"' || c.stage || '"') > 0 THEN 'Waiting for lookup'
    ELSE 'No email'
  END AS email_state,
  (SELECT s.status FROM outreach_sends s WHERE s._deleted = 0 AND s.contact_id = c._id ORDER BY s._id DESC LIMIT 1) AS last_status,
  (SELECT datetime(COALESCE(s.sent_at, s.queued_at)) FROM outreach_sends s WHERE s._deleted = 0 AND s.contact_id = c._id ORDER BY s._id DESC LIMIT 1) AS last_at,
  datetime(c._created_at) AS added_at
FROM outreach_contacts c
WHERE c._deleted = 0
