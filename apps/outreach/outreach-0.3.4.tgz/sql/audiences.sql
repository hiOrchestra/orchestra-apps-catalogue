SELECT a._id AS _id, a.name AS name, a.description AS description, a.filter AS filter,
  (SELECT COUNT(*) FROM outreach_campaigns k WHERE k._deleted = 0 AND k.status IN ('Active', 'Paused', 'Draft', 'Scheduled', 'Sending')
    AND ((COALESCE(k.recipients, '') = '' AND k.audience_id = a._id)
      OR instr(',' || replace(replace(COALESCE(json_extract(k.recipients, '$.audiences'), ''), '[', ''), ']', '') || ',', ',' || a._id || ',') > 0
      OR instr(',' || replace(replace(COALESCE(json_extract(k.recipients, '$.exclude_audiences'), ''), '[', ''), ']', '') || ',', ',' || a._id || ',') > 0)) AS campaigns,
  (SELECT group_concat(k.name, ' · ') FROM outreach_campaigns k WHERE k._deleted = 0 AND k.status IN ('Active', 'Paused', 'Draft', 'Scheduled', 'Sending')
    AND ((COALESCE(k.recipients, '') = '' AND k.audience_id = a._id)
      OR instr(',' || replace(replace(COALESCE(json_extract(k.recipients, '$.audiences'), ''), '[', ''), ']', '') || ',', ',' || a._id || ',') > 0
      OR instr(',' || replace(replace(COALESCE(json_extract(k.recipients, '$.exclude_audiences'), ''), '[', ''), ']', '') || ',', ',' || a._id || ',') > 0)) AS used_by,
  datetime(a._updated_at) AS updated_at
FROM outreach_audiences a
WHERE a._deleted = 0 AND COALESCE(a.archived, 0) = 0
