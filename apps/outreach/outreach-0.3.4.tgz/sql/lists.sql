WITH RECURSIVE registry(t) AS (
  SELECT CASE WHEN json_valid(tags) AND json_array_length(tags) > 0 THEN tags ELSE '[]' END
  FROM outreach_settings WHERE _id = (SELECT MIN(_id) FROM outreach_settings WHERE _deleted = 0)
),
names(i, name) AS (
  SELECT 0, json_extract((SELECT t FROM registry), '$[0]')
  UNION ALL
  SELECT i + 1, json_extract((SELECT t FROM registry), '$[' || (i + 1) || ']') FROM names
  WHERE i + 1 < json_array_length((SELECT t FROM registry))
)
SELECT n.name AS name, n.i AS position,
  COUNT(c._id) AS total,
  COALESCE(SUM(COALESCE(NULLIF(c.status, ''), 'Active') = 'Active' AND c.email IS NOT NULL AND TRIM(c.email) <> ''), 0) AS reachable,
  COALESCE(SUM(c.status = 'Unsubscribed'), 0) AS unsubscribed,
  COALESCE(SUM(c.status IN ('Bounced', 'Complained')), 0) AS bounced,
  COALESCE(SUM(c.status = 'Blocked'), 0) AS blocked,
  COALESCE(SUM(c._id IS NOT NULL AND (c.email IS NULL OR TRIM(c.email) = '')), 0) AS no_email
FROM names n
LEFT JOIN outreach_contacts c ON c._deleted = 0 AND c.tags LIKE '%|' || n.name || '|%'
WHERE n.name IS NOT NULL AND TRIM(n.name) <> ''
GROUP BY n.name, n.i
