// Campaigns: what is running and how it went. Getting started sits on top
// until Resend answers and a sender is set (start.js). Two kinds: a broadcast is one
// email sent once to lists and audiences; a sequence writes to each new
// contact of its recipients, one at a time. On top, only what needs a person:
// emails waiting for review, sends that failed, a campaign that stopped. Each
// row opens its campaign; "New campaign" asks the kind, the name and where the
// email starts.
import { V, T, A, badge, kindLabel, act, plural, settings } from '../data.js';
import { ago, pct, localClock } from '../time.js';
import { startCard } from './start.js';

const { el, router, fmt } = Orch;

export function render(_params, path) {
  const start = el('div');
  const attention = el('div', { class: 'ox-notes' });
  const table = el('div');
  Orch.mount('view', el('div', { class: 'ox-page' }, [
    el('header', { class: 'ox-head' }, [
      el('div', { class: 'ox-head__text' }, [
        el('h1', { class: 'oc-h1 oc-h1--collection' }, 'Campaigns'),
        el('p', { class: 'oc-lede' }, 'A broadcast is one email sent once to lists and audiences. A sequence writes to each new contact of its recipients, one at a time, at the pace set in Settings.'),
      ]),
      el('button', { class: 'oc-btn oc-btn--primary', type: 'button', onClick: newCampaign }, 'New campaign'),
    ]),
    start,
    attention,
    table,
  ]));
  settings().then((s) => startCard(s, () => render(_params, path)))
    .then((card) => { if (card) Orch.mount(start, card); else start.remove(); })
    .catch(() => start.remove());
  notes(attention);
  Orch.table({
    into: table, view: V.campaigns, path: '/', query: path, sort: 'rank:asc',
    empty: 'No campaign yet. A broadcast needs a list; a sequence, an audience or a list.',
    filters: [{ key: 'kind', label: 'Kind', all: 'Both', options: [{ value: 'broadcast', label: 'Broadcasts' }, { value: 'sequence', label: 'Sequences' }] }],
    columns: [
      { key: 'name', label: 'Campaign', render: (r) => el('div', {}, [
        router.link(`/campaigns/${r._id}`, r.name || 'Untitled'),
        el('p', { class: 'oc-small oc-muted ox-sub' }, kindLabel(r.kind)),
        r.problem ? el('p', { class: 'oc-small ox-problem' }, r.problem) : null,
      ]) },
      { key: 'status', label: 'Status', render: (r) => el('span', { class: 'ox-status' }, [badge(r.status), progress(r)]) },
      { key: 'sent', label: 'Sent', numeric: true, render: (r) => (r.kind === 'broadcast' && r.total ? `${fmt.number(r.sent)} of ${fmt.number(r.total)}` : fmt.number(r.sent)) },
      { key: 'replied', label: 'Marked replied', numeric: true, render: (r) => (r.sent ? `${fmt.number(r.replied)} · ${pct(r.replied, r.sent)}` : '—') },
      { key: 'unsubscribed', label: 'Unsubscribed', numeric: true, render: (r) => (r.sent ? fmt.number(r.unsubscribed) : '—') },
      { key: 'bounced', label: 'Bounced', numeric: true, render: (r) => (r.sent ? fmt.number(r.bounced) : '—') },
      { key: 'at', label: 'When', render: (r) => when(r) },
    ],
  });
}

/** A sending broadcast's progress, after its badge. */
function progress(r) {
  if (r.kind !== 'broadcast' || r.status !== 'Sending' || !r.total) return null;
  return el('span', { class: 'oc-small oc-muted' }, ` ${pct(r.sent, r.total)}`);
}
function when(r) {
  if (r.status === 'Scheduled') return `Goes out ${localClock(r.scheduled_at)}`;
  if (r.last_sent_at) return ago(r.last_sent_at);
  if (r.status === 'Draft') return `Draft · ${ago(r.created_at)}`;
  return '—';
}

/** Only what a person has to act on; nothing when all is well. */
async function notes(host) {
  try {
    const [review, failed, stuck] = await Promise.all([
      Orch.db.view(V.review, { count: true, limit: 1 }),
      Orch.db.view(V.sent, { filter: { status: 'Failed' }, count: true, limit: 1 }),
      Orch.db.view(V.campaigns, { filter: { status: ['Active', 'Paused', 'Sending'], problem: { notnull: '1' } }, limit: 10 }),
    ]);
    const items = [];
    if (review.total) {
      items.push(el('p', { class: 'ox-note ox-note--warn' }, [
        `${plural(review.total, 'email is', 'emails are')} waiting for your review before they go out. `,
        router.link('/review', 'Review them'),
      ]));
    }
    if (failed.total) {
      items.push(el('p', { class: 'ox-note ox-note--bad' }, [
        `${plural(failed.total, 'email', 'emails')} did not go out. `,
        router.link('/sent?status=Failed', 'Send them again, fix them or drop them'),
      ]));
    }
    for (const k of stuck.rows || []) {
      items.push(el('p', { class: 'ox-note ox-note--bad' }, [`${k.name}: ${k.problem} `, router.link(`/campaigns/${k._id}`, 'Open it')]));
    }
    Orch.mount(host, items);
  } catch (e) {
    Orch.mount(host, el('p', { class: 'ox-note ox-note--bad' }, `Could not check what needs attention: ${e.message}`));
  }
}

/** The kind, a name, and where the email starts: a draft that is opened at once. */
async function newCampaign() {
  const tpl = await Orch.db.view(V.templates, { sort: 'name:asc', limit: 200 });
  const radio = (value, title, text, checked) => el('label', { class: 'ox-kind' }, [
    el('input', { type: 'radio', name: 'kind', value, checked: checked || null }),
    el('span', {}, [el('span', { class: 'ox-kind__title' }, title), el('span', { class: 'oc-small oc-muted' }, text)]),
  ]);
  const form = el('form', { class: 'ox-form' }, [
    el('fieldset', { class: 'oc-field ox-plain' }, [
      el('legend', { class: 'oc-label' }, 'Kind'),
      radio('broadcast', 'Broadcast', 'One email to lists and audiences, sent once: now or at a set time. A newsletter, an announcement.', true),
      radio('sequence', 'Sequence', 'Writes to each contact who joins its recipients, one email at a time, optionally reviewed first. Outreach to people you pick.'),
    ]),
    el('label', { class: 'oc-field' }, [el('span', { class: 'oc-label' }, 'Name'),
      el('input', { class: 'oc-input', name: 'name', required: true, maxlength: '120', placeholder: 'October newsletter' })]),
    el('label', { class: 'oc-field' }, [el('span', { class: 'oc-label' }, 'Start from'),
      el('select', { class: 'oc-select', name: 'template_id' }, [el('option', { value: '' }, 'A blank email'),
        ...(tpl.rows || []).map((t) => el('option', { value: String(t._id) }, t.name))])]),
    el('p', { class: 'oc-help' }, 'It starts as a draft: you write the email, pick who gets it, send yourself a test, and only then send or start it.'),
    el('div', { class: 'ox-actions' }, [el('button', { class: 'oc-btn oc-btn--primary', type: 'submit' }, 'Create the draft')]),
  ]);
  const dlg = Orch.dialog(form, { title: 'New campaign' });
  Orch.onSubmit(form, async (d) => {
    const kind = d.kind === 'sequence' ? 'sequence' : 'broadcast';
    const t = d.template_id ? await Orch.db.get(T.templates, Number(d.template_id)) : null;
    const params = {
      kind, name: d.name.trim(),
      subject: t ? t.subject || '' : '', body: t ? t.body || '' : '', format: (t && t.format) || (kind === 'broadcast' ? 'simple' : 'text'),
      recipients: '{}', mode: 'auto', skip_contacted: kind === 'broadcast' ? 0 : 1, unsubscribe_link: kind === 'broadcast' ? 1 : 0,
    };
    if (t) params.template_id = t._id;
    const r = await act(A.createCampaign, params, 'Draft created.');
    if (!r) return;
    dlg.close();
    router.go(`/campaigns/${r._id}`);
  });
}
