// Settings: the mail integrations, what is managed in Orchestra (who the emails
// come from, the footer, the broadcasts' and sequences' pace, the stages and
// which get their email looked up), the brake, replies, the no-contact list,
// and the automations that do the work (the buttons run one now).
import { A, settings, list, act, transportsOf, INTEGRATIONS, waitFor } from '../data.js';
import { noContactList } from './no-contact.js';
import { connectionLines, checkConnections } from './start.js';

const { el } = Orch;
const DAYS = [[1, 'Mon'], [2, 'Tue'], [3, 'Wed'], [4, 'Thu'], [5, 'Fri'], [6, 'Sat'], [7, 'Sun']];

export async function render(_params, path) {
  const noContact = el('div');
  Orch.load('view', async () => {
    const s = await settings();
    if (!s) return el('p', { class: 'oc-state' }, 'Outreach has no settings row: it is not installed.');
    const reload = () => render(_params, path);
    const page = el('div', { class: 'ox-page' }, [
      el('header', { class: 'ox-head' }, [el('div', { class: 'ox-head__text' }, [
        el('h1', { class: 'oc-h1 oc-h1--collection' }, 'Settings'),
        el('p', { class: 'oc-lede' }, 'Who the emails come from, what goes under them, when they leave and whose email is looked up are managed in Orchestra. Here: the integrations, the brake, replies, the no-contact list and the automations.'),
      ])]),
      integrations(s, reload),
      managed(s),
      sending(s, reload),
      replies(s, reload),
      noContact,
      automations(),
    ]);
    return page;
  }).then(() => noContactList(noContact, path));
}

/** Replies found at the portal's mail: which list they join (set in Orchestra), when it last looked, and a look now. */
function replies(s, reload) {
  const now = el('button', { type: 'button', class: 'oc-btn oc-btn--sm' }, 'Look now');
  now.addEventListener('click', async () => {
    now.disabled = true;
    now.textContent = 'Looking…';
    const before = s.replies_checked_at || '';
    if (await act(A.checkRepliesNow, {})) {
      const after = await waitFor(() => settings(), (x) => x && (x.replies_checked_at || '') !== before, 45);
      if (!after) Orch.toast('No answer yet. Try again in a minute.', { error: true });
      reload();
      return;
    }
    now.disabled = false;
    now.textContent = 'Look now';
  });
  const state = s.replies_error
    ? el('p', { class: 'ox-note ox-note--warn' }, `The last look failed: ${s.replies_error}`)
    : (s.replies_checked_at ? el('p', { class: 'oc-help' }, `Last looked ${String(s.replies_checked_at).replace('T', ' ').slice(0, 16)} UTC.`) : el('p', { class: 'oc-help' }, 'It has not looked yet.'));
  return el('section', { class: 'ox-section' }, [
    el('h2', { class: 'oc-h2' }, 'Replies'),
    el('p', { class: 'oc-help' }, `Every hour, while something sent is waiting for an answer, Outreach asks the portal's mail (where replies to your sender land) whether anyone you wrote to answered. An answer marks that email Replied in its campaign${s.replied_list ? ` and adds the contact to the list ${s.replied_list}` : ''}. Only an instance of Orchestra's own organization can read the portal mail.`),
    state,
    el('div', { class: 'ox-actions' }, [now]),
  ]);
}

/** Which integrations answer: read-only facts, a look again, and the link to where they are connected. */
function integrations(s, reload) {
  const t = transportsOf(s);
  const look = el('button', { type: 'button', class: 'oc-btn oc-btn--sm' }, 'Look again');
  look.addEventListener('click', async () => {
    look.disabled = true;
    look.textContent = 'Checking…';
    if (await checkConnections(s)) { reload(); return; }
    look.disabled = false;
    look.textContent = 'Look again';
  });
  const auto = t.resend.ok ? 'Resend' : (t.gmail.ok ? 'Gmail' : 'Resend');
  return el('section', { class: 'ox-section' }, [
    el('h2', { class: 'oc-h2' }, 'Mail integrations'),
    el('p', { class: 'oc-help' }, `Each campaign chooses what sends it: Resend (batches, your own domain, bounces and opens reported) or Gmail (the connected account, one email at a time, replies in that inbox). A campaign that chooses neither goes through whichever answers, Resend first: today that is ${auto}. They are connected in Integrations; this looks at what answered last.`),
    ...connectionLines(s),
    el('div', { class: 'oc-row ox-start__do' }, [
      el('a', { class: 'oc-btn oc-btn--sm', href: INTEGRATIONS, target: '_blank', rel: 'noopener' }, 'Open Integrations ↗'),
      look,
    ]),
  ]);
}

// Sender, footer, broadcasts' and sequences' pace, the stages and which of them get their
// email looked up are managed in Orchestra (Apps → Outreach → Ajustes): typed, next to its
// Resend and Gmail connections and who looks emails up. Here, what they are now and a way there.
function managed(s) {
  const link = el('a', { class: 'oc-btn oc-btn--primary', target: '_blank', rel: 'noopener', hidden: true }, 'Open the settings in Orchestra');
  const where = el('p', { class: 'oc-help' }, 'In Orchestra: Apps → Outreach → Ajustes.');
  if (Orch.manageUrl) Orch.manageUrl('settings').then((url) => { if (url) { link.href = url; link.hidden = false; where.hidden = true; } });
  const dayNames = (v, all) => { let raw = String(v || ''); try { const j = JSON.parse(raw); if (Array.isArray(j)) raw = j.join(','); } catch { /* "1,2,3" */ } const n = raw.split(',').map(Number).filter((x) => x >= 1 && x <= 7); return n.length ? n.map((x) => DAYS[x - 1][1]).join(', ') : all; };
  const bHours = s.broadcast_window_start && s.broadcast_window_end ? `${s.broadcast_window_start}–${s.broadcast_window_end}, ${dayNames(s.broadcast_days, 'every day')}` : 'any hour';
  const facts = [
    ['Sender', s.from_email ? `${s.from_name ? `${s.from_name} ` : ''}<${s.from_email}>` : '— (not set yet: Resend sends nothing without it)'],
    ['Replies go to', s.reply_to || 'the same address'],
    ['Under every email', [s.footer ? 'your line' : null, s.postal_address ? 'postal address' : null, s.unsubscribe_text ? `"${s.unsubscribe_text}"` : 'the unsubscribe link in the headers'].filter(Boolean).join(', ')],
    ['Broadcasts', `${Number(s.broadcast_per_run) ? `${s.broadcast_per_run} each 5 minutes` : 'batches of 100'}, at most ${s.broadcast_daily_cap || 500} a day, ${bHours}`],
    ['Sequences', `one every ${s.send_every_minutes || 30} minutes, at most ${s.daily_cap || 20} a day, ${s.window_start || '09:00'}–${s.window_end || '18:00'} ${s.timezone || 'UTC'}, ${dayNames(s.send_days || '1,2,3,4,5', 'Mon–Fri')}`],
    ['Stages', list(s.stages).join(', ') || '—'],
    ['Emails looked up in', list(s.enrich_stages).join(', ') || 'no stage', `, ${s.enrich_per_run || 10} a run`],
  ].map(([k, ...v]) => [k, v.join('')]);
  const page = el('p', { class: 'oc-help' }, 'Checking the unsubscribe page…');
  const url = String(s.unsubscribe_url || '').split('#')[0];
  if (!url) page.textContent = 'No unsubscribe page is set: a campaign with the link cannot go out.';
  else {
    fetch(url, { credentials: 'omit', cache: 'no-store' }).then((r) => (r.ok ? r.text() : '')).then((html) => {
      const ok = /outreach-unsubscribe/.test(html);
      page.className = ok ? 'oc-help' : 'ox-note ox-note--warn';
      page.textContent = ok ? 'The unsubscribe page is public: the link works for anyone.' : 'The unsubscribe page does not open for everyone yet, so the link may ask for a sign-in.';
    }).catch(() => { page.textContent = 'The unsubscribe page could not be reached from here.'; });
  }
  return el('section', { class: 'ox-section' }, [
    el('h2', { class: 'oc-h2' }, 'Sender, footer, pace and stages'),
    el('p', { class: 'oc-help' }, 'Managed in Orchestra, with the Resend and Gmail connections Outreach sends through.'),
    el('ul', { class: 'oc-stack' }, facts.map(([k, v]) => el('li', [el('b', `${k}: `), v]))),
    page,
    el('div', { class: 'oc-row' }, [link]), where,
  ]);
}

/** The brake: pause every campaign at once, broadcasts included. */
function sending(s, reload) {
  const paused = Number(s.paused) === 1;
  return el('section', { class: 'ox-section' }, [
    el('h2', { class: 'oc-h2' }, 'Sending'),
    el('div', { class: 'ox-inline' }, [
      el('p', { class: paused ? 'ox-note ox-note--warn' : 'oc-help' }, paused ? 'Sending is paused: nothing leaves, from any campaign, broadcasts included.' : 'Sending is on.'),
      el('button', { class: 'oc-btn', type: 'button', onClick: async () => {
        if (!paused && !(await Orch.confirm('Pause all sending? Nothing leaves until you resume it; the queue keeps its order.', { yes: 'Pause' }))) return;
        if (await act(paused ? A.resumeSending : A.pauseSending, { id: s._id }, paused ? 'Sending resumed.' : 'Sending paused.')) reload();
      } }, paused ? 'Resume sending' : 'Pause all sending'),
    ]),
  ]);
}

function automations() {
  const row = (name, what, run, label) => el('li', {}, [
    el('div', {}, [el('span', {}, name), el('p', { class: 'oc-small oc-muted' }, what)]),
    run ? el('button', { class: 'oc-btn oc-btn--sm', type: 'button', onClick: () => act(run, {}, `${name}: running now.`) }, label) : el('span'),
  ]);
  return el('section', { class: 'ox-section' }, [
    el('h2', { class: 'oc-h2' }, 'Automations'),
    el('p', { class: 'oc-help' }, 'They run on their own, as workflows (Workflows → Scheduled). Each one only runs when there is something to do.'),
    el('ul', { class: 'ox-rows' }, [
      row('Broadcast', 'Every five minutes while a broadcast is due or sending: batches of 100, up to the daily limit.', A.broadcastNow, 'Run now'),
      row('Write emails', 'Every half hour while a sequence is active: writes the email of each new contact of its recipients.', A.queueNow, 'Run now'),
      row('Send', 'Every ten minutes it checks whether a sequence email is due, and sends the oldest.', null),
      row('Bounces', 'Every hour: asks Resend what happened to sent emails; a bounce or a spam complaint marks the contact and goes on the no-contact list.', A.checkBouncesNow, 'Run now'),
      row('Find emails', 'Every half hour, when contacts in the chosen stages have none: the agent looks them up.', A.findEmailsNow, 'Run now'),
      row('Count recipients, Test send, Import contacts, Add to a list, Unsubscribe', 'Run when you ask for them here, or when someone presses Unsubscribe.', null),
    ]),
  ]);
}
