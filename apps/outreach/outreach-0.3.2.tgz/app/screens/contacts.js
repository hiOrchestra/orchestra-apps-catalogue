// Contacts: everyone Outreach can write to, and where each one stands. The
// tabs are their status, like Sendy's: Active, Unsubscribed, Bounced, Marked
// as spam, Blocked; only Active ones get email. The work here is marking:
// tick contacts to add them to a list, move them to a stage, unsubscribe or
// block them. A row opens the contact: everything known about it, its lists
// and audiences, and every email it got. Filters and columns for the custom
// fields come from Settings (outreach_fields), so a new field needs no code.
import { V, T, A, MC, badge, settings, fields, list, act, tagsOf, who, downloadCsv, plural } from '../data.js';
import { ago } from '../time.js';
import { editContact, listDialog, stageDialog } from './contact-form.js';

const { el, router, fmt } = Orch;
const EMAIL_STATES = ['Has email', 'Waiting for lookup', 'Searching', 'Not found', 'No email'];
const chips = (tags) => (tags.length ? el('span', { class: 'ox-tags' }, [
  ...tags.slice(0, 2).map((t) => el('span', { class: 'oc-badge' }, t)), tags.length > 2 ? el('span', { class: 'oc-muted' }, ` +${tags.length - 2}`) : null,
]) : '—');

export async function render(_params, path) {
  const lookup = el('p', { class: 'oc-help' });
  const tabs = el('nav', { class: 'ox-tabs', 'aria-label': 'Status' });
  const table = el('div', { class: 'ox-contacts' });
  const query = new URLSearchParams(String(path || '').split('?')[1] || '');
  const [s, fs] = await Promise.all([settings(), fields()]);
  const stages = list(s && s.stages);
  const lists = list(s && s.tags);
  const listFields = fs.filter((f) => f.kind === 'list');
  const keep = ['tags', 'stage', 'country', ...listFields.map((f) => f.key)].filter((k) => query.get(k));
  let t = null;
  Orch.mount('view', el('div', { class: 'ox-page' }, [
    el('header', { class: 'ox-head' }, [
      el('div', { class: 'ox-head__text' }, [
        el('h1', { class: 'oc-h1 oc-h1--collection' }, 'Contacts'),
        el('p', { class: 'oc-lede' }, 'One per address. Tick contacts to add them to a list or move them to a stage; campaigns write to lists and audiences.'),
      ]),
      el('div', { class: 'ox-actions' }, [
        keep.length ? router.link(`/audiences/new?${keep.map((k) => `${k}=${encodeURIComponent(query.get(k))}`).join('&')}`,
          'Save these filters as an audience', { class: 'oc-btn oc-btn--ghost' }) : null,
        el('button', { class: 'oc-btn', type: 'button', onClick: () => listDialog(t, s) }, 'Lists…'),
        stages.length ? el('button', { class: 'oc-btn', type: 'button', onClick: () => stageDialog(t, stages) }, 'Stage…') : null,
        router.link('/contacts/import', 'Import', { class: 'oc-btn' }),
        el('button', { class: 'oc-btn', type: 'button', onClick: () => exportNow(query, listFields) }, 'Export'),
        el('button', { class: 'oc-btn oc-btn--primary', type: 'button', onClick: () => editContact(null) }, 'Add a contact'),
      ]),
    ]),
    tabs,
    lookup,
    table,
  ]));
  statusTabs(tabs, query.get('state') || '');
  lookupLine(lookup, s);
  t = Orch.pattern('queue', {
    into: table, path: '/contacts', query: path, view: V.contacts, sort: 'name:asc', pageSize: 50,
    empty: 'No contact matches. Add one, import a file, or ask your agent to import a list.',
    search: ['name', 'organization', 'email'], searchLabel: 'Search', searchPlaceholder: 'Name, organisation or address',
    filters: [
      // The status is chosen with the tabs above; this filter only carries it.
      { key: 'state', label: 'Status', all: 'Any status', options: MC.STATUSES.map((x) => ({ value: x, label: MC.STATUS_LABEL[x] })) },
      { key: 'tags', label: 'List', all: 'Any', op: 'like', options: lists.map((x) => ({ value: `|${x}|`, label: x })) },
      ...(stages.length ? [{ key: 'stage', label: 'Stage', all: 'Any stage', options: stages }] : []),
      ...listFields.map((f) => ({ key: f.key, label: f.label, all: 'Any', options: list(f.options) })),
      { key: 'email_state', label: 'Email', all: 'Any', options: EMAIL_STATES },
      { key: 'country', label: 'Country', op: 'like', placeholder: 'Any' },
    ],
    columns: [
      // The organisation beside the name only when it says something more.
      { key: 'name', label: 'Name', format: (v, r) => who(r) },
      ...listFields.filter((f) => Number(f.in_list) === 1).map((f) => ({ key: f.key, label: f.label })),
      ...(stages.length ? [{ key: 'stage', label: 'Stage' }] : []),
      { key: 'email_state', label: 'Email', render: (r) => (r.email_state === 'Has email' ? r.email : badge(r.email_state)) },
      { key: 'tags', label: 'Lists', sortable: false, render: (r) => chips(tagsOf(r.tags)) },
      { key: 'state', label: 'Status', render: (r) => (r.state === 'Active' ? el('span', { class: 'oc-muted' }, 'Active') : badge(r.state)) },
      { key: 'last_at', label: 'Last email', render: (r) => (r.last_status ? `${r.last_status} · ${ago(r.last_at)}` : '—') },
    ],
    bulk: [
      { label: 'Unsubscribe', action: A.unsubscribe, danger: true, confirm: 'Unsubscribe {n}? Their addresses go on the no-contact list and their pending emails are cancelled. No campaign writes to them again; only they can ask to be back.', done: 'Unsubscribing {n}: it takes a few seconds' },
      { label: 'Block', action: A.block, danger: true, confirm: 'Block {n}? No campaign writes to them until you allow them again. All must be active ones.', done: '{n} blocked' },
      { label: 'Allow again', action: A.unblock, confirm: 'Allow {n} blocked contacts again? Campaigns can write to them again. Tick only blocked ones: unsubscribed contacts are allowed one by one, bounced and marked-as-spam never.', done: '{n} allowed again' },
      { label: 'Look up again', action: A.lookUpAgain, confirm: 'Look up the email of {n} again? Only contacts whose email was not found can be.', done: '{n} back in line for the lookup' },
    ],
    detail: { title: 'Contact', table: T.contacts, render: (row) => panel(row, fs, stages) },
  });
}

/** The status tabs with how many are in each: one request, grouped by the server. */
async function statusTabs(host, current) {
  let counts = {};
  let total = 0;
  try {
    const g = await Orch.db.count(T.contacts, { group: 'status' });
    for (const x of g.groups || []) counts[x.value || 'Active'] = (counts[x.value || 'Active'] || 0) + x.count;
    total = g.total || Object.values(counts).reduce((a, b) => a + b, 0);
  } catch { counts = {}; }
  const tab = (value, label, n) => router.link(value ? `/contacts?state=${encodeURIComponent(value)}` : '/contacts', [
    el('span', label), el('span', { class: 'ox-count' }, n === undefined ? '' : fmt.number(n || 0)),
  ], { class: 'ox-tab', 'aria-current': current === value ? 'page' : 'false' });
  Orch.mount(host, [tab('', 'All', total), ...MC.STATUSES.map((st) => tab(st, MC.STATUS_LABEL[st], counts[st]))]);
}

async function lookupLine(host, s) {
  if (!s) return;
  const stages = list(s.enrich_stages);
  if (!stages.length) { host.textContent = ''; host.hidden = true; return; }
  const [waiting, searching] = await Promise.all([
    Orch.db.view(V.contacts, { filter: { email_state: 'Waiting for lookup', state: 'Active' }, count: true, limit: 1 }),
    Orch.db.view(V.contacts, { filter: { email_state: 'Searching' }, count: true, limit: 1 }),
  ]);
  const agent = s.enrich_agent ? s.enrich_agent.charAt(0).toUpperCase() + s.enrich_agent.slice(1) : 'The agent';
  if (!waiting.total && !searching.total) {
    host.textContent = `${agent} looks up the email of contacts in ${stages.join(', then ')}. Nobody is waiting: each of them has an email or was already looked up.`;
    return;
  }
  Orch.mount(host, [
    `${agent} looks up the email of contacts in ${stages.join(', then ')}: ${fmt.number(s.enrich_per_run || 10)} every half hour. `,
    `${fmt.number(waiting.total)} waiting, ${fmt.number(searching.total)} being looked up now. `,
    el('button', { class: 'oc-btn oc-btn--sm', type: 'button', onClick: () => act(A.findEmailsNow, {}, 'Looking them up now: results in a few minutes.') }, 'Look up now'),
  ]);
}

/** The contacts the list shows now (its filters and search), as a CSV file. */
async function exportNow(query, listFields) {
  const filter = {};
  for (const key of ['state', 'stage', 'email_state', ...listFields.map((f) => f.key)]) if (query.get(key)) filter[key] = query.get(key);
  if (query.get('tags')) filter.tags = { like: query.get('tags') };
  if (query.get('country')) filter.country = { like: query.get('country') };
  if (query.get('q')) filter['name,organization,email'] = { like: query.get('q') };
  Orch.toast('Preparing the file…');
  const n = await downloadCsv({ view: V.contacts, filter, name: 'contacts',
    columns: ['name', 'email', 'organization', 'title', 'website', 'country', 'city', 'stage', 'state', 'tags', ...listFields.map((f) => f.key), 'email_state', 'notes', 'source', 'added_at'] });
  Orch.toast(`${plural(n, 'contact', 'contacts')} exported.`);
}

/** Everything known about the contact, then the emails it got. */
function panel(row, fs, stages) {
  const history = el('div', {}, el('p', { class: 'oc-muted' }, 'Loading its emails…'));
  Orch.db.list(T.sends, { filter: { contact_id: row._id }, sort: '_id:desc', limit: 20 }).then((r) => {
    Orch.mount(history, (r.rows || []).length
      ? el('ul', { class: 'ox-rows' }, r.rows.map((x) => el('li', {}, [
        el('div', {}, [el('span', {}, x.subject || '—'), el('p', { class: 'oc-small oc-muted' }, `${ago(x.sent_at || x.queued_at)}${x.last_event && x.last_event !== 'delivered' ? ` · ${x.last_event}` : ''}${x.unsubscribed_at ? ' · unsubscribed from it' : ''}`)]),
        badge(x.status)])))
      : el('p', { class: 'oc-muted' }, 'No email written to this contact yet.'));
  }).catch((e) => Orch.mount(history, el('p', { class: 'oc-muted' }, e.message)));
  const status = MC.statusOf(row);
  const facts = [
    ['Name', row.name], ['Organisation', row.organization], ['Stage', row.stage],
    ['Email', row.email ? `${row.email}${row.email_status ? ` (${row.email_status})` : ''}` : (row.email_status || 'None yet')],
    ['Where it was found', row.email_source], ['Website', row.website],
    ...fs.map((f) => [f.label, row[f.key]]),
    ['Lists', tagsOf(row.tags).join(', ')], ['Came from', row.source], ['Notes', row.notes],
  ].filter(([, v]) => v !== null && v !== undefined && String(v).trim() !== '');
  // Which audiences it is in: an audience is conditions, so a contact meets
  // several at once. Asked of the server, one count per audience.
  const inAudiences = el('dd', {}, '…');
  Orch.db.view(V.audiences, { limit: 200 }).then(async (r) => {
    const names = [];
    await Promise.all((r.rows || []).map(async (a) => {
      let f;
      try { f = JSON.parse(a.filter || '{}'); } catch { return; }
      if (await Orch.db.count(T.contacts, { filter: { ...f, _id: row._id } }).catch(() => 0)) names.push(a.name);
    }));
    inAudiences.textContent = names.length ? names.sort((x, y) => x.localeCompare(y)).join(', ') : 'None';
  }).catch(() => { inAudiences.textContent = '—'; });
  const state = status === 'Active' ? null : el('div', { class: `ox-note ${status === 'Blocked' || status === 'Unsubscribed' ? 'ox-note--warn' : 'ox-note--bad'}` }, [
    el('p', { class: 'ox-note__title' }, `${MC.STATUS_LABEL[status]}: no campaign writes to them`),
    row.status_note ? el('p', {}, `${row.status_note}${row.status_at ? ` · ${ago(row.status_at)}` : ''}`) : null,
    status === 'Unsubscribed' ? el('p', { class: 'oc-small' }, 'Only they can undo it. If they asked to be back, take their address off the no-contact list in Settings, then allow them again.') : null,
    status === 'Bounced' || status === 'Complained' ? el('p', { class: 'oc-small' }, 'Their address is on the no-contact list, and the app does not allow them again: writing to an address that bounced or reported spam hurts every email you send. If they have a new address, add it as a new contact.') : null,
  ]);
  const setStatus = async (name, done) => { if (await act(name, { ids: [row._id] }, done)) router.go('/contacts'); };
  return el('div', { class: 'oc-stack' }, [
    state,
    el('dl', { class: 'oc-dl' }, [
      ...facts.map(([k, v]) => el('div', { class: 'oc-dl__row' }, [el('dt', k), el('dd', String(v))])),
      el('div', { class: 'oc-dl__row' }, [el('dt', 'Audiences'), inAudiences]),
    ]),
    el('div', { class: 'ox-actions' }, [
      el('button', { class: 'oc-btn oc-btn--primary', type: 'button', onClick: () => editContact(row, fs, stages) }, 'Edit'),
      status === 'Active' ? el('button', { class: 'oc-btn', type: 'button', onClick: async () => {
        if (await Orch.confirm('Unsubscribe them? Their address goes on the no-contact list and their pending emails are cancelled. No campaign writes to them again; only they can ask to be back.', { yes: 'Unsubscribe', danger: true })) setStatus(A.unsubscribe, 'Unsubscribing: it takes a few seconds.');
      } }, 'Unsubscribe') : null,
      status === 'Active' ? el('button', { class: 'oc-btn oc-btn--ghost', type: 'button', onClick: () => setStatus(A.block, 'Blocked.') }, 'Block') : null,
      status === 'Blocked' || status === 'Unsubscribed' ? el('button', { class: 'oc-btn', type: 'button', onClick: async () => {
        if (await Orch.confirm(status === 'Unsubscribed' ? 'Allow them again? Only if they asked to be back. Their address stays on the no-contact list until you take it off in Settings.' : 'Allow them again? Campaigns can write to them again.', { yes: 'Allow again' })) setStatus(status === 'Unsubscribed' ? A.resubscribe : A.unblock, 'They can be written to again.');
      } }, 'Allow again') : null,
    ]),
    el('h3', { class: 'oc-h3' }, 'Emails'),
    history,
  ]);
}
