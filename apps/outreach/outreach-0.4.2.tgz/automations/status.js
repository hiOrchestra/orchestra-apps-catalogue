#!/usr/bin/env node
'use strict';
/**
 * Bounces: asks Resend what happened to the emails that left.
 *
 * Sequences, one email at a time: each sent email is asked about three
 * times, 30 minutes, 6 hours and 2 days after it left, which is when bounces
 * and complaints show up.
 *
 * Broadcasts, all their emails at once: 1 hour, 24 hours and 72 hours after
 * one started, Resend's list of sent emails is read 100 at a time, newest
 * first, down to where the broadcast began. One call per hundred emails instead
 * of one per email.
 *
 * Only emails Resend sent: Gmail (provider id "gmail:…") reports no events
 * through the API, so those are left as Sent.
 *
 * Whatever the kind, Resend's last event is kept on the email (delivered,
 * opened, clicked, bounced, complained). A bounce marks the email Bounced;
 * a bounce or a complaint marks the contact Bounced or Complained and puts
 * the address on the no-contact list, so no campaign writes to it again.
 */
const L = require('./lib');

const AFTER = ['-30 minutes', '-6 hours', '-48 hours'];
const BROADCAST_AFTER_HOURS = [1, 24, 72];
const MAX_PAGES = Number(process.env.OUTREACH_STATUS_MAX_PAGES || 60);

async function main() {
  const out = { ok: true, ran: 'bounces', checked: 0, bounced: [], complained: [], errors: [] };
  const listed = new Set(); // one row per address, even when it bounced twice in this run
  const suppress = (email, reason, note) => {
    const e = L.normEmail(email);
    if (listed.has(e)) return [];
    listed.add(e);
    return L.suppressOps(e, reason, note);
  };
  /** The writes one event causes: the email's row, the contact and the list. */
  const apply = (r, event, extra = {}) => {
    const data = { last_event: event ? String(event) : null, checked_at: L.sqlNow(), ...extra };
    const ops = [];
    if (event === 'bounced') {
      Object.assign(data, { status: 'Bounced', error: 'The address bounced' });
      ops.push(...suppress(r.email, 'Bounced', `Bounced on email #${r._id}`));
      if (r.contact_id) ops.push({ op: 'update', table: 'outreach_contacts', id: r.contact_id, data: { status: 'Bounced', status_at: L.sqlNow(), status_note: `Bounced on email #${r._id}` } });
      out.bounced.push(r.email);
    } else if (event === 'complained') {
      ops.push(...suppress(r.email, 'Complained', `Marked as spam on email #${r._id}`));
      if (r.contact_id) ops.push({ op: 'update', table: 'outreach_contacts', id: r.contact_id, data: { status: 'Complained', status_at: L.sqlNow(), status_note: `Marked as spam on email #${r._id}` } });
      out.complained.push(r.email);
    }
    return [{ op: 'update', table: 'outreach_sends', id: r._id, data }, ...ops];
  };

  // ── sequences: one question per email ──────────────────────────────────
  const rows = L.all(`SELECT s._id, s.provider_id, s.email, s.contact_id, COALESCE(s.checks, 0) AS checks FROM outreach_sends s
    JOIN outreach_campaigns k ON k._id = s.campaign_id
    WHERE s._deleted = 0 AND COALESCE(k.kind, 'sequence') = 'sequence' AND s.status = 'Sent' AND s.provider_id IS NOT NULL AND s.provider_id <> ''
      AND s.provider_id NOT LIKE 'gmail:%'
      AND COALESCE(s.checks, 0) < 3 AND datetime(s.sent_at) >= datetime('now', '-7 days')
      AND datetime(s.sent_at) <= datetime('now', CASE COALESCE(s.checks, 0) WHEN 0 THEN ? WHEN 1 THEN ? ELSE ? END)
    ORDER BY datetime(s.sent_at) LIMIT 40`, ...AFTER);
  for (const r of rows) {
    let event;
    try {
      event = L.pick(await L.composio('RESEND_RETRIEVE_EMAIL', { email_id: r.provider_id }), 'last_event');
    } catch (e) {
      out.errors.push({ id: r._id, error: String(e.message || e).slice(0, 200) });
      continue;
    }
    L.write(apply(r, event, { checks: r.checks + 1 }));
    out.checked += 1;
  }

  // ── broadcasts: Resend's list, a hundred at a time ─────────────────────
  const due = L.all(`SELECT * FROM outreach_campaigns WHERE _deleted = 0 AND kind = 'broadcast' AND frozen_at IS NOT NULL
    AND COALESCE(checks, 0) < ? AND next_check_at IS NOT NULL AND datetime(next_check_at) <= datetime('now') ORDER BY _id`, BROADCAST_AFTER_HOURS.length)
    .filter((k) => {
      // A broadcast Gmail sent has nothing to ask Resend about: its checks are over.
      const resend = L.one(`SELECT COUNT(*) AS n FROM outreach_sends WHERE _deleted = 0 AND campaign_id = ? AND provider_id IS NOT NULL AND provider_id <> '' AND provider_id NOT LIKE 'gmail:%'`, k._id).n;
      if (resend > 0) return true;
      L.write([{ op: 'update', table: 'outreach_campaigns', id: k._id, data: { checks: BROADCAST_AFTER_HOURS.length, next_check_at: null } }]);
      out.gmailOnly = (out.gmailOnly || []).concat(k._id);
      return false;
    });
  if (due.length) {
    const since = due.map((k) => L.toDate(k.started_at || k.frozen_at)).filter(Boolean).reduce((a, b) => (a < b ? a : b), new Date());
    const floor = new Date(since.getTime() - 3600000);
    const events = new Map();
    let after = null;
    let pages = 0;
    let complete = false;
    try {
      while (pages < MAX_PAGES) {
        const res = await L.composio('RESEND_LIST_EMAILS', after ? { limit: 100, after } : { limit: 100 });
        pages += 1;
        const list = findList(res);
        for (const e of list) if (e && e.id) events.set(String(e.id), e.last_event ? String(e.last_event) : null);
        const last = list[list.length - 1];
        const oldest = last && L.toDate(last.created_at);
        if (!list.length || !hasMore(res) || (oldest && oldest < floor)) { complete = true; break; }
        after = String(last.id);
      }
    } catch (e) {
      out.errors.push({ broadcasts: due.map((k) => k._id), error: String(e.message || e).slice(0, 200) });
    }
    out.pages = pages;
    for (const k of due) {
      const sends = L.all(`SELECT _id, provider_id, email, contact_id, last_event, status FROM outreach_sends
        WHERE _deleted = 0 AND campaign_id = ? AND status IN ('Sent', 'Replied') AND provider_id IS NOT NULL AND provider_id <> '' AND provider_id NOT LIKE 'gmail:%'`, k._id);
      const ops = [];
      let seen = 0;
      for (const r of sends) {
        if (!events.has(r.provider_id)) continue;
        seen += 1;
        const event = events.get(r.provider_id);
        if (event === r.last_event) continue;
        ops.push(...apply(r, event));
      }
      L.write(ops);
      out.checked += seen;
      // Asked in full (or nothing left to learn): move on to the next check.
      if (complete || seen === sends.length) {
        const checks = Number(k.checks || 0) + 1;
        const next = checks < BROADCAST_AFTER_HOURS.length
          ? L.sqlNow(new Date(L.toDate(k.started_at || k.frozen_at).getTime() + BROADCAST_AFTER_HOURS[checks] * 3600000)) : null;
        L.write([{ op: 'update', table: 'outreach_campaigns', id: k._id, data: { checks, next_check_at: next } }]);
      }
    }
  }
  return L.done(out);
}

/** The emails in Resend's answer: { data: [...] } however deep Composio wraps it. */
function findList(res) {
  const walk = (v) => {
    if (Array.isArray(v)) return v.length === 0 || v.every((x) => x && typeof x === 'object' && x.id !== undefined) ? v : null;
    if (v && typeof v === 'object') for (const x of Object.values(v)) { const f = walk(x); if (f) return f; }
    return null;
  };
  return walk(res) || [];
}
function hasMore(res) {
  const v = L.pick(res, 'has_more');
  return v === true || v === 'true';
}

main().catch((e) => {
  process.stderr.write(`bounces: ${e.message}\n`);
  process.exit(1);
});
