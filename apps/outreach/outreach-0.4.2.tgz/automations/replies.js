#!/usr/bin/env node
'use strict';
/**
 * Replies: asks the portal's mail (through this instance's api-server, which
 * asks orchestra-backend with the instance's own token) for inbound mail from
 * the addresses our campaigns wrote to in the last 30 days. A reply that
 * arrived after an email left marks that email Replied; the contact joins
 * Settings' `replied_list`, so later campaigns that exclude it skip them. The
 * person hears on Telegram who answered. Settings note when it last looked and
 * why it could not (`replies_checked_at`, `replies_error`).
 *   node replies.js
 */
const L = require('./lib');

const DAYS = 30;

/** A subject without its reply and forward prefixes, lowercased, spaces collapsed. */
function bareSubject(subject) {
  let s = String(subject || '').toLowerCase().replace(/\s+/g, ' ').trim();
  for (let i = 0; i < 6; i += 1) {
    const next = s.replace(/^(re|aw|sv|vs|rv|fw|fwd|wg|tr|r)\s*(\[\d+\])?\s*:\s*/i, '').trim();
    if (next === s) break;
    s = next;
  }
  return s;
}

/**
 * Is an inbound mail an answer to the email we sent? Its subject, stripped of
 * Re:/Fwd:, must be ours (or contain ours). Mail from the same address about
 * something else, like a calendar invitation, is not an answer.
 */
function answers(sentSubject, inboundSubject) {
  const ours = bareSubject(sentSubject);
  const theirs = bareSubject(inboundSubject);
  if (!ours || !theirs) return false;
  return theirs === ours || theirs.includes(ours);
}

async function main() {
  const s = L.settings();
  const out = { ok: true, ran: 'replies', asked: 0, found: 0, replied: [], listed: 0 };
  const note = (error) => L.write([{ op: 'update', table: 'outreach_settings', id: s._id, data: { replies_checked_at: L.sqlNow(), replies_error: error ? String(error).slice(0, 300) : null } }]);

  const sends = L.all(`SELECT s._id, s.campaign_id, s.contact_id, LOWER(TRIM(s.email)) AS email, s.sent_at, s.status, s.subject
    FROM outreach_sends s WHERE s._deleted = 0 AND s.status IN ('Sent', 'Replied') AND s.sent_at IS NOT NULL
      AND datetime(s.sent_at) >= datetime('now', '-${DAYS} days') ORDER BY datetime(s.sent_at)`);
  const open = sends.filter((r) => r.status === 'Sent');
  if (!open.length) { note(null); return L.done({ ...out, skipped: `Nothing sent in the last ${DAYS} days is waiting for an answer` }); }
  const addresses = [...new Set(open.map((r) => r.email).filter((e) => L.EMAIL.test(e)))];
  const since = new Date(`${String(open[0].sent_at).replace(' ', 'T')}Z`);
  out.asked = addresses.length;

  let data;
  try {
    data = await L.apiJson('POST', '/api/mail/replies', { from: addresses, since: since.toISOString() });
  } catch (e) {
    note(e.message || e);
    return L.done({ ...out, ok: false, error: String(e.message || e).slice(0, 300) });
  }
  const replies = Array.isArray(data && data.replies) ? data.replies : [];
  out.found = replies.length;

  // Every inbound mail per address, with the moment it arrived.
  const byFrom = new Map();
  for (const r of replies) {
    const m = String(r.from || '').match(/<([^>]+)>/); // the backend sends bare addresses; a display name is tolerated
    const from = L.normEmail(m ? m[1] : r.from);
    const at = L.toDate(r.receivedAt);
    if (!from || !at) continue;
    if (!byFrom.has(from)) byFrom.set(from, []);
    byFrom.get(from).push({ at, subject: r.subject || '', snippet: r.snippet || '' });
  }

  const ops = [];
  const contacts = new Set();
  out.ignored = 0;
  for (const r of open) {
    const mails = byFrom.get(r.email);
    if (!mails) continue;
    // The newest mail that answers THIS email: about our subject, after we wrote.
    const hit = mails.filter((m) => m.at > L.toDate(r.sent_at) && answers(r.subject, m.subject)).sort((a, b) => b.at - a.at)[0];
    if (!hit) { out.ignored += 1; continue; }
    ops.push({ op: 'update', table: 'outreach_sends', id: r._id, when: { status: 'Sent' }, data: { status: 'Replied', replied_at: L.sqlNow(hit.at), reply_status: 'Replied', notes: `Replied ${L.sqlNow(hit.at)} UTC: ${hit.subject}`.slice(0, 300) } });
    if (r.contact_id) contacts.add(r.contact_id);
    out.replied.push({ email: r.email, campaign: r.campaign_id, at: L.sqlNow(hit.at) });
  }
  if (ops.length) L.write(ops);

  // The contacts join the list, which is registered in Settings when new.
  const list = String(s.replied_list || '').trim().replace(/\|/g, '/');
  if (list && contacts.size) {
    const rows = L.all(`SELECT _id, tags FROM outreach_contacts WHERE _deleted = 0 AND _id IN (${[...contacts].map(() => '?').join(',')})`, ...contacts);
    const tagOps = [];
    for (const c of rows) {
      const tags = String(c.tags || '').split('|').map((x) => x.trim()).filter(Boolean);
      if (tags.includes(list)) continue;
      tagOps.push({ op: 'update', table: 'outreach_contacts', id: c._id, data: { tags: `|${[...tags, list].join('|')}|` } });
    }
    if (tagOps.length) L.write(tagOps);
    out.listed = tagOps.length;
    const known = L.jsonList(s.tags);
    if (!known.includes(list)) L.write([{ op: 'update', table: 'outreach_settings', id: s._id, data: { tags: JSON.stringify([...known, list].sort((a, b) => a.localeCompare(b))) } }]);
  }
  note(null);
  if (out.replied.length) {
    const who = [...new Set(out.replied.map((r) => r.email))];
    out.telegram = L.notify(s, `Outreach: ${who.length === 1 ? 'a reply' : `${who.length} replies`} at the portal mail: ${who.slice(0, 10).join(', ')}${who.length > 10 ? '…' : ''}.${list ? ` Added to "${list}".` : ''}`);
  }
  return L.done(out);
}

module.exports = { bareSubject, answers };

if (require.main === module) main().catch((e) => {
  process.stderr.write(`replies: ${e.message}\n`);
  process.exit(1);
});
