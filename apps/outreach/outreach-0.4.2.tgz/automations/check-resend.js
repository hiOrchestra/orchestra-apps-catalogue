#!/usr/bin/env node
'use strict';
/**
 * Check the mail integrations: asks Resend for its latest email and Gmail for
 * its profile (one read each, nothing is sent) and notes in Settings whether
 * each answered, and which Gmail account it is, for Getting started, Settings
 * and the campaign's "Sends through". The integrations are connected in the
 * portal (Integrations), which this app cannot see; an integration answering
 * through Composio is how it knows. The file keeps its old name so the
 * workflow that runs it needs no change.
 *   node check-resend.js
 */
const L = require('./lib');

async function main() {
  const out = { ok: true, ran: 'check mail' };
  try {
    await L.composio('RESEND_LIST_EMAILS', { limit: 1 });
    out.resend = { connected: true };
  } catch (e) {
    const why = L.readable(e.message || e);
    L.noteResend(why);
    out.resend = { connected: false, why };
  }
  try {
    const r = await L.composio('GMAIL_GET_PROFILE', { user_id: 'me' }, 30000);
    out.gmail = { connected: true, account: L.normEmail(L.pick(r, 'emailAddress') || L.pick(r, 'email_address') || '') || null };
  } catch (e) {
    const why = L.readable(e.message || e);
    L.noteGmail(why);
    out.gmail = { connected: false, why };
  }
  // Kept for the screens that read the old shape.
  out.connected = out.resend.connected;
  return L.done(out);
}

main().catch((e) => {
  process.stderr.write(`check mail: ${e.message}\n`);
  process.exit(1);
});
