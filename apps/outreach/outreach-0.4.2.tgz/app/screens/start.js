// The first-run card on top of Campaigns: connect Resend or Gmail, then say
// who the emails come from. Shown until both are done; Hide keeps it away for
// good (outreach_settings.onboarding_hidden_at, so it holds on every device).
// The integrations are connected in the portal, which this app cannot see:
// "Check the connections" asks Resend for one email and Gmail for its profile
// (nothing is sent) and the step reads what that noted. The sender is set in
// Settings, its one home.
import { T, A, act, settings, senderOf, transportsOf, waitFor, INTEGRATIONS } from '../data.js';
import { STEPS, onboarding } from '../onboarding.js';

const { el, router } = Orch;

/** The card, or null when it is done or hidden. `again` draws Campaigns again. */
export async function startCard(s, again) {
  if (!s || s.onboarding_hidden_at) return null;
  const left = await Orch.db.count(T.sends, { filter: { provider_id: { notnull: '1' } } }).catch(() => 0);
  const { done, count, show } = onboarding(s, { left });
  if (!show) return null;
  const hide = el('button', { type: 'button', class: 'oc-btn oc-btn--ghost oc-btn--sm' }, 'Hide');
  hide.addEventListener('click', async () => { hide.disabled = true; if (await act(A.hideStart, { id: s._id })) again(); else hide.disabled = false; });
  const body = { mail: mail(s, done.mail, again), sender: sender(s, done.sender) };
  return el('section', { class: 'oc-card oc-card--pad0 ox-start', 'aria-label': 'Getting started' }, [
    el('header', { class: 'ox-start__head' }, [
      el('h2', { class: 'oc-h2' }, 'Getting started'),
      el('span', { class: 'oc-eyebrow' }, `${count} of ${STEPS.length} done`),
      hide,
    ]),
    el('p', { class: 'oc-help ox-start__lede' }, 'Two things before the first email can go out. Each one ticks itself when it is done.'),
    el('ol', { class: 'ox-start__steps' }, STEPS.map((x, i) => el('li', { class: `ox-start__step${done[x.id] ? ' ox-start__step--done' : ''}` }, [
      el('span', { class: 'oc-value ox-start__n' }, String(i + 1).padStart(2, '0')),
      el('div', { class: 'ox-start__main' }, [
        el('p', { class: 'ox-start__title' }, x.title),
        body[x.id],
      ]),
      el('span', { class: `oc-badge${done[x.id] ? ' oc-badge--good' : ''}` }, done[x.id] ? 'Done' : 'To do'),
    ]))),
  ]);
}

/** One line per integration: answers, did not answer and why, or not checked yet. */
export function connectionLines(s) {
  const t = transportsOf(s);
  const line = (label, x, extra) => (x.error
    ? el('p', { class: 'ox-start__state ox-start__state--bad' }, [`${label} did not answer: `, el('span', { class: 'ox-start__raw' }, x.error), '.'])
    : x.ok ? el('p', { class: 'ox-start__state' }, [`${label} answers${extra ? ` (${extra})` : ''}: emails can go out through it.`])
      : el('p', { class: 'ox-start__state oc-muted' }, `${label}: not checked yet.`));
  return [line('Resend', t.resend), line('Gmail', t.gmail, t.gmail.account)];
}

/** Runs the check workflow and waits for Settings to note the answers; resolves when they did. */
export async function checkConnections(s) {
  const before = `${s.resend_checked_at || ''}|${s.gmail_checked_at || ''}`;
  if (!(await act(A.checkMail, {}))) return false;
  const after = await waitFor(() => settings(), (x) => x && `${x.resend_checked_at || ''}|${x.gmail_checked_at || ''}` !== before, 45);
  if (!after) Orch.toast('No answer yet. Try again in a minute.', { error: true });
  return true;
}

function mail(s, done, again) {
  const check = el('button', { type: 'button', class: 'oc-btn oc-btn--sm' }, 'Check the connections');
  check.addEventListener('click', async () => {
    check.disabled = true;
    check.textContent = 'Checking…';
    if (await checkConnections(s)) { again(); return; }
    check.disabled = false;
    check.textContent = 'Check the connections';
  });
  return el('div', { class: 'ox-start__body' }, [
    el('p', { class: 'ox-start__why' }, 'Outreach sends through your Resend account or your Gmail, connected in Integrations; each campaign chooses which. With Resend, verify the domain your emails come from, or they are refused. With Gmail, emails leave from the connected account, one at a time.'),
    ...connectionLines(s),
    done ? null : el('div', { class: 'oc-row ox-start__do' }, [
      el('a', { class: 'oc-btn oc-btn--primary oc-btn--sm', href: INTEGRATIONS, target: '_blank', rel: 'noopener' }, 'Open Integrations ↗'),
      check,
    ]),
  ]);
}

function sender(s, done) {
  const from = senderOf(null, s);
  const t = transportsOf(s);
  return el('div', { class: 'ox-start__body' }, [
    el('p', { class: 'ox-start__why' }, 'The name and address your emails come from with Resend. The address has to be on the domain you verified there; replies go to it unless you name another. A campaign sent through Gmail comes from the connected account instead.'),
    done ? el('p', { class: 'ox-start__state' }, from.text ? ['Emails come from ', el('span', { class: 'oc-value' }, from.text), '.']
      : ['Gmail sends from ', el('span', { class: 'oc-value' }, t.gmail.account || 'the connected account'), '; set a Resend sender in Settings when you connect Resend.']) : null,
    done ? null : el('div', { class: 'oc-row ox-start__do' }, [router.link('/settings', 'Set it in Settings', { class: 'oc-btn oc-btn--sm' })]),
  ]);
}
