// Settings: who the emails come from (a campaign can have its own), the
// footer and unsubscribe page, the broadcasts' daily limit, the sequences'
// pace and window, which stages get their email looked up, the stages
// themselves, the no-contact list, and the automations that do the work. Each
// section saves on its own. The automations run on the instance; the buttons
// run one now.
import { A, settings, list, act, transportsOf, INTEGRATIONS, waitFor } from '../data.js';
import { noContactList } from './no-contact.js';
import { connectionLines, checkConnections } from './start.js';

const { el } = Orch;
const DAYS = [[1, 'Mon'], [2, 'Tue'], [3, 'Wed'], [4, 'Thu'], [5, 'Fri'], [6, 'Sat'], [7, 'Sun']];
const ZONES = ['Europe/Berlin', 'Europe/Madrid', 'Europe/London', 'Europe/Lisbon', 'America/New_York', 'America/Buenos_Aires', 'UTC'];

export async function render(_params, path) {
  const noContact = el('div');
  Orch.load('view', async () => {
    const s = await settings();
    if (!s) return el('p', { class: 'oc-state' }, 'Outreach has no settings row: it is not installed.');
    const reload = () => render(_params, path);
    const save = (fields, done) => async (data) => {
      const payload = { id: s._id };
      for (const f of fields) if (data[f] !== undefined) payload[f] = data[f];
      if (await act(A.updateSettings, payload, done || 'Saved.')) reload();
    };
    const page = el('div', { class: 'ox-page' }, [
      el('header', { class: 'ox-head' }, [el('div', { class: 'ox-head__text' }, [
        el('h1', { class: 'oc-h1 oc-h1--collection' }, 'Settings'),
        el('p', { class: 'oc-lede' }, 'Who the emails come from, what goes under them, when they leave, and whose email is looked up.'),
      ])]),
      integrations(s, reload),
      sender(s, save),
      footer(s, save),
      broadcasts(s, save),
      pace(s, save, reload),
      replies(s, save, reload),
      lookup(s, save),
      stagesForm(s, save),
      noContact,
      automations(),
    ]);
    return page;
  }).then(() => noContactList(noContact, path));
}

const field = (label, control, help) => el('label', { class: 'oc-field' }, [el('span', { class: 'oc-label' }, label), control, help ? el('span', { class: 'oc-help' }, help) : null]);
const input = (name, value, attrs = {}) => el('input', { class: 'oc-input', name, value: value === null || value === undefined ? '' : String(value), ...attrs });
function section(title, lede, body, onSave) {
  const form = el('form', { class: 'ox-form' }, [...body, el('div', { class: 'ox-actions' }, [el('button', { class: 'oc-btn oc-btn--primary', type: 'submit' }, 'Save')])]);
  Orch.onSubmit(form, onSave);
  return el('section', { class: 'ox-section' }, [el('h2', { class: 'oc-h2' }, title), lede ? el('p', { class: 'oc-help' }, lede) : null, form]);
}

/** Replies found at the portal's mail: which list they join, when it last looked, and a look now. */
function replies(s, save, reload) {
  const now = el('button', { type: 'button', class: 'oc-btn oc-btn--sm' }, 'Look now');
  now.addEventListener('click', async () => {
    now.disabled = true;
    now.textContent = 'Looking…';
    const before = s.replies_checked_at || '';
    if (await act(A.checkRepliesNow, {})) {
      const after = await waitFor(() => settings(), (x) => x && (x.replies_checked_at || '') !== before, 45);
      if (!after) Orch.toast('No answer yet. Try again in a minute.', { error: true });
      reload();
      return;
    }
    now.disabled = false;
    now.textContent = 'Look now';
  });
  const state = s.replies_error
    ? el('p', { class: 'ox-note ox-note--warn' }, `The last look failed: ${s.replies_error}`)
    : (s.replies_checked_at ? el('p', { class: 'oc-help' }, `Last looked ${String(s.replies_checked_at).replace('T', ' ').slice(0, 16)} UTC.`) : el('p', { class: 'oc-help' }, 'It has not looked yet.'));
  const body = section('Replies', 'Every hour, while something sent is waiting for an answer, Outreach asks the portal\'s mail (where replies to your sender land) whether anyone you wrote to answered. An answer marks that email Replied in its campaign and adds the contact to this list; a campaign that excludes the list then skips them. Only an instance of Orchestra\'s own organization can read the portal mail.', [
    field('Replies join the list', input('replied_list', s.replied_list, { maxlength: '80', placeholder: 'e.g. Replied' }), 'Created when the first reply arrives. Empty: replies are marked but join no list.'),
    state,
  ], (d) => save(['replied_list'])({ replied_list: String(d.replied_list || '').replace(/\|/g, '/').trim() }));
  body.querySelector('.ox-actions').appendChild(now);
  return body;
}

/** Which integrations answer: read-only facts, a look again, and the link to where they are connected. */
function integrations(s, reload) {
  const t = transportsOf(s);
  const look = el('button', { type: 'button', class: 'oc-btn oc-btn--sm' }, 'Look again');
  look.addEventListener('click', async () => {
    look.disabled = true;
    look.textContent = 'Checking…';
    if (await checkConnections(s)) { reload(); return; }
    look.disabled = false;
    look.textContent = 'Look again';
  });
  const auto = t.resend.ok ? 'Resend' : (t.gmail.ok ? 'Gmail' : 'Resend');
  return el('section', { class: 'ox-section' }, [
    el('h2', { class: 'oc-h2' }, 'Mail integrations'),
    el('p', { class: 'oc-help' }, `Each campaign chooses what sends it: Resend (batches, your own domain, bounces and opens reported) or Gmail (the connected account, one email at a time, replies in that inbox). A campaign that chooses neither goes through whichever answers, Resend first: today that is ${auto}. They are connected in Integrations; this looks at what answered last.`),
    ...connectionLines(s),
    el('div', { class: 'oc-row ox-start__do' }, [
      el('a', { class: 'oc-btn oc-btn--sm', href: INTEGRATIONS, target: '_blank', rel: 'noopener' }, 'Open Integrations ↗'),
      look,
    ]),
  ]);
}

function sender(s, save) {
  return section('Sender', 'Emails sent through Resend come from this address, unless a campaign has its own. Its domain must be verified in Resend. Emails sent through Gmail come from the connected account instead. A broadcast to people who did not ask for it is best sent from a domain of its own: a spam complaint then does not reach the domain your other email comes from.', [
    el('div', { class: 'ox-grid2' }, [
      field('Name', input('from_name', s.from_name, { maxlength: '120' })),
      field('Address', input('from_email', s.from_email, { type: 'email', required: true })),
      field('Replies go to', input('reply_to', s.reply_to, { type: 'email', placeholder: 'The same address' })),
    ]),
  ], (d) => save(['from_name', 'from_email', 'reply_to'])({ ...d, from_email: d.from_email.trim().toLowerCase(), reply_to: d.reply_to.trim().toLowerCase() }));
}

/** What goes under every email, and where its unsubscribe link leads. */
function footer(s, save) {
  const text = el('textarea', { class: 'oc-textarea', name: 'footer', rows: '2' });
  text.value = s.footer || '';
  const address = el('textarea', { class: 'oc-textarea', name: 'postal_address', rows: '2' });
  address.value = s.postal_address || '';
  const page = el('p', { class: 'oc-help' }, 'Checking the unsubscribe page…');
  const url = String(s.unsubscribe_url || '').split('#')[0];
  if (!url) page.textContent = 'No unsubscribe page is set: a campaign with the link cannot go out.';
  else {
    fetch(url, { credentials: 'omit', cache: 'no-store' }).then((r) => r.text()).then((html) => {
      const ok = /name="outreach-unsubscribe"/.test(html);
      page.className = ok ? 'oc-help' : 'ox-note ox-note--warn';
      page.textContent = ok ? 'The unsubscribe page is public: the link works for anyone.'
        : 'The unsubscribe page is not public yet, so the link opens a sign-in. An admin sets Canvas → Unsubscribe to Public and publishes it.';
    }).catch(() => { page.textContent = 'The unsubscribe page could not be reached from here.'; });
  }
  return section('Footer and unsubscribe', 'Under every email: your line, your postal address (the law asks for one in most countries), and, in a campaign that has it, the unsubscribe link. Unsubscribing is from every campaign.', [
    field('Your line', text, 'Who you are, in one line. Leave it empty for none.'),
    field('Postal address', address, 'Company name and address, as on your invoices.'),
    el('div', { class: 'ox-grid2' }, [
      field('The unsubscribe link says', input('unsubscribe_text', s.unsubscribe_text || '', { maxlength: '60', placeholder: 'Unsubscribe' }),
        'Shown as the last line of each email. Leave it empty and the link travels only in the email headers: mail apps show their own Unsubscribe button and no line is added.'),
      field('Logo on the simple layout (a URL)', input('html_logo_url', s.html_logo_url, { type: 'url', placeholder: 'https://… (optional)' })),
    ]),
    field('Unsubscribe page', input('unsubscribe_url', url, { type: 'url', required: true }), 'The public page the link leads to. Set when Outreach was installed; change it only if the instance has another address.'),
    page,
  ], (d) => save(['footer', 'postal_address', 'unsubscribe_text', 'html_logo_url', 'unsubscribe_url'])({
    ...d, footer: d.footer.trim(), postal_address: d.postal_address.trim(), unsubscribe_text: d.unsubscribe_text.trim(),
    html_logo_url: d.html_logo_url.trim(), unsubscribe_url: d.unsubscribe_url.trim(),
  }));
}

/** How many broadcast emails may leave in a day, across broadcasts. */
function broadcasts(s, save) {
  const perRun = Number(s.broadcast_per_run) || 0;
  const days = String(s.broadcast_days || '').split(',');
  const noDays = !String(s.broadcast_days || '').trim();
  return section('Broadcasts', `How fast a broadcast leaves, and when. The sender runs every five minutes: with a pace it sends that many each run (1 is 12 an hour, 2 is 24), one at a time like a person would; without one it sends in batches of 100 as fast as the integration takes them. With hours, nothing leaves outside them (${s.timezone || 'UTC'}, the time zone of the sequences); the rest waits for the next opening. The daily limit holds either way. A new domain earns trust slowly: start low and raise it.`, [
    el('div', { class: 'ox-grid2' }, [
      field('Each run (every 5 minutes)', input('broadcast_per_run', perRun || '', { type: 'number', min: '0', max: '100', placeholder: 'No pace: batches of 100' }), 'Empty or 0: no pace.'),
      field('At most a day', input('broadcast_daily_cap', s.broadcast_daily_cap || 500, { type: 'number', min: '1', max: '100000', required: true })),
      field('From', input('broadcast_window_start', s.broadcast_window_start, { type: 'time' }), 'Leave both empty for any hour.'),
      field('To', input('broadcast_window_end', s.broadcast_window_end, { type: 'time' })),
    ]),
    el('div', { class: 'oc-field' }, [el('span', { class: 'oc-label' }, 'Days'),
      el('div', { class: 'ox-days' }, DAYS.map(([n, label]) => el('label', {}, [el('input', { type: 'checkbox', name: `bday${n}`, checked: noDays || days.includes(String(n)) }), label])))]),
  ], (d) => {
    const start = String(d.broadcast_window_start || '').trim();
    const end = String(d.broadcast_window_end || '').trim();
    if ((start && !end) || (!start && end)) { Orch.toast('Set both hours, or neither.', { error: true }); return null; }
    if (start && end && end <= start) { Orch.toast('The hours have to end after they start.', { error: true }); return null; }
    const picked = DAYS.map(([n]) => n).filter((n) => d[`bday${n}`]);
    if (start && !picked.length) { Orch.toast('Pick at least one day.', { error: true }); return null; }
    return save(['broadcast_daily_cap', 'broadcast_per_run', 'broadcast_window_start', 'broadcast_window_end', 'broadcast_days'])({
      broadcast_daily_cap: Math.max(1, Number(d.broadcast_daily_cap) || 500), broadcast_per_run: Math.max(0, Math.floor(Number(d.broadcast_per_run) || 0)),
      broadcast_window_start: start, broadcast_window_end: end, broadcast_days: picked.length === 7 ? '' : picked.join(','),
    });
  });
}

function pace(s, save, reload) {
  const days = String(s.send_days || '').split(',');
  const every = el('select', { class: 'oc-select', name: 'send_every_minutes' }, [10, 15, 20, 30, 45, 60, 90, 120].map((m) => el('option', { value: String(m) }, `${m} minutes`)));
  every.value = String(s.send_every_minutes || 30);
  const zone = el('select', { class: 'oc-select', name: 'timezone' }, [...new Set([s.timezone, ...ZONES].filter(Boolean))].map((z) => el('option', { value: z }, z)));
  zone.value = s.timezone || 'UTC';
  const paused = Number(s.paused) === 1;
  const box = section('Sequences: pace', 'A sequence sends one email at a time, never outside these hours, never more than the cap in a day. (Broadcasts are not held to it.)', [
    el('div', { class: 'ox-grid2' }, [
      field('One every', every),
      field('At most a day', input('daily_cap', s.daily_cap, { type: 'number', min: '1', max: '500', required: true })),
      field('From', input('window_start', s.window_start, { type: 'time', required: true })),
      field('Until', input('window_end', s.window_end, { type: 'time', required: true })),
      field('Time zone', zone),
    ]),
    el('fieldset', { class: 'oc-field ox-plain' }, [el('legend', { class: 'oc-label' }, 'On'),
      el('div', { class: 'ox-days' }, DAYS.map(([n, label]) => el('label', {}, [el('input', { type: 'checkbox', name: `day${n}`, checked: days.includes(String(n)) }), label])))]),
  ], (d) => {
    if (d.window_end <= d.window_start) { Orch.toast('The window has to end after it starts.', { error: true }); return null; }
    const sendDays = DAYS.filter(([n]) => d[`day${n}`]).map(([n]) => n).join(',');
    if (!sendDays) { Orch.toast('Pick at least one day.', { error: true }); return null; }
    return save(['send_every_minutes', 'daily_cap', 'window_start', 'window_end', 'timezone', 'send_days'])({
      ...d, send_every_minutes: Number(d.send_every_minutes), daily_cap: Number(d.daily_cap), send_days: sendDays,
    });
  });
  box.appendChild(el('div', { class: 'ox-inline' }, [
    el('p', { class: paused ? 'ox-note ox-note--warn' : 'oc-help' }, paused ? 'Sending is paused: nothing leaves, from any campaign, broadcasts included.' : 'Sending is on.'),
    el('button', { class: 'oc-btn', type: 'button', onClick: async () => {
      if (!paused && !(await Orch.confirm('Pause all sending? Nothing leaves until you resume it; the queue keeps its order.', { yes: 'Pause' }))) return;
      if (await act(paused ? A.resumeSending : A.pauseSending, { id: s._id }, paused ? 'Sending resumed.' : 'Sending paused.')) reload();
    } }, paused ? 'Resume sending' : 'Pause all sending'),
  ]));
  return box;
}

function lookup(s, save) {
  const stages = list(s.stages);
  const on = list(s.enrich_stages);
  const ordered = [...on.filter((x) => stages.includes(x)), ...stages.filter((x) => !on.includes(x))];
  const agent = s.enrich_agent ? s.enrich_agent.charAt(0).toUpperCase() + s.enrich_agent.slice(1) : 'The agent';
  return section('Find emails', `${agent} looks up, on the web, the email of contacts without one in these stages, the first ones first. Only an address published on a page it can cite is written; when web search fails, nobody is marked.`, [
    el('fieldset', { class: 'oc-field ox-plain' }, [el('legend', { class: 'oc-label' }, 'Stages'),
      el('div', { class: 'ox-days' }, ordered.map((st) => el('label', {}, [el('input', { type: 'checkbox', name: `stage:${st}`, checked: on.includes(st) }), st])))]),
    field('Contacts per run (every half hour)', input('enrich_per_run', s.enrich_per_run || 10, { type: 'number', min: '1', max: '25', required: true })),
    field('Tell this Telegram chat what each run found', input('notify_telegram', s.notify_telegram, {
      placeholder: 'A chat id or @username', pattern: '-?[0-9]{5,20}|@[A-Za-z0-9_]{5,32}',
    }), 'The instance’s bot sends who was looked up, the emails found and who has none. Empty: no message.'),
  ], (d) => save(['enrich_stages', 'enrich_per_run', 'notify_telegram'])({
    enrich_stages: JSON.stringify(ordered.filter((st) => d[`stage:${st}`])), enrich_per_run: Number(d.enrich_per_run),
    notify_telegram: String(d.notify_telegram || '').trim(),
  }));
}

function stagesForm(s, save) {
  const area = el('textarea', { class: 'oc-textarea', name: 'stages', rows: '6' });
  area.value = list(s.stages).join('\n');
  return section('Stages', 'Where each contact stands, one per line, in order. Renaming one does not move the contacts that have the old name.', [
    field('Stages', area),
  ], (d) => {
    const stages = [...new Set(d.stages.split('\n').map((x) => x.trim()).filter(Boolean))];
    if (!stages.length) { Orch.toast('Keep at least one stage.', { error: true }); return null; }
    return save(['stages'])({ stages: JSON.stringify(stages) });
  });
}

function automations() {
  const row = (name, what, run, label) => el('li', {}, [
    el('div', {}, [el('span', {}, name), el('p', { class: 'oc-small oc-muted' }, what)]),
    run ? el('button', { class: 'oc-btn oc-btn--sm', type: 'button', onClick: () => act(run, {}, `${name}: running now.`) }, label) : el('span'),
  ]);
  return el('section', { class: 'ox-section' }, [
    el('h2', { class: 'oc-h2' }, 'Automations'),
    el('p', { class: 'oc-help' }, 'They run on their own, as workflows (Workflows → Scheduled). Each one only runs when there is something to do.'),
    el('ul', { class: 'ox-rows' }, [
      row('Broadcast', 'Every five minutes while a broadcast is due or sending: batches of 100, up to the daily limit.', A.broadcastNow, 'Run now'),
      row('Write emails', 'Every half hour while a sequence is active: writes the email of each new contact of its recipients.', A.queueNow, 'Run now'),
      row('Send', 'Every ten minutes it checks whether a sequence email is due, and sends the oldest.', null),
      row('Bounces', 'Every hour: asks Resend what happened to sent emails; a bounce or a spam complaint marks the contact and goes on the no-contact list.', A.checkBouncesNow, 'Run now'),
      row('Find emails', 'Every half hour, when contacts in the chosen stages have none: the agent looks them up.', A.findEmailsNow, 'Run now'),
      row('Count recipients, Test send, Import contacts, Add to a list, Unsubscribe', 'Run when you ask for them here, or when someone presses Unsubscribe.', null),
    ]),
  ]);
}
