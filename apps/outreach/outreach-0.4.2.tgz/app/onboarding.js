// Getting started, the pure part (no Orch, so a test can import it): the two
// things a fresh install needs before an email can go out, each read from the
// data every time Campaigns draws, never ticked by hand.
//   mail    Resend or Gmail answered through Composio (check-resend.js, or any
//           email that left), and that one's last check did not fail
//   sender  Settings name the address the emails come from (Resend needs it;
//           with Gmail alone the connected account is the sender, so it is done)
export const STEPS = [
  { id: 'mail', title: 'Connect Resend or Gmail' },
  { id: 'sender', title: 'Your sender' },
];

export function onboarding(s, { left = 0 } = {}) {
  const resend = Boolean(s && s.resend_ok_at && !s.resend_error) || (Number(left) > 0 && !(s && s.resend_error));
  const gmail = Boolean(s && s.gmail_ok_at && !s.gmail_error);
  const done = {
    mail: resend || gmail,
    sender: Boolean(s && String(s.from_email || '').trim()) || (gmail && !resend),
  };
  const all = done.mail && done.sender;
  return { done, count: Number(done.mail) + Number(done.sender), show: Boolean(s) && !s.onboarding_hidden_at && !all, resend, gmail };
}
