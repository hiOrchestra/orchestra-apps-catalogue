// The router, the navigation and the sending line under it. Campaigns is
// home: broadcasts and sequences. To review is the one work queue. Sent is
// every email across campaigns. Contacts, Lists and Audiences are who a
// campaign writes to; Templates are where an email can start. Settings:
// sender, unsubscribe, pace, email lookup, no-contact list, automations.
// Going out (the sequences' queue) is reached from the sending line.
import { render as campaigns } from './screens/campaigns.js';
import { render as campaign } from './screens/campaign.js';
import { render as queue } from './screens/queue.js';
import { render as review } from './screens/review.js';
import { render as sent } from './screens/sent.js';
import { render as contacts } from './screens/contacts.js';
import { render as importer } from './screens/import.js';
import { render as lists } from './screens/lists.js';
import { render as audiences } from './screens/audiences.js';
import { render as templates } from './screens/templates.js';
import { render as settingsScreen } from './screens/settings.js';
import { V, settings, sequenceSentToday } from './data.js';
import { leaveTimes, clock, dayStart, sqlTime, schedule } from './time.js';

const { el, router, fmt } = Orch;

const NAV = [
  ['/', 'Campaigns'], ['/review', 'To review'], ['/sent', 'Sent'],
  ['/contacts', 'Contacts'], ['/lists', 'Lists'], ['/audiences', 'Audiences'], ['/templates', 'Templates'], ['/settings', 'Settings'],
];

router.define({
  '/': campaigns, '/campaigns/:id': campaign, '/campaigns/:id/:who': campaign, '/queue': queue, '/review': review, '/sent': sent,
  '/contacts': contacts, '/contacts/import': importer, '/lists': lists, '/audiences': audiences, '/audiences/:id': audiences,
  '/templates': templates, '/templates/:id': templates, '/settings': settingsScreen,
}, () => Orch.mount('view', el('p', { class: 'oc-state' }, 'This screen does not exist.'))).start();

const counts = {};
Orch.mount('nav', NAV.map(([path, label]) => {
  counts[path] = el('span', { class: 'oc-count ox-count' });
  return router.link(path, [el('span', label), counts[path]], { class: 'oc-tab', 'data-path': path });
}));

const screenOf = () => router.path().split('?')[0];
const sectionOf = (p) => {
  if (p.startsWith('/campaigns/') || p === '/queue') return '/';
  return p.replace(/^(\/[^/]*).*$/, '$1');
};
let screen = screenOf();

// The runtime marks a tab only on its own screen ('/' matches only itself), so
// a campaign or the queue would leave Campaigns unmarked: say which section it
// is, after the runtime has had its turn.
function mark() {
  setTimeout(() => {
    const here = sectionOf(screenOf());
    for (const a of document.querySelectorAll('#nav .oc-tab')) {
      if (a.dataset.path === here) a.setAttribute('aria-current', 'page'); else a.removeAttribute('aria-current');
    }
  }, 0);
}

/** What is going out now: a broadcast's progress, the sequences' next email, and what waits for review. */
async function pulse() {
  try {
    const s = await settings();
    const [going, waiting, sending] = await Promise.all([
      Orch.db.view(V.goingOut, { filter: { campaign_status: 'Active' }, count: true, limit: 1 }),
      Orch.db.view(V.review, { count: true, limit: 1 }),
      Orch.db.view(V.campaigns, { filter: { kind: 'broadcast', status: 'Sending' }, limit: 20 }),
    ]);
    counts['/review'].textContent = waiting.total ? fmt.number(waiting.total) : '';
    if (!s) { Orch.mount('pulse', el('span', 'Outreach has no settings yet.')); return; }
    const sch = schedule(s);
    const lines = [el('span', { class: 'oc-label' }, 'Sending')];
    if (Number(s.paused) === 1) lines.push(el('span', { class: 'ox-pulse__hot' }, 'Paused in Settings'));
    // One broadcast: its name. Several: one line for all of them, so the bar never outgrows the window.
    const rows = sending.rows || [];
    if (rows.length === 1) {
      const k = rows[0];
      lines.push(router.link(`/campaigns/${k._id}`, [el('span', { class: 'ox-pulse__hot', title: k.name }, k.name), ` ${fmt.number(k.sent)} of ${fmt.number(k.total || 0)}`]));
    } else if (rows.length > 1) {
      const sent = rows.reduce((n, k) => n + Number(k.sent || 0), 0);
      const total = rows.reduce((n, k) => n + Number(k.total || 0), 0);
      lines.push(router.link('/campaigns', [el('span', { class: 'ox-pulse__hot', title: rows.map((k) => `${k.name} ${fmt.number(k.sent)} of ${fmt.number(k.total || 0)}`).join('\n') }, `${rows.length} broadcasts`), ` ${fmt.number(sent)} of ${fmt.number(total)}`]));
    }
    if (going.total && Number(s.paused) !== 1) {
      const sentToday = await sequenceSentToday(sqlTime(dayStart(new Date(), sch.tz)));
      const next = leaveTimes(1, s, sentToday)[0];
      lines.push(router.link('/queue', [`${fmt.number(going.total)} going out · next `, el('span', { class: 'ox-pulse__hot' }, clock(next, sch.tz))]));
    } else if (!rows.length && Number(s.paused) !== 1) lines.push(el('span', 'Nothing is going out'));
    Orch.mount('pulse', lines);
  } catch (e) {
    Orch.mount('pulse', el('span', 'Could not read the sending status.'));
  }
}

// A row's panel is a modal on <body>, and the runtime leaves it open when the
// screen changes. Leaving a screen removes its panels.
window.addEventListener('hashchange', () => {
  if (screenOf() !== screen) document.querySelectorAll('dialog[data-orch-detail]').forEach((d) => d.remove());
  screen = screenOf();
  mark();
  pulse();
});
window.addEventListener('outreach:changed', pulse);
mark();
pulse();
