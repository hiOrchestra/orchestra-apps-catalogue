// Settings: pausing first (its own button: it takes every time off the page at
// once), when the free times were last worked out, and what is managed in
// Orchestra (how bookings work).
import { A, act, copy, head, notices, prepOn, publicLink, settings, when } from '../data.js';

const { el, fmt, router } = Orch;

export function render() {
  Orch.load('view', async () => {
    const s = await settings();
    if (!s._id) return el('p', { class: 'oc-state' }, 'Booking is not installed in this project.');
    return el('div', { class: 'oc-stack oc-stack--loose' }, [
      head('Settings', 'How bookings work for every meeting type.'),
      ...notices(s),
      pause(s),
      times(s),
      form(s),
    ]);
  });
}

function pause(s) {
  const paused = s.paused === 'yes';
  const b = el('button', { type: 'button', class: `oc-btn${paused ? ' oc-btn--primary' : ''}`, onClick: async () => {
    if (!paused && !(await Orch.confirm('Pause bookings? Your page stops offering times at once. Requests already in stay, and confirmed meetings are not touched.', { yes: 'Pause' }))) return;
    if (await act(paused ? A.resume : A.pause, { id: s._id }, paused ? 'Resumed: the times are back on your page in a moment.' : 'Paused: no times are offered.')) render();
  } }, paused ? 'Resume bookings' : 'Pause bookings');
  return el('section', { class: 'oc-card oc-stack' }, [
    el('div', { class: 'oc-row oc-row--between' }, [el('h2', { class: 'oc-h2' }, 'Your booking page'), el('span', { class: `oc-badge${paused ? ' oc-badge--warn' : ' oc-badge--good'}` }, paused ? 'Paused' : 'Taking bookings')]),
    el('div', { class: 'bk-code' }, [el('code', publicLink(s)), el('button', { type: 'button', class: 'oc-btn oc-btn--sm', onClick: () => copy(publicLink(s), 'Link copied.') }, 'Copy')]),
    el('div', { class: 'oc-row' }, b),
  ]);
}

function times(s) {
  const built = when(s.slots_built_at);
  return el('section', { class: 'oc-card oc-stack' }, [
    el('h2', { class: 'oc-h2' }, 'Free times'),
    el('p', { class: 'oc-help' }, 'Worked out every 30 minutes from your weekly hours and Google Calendar (only when each slot is busy, never what is in it), after each request, and when you save here.'),
    built ? el('p', { class: 'oc-value' }, `Last built ${fmt.ago(built.toISOString())} · ${s.slots_note || ''}`)
      : el('p', { class: 'oc-help' }, ['Not built yet: they are worked out once a meeting type is on and Google Calendar is connected. ', router.link('/', 'See Getting started')]),
    el('div', { class: 'oc-row' }, el('button', { type: 'button', class: 'oc-btn oc-btn--sm', onClick: async () => { if (await act(A.rebuild, {}, 'Working them out now.')) setTimeout(render, 3000); } }, 'Work them out now')),
  ]);
}

// How bookings work — the name visitors see, the words on the page, the time zone,
// the calendar, notice, days ahead, the buffer, auto-confirm, briefs and Telegram —
// is managed in Orchestra (Apps → Booking → Ajustes): typed, next to its Google
// Calendar connection and who prepares the meetings. Here, what they are now and a way there.
function form(s) {
  const link = el('a', { class: 'oc-btn oc-btn--primary', target: '_blank', rel: 'noopener', hidden: true }, 'Open the settings in Orchestra');
  const where = el('p', { class: 'oc-help' }, 'In Orchestra: Apps → Booking → Ajustes.');
  if (Orch.manageUrl) Orch.manageUrl('settings').then((url) => { if (url) { link.href = url; link.hidden = false; where.hidden = true; } });
  const facts = [
    ['Name visitors see', s.display_name || '—'],
    ['Time zone', s.timezone || 'UTC'],
    ['Google calendar', s.calendar_id || 'primary'],
    ['Minimum notice', `${s.min_notice_hours ?? 4} hours`],
    ['Days ahead', String(s.days_ahead ?? 30)],
    ['Buffer around meetings', `${s.buffer_min ?? 0} minutes`],
    ['Auto-confirm', s.auto_confirm === 'yes' ? 'on: good requests are confirmed and invited at once' : 'off: you confirm each request'],
    ['Briefs before each meeting', prepOn(s) ? 'on' : 'off'],
    ['Telegram notices', s.notify_telegram ? 'on' : 'off'],
  ];
  return el('section', { class: 'oc-card oc-stack bk-form' }, [
    el('h2', { class: 'oc-h2' }, 'How bookings work'),
    el('p', { class: 'oc-help' }, 'Managed in Orchestra, next to the Google Calendar connection Booking uses and the agent who prepares the meetings.'),
    el('ul', { class: 'oc-stack' }, facts.map(([k, v]) => el('li', [el('b', `${k}: `), v]))),
    el('div', { class: 'oc-row' }, [link]), where,
  ]);
}
