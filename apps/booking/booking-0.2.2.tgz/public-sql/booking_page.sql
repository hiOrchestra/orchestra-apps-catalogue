SELECT st.display_name AS host, st.intro, st.paused, st.auto_confirm,
       t._id AS type_id, t.slug, t.name, t.duration_min, t.description,
       t.location_kind, t.location_detail, t.questions, t.position
FROM (SELECT display_name, intro, paused, auto_confirm FROM bk_settings ORDER BY _id LIMIT 1) st
LEFT JOIN bk_types t ON t.active = 'yes'
