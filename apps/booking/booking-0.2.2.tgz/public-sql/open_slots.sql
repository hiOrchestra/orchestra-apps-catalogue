SELECT t._id AS type_id, t.slug, t.name, t.duration_min, s.start_at, s.end_at
FROM bk_slots s
JOIN bk_types t ON t._id = s.type_id
WHERE t.active = 'yes'
  AND (SELECT paused FROM bk_settings ORDER BY _id LIMIT 1) = 'no'
  AND s.start_at > strftime('%Y-%m-%dT%H:%M:%SZ', 'now')
  AND NOT EXISTS (
    SELECT 1 FROM bk_bookings b
    WHERE b.start_at < s.end_at AND b.end_at > s.start_at
      AND (b.status IN ('Requested', 'Confirming', 'Confirmed')
        OR (b.status = 'New' AND COALESCE(b.hp, '') = '' AND julianday(b.end_at) - julianday(b.start_at) <= 0.25))
  )
