SELECT t._id, t.slug, t.name, t.duration_min, t.active, t.location_kind, t.position,
       (SELECT COUNT(*) FROM bk_slots s WHERE s.type_id = t._id AND s.start_at > strftime('%Y-%m-%dT%H:%M:%SZ', 'now')) AS open_slots,
       (SELECT COUNT(*) FROM bk_bookings b WHERE b.type_id = t._id AND b.status = 'Confirmed' AND b.start_at > strftime('%Y-%m-%dT%H:%M:%SZ', 'now')) AS upcoming,
       (SELECT COUNT(*) FROM bk_bookings b WHERE b.type_id = t._id AND b.status = 'Requested') AS waiting
FROM bk_types t
