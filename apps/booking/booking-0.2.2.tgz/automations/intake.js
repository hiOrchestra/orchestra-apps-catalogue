'use strict';
/**
 * Booking · Take requests. Every request the public page left as New is
 * checked again here (the page is not trusted: a curl can call the action):
 *
 *   Requested  a real person, a type still offered, a time that is still among
 *              the free times and not taken by an earlier booking, with enough
 *              notice. It waits for the owner's Confirm (or is confirmed at
 *              once when auto-confirm is on).
 *   Failed     a person asked for a time that could not be given: taken by
 *              someone just before, no longer free in the calendar, too soon,
 *              bookings paused, the type turned off. `reason` says which, and
 *              the desk offers the way out (another time, write to them).
 *   Discarded  not a person's request: the bot trap, sent in under 3 seconds,
 *              the same request twice, or answers the page could never send.
 *
 * Nothing is deleted, nothing goes out. The owner hears on Telegram.
 * Started by the page after each request (the data-less public action
 * `process`), by "Check now" on the desk, and every 30 minutes while
 * something is New. One run at a time; the others leave.
 *   node intake.js [--auto|--now] [--dry-run]
 */
const L = require('./lib');

const BATCH = 100;
const BUDGET_MS = 90000;
const MIN_MS = 3000;
const HELD = ['Requested', 'Confirming', 'Confirmed'];
const EMAIL = /^[^\s@<>()",;:]+@[^\s@<>()",;:]+\.[a-z]{2,}$/i;

function judge(b, s, now) {
  const type = Number.isInteger(b.type_id) ? L.one('SELECT * FROM bk_types WHERE _id = ? AND _deleted = 0', b.type_id) : null;
  const discard = (reason) => ({ status: 'Discarded', reason });
  const fail = (reason, extra = {}) => Object.assign({ status: 'Failed', reason }, extra);
  if (String(b.hp || '').trim()) return discard('A field only bots see was filled');
  if (Number.isFinite(Number(b.ms)) && Number(b.ms) < MIN_MS) return discard('Sent in under 3 seconds');
  if (b.visit) {
    const twin = L.one("SELECT _id FROM bk_bookings WHERE visit = ? AND _id < ? AND _deleted = 0 AND status NOT IN ('New', 'Discarded') LIMIT 1", String(b.visit), b._id);
    if (twin) return discard(`The same request arrived twice: kept as #${twin._id}`);
  }
  const name = String(b.name || '').trim().replace(/\s+/g, ' ');
  const email = String(b.email || '').trim().toLowerCase();
  if (!name || name.length > 120) return discard('Not a valid request: no name');
  if (!EMAIL.test(email) || email.length > 200) return discard('Not a valid request: the email is not an address');
  const start = /^\d{4}-\d\d-\d\dT\d\d:\d\d(:\d\d(\.\d+)?)?Z$/.test(String(b.start_at || '')) ? new Date(b.start_at) : null;
  if (!start || Number.isNaN(start.getTime())) return discard('Not a valid request: the time cannot be read');
  if (!type) return fail('This meeting type is not offered any more', { name, email });

  const asked = L.jsonOf(type.questions, []);
  const given = L.jsonOf(b.answers, {});
  if (!given || typeof given !== 'object' || Array.isArray(given)) return discard('Not a valid request: the answers cannot be read');
  const answers = {};
  for (const q of Array.isArray(asked) ? asked : []) {
    const v = given[q.ref] === undefined || given[q.ref] === null ? '' : String(given[q.ref]).trim().slice(0, 2000);
    if (q.required && !v) return discard(`Not a valid request: "${q.label}" was not answered`);
    if (v) answers[q.ref] = v;
  }
  if (type.location_kind === 'phone') {
    const phone = String(given.phone || '').trim();
    if (!/^[+\d][\d\s().-]{5,24}$/.test(phone)) return discard('Not a valid request: no phone number to call');
    answers.phone = phone;
  }

  const dur = Number(type.duration_min) || 30;
  const startAt = L.isoZ(start);
  const endAt = L.isoZ(new Date(start.getTime() + dur * 60000));
  const fields = { name, email, answers: JSON.stringify(answers), start_at: startAt, end_at: endAt, type_name: type.name, duration_min: dur };
  if (type.active !== 'yes') return fail('This meeting type was turned off before the request arrived', fields);
  if (s.paused === 'yes') return fail('Bookings were paused when this arrived', fields);
  const notice = Number(s.min_notice_hours) || 0;
  if (start.getTime() < now.getTime() + notice * 3600000) {
    return fail(start <= now ? 'That time had already passed' : `That time was too soon: less than ${notice} hours ahead`, fields);
  }
  const taken = L.one(`SELECT _id FROM bk_bookings WHERE _deleted = 0 AND _id <> ? AND status IN (${HELD.map(() => '?').join(',')}) AND start_at < ? AND end_at > ? ORDER BY _id LIMIT 1`,
    b._id, ...HELD, endAt, startAt);
  if (taken) return fail(`That time was taken by another booking just before (#${taken._id})`, fields);
  const slot = L.one('SELECT _id FROM bk_slots WHERE _deleted = 0 AND type_id = ? AND start_at = ?', type._id, startAt);
  if (!slot) return fail('That time is not free any more: something was added to the calendar, or it was never offered', fields);
  return Object.assign({ status: 'Requested', reason: null }, fields);
}

function run({ mode = '--auto', dryRun = false } = {}) {
  const t0 = Date.now();
  const s = L.settings();
  const now = L.now();
  let held = dryRun ? { release() {} } : L.lock('intake');
  if (!held) return { ok: true, mode, processed: 0, skipped: 'Another run is taking the new requests' };
  const auto = s.auto_confirm === 'yes';
  const tally = { processed: 0, requested: 0, failed: 0, discarded: 0, lost: 0 };
  const told = { requested: [], failed: [] };
  const verdicts = [];
  const seen = new Set();
  const fresh = (limit) => L.all(`SELECT * FROM bk_bookings WHERE _deleted = 0 AND status = 'New'${seen.size ? ` AND _id NOT IN (${[...seen].join(',')})` : ''} ORDER BY _id LIMIT ${limit}`);
  try {
    for (;;) {
      const news = fresh(BATCH);
      for (const b of news) {
        seen.add(b._id);
        const v = judge(b, s, now);
        verdicts.push({ id: b._id, status: v.status, reason: v.reason || undefined });
        if (dryRun) { tally.processed += 1; tally[v.status.toLowerCase()] += 1; continue; }
        const data = Object.assign({}, v, { processed_at: L.sqlNow(now) });
        if (v.status === 'Requested' && auto) Object.assign(data, { confirm_asked_at: L.isoZ(now), decided_by: 'auto-confirm' });
        try {
          L.write([{ op: 'update', table: 'bk_bookings', id: b._id, when: { status: 'New' }, data }]);
        } catch (e) {
          tally.lost += 1; // changed meanwhile: another run had it
          continue;
        }
        tally.processed += 1;
        tally[v.status.toLowerCase()] += 1;
        if (v.status === 'Requested') told.requested.push(`${v.name} <${v.email}>, ${v.type_name}, ${L.said(v.start_at, s.timezone)}`);
        if (v.status === 'Failed') told.failed.push(`${v.name || b.name} (${v.reason})`);
      }
      if (news.length === BATCH && Date.now() - t0 < BUDGET_MS) continue;
      held.release();
      held = null;
      if (dryRun || Date.now() - t0 >= BUDGET_MS || !fresh(1).length) break;
      held = L.lock('intake'); // something arrived while this run was finishing
      if (!held) break;
    }
  } finally {
    if (held) held.release();
  }
  const out = Object.assign({ ok: true, mode }, tally, dryRun ? { dryRun: true, verdicts } : {});
  if (dryRun) return out;
  if (auto && tally.requested) out.confirmed = require('./confirm').run({ mode: '--auto' }).confirmed || 0;
  else out.notified = tell(s, told);
  return out;
}

function tell(s, told) {
  if (!told.requested.length && !told.failed.length) return {};
  const lines = ['Booking'];
  if (told.requested.length) lines.push(`${told.requested.length === 1 ? 'A request waits' : `${told.requested.length} requests wait`} for your OK:`, ...told.requested.slice(0, 8).map((x) => `· ${x}`));
  if (told.failed.length) lines.push(`${told.failed.length === 1 ? 'A request' : `${told.failed.length} requests`} could not be given the time asked:`, ...told.failed.slice(0, 5).map((x) => `· ${x}`));
  if (s.desk_url) lines.push(`${s.desk_url}#/requests`);
  return { telegram: L.telegram(s.notify_telegram, lines.join('\n')) };
}

if (require.main === module) {
  const argv = process.argv.slice(2);
  const mode = ['--auto', '--now'].find((m) => argv.includes(m)) || '--auto';
  try { L.done(run({ mode, dryRun: argv.includes('--dry-run') })); } catch (e) { L.done({ ok: false, error: e.message }); process.exitCode = 1; }
}

module.exports = { run, judge };
