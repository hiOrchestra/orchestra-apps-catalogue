'use strict';
/**
 * Booking · Offer times. Works out the free times of the next days into
 * `bk_slots`, the only thing the public page reads about the calendar:
 *
 *   each active type's weekly hours, in the owner's time zone (DST included)
 *   − what Google Calendar says is busy (free/busy: start and end, no titles)
 *   − bookings already taken (Requested, Confirming, Confirmed)
 *   − the buffer around both, the minimum notice, and the days ahead.
 *
 * The table is rewritten by difference: rows still right stay, rows no longer
 * right are moved to a time now needed (so the table does not grow with
 * deleted rows every half hour), and only what is left over is added or
 * deleted. If Google cannot be read, nothing changes and the desk says why:
 * the page keeps the times of the last good build, minus what got booked
 * since (the public view checks bookings itself).
 *
 * Every time it asks Google it also notes how that went, for the desk's
 * Getting started (the app cannot see the portal's integrations):
 * `calendar_status` ok | not_connected | error, and `calendar_checked_at`.
 * With no type on, Google is only asked when a person pressed for it (--now),
 * over one day, so "Check again" works before anything is offered.
 *
 *   node slots.js [--auto|--now|--after-intake] [--dry-run]
 *   --after-intake reads the previous step ($PRIOR) and only builds if a request was taken.
 */
const L = require('./lib');
const C = require('./calendar');

const DAYS = ['mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun'];
const MAX_PER_TYPE = 1500;
const HELD = ['Requested', 'Confirming', 'Confirmed'];
const HHMM = /^([01]\d|2[0-4]):([0-5]\d)$/;

/**
 * How Composio says the workspace has no Google Calendar to use: no connected
 * account for the toolkit, or one that expired or was revoked. Anything else
 * (Google refusing a calendar, a timeout, a 5xx) is an error, not a missing
 * connection.
 */
const NOT_CONNECTED = [
  /\bno (active |connected |valid )*(connected[ _]?)?(account|connection)s?\b/i,
  /\b(connected[ _]?account|connection|integration)s?\b[^.]{0,60}\b(not found|does not exist|doesn't exist|missing|expired|inactive|revoked|disabled|not active)\b/i,
  /ConnectedAccount(Not|Expired|Inactive)|NoConnectedAccount|NoActiveConnection|ConnectionNotFound/,
  /\bnot connected\b/i,
];

/** ok | not_connected | error, from what calendar.busy answered. */
function calendarStatus(g) {
  if (g && g.ok) return 'ok';
  const why = String((g && g.why) || '');
  return NOT_CONNECTED.some((re) => re.test(why)) ? 'not_connected' : 'error';
}

/** A type's weekly hours as { mon: [['09:00','17:00']], … }, only well-formed ranges. */
function hoursOf(text) {
  const h = L.jsonOf(text, {});
  const out = {};
  for (const d of DAYS) {
    out[d] = (Array.isArray(h[d]) ? h[d] : []).filter((r) => Array.isArray(r) && HHMM.test(r[0]) && HHMM.test(r[1]) && r[0] < r[1]);
  }
  return out;
}

const clamp = (v, lo, hi, dflt) => { const n = Number(v); return Number.isFinite(n) ? Math.min(hi, Math.max(lo, Math.round(n))) : dflt; };

/** The rules the settings row sets, with safe bounds. */
function rules(s, now) {
  const tz = L.validZone(s.timezone || 'UTC');
  const notice = clamp(s.min_notice_hours, 0, 24 * 30, 4);
  const ahead = clamp(s.days_ahead, 1, 90, 30);
  const today = L.localDay(now, tz);
  return {
    tz, ahead, today,
    buffer: clamp(s.buffer_min, 0, 240, 0),
    from: new Date(now.getTime() + notice * 3600000),
    to: L.localToUtc(L.addDays(today, ahead + 1), '00:00', tz),
    calendars: String(s.calendar_id || 'primary').split(/[\s,]+/).filter(Boolean),
  };
}

/** Every free start of one type, as [{ start, end }] Dates. */
function slotsFor(type, r, busy) {
  const dur = clamp(type.duration_min, 5, 480, 30);
  const step = clamp(type.step_min, 5, 240, Math.min(30, dur)) * 60000;
  const hours = hoursOf(type.hours);
  const out = [];
  for (let i = 0; i <= r.ahead; i += 1) {
    const day = L.addDays(r.today, i);
    for (const [a, b] of hours[L.weekday(day)] || []) {
      const ws = L.localToUtc(day, a, r.tz).getTime();
      const we = L.localToUtc(day, b, r.tz).getTime();
      // Starts step from the window's start in real time: across a DST change
      // inside the window, the clock-hour that does not exist is skipped and
      // the one that happens twice is offered twice, as it really is.
      for (let t = ws; t + dur * 60000 <= we; t += step) {
        const end = t + dur * 60000;
        if (t < r.from.getTime() || end > r.to.getTime()) continue;
        if (busy.some((x) => x.start < end && x.end > t)) continue;
        out.push({ start: new Date(t), end: new Date(end) });
        if (out.length >= MAX_PER_TYPE) return out;
      }
    }
  }
  return out;
}

/** Bookings that hold time, as busy spans. */
function bookedSpans(from, to) {
  return L.all(`SELECT start_at, end_at FROM bk_bookings WHERE _deleted = 0 AND status IN (${HELD.map(() => '?').join(',')})`, ...HELD)
    .map((b) => ({ start: L.toDate(b.start_at), end: L.toDate(b.end_at) }))
    .filter((b) => b.start && b.end && b.end > from && b.start < to);
}

function build({ mode = '--auto', dryRun = false } = {}) {
  const s = L.settings();
  const now = L.now();
  const r = rules(s, now);
  const types = L.all("SELECT * FROM bk_types WHERE _deleted = 0 AND active = 'yes' ORDER BY position, _id");
  let busy = [];
  let calendarNote = null;
  let calendar = null; // what Google answered this run, when it was asked
  if (types.length) {
    const g = C.busy(r.calendars, r.from, r.to, L.composio);
    calendar = { calendar_status: calendarStatus(g), calendar_checked_at: L.isoZ(now) };
    if (!g.ok) calendarNote = g.why;
    else busy = g.busy;
  } else if (mode === '--now') {
    const g = C.busy(r.calendars, r.from, new Date(r.from.getTime() + 86400000), L.composio);
    calendar = { calendar_status: calendarStatus(g), calendar_checked_at: L.isoZ(now) };
  }
  if (calendarNote) {
    const note = `Could not read Google Calendar: ${calendarNote}. The page keeps the times of the last good build.`;
    if (!dryRun) {
      L.write([{ op: 'update', table: 'bk_settings', id: s._id, data: Object.assign({ slots_note: note.slice(0, 500) }, calendar) }]);
      if (!String(s.slots_note || '').startsWith('Could not')) L.telegram(s.notify_telegram, `Booking: ${note}${s.desk_url ? `\n${s.desk_url}#/settings` : ''}`);
    }
    return { ok: false, mode, error: note, calendar: calendar.calendar_status };
  }
  const pad = r.buffer * 60000;
  const spans = [...busy, ...bookedSpans(r.from, r.to)].map((b) => ({ start: b.start.getTime() - pad, end: b.end.getTime() + pad }));

  const want = new Map();
  const perType = {};
  for (const t of types) {
    const list = slotsFor(t, r, spans);
    perType[t.slug] = list.length;
    for (const x of list) want.set(`${t._id}|${L.isoZ(x.start)}`, { type_id: t._id, start_at: L.isoZ(x.start), end_at: L.isoZ(x.end) });
  }
  const have = L.all('SELECT _id, type_id, start_at, end_at FROM bk_slots WHERE _deleted = 0');
  const stale = [];
  for (const row of have) {
    const key = `${row.type_id}|${row.start_at}`;
    const w = want.get(key);
    if (w && w.end_at === row.end_at) want.delete(key); else stale.push(row._id);
  }
  const need = [...want.values()];
  const builtAt = L.isoZ(now);
  const ops = [];
  const moved = Math.min(stale.length, need.length);
  for (let i = 0; i < moved; i += 1) ops.push({ op: 'update', table: 'bk_slots', id: stale[i], data: Object.assign({ built_at: builtAt }, need[i]) });
  for (const n of need.slice(moved)) ops.push({ op: 'insert', table: 'bk_slots', data: Object.assign({ built_at: builtAt }, n) });
  const gone = stale.slice(moved);
  const total = Object.values(perType).reduce((a, b) => a + b, 0);
  const note = types.length ? `${total} free ${total === 1 ? 'time' : 'times'} offered over the next ${r.ahead} days` : 'No meeting type is on: nothing is offered';
  const result = { ok: true, mode, types: perType, offered: total, kept: have.length - stale.length, moved, added: need.length - moved, removed: gone.length, busy: busy.length };
  if (calendar) result.calendar = calendar.calendar_status;
  if (dryRun) return Object.assign(result, { dryRun: true });
  // Remove first: a row being freed can never collide with a time another row is moved to.
  if (gone.length) L.softDelete('bk_slots', gone);
  ops.push({ op: 'update', table: 'bk_settings', id: s._id, data: Object.assign({ slots_built_at: builtAt, slots_note: note }, calendar) });
  L.write(ops);
  return result;
}

function main(argv) {
  const dryRun = argv.includes('--dry-run');
  const mode = ['--auto', '--now', '--after-intake'].find((m) => argv.includes(m)) || '--auto';
  if (mode === '--after-intake') {
    let prior = {};
    try { prior = JSON.parse(String(process.env.PRIOR || '').trim().split('\n').pop() || '{}'); } catch { prior = {}; }
    if (!Number(prior.requested) && !Number(prior.confirmed)) return L.done({ ok: true, mode, skipped: 'No request was taken: the times stand' });
  }
  const held = dryRun ? { release() {} } : L.lock('slots');
  if (!held) return L.done({ ok: true, mode, skipped: 'Another run is building the times' });
  try {
    const out = build({ mode, dryRun });
    if (!dryRun) require('./prep').unstick(L.now()); // a brief left Working by a turn that died: said, not waited on forever
    L.done(out);
    if (!out.ok && mode !== '--after-intake') process.exitCode = 1; // after a request, the request still stands
  } catch (e) {
    L.done({ ok: false, mode, error: e.message });
    process.exitCode = 1;
  } finally {
    held.release();
  }
}

if (require.main === module) main(process.argv.slice(2));

module.exports = { build, slotsFor, rules, hoursOf, calendarStatus };
