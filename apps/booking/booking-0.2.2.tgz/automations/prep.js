'use strict';
/**
 * Booking · Prepare the meeting: the two script steps around the agent's turn.
 *
 *   node prep.js pick   claims one confirmed meeting waiting for its brief
 *                       (Waiting → Working) and prints what the agent needs:
 *                       who booked, their answers, earlier bookings, and the
 *                       CRM's record when the CRM app is in this project
 *   node prep.js save   checks the agent's answer ($PRIOR, JSON only) and
 *                       saves it in `prep`; otherwise Failed with why, and
 *                       nothing else changes
 *
 * The agent never writes: it answers JSON, this checks and saves it. A brief
 * left Working by a turn that died goes to Failed after 30 minutes.
 */
const L = require('./lib');

const STUCK_MS = 30 * 60000;
const MAX_BYTES = 20000;
const URL_RE = /^https?:\/\/[^\s]{3,300}$/i;

/** The CRM's record of this person, when the CRM app lives in the same project. */
function crmOf(email) {
  const has = (t) => Boolean(L.one("SELECT name FROM sqlite_master WHERE type = 'table' AND name = ?", t));
  if (!has('crm_contacts')) return null;
  const c = L.one('SELECT * FROM crm_contacts WHERE _deleted = 0 AND lower(email) = ? LIMIT 1', email);
  if (!c) return { known: false };
  const company = c.company_id && has('crm_companies') ? L.one('SELECT name, domain, industry, size, summary FROM crm_companies WHERE _id = ? AND _deleted = 0', c.company_id) : null;
  const activities = has('crm_activities')
    ? L.all('SELECT type, at, subject, summary FROM crm_activities WHERE _deleted = 0 AND contact_id = ? ORDER BY at DESC LIMIT 10', c._id) : [];
  const pick = (o, keys) => Object.fromEntries(keys.filter((k) => o[k] !== undefined && o[k] !== null && o[k] !== '').map((k) => [k, o[k]]));
  return { known: true, contact: pick(c, ['name', 'title', 'status', 'linkedin', 'last_activity_at']), company, activities };
}

function unstick(now) {
  const cut = L.sqlNow(new Date(now.getTime() - STUCK_MS));
  for (const r of L.all("SELECT _id FROM bk_bookings WHERE _deleted = 0 AND prep_status = 'Working' AND _updated_at < ?", cut)) {
    try { L.write([{ op: 'update', table: 'bk_bookings', id: r._id, when: { prep_status: 'Working' }, data: { prep_status: 'Failed', prep_note: 'The agent did not answer in time' } }]); } catch { /* moved on */ }
  }
}

function pick() {
  const now = L.now();
  unstick(now);
  const s = L.settings();
  const b = L.one("SELECT * FROM bk_bookings WHERE _deleted = 0 AND status = 'Confirmed' AND prep_status = 'Waiting' ORDER BY start_at LIMIT 1");
  if (!b) return { skip: true, why: 'No meeting is waiting for its brief' };
  try {
    L.write([{ op: 'update', table: 'bk_bookings', id: b._id, when: { prep_status: 'Waiting' }, data: { prep_status: 'Working', prep_at: L.isoZ(now) } }]);
  } catch (e) {
    return { skip: true, why: 'Another run took it' };
  }
  const type = L.one('SELECT name, description, questions FROM bk_types WHERE _id = ?', b.type_id) || {};
  const asked = L.jsonOf(type.questions, []);
  const given = L.jsonOf(b.answers, {});
  const answers = (Array.isArray(asked) ? asked : []).filter((q) => given[q.ref]).map((q) => ({ question: q.label, answer: given[q.ref] }));
  const domain = String(b.email).split('@')[1] || '';
  const earlier = L.all("SELECT type_name, start_at, status FROM bk_bookings WHERE _deleted = 0 AND lower(email) = ? AND _id <> ? AND status IN ('Confirmed', 'Cancelled', 'Declined') ORDER BY start_at DESC LIMIT 5", b.email, b._id);
  return {
    booking: b._id,
    meeting: { type: b.type_name, about: type.description || '', when: L.said(b.start_at, s.timezone), timezone: s.timezone, host: s.display_name || '' },
    person: { name: b.name, email: b.email, email_domain: domain, their_time_zone: b.tz || '' },
    answers,
    earlier_bookings: earlier,
    crm: crmOf(String(b.email).toLowerCase()),
  };
}

/** The agent's JSON, wherever it is: bare, fenced, or inside a step wrapper's `content`. */
function jsonIn(text) {
  const grab = (t) => {
    const s = String(t || '').replace(/```(?:json)?/gi, '');
    const a = s.indexOf('{');
    const b = s.lastIndexOf('}');
    if (a < 0 || b <= a) return null;
    try { return JSON.parse(s.slice(a, b + 1)); } catch { return null; }
  };
  const j = grab(text);
  if (j && typeof j.content === 'string') { const inner = grab(j.content); if (inner) return inner; }
  return j;
}

const str = (v, n) => (typeof v === 'string' ? v.trim().slice(0, n) : '');
const strs = (v, max, n) => (Array.isArray(v) ? v.map((x) => str(x, n)).filter(Boolean).slice(0, max) : []);

/** The brief as the desk shows it, or the reason it cannot be saved. */
function check(given) {
  if (!given || typeof given !== 'object' || Array.isArray(given)) return { error: 'The agent did not answer with JSON' };
  const person = given.person && typeof given.person === 'object' ? given.person : {};
  const company = given.company && typeof given.company === 'object' ? given.company : {};
  const brief = {
    summary: str(given.summary, 1200),
    person: { name: str(person.name, 120), role: str(person.role, 160), location: str(person.location, 120), linkedin: URL_RE.test(str(person.linkedin, 300)) ? str(person.linkedin, 300) : '' },
    company: { name: str(company.name, 160), website: URL_RE.test(str(company.website, 300)) ? str(company.website, 300) : '', what_they_do: str(company.what_they_do, 600), size: str(company.size, 80) },
    history: strs(given.history, 8, 300),
    wants: strs(given.wants, 6, 300),
    questions: strs(given.questions, 6, 300),
    sources: strs(given.sources, 10, 300).filter((u) => URL_RE.test(u)),
    confidence: ['high', 'medium', 'low'].includes(given.confidence) ? given.confidence : 'low',
  };
  if (!brief.summary) return { error: 'The brief has no summary' };
  const text = JSON.stringify(brief);
  if (Buffer.byteLength(text) > MAX_BYTES) return { error: 'The brief is too long' };
  return { brief, text };
}

function save() {
  let picked = {};
  try { picked = JSON.parse(String(process.env.STEP_pick || '').trim().split('\n').pop() || '{}'); } catch { picked = {}; }
  if (picked.skip || !Number.isInteger(picked.booking)) return { ok: true, skipped: 'Nothing was picked' };
  const b = L.one('SELECT _id, prep_status FROM bk_bookings WHERE _id = ? AND _deleted = 0', picked.booking);
  if (!b || b.prep_status !== 'Working') return { ok: true, skipped: `Booking ${picked.booking} is not waiting for a brief` };
  const c = check(jsonIn(process.env.PRIOR));
  if (c.error) {
    L.write([{ op: 'update', table: 'bk_bookings', id: b._id, when: { prep_status: 'Working' }, data: { prep_status: 'Failed', prep_note: c.error } }]);
    return { ok: false, booking: b._id, failed: c.error };
  }
  L.write([{ op: 'update', table: 'bk_bookings', id: b._id, when: { prep_status: 'Working' }, data: { prep: c.text, prep_status: 'Done', prep_note: null, prep_at: L.isoZ(L.now()) } }]);
  return { ok: true, booking: b._id, saved: true, confidence: c.brief.confidence };
}

if (require.main === module) {
  const cmd = process.argv[2];
  let out;
  try { out = cmd === 'pick' ? pick() : cmd === 'save' ? save() : { ok: false, error: 'node prep.js pick|save' }; } catch (e) { out = { ok: false, error: e.message }; }
  L.done(out);
}

module.exports = { pick, save, check, jsonIn, crmOf, unstick };
