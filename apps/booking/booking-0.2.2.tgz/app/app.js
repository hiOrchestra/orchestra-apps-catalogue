// The router and the bar. Upcoming is home: the meetings ahead, each with the
// agent's brief. Requests is the queue to confirm or decline. Types are what
// people can book, Settings the rest.
import { render as upcoming } from './screens/upcoming.js';
import { render as requests } from './screens/requests.js';
import { render as types } from './screens/types.js';
import { render as typeEdit } from './screens/type-edit.js';
import { render as settings } from './screens/settings.js';

const { el, router } = Orch;

router.define({
  '/': upcoming,
  '/past': upcoming,
  '/requests': requests,
  '/requests/:state': requests,
  '/types': types,
  '/types/new': typeEdit,
  '/types/:id': typeEdit,
  '/settings': settings,
}, () => Orch.mount('view', el('div', { class: 'oc-state' }, [
  el('p', 'There is no screen here.'), router.link('/', 'Go to upcoming meetings'),
]))).start();

Orch.mount('nav', [
  router.link('/', 'Upcoming', { class: 'oc-tab' }),
  router.link('/requests', 'Requests', { class: 'oc-tab' }),
  router.link('/types', 'Types', { class: 'oc-tab' }),
  router.link('/settings', 'Settings', { class: 'oc-tab' }),
]);
