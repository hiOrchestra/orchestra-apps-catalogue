// The kinds of meeting people can book: each with its length, where it
// happens, whether it is on, how many free times it offers now, and its link.
// A type opens in its editor; turning it on or off is right here.
import { V, A, act, copy, head, notices, publicLink, settings, LOCATIONS } from '../data.js';

const { el, router, fmt } = Orch;

export function render() {
  Orch.load('view', async () => {
    const [s, r] = await Promise.all([settings(), Orch.db.view(V.types, { sort: 'position:asc', limit: 100 })]);
    const rows = r.rows || [];
    return el('div', { class: 'oc-stack oc-stack--loose' }, [
      head('Types', 'What people can book with you. A type is offered on your page only while it is on.',
        [router.link('/types/new', 'New type', { class: 'oc-btn oc-btn--primary' })]),
      ...notices(s),
      rows.length ? el('section', { class: 'oc-card oc-card--pad0' }, el('ul', { class: 'bk-rows' }, rows.map((t) => row(t, s))))
        : el('div', { class: 'oc-card oc-state' }, [el('p', { class: 'oc-state__title' }, 'No meeting types yet.'), router.link('/types/new', 'Make the first one', { class: 'oc-btn' })]),
      el('section', { class: 'oc-card oc-stack' }, [
        el('h2', { class: 'oc-h2' }, 'Your booking page'),
        el('p', { class: 'oc-help' }, 'One link shows every type that is on; each type also has its own link.'),
        el('div', { class: 'bk-code' }, [el('code', publicLink(s)), el('button', { type: 'button', class: 'oc-btn oc-btn--sm', onClick: () => copy(publicLink(s), 'Link copied.') }, 'Copy')]),
      ]),
    ]);
  });
}

function row(t, s) {
  const on = t.active === 'yes';
  const toggle = el('button', { type: 'button', class: `oc-btn oc-btn--sm${on ? ' oc-btn--ghost' : ''}`, onClick: async () => {
    if (on && !(await Orch.confirm(`Turn off "${t.name}"? Its times leave your page at once. Meetings already confirmed stay.`, { yes: 'Turn off' }))) return;
    if (await act(on ? A.typeOff : A.typeOn, { id: t._id }, on ? 'Turned off: not offered any more.' : 'Turned on: its times appear on your page in a moment.')) render();
  } }, on ? 'Turn off' : 'Turn on');
  const facts = [`${t.duration_min} min`, LOCATIONS[t.location_kind] || ''].filter(Boolean).join(' · ');
  const offer = on ? `${fmt.number(t.open_slots)} free times` : 'Not offered';
  return el('li', { class: 'bk-row bk-row--type' }, [
    router.link(`/types/${t._id}`, [
      el('span', { class: 'bk-row__name' }, [el('span', t.name), el('span', { class: 'bk-row__sub' }, facts)]),
      el('span', { class: 'oc-value bk-row__time' }, offer),
      el('span', { class: `oc-badge${on ? ' oc-badge--good' : ''}` }, on ? 'On' : 'Off'),
    ], { class: 'bk-row__open' }),
    el('div', { class: 'oc-row' }, [
      on ? el('button', { type: 'button', class: 'oc-btn oc-btn--sm oc-btn--ghost', onClick: () => copy(publicLink(s, t.slug), 'Link copied.') }, 'Copy link') : null,
      toggle,
    ]),
  ]);
}
