// The queue: requests waiting for the owner's OK, each with Confirm and
// Decline right on it. Failed ones (a time that could not be given, an event
// Google did not create) have their own tab, each with its way out in the
// panel; Arriving, Done and Set aside are there to look back.
import { T, A, act, badge, head, notices, settings, span, theirs } from '../data.js';
import { openBooking } from './booking.js';
import { startData, unfinished } from './start.js';

const { el, router, fmt } = Orch;
const STATES = [
  ['', 'Waiting', ['Requested']], ['failed', 'Failed', ['Failed']], ['arriving', 'Arriving', ['New', 'Confirming']],
  ['done', 'Done', ['Declined', 'Cancelled']], ['discarded', 'Set aside', ['Discarded']],
];

export function render({ state = '' } = {}, path) {
  const again = () => render({ state }, path);
  Orch.load('view', async () => {
    const tab = STATES.find((x) => x[0] === state) || STATES[0];
    const [s, counts, list, setup] = await Promise.all([
      settings(),
      Orch.db.count(T.bookings, { filter: { status: { ne: 'Confirmed' } }, group: 'status' }),
      Orch.db.list(T.bookings, { filter: { status: tab[2] }, sort: tab[0] === '' ? 'start_at:asc' : '_id:desc', limit: 100 }),
      tab[0] === '' ? startData() : null,
    ]);
    const n = (statuses) => statuses.reduce((sum, st) => sum + (((counts.groups || []).find((g) => g.value === st) || {}).count || 0), 0);
    const rows = list.rows || [];
    return el('div', { class: 'oc-stack oc-stack--loose' }, [
      head('Requests', s.auto_confirm === 'yes'
        ? 'Auto-confirm is on: good requests become meetings without waiting here.'
        : 'Nothing reaches the person until you confirm: then Google sends them the invitation.'),
      ...notices(s),
      el('nav', { class: 'oc-tabs', 'aria-label': 'Which requests' }, STATES.filter((x) => !x[0] || x === tab || n(x[2])).map((x) => router.link(
        `/requests${x[0] ? `/${x[0]}` : ''}`, [x[1], el('span', { class: 'oc-count' }, fmt.number(n(x[2])))],
        { class: 'oc-tab', 'aria-current': x === tab ? 'page' : null }))),
      rows.length ? el('ul', { class: 'bk-queue' }, rows.map((b) => item(b, tab[0], again))) : empty(tab[0], setup && unfinished(s, setup)),
    ]);
  });
}

function item(b, tab, again) {
  const them = theirs(b);
  const quick = tab === '' ? el('div', { class: 'oc-row bk-queue__actions' }, [
    el('button', { type: 'button', class: 'oc-btn oc-btn--primary oc-btn--sm', onClick: async () => {
      if (!(await Orch.confirm(`This creates the event on your Google Calendar and Google sends ${b.name} the invitation.`, { yes: 'Confirm and invite' }))) return;
      if (await act(A.confirm, { id: b._id }, 'Confirming: the invitation goes out in a moment.')) setTimeout(again, 1500);
    } }, 'Confirm'),
    el('button', { type: 'button', class: 'oc-btn oc-btn--ghost oc-btn--sm', onClick: async () => {
      if (!(await Orch.confirm(`Decline ${b.name}'s request? Nothing is sent to them.`, { yes: 'Decline', danger: true }))) return;
      if (await act(A.decline, { id: b._id, reason: 'Declined by hand' }, 'Declined. The time is free again.')) again();
    } }, 'Decline'),
  ]) : null;
  return el('li', { class: 'bk-queue__item' }, [
    el('button', { type: 'button', class: 'bk-queue__open', onClick: () => openBooking(b._id, again) }, [
      el('span', { class: 'oc-row' }, [el('span', { class: 'bk-queue__name' }, b.name || '—'), tab === '' ? null : badge(b.status)]),
      el('span', { class: 'oc-value' }, b.start_at ? span(b.start_at, b.end_at) : '—'),
      el('span', { class: 'bk-row__sub' }, [b.type_name || '', b.email ? ` · ${b.email}` : '', them ? ` · ${them}` : '']),
      b.reason && tab !== '' ? el('span', { class: 'bk-queue__why' }, b.reason) : null,
    ]),
    quick,
  ]);
}

function empty(tab, settingUp) {
  if (settingUp) {
    return el('div', { class: 'oc-card oc-state' }, [
      el('p', { class: 'oc-state__title' }, 'No requests yet.'),
      el('p', { class: 'oc-help' }, 'Booking is not fully set up: nobody can ask for a time until Getting started is done.'),
      router.link('/', 'Go to Getting started', { class: 'oc-btn' }),
    ]);
  }
  const say = {
    '': ['Nothing waits for you.', 'New requests appear here, and on Telegram if it is set in Settings.'],
    failed: ['Nothing failed.', ''],
  }[tab] || ['Nothing here.', ''];
  return el('div', { class: 'oc-card oc-state' }, [el('p', { class: 'oc-state__title' }, say[0]), say[1] ? el('p', { class: 'oc-help' }, say[1]) : null]);
}
