// Getting started: the four things a fresh install needs before anyone can
// book, on top of Upcoming. Each step is checked from the data every time the
// screen draws (never ticked by hand), says in one sentence why it matters,
// and has one action: done here when it is small, a link when it is not.
// Google Calendar is connected in the portal, which this app cannot see: the
// step reads what slots.js noted the last time it asked Google
// (calendar_status). Once every step is done the panel says so and can be
// hidden; hiding is kept in bk_settings, so it holds on every device.
import { A, T, act, nowIso, parse } from '../data.js';
import { BODY } from './start-steps.js';

const { el } = Orch;

/** What Getting started needs to judge the steps: the types and how many future free times there are. */
export async function startData() {
  const [types, slots] = await Promise.all([
    Orch.db.list(T.types, { sort: 'position:asc', limit: 50 }),
    Orch.db.count(T.slots, { filter: { start_at: { gt: nowIso() } } }),
  ]);
  return { types: types.rows || [], slots: Number(slots) || 0 };
}

const hasHours = (t) => Object.values(parse(t.hours, {})).some((r) => Array.isArray(r) && r.length);

/** The four steps, each done or not, from the data alone. */
export function steps(s, { types, slots }) {
  const isOn = (t) => t.active === 'yes';
  return [
    { id: 'profile', title: 'Your name and time zone', done: Boolean(String(s.display_name || '').trim() && s.timezone) },
    { id: 'calendar', title: 'Connect Google Calendar', done: s.calendar_status === 'ok' },
    { id: 'hours', title: 'Your available hours', done: types.some((t) => isOn(t) && hasHours(t)) },
    { id: 'share', title: 'Share your link', done: types.some(isOn) && slots > 0 },
  ];
}

/** True while the owner still has something to do here (the other screens' empty states point to it). */
export const unfinished = (s, data) => steps(s, data).some((x) => !x.done);

/** The panel, or null once it was hidden. `again` draws the screen again after a change. */
export function startPanel(s, data, again) {
  if (s.onboarding_dismissed_at) return null;
  const list = steps(s, data);
  const left = list.reduce((n, x) => n + (x.done ? 0 : 1), 0);
  if (!left) {
    return el('section', { class: 'oc-card bk-start bk-start--done', 'aria-label': 'Getting started' }, [
      el('div', { class: 'bk-start__line' }, [
        el('span', { class: 'oc-eyebrow' }, 'Getting started · 4 of 4'),
        el('p', { class: 'bk-start__said' }, 'You are set up: people can book time with you from your link.'),
        el('button', { type: 'button', class: 'oc-btn oc-btn--sm oc-btn--ghost', onClick: async () => {
          if (await act(A.dismissStart, { id: s._id })) again();
        } }, 'Hide this'),
      ]),
    ]);
  }
  let open = (list.find((x) => !x.done) || list[0]).id;
  const host = el('ol', { class: 'bk-steps' });
  const draw = () => {
    host.replaceChildren(...list.map((x, i) => step(x, i, x.id === open, () => { open = open === x.id ? '' : x.id; draw(); }, s, data, again)));
  };
  draw();
  return el('section', { class: 'oc-card oc-card--pad0 bk-start', 'aria-label': 'Getting started' }, [
    el('header', { class: 'bk-start__head' }, [
      el('h2', { class: 'oc-h2' }, 'Getting started'),
      el('span', { class: 'oc-eyebrow' }, `${4 - left} of 4 done`),
    ]),
    el('p', { class: 'oc-help bk-start__lede' }, 'Four steps before anyone can book a time with you. Each one ticks itself when it is done.'),
    host,
  ]);
}

const WHY = {
  profile: 'Visitors see your name on the booking page and in the invitation, and your weekly hours are kept in this time zone.',
  calendar: 'Free times are worked out from your real calendar, and every meeting you confirm lands in it with the invitation.',
  hours: 'The times of the week people can pick from. Busy time in your calendar is left out on its own.',
  share: 'Anyone with this link can ask for a time. Nothing is booked until you confirm it.',
};

function step(x, i, isOpen, toggle, s, data, again) {
  const n = String(i + 1).padStart(2, '0');
  return el('li', { class: `bk-step${x.done ? ' bk-step--done' : ''}${isOpen ? ' bk-step--open' : ''}` }, [
    el('button', { type: 'button', class: 'bk-step__head', 'aria-expanded': String(isOpen), onClick: toggle }, [
      el('span', { class: 'oc-value bk-step__n' }, n),
      el('span', { class: 'bk-step__title' }, x.title),
      el('span', { class: `oc-badge${x.done ? ' oc-badge--good' : ''}` }, x.done ? 'Done' : 'To do'),
    ]),
    isOpen ? el('div', { class: 'bk-step__body oc-stack' }, [el('p', { class: 'bk-step__why' }, WHY[x.id]), BODY[x.id](s, data, again, x)]) : null,
  ]);
}
