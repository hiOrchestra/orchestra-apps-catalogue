// The meetings ahead, day by day, in the reader's own time, each with the
// state of the agent's brief; a meeting opens in its panel. What waits for
// the owner (requests, a paused page, Google unreadable) is said on top.
// /past is the same list, backwards. Until Booking is set up, Getting started
// (start.js) sits on top.
import { T, badge, dayKey, dayName, head, hour, notices, nowIso, settings } from '../data.js';
import { openBooking } from './booking.js';
import { startData, startPanel, unfinished } from './start.js';

const { el, router } = Orch;

export function render(_p, path) {
  const past = String(path || '').startsWith('/past');
  Orch.load('view', async () => {
    const now = nowIso();
    const [s, list, waiting, failed, setup] = await Promise.all([
      settings(),
      Orch.db.list(T.bookings, past
        ? { filter: { status: 'Confirmed', start_at: { lt: now } }, sort: 'start_at:desc', limit: 60 }
        : { filter: { status: ['Confirmed', 'Confirming'], end_at: { gt: now } }, sort: 'start_at:asc', limit: 200 }),
      Orch.db.count(T.bookings, { filter: { status: 'Requested' } }),
      Orch.db.count(T.bookings, { filter: { status: 'Failed' } }),
      past ? null : startData(),
    ]);
    const rows = list.rows || [];
    const panel = past ? null : startPanel(s, setup, () => render(_p, path));
    const queue = [];
    if (waiting) queue.push(el('div', { class: 'bk-notice bk-notice--warn' }, [`${waiting === 1 ? 'A request waits' : `${waiting} requests wait`} for your OK. `, router.link('/requests', 'See requests')]));
    if (failed) queue.push(el('div', { class: 'bk-notice bk-notice--bad' }, [`${failed === 1 ? 'A booking' : `${failed} bookings`} could not be given. `, router.link('/requests/failed', 'See what to do')]));
    return el('div', { class: 'oc-stack oc-stack--loose' }, [
      head(past ? 'Past meetings' : 'Upcoming', past ? 'The meetings that already happened, latest first.' : 'Your confirmed meetings, in your time, with what the agent found about each person.',
        [router.link(past ? '/' : '/past', past ? 'Upcoming' : 'Past meetings', { class: 'oc-btn oc-btn--ghost' })]),
      panel,
      ...notices(s, past ? [] : queue, { panel: Boolean(panel) }),
      rows.length ? days(rows, () => render(_p, path)) : empty(past, !past && unfinished(s, setup)),
    ]);
  });
}

function days(rows, again) {
  const groups = [];
  for (const b of rows) {
    const k = dayKey(b.start_at);
    if (!groups.length || groups[groups.length - 1].k !== k) groups.push({ k, items: [] });
    groups[groups.length - 1].items.push(b);
  }
  const today = dayKey(new Date().toISOString());
  return el('div', { class: 'oc-stack oc-stack--loose' }, groups.map((g) => el('section', { class: 'oc-card oc-card--pad0' }, [
    el('h2', { class: 'oc-eyebrow bk-day' }, g.k === today ? `Today · ${dayName(g.items[0].start_at)}` : dayName(g.items[0].start_at)),
    el('ul', { class: 'bk-rows' }, g.items.map((b) => row(b, again))),
  ])));
}

const PREP = { Done: 'Brief ready', Waiting: 'Brief coming', Working: 'Brief coming', Failed: 'No brief' };

function row(b, again) {
  const open = el('button', { type: 'button', class: 'bk-row__open', onClick: () => openBooking(b._id, again) }, [
    el('span', { class: 'oc-value bk-row__time' }, `${hour(b.start_at)}–${hour(b.end_at)}`),
    el('span', { class: 'bk-row__name' }, [el('span', b.name), el('span', { class: 'bk-row__sub' }, b.type_name || '')]),
    b.status === 'Confirming' ? badge(b.status) : el('span', { class: 'oc-eyebrow' }, PREP[b.prep_status] || ''),
  ]);
  return el('li', { class: 'bk-row' }, [open,
    b.meet_link ? el('a', { class: 'oc-btn oc-btn--sm', href: b.meet_link, target: '_blank', rel: 'noopener' }, 'Join') : el('span')]);
}

function empty(past, settingUp) {
  if (past) return el('div', { class: 'oc-card oc-state' }, el('p', { class: 'oc-state__title' }, 'No past meetings yet.'));
  if (settingUp) {
    return el('div', { class: 'oc-card oc-state' }, [
      el('p', { class: 'oc-state__title' }, 'No meetings yet.'),
      el('p', { class: 'oc-help' }, 'Finish Getting started above: once your link is live, requests arrive in Requests and you confirm each one.'),
    ]);
  }
  return el('div', { class: 'oc-card oc-state' }, [
    el('p', { class: 'oc-state__title' }, 'No meetings coming up.'),
    el('p', { class: 'oc-help' }, 'Turn on a meeting type and share its link: requests arrive in Requests, and you confirm each one.'),
    router.link('/types', 'Go to meeting types', { class: 'oc-btn' }),
  ]);
}
