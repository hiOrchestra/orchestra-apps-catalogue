// One meeting type: its name and link, how long, where, the weekly hours
// (in the time zone of Settings), and the questions people answer when they
// book. Saving rebuilds the free times; a new type starts off.
import { T, A, act, head, parse, settings, LOCATIONS } from '../data.js';

const { el, router } = Orch;
const DAYS = [['mon', 'Monday'], ['tue', 'Tuesday'], ['wed', 'Wednesday'], ['thu', 'Thursday'], ['fri', 'Friday'], ['sat', 'Saturday'], ['sun', 'Sunday']];
const BLANK = { name: '', slug: '', duration_min: 30, step_min: 30, description: '', location_kind: 'meet', location_detail: '',
  hours: JSON.stringify(Object.fromEntries(DAYS.slice(0, 5).map(([d]) => [d, [['09:00', '17:00']]]))), questions: '[]', active: 'no' };

export function render({ id } = {}) {
  Orch.load('view', async () => {
    const [s, t] = await Promise.all([settings(), id ? Orch.db.get(T.types, id) : BLANK]);
    if (!t) return el('div', { class: 'oc-state' }, [el('p', 'This type does not exist.'), router.link('/types', 'All types')]);
    return form(t, s, id);
  });
}

const input = (attrs) => el('input', Object.assign({ class: 'oc-input' }, attrs));
const field = (label, control, help) => el('label', { class: 'oc-field' }, [el('span', { class: 'oc-label' }, label), control, help ? el('span', { class: 'oc-help' }, help) : null]);
const slugOf = (v) => String(v || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 50);

function form(t, s, id) {
  const name = input({ value: t.name || '', maxlength: '80', required: true });
  const slug = input({ value: t.slug || '', maxlength: '50', pattern: '[a-z0-9-]+' });
  if (!id) name.addEventListener('input', () => { slug.value = slugOf(name.value); });
  const duration = el('select', { class: 'oc-select' }, [15, 20, 30, 45, 60, 90, 120].map((m) => el('option', { value: m, selected: Number(t.duration_min) === m }, `${m} minutes`)));
  const step = el('select', { class: 'oc-select' }, [15, 30, 60].map((m) => el('option', { value: m, selected: Number(t.step_min || 30) === m }, `Every ${m} minutes`)));
  const description = el('textarea', { class: 'oc-textarea', rows: '3', maxlength: '600' }, t.description || '');
  const where = el('select', { class: 'oc-select' }, Object.entries(LOCATIONS).map(([k, v]) => el('option', { value: k, selected: t.location_kind === k }, v)));
  const detail = input({ value: t.location_detail || '', maxlength: '300', placeholder: 'Street, number, city' });
  const detailField = field('Address', detail, 'People see it on the page and in the invitation.');
  const sync = () => { detailField.hidden = where.value !== 'place'; };
  where.addEventListener('change', sync);
  sync();
  const hours = hoursEditor(parse(t.hours, {}));
  const questions = questionsEditor(parse(t.questions, []));
  const save = el('button', { type: 'submit', class: 'oc-btn oc-btn--primary' }, id ? 'Save' : 'Create type');
  const f = el('form', { class: 'oc-stack oc-stack--loose bk-form' }, [
    head(id ? t.name : 'New type', id ? 'Changes apply to new bookings; the free times are worked out again when you save.' : 'It starts off: turn it on from Types when it is ready.',
      [router.link('/types', '← All types', { class: 'oc-btn oc-btn--ghost' })]),
    el('section', { class: 'oc-card oc-stack' }, [
      el('h2', { class: 'oc-h2' }, 'The meeting'),
      field('Name', name, 'What people pick, like "Intro call" or "Product demo".'),
      field('Link name', slug, 'The end of its own link. Letters, numbers and dashes.'),
      el('div', { class: 'bk-two' }, [field('Length', duration), field('Start times', step, 'How often a start time is offered.')]),
      field('Description', description, 'One or two lines people read before they pick a time.'),
      field('Where', where, 'Google Meet adds a video link to the invitation; a phone call asks them for their number.'),
      detailField,
    ]),
    el('section', { class: 'oc-card oc-stack' }, [
      el('h2', { class: 'oc-h2' }, 'Weekly hours'),
      el('p', { class: 'oc-help' }, `When it can be booked, in ${s.timezone || 'UTC'} (Settings). Busy time in your Google Calendar is left out on its own.`),
      hours.node,
    ]),
    el('section', { class: 'oc-card oc-stack' }, [
      el('h2', { class: 'oc-h2' }, 'Questions'),
      el('p', { class: 'oc-help' }, 'Asked after name and email. The agent reads the answers to prepare the meeting.'),
      questions.node,
    ]),
    el('div', { class: 'oc-row' }, save),
  ]);
  f.addEventListener('submit', async (e) => {
    e.preventDefault();
    const params = { name: name.value.trim(), slug: slugOf(slug.value || name.value), duration_min: Number(duration.value), step_min: Number(step.value),
      description: description.value.trim(), location_kind: where.value, location_detail: where.value === 'place' ? detail.value.trim() : '',
      hours: JSON.stringify(hours.value()), questions: JSON.stringify(questions.value()) };
    if (!params.name || !params.slug) { Orch.toast('Give it a name.', { error: true }); return; }
    const same = await Orch.db.find(T.types, { slug: params.slug });
    if (same && String(same._id) !== String(id || '')) { Orch.toast('Another type has that link name.', { error: true }); return; }
    save.disabled = true;
    const r = id ? await act(A.updateType, Object.assign({ id }, params), 'Saved. The free times are being worked out again.')
      : await act(A.createType, Object.assign({ position: 100 }, params), 'Created. Turn it on when it is ready.');
    save.disabled = false;
    if (r) router.go(id ? `/types/${id}` : '/types');
  });
  return f;
}

/** The weekly hours, one range a day: { node, value() } (also used by Getting started). */
export function hoursEditor(h) {
  const rows = DAYS.map(([d, label]) => {
    const range = (Array.isArray(h[d]) && h[d][0]) || null;
    const on = el('input', { type: 'checkbox', checked: Boolean(range) });
    const from = input({ type: 'time', value: range ? range[0] : '09:00', step: '900', 'aria-label': `${label} from` });
    const to = input({ type: 'time', value: range ? range[1] : '17:00', step: '900', 'aria-label': `${label} until` });
    const sync = () => { from.disabled = !on.checked; to.disabled = !on.checked; };
    on.addEventListener('change', sync);
    sync();
    return { d, on, from, to, node: el('div', { class: 'bk-hours__row' }, [el('label', { class: 'bk-hours__day' }, [on, label]), from, el('span', { class: 'oc-help' }, 'to'), to]) };
  });
  return {
    node: el('div', { class: 'bk-hours' }, rows.map((r) => r.node)),
    value: () => Object.fromEntries(rows.filter((r) => r.on.checked && r.from.value < r.to.value).map((r) => [r.d, [[r.from.value, r.to.value]]])),
  };
}

function questionsEditor(list) {
  const host = el('div', { class: 'oc-stack' });
  const items = [];
  const add = (q = { label: '', type: 'text', required: false }) => {
    const label = input({ value: q.label || '', maxlength: '200', placeholder: 'The question' });
    const long = el('input', { type: 'checkbox', checked: q.type === 'long' });
    const req = el('input', { type: 'checkbox', checked: Boolean(q.required) });
    const item = { ref: q.ref, label, long, req };
    const node = el('div', { class: 'bk-q' }, [label, el('label', { class: 'bk-check' }, [long, 'Long answer']), el('label', { class: 'bk-check' }, [req, 'Required']),
      el('button', { type: 'button', class: 'oc-btn oc-btn--ghost oc-btn--sm', onClick: () => { items.splice(items.indexOf(item), 1); node.remove(); } }, 'Remove')]);
    items.push(item);
    host.appendChild(node);
  };
  (Array.isArray(list) ? list : []).forEach(add);
  const more = el('button', { type: 'button', class: 'oc-btn oc-btn--sm', onClick: () => add() }, 'Add a question');
  return {
    node: el('div', { class: 'oc-stack' }, [host, el('div', {}, more)]),
    value: () => {
      const used = new Set();
      return items.filter((i) => i.label.value.trim()).map((i, n) => {
        let ref = i.ref || slugOf(i.label.value).replace(/-/g, '_').slice(0, 30) || `q${n + 1}`;
        while (used.has(ref) || ref === 'phone') ref = `${ref}_${n + 1}`;
        used.add(ref);
        return { ref, label: i.label.value.trim(), type: i.long.checked ? 'long' : 'text', required: i.req.checked };
      });
    },
  };
}
