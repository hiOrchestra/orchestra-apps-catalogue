// The booking page. #/ lists the meeting types that are on (one alone opens
// at once); #/<type> shows its free days and times, then asks who you are.
// It reads two approved public views and writes one public action; a request
// is not "sent" until the action answered, and on a busy platform or a lost
// connection it retries on its own for about two minutes. What was typed is
// kept in this browser until it is sent.
import { ZONE, details, picker, state, top, typeList, whenSaid, whereOf } from './ui.js';

const { el, router } = Orch;
const HOST = 'page';
const WAITS = [3, 6, 12, 20, 30, 30, 30];
const T0 = Date.now();
const sleep = (ms) => new Promise((r) => { setTimeout(r, ms); });
const newId = () => (self.crypto && crypto.randomUUID ? crypto.randomUUID() : `${Date.now().toString(36)}${Math.random().toString(36).slice(2)}`);
const store = {
  get(k) { try { return JSON.parse(localStorage.getItem(k) || 'null') || {}; } catch { return {}; } },
  set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch { /* private window */ } },
};
const BASE = (() => {
  const p = location.pathname;
  const i = p.indexOf('/canvas/a/');
  return i < 0 ? '.' : `${p.slice(0, i)}/canvas/a/${p.slice(i + 10).split('/')[0]}`;
})();

function show(...nodes) {
  Orch.mount(HOST, nodes);
  const h = document.querySelector('#page h1, #page h2');
  if (h && h.tabIndex < 0) h.focus({ preventScroll: true });
  window.scrollTo(0, 0);
}
const again = (label = 'Try again') => el('button', { type: 'button', class: 'oc-btn', onClick: () => router.go(location.hash.slice(1) || '/', { replace: true }) }, label);
const back = (to, label) => el('button', { type: 'button', class: 'bp-back', onClick: to }, `← ${label}`);

/** The page's state from an error: not approved yet, busy, or broken. */
function trouble(e) {
  if (e.reason === 'public-view-pending' || e.status === 403) return show(state('Bookings are not open yet', 'This page is waiting to be switched on. Please come back a little later.'));
  if (e.status === 429) return show(state('Many people are booking right now', 'Please try again in a minute.', again()));
  return show(state('This page could not load', 'Check your connection and try again.', again()));
}

let page = null; // { host, intro, paused, auto, types }
async function loadPage() {
  if (page) return page;
  const r = await Orch.db.view('booking_page', { sort: 'position:asc', limit: 50 });
  const rows = r.rows || [];
  const s = rows[0] || {};
  page = { host: s.host || '', intro: s.intro || '', paused: s.paused === 'yes', auto: s.auto_confirm === 'yes', types: rows.filter((x) => x.slug) };
  return page;
}

async function home() {
  try { await loadPage(); } catch (e) { trouble(e); return; }
  if (page.paused) { show(state('Bookings are paused', `${page.host || 'This calendar'} is not taking bookings right now. Please come back later.`)); return; }
  if (!page.types.length) { show(state('Nothing to book right now', 'There is no meeting to book at the moment. Please come back later.')); return; }
  if (page.types.length === 1) { router.go(`/${page.types[0].slug}`, { replace: true }); return; }
  show(el('section', { class: 'bp-card' }, [top(page.host, page.intro), el('h1', { class: 'bp-title', tabindex: '-1' }, 'What would you like to book?'),
    typeList(page.types, (t) => router.go(`/${t.slug}`))]));
}

async function freeTimes(slug, filter = {}) {
  const out = [];
  for (let offset = 0; offset < 2000; offset += 500) {
    const r = await Orch.db.view('open_slots', { filter: Object.assign({ slug }, filter), sort: 'start_at:asc', limit: 500, offset });
    out.push(...(r.rows || []));
    if (!r.hasMore) break;
  }
  return out;
}

async function typePage({ slug }) {
  show(el('section', { class: 'bp-card bp-state' }, el('p', { class: 'bp-text' }, 'Looking for free times…')));
  let slots;
  try { await loadPage(); slots = await freeTimes(slug); } catch (e) { trouble(e); return; }
  const type = page.types.find((t) => t.slug === slug);
  if (page.paused) { show(state('Bookings are paused', 'No times are offered right now. Please come back later.')); return; }
  if (!type) { show(state('This meeting is not offered', 'The link may be old.', page.types.length ? router.link('/', 'See what can be booked', { class: 'oc-btn' }) : null)); return; }
  const many = page.types.length > 1;
  const head = () => [top(page.host, null), many ? back(() => router.go('/'), 'All meetings') : null, el('h1', { class: 'bp-title', tabindex: '-1' }, type.name),
    el('p', { class: 'oc-value bp-facts' }, [`${type.duration_min} min`, whereOf(type) ? ` · ${whereOf(type)}` : '']),
    type.description ? el('p', { class: 'bp-text' }, type.description) : null];
  if (!slots.length) { show(el('section', { class: 'bp-card' }, [...head(), state('No free times right now', 'Every time is taken for now. Please look again in a day or two.')])); return; }
  let day = null;
  const pickTime = () => show(el('section', { class: 'bp-card' }, [...head(),
    picker(slots, day, (k) => { day = k; pickTime(); }, (s) => form(type, s, head, pickTime))]));
  pickTime();
}

function form(type, slot, head, toTimes) {
  const key = 'booking:me';
  const saved = store.get(key);
  const qs = (() => { try { return JSON.parse(type.questions || '[]'); } catch { return []; } })();
  const d = details(type, Array.isArray(qs) ? qs : [], saved);
  const visit = newId();
  const status = el('p', { class: 'bp-status', role: 'status', 'aria-live': 'polite' });
  const send = el('button', { type: 'submit', class: 'oc-btn oc-btn--primary bp-send' }, 'Request this time');
  const f = el('form', { class: 'bp-form', novalidate: false }, [
    el('div', { class: 'bp-chosen' }, [el('p', { class: 'oc-eyebrow' }, 'Your time'), el('p', { class: 'bp-chosen__when' }, whenSaid(slot)), back(toTimes, 'Pick another time')]),
    ...d.nodes,
    send, status,
    el('p', { class: 'bp-note' }, page.auto ? 'You get a calendar invitation by email in a moment.' : 'This is a request: you get a calendar invitation by email once it is confirmed.'),
  ]);
  f.addEventListener('input', () => { const v = d.read(); store.set(key, { name: v.name, email: v.email, phone: v.phone, answers: v.answers }); });
  f.addEventListener('submit', async (e) => {
    e.preventDefault();
    if (!f.reportValidity()) return;
    send.disabled = true;
    try {
      const still = await freeTimes(type.slug, { start_at: slot.start_at });
      if (!still.length) {
        Orch.toast('That time was just taken. Please pick another.', { error: true });
        typePage({ slug: type.slug });
        return;
      }
      const v = d.read();
      await request({ type_id: slot.type_id, start_at: slot.start_at, end_at: slot.end_at, name: v.name, email: v.email,
        answers: JSON.stringify(v.answers), tz: ZONE, hp: v.hp || '', ms: Date.now() - T0, visit }, status);
      processNow();
      sent(type, slot, v);
    } catch (err) {
      send.disabled = false;
      status.textContent = 'It could not be sent. What you wrote is still here: try again.';
    }
  });
  show(el('section', { class: 'bp-card' }, [...head(), f]));
}

/** The request, sent; on a busy platform or a lost connection, again after a wait. */
async function request(params, status) {
  status.textContent = 'Sending…';
  for (let i = 0; ; i += 1) {
    try {
      return await Orch.action('request', params);
    } catch (e) {
      const passing = !e.status || e.status === 429 || e.status >= 500;
      if (!passing || i >= WAITS.length) throw e;
      for (let s = WAITS[i]; s > 0; s -= 1) { status.textContent = `Busy right now. Trying again in ${s} s…`; await sleep(1000); }
      status.textContent = 'Sending…';
    }
  }
}

/** Ask for the request to be checked now. It carries nothing; a refused beacon is picked up by the half-hourly check. */
function processNow() {
  const body = new Blob([JSON.stringify({ params: {} })], { type: 'application/json' });
  try { if (navigator.sendBeacon && navigator.sendBeacon(`${BASE}/api/actions/process`, body)) return; } catch { /* plain call below */ }
  Orch.action('process', {}).catch(() => { /* the half-hourly check takes it */ });
}

function sent(type, slot, v) {
  show(state('Request sent', page.auto
    ? `${type.name}, ${whenSaid(slot)}. The invitation is on its way to ${v.email}: accept it there to add it to your calendar.`
    : `${type.name}, ${whenSaid(slot)}. You get the invitation at ${v.email} once it is confirmed. If the time cannot be kept, you will hear back.`,
  router.link('/', 'Book something else', { class: 'oc-btn oc-btn--ghost' })));
}

router.define({ '/': home, '/:slug': typePage }, () => home()).start();
