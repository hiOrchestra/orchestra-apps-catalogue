// The pieces of the booking page. Times are shown in the visitor's own time
// zone (the browser's), never the owner's: the server keeps them in UTC.
const { el } = Orch;

export const ZONE = (() => { try { return Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC'; } catch { return 'UTC'; } })();
const f = (o) => new Intl.DateTimeFormat(undefined, Object.assign({ timeZone: ZONE }, o));
const DAY = f({ weekday: 'long', day: 'numeric', month: 'long' });
const SHORT = f({ weekday: 'short', day: 'numeric', month: 'short' });
const TIME = f({ hour: '2-digit', minute: '2-digit' });
const KEY = f({ year: 'numeric', month: '2-digit', day: '2-digit' });
export const dayOf = (iso) => KEY.format(new Date(iso));
export const longDay = (iso) => DAY.format(new Date(iso));
export const time = (iso) => TIME.format(new Date(iso));
export const whenSaid = (s) => `${longDay(s.start_at)}, ${time(s.start_at)}–${time(s.end_at)}`;

const WHERE = { meet: 'Video call (Google Meet)', phone: 'Phone call', place: 'In person', none: '' };
export const whereOf = (t) => (t.location_kind === 'place' && t.location_detail ? `In person · ${t.location_detail}` : WHERE[t.location_kind] || '');

/** A page with nothing to pick: not open yet, paused, no times, busy, broken, sent. */
export function state(title, text, extra) {
  return el('section', { class: 'bp-card bp-state', 'aria-live': 'polite' }, [
    el('h1', { class: 'bp-title', tabindex: '-1' }, title),
    text ? el('p', { class: 'bp-text' }, text) : null,
    extra || null,
  ]);
}

/** The top of every step: who you meet, and the step's own line. */
export function top(host, intro) {
  return el('header', { class: 'bp-top' }, [
    host ? el('p', { class: 'oc-eyebrow' }, host) : null,
    intro ? el('p', { class: 'bp-text' }, intro) : null,
  ]);
}

export function typeList(types, open) {
  return el('ul', { class: 'bp-types' }, types.map((t) => el('li', {}, el('button', { type: 'button', class: 'bp-type', onClick: () => open(t) }, [
    el('span', { class: 'bp-type__name' }, t.name),
    el('span', { class: 'oc-value' }, [`${t.duration_min} min`, whereOf(t) ? ` · ${whereOf(t)}` : '']),
    t.description ? el('span', { class: 'bp-type__desc' }, t.description) : null,
  ]))));
}

/** The days that have free times, then the times of the day picked. */
export function picker(slots, chosenDay, onDay, onTime) {
  const days = [];
  for (const s of slots) {
    const k = dayOf(s.start_at);
    if (!days.length || days[days.length - 1].k !== k) days.push({ k, slots: [] });
    days[days.length - 1].slots.push(s);
  }
  const day = days.find((d) => d.k === chosenDay) || days[0];
  return el('div', { class: 'bp-pick' }, [
    el('div', { class: 'bp-days', role: 'group', 'aria-label': 'Days with free times' }, days.map((d) => el('button', {
      type: 'button', class: 'bp-day', 'aria-pressed': d === day ? 'true' : 'false', onClick: () => onDay(d.k),
    }, [el('span', SHORT.format(new Date(d.slots[0].start_at))), el('span', { class: 'bp-day__n' }, `${d.slots.length} ${d.slots.length === 1 ? 'time' : 'times'}`)]))),
    el('section', { class: 'bp-times', 'aria-label': `Free times on ${longDay(day.slots[0].start_at)}` }, [
      el('h2', { class: 'bp-h2' }, longDay(day.slots[0].start_at)),
      el('div', { class: 'bp-times__grid' }, day.slots.map((s) => el('button', { type: 'button', class: 'bp-time', onClick: () => onTime(s) }, time(s.start_at)))),
    ]),
    el('p', { class: 'bp-note' }, `Times are in your time zone: ${ZONE.replace(/_/g, ' ')}.`),
  ]);
}

/** Name, email, the type's questions (and a phone for a phone call); the bot trap off-screen. */
export function details(type, questions, saved) {
  const field = (label, control, help) => el('label', { class: 'oc-field bp-field' }, [el('span', { class: 'oc-label' }, label), control, help ? el('span', { class: 'oc-help' }, help) : null]);
  const name = el('input', { class: 'oc-input', name: 'name', autocomplete: 'name', required: true, maxlength: '120', value: saved.name || '' });
  const email = el('input', { class: 'oc-input', name: 'email', type: 'email', autocomplete: 'email', required: true, maxlength: '200', value: saved.email || '' });
  const phone = type.location_kind === 'phone' ? el('input', { class: 'oc-input', name: 'phone', type: 'tel', autocomplete: 'tel', required: true, maxlength: '25', value: saved.phone || '' }) : null;
  const asks = questions.map((q) => ({ q, node: q.type === 'long'
    ? el('textarea', { class: 'oc-textarea', name: q.ref, rows: '3', maxlength: '2000', required: Boolean(q.required) }, (saved.answers || {})[q.ref] || '')
    : el('input', { class: 'oc-input', name: q.ref, maxlength: '2000', required: Boolean(q.required), value: (saved.answers || {})[q.ref] || '' }) }));
  const trap = el('input', { class: 'bp-trap', type: 'text', name: 'website_url', tabindex: '-1', autocomplete: 'off', 'aria-hidden': 'true' });
  const nodes = [
    field('Your name', name),
    field('Email', email, 'The invitation goes here.'),
    phone ? field('Phone number', phone, 'We call you on it.') : null,
    ...asks.map(({ q, node }) => field(q.required ? q.label : `${q.label} (optional)`, node)),
    trap,
  ];
  return {
    nodes,
    read() {
      const answers = {};
      for (const { q, node } of asks) if (node.value.trim()) answers[q.ref] = node.value.trim();
      if (phone) answers.phone = phone.value.trim();
      return { name: name.value.trim(), email: email.value.trim(), answers, hp: trap.value, phone: phone ? phone.value.trim() : '' };
    },
  };
}
