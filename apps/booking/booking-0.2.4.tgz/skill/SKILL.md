---
name: app-booking
version: 0.2.4
description: >-
  Work with the Booking app (a Calendly on this workspace): what is booked
  today or this week, which requests wait for an OK, the meeting types and
  their weekly hours, the booking link to share, and the agent's prep brief
  before a meeting. Use when someone says "what meetings do I have / qué
  reuniones tengo", "what's booked this week / qué tengo esta semana", "change
  my hours / cambia mi horario", "add a meeting type / crea un tipo de
  reunión", "send me my booking link / pásame el link para agendar", "cancel
  the meeting with Ana / cancela la reunión con Ana", "reschedule / mover la
  reunión", "prep me for my 3 pm / prepárame la reunión de las 15". Needs the
  Booking app installed in a project you work in.
metadata:
  openclaw:
    emoji: "📅"
---
# Booking — meetings people book, the hours offered, a brief before each one

People pick a free time on a public page (the Canvas app `book`), the owner
confirms it on the desk (`scheduling`), and Google Calendar sends the
invitation. Before each confirmed meeting the project's agent writes a brief.

## Is it installed

```bash
ls -d ~/.openclaw/orchestra/projects/*/apps/booking      # the project id is the directory under projects/
P=<project id>
cat ~/.openclaw/orchestra/projects/$P/apps/booking/workflows.json   # {"slots":…, "intake":…, "confirm":…, "prep":…}
orch-database --project $P tables                         # bk_settings, bk_types, bk_slots, bk_bookings
```

If nothing is there, Booking is not installed in a project you work in: say
so, and do not improvise bookings some other way.

## The model

| Table | One row per |
|---|---|
| `bk_settings` | one row: `display_name`, `intro`, `timezone` (IANA), `calendar_id` (`primary` by default; several ids separated by commas, events go to the first), `min_notice_hours`, `days_ahead`, `buffer_min`, `auto_confirm` (`yes`/`no`), `paused` (`yes`/`no`), `notify_telegram`, `prep_agent`, `public_url`, `desk_url`, `calendar_status` (`ok`, `not_connected`, `error`), `slots_note` |
| `bk_types` | meeting type: `slug` (its link, unique), `name`, `duration_min`, `step_min` (15, 30 or 60), `description`, `location_kind` (`meet`, `phone`, `place`, `none`), `location_detail` (the address for `place`), `hours`, `questions`, `active` (`yes`/`no`), `position` |
| `bk_slots` | a free time per type, `start_at`/`end_at`. Written only by the Offer times workflow: never write here |
| `bk_bookings` | a request: `type_name`, `name`, `email`, `answers` (JSON), `start_at`, `end_at`, `tz` (the visitor's zone), `status`, `reason`, `decided_by`, `calendar_event_id`, `event_link`, `meet_link`, `prep` (the brief, JSON), `prep_status`, `prep_note`, `cancel_status`, `cancel_note` |

All times are UTC text `YYYY-MM-DDTHH:MM:SSZ`. Say them to people in
`bk_settings.timezone`. `hours` is JSON in that zone,
`{"mon":[["09:00","17:00"]],"tue":[…]}` (keys `mon`…`sun`, `HH:MM`, start
before end; a missing day is closed). `questions` is JSON
`[{"ref":"company","label":"Company or website","type":"text","required":false}]`,
`type` `text` or `long`.

Statuses: New (sent by the page; Take requests judges it in seconds) →
Requested (waits for the owner's Confirm) → Confirming (the Confirm workflow
is creating the event) → Confirmed (the event exists; Google invited the
person). Failed: the time could not be given (taken, no longer free, too
soon, paused, type off) or Google refused; `reason` says which. Declined: the
owner said no, or dismissed a Failed. Cancelled: a Confirmed the owner
cancelled; its `cancel_status` says what happened to the Google event:
Pending → Working (the Confirm workflow is deleting it) → Done (deleted, and
Google told the guest), or Failed (`cancel_note` says why; Try again on the
desk). Empty on meetings cancelled before 0.2.4. Discarded: not a person (bot trap, too fast, duplicate). Declined,
Cancelled and Discarded are final. `prep_status`: Waiting → Working
→ Done, or Failed (`prep_note` says why), or Off (no `prep_agent` set).

## How you act

The desk's buttons are actions you cannot call from the shell. You act by
running the app's workflows, and by `orch-database` writes that copy exactly
what the matching desk action writes (below). Rules:

- After changing a type or the settings, run Offer times; the desk does the
  same. Nothing new is offered until it runs.
- Use `batch` with a `when` on the status for any status change: if the row
  moved on, the write fails instead of clobbering it.
- Outward steps need the person's yes in this conversation: confirming (Google
  emails the guest), cancelling a meeting (Google emails the guest that it is
  cancelled), turning on `auto_confirm`, turning a type on (it appears on the
  public page), resuming bookings.
- Booking never writes to the guest itself. Decline sends nothing; Confirm and
  Cancel go through Google Calendar, which invites the guest or tells them it
  is cancelled.

Workflows (ids from `workflows.json`; `--args` must carry a mode):

| Workflow | Run | Does |
|---|---|---|
| Offer times (`slots`) | `orch-workflows run <slots> --args '{"mode":"--now"}'` | rebuilds `bk_slots` from hours, Google free/busy, bookings |
| Take requests (`intake`) | `orch-workflows run <intake> --args '{"mode":"--now"}'` | judges New requests |
| Confirm (`confirm`) | `orch-workflows run <confirm> --args '{"mode":"--now"}'` | creates the events for Requested rows with `confirm_asked_at` set; deletes the events of Cancelled rows with `cancel_status` Pending |
| Prepare (`prep`) | `orch-workflows run <prep> --args '{"mode":"--auto"}'` | writes the brief for the next Confirmed meeting with `prep_status` Waiting |

Each also runs on its own every 30 minutes when it has work. Check a run with
`orch-workflows runs --limit 5` and `orch-workflows status <run-id>`.

## Recipes

What's booked today / this week:
```bash
orch-database --project $P query "SELECT _id, type_name, name, email, start_at, end_at, meet_link, prep_status FROM bk_bookings WHERE _deleted = 0 AND status = 'Confirmed' AND start_at >= strftime('%Y-%m-%dT%H:%M:%SZ','now') AND start_at < strftime('%Y-%m-%dT%H:%M:%SZ','now','+7 days') ORDER BY start_at"
```
Waiting for an OK: the same with `status = 'Requested'`. Needing a decision:
`status = 'Failed'`, read `reason`. Convert times to the settings zone.

Confirm a request (only with the person's yes; Google invites the guest):
```bash
orch-database --project $P batch --ops '[{"op":"update","table":"bk_bookings","id":42,"when":{"status":"Requested"},"data":{"confirm_asked_at":"'$(date -u +%Y-%m-%dT%H:%M:%SZ)'","decided_by":"<person name>"}}]'
orch-workflows run <confirm> --args '{"mode":"--now"}'
```
Then read the row: Confirmed with `event_link`, or Failed with `reason`.
Decline: `"data":{"status":"Declined","reason":"…","decided_by":"…","decided_at":"<now>"}` with the same `when`.

Set the hours / availability:
1. `orch-database --project $P query "SELECT _id, name, slug, active, hours FROM bk_types WHERE _deleted = 0 ORDER BY position"`.
2. `orch-database --project $P update bk_types --id <id> --data '{"hours":"{\"mon\":[[\"10:00\",\"14:00\"]],\"wed\":[[\"10:00\",\"14:00\"]]}"}'` (the whole week: days left out are closed).
3. Run Offer times; then `SELECT slots_note, calendar_status FROM bk_settings`.
Notice, days ahead, buffer and time zone are `bk_settings` fields
(`min_notice_hours`, `days_ahead`, `buffer_min`, `timezone`): `update` its one
row, then run Offer times. Pause all bookings: `paused` = `yes`; resume:
`paused` = `no` and run Offer times.

Add or change a meeting type:
- New: `orch-database --project $P insert bk_types --data '{…}'` with `slug`
  (lowercase letters, digits, dashes; check no live type has it), `name`,
  `duration_min`, `step_min`, `description`, `location_kind`,
  `location_detail`, `hours`, `questions` (JSON as text, `"[]"` for none),
  `position`, and `"active":"no"`. It starts off, as on the desk.
- Change: `update bk_types --id N` with any of those fields except `active`.
- On / off (on only with the person's yes): `active` `yes` / `no`. Run Offer
  times after any change. Never delete a type that has bookings: turn it off.

Cancel a meeting (Confirmed), only with the person's yes (Google tells the
guest), the same as the desk's Cancel:
```bash
orch-database --project $P batch --ops '[{"op":"update","table":"bk_bookings","id":42,"when":{"status":"Confirmed"},"data":{"status":"Cancelled","reason":"…","decided_by":"…","decided_at":"<now>","cancel_status":"Pending","cancel_note":null}}]'
orch-workflows run <confirm> --args '{"mode":"--now"}'
```
That frees the time, and the run deletes the event with `send_updates: all`.
Then read the row: `cancel_status` Done, or Failed with `cancel_note` (try
again: `"when":{"status":"Cancelled","cancel_status":"Failed"}`,
`"data":{"cancel_status":"Pending","cancel_note":null}`, run Confirm).

Reschedule: there is no reschedule for a Confirmed meeting. Cancel it as
above and share the booking link so
the guest picks again (the person sends it). A Failed request can be invited
at another free time, on the desk ("Invite at another time"), or by hand:
take a `bk_slots` row of the same `type_id` in the future, then `batch` with
`"when":{"status":"Failed"}` and `"data":{"start_at":…,"end_at":…,"status":"Requested","reason":null,"confirm_asked_at":"<now>","decided_by":"…"}`,
and run Confirm (with the person's yes: Google invites the guest).

The booking link to share: `orch-canvas url book`, or `public_url` in
`bk_settings`; one type's own page is `<url>#/<slug>`. It only takes bookings
when a type is `active = 'yes'`, `paused` is `no`, Google Calendar is
connected (`calendar_status = 'ok'`) and a person has set Book to Public and
published it. Give the link to the person; do not send it to anyone yourself.

Prep notes for an upcoming meeting: read `prep` of that booking (JSON:
`summary`, `person`, `company`, `history`, `wants`, `questions`, `sources`,
`confidence`). Quote it; mention `confidence` when it is low. If
`prep_status` is Failed or Done and the person wants it redone, set
`"prep_status":"Waiting","prep_note":null` (only on a Confirmed row) and run
Prepare. Off means no `prep_agent` in Settings.

## Other apps

- CRM: Prepare reads `crm_contacts`, `crm_companies`, `crm_activities` when
  the CRM is in the same project. Booking writes nothing to the CRM; the CRM's
  calendar sync (when on) logs the event only for a guest already a contact.
  Adding a booker as a contact is by hand, through the CRM.
- Google Calendar: through Composio, inside the scripts; the person connects
  it in the portal's Integrations. Nothing links to the other apps.

## Never

- Confirm, turn on `auto_confirm`, turn a type on or resume bookings without the person's yes here.
- Write to `bk_slots`, or set a booking to New, Confirming or Confirmed yourself.
- Change `start_at`/`end_at` of a Requested or Confirmed booking.
- Write to a guest, or send the link to anyone, unless the person asked and said to whom.
- Delete rows; Cancel and Decline are the way out. Publish or make `book` public: only a person can.
