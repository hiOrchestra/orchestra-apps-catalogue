// How bookings work for everyone: the name visitors see, the time zone the
// weekly hours are in, the calendar checked and written to, notice, how far
// ahead, the buffer, auto-confirm (off unless the owner turns it on), who
// prepares the briefs, and Telegram. Pausing is its own button: it takes
// every time off the page at once.
import { A, act, copy, head, notices, publicLink, settings, when } from '../data.js';

const { el, fmt } = Orch;
const ZONES = ['Europe/Madrid', 'Europe/London', 'Europe/Lisbon', 'Europe/Paris', 'Europe/Berlin', 'America/New_York', 'America/Chicago', 'America/Denver',
  'America/Los_Angeles', 'America/Mexico_City', 'America/Bogota', 'America/Lima', 'America/Santiago', 'America/Argentina/Buenos_Aires', 'America/Sao_Paulo',
  'Asia/Dubai', 'Asia/Kolkata', 'Asia/Singapore', 'Asia/Tokyo', 'Australia/Sydney', 'UTC'];

export function render() {
  Orch.load('view', async () => {
    const s = await settings();
    if (!s._id) return el('p', { class: 'oc-state' }, 'Booking is not installed in this project.');
    return el('div', { class: 'oc-stack oc-stack--loose' }, [
      head('Settings', 'How bookings work for every meeting type.'),
      ...notices(s),
      pause(s),
      times(s),
      form(s),
    ]);
  });
}

function pause(s) {
  const paused = s.paused === 'yes';
  const b = el('button', { type: 'button', class: `oc-btn${paused ? ' oc-btn--primary' : ''}`, onClick: async () => {
    if (!paused && !(await Orch.confirm('Pause bookings? Your page stops offering times at once. Requests already in stay, and confirmed meetings are not touched.', { yes: 'Pause' }))) return;
    if (await act(paused ? A.resume : A.pause, { id: s._id }, paused ? 'Resumed: the times are back on your page in a moment.' : 'Paused: no times are offered.')) render();
  } }, paused ? 'Resume bookings' : 'Pause bookings');
  return el('section', { class: 'oc-card oc-stack' }, [
    el('div', { class: 'oc-row oc-row--between' }, [el('h2', { class: 'oc-h2' }, 'Your booking page'), el('span', { class: `oc-badge${paused ? ' oc-badge--warn' : ' oc-badge--good'}` }, paused ? 'Paused' : 'Taking bookings')]),
    el('div', { class: 'bk-code' }, [el('code', publicLink(s)), el('button', { type: 'button', class: 'oc-btn oc-btn--sm', onClick: () => copy(publicLink(s), 'Link copied.') }, 'Copy')]),
    el('div', { class: 'oc-row' }, b),
  ]);
}

function times(s) {
  const built = when(s.slots_built_at);
  return el('section', { class: 'oc-card oc-stack' }, [
    el('h2', { class: 'oc-h2' }, 'Free times'),
    el('p', { class: 'oc-help' }, 'Worked out every 30 minutes from your weekly hours and Google Calendar (only when each slot is busy, never what is in it), after each request, and when you save here.'),
    el('p', { class: 'oc-value' }, built ? `Last built ${fmt.ago(built.toISOString())} · ${s.slots_note || ''}` : 'Not built yet'),
    el('div', { class: 'oc-row' }, el('button', { type: 'button', class: 'oc-btn oc-btn--sm', onClick: async () => { if (await act(A.rebuild, {}, 'Working them out now.')) setTimeout(render, 3000); } }, 'Work them out now')),
  ]);
}

const input = (attrs) => el('input', Object.assign({ class: 'oc-input' }, attrs));
const field = (label, control, help) => el('label', { class: 'oc-field' }, [el('span', { class: 'oc-label' }, label), control, help ? el('span', { class: 'oc-help' }, help) : null]);
const yesNo = (v, yes, no) => el('select', { class: 'oc-select' }, [el('option', { value: 'no', selected: v !== 'yes' }, no), el('option', { value: 'yes', selected: v === 'yes' }, yes)]);

function form(s) {
  const c = {
    display_name: input({ value: s.display_name || '', maxlength: '80', placeholder: 'Your name or your company' }),
    intro: el('textarea', { class: 'oc-textarea', rows: '2', maxlength: '400' }, s.intro || ''),
    timezone: el('select', { class: 'oc-select' }, [...new Set([s.timezone || 'Europe/Madrid', ...ZONES])].map((z) => el('option', { value: z, selected: z === s.timezone }, z))),
    calendar_id: input({ value: s.calendar_id || 'primary', maxlength: '200' }),
    min_notice_hours: input({ type: 'number', min: '0', max: '720', value: s.min_notice_hours ?? 4 }),
    days_ahead: input({ type: 'number', min: '1', max: '90', value: s.days_ahead ?? 30 }),
    buffer_min: input({ type: 'number', min: '0', max: '240', step: '5', value: s.buffer_min ?? 0 }),
    auto_confirm: yesNo(s.auto_confirm, 'On: confirm and invite at once', 'Off: I confirm each request'),
    prep_agent: input({ value: s.prep_agent || '', maxlength: '60', placeholder: 'Empty: no briefs' }),
    notify_telegram: input({ value: s.notify_telegram || '', maxlength: '40', placeholder: '@channel or chat id' }),
  };
  const save = el('button', { type: 'submit', class: 'oc-btn oc-btn--primary' }, 'Save');
  const f = el('form', { class: 'oc-card oc-stack bk-form' }, [
    el('h2', { class: 'oc-h2' }, 'How bookings work'),
    field('Name visitors see', c.display_name, 'On the page, and in the invitation title.'),
    field('Words on the page', c.intro),
    field('Time zone', c.timezone, 'The weekly hours of every type are in this zone. Visitors see times in their own.'),
    field('Google calendar', c.calendar_id, '"primary" is the main calendar of the connected Google account. Busy time is read from it and events are created in it.'),
    el('div', { class: 'bk-two' }, [field('Minimum notice (hours)', c.min_notice_hours), field('Days ahead', c.days_ahead)]),
    field('Buffer around meetings (minutes)', c.buffer_min, 'Kept free before and after each busy time.'),
    field('Auto-confirm', c.auto_confirm, 'On, a good request becomes a meeting and Google invites the person without you. Off, nothing is sent until you press Confirm.'),
    field('Agent that prepares meetings', c.prep_agent, 'Before each confirmed meeting it writes a brief on the person and their company. It contacts nobody.'),
    field('Telegram', c.notify_telegram, 'Where you hear about new requests and confirmations.'),
    el('div', { class: 'oc-row' }, save),
  ]);
  f.addEventListener('submit', async (e) => {
    e.preventDefault();
    const params = { id: s._id };
    for (const [k, node] of Object.entries(c)) params[k] = node.type === 'number' ? Number(node.value) : String(node.value).trim();
    if (params.auto_confirm === 'yes' && s.auto_confirm !== 'yes'
      && !(await Orch.confirm('With auto-confirm on, every good request creates an event and Google sends the invitation, without you seeing it first. Turn it on?', { yes: 'Turn it on' }))) return;
    save.disabled = true;
    if (await act(A.settings, params, 'Saved. The free times are being worked out again.')) render();
    save.disabled = false;
  });
  return f;
}
