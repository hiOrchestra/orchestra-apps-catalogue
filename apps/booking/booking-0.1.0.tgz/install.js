// Booking, installed into one project of this instance: tables and indexes,
// the seed (settings and an Intro call that starts OFF, only into empty
// tables), the scripts, four workflows with their half-hourly checks (each
// only runs when there is work), the desk `scheduling` and the public page
// `book` with their grants, views, actions, brand and brief, and the links
// the scripts give out. Converges: run it again after a change and it ends in
// the same state. Turns nothing on: no type is offered until the owner does it.
//
//   as node, by the team over ssh:        gosu node node install.js <bundle> --project default --agent dario
//   as the project's agent, over the MCP: projects.run → node <bundle>/install.js <bundle> --project default --agent dario
// Over the MCP each call has 120 s: run it in parts with --only (in this order):
//   --only files,tables,seed  ·  --only workflows,schedule  ·  --only desk  ·  --only public,settings
// Prints one JSON line per step, and at the end what a person still has to do.
'use strict';
const { execFileSync } = require('child_process');
const fs = require('fs');
const path = require('path');

const B = path.resolve(process.argv[2] || __dirname);
const flag = (name, fallback) => { const i = process.argv.indexOf(`--${name}`); return i > 0 && process.argv[i + 1] ? process.argv[i + 1] : fallback; };
const PROJECT = flag('project', 'default');
const AGENT = flag('agent', '');
const ONLY = new Set((flag('only', 'files,tables,seed,workflows,schedule,desk,public,settings')).split(','));
const STATE = process.env.OPENCLAW_STATE_DIR || '/home/node/.openclaw';
const HOME = path.join(STATE, 'orchestra', 'projects', PROJECT);
const AUTO = path.join(HOME, 'apps', 'booking', 'automations');
const read = (f) => fs.readFileSync(path.join(B, f), 'utf8');
const json = (f) => JSON.parse(read(f));
const todo = [];
const out = (step, data) => console.log(JSON.stringify(Object.assign({ step }, data)));

function cli(bin, args, { soft = false } = {}) {
  let text;
  try {
    text = execFileSync(bin, args, { encoding: 'utf8', timeout: 100000, maxBuffer: 32 << 20 });
  } catch (e) {
    text = String(e.stdout || '') || String(e.stderr || e.message);
    if (!soft) out('warn', { bin, args: args.slice(0, 3), said: text.trim().slice(0, 300) });
  }
  try { return JSON.parse(text); } catch { return { raw: String(text).trim().slice(0, 600) }; }
}
const db = (...a) => cli('orch-database', ['--project', PROJECT, ...a]);
const canvas = (...a) => cli('orch-canvas', a);
const wf = (...a) => cli('orch-workflows', a);
const pick = (o, keys) => Object.fromEntries(keys.filter((k) => o && o[k] !== undefined).map((k) => [k, o[k]]));
const ids = () => { try { return JSON.parse(fs.readFileSync(path.join(AUTO, '..', 'workflows.json'), 'utf8')); } catch { return {}; } };
const WORKFLOWS = ['slots', 'intake', 'confirm', 'prep'];
// Staggered, so the four checks never start in the same minute.
const CRON = { slots: '7,37 * * * *', intake: '*/30 * * * *', confirm: '13,43 * * * *', prep: '21,51 * * * *' };
const CHECK = { slots: 'Offer times (every 30 min while a type is on)', intake: 'Take requests (half-hourly check)', confirm: 'Confirm (half-hourly check)', prep: 'Prepare meetings (half-hourly check)' };

// ── 1. the scripts ───────────────────────────────────────────────────────
if (ONLY.has('files')) {
  fs.mkdirSync(AUTO, { recursive: true });
  for (const f of fs.readdirSync(path.join(B, 'automations'))) fs.copyFileSync(path.join(B, 'automations', f), path.join(AUTO, f));
  out('files', { dir: AUTO, files: fs.readdirSync(AUTO) });
}

// ── 2. tables and indexes ────────────────────────────────────────────────
const schema = json('schema.json');
if (ONLY.has('tables')) {
  for (const [table, cols] of Object.entries(schema.tables)) {
    out('table', Object.assign({ table }, pick(db('ensure-table', table, '--columns', ...cols), ['ok', 'action', 'created', 'added', 'error', 'raw'])));
  }
  for (const sql of schema.indexes) out('index', Object.assign({ sql: sql.slice(0, 80) }, pick(db('sql', sql, '--confirm'), ['ok', 'error', 'raw'])));
}

// ── 3. seed, only into empty tables ──────────────────────────────────────
if (ONLY.has('seed')) {
  const count = (t) => (((db('query', `SELECT COUNT(*) AS n FROM ${t} WHERE _deleted = 0`).rows || [{}])[0]) || {}).n;
  for (const [table, rows] of Object.entries(json('seed.json'))) {
    if (count(table) > 0) { out('seed', { table, left: 'it has rows' }); continue; }
    const data = rows.map((r) => Object.fromEntries(Object.entries(r).map(([k, v]) => [k, v !== null && typeof v === 'object' ? JSON.stringify(v) : v])));
    if (table === 'bk_settings' && AGENT) data[0].prep_agent = AGENT;
    out('seed', Object.assign({ table }, pick(db('insert-many', table, '--data', JSON.stringify(data)), ['ok', 'count', 'inserted', 'error', 'raw'])));
  }
}

// ── 4. workflows (by name: created once, updated after) ─────────────────
if (ONLY.has('workflows')) {
  if (!AGENT) throw new Error('--agent <id> names the project member the scripts run as and who prepares the meetings (the project\'s coordinator)');
  const existing = wf('list').workflows || [];
  const WF = {};
  const tmp = fs.mkdtempSync('/tmp/booking-wf-');
  for (const key of WORKFLOWS) {
    // runsAs: the scripts run as this agent (orch-as), so it must be a member of the project to reach its database.
    const spec = Object.assign(JSON.parse(read(`workflows/${key}.json`).replace(/__AUTO__/g, AUTO).replace(/__AGENT__/g, AGENT)),
      { project: PROJECT, runsAs: AGENT });
    const file = path.join(tmp, `${key}.json`);
    fs.writeFileSync(file, JSON.stringify(spec));
    const found = existing.find((w) => w.name === spec.name);
    const r = found ? wf('update', found.id, '--file', file) : wf('create', '--file', file);
    WF[key] = found ? found.id : ((r.workflow && r.workflow.id) || r.id || r.workflowId);
    out('workflow', { name: spec.name, id: WF[key], did: found ? 'updated' : 'created', error: r.error || undefined });
  }
  fs.rmSync(tmp, { recursive: true, force: true });
  // confirm.js reads this to start the brief right after a confirmation.
  fs.writeFileSync(path.join(AUTO, '..', 'workflows.json'), JSON.stringify(WF, null, 1));
}

// ── 5. the half-hourly checks: each one only when its --where finds work ──
if (ONLY.has('schedule')) {
  const WF = ids();
  for (const key of WORKFLOWS) {
    if (!WF[key]) { out('schedule', { workflow: key, error: 'not created: run --only workflows first' }); continue; }
    for (const s of (wf('schedules', WF[key]).schedules || [])) out('unschedule', pick(wf('unschedule', s.jobId), ['ok', 'error']));
    out('schedule', Object.assign({ workflow: key }, pick(wf('schedule', WF[key], '--cron', CRON[key], '--timezone', 'UTC', '--name', `Booking · ${CHECK[key]}`,
      '--table', 'bk_settings', '--where', read(`workflows/${key}.where`), '--limit', '1'), ['ok', 'jobId', 'schedule', 'error', 'raw'])));
  }
}

// ── 6. the apps ──────────────────────────────────────────────────────────
function app(id, src, brief) {
  let a = (canvas('list').apps || []).find((x) => x.id === id);
  if (!a) {
    out('init', Object.assign({ app: id }, pick(canvas('init', id, '--project', PROJECT, '--pattern', 'list', '--confirmed', ...brief), ['ok', 'dir', 'url', 'error', 'raw'])));
    a = (canvas('list').apps || []).find((x) => x.id === id);
  }
  if (!a) throw new Error(`The app ${id} could not be created`);
  const dir = path.join(STATE, 'orchestra', a.dir);
  const ours = new Set();
  const copy = (from, to) => {
    for (const f of fs.readdirSync(from)) {
      const s = path.join(from, f);
      const d = path.join(to, f);
      if (fs.statSync(s).isDirectory()) { fs.mkdirSync(d, { recursive: true }); copy(s, d); } else { fs.copyFileSync(s, d); ours.add(path.relative(dir, d)); }
    }
  };
  copy(path.join(B, src), dir);
  // What the starter wrote and Booking does not use goes, so the app is exactly the source.
  const sweep = (d) => {
    for (const f of fs.readdirSync(d)) {
      const p = path.join(d, f);
      const rel = path.relative(dir, p);
      if (rel.startsWith('_') || rel.startsWith('.')) continue;
      if (fs.statSync(p).isDirectory()) sweep(p); else if (!ours.has(rel)) { fs.unlinkSync(p); out('removed', { app: id, file: rel }); }
    }
  };
  sweep(dir);
  out('files', { app: id, dir, count: ours.size });
  return a;
}

function actions(id, list) {
  const WF = ids();
  const sub = (v) => (typeof v === 'string' && v.startsWith('$WF_') ? WF[v.slice(4).toLowerCase()] : v);
  for (const a of list) {
    const args = ['action', 'add', id, '--name', a.name, '--type', a.type, '--access', a.access || 'members'];
    if (a.table) args.push('--table', a.table);
    if (a.fields) args.push('--fields', a.fields.join(','));
    if (a.defaults) args.push('--defaults', JSON.stringify(a.defaults));
    if (a.precondition) args.push('--precondition', JSON.stringify(a.precondition));
    if (a.bulk) args.push('--bulk');
    if (a.workflow) args.push('--workflow', sub(a.workflow));
    if (a.args) args.push('--args', JSON.stringify(a.args));
    if (a.trigger) args.push('--trigger-workflow', sub(a.trigger));
    out('action', Object.assign({ app: id, name: a.name }, pick(canvas(...args), ['ok', 'error', 'raw'])));
  }
}

function brand(id, spec) {
  const args = ['brand', 'set', id, '--preset', spec.preset];
  for (const [k, v] of Object.entries(spec.brand || {})) args.push(`--${k}`, v);
  out('brand', Object.assign({ app: id }, pick(canvas(...args), ['ok', 'error', 'raw'])));
}

if (ONLY.has('desk')) {
  app('scheduling', 'app', ['--name', 'Scheduling', '--icon', '📅', '--desc', 'Meetings people book with you: confirm each request, and the agent prepares every meeting',
    '--user', 'Whoever takes meetings: sales, interviews, demos, consultations',
    '--frequency', 'Once to set it up; then whenever a request arrives, and before each meeting',
    '--question', 'What meetings do I have, and with whom?',
    '--question', 'Which requests are waiting for my OK?',
    '--question', 'Which times do I offer, for which kind of meeting?',
    '--primary-action', 'Confirm a request: it creates the event and Google invites the person']);
  const grants = Object.keys(schema.tables).map((t) => `${t}:${t === 'bk_slots' ? 'read' : 'action'}`);
  // One --grant with every table: the flag is nargs="*", so repeating it keeps only the last.
  const g = canvas('grants', 'set', 'scheduling', '--grant', ...grants);
  out('grants', Object.assign({ app: 'scheduling' }, pick(g, ['ok', 'grants', 'pendingApproval', 'error', 'raw'])));
  if ((g.pendingApproval || []).length) todo.push(`Approve the tables Scheduling asks for: ${g.pendingApproval.map((x) => x.table || x).join(', ')} (Canvas → Scheduling → who gets in)`);
  for (const f of fs.readdirSync(path.join(B, 'sql'))) {
    const r = canvas('view', 'add', 'scheduling', '--name', f.replace(/\.sql$/, ''), '--sql-file', path.join(B, 'sql', f), '--description', f.replace(/\.sql$/, '').replace(/_/g, ' '));
    out('view', Object.assign({ app: 'scheduling', name: f }, pick(r, ['ok', 'reads', 'pending', 'error', 'raw'])));
  }
  actions('scheduling', json('actions.json'));
  brand('scheduling', json('brand.json').scheduling);
  out('brief', pick(canvas('brief', 'set', 'scheduling', '--density', 'balanced', '--variety', 'focused', '--confirmed'), ['ok', 'error', 'raw']));
  todo.push('Publish Scheduling (Canvas → Scheduling → Historial)');
}

const PUBLIC_VIEWS = {
  open_slots: 'The free times of each meeting type that is on: type, start and end. Nothing from the calendar, nobody\'s booking.',
  booking_page: 'The name visitors see, the words on the page, whether bookings are paused, and the meeting types that are on (name, length, where, questions).',
};
if (ONLY.has('public')) {
  app('book', 'public', ['--name', 'Book', '--icon', '📅', '--desc', 'The page where anyone with the link picks a time to meet',
    '--user', 'Anyone with the link: prospects, candidates, clients',
    '--frequency', 'Once, when they book',
    '--question', 'Which times are free, in my own time zone?',
    '--primary-action', 'Pick a time, say who you are, and send the request']);
  for (const [name, description] of Object.entries(PUBLIC_VIEWS)) {
    const r = canvas('view', 'add', 'book', '--name', name, '--access', 'public', '--sql-file', path.join(B, 'public-sql', `${name}.sql`), '--description', description);
    out('view', Object.assign({ app: 'book', name }, pick(r, ['ok', 'pending', 'status', 'error', 'raw'])));
  }
  actions('book', json('public-actions.json'));
  brand('book', json('brand.json').book);
  todo.push('Approve the public lists "open_slots" and "booking_page" for the internet (Canvas → Book → the first tab)');
  todo.push('Set Book to Public, and publish it (Canvas → Book)');
}

// ── 7. where the apps live, for the links the scripts give out ───────────
if (ONLY.has('settings')) {
  const url = (id) => { const u = canvas('url', id).url || ''; return u.endsWith('/') ? u : (u ? `${u}/` : ''); };
  const s = (db('query', 'SELECT _id, prep_agent FROM bk_settings WHERE _deleted = 0 ORDER BY _id LIMIT 1').rows || [])[0];
  if (s) {
    const data = { public_url: url('book'), desk_url: url('scheduling'), installed_version: read('VERSION').trim() };
    if (AGENT && !s.prep_agent) data.prep_agent = AGENT;
    out('settings', Object.assign(data, pick(db('update', 'bk_settings', '--id', String(s._id), '--data', JSON.stringify(data)), ['ok', 'error'])));
  }
  todo.push('Connect Google Calendar for this workspace (portal → Integrations), then check the two Composio argument lists (README, "Before it goes live")');
  todo.push('In Scheduling: set your name and time zone in Settings, then turn on a meeting type in Types');
}

out('done', { project: PROJECT, a_person_still_has_to: todo });
