'use strict';
/**
 * Every word Booking says to Google Calendar, in one place: three Composio
 * actions on the tenant's connected Google account.
 *
 *   GOOGLECALENDAR_FREE_BUSY_QUERY  when the owner is busy (only start/end; never a title)
 *     { timeMin, timeMax, items: [{ id }], timeZone: 'UTC' }
 *     → { calendars: { <id>: { busy: [{ start, end }], errors? } } }  (Google's freeBusy shape)
 *
 *   GOOGLECALENDAR_CREATE_EVENT     the meeting, with the person as a guest; Google sends the invitation
 *     { calendar_id, summary, description, location?, start_datetime: 'YYYY-MM-DDTHH:MM:SS' (wall clock),
 *       timezone, event_duration_hour, event_duration_minutes, attendees: [email],
 *       create_meeting_room (Google Meet), send_updates: "all", guestsCanModify: false }
 *     → { id, htmlLink, hangoutLink?, conferenceData? }  (Google's event, often under response_data)
 *
 *   GOOGLECALENDAR_DELETE_EVENT     a meeting the owner cancelled; Google tells the guest
 *     { calendar_id, event_id, send_updates: "all" }   (the same send_updates as CREATE_EVENT)
 *     → nothing to read; an event Google no longer has (404 / 410 / "deleted") counts as done
 *
 * Composio wraps answers differently between versions, so the reading is
 * forgiving: it looks for the Google shape wherever it is. Check the argument
 * names on a live instance with `orch-composio schema --slug <SLUG>` before
 * turning Booking on (README, "Before it goes live").
 *
 * BOOKING_FAKE_COMPOSIO=1 answers both from BOOKING_FAKE_CALENDAR, a JSON file
 * { busy: [{start, end}], events: [...], fail: { <slug>: 'why' | 'timeout' } }:
 * an event it creates becomes busy time, as in Google.
 */
const fs = require('fs');

const FREE_BUSY = 'GOOGLECALENDAR_FREE_BUSY_QUERY';
const CREATE_EVENT = 'GOOGLECALENDAR_CREATE_EVENT';
const DELETE_EVENT = 'GOOGLECALENDAR_DELETE_EVENT';

/** The first object under `v` (depth-first) that has `key`. */
function find(v, key, depth = 0) {
  if (!v || typeof v !== 'object' || depth > 6) return null;
  if (Object.prototype.hasOwnProperty.call(v, key)) return v;
  for (const k of Object.keys(v)) {
    const hit = find(v[k], key, depth + 1);
    if (hit) return hit;
  }
  return null;
}

/**
 * When the owner is busy between two instants, on every calendar named.
 * { ok, busy: [{ start: Date, end: Date }] } or { ok: false, why }.
 * A calendar Google reports an error for counts as a failure: offering times
 * nobody checked is worse than offering none.
 */
function busy(calendarIds, from, to, composio) {
  const ids = calendarIds.length ? calendarIds : ['primary'];
  const r = composio(FREE_BUSY, { timeMin: from.toISOString(), timeMax: to.toISOString(), items: ids.map((id) => ({ id })), timeZone: 'UTC' });
  if (!r.ok) return { ok: false, why: r.why };
  const holder = find(r.data, 'calendars');
  if (!holder || typeof holder.calendars !== 'object') return { ok: false, why: 'Google Calendar answered without a calendar in it' };
  const out = [];
  for (const id of ids) {
    const c = holder.calendars[id] || (ids.length === 1 ? Object.values(holder.calendars)[0] : null);
    if (!c) return { ok: false, why: `Google Calendar did not answer for the calendar "${id}"` };
    if (Array.isArray(c.errors) && c.errors.length) return { ok: false, why: `Google Calendar could not read "${id}": ${c.errors.map((e) => e.reason || e.message || e).join(', ')}` };
    for (const b of c.busy || []) {
      const start = new Date(b.start);
      const end = new Date(b.end);
      if (!Number.isNaN(start.getTime()) && !Number.isNaN(end.getTime()) && end > start) out.push({ start, end });
    }
  }
  return { ok: true, busy: out };
}

/**
 * The meeting on the owner's calendar with the person invited.
 * { ok, id, link, meet } or { ok: false, why, timedOut }. A timeout means it may exist.
 */
function createEvent(e, composio) {
  const args = {
    calendar_id: e.calendarId || 'primary',
    summary: e.summary,
    description: e.description,
    start_datetime: e.startLocal,
    timezone: e.timezone,
    event_duration_hour: Math.floor(e.durationMin / 60),
    event_duration_minutes: e.durationMin % 60,
    attendees: [e.attendee],
    create_meeting_room: Boolean(e.meet),
    send_updates: 'all',
    guestsCanModify: false,
  };
  if (e.location) args.location = e.location;
  const r = composio(CREATE_EVENT, args);
  if (!r.ok) return { ok: false, why: r.why, timedOut: Boolean(r.timedOut) };
  const ev = find(r.data, 'htmlLink') || find(r.data, 'id');
  if (!ev || !ev.id) return { ok: false, why: 'Google Calendar answered, but without the new event in it', unsure: true };
  const entry = ((ev.conferenceData && ev.conferenceData.entryPoints) || []).find((p) => p.entryPointType === 'video');
  return { ok: true, id: String(ev.id), link: ev.htmlLink || '', meet: ev.hangoutLink || (entry && entry.uri) || '', args };
}

/**
 * Take a cancelled meeting off the owner's calendar, telling the guest
 * (send_updates: all, as when it was created). { ok, gone } or { ok: false, why, timedOut }.
 * An event already gone (the owner deleted it in Google) is done, not a failure.
 */
function cancelEvent(e, composio) {
  const args = { calendar_id: e.calendarId || 'primary', event_id: e.eventId, send_updates: 'all' };
  const r = composio(DELETE_EVENT, args);
  if (r.ok) return { ok: true, args };
  if (/\b(404|410)\b|not ?found|has been deleted|resource.*deleted/i.test(r.why || '')) return { ok: true, gone: true, args };
  return { ok: false, why: r.why, timedOut: Boolean(r.timedOut) };
}

// ── the stand-in, for tests and the local harness ─────────────────────────
function fakeState() {
  const file = process.env.BOOKING_FAKE_CALENDAR;
  if (!file || !fs.existsSync(file)) return { file, s: { busy: [], events: [], fail: {} } };
  return { file, s: Object.assign({ busy: [], events: [], fail: {} }, JSON.parse(fs.readFileSync(file, 'utf8'))) };
}

function fake(slug, args) {
  const { file, s } = fakeState();
  const failing = s.fail && s.fail[slug];
  if (failing === 'timeout') return { ok: false, why: 'Operation timed out after 60000 milliseconds', timedOut: true };
  if (failing) return { ok: false, why: failing };
  if (slug === FREE_BUSY) {
    const from = new Date(args.timeMin);
    const to = new Date(args.timeMax);
    const calendars = {};
    for (const { id } of args.items) {
      calendars[id] = { busy: s.busy.filter((b) => new Date(b.end) > from && new Date(b.start) < to) };
    }
    return { ok: true, data: { response_data: { kind: 'calendar#freeBusy', timeMin: args.timeMin, timeMax: args.timeMax, calendars } } };
  }
  if (slug === CREATE_EVENT) {
    const id = `fake-${s.events.length + 1}`;
    const ev = { id, htmlLink: `https://calendar.google.com/event?eid=${id}`, args };
    if (args.create_meeting_room) ev.hangoutLink = `https://meet.google.com/fak-e${s.events.length + 1}`;
    s.events.push(ev);
    // The event is busy time from now on, as in Google: its UTC span from the wall clock and zone.
    const L = require('./lib');
    const [day, time] = args.start_datetime.split('T');
    const start = L.localToUtc(day, time.slice(0, 5), args.timezone);
    const end = new Date(start.getTime() + ((args.event_duration_hour * 60) + args.event_duration_minutes) * 60000);
    s.busy.push({ start: start.toISOString(), end: end.toISOString() });
    if (file) fs.writeFileSync(file, JSON.stringify(s, null, 1));
    return { ok: true, data: { response_data: ev } };
  }
  if (slug === DELETE_EVENT) {
    const ev = s.events.find((x) => x.id === args.event_id && !x.deleted);
    if (!ev) return { ok: false, why: 'Not Found (404)' };
    ev.deleted = { args };
    // Its time is free again, as in Google.
    const L = require('./lib');
    const [day, time] = ev.args.start_datetime.split('T');
    const start = L.localToUtc(day, time.slice(0, 5), ev.args.timezone).toISOString();
    s.busy = s.busy.filter((b) => b.start !== start);
    if (file) fs.writeFileSync(file, JSON.stringify(s, null, 1));
    return { ok: true, data: { response_data: {} } };
  }
  return { ok: false, why: `the fake calendar has no ${slug}` };
}

module.exports = { FREE_BUSY, CREATE_EVENT, DELETE_EVENT, busy, createEvent, cancelEvent, fake, find };
