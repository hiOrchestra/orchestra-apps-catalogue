'use strict';
/**
 * Booking · Confirm. The one place anything leaves: for each request the
 * owner confirmed (Confirm on the desk, or auto-confirm when it is on), the
 * meeting goes on the owner's Google Calendar with the person as a guest, and
 * Google sends them the invitation (with a Meet link when the type says so).
 *
 *   1. claim it: Requested → Confirming, atomic (a `when`), so two runs never
 *      create two events;
 *   2. look again: the time has not passed, no other booking holds it, and the
 *      calendar is still free then (free/busy, buffer included);
 *   3. create the event; Confirmed with its id and links, or Failed with what
 *      happened. Never retried on its own: a timeout may have created it.
 *
 * A Confirming left by a run that died is turned into Failed after 10 minutes,
 * saying to look in the calendar first. After a confirmation the agent's
 * meeting brief is asked for (prep.js), when an agent is set.
 *
 * Cancelling goes out here too. Cancel on the desk marks the booking Cancelled
 * (the time is free at once) with `cancel_status` Pending; this run claims it
 * (Pending → Working), deletes the event with send_updates: all, so Google
 * tells the guest, and leaves Done, or Failed with why and Try again on the
 * desk. A Working left by a dead run is Failed after 10 minutes, saying to
 * look in the calendar first.
 *   node confirm.js [--auto|--now] [--dry-run]
 */
const fs = require('fs');
const path = require('path');
const L = require('./lib');
const C = require('./calendar');

const STUCK_MS = 10 * 60000;
const LIMIT = 20;
const WHERE = { meet: 'Google Meet (the link is in the invitation)', phone: 'Phone call', place: 'In person' };

function description(b, type, s) {
  const answers = L.jsonOf(b.answers, {});
  const asked = L.jsonOf(type && type.questions, []);
  const lines = [];
  if (type && type.description) lines.push(type.description, '');
  if (type && type.location_kind === 'phone' && answers.phone) lines.push(`We will call ${b.name} on ${answers.phone}.`, '');
  if (type && type.location_kind === 'place' && type.location_detail) lines.push(`Where: ${type.location_detail}`, '');
  for (const q of Array.isArray(asked) ? asked : []) if (answers[q.ref]) lines.push(`${q.label}`, `${answers[q.ref]}`, '');
  lines.push(`Booked by ${b.name} <${b.email}>${s.public_url ? ` at ${s.public_url}` : ''}.`);
  return lines.join('\n').slice(0, 7000);
}

function locationOf(b, type) {
  const answers = L.jsonOf(b.answers, {});
  if (!type) return '';
  if (type.location_kind === 'place') return String(type.location_detail || '').slice(0, 300);
  if (type.location_kind === 'phone') return answers.phone ? `Phone: ${answers.phone}` : WHERE.phone;
  return '';
}

/** Why this booking cannot be confirmed now, or null. */
function obstacle(b, s, now) {
  const start = L.toDate(b.start_at);
  const end = L.toDate(b.end_at);
  if (!start || !end) return 'The booking has no time';
  if (start <= now) return 'That time has passed';
  const other = L.one("SELECT _id FROM bk_bookings WHERE _deleted = 0 AND _id <> ? AND status IN ('Confirming', 'Confirmed') AND start_at < ? AND end_at > ? LIMIT 1",
    b._id, b.end_at, b.start_at);
  if (other) return `Another booking holds that time (#${other._id}). Nothing was sent`;
  const pad = (Number(s.buffer_min) || 0) * 60000;
  const g = C.busy(String(s.calendar_id || 'primary').split(/[\s,]+/).filter(Boolean), new Date(start.getTime() - pad), new Date(end.getTime() + pad), L.composio);
  if (!g.ok) return `Could not read Google Calendar to check the time (${g.why}). Nothing was sent`;
  if (g.busy.length) return 'Your calendar has something else at that time now. Nothing was sent';
  return null;
}

function confirmOne(b, s, now, dryRun) {
  const type = L.one('SELECT * FROM bk_types WHERE _id = ?', b.type_id);
  if (dryRun) return { id: b._id, would: obstacle(b, s, now) || 'create the event' };
  try {
    L.write([{ op: 'update', table: 'bk_bookings', id: b._id, when: { status: 'Requested' }, data: { status: 'Confirming' } }]);
  } catch (e) {
    return { id: b._id, lost: true };
  }
  const fail = (reason) => {
    L.write([{ op: 'update', table: 'bk_bookings', id: b._id, when: { status: 'Confirming' }, data: { status: 'Failed', reason: reason.slice(0, 500) } }]);
    return { id: b._id, failed: reason };
  };
  const stop = obstacle(b, s, now);
  if (stop) return fail(stop);
  const tz = L.validZone(s.timezone || 'UTC');
  const dur = Math.round((L.toDate(b.end_at) - L.toDate(b.start_at)) / 60000);
  const host = String(s.display_name || '').trim();
  const r = C.createEvent({
    calendarId: String(s.calendar_id || 'primary').split(/[\s,]+/)[0] || 'primary',
    summary: `${b.type_name || (type && type.name) || 'Meeting'}: ${b.name}${host ? ` and ${host}` : ''}`.slice(0, 200),
    description: description(b, type, s),
    startLocal: L.localNaive(L.toDate(b.start_at), tz),
    timezone: tz,
    durationMin: dur,
    attendee: b.email,
    meet: !type || type.location_kind === 'meet',
    location: locationOf(b, type),
  }, L.composio);
  if (!r.ok) {
    return fail(r.timedOut || r.unsure
      ? `Google did not answer in time, so the event may have been created. Look in your calendar before trying again (${r.why})`
      : `Google Calendar did not create it: ${r.why}. Nothing was sent`);
  }
  L.write([{ op: 'update', table: 'bk_bookings', id: b._id, when: { status: 'Confirming' }, data: {
    status: 'Confirmed', reason: null, confirmed_at: L.isoZ(now), calendar_event_id: r.id, event_link: r.link, meet_link: r.meet,
    prep_status: s.prep_agent ? 'Waiting' : 'Off',
  } }]);
  return { id: b._id, confirmed: r.id, line: `${b.name}, ${b.type_name}, ${L.said(b.start_at, s.timezone)}` };
}

function calendarOf(s) { return String(s.calendar_id || 'primary').split(/[\s,]+/)[0] || 'primary'; }

/** A meeting the owner cancelled: its event off the calendar, and Google tells the guest. */
function cancelOne(b, s, dryRun) {
  if (dryRun) return { id: b._id, would: b.calendar_event_id ? `delete the event ${b.calendar_event_id}` : 'nothing: no event' };
  try {
    L.write([{ op: 'update', table: 'bk_bookings', id: b._id, when: { status: 'Cancelled', cancel_status: 'Pending' }, data: { cancel_status: 'Working' } }]);
  } catch (e) {
    return { id: b._id, lost: true };
  }
  const finish = (data) => L.write([{ op: 'update', table: 'bk_bookings', id: b._id, when: { cancel_status: 'Working' }, data }]);
  if (!b.calendar_event_id) {
    finish({ cancel_status: 'Done', cancel_note: 'There was no event in Google Calendar to cancel' });
    return { id: b._id, cancelled: 'no event' };
  }
  const r = C.cancelEvent({ calendarId: calendarOf(s), eventId: b.calendar_event_id }, L.composio);
  if (!r.ok) {
    const why = r.timedOut
      ? `Google did not answer in time, so the event may already be cancelled. Look in your calendar before trying again (${r.why})`
      : `Google Calendar did not cancel it: ${r.why}. ${b.name} was not told`;
    finish({ cancel_status: 'Failed', cancel_note: why.slice(0, 500) });
    return { id: b._id, cancelFailed: why };
  }
  finish({ cancel_status: 'Done', cancel_note: r.gone ? 'The event was already gone from Google Calendar' : null, event_link: null, meet_link: null });
  return { id: b._id, cancelled: b.calendar_event_id, line: `${b.name}, ${b.type_name}, ${L.said(b.start_at, s.timezone)}` };
}

/** Confirming rows a dead run left behind: Failed, and never retried blind. */
function unstick(now) {
  const cut = L.sqlNow(new Date(now.getTime() - STUCK_MS));
  const rows = L.all("SELECT _id FROM bk_bookings WHERE _deleted = 0 AND status = 'Confirming' AND _updated_at < ?", cut);
  let n = 0;
  for (const r of rows) {
    try {
      L.write([{ op: 'update', table: 'bk_bookings', id: r._id, when: { status: 'Confirming' }, data: { status: 'Failed',
        reason: 'It stopped halfway while creating the event. Look in your calendar before trying again: the invitation may have gone out' } }]);
      n += 1;
    } catch { /* moved on meanwhile */ }
  }
  for (const r of L.all("SELECT _id FROM bk_bookings WHERE _deleted = 0 AND status = 'Cancelled' AND cancel_status = 'Working' AND _updated_at < ?", cut)) {
    try {
      L.write([{ op: 'update', table: 'bk_bookings', id: r._id, when: { cancel_status: 'Working' }, data: { cancel_status: 'Failed',
        cancel_note: 'It stopped halfway while cancelling the event. Look in your calendar before trying again: the guest may have been told' } }]);
      n += 1;
    } catch { /* moved on meanwhile */ }
  }
  return n;
}

/** Ask for the agent's brief now; the half-hourly check does it otherwise. */
function startPrep() {
  if (L.LOCAL) return { started: false, why: 'local run' };
  let ids = {};
  try { ids = JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'workflows.json'), 'utf8')); } catch { /* not installed by install.js */ }
  if (!ids.prep) return { started: false, why: 'the prep workflow id is not known; the half-hourly check will start it' };
  const r = L.post(`/api/platform/workflows/${encodeURIComponent(ids.prep)}/run`, { argsJson: '{"mode":"--auto"}', execute: true });
  return r.ok ? { started: true } : { started: false, why: r.why };
}

function run({ mode = '--auto', dryRun = false } = {}) {
  const s = L.settings();
  const now = L.now();
  const held = dryRun ? { release() {} } : L.lock('confirm');
  if (!held) return { ok: true, mode, skipped: 'Another run is confirming' };
  const done = [];
  let stuck = 0;
  try {
    stuck = dryRun ? 0 : unstick(now);
    const asked = L.all(`SELECT * FROM bk_bookings WHERE _deleted = 0 AND status = 'Requested' AND COALESCE(confirm_asked_at, '') <> '' ORDER BY start_at LIMIT ${LIMIT}`);
    for (const b of asked) done.push(confirmOne(b, s, now, dryRun));
    const cancels = L.all(`SELECT * FROM bk_bookings WHERE _deleted = 0 AND status = 'Cancelled' AND cancel_status = 'Pending' ORDER BY _id LIMIT ${LIMIT}`);
    for (const b of cancels) done.push(cancelOne(b, s, dryRun));
  } finally {
    held.release();
  }
  const confirmed = done.filter((d) => d.confirmed);
  const failed = done.filter((d) => d.failed);
  const cancelled = done.filter((d) => d.cancelled);
  const cancelFailed = done.filter((d) => d.cancelFailed);
  const out = { ok: true, mode, confirmed: confirmed.length, failed: failed.length, cancelled: cancelled.length, cancelFailed: cancelFailed.length,
    lost: done.filter((d) => d.lost).length, stuck };
  if (dryRun) return Object.assign(out, { dryRun: true, would: done });
  if (confirmed.length && s.prep_agent) out.prep = startPrep();
  // The owner pressed Cancel and sees it on the desk; only a cancel that failed is worth a notice.
  if (confirmed.length || failed.length || stuck || cancelFailed.length) {
    const lines = ['Booking'];
    if (confirmed.length) lines.push('Confirmed, and Google sent the invitation:', ...confirmed.map((d) => `· ${d.line}`));
    if (failed.length || stuck) lines.push(`${failed.length + stuck} could not be confirmed (or cancelled): open them to see why and what to do.`);
    if (cancelFailed.length) lines.push(`${cancelFailed.length} cancelled here, but the event is still in Google Calendar: open them to try again.`);
    if (s.desk_url) lines.push(`${s.desk_url}#/${failed.length || stuck ? 'requests/failed' : ''}`);
    out.notified = L.telegram(s.notify_telegram, lines.join('\n'));
  }
  return out;
}

if (require.main === module) {
  const argv = process.argv.slice(2);
  const mode = ['--auto', '--now'].find((m) => argv.includes(m)) || '--auto';
  try { L.done(run({ mode, dryRun: argv.includes('--dry-run') })); } catch (e) { L.done({ ok: false, error: e.message }); process.exitCode = 1; }
}

module.exports = { run, obstacle, description };
