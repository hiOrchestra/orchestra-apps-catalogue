// One booking, in a panel: who, when (here and for them), what they wrote,
// the agent's brief, and what can be done with it now. Every state that needs
// a person has its way out here: a request is confirmed or declined; a failed
// one is tried again, moved to another free time, written to, or dismissed.
import { T, A, act, badge, parse, span, theirs, hour, dayName, sheet, settings, LOCATIONS } from '../data.js';
import { linked } from '../links.js';

const { el } = Orch;

export async function openBooking(id, again) {
  const b = await Orch.db.get(T.bookings, id);
  if (!b) { Orch.toast('That booking is not there any more.', { error: true }); return; }
  const [type, s] = await Promise.all([b.type_id ? Orch.db.get(T.types, b.type_id) : null, settings()]);
  let d = null;
  const after = () => { if (d) d.close(); if (again) again(); };
  d = sheet(panel(b, type || {}, s, after), { title: b.name || 'Booking', drawer: true });
}

function panel(b, type, s, after) {
  const answers = parse(b.answers, {});
  const asked = parse(type.questions, []);
  const rows = (Array.isArray(asked) ? asked : []).filter((q) => answers[q.ref]).map((q) => el('div', { class: 'bk-qa' }, [el('dt', q.label), el('dd', linked(answers[q.ref]))]));
  if (answers.phone) rows.unshift(el('div', { class: 'bk-qa' }, [el('dt', 'Phone'), el('dd', answers.phone)]));
  const them = theirs(b);
  return el('div', { class: 'oc-stack oc-stack--loose bk-panel' }, [
    el('div', { class: 'oc-stack oc-stack--tight' }, [
      el('div', { class: 'oc-row' }, [badge(b.status), el('span', { class: 'oc-eyebrow' }, b.type_name || type.name || '')]),
      el('p', { class: 'oc-value bk-panel__when' }, b.start_at ? span(b.start_at, b.end_at) : 'No time'),
      them ? el('p', { class: 'oc-help' }, them) : null,
      el('p', {}, el('a', { href: `mailto:${b.email}` }, b.email)),
    ]),
    reasonOf(b),
    calendarOf(b),
    rows.length ? el('dl', { class: 'bk-qas' }, rows) : null,
    links(b, type),
    b.status === 'Confirmed' ? brief(b, s, after) : null,
    el('div', { class: 'oc-row bk-panel__actions' }, actions(b, type, s, after)),
  ]);
}

const WHY = {
  Failed: 'This person asked for a time that could not be given, or the event could not be created. Nothing reached them from here.',
  Discarded: 'Set aside as not a real request. It holds no time.',
};
function reasonOf(b) {
  if (!['Failed', 'Discarded', 'Declined', 'Cancelled'].includes(b.status) || !b.reason) return null;
  return el('div', { class: `bk-notice${b.status === 'Failed' ? ' bk-notice--bad' : ''}` }, [
    WHY[b.status] ? el('p', WHY[b.status]) : null, el('p', { class: 'oc-value' }, b.reason)]);
}

/** What happened to a cancelled meeting's event (bookings cancelled before 0.2.4 have no cancel_status). */
function calendarOf(b) {
  if (b.status !== 'Cancelled' || !b.cancel_status) return null;
  const said = {
    Pending: 'Removing the event from your Google Calendar: Google tells them in a moment.',
    Working: 'Removing the event from your Google Calendar: Google tells them in a moment.',
    Done: b.cancel_note || `Removed from your Google Calendar: Google told ${b.name} it is cancelled.`,
    Failed: b.cancel_note || 'The event could not be removed from Google Calendar.',
  }[b.cancel_status];
  return said ? el('div', { class: `bk-notice${b.cancel_status === 'Failed' ? ' bk-notice--bad' : ''}` }, el('p', said)) : null;
}

function links(b, type) {
  const items = [];
  if (b.meet_link) items.push(el('a', { class: 'oc-btn oc-btn--sm', href: b.meet_link, target: '_blank', rel: 'noopener' }, 'Join Meet'));
  if (b.event_link) items.push(el('a', { class: 'oc-btn oc-btn--sm oc-btn--ghost', href: b.event_link, target: '_blank', rel: 'noopener' }, 'Open in Google Calendar'));
  const where = type.location_kind === 'place' && type.location_detail ? `In person: ${type.location_detail}` : LOCATIONS[type.location_kind] || '';
  return el('div', { class: 'oc-stack oc-stack--tight' }, [where ? el('p', { class: 'oc-help' }, where) : null, items.length ? el('div', { class: 'oc-row' }, items) : null]);
}

function brief(b, s, after) {
  const p = parse(b.prep, null);
  const again = el('button', { type: 'button', class: 'oc-btn oc-btn--sm', onClick: async () => { if (await act(A.prepAgain, { id: b._id }, 'The agent will prepare it again.')) after(); } }, 'Prepare again');
  const state = { Waiting: 'The agent will prepare a brief shortly.', Working: 'The agent is preparing the brief.', Off: 'No agent prepares briefs: name one in Settings.',
    Failed: `The brief could not be made: ${b.prep_note || 'no reason given'}.` }[b.prep_status] || '';
  const head = el('div', { class: 'oc-row oc-row--between' }, [el('h2', { class: 'oc-h2' }, 'Brief'), b.prep_status === 'Off' && !s.prep_agent ? null : again]);
  if (!p) return el('section', { class: 'bk-brief' }, [head, el('p', { class: 'oc-help' }, state)]);
  const list = (label, items) => (items && items.length ? el('div', {}, [el('p', { class: 'oc-eyebrow' }, label), el('ul', { class: 'bk-list' }, items.map((x) => el('li', x)))]) : null);
  const who = [p.person && p.person.role, p.company && p.company.name].filter(Boolean).join(' · ');
  return el('section', { class: 'bk-brief oc-stack' }, [
    head,
    b.prep_status !== 'Done' && state ? el('p', { class: 'oc-help' }, state) : null,
    who ? el('p', { class: 'oc-eyebrow' }, who) : null,
    el('p', {}, p.summary),
    p.company && p.company.what_they_do ? el('p', { class: 'oc-help' }, p.company.what_they_do) : null,
    list('Before', p.history), list('What they want', p.wants), list('To ask', p.questions),
    p.sources && p.sources.length ? el('p', { class: 'oc-help bk-sources' }, ['Sources: ', ...p.sources.flatMap((u, i) => [i ? ' · ' : '', el('a', { href: u, target: '_blank', rel: 'noopener' }, u.replace(/^https?:\/\/(www\.)?/, '').slice(0, 40))])]) : null,
    el('p', { class: 'oc-eyebrow' }, `Confidence: ${p.confidence || 'low'}`),
  ]);
}

function button(label, run, kind = '') {
  return el('button', { type: 'button', class: `oc-btn${kind ? ` oc-btn--${kind}` : ''}`, onClick: run }, label);
}

function actions(b, type, s, after) {
  const id = b._id;
  const ask = async (name, params, msg, yes, done, danger, no) => {
    if (msg && !(await Orch.confirm(msg, { yes, danger, no }))) return;
    if (await act(name, Object.assign({ id }, params), done)) after();
  };
  if (b.status === 'Requested') {
    return [
      button('Confirm and invite', () => ask(A.confirm, {}, `This creates the event on your Google Calendar and Google sends ${b.name} the invitation${b.meet_link || type.location_kind === 'meet' ? ', with a Meet link' : ''}.`, 'Confirm and invite', 'Confirming: the invitation goes out in a moment.'), 'primary'),
      button('Decline', () => ask(A.decline, { reason: 'Declined by hand' }, `Decline ${b.name}'s request? Nothing is sent to them: write to them yourself if you want them to know.`, 'Decline', 'Declined. The time is free again.', true), 'ghost'),
    ];
  }
  if (b.status === 'Failed') {
    return [
      button('Try again', () => ask(A.retry, {}, `Try to create the event again? If it works, Google sends ${b.name} the invitation. If the reason says it may already exist, look in your calendar first.`, 'Try again', 'Trying again.')),
      button('Invite at another time', () => moveTo(b, after)),
      el('a', { class: 'oc-btn', href: mailto(b, s) }, 'Write to them'),
      button('Dismiss', () => ask(A.dismiss, { reason: b.reason || 'Dismissed' }, 'Dismiss it? Nothing is sent: it moves to Done.', 'Dismiss', 'Dismissed.'), 'ghost'),
    ];
  }
  if (b.status === 'Confirmed') {
    return [button('Cancel the meeting', () => ask(A.cancel, { reason: 'Cancelled by hand' },
      `Cancel the meeting with ${b.name}? The event is deleted from your Google Calendar and Google tells ${b.name} it is cancelled. The time is free again.`,
      'Cancel the meeting', 'Cancelled: Google tells them in a moment.', true, 'Keep it'), 'danger')];
  }
  if (b.status === 'Cancelled' && b.cancel_status === 'Failed') {
    return [button('Try again', () => ask(A.retryCancel, {}, `Try to delete the event again? If it works, Google tells ${b.name} it is cancelled. If the reason says it may already be gone, look in your calendar first.`,
      'Try again', 'Trying again.'))];
  }
  if (b.status === 'New') return [el('p', { class: 'oc-help' }, 'Just arrived: it is checked within seconds.'), button('Check now', async () => { if (await act(A.processNow, {}, 'Checking.')) setTimeout(after, 2500); })];
  if (b.status === 'Confirming') return [el('p', { class: 'oc-help' }, 'Creating the event in Google Calendar…')];
  return [];
}

/** A message the owner sends from their own mail: the app never writes to strangers. */
function mailto(b, s) {
  const subject = `Your ${b.type_name || 'meeting'} request`;
  const body = `Hi ${String(b.name || '').split(' ')[0]},\n\nThe time you picked (${span(b.start_at, b.end_at)}) is no longer free. Could you pick another one here?\n${s.public_url || ''}\n\nThanks`;
  return `mailto:${encodeURIComponent(b.email)}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
}

/** The free times of the same type, to invite the person at one of them. */
async function moveTo(b, after) {
  const r = await Orch.db.list(T.slots, { filter: { type_id: b.type_id, start_at: { gt: new Date().toISOString().slice(0, 19) } }, sort: 'start_at:asc', limit: 40 });
  const free = r.rows || [];
  if (!free.length) { Orch.toast('No free time is offered for this type now.', { error: true }); return; }
  const pick = el('select', { class: 'oc-select' }, free.map((x) => el('option', { value: x._id }, `${dayName(x.start_at)}, ${hour(x.start_at)}`)));
  const go = el('button', { type: 'button', class: 'oc-btn oc-btn--primary' }, 'Invite at this time');
  const d = sheet(el('div', { class: 'oc-stack' }, [
    el('label', { class: 'oc-field' }, [el('span', { class: 'oc-label' }, 'Free times (yours)'), pick]),
    el('p', { class: 'oc-help' }, `This creates the event at that time and Google sends ${b.name} the invitation. They can accept or decline it there.`),
    el('div', { class: 'oc-row' }, go),
  ]), { title: 'Invite at another time' });
  go.addEventListener('click', async () => {
    const x = free.find((f) => String(f._id) === pick.value);
    go.disabled = true;
    if (await act(A.move, { id: b._id, start_at: x.start_at, end_at: x.end_at }, 'Inviting them at the new time.')) { d.close(); after(); } else go.disabled = false;
  });
}
