// Web addresses in what the app shows open in a new tab instead of being
// copied and pasted: a value that is an address ("acme.com",
// "https://linkedin.com/in/x") becomes a link, and text with addresses in it
// (notes, answers) gets those linked. Only http(s); anything else stays text.
// The same file is in each app that shows people's data (outreach, crm, forms,
// booking): apps are installed on their own.

const FILES = /\.(pdf|docx?|xlsx?|pptx?|csv|txt|png|jpe?g|gif|zip|json|md)$/i;
const BARE = /^(?:[a-z0-9-]+\.)+[a-z]{2,}(?::\d+)?(?:[/?#][^\s]*)?$/i;
const IN_TEXT = /(?:https?:\/\/|www\.)[^\s<>"']+|\b(?:[a-z0-9-]+\.)+[a-z]{2,}\/[^\s<>"']*/gi;

function safe(s) {
  try {
    const u = new URL(s);
    return u.protocol === 'http:' || u.protocol === 'https:' ? u.href : null;
  } catch { return null; }
}

/** The address a value points to, or null when it is not one. */
export function hrefOf(value) {
  const s = String(value ?? '').trim();
  if (!s || /\s/.test(s)) return null;
  if (/^https?:\/\//i.test(s)) return safe(s);
  if (s.includes('@')) return null; // an email address
  if (/^www\./i.test(s) || (BARE.test(s) && !FILES.test(s.split(/[?#]/)[0]))) return safe(`https://${s}`);
  return null;
}

/** A link that opens in a new tab. */
export function link(href, text) {
  return Orch.el('a', { href, target: '_blank', rel: 'noopener noreferrer' }, text);
}

/** A value as it is shown: an address is a link; text keeps its words and links its addresses. */
export function linked(value) {
  if (value === null || value === undefined || typeof value !== 'string' && typeof value !== 'number') return value;
  const s = String(value);
  const whole = hrefOf(s);
  if (whole) return link(whole, s.trim());
  const out = [];
  let at = 0;
  for (const m of s.matchAll(IN_TEXT)) {
    let text = m[0];
    const trail = /[.,;:!?)\]]+$/.exec(text);
    if (trail) text = text.slice(0, -trail[0].length);
    const href = hrefOf(text);
    if (!href) continue;
    if (m.index > at) out.push(s.slice(at, m.index));
    out.push(link(href, text));
    at = m.index + text.length;
  }
  if (!out.length) return s;
  if (at < s.length) out.push(s.slice(at));
  return out;
}
