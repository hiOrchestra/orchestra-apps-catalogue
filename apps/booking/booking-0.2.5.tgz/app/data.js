// What Scheduling reads, the only things it writes, and what the screens
// share. Free times are worked out on the instance (automations/slots.js)
// into bk_slots; confirming creates the Google Calendar event there too
// (confirm.js). Every write here is a declared action (A).
const { el, router } = Orch;

export const T = { settings: 'bk_settings', types: 'bk_types', slots: 'bk_slots', bookings: 'bk_bookings' };
export const V = { types: 'types_list' };
export const A = {
  confirm: 'confirm_booking', decline: 'decline_booking', retry: 'retry_booking', move: 'move_booking', dismiss: 'dismiss_booking',
  cancel: 'cancel_booking', retryCancel: 'retry_cancel', prepAgain: 'prepare_again', createType: 'create_type', updateType: 'update_type',
  typeOn: 'turn_on_type', typeOff: 'turn_off_type', settings: 'update_settings', pause: 'pause_bookings', resume: 'resume_bookings',
  rebuild: 'rebuild_slots', processNow: 'process_now', startType: 'start_type', dismissStart: 'dismiss_onboarding',
};

/** Where Google Calendar is connected: the portal's Integrations, in the top window (the desk runs in a frame or its own tab). */
// The app is served from the instance, not the portal, so a relative link would
// 404. The portal is where the person came from (the referrer when it opened
// the app); otherwise Orchestra's own address.
const PORTAL_ORIGIN = (() => {
  try {
    const o = document.referrer ? new URL(document.referrer).origin : '';
    if (/^https:\/\/([a-z0-9-]+\.)*(hiorchestra\.com|orchestra-portal[a-z0-9-]*\.up\.railway\.app)$/.test(o)) return o;
  } catch { /* no referrer */ }
  return 'https://hiorchestra.com';
})();
export const INTEGRATIONS = `${PORTAL_ORIGIN}/portal/integrations`;

/** This browser's time zone, the default for a first setup. */
export const browserZone = () => { try { return Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC'; } catch { return 'UTC'; } };
export const ZONES = ['Europe/Madrid', 'Europe/London', 'Europe/Lisbon', 'Europe/Paris', 'Europe/Berlin', 'America/New_York', 'America/Chicago', 'America/Denver',
  'America/Los_Angeles', 'America/Mexico_City', 'America/Bogota', 'America/Lima', 'America/Santiago', 'America/Argentina/Buenos_Aires', 'America/Sao_Paulo',
  'Asia/Dubai', 'Asia/Kolkata', 'Asia/Singapore', 'Asia/Tokyo', 'Australia/Sydney', 'UTC'];
/** A time zone select: the chosen zone and this browser's first, then the usual ones. */
export function zoneSelect(chosen) {
  return el('select', { class: 'oc-select' }, [...new Set([chosen || browserZone(), browserZone(), ...ZONES])].map((z) => el('option', { value: z, selected: z === chosen }, z)));
}

/** Run a declared action, say how it went, and hand back its result (null on failure). */
export async function act(name, params, done) {
  try {
    const r = await Orch.action(name, params);
    if (done) Orch.toast(done);
    return r || {};
  } catch (e) {
    Orch.toast(e.status === 409 ? 'It changed in the meantime: look again.' : (e.message || 'That did not work.'), { error: true });
    return null;
  }
}

/** The one settings row. */
export async function settings() {
  return (await Orch.db.list(T.settings, { sort: '_id:asc', limit: 1 })).rows[0] || {};
}

export function parse(text, fallback) {
  if (!text) return fallback;
  if (typeof text === 'object') return text;
  try { return JSON.parse(text); } catch { return fallback; }
}

/** '2026-10-03 10:00:00' (UTC, as rows are stamped) or ISO, as a Date. */
export function when(v) {
  if (!v) return null;
  const s = String(v).trim();
  const d = new Date(/[zZ]|[+-]\d\d:?\d\d$/.test(s) ? s : `${s.replace(' ', 'T')}Z`);
  return Number.isNaN(d.getTime()) ? null : d;
}
const fmt = (v, o) => { const d = when(v); return d ? new Intl.DateTimeFormat(undefined, o).format(d) : '—'; };
/** "10:00", in the reader's own time. */
export const hour = (v) => fmt(v, { hour: '2-digit', minute: '2-digit' });
/** "Fri 23 Oct". */
export const dayName = (v) => fmt(v, { weekday: 'short', day: 'numeric', month: 'short' });
/** "Fri 23 Oct, 10:00–10:30". */
export const span = (a, b) => `${dayName(a)}, ${hour(a)}–${hour(b)}`;
/** The day key a time falls on, here. */
export const dayKey = (v) => { const d = when(v); return d ? `${d.getFullYear()}-${d.getMonth()}-${d.getDate()}` : ''; };
/** That time where the person who booked is, when it is not here. */
export function theirs(b) {
  const mine = Intl.DateTimeFormat().resolvedOptions().timeZone;
  if (!b.tz || b.tz === mine) return '';
  try { return `${new Intl.DateTimeFormat(undefined, { timeZone: b.tz, weekday: 'short', hour: '2-digit', minute: '2-digit' }).format(when(b.start_at))} for them (${b.tz})`; } catch { return ''; }
}
export const nowIso = () => `${new Date().toISOString().slice(0, 19)}Z`;

const TONE = { Requested: 'warn', Confirming: 'warn', Confirmed: 'good', Failed: 'bad' };
const SAID = { New: 'Arriving', Confirming: 'Confirming…' };
export const badge = (status) => el('span', { class: `oc-badge${TONE[status] ? ` oc-badge--${TONE[status]}` : ''}` }, SAID[status] || status || '—');

export const LOCATIONS = { meet: 'Google Meet', phone: 'Phone call', place: 'In person', none: 'Agreed later' };

/** The public booking page of this instance; Settings may name another. */
export function publicLink(s, slug) {
  const own = `${location.origin}${location.pathname.replace(/\/canvas\/a\/[^/]+\/?.*$/, '/canvas/a/book/')}`;
  const base = (s && s.public_url) || own;
  return slug ? `${base}#/${slug}` : base;
}

export async function copy(text, said) {
  try { await navigator.clipboard.writeText(text); Orch.toast(said || 'Copied.'); } catch { Orch.toast('Select the link and copy it.', { error: true }); }
}

/** A dialog that closes when the screen changes: a link inside it must not leave it over the next screen. */
export function sheet(content, opts) {
  const d = Orch.dialog(content, opts);
  window.addEventListener('hashchange', () => { try { d.close(); } catch { /* already closed */ } }, { once: true });
  return d;
}

/** A screen's head: its title, a sentence, and tools on the right. */
export const head = (title, lede, tools) => el('header', { class: 'bk-head' }, [
  el('div', { class: 'bk-head__title' }, [el('h1', { class: 'oc-h1 oc-h1--collection' }, title), lede ? el('p', { class: 'oc-lede' }, lede) : null]),
  tools ? el('div', { class: 'bk-head__tools' }, tools) : null,
]);

/** What the owner should know before anything else: paused, Google not connected or unreadable, nothing on. */
export function notices(s, extra = [], { panel = false } = {}) {
  const out = [];
  if (s.paused === 'yes') out.push(el('div', { class: 'bk-notice bk-notice--warn' }, ['Bookings are paused: the page offers no times. ', router.link('/settings', 'Resume them in Settings')]));
  if (s.calendar_status === 'not_connected') { if (!panel) out.push(el('div', { class: 'bk-notice bk-notice--bad' }, ['Google Calendar is not connected, so no times can be offered. ', el('a', { href: INTEGRATIONS, target: '_top' }, 'Connect it in Orchestra → Integrations')])); }
  else if (String(s.slots_note || '').startsWith('Could not')) out.push(el('div', { class: 'bk-notice bk-notice--bad' }, [s.slots_note, ' ', router.link('/settings', 'See Settings')]));
  return [...out, ...extra];
}
