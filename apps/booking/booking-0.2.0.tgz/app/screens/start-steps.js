// The action of each Getting started step (start.js draws the list): the name
// and time zone, Google Calendar, the weekly hours of the first type, and the
// link to share. Each gets the settings row, what start.js loaded, a way to
// draw the screen again, and its step.
import { A, INTEGRATIONS, act, browserZone, copy, parse, publicLink, when, zoneSelect } from '../data.js';
import { hoursEditor } from './type-edit.js';

const { el, router, fmt } = Orch;

const field = (label, control, help) => el('label', { class: 'oc-field' }, [el('span', { class: 'oc-label' }, label), control, help ? el('span', { class: 'oc-help' }, help) : null]);

export const BODY = {
  profile(s, _d, again) {
    const first = !String(s.display_name || '').trim();
    const name = el('input', { class: 'oc-input', value: s.display_name || '', maxlength: '80', placeholder: 'Your name or your company' });
    // On a first setup the zone of this browser is the better guess than the installer's default.
    const zone = zoneSelect(first ? browserZone() : (s.timezone || browserZone()));
    const save = el('button', { type: 'submit', class: 'oc-btn oc-btn--primary' }, 'Save');
    const f = el('form', { class: 'oc-stack bk-start__form' }, [
      el('div', { class: 'bk-two' }, [field('Name visitors see', name), field('Time zone', zone, 'Visitors still see times in their own.')]),
      el('div', { class: 'oc-row' }, save),
    ]);
    f.addEventListener('submit', async (e) => {
      e.preventDefault();
      if (!name.value.trim()) { Orch.toast('Write the name visitors should see.', { error: true }); name.focus(); return; }
      save.disabled = true;
      const r = await act(A.settings, { id: s._id, display_name: name.value.trim(), timezone: zone.value }, 'Saved.');
      save.disabled = false;
      if (r) again();
    });
    return f;
  },

  calendar(s, _d, again, x) {
    const checked = when(s.calendar_checked_at);
    const said = {
      ok: 'Connected: Google Calendar answered the last time it was asked.',
      not_connected: 'Not connected yet: Orchestra has no Google Calendar for this workspace.',
      error: String(s.slots_note || '').startsWith('Could not') ? s.slots_note : 'Google Calendar answered with an error the last time it was asked.',
    }[s.calendar_status] || 'Not checked yet.';
    const check = el('button', { type: 'button', class: 'oc-btn' }, 'Check again');
    check.addEventListener('click', async () => {
      check.disabled = true;
      if (await act(A.rebuild, {}, 'Asking Google Calendar…')) setTimeout(again, 3000);
      else check.disabled = false;
    });
    return el('div', { class: 'oc-stack' }, [
      el('p', { class: `bk-step__state${s.calendar_status && s.calendar_status !== 'ok' ? ' bk-step__state--bad' : ''}` },
        [said, checked ? el('span', { class: 'bk-row__sub' }, ` Checked ${fmt.ago(checked.toISOString())}.`) : null]),
      x.done ? null : el('p', { class: 'oc-help' }, 'Connect the Google account whose calendar you use for meetings, then come back here and check again.'),
      el('div', { class: 'oc-row' }, [
        x.done ? null : el('a', { class: 'oc-btn oc-btn--primary', href: INTEGRATIONS, target: '_top' }, 'Connect it in Orchestra → Integrations'),
        check,
      ]),
    ]);
  },

  hours(s, { types }, again) {
    const t = types[0];
    if (!t) {
      return el('div', { class: 'oc-stack' }, [
        el('p', { class: 'oc-help' }, 'There is no meeting type yet.'),
        el('div', { class: 'oc-row' }, router.link('/types/new', 'Make a meeting type', { class: 'oc-btn oc-btn--primary' })),
      ]);
    }
    const on = t.active === 'yes';
    const hours = hoursEditor(parse(t.hours, {}));
    const save = el('button', { type: 'submit', class: 'oc-btn oc-btn--primary' }, on ? 'Save hours' : 'Save and turn it on');
    const f = el('form', { class: 'oc-stack' }, [
      el('p', { class: 'oc-help' }, [`For "${t.name}" (${t.duration_min} min), in ${s.timezone || 'UTC'}. `, router.link(`/types/${t._id}`, 'Change everything else about it')]),
      hours.node,
      el('div', { class: 'oc-row' }, [save, el('span', { class: `oc-badge${on ? ' oc-badge--good' : ''}` }, on ? 'On' : 'Off')]),
    ]);
    f.addEventListener('submit', async (e) => {
      e.preventDefault();
      const value = hours.value();
      if (!Object.keys(value).length) { Orch.toast('Tick at least one day, with a start before its end.', { error: true }); return; }
      save.disabled = true;
      // One write, one rebuild: turning on and saving the hours in two actions would start two builds, and the second waits out the first.
      const r = await act(on ? A.updateType : A.startType, { id: t._id, hours: JSON.stringify(value) },
        on ? 'Saved. The free times are being worked out again.' : 'Turned on: its times appear on your page in a moment.');
      save.disabled = false;
      if (r) setTimeout(again, on ? 0 : 2500);
    });
    return f;
  },

  share(s, { types, slots }) {
    const link = publicLink(s);
    const on = types.some((t) => t.active === 'yes');
    const state = !on ? 'The link goes live once a meeting type is on (the step above).'
      : !slots && s.calendar_status !== 'ok' ? 'No free times yet: they are worked out once Google Calendar is connected (step 2).'
        : !slots ? 'No free times in the coming days yet. If it stays like this, check that your hours leave room for a whole meeting.'
        : `Live: ${fmt.number(slots)} free times offered.`;
    return el('div', { class: 'oc-stack' }, [
      el('div', { class: 'bk-code' }, [el('code', link), el('button', { type: 'button', class: 'oc-btn oc-btn--sm', onClick: () => copy(link, 'Link copied.') }, 'Copy')]),
      el('p', { class: 'bk-step__why' }, 'Put it in your email signature or on your website.'),
      el('p', { class: `bk-step__state${on && slots ? '' : ' bk-step__state--muted'}` }, state),
    ]);
  },
};
