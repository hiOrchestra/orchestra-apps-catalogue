// Inbox: what waits for an answer, most urgent and oldest first. The numbers
// on top are what the team asks first (new, unanswered, past the
// first-response time); each opens its queue. Below, one list per queue with
// filters by category, priority and who has it. A row opens its ticket.
import { T, V, A, act, settings, categories, badge, age, who, pausedNote, PRIORITIES, STATUSES } from '../data.js';
import { startCard } from './start.js';

const { el, router, fmt } = Orch;

const QUEUES = {
  open: { label: 'To answer', filter: { status: ['New', 'Open'] }, sort: 'queue_key:asc', empty: 'Nothing waits for an answer. New mail and contact-page messages arrive here.' },
  overdue: { label: 'Overdue', filter: { overdue: 'yes' }, sort: 'queue_key:asc', empty: 'Nobody has waited past the first-response time.' },
  waiting: { label: 'Waiting on customer', filter: { status: 'Pending' }, sort: '_id:desc', empty: 'No ticket waits on a customer.' },
  solved: { label: 'Solved', filter: { status: 'Solved' }, sort: '_id:desc', empty: 'Nothing solved yet.' },
  spam: { label: 'Spam', filter: { status: 'Spam' }, sort: '_id:desc', empty: 'No spam.' },
  all: { label: 'All', filter: null, sort: '_id:desc', empty: 'No tickets yet.' },
};

export function render(params, path) {
  const key = QUEUES[params.queue] ? params.queue : 'open';
  const q = QUEUES[key];
  Orch.load('view', async () => {
    const s = await settings(true);
    const again = () => render(params, path);
    const [fresh, unanswered, overdue, assignees, start] = await Promise.all([
      Orch.db.count(T.tickets, { filter: { status: 'New' } }),
      Orch.db.view(V.queue, { filter: { awaiting: 'yes' }, limit: 1, count: true }).then((r) => r.total || 0),
      Orch.db.view(V.queue, { filter: { overdue: 'yes' }, limit: 1, count: true }).then((r) => r.total || 0),
      Orch.db.count(T.tickets, { group: 'assignee' }).then((r) => (r.groups || []).map((g) => g.value).filter(Boolean)).catch(() => []),
      key === 'open' ? startCard(s, again).catch(() => null) : null,
    ]);
    const list = el('div', { class: 'hd-queue' });
    table(list, key, q, path, s, assignees);
    return el('div', { class: 'oc-stack oc-stack--loose' }, [
      head(s, again),
      pausedNote(s),
      start,
      el('div', { class: 'oc-metrics hd-kpis' }, [
        metric('New', fresh, 'Arrived and nobody has opened them', '/q/all?status=New'),
        metric('Unanswered', unanswered, 'The customer wrote last and is waiting', '/'),
        metric('Over SLA', overdue, `Waiting more than ${s.sla_hours || 24} h for an answer`, '/q/overdue', overdue ? 'bad' : ''),
      ]),
      el('nav', { class: 'oc-tabs', 'aria-label': 'Queues' }, Object.entries(QUEUES).map(([k, x]) =>
        router.link(k === 'open' ? '/' : `/q/${k}`, x.label, { class: 'oc-tab', 'aria-current': k === key ? 'page' : null }))),
      list,
    ]);
  });
}

function head(s, again) {
  const check = el('button', { class: 'oc-btn oc-btn--sm', type: 'button' }, 'Check mail now');
  check.addEventListener('click', async () => {
    check.disabled = true;
    const ok = await act(A.checkNow, {}, 'Checking the mailbox. New tickets appear in a moment.');
    setTimeout(() => { if (check.isConnected) again(); }, ok ? 6000 : 0);
  });
  const last = s.intake_at ? `Mail checked ${age(s.intake_at)} ago${s.intake_note ? ` · ${s.intake_note}` : ''}` : 'Mail not checked yet';
  return el('header', { class: 'hd-head' }, [
    el('div', {}, [el('h1', { class: 'oc-h1 oc-h1--collection' }, 'Inbox'), el('p', { class: 'oc-eyebrow' }, last)]),
    check,
  ]);
}

function metric(label, n, hint, href, tone) {
  return el('div', { class: 'oc-metric oc-metric--compact', title: hint }, [
    el('span', { class: 'oc-kpi__label' }, label),
    el('span', { class: `oc-kpi__value${tone ? ` hd-${tone}` : ''}` }, fmt.number(n || 0)),
    router.link(href, hint, { class: 'oc-metric__link oc-help' }),
  ]);
}

/** Where a ticket stands for the person reading the list: the one thing to do next. */
function state(row) {
  if (row.failed === 'yes') return badge('Send failed', 'bad');
  if (row.draft === 'yes') return badge('Draft to review', 'warn');
  if (row.triage === 'Working' || row.triage === 'Pending') return el('span', { class: 'oc-help' }, 'Drafting…');
  if (row.overdue === 'yes') return badge('Overdue', 'bad');
  if (row.awaiting === 'yes') return el('span', { class: 'oc-help' }, 'No draft');
  return badge(row.status);
}

function table(into, key, q, path, s, assignees) {
  Orch.table({
    into,
    path: key === 'open' ? '/' : `/q/${key}`,
    query: path,
    view: V.queue,
    filter: q.filter || undefined,
    sort: q.sort,
    pageSize: 50,
    search: ['subject', 'requester_email', 'requester_name'],
    searchPlaceholder: 'Subject, name or email',
    filters: [
      { key: 'priority', label: 'Priority', options: PRIORITIES },
      { key: 'category', label: 'Category', options: categories(s) },
      { key: 'assignee', label: 'Assigned to', options: [{ value: '__isnull', label: 'Nobody' }, ...assignees] },
      ...(key === 'all' ? [{ key: 'status', label: 'Status', options: STATUSES }] : []),
    ],
    columns: [
      { key: 'subject', label: 'Ticket', format: (v, row) => el('div', { class: 'hd-subject' }, [
        router.link(`/t/${row._id}`, v || '(No subject)', { class: 'hd-subject__link' }),
        el('span', { class: 'oc-help' }, row.summary || who(row)),
      ]) },
      { key: 'requester_name', label: 'From', format: (v, row) => el('span', { title: row.requester_email || '' }, who(row)) },
      { key: 'priority', label: 'Priority', format: (v) => (v === 'Urgent' || v === 'High' ? badge(v) : el('span', { class: 'oc-help' }, v || 'Normal')) },
      { key: 'category', label: 'Category', format: (v) => v || '—' },
      { key: 'assignee', label: 'Assigned', format: (v) => (v ? String(v).split('@')[0] : '—') },
      { key: 'last_inbound_at', label: 'Waiting', format: (v, row) => el('span', { class: 'oc-value' }, row.awaiting === 'yes' ? age(v) : '—') },
      { key: 'status', label: 'Next', sortable: false, render: state },
    ],
    empty: q.empty,
  });
}
