// The first-run card on top of the Inbox: where customers reach you, and the
// answers the agent drafts from. Shown until both are done; Hide keeps it
// away for good (hd_settings.onboarding_hidden_at, so it holds on every device).
import { T, A, act } from '../data.js';
import { STEPS, onboarding } from '../onboarding.js';

const { el, router } = Orch;

/** The card, or null when it is done or hidden. */
export async function startCard(s, again) {
  const [tickets, articles, examples] = await Promise.all([
    Orch.db.count(T.tickets),
    Orch.db.count(T.articles),
    Orch.db.count(T.articles, { filter: { example: 'yes' } }),
  ]);
  const { done, show } = onboarding(s, { tickets, articles, examples });
  if (!show) return null;
  const hide = el('button', { type: 'button', class: 'oc-btn oc-btn--ghost oc-btn--sm' }, 'Hide');
  hide.addEventListener('click', async () => { hide.disabled = true; if (await act(A.hideStart, { id: s._id })) again(); else hide.disabled = false; });
  const body = { contact: contact(s, again), answers: answers() };
  return el('section', { class: 'oc-card hd-start', 'aria-label': 'Getting started' }, [
    el('div', { class: 'hd-start__head' }, [el('h2', { class: 'oc-h2' }, 'Getting started'), hide]),
    el('ol', { class: 'hd-start__steps' }, STEPS.map((x) => el('li', { class: `hd-start__step${done[x.id] ? ' hd-start__step--done' : ''}` }, [
      el('p', { class: 'hd-start__title' }, [x.title, done[x.id] ? el('span', { class: 'oc-badge oc-badge--good' }, 'Done') : null]),
      body[x.id],
    ]))),
  ]);
}

function contact(s, again) {
  const url = s.public_url || '';
  const copy = el('button', { type: 'button', class: 'oc-btn oc-btn--sm' }, 'Copy');
  copy.addEventListener('click', async () => {
    try { await navigator.clipboard.writeText(url); Orch.toast('Link copied.'); } catch { Orch.toast('Select the link and copy it.', { error: true }); return; }
    if (!s.contact_copied_at && await act(A.contactCopied, { id: s._id })) again();
  });
  return el('div', { class: 'hd-start__body' }, [
    url ? el('div', { class: 'hd-start__link' }, [el('code', { class: 'hd-link' }, url), copy])
      : el('p', { class: 'oc-help' }, 'The contact page link appears here once Helpdesk is installed.'),
    el('p', { class: 'oc-help' }, 'Put the contact page on your website. Customers can also email your workspace address; both land here as tickets.'),
  ]);
}

function answers() {
  return el('div', { class: 'hd-start__body' }, [
    el('p', { class: 'oc-help' }, 'The agent drafts replies from the knowledge base. Replace the example articles with yours.'),
    router.link('/kb', 'Open the knowledge base', { class: 'oc-btn oc-btn--sm' }),
  ]);
}
