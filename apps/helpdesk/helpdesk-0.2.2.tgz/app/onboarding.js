// First run, the pure part (no Orch, so a test can import it): which of the
// two steps are done, and whether the card shows. Each step is read from the
// data every time the Inbox draws, never ticked by hand.
//   contact  the contact-page link was copied, or a first ticket exists
//   answers  an article that is not one of the installed examples exists
//            (adding one, or saving an example, clears its `example` flag)
export const STEPS = [
  { id: 'contact', title: 'Where customers reach you' },
  { id: 'answers', title: 'Your answers' },
];

export function onboarding(s, { tickets = 0, articles = 0, examples = 0 } = {}) {
  const done = {
    contact: Boolean(s && s.contact_copied_at) || Number(tickets) > 0,
    answers: Number(articles) - Number(examples) > 0,
  };
  return { done, show: !(s && s.onboarding_hidden_at) && !(done.contact && done.answers) };
}
