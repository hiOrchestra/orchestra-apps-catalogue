// What Helpdesk reads, the only things it writes, and what the screens share.
// Tables give rows, the views do the counting (queue: what waits, what is
// overdue, which ticket has a draft or a failed send), and every write is a
// declared action (A). Reading the mail, drafting with the agent and sending
// run as workflows on the instance; a page only ever asks for them.
const { el, router, fmt } = Orch;

export const T = {
  tickets: 'hd_tickets', messages: 'hd_messages', articles: 'hd_articles', macros: 'hd_macros', settings: 'hd_settings', requests: 'hd_requests',
};
export const V = { queue: 'queue', volume: 'volume', first: 'first_responses' };
export const A = {
  setStatus: 'set_status', solve: 'solve_ticket', spam: 'mark_spam', notSpam: 'not_spam', update: 'update_ticket',
  assign: 'assign_ticket', assignMe: 'assign_me', redraft: 'redraft',
  approve: 'approve_draft', saveDraft: 'save_draft', discard: 'discard_draft', reply: 'send_reply',
  retry: 'retry_send', drop: 'drop_failed', note: 'add_note', sendNow: 'send_now', checkNow: 'check_now',
  addArticle: 'add_article', updateArticle: 'update_article', addMacro: 'add_macro', updateMacro: 'update_macro', archiveMacro: 'archive_macro',
  settings: 'update_settings', pause: 'pause', resume: 'resume', contactCopied: 'contact_copied', hideStart: 'hide_onboarding',
};
// No Closed: Solved is the end of a ticket (a new customer message reopens it).
export const STATUSES = ['New', 'Open', 'Pending', 'Solved', 'Spam'];
export const PRIORITIES = ['Urgent', 'High', 'Normal', 'Low'];

/** Run a declared action, say how it went, and hand back its result (null on failure). */
export async function act(name, params, done) {
  try {
    const r = await Orch.action(name, params);
    if (done) Orch.toast(done);
    return r || {};
  } catch (e) {
    Orch.toast(e.status === 409 ? 'It changed in the meantime: look again.' : (e.message || 'That did not work.'), { error: true });
    return null;
  }
}

/** Approve, then ask for the send run. The run carries nothing: it finds every approved reply itself. */
export async function sendApproved() {
  try { await Orch.action(A.sendNow, {}); } catch { /* the 15-minute check sends it */ }
}

let kept = null;
/** The one settings row. */
export async function settings(fresh) {
  if (!kept || fresh) kept = (await Orch.db.list(T.settings, { sort: '_id:asc', limit: 1 })).rows[0] || {};
  return kept;
}
export const isPaused = (s) => String((s && s.paused) || '').toLowerCase() === 'yes';

/** The categories in Settings (a JSON list). */
export function categories(s) {
  let v = null;
  try { v = JSON.parse(s.categories || '[]'); } catch { /* a comma list */ }
  return words(Array.isArray(v) ? v : String(s.categories || '').split(','));
}
/** A list as people typed it: trimmed, no empties, no repeats. */
export const words = (list) => [...new Set(list.map((x) => String(x).trim()).filter(Boolean))];

// States are chips: gold waits on a person, green is done, red went wrong.
const TONE = {
  New: 'warn', Open: '', Pending: '', Solved: 'good', Spam: 'bad',
  Urgent: 'bad', High: 'warn', Normal: '', Low: '',
  Draft: 'warn', Approved: '', Sending: '', Sent: 'good', Failed: 'bad', Dropped: '',
};
export const badge = (text, tone) => el('span', { class: `oc-badge${(tone || TONE[text]) ? ` oc-badge--${tone || TONE[text]}` : ''}` }, text || '—');

/** '2026-10-03 10:00:00' (UTC, as rows are stamped) or ISO, as a Date. */
export function when(v) {
  if (!v) return null;
  const s = String(v).trim();
  const d = new Date(/[zZ]|[+-]\d\d:?\d\d$/.test(s) ? s : `${s.replace(' ', 'T')}Z`);
  return Number.isNaN(d.getTime()) ? null : d;
}
/** "12 min", "3 h", "2 d": how long, said short. */
export function age(v) {
  const d = when(v);
  if (!d) return '—';
  const m = Math.max(0, Math.round((Date.now() - d.getTime()) / 60000));
  if (m < 60) return `${m} min`;
  if (m < 2880) return `${Math.round(m / 60)} h`;
  return `${Math.round(m / 1440)} d`;
}
export const stamp = (v) => { const d = when(v); return d ? d.toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' }) : '—'; };
export const plural = (n, one, many) => `${fmt.number(n || 0)} ${Number(n) === 1 ? one : many}`;
/** Minutes as people say them: "45 min", "3.5 h", "2.1 d". */
export function duration(min) {
  if (min === null || min === undefined || !Number.isFinite(min)) return '—';
  if (min < 60) return `${Math.round(min)} min`;
  if (min < 2880) return `${(min / 60).toFixed(min < 600 ? 1 : 0)} h`;
  return `${(min / 1440).toFixed(1)} d`;
}

/** Who wrote: the name when there is one, the address otherwise. */
export const who = (t) => t.requester_name || t.requester_email || 'Someone';

/** A dialog that closes when the screen changes. */
export function sheet(content, opts) {
  const d = Orch.dialog(content, opts);
  window.addEventListener('hashchange', () => { try { d.close(); } catch { /* already closed */ } }, { once: true });
  return d;
}

/** A labelled field; the help under it says what it is for. */
export function field(label, control, help) {
  return el('label', { class: 'oc-field' }, [el('span', { class: 'oc-label' }, label), control, help ? el('span', { class: 'oc-help' }, help) : null]);
}

/** The line under a screen's title when Helpdesk is paused: what is held back, and the way out. */
export function pausedNote(s) {
  if (!isPaused(s)) return null;
  return el('p', { class: 'hd-paused oc-help' }, [
    badge('Paused', 'warn'), ' The agent drafts nothing and no reply goes out; approved replies wait. ',
    router.link('/settings', 'Resume in Settings'),
  ]);
}
