// Settings: the brake first (pause), then what is managed in Orchestra (how
// replies sound, what counts as late, where tickets come from), the contact
// page, and the saved replies.
import { T, A, act, settings, categories, isPaused, badge, field, sheet, age } from '../data.js';

const { el } = Orch;
const DOORS = [
  ['inbox,unverified', 'Mail nobody was woken for (recommended): strangers and customers'],
  ['inbox,unverified,instructions,workflow', 'All mail to the workspace address, including your listed senders'],
];

export function render() {
  Orch.load('view', async () => {
    const s = await settings(true);
    const macros = (await Orch.db.list(T.macros, { filter: { archived: 'no' }, sort: 'name:asc', limit: 100 })).rows || [];
    return el('div', { class: 'oc-stack oc-stack--loose hd-settings' }, [
      el('h1', { class: 'oc-h1 oc-h1--collection' }, 'Settings'),
      brake(s),
      managed(s),
      sources(s),
      saved(macros),
    ]);
  });
}

function brake(s) {
  const on = isPaused(s);
  const b = el('button', { class: `oc-btn${on ? ' oc-btn--primary' : ''}`, type: 'button' }, on ? 'Resume' : 'Pause Helpdesk');
  b.addEventListener('click', async () => {
    if (!on && !(await Orch.confirm('Pause Helpdesk? The agent stops drafting and no reply goes out until you resume; mail keeps arriving.', { yes: 'Pause' }))) return;
    b.disabled = true;
    if (await act(on ? A.resume : A.pause, { id: s._id }, on ? 'Resumed: approved replies go out now.' : 'Paused.')) {
      if (on) { try { await Orch.action(A.sendNow, {}); } catch { /* the 15-minute check */ } }
      render();
    } else b.disabled = false;
  });
  return el('section', { class: 'oc-card hd-brake' }, [
    el('div', {}, [
      el('div', { class: 'hd-head__name' }, [el('h2', { class: 'oc-h2' }, 'Drafting and sending'), badge(on ? 'Paused' : 'Running', on ? 'warn' : 'good')]),
      el('p', { class: 'oc-help' }, on
        ? 'Paused: the agent drafts nothing and no reply goes out. Replies you approve wait here until you resume. Mail and contact-page messages keep arriving.'
        : 'Running: the agent drafts a reply for each new message, and a reply goes out only when someone presses Send. Pause to stop both at once.'),
    ]),
    b,
  ]);
}

// How replies sound, what counts as late, where tickets come from and which Gmail
// answers the contact page are managed in Orchestra (Apps → Helpdesk → Ajustes and
// Conexiones): typed, next to who does its work. Here, what they are now and a way there.
function managed(s) {
  const link = el('a', { class: 'oc-btn oc-btn--primary', target: '_blank', rel: 'noopener', hidden: true }, 'Open the settings in Orchestra');
  const where = el('p', { class: 'oc-help' }, 'In Orchestra: Apps → Helpdesk → Ajustes.');
  if (Orch.manageUrl) Orch.manageUrl('settings').then((url) => { if (url) { link.href = url; link.hidden = false; where.hidden = true; } });
  const door = (DOORS.find(([v]) => v === (s.intake_from || DOORS[0][0])) || DOORS[0])[1];
  const facts = [
    ['Categories', categories(s).join(', ') || '—'],
    ['First-response time', `${s.sla_hours || 8} hours`],
    ['Urgent and overdue tickets told on Telegram', s.telegram_chat ? 'yes' : 'no'],
    ['Which mail becomes a ticket', door],
  ];
  return el('section', { class: 'oc-card oc-stack hd-form' }, [
    el('h2', { class: 'oc-h2' }, 'How we answer'),
    el('p', { class: 'oc-help' }, 'The signature, the tone, the categories, the first-response time, Telegram notices and which mail becomes a ticket are managed in Orchestra.'),
    el('ul', { class: 'oc-stack' }, facts.map(([k, v]) => el('li', [el('b', `${k}: `), v]))),
    el('div', { class: 'oc-row' }, [link]), where,
  ]);
}

function sources(s) {
  return el('section', { class: 'oc-card oc-stack hd-form' }, [
    el('h2', { class: 'oc-h2' }, 'Where tickets come from'),
    el('p', { class: 'oc-help' }, `Mail to the workspace address is read every 15 minutes (last time: ${s.intake_at ? `${age(s.intake_at)} ago` : 'not yet'}). Answers to it go back from the same address, into the customer's conversation.`),
    el('div', { class: 'oc-field' }, [
      el('span', { class: 'oc-label' }, 'Contact page'),
      s.public_url ? el('a', { href: s.public_url, target: '_blank', rel: 'noopener', class: 'oc-value hd-link' }, s.public_url) : el('span', { class: 'oc-help' }, 'Its address appears here once Helpdesk is installed.'),
      el('span', { class: 'oc-help' }, 'Link it from your website. A person who writes there never wrote to the workspace address, so the answer goes out from the Gmail connection chosen for Helpdesk in Orchestra.'),
    ]),
  ]);
}

function saved(macros) {
  const add = el('button', { class: 'oc-btn oc-btn--sm', type: 'button' }, 'New saved reply');
  add.addEventListener('click', () => editMacro(null));
  return el('section', { class: 'oc-card oc-card--pad0' }, [
    el('div', { class: 'hd-compose__head hd-pad' }, [el('h2', { class: 'oc-h2' }, 'Saved replies'), add]),
    el('p', { class: 'oc-help hd-pad' }, 'Text you can insert into any reply from the ticket screen.'),
    macros.length
      ? el('ul', { class: 'hd-rows' }, macros.map((m) => {
        const open = el('button', { class: 'oc-btn oc-btn--sm oc-btn--ghost', type: 'button' }, 'Edit');
        open.addEventListener('click', () => editMacro(m));
        return el('li', { class: 'hd-row' }, [el('span', { class: 'hd-row__name' }, m.name), el('span', { class: 'oc-help hd-row__more' }, String(m.body || '').slice(0, 90)), open]);
      }))
      : el('p', { class: 'oc-help hd-pad' }, 'None yet.'),
  ]);
}

function editMacro(m) {
  const name = el('input', { class: 'oc-input', value: (m && m.name) || '', maxlength: '80' });
  const body = el('textarea', { class: 'oc-textarea', rows: '8' }, (m && m.body) || '');
  const save = el('button', { class: 'oc-btn oc-btn--primary', type: 'submit' }, 'Save');
  const gone = m ? el('button', { class: 'oc-btn oc-btn--ghost', type: 'button' }, 'Remove') : null;
  const f = el('form', { class: 'oc-stack' }, [field('Name', name), field('Text', body), el('div', { class: 'oc-row' }, [save, gone])]);
  const d = sheet(f, { title: m ? 'Saved reply' : 'New saved reply' });
  f.addEventListener('submit', async (e) => {
    e.preventDefault();
    if (!name.value.trim() || !body.value.trim()) { Orch.toast('A saved reply needs a name and a text.', { error: true }); return; }
    const data = { name: name.value.trim(), body: body.value.trim() };
    if (await act(m ? A.updateMacro : A.addMacro, m ? Object.assign({ id: m._id }, data) : data, 'Saved.')) { d.close(); render(); }
  });
  if (gone) gone.addEventListener('click', async () => { if (await act(A.archiveMacro, { id: m._id }, 'Removed.')) { d.close(); render(); } });
}
