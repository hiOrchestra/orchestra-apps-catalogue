// The router and the bar. Inbox is home: what waits for an answer. A ticket
// is its own screen (#/t/<id>), so a link to it can be sent to a colleague.
import { render as inbox } from './screens/inbox.js';
import { render as ticket } from './screens/ticket.js';
import { render as kb, edit as article } from './screens/kb.js';
import { render as reports } from './screens/reports.js';
import { render as settings } from './screens/settings.js';

const { el, router } = Orch;

router.define({
  '/': inbox,
  '/q/:queue': inbox,
  '/t/:id': ticket,
  '/kb': kb,
  '/kb/:id': article,
  '/reports': reports,
  '/reports/:period': reports,
  '/settings': settings,
}, () => Orch.mount('view', el('div', { class: 'oc-state' }, [
  el('p', 'There is no screen here.'), router.link('/', 'Go to the inbox'),
]))).start();

Orch.mount('nav', [
  router.link('/', 'Inbox', { class: 'oc-tab' }),
  router.link('/kb', 'Knowledge base', { class: 'oc-tab' }),
  router.link('/reports', 'Reports', { class: 'oc-tab' }),
  router.link('/settings', 'Settings', { class: 'oc-tab' }),
]);
