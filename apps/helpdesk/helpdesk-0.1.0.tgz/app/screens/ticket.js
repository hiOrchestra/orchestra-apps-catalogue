// One ticket: the conversation with the agent's draft to review and send
// (thread.js), and beside it what the team decides — status, priority,
// category, who has it — with what else this customer asked before.
import { T, A, act, settings, categories, badge, age, stamp, duration, who, when, field, pausedNote, STATUSES, PRIORITIES } from '../data.js';
import { conversation } from './thread.js';

const { el, router } = Orch;

export function render(params) {
  const id = Number(params.id);
  const again = () => render(params);
  Orch.load('view', async () => {
    const t = await Orch.db.get(T.tickets, id);
    if (!t) return el('div', { class: 'oc-state' }, [el('p', { class: 'oc-state__title' }, 'This ticket is not here.'), router.link('/', 'Back to the inbox')]);
    const [s, msgs, macros, earlier] = await Promise.all([
      settings(true),
      Orch.db.list(T.messages, { filter: { ticket_id: id }, sort: '_id:asc', limit: 200 }).then((r) => r.rows || []),
      Orch.db.list(T.macros, { filter: { archived: 'no' }, sort: 'name:asc', limit: 100 }).then((r) => r.rows || []),
      t.requester_email
        ? Orch.db.list(T.tickets, { filter: { requester_email: t.requester_email, _id: { ne: id } }, sort: '_id:desc', limit: 5 }).then((r) => r.rows || [])
        : [],
    ]);
    return el('div', { class: 'oc-stack hd-ticket' }, [
      head(t, again),
      pausedNote(s),
      el('div', { class: 'hd-ticket__grid' }, [
        el('div', { class: 'hd-ticket__main' }, conversation(t, msgs, s, macros, again)),
        el('aside', { class: 'hd-ticket__side oc-stack', 'aria-label': 'About this ticket' }, [decide(t, s, again), customer(t, earlier)]),
      ]),
    ]);
  });
}

function head(t, again) {
  const tool = (label, name, params, done, cls) => {
    const b = el('button', { class: `oc-btn oc-btn--sm${cls ? ` ${cls}` : ''}`, type: 'button' }, label);
    b.addEventListener('click', async () => { b.disabled = true; if (await act(name, Object.assign({ id: t._id }, params), done)) again(); else b.disabled = false; });
    return b;
  };
  const tools = [];
  if (t.status === 'Spam') tools.push(tool('Not spam', A.notSpam, {}, 'Back in the inbox; the agent drafts a reply.'));
  else {
    if (!['Solved', 'Closed'].includes(t.status)) tools.push(tool('Solve', A.solve, {}, 'Solved.'));
    else tools.push(tool('Reopen', A.setStatus, { status: 'Open' }, 'Open again.'));
    tools.push(tool('Spam', A.spam, { ids: [t._id] }, 'Marked as spam.', 'oc-btn--ghost'));
  }
  const how = t.channel === 'form' ? 'from the contact page' : 'by email';
  return el('header', { class: 'hd-head hd-head--ticket' }, [
    el('div', { class: 'hd-head__title' }, [
      router.link('/', '← Inbox', { class: 'oc-small' }),
      el('div', { class: 'hd-head__name' }, [
        el('h1', { class: 'oc-h1' }, t.subject || '(No subject)'),
        badge(t.status),
        t.priority === 'Urgent' || t.priority === 'High' ? badge(t.priority) : null,
      ]),
      el('p', { class: 'oc-eyebrow' }, [`${who(t)} · ${t.requester_email || 'no address'} · ${how} · opened ${stamp(t.opened_at || t._created_at)}`]),
    ]),
    el('div', { class: 'hd-head__tools' }, tools),
  ]);
}

/** A select that saves itself: one control per decision, said back in a toast. */
function choose(label, value, options, save, help) {
  const sel = el('select', { class: 'oc-select' }, [
    ...(options.includes(value) || !value ? [] : [el('option', { value }, value)]),
    ...(value ? [] : [el('option', { value: '' }, '—')]),
    ...options.map((o) => el('option', { value: o, selected: o === value }, o)),
  ]);
  sel.addEventListener('change', () => save(sel.value));
  return field(label, sel, help);
}

function decide(t, s, again) {
  const saved = (msg) => (r) => { if (r) { Orch.toast(msg); again(); } };
  const other = el('input', { class: 'oc-input', type: 'email', placeholder: 'colleague@company.com', value: '' });
  const give = el('button', { class: 'oc-btn oc-btn--sm', type: 'button' }, 'Assign');
  give.addEventListener('click', async () => {
    const v = other.value.trim().toLowerCase();
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)) { Orch.toast('Write their email address.', { error: true }); return; }
    saved(`Assigned to ${v}.`)(await act(A.assign, { id: t._id, assignee: v }));
  });
  const me = el('button', { class: 'oc-btn oc-btn--sm', type: 'button' }, 'Assign to me');
  me.addEventListener('click', async () => saved('Assigned to you.')(await act(A.assignMe, { id: t._id })));
  const nobody = el('button', { class: 'oc-btn oc-btn--sm oc-btn--ghost', type: 'button' }, 'Unassign');
  nobody.addEventListener('click', async () => saved('Nobody has it now.')(await act(A.assign, { id: t._id, assignee: '' })));
  const statuses = STATUSES.slice(0, 5); // Spam has its own button
  return el('section', { class: 'oc-card oc-stack' }, [
    el('h2', { class: 'oc-h2' }, 'Decide'),
    choose('Status', t.status, t.status === 'Spam' ? ['Spam'] : statuses, async (v) => {
      if (v === 'Solved') saved('Solved.')(await act(A.solve, { id: t._id }));
      else saved(`Now ${v}.`)(await act(A.setStatus, { id: t._id, status: v }));
    }, 'Pending waits on the customer; Solved closes it until they write again.'),
    choose('Priority', t.priority || 'Normal', PRIORITIES, async (v) => saved(`Priority ${v}.`)(await act(A.update, { id: t._id, priority: v }))),
    choose('Category', t.category || '', categories(s), async (v) => saved(`Category ${v}.`)(await act(A.update, { id: t._id, category: v })),
      'Reports count tickets by it. The list is in Settings.'),
    el('div', { class: 'oc-field' }, [
      el('span', { class: 'oc-label' }, 'Assigned to'),
      el('p', { class: 'oc-value hd-assignee' }, t.assignee || 'Nobody'),
      el('div', { class: 'oc-row' }, [me, t.assignee ? nobody : null]),
      el('div', { class: 'hd-inline' }, [other, give]),
    ]),
  ]);
}

function customer(t, earlier) {
  const first = when(t.first_response_at) && when(t.opened_at) ? (when(t.first_response_at) - when(t.opened_at)) / 60000 : null;
  return el('section', { class: 'oc-card oc-stack' }, [
    el('h2', { class: 'oc-h2' }, 'This customer'),
    t.summary ? el('p', { class: 'hd-summary' }, [el('span', { class: 'oc-eyebrow' }, 'Summary by the agent'), el('span', t.summary)]) : null,
    el('dl', { class: 'oc-facts' }, [
      el('div', { class: 'oc-facts__item' }, [el('dt', 'Waiting'), el('dd', { class: 'oc-value' }, ['New', 'Open'].includes(t.status) ? age(t.last_inbound_at) : '—')]),
      el('div', { class: 'oc-facts__item' }, [el('dt', 'First answer'), el('dd', { class: 'oc-value' }, first === null ? 'not yet' : duration(first))]),
    ]),
    earlier.length
      ? el('div', { class: 'oc-stack oc-stack--tight' }, [el('span', { class: 'oc-eyebrow' }, 'Asked before'),
        el('ul', { class: 'hd-rows' }, earlier.map((e) => el('li', { class: 'hd-row' }, [
          router.link(`/t/${e._id}`, e.subject || '(No subject)', { class: 'hd-row__name' }), el('span', { class: 'oc-value' }, age(e.opened_at || e._created_at)), badge(e.status),
        ])))])
      : el('p', { class: 'oc-help' }, 'First time this address writes to us.'),
  ]);
}
