// Settings: the brake first (pause), then how replies sound, what counts as
// late, where tickets come from and go out through, and the saved replies.
import { T, A, act, settings, categories, words, isPaused, badge, field, sheet, age } from '../data.js';

const { el } = Orch;
const DOORS = [
  ['inbox,unverified', 'Mail nobody was woken for (recommended): strangers and customers'],
  ['inbox,unverified,instructions,workflow', 'All mail to the workspace address, including your listed senders'],
];

export function render() {
  Orch.load('view', async () => {
    const s = await settings(true);
    const macros = (await Orch.db.list(T.macros, { filter: { archived: 'no' }, sort: 'name:asc', limit: 100 })).rows || [];
    return el('div', { class: 'oc-stack oc-stack--loose hd-settings' }, [
      el('h1', { class: 'oc-h1 oc-h1--collection' }, 'Settings'),
      brake(s),
      form(s),
      sources(s),
      saved(macros),
    ]);
  });
}

function brake(s) {
  const on = isPaused(s);
  const b = el('button', { class: `oc-btn${on ? ' oc-btn--primary' : ''}`, type: 'button' }, on ? 'Resume' : 'Pause Helpdesk');
  b.addEventListener('click', async () => {
    if (!on && !(await Orch.confirm('Pause Helpdesk? The agent stops drafting and no reply goes out until you resume; mail keeps arriving.', { yes: 'Pause' }))) return;
    b.disabled = true;
    if (await act(on ? A.resume : A.pause, { id: s._id }, on ? 'Resumed: approved replies go out now.' : 'Paused.')) {
      if (on) { try { await Orch.action(A.sendNow, {}); } catch { /* the 15-minute check */ } }
      render();
    } else b.disabled = false;
  });
  return el('section', { class: 'oc-card hd-brake' }, [
    el('div', {}, [
      el('div', { class: 'hd-head__name' }, [el('h2', { class: 'oc-h2' }, 'Drafting and sending'), badge(on ? 'Paused' : 'Running', on ? 'warn' : 'good')]),
      el('p', { class: 'oc-help' }, on
        ? 'Paused: the agent drafts nothing and no reply goes out. Replies you approve wait here until you resume. Mail and contact-page messages keep arriving.'
        : 'Running: the agent drafts a reply for each new message, and a reply goes out only when someone presses Send. Pause to stop both at once.'),
    ]),
    b,
  ]);
}

function form(s) {
  const signature = el('textarea', { class: 'oc-textarea', rows: '3' }, s.signature || '');
  const tone = el('textarea', { class: 'oc-textarea', rows: '3' }, s.tone || '');
  const cats = el('input', { class: 'oc-input', value: categories(s).join(', ') });
  const sla = el('input', { class: 'oc-input hd-short', type: 'number', min: '1', max: '720', value: String(s.sla_hours || 24) });
  const tg = el('input', { class: 'oc-input', value: s.telegram_chat || '', placeholder: '-1001234567890 or @team_chat' });
  const save = el('button', { class: 'oc-btn oc-btn--primary', type: 'submit' }, 'Save');
  const f = el('form', { class: 'oc-card oc-stack hd-form' }, [
    el('h2', { class: 'oc-h2' }, 'How we answer'),
    field('Signature', signature, 'Added under every draft the agent writes, and to a reply you start yourself.'),
    field('Tone', tone, 'How the agent should sound. One or two sentences are enough.'),
    field('Categories', cats, 'Separated by commas. The agent picks one for each ticket; Reports count by them.'),
    field('First-response time (hours)', sla, 'A customer waiting longer than this counts as overdue in the Inbox and in Reports.'),
    field('Telegram chat for urgent tickets', tg, 'The chat id or @username of a chat the workspace bot is already in. Urgent tickets and overdue ones are told there. Empty: no messages.'),
    el('div', { class: 'oc-row' }, save),
  ]);
  f.addEventListener('submit', async (e) => {
    e.preventDefault();
    const list = words(cats.value.split(','));
    const hours = Math.round(Number(sla.value));
    if (!list.length) { Orch.toast('Keep at least one category.', { error: true }); return; }
    if (!(hours >= 1 && hours <= 720)) { Orch.toast('The first-response time is between 1 and 720 hours.', { error: true }); return; }
    save.disabled = true;
    await act(A.settings, { id: s._id, signature: signature.value.trim(), tone: tone.value.trim(), categories: JSON.stringify(list), sla_hours: hours, telegram_chat: tg.value.trim() }, 'Saved.');
    save.disabled = false;
  });
  return f;
}

function sources(s) {
  const door = el('select', { class: 'oc-select' }, DOORS.map(([v, l]) => el('option', { value: v, selected: v === (s.intake_from || DOORS[0][0]) }, l)));
  const gmail = el('input', { class: 'oc-input', value: s.gmail_account || '', placeholder: 'Leave empty to use the only Gmail connected' });
  const save = el('button', { class: 'oc-btn', type: 'submit' }, 'Save');
  const f = el('form', { class: 'oc-card oc-stack hd-form' }, [
    el('h2', { class: 'oc-h2' }, 'Where tickets come from'),
    el('p', { class: 'oc-help' }, `Mail to the workspace address is read every 15 minutes (last time: ${s.intake_at ? `${age(s.intake_at)} ago` : 'not yet'}). Answers to it go back from the same address, into the customer's conversation.`),
    field('Which mail becomes a ticket', door, 'Listed senders already wake an agent with their mail; usually they are your team, not customers.'),
    el('div', { class: 'oc-field' }, [
      el('span', { class: 'oc-label' }, 'Contact page'),
      s.public_url ? el('a', { href: s.public_url, target: '_blank', rel: 'noopener', class: 'oc-value hd-link' }, s.public_url) : el('span', { class: 'oc-help' }, 'Its address appears here once Helpdesk is installed.'),
      el('span', { class: 'oc-help' }, 'Link it from your website. A person who writes there never wrote to the workspace address, so the answer goes out from your connected Gmail.'),
    ]),
    field('Gmail account for contact-page answers', gmail, 'The name of the connection in the portal (Integrations), when more than one Gmail is connected.'),
    el('div', { class: 'oc-row' }, save),
  ]);
  f.addEventListener('submit', async (e) => {
    e.preventDefault();
    save.disabled = true;
    await act(A.settings, { id: s._id, intake_from: door.value, gmail_account: gmail.value.trim() }, 'Saved.');
    save.disabled = false;
  });
  return f;
}

function saved(macros) {
  const add = el('button', { class: 'oc-btn oc-btn--sm', type: 'button' }, 'New saved reply');
  add.addEventListener('click', () => editMacro(null));
  return el('section', { class: 'oc-card oc-card--pad0' }, [
    el('div', { class: 'hd-compose__head hd-pad' }, [el('h2', { class: 'oc-h2' }, 'Saved replies'), add]),
    el('p', { class: 'oc-help hd-pad' }, 'Text you can insert into any reply from the ticket screen.'),
    macros.length
      ? el('ul', { class: 'hd-rows' }, macros.map((m) => {
        const open = el('button', { class: 'oc-btn oc-btn--sm oc-btn--ghost', type: 'button' }, 'Edit');
        open.addEventListener('click', () => editMacro(m));
        return el('li', { class: 'hd-row' }, [el('span', { class: 'hd-row__name' }, m.name), el('span', { class: 'oc-help hd-row__more' }, String(m.body || '').slice(0, 90)), open]);
      }))
      : el('p', { class: 'oc-help hd-pad' }, 'None yet.'),
  ]);
}

function editMacro(m) {
  const name = el('input', { class: 'oc-input', value: (m && m.name) || '', maxlength: '80' });
  const body = el('textarea', { class: 'oc-textarea', rows: '8' }, (m && m.body) || '');
  const save = el('button', { class: 'oc-btn oc-btn--primary', type: 'submit' }, 'Save');
  const gone = m ? el('button', { class: 'oc-btn oc-btn--ghost', type: 'button' }, 'Remove') : null;
  const f = el('form', { class: 'oc-stack' }, [field('Name', name), field('Text', body), el('div', { class: 'oc-row' }, [save, gone])]);
  const d = sheet(f, { title: m ? 'Saved reply' : 'New saved reply' });
  f.addEventListener('submit', async (e) => {
    e.preventDefault();
    if (!name.value.trim() || !body.value.trim()) { Orch.toast('A saved reply needs a name and a text.', { error: true }); return; }
    const data = { name: name.value.trim(), body: body.value.trim() };
    if (await act(m ? A.updateMacro : A.addMacro, m ? Object.assign({ id: m._id }, data) : data, 'Saved.')) { d.close(); render(); }
  });
  if (gone) gone.addEventListener('click', async () => { if (await act(A.archiveMacro, { id: m._id }, 'Removed.')) { d.close(); render(); } });
}
