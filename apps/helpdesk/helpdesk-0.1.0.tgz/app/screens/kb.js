// Knowledge base: what the agent may say. Every draft is written from the
// published articles here and from the conversation; nothing else. A draft
// article stays out of the agent's reach until it is published.
import { T, A, act, badge, age, field } from '../data.js';

const { el, router } = Orch;

export function render(params, path) {
  Orch.load('view', async () => {
    const list = el('div');
    Orch.table({
      into: list, path: '/kb', query: path, table: T.articles, sort: 'title:asc', pageSize: 50,
      search: ['title', 'tags', 'body'], searchPlaceholder: 'Title, tag or words',
      filters: [{ key: 'published', label: 'Published', options: [{ value: 'yes', label: 'Published' }, { value: 'no', label: 'Draft' }] }],
      columns: [
        { key: 'title', label: 'Article', format: (v, row) => router.link(`/kb/${row._id}`, v || 'Untitled') },
        { key: 'tags', label: 'Tags', format: (v) => el('span', { class: 'oc-help' }, v || '—') },
        { key: 'published', label: 'State', format: (v) => (v === 'yes' ? badge('Published', 'good') : badge('Draft', 'warn')) },
        { key: '_updated_at', label: 'Changed', format: (v) => el('span', { class: 'oc-value' }, `${age(v)} ago`) },
      ],
      empty: 'No articles yet. Write the answers the team gives most: the agent drafts from them.',
    });
    return el('div', { class: 'oc-stack oc-stack--loose' }, [
      el('header', { class: 'hd-head' }, [
        el('div', {}, [
          el('h1', { class: 'oc-h1 oc-h1--collection' }, 'Knowledge base'),
          el('p', { class: 'oc-help hd-lede' }, 'The agent drafts every reply from the published articles and the conversation, and states nothing else about your product, prices or policies. Keep them short and true.'),
        ]),
        router.link('/kb/new', 'New article', { class: 'oc-btn oc-btn--primary' }),
      ]),
      list,
    ]);
  });
}

export function edit(params) {
  const fresh = params.id === 'new';
  Orch.load('view', async () => {
    const a = fresh ? {} : await Orch.db.get(T.articles, Number(params.id));
    if (!a) return el('div', { class: 'oc-state' }, [el('p', { class: 'oc-state__title' }, 'This article is not here.'), router.link('/kb', 'All articles')]);
    const title = el('input', { class: 'oc-input', value: a.title || '', maxlength: '160', required: true });
    const body = el('textarea', { class: 'oc-textarea hd-article', rows: '14' }, a.body || '');
    const tags = el('input', { class: 'oc-input', value: a.tags || '', maxlength: '200' });
    const published = el('select', { class: 'oc-select' }, [
      el('option', { value: 'yes', selected: a.published !== 'no' }, 'Published: the agent uses it'),
      el('option', { value: 'no', selected: a.published === 'no' }, 'Draft: the agent does not see it yet'),
    ]);
    const save = el('button', { class: 'oc-btn oc-btn--primary', type: 'submit' }, fresh ? 'Add article' : 'Save');
    const form = el('form', { class: 'oc-card oc-stack hd-form' }, [
      field('Title', title, 'The question as a customer would ask it works best.'),
      field('Answer', body, 'Plain text. What is true today, with the steps; the agent adapts the wording to each customer.'),
      field('Tags', tags, 'Words customers use for this, separated by commas. They help the agent find it.'),
      field('State', published),
      el('div', { class: 'oc-row' }, [save, router.link('/kb', 'Cancel', { class: 'oc-btn oc-btn--ghost' })]),
    ]);
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      if (!title.value.trim() || !body.value.trim()) { Orch.toast('An article needs a title and an answer.', { error: true }); return; }
      save.disabled = true;
      const data = { title: title.value.trim(), body: body.value.trim(), tags: tags.value.trim(), published: published.value };
      const r = fresh ? await act(A.addArticle, data, 'Article added.') : await act(A.updateArticle, Object.assign({ id: a._id }, data), 'Saved.');
      save.disabled = false;
      if (r) router.go(fresh && r._id ? `/kb/${r._id}` : '/kb');
    });
    return el('div', { class: 'oc-stack' }, [
      router.link('/kb', '← Knowledge base', { class: 'oc-small' }),
      el('h1', { class: 'oc-h1' }, fresh ? 'New article' : (a.title || 'Untitled')),
      form,
    ]);
  });
}
