// Reports: what customers ask most and how fast we answer. Tickets per day,
// the categories ranked, and the first response (median and the 75th
// percentile: three in four were answered faster than that). Spam is left out.
import { T, V, settings, duration, plural } from '../data.js';

const { el, router, fmt } = Orch;
const PERIODS = [['7d', '7 days', 7], ['30d', '30 days', 30], ['90d', '90 days', 90]];

/** The value below which `p` of the sorted numbers fall. */
function percentile(sorted, p) {
  if (!sorted.length) return null;
  const i = (sorted.length - 1) * p;
  const lo = Math.floor(i);
  return sorted[lo] + (sorted[Math.min(lo + 1, sorted.length - 1)] - sorted[lo]) * (i - lo);
}

export function render(params) {
  const [key, label, days] = PERIODS.find((p) => p[0] === params.period) || PERIODS[1];
  Orch.load('view', async () => {
    const from = new Date(Date.now() - (days - 1) * 86400000).toISOString().slice(0, 10);
    const [s, vol, firsts, solved] = await Promise.all([
      settings(),
      Orch.db.view(V.volume, { filter: { day: { gte: from } }, sort: 'day:asc', limit: 500 }).then((r) => r.rows || []),
      Orch.db.view(V.first, { filter: { day: { gte: from } }, sort: 'day:asc', limit: 500 }).then((r) => r.rows || []),
      Orch.db.count(T.tickets, { filter: { solved_at: { gte: from } } }),
    ]);
    const total = vol.reduce((n, r) => n + Number(r.n || 0), 0);
    const mins = firsts.map((r) => Number(r.minutes)).filter((m) => Number.isFinite(m) && m >= 0).sort((a, b) => a - b);
    const slaMin = (Number(s.sla_hours) || 24) * 60;
    const inTime = mins.length ? Math.round((mins.reduce((n, m) => n + (m <= slaMin ? 1 : 0), 0) / mins.length) * 100) : null;
    return el('div', { class: 'oc-stack oc-stack--loose' }, [
      el('header', { class: 'hd-head' }, [
        el('div', {}, [el('h1', { class: 'oc-h1 oc-h1--collection' }, 'Reports'), el('p', { class: 'oc-eyebrow' }, `Last ${label} · spam left out`)]),
        el('nav', { class: 'oc-segmented', 'aria-label': 'Period' }, PERIODS.map(([k, l]) =>
          router.link(`/reports/${k}`, l, { class: 'oc-segmented__item', 'aria-current': k === key ? 'true' : 'false' }))),
      ]),
      el('div', { class: 'oc-metrics hd-kpis hd-kpis--4' }, [
        metric('Tickets', fmt.number(total), 'Opened in the period'),
        metric('First response, median', duration(percentile(mins, 0.5)), `Half were answered faster (${plural(mins.length, 'ticket', 'tickets')} answered)`),
        metric('First response, p75', duration(percentile(mins, 0.75)), 'Three in four were answered faster'),
        metric('Within SLA', inTime === null ? '—' : `${inTime}%`, `First answer within ${s.sla_hours || 24} h · ${plural(solved, 'ticket', 'tickets')} solved`),
      ]),
      total ? perDay(vol, from, days) : el('div', { class: 'oc-card oc-state' }, el('p', { class: 'oc-state__title' }, 'No tickets in this period.')),
      total ? byCategory(vol, firsts, total) : null,
    ]);
  });
}

function metric(label, value, hint) {
  return el('div', { class: 'oc-metric oc-metric--compact' }, [
    el('span', { class: 'oc-kpi__label' }, label), el('span', { class: 'oc-kpi__value' }, value), el('span', { class: 'oc-help' }, hint),
  ]);
}

function perDay(vol, from, days) {
  const byDay = new Map();
  for (const r of vol) byDay.set(r.day, (byDay.get(r.day) || 0) + Number(r.n || 0));
  const rows = [];
  for (let i = 0; i < days; i += 1) {
    const d = new Date(Date.parse(`${from}T12:00:00Z`) + i * 86400000).toISOString().slice(0, 10);
    rows.push({ x: fmt.date(`${d}T12:00:00Z`, { day: 'numeric', month: 'short' }), tickets: byDay.get(d) || 0 });
  }
  return el('section', { class: 'oc-card' }, [
    el('h2', { class: 'oc-h2 hd-card-title' }, 'Tickets per day'),
    Orch.chart({ rows, x: 'x', kind: 'bar', height: 200, series: [{ key: 'tickets', label: 'Tickets' }] }),
  ]);
}

function byCategory(vol, firsts, total) {
  const count = new Map();
  for (const r of vol) count.set(r.category, (count.get(r.category) || 0) + Number(r.n || 0));
  const times = new Map();
  for (const r of firsts) { if (!times.has(r.category)) times.set(r.category, []); times.get(r.category).push(Number(r.minutes)); }
  const rows = [...count.entries()].sort((a, b) => b[1] - a[1]);
  return el('section', { class: 'oc-card oc-card--pad0' }, [
    el('h2', { class: 'oc-h2 hd-card-title hd-pad' }, 'What customers ask'),
    el('ul', { class: 'hd-rows' }, [
      el('li', { class: 'hd-row hd-row--cat hd-row--head' }, [el('span', { class: 'oc-eyebrow' }, 'Category'), el('span', { class: 'oc-eyebrow' }, 'Tickets'),
        el('span', { class: 'oc-eyebrow' }, 'Share'), el('span', { class: 'oc-eyebrow' }, 'First response')]),
      ...rows.map(([cat, n]) => {
        const t = (times.get(cat) || []).filter(Number.isFinite).sort((a, b) => a - b);
        return el('li', { class: 'hd-row hd-row--cat' }, [
          el('span', { class: 'hd-row__name' }, cat), el('span', { class: 'oc-value' }, fmt.number(n)),
          el('span', { class: 'oc-value' }, `${Math.round((n / total) * 100)}%`), el('span', { class: 'oc-value' }, duration(percentile(t, 0.5))),
        ]);
      }),
    ]),
  ]);
}
