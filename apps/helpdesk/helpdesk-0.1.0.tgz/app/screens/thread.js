// The conversation of one ticket, oldest first, and under it the reply: the
// agent's draft when there is one (edit it, then Send), or an empty reply
// with the signature. Nothing leaves without Send. A reply that failed shows
// why, with Retry, Edit and retry, and Drop right on it. Notes stay inside
// the team.
import { A, act, sendApproved, badge, stamp, isPaused } from '../data.js';

const { el } = Orch;

export function conversation(t, msgs, s, macros, again) {
  const shown = [];
  let draft = null; // the latest draft; dropped replies are not shown
  for (const m of msgs) { if (m.status === 'Draft') draft = m; else if (m.status !== 'Dropped') shown.push(m); }
  return [
    el('section', { class: 'hd-thread', 'aria-label': 'Conversation' }, shown.length ? shown.map((m) => message(m, t, again)) : el('p', { class: 'oc-help' }, 'No messages yet.')),
    agentState(t, draft, again),
    t.status === 'Spam' ? null : composer(t, draft, s, macros, again),
    note(t, again),
  ];
}

function message(m, t, again) {
  const mine = m.direction === 'out';
  const kind = m.direction === 'note' ? 'note' : mine ? 'out' : 'in';
  const by = kind === 'in' ? (m.sender || t.requester_email) : kind === 'note' ? `Note · ${m.sender || 'team'}` : `Reply · ${m.approved_by || m.sender || 'team'}`;
  const state = mine && m.status !== 'Sent' ? badge(m.status === 'Approved' || m.status === 'Sending' ? 'Sending' : m.status) : null;
  return el('article', { class: `hd-msg hd-msg--${kind}${m.status === 'Failed' ? ' hd-msg--failed' : ''}` }, [
    el('header', { class: 'hd-msg__head' }, [el('span', { class: 'oc-eyebrow' }, by), state, el('span', { class: 'oc-value hd-msg__at' }, stamp(m.at || m.sent_at || m._created_at))]),
    el('div', { class: 'hd-msg__body' }, m.body || ''),
    m.status === 'Failed' ? failed(m, again) : null,
  ]);
}

/** A failed reply's way out, on the reply itself. */
function failed(m, again) {
  const retry = el('button', { class: 'oc-btn oc-btn--sm oc-btn--primary', type: 'button' }, 'Retry');
  const edit = el('button', { class: 'oc-btn oc-btn--sm', type: 'button' }, 'Edit and retry');
  const drop = el('button', { class: 'oc-btn oc-btn--sm oc-btn--ghost', type: 'button' }, 'Drop');
  const box = el('div', { class: 'hd-failed oc-stack oc-stack--tight' }, [
    el('p', { class: 'hd-failed__why' }, m.error || 'It did not go out.'),
    el('div', { class: 'oc-row' }, [retry, edit, drop]),
  ]);
  retry.addEventListener('click', async () => {
    if (/may have gone out/.test(m.error || '') && !(await Orch.confirm('It may already have gone out. Send it again anyway?', { yes: 'Send again' }))) return;
    retry.disabled = true;
    if (await act(A.retry, { id: m._id }, 'Sending again.')) { await sendApproved(); later(again); } else retry.disabled = false;
  });
  drop.addEventListener('click', async () => {
    if (await Orch.confirm('Drop this reply? It stays out of the conversation and is never sent.', { yes: 'Drop it' }) && await act(A.drop, { id: m._id }, 'Dropped.')) again();
  });
  edit.addEventListener('click', () => {
    const text = el('textarea', { class: 'oc-textarea hd-reply', rows: '8', 'aria-label': 'Reply' }, m.body || '');
    const go = el('button', { class: 'oc-btn oc-btn--sm oc-btn--primary', type: 'button' }, 'Send edited');
    go.addEventListener('click', async () => {
      if (!text.value.trim()) { Orch.toast('The reply is empty.', { error: true }); return; }
      go.disabled = true;
      if (await act(A.retry, { id: m._id, body: text.value }, 'Sending the edited reply.')) { await sendApproved(); later(again); } else go.disabled = false;
    });
    Orch.mount(box, [el('p', { class: 'hd-failed__why' }, m.error || ''), text, el('div', { class: 'oc-row' }, [go, drop])]);
    text.focus();
  });
  return box;
}

/** What the agent is doing with this ticket, when it is not a draft below. */
function agentState(t, draft, again) {
  if (draft || t.status === 'Spam') return null;
  const ask = el('button', { class: 'oc-btn oc-btn--sm', type: 'button' }, 'Draft again');
  ask.addEventListener('click', async () => { ask.disabled = true; if (await act(A.redraft, { id: t._id }, 'Asked the agent for a new draft.')) later(again, 8000); });
  if (t.triage === 'Pending' || t.triage === 'Working') {
    const look = el('button', { class: 'oc-btn oc-btn--sm oc-btn--ghost', type: 'button' }, 'Look again');
    look.addEventListener('click', again);
    return el('p', { class: 'hd-agent oc-help' }, ['The agent is reading this and writing a draft. ', look]);
  }
  if (t.triage === 'Failed') return el('div', { class: 'hd-agent hd-agent--bad oc-help' }, [`No draft: ${t.triage_note || 'the agent could not write one'}. Write the reply yourself, or `, ask]);
  if (t.triage === 'Done' && t.triage_note) return el('div', { class: 'hd-agent oc-help' }, [`The agent suggests no reply: ${t.triage_note}. `, ask]);
  return null;
}

function composer(t, draft, s, macros, again) {
  const sig = String(s.signature || '').trim();
  const text = el('textarea', { class: 'oc-textarea hd-reply', rows: '10', 'aria-label': 'Reply to the customer' }, draft ? draft.body : (sig ? `\n\n${sig}` : ''));
  const where = t.channel === 'form'
    ? `Goes to ${t.requester_email} from your connected Gmail.`
    : `Goes to ${t.requester_email} from the workspace address, in the same conversation.`;
  const send = el('button', { class: 'oc-btn oc-btn--primary', type: 'button' }, 'Send');
  const solve = el('button', { class: 'oc-btn', type: 'button' }, 'Send and solve');
  const keep = draft ? el('button', { class: 'oc-btn oc-btn--ghost', type: 'button' }, 'Save draft') : null;
  const toss = draft ? el('button', { class: 'oc-btn oc-btn--ghost', type: 'button' }, 'Discard draft') : null;
  const macro = macros.length ? el('select', { class: 'oc-select oc-select--sm hd-macro', 'aria-label': 'Insert a saved reply' }, [
    el('option', { value: '' }, 'Insert a saved reply…'), ...macros.map((m) => el('option', { value: String(m._id) }, m.name)),
  ]) : null;
  if (macro) {
    macro.addEventListener('change', () => {
      const m = macros.find((x) => String(x._id) === macro.value);
      if (m) { const i = text.selectionStart || 0; text.value = `${text.value.slice(0, i)}${m.body}${text.value.slice(i)}`; text.focus(); }
      macro.value = '';
    });
  }
  const busy = (on) => [send, solve, keep, toss].forEach((b) => { if (b) b.disabled = on; });
  const go = async (then) => {
    const body = text.value.trim();
    if (!body || body === sig) { Orch.toast('Write the reply first.', { error: true }); return; }
    busy(true);
    const params = { body, then_status: then };
    const ok = draft ? await act(A.approve, Object.assign({ id: draft._id }, params)) : await act(A.reply, Object.assign({ ticket_id: t._id }, params));
    if (!ok) { busy(false); return; }
    Orch.toast(isPaused(s) ? 'Approved. It goes out when Helpdesk is resumed.' : 'Sending…');
    await sendApproved();
    later(again);
  };
  send.addEventListener('click', () => go('Pending'));
  solve.addEventListener('click', () => go('Solved'));
  if (keep) keep.addEventListener('click', async () => { busy(true); await act(A.saveDraft, { id: draft._id, body: text.value }, 'Draft saved.'); busy(false); });
  if (toss) toss.addEventListener('click', async () => { if (await Orch.confirm('Discard the agent\'s draft?', { yes: 'Discard' }) && await act(A.discard, { id: draft._id }, 'Discarded.')) again(); });
  return el('section', { class: `oc-card hd-compose${draft ? ' hd-compose--draft' : ''}`, 'aria-label': 'Reply' }, [
    el('div', { class: 'hd-compose__head' }, [
      el('h2', { class: 'oc-h2' }, draft ? 'Draft by the agent' : 'Reply'),
      draft ? badge('Review, then send', 'warn') : null,
      macro,
    ]),
    draft ? el('p', { class: 'oc-help' }, 'Read it against the conversation and correct anything that is not right. Nothing is sent until you press Send.') : null,
    text,
    el('p', { class: 'oc-help' }, where),
    el('div', { class: 'oc-row hd-compose__actions' }, [send, solve, keep, toss]),
  ]);
}

function note(t, again) {
  const text = el('textarea', { class: 'oc-textarea', rows: '2', 'aria-label': 'Internal note' });
  const add = el('button', { class: 'oc-btn oc-btn--sm', type: 'button' }, 'Add note');
  add.addEventListener('click', async () => {
    if (!text.value.trim()) return;
    add.disabled = true;
    if (await act(A.note, { ticket_id: t._id, body: text.value.trim() }, 'Note added.')) again(); else add.disabled = false;
  });
  return el('details', { class: 'hd-note' }, [
    el('summary', {}, 'Internal note'),
    el('div', { class: 'oc-stack oc-stack--tight' }, [el('p', { class: 'oc-help' }, 'Only the team sees notes. The agent reads them as context, never sends them.'), text, el('div', { class: 'oc-row' }, add)]),
  ]);
}

/** Look again in a moment (the send or the draft runs on the instance), unless the screen changed meanwhile. */
function later(again, ms = 3500) {
  const here = location.hash;
  setTimeout(() => { if (location.hash === here) again(); }, ms);
}
