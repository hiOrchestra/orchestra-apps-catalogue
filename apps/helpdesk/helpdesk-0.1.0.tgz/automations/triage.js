'use strict';
/**
 * Helpdesk · Triage and draft, the two script steps around the agent's turn:
 *
 *   node triage.js pick    claims up to 5 tickets waiting for triage and prints what the
 *                          agent needs: each conversation, the categories, the tone and
 *                          the knowledge-base articles closest to what was asked
 *   node triage.js save    the agent's answer ($PRIOR) checked ticket by ticket and saved:
 *                          category (when none yet), priority (only ever raised), summary,
 *                          and the reply as a Draft. Nothing is sent: a person presses Send.
 *
 * The agent never writes to the database and never sends. A ticket it did not
 * answer for goes back to the queue (three tries, then Failed with the reason,
 * and "Draft again" on its screen). A ticket that changed meanwhile (a new
 * message arrived, a person marked it spam) is left alone: the `when` fails.
 * Urgent tickets are told to the team on Telegram.
 *   node triage.js pick|save [--dry-run]
 */
const L = require('./lib');

const CLAIM = 5;
const STALE_MIN = 30;
const TRIES = 3;
const PRIORITIES = ['Low', 'Normal', 'High', 'Urgent'];
const rank = (p) => Math.max(0, PRIORITIES.indexOf(p));

const FORMAT = {
  tickets: [{
    id: 'the ticket id, as given',
    category: 'exactly one of `categories`',
    priority: 'Low | Normal | High | Urgent (Urgent only when something is down, money is lost, or there is a deadline today)',
    summary: 'one sentence for the team: who wants what',
    draft: 'the reply to send, in the customer\'s language, plain text; or null when no reply is due (spam, an auto-reply, a thank-you)',
    reason: 'only when draft is null: why no reply is due',
  }],
};

// ── pick ─────────────────────────────────────────────────────────────────
function words(text) {
  return new Set(String(text || '').toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '')
    .split(/[^a-z0-9]+/).filter((w) => w.length > 3));
}

/**
 * The articles the agent reads. A small knowledge base goes whole: the agent
 * matches meaning across languages ("contraseña" finds "password"), which
 * shared words cannot. A big one: the 6 that share the most words with what was asked.
 */
const WHOLE_KB = 12;
function articlesFor(text) {
  const asked = words(text);
  const all = L.all("SELECT title, body, tags FROM hd_articles WHERE _deleted = 0 AND published = 'yes' ORDER BY _id");
  if (all.length <= WHOLE_KB) return all.map((a) => ({ title: a.title, body: String(a.body || '').slice(0, 2500) }));
  return all
    .map((a) => { const w = words(`${a.title} ${a.tags} ${a.body}`); let n = 0; for (const x of asked) if (w.has(x)) n += 1; return { a, n }; })
    .filter((x) => x.n > 0).sort((x, y) => y.n - x.n).slice(0, 6)
    .map(({ a }) => ({ title: a.title, body: String(a.body || '').slice(0, 2500) }));
}

function pick(dry = false) {
  const s = L.settings();
  if (L.paused(s)) return { skip: true, why: 'Helpdesk is paused' };
  const now = L.sqlNow();
  if (!dry) {
    // A claim whose run died: back to the queue, or Failed after its tries.
    const stale = L.all(`SELECT _id, triage_attempts FROM hd_tickets WHERE _deleted = 0 AND triage = 'Working'
      AND datetime(triage_at) < datetime('now', '-${STALE_MIN} minutes')`);
    for (const t of stale) {
      const out = Number(t.triage_attempts) >= TRIES;
      try {
        L.write([{ op: 'update', table: 'hd_tickets', id: t._id, when: { triage: 'Working' },
          data: out ? { triage: 'Failed', triage_note: `The agent did not finish a draft in ${TRIES} tries` } : { triage: 'Pending' } }]);
      } catch { /* moved on meanwhile */ }
    }
  }
  const waiting = L.all(`SELECT * FROM hd_tickets WHERE _deleted = 0 AND triage = 'Pending' AND status NOT IN ('Spam', 'Closed')
    ORDER BY CASE priority WHEN 'Urgent' THEN 1 WHEN 'High' THEN 2 WHEN 'Normal' THEN 3 ELSE 4 END, _id LIMIT ${CLAIM * 2}`);
  const claimed = [];
  for (const t of waiting) {
    if (claimed.length >= CLAIM) break;
    try {
      if (!dry) {
        L.write([{ op: 'update', table: 'hd_tickets', id: t._id, when: { triage: 'Pending' },
          data: { triage: 'Working', triage_at: now, triage_attempts: Number(t.triage_attempts || 0) + 1 } }]);
      }
      claimed.push(t);
    } catch { /* another run has it */ }
  }
  if (!claimed.length) return { skip: true, why: 'No ticket is waiting for a draft' };
  const tickets = claimed.map((t) => {
    const msgs = L.all(`SELECT direction, sender, body, at, status FROM hd_messages WHERE _deleted = 0 AND ticket_id = ?
      AND (direction IN ('in', 'note') OR status = 'Sent') ORDER BY _id DESC LIMIT 12`, t._id).reverse();
    const before = L.one("SELECT COUNT(*) AS n FROM hd_tickets WHERE _deleted = 0 AND requester_email = ? AND _id < ? AND status <> 'Spam'", t.requester_email || '', t._id).n;
    return {
      id: t._id, subject: t.subject, channel: t.channel, customer_name: t.requester_name || null, earlier_tickets: before,
      messages: msgs.map((m) => ({ from: m.direction === 'in' ? 'customer' : m.direction === 'note' ? 'internal note (team only)' : 'us',
        at: m.at, text: String(m.body || '').slice(0, 3000) })),
    };
  });
  const asked = tickets.map((t) => `${t.subject} ${t.messages.filter((m) => m.from === 'customer').map((m) => m.text).join(' ')}`).join(' ');
  return {
    skip: false, ids: claimed.map((t) => t._id), dry: dry || undefined,
    categories: L.categoriesOf(s), priorities: PRIORITIES, tone: s.tone || '', articles: articlesFor(asked),
    answer_format: FORMAT, tickets,
  };
}

// ── save ─────────────────────────────────────────────────────────────────
/** The agent's JSON, wherever it is: bare, fenced, or inside the step wrapper's `content`. */
function jsonIn(text) {
  const t = String(text || '').replace(/```(?:json)?/gi, '');
  const a = t.indexOf('{');
  const b = t.lastIndexOf('}');
  if (a < 0 || b <= a) return null;
  let j;
  try { j = JSON.parse(t.slice(a, b + 1)); } catch { return null; }
  if (j && !Array.isArray(j.tickets) && typeof j.content === 'string') return jsonIn(j.content);
  return j;
}

/** One answer item checked: what may be saved, or why not. */
function check(item, cats) {
  if (!item || typeof item !== 'object') return { ok: false, why: 'The agent did not answer for this ticket' };
  const category = cats.find((c) => c.toLowerCase() === String(item.category || '').trim().toLowerCase()) || null;
  const priority = PRIORITIES.find((p) => p.toLowerCase() === String(item.priority || '').trim().toLowerCase()) || 'Normal';
  const summary = String(item.summary || '').replace(/\s+/g, ' ').trim().slice(0, 300);
  let draft = item.draft === null || item.draft === undefined ? null : String(item.draft).replace(/\r\n/g, '\n').trim();
  if (draft === '') draft = null;
  if (draft && draft.length > 8000) return { ok: false, why: 'The draft was longer than 8,000 characters' };
  if (draft && /^\s*\{[\s\S]*\}\s*$/.test(draft)) return { ok: false, why: 'The draft was JSON, not a reply' };
  return { ok: true, category, priority, summary, draft, reason: String(item.reason || '').trim().slice(0, 300) };
}

function withSignature(draft, signature) {
  const sig = String(signature || '').trim();
  return !sig || draft.includes(sig) ? draft : `${draft}\n\n${sig}`;
}

function save(dry = false) {
  const s = L.settings();
  const picked = jsonIn(process.env.STEP_pick || process.env.STEP_step_1 || '') || {};
  if (picked.skip) return { ok: true, skipped: picked.why || 'Nothing was picked' };
  const given = jsonIn(process.env.PRIOR) || {};
  const answers = new Map((Array.isArray(given.tickets) ? given.tickets : []).map((x) => [String(x && x.id), x]));
  const ids = (Array.isArray(picked.ids) ? picked.ids : [...answers.keys()]).map(Number).filter(Number.isInteger);
  const cats = L.categoriesOf(s);
  const agent = process.env.ORCHESTRA_AGENT_ID || s.agent || 'agent';
  const out = { ok: true, drafts: 0, no_reply: 0, retry: 0, failed: 0, changed: 0, urgent: [], dry: dry || undefined, would: dry ? [] : undefined };
  for (const id of ids) {
    const t = L.one('SELECT * FROM hd_tickets WHERE _id = ? AND _deleted = 0', id);
    if (!t || (!dry && t.triage !== 'Working')) { out.changed += 1; continue; }
    const c = check(answers.get(String(id)), cats);
    const ops = [];
    if (!c.ok) {
      const last = Number(t.triage_attempts) >= TRIES;
      ops.push({ op: 'update', table: 'hd_tickets', id, when: { triage: 'Working' },
        data: last ? { triage: 'Failed', triage_note: c.why } : { triage: 'Pending', triage_note: c.why } });
      out[last ? 'failed' : 'retry'] += 1;
    } else {
      const data = { triage: 'Done', triage_note: c.draft ? '' : (c.reason || 'The agent suggests no reply is due'), summary: c.summary || t.summary || null };
      if (!t.category && c.category) data.category = c.category;
      if (rank(c.priority) > rank(t.priority)) data.priority = c.priority;
      ops.push({ op: 'update', table: 'hd_tickets', id, when: { triage: 'Working' }, data });
      for (const d of L.all("SELECT _id FROM hd_messages WHERE _deleted = 0 AND ticket_id = ? AND status = 'Draft'", id)) {
        ops.push({ op: 'update', table: 'hd_messages', id: d._id, when: { status: 'Draft' }, data: { status: 'Dropped', error: 'Replaced by a newer draft' } });
      }
      if (c.draft) {
        ops.push({ op: 'insert', table: 'hd_messages', data: { ticket_id: id, direction: 'out', status: 'Draft', sender: agent, drafted_by: agent,
          body: withSignature(c.draft, s.signature), at: L.sqlNow() } });
      }
      out[c.draft ? 'drafts' : 'no_reply'] += 1;
      if (data.priority === 'Urgent') out.urgent.push({ id, subject: t.subject, summary: data.summary });
    }
    if (dry) { out.would.push(ops); continue; }
    try { L.write(ops); } catch (e) {
      out.changed += 1; // a new message or a person got there first: the next triage sees it
      out.urgent = out.urgent.filter((u) => u.id !== id);
    }
  }
  if (out.urgent.length && !dry) {
    out.notified = L.telegram(s.telegram_chat, ['Helpdesk · urgent', ...out.urgent.map((u) => `#${u.id} ${u.subject}${u.summary ? ` — ${u.summary}` : ''}\n${L.ticketLink(s, u.id)}`.trim())].join('\n'));
  }
  const left = L.one("SELECT COUNT(*) AS n FROM hd_tickets WHERE _deleted = 0 AND triage = 'Pending' AND status NOT IN ('Spam', 'Closed')").n;
  if (left && !dry && !L.paused(s)) out.next = Object.assign({ waiting: left }, L.kick('triage'));
  return out;
}

if (require.main === module) {
  const [cmd] = process.argv.slice(2);
  const dry = process.argv.includes('--dry-run');
  let out;
  try { out = cmd === 'pick' ? pick(dry) : cmd === 'save' ? save(dry) : { ok: false, error: 'node triage.js pick|save [--dry-run]' }; } catch (e) { out = { ok: false, error: e.message }; }
  L.done(out);
}

module.exports = { pick, save, jsonIn, check, articlesFor };
