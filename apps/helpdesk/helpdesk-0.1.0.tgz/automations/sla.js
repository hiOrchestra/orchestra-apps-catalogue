'use strict';
/**
 * Helpdesk · SLA reminder. Tickets whose customer has waited longer than the
 * first-response hours in Settings (status New or Open, our last word older
 * than theirs) are told to the team on Telegram, once per wait: a ticket is
 * named again only after the customer writes again. The hourly schedule only
 * runs when one is overdue and not yet told (workflows/sla.where).
 *   node sla.js [--dry-run]
 */
const L = require('./lib');

/** Tickets waiting past the SLA that nobody was told about for this wait. */
function overdue(s) {
  const hours = Number(s.sla_hours) > 0 ? Number(s.sla_hours) : 24;
  return L.all(`SELECT _id, subject, priority, requester_name, requester_email, COALESCE(last_inbound_at, opened_at, _created_at) AS since
    FROM hd_tickets WHERE _deleted = 0 AND status IN ('New', 'Open')
      AND (last_outbound_at IS NULL OR datetime(last_outbound_at) < datetime(last_inbound_at))
      AND datetime(COALESCE(last_inbound_at, opened_at, _created_at)) < datetime('now', ?)
      AND (sla_warned_at IS NULL OR datetime(sla_warned_at) < datetime(COALESCE(last_inbound_at, opened_at, _created_at)))
    ORDER BY CASE priority WHEN 'Urgent' THEN 1 WHEN 'High' THEN 2 WHEN 'Normal' THEN 3 ELSE 4 END, since`, `-${hours} hours`);
}

function waited(since) {
  const h = Math.floor((Date.now() - L.toDate(since).getTime()) / 3600000);
  return h >= 48 ? `${Math.floor(h / 24)} days` : `${h} h`;
}

function run(dry = false) {
  const s = L.settings();
  const list = overdue(s);
  if (!list.length) return L.done({ ok: true, overdue: 0 });
  const lines = list.slice(0, 10).map((t) => `#${t._id} ${t.subject} — ${t.requester_name || t.requester_email}, waiting ${waited(t.since)}${t.priority === 'Urgent' || t.priority === 'High' ? ` (${t.priority})` : ''}`);
  const text = ['Helpdesk · past the first-response time', ...lines, list.length > 10 ? `and ${list.length - 10} more` : '', s.desk_url ? `${s.desk_url}#/q/overdue` : '']
    .filter(Boolean).join('\n');
  if (dry) return L.done({ ok: true, overdue: list.length, would: text });
  const notified = L.telegram(s.telegram_chat, text);
  // Only what was told is marked; with no chat set, the desk's Overdue count still shows them.
  if (notified.sent) L.write(list.map((t) => ({ op: 'update', table: 'hd_tickets', id: t._id, data: { sla_warned_at: L.sqlNow() } })));
  return L.done({ ok: true, overdue: list.length, notified });
}

if (require.main === module) {
  try { run(process.argv.includes('--dry-run')); } catch (e) { L.done({ ok: false, error: e.message }); process.exitCode = 1; }
}

module.exports = { run, overdue };
