'use strict';
/**
 * Helpdesk · Intake. Turns what arrived into tickets and messages, no agent:
 *
 *   the public form   every hd_requests row still New is checked again here
 *                     (the page is not trusted): the bot trap, the minimum
 *                     time, a valid address, a message, the same sending
 *                     twice. A good one becomes a ticket (channel form) with
 *                     its first message; the rest stay, marked Spam or
 *                     Rejected with the reason.
 *   the instance mail GET /api/email/inbox since the last run (minus an
 *                     overlap), only the dispositions Settings names (by
 *                     default mail nobody was woken for: inbox, unverified).
 *                     Each thread with something new is read whole
 *                     (GET /api/email/threads/:id) and its inbound messages
 *                     not seen yet join the thread's ticket, or open one.
 *                     Dedup is the unique external_id (the mail's id); mail
 *                     we sent is never read back (only direction "in").
 *
 * A ticket that got a new message is marked for triage, and the triage
 * workflow is started when something is waiting (never while paused).
 * One run at a time (a lock); the `when` on every claim is the guarantee.
 *   node intake.js [--auto|--now|--form] [--dry-run]
 *     --form: only the public form (what the page starts); --auto/--now: both
 */
const L = require('./lib');

const BATCH = 100;
const OVERLAP_MS = 10 * 60000;
const FIRST_LOOK_MS = 3 * 86400000; // the first run reads the last three days
const OWN_DOMAIN = /@agents\.hiorchestra\.com$/i;
const MAX_BODY = 20000;

function run(mode = '--auto', dry = false) {
  const s = L.settings();
  const held = dry ? { release() {} } : L.lock('intake');
  if (!held) return L.done({ ok: true, mode, skipped: 'Another intake run is at work' });
  const out = { ok: true, mode, dry: dry || undefined, form: { tickets: 0, spam: 0, rejected: 0 }, email: null, triage: null };
  const plan = []; // what a dry run would have written
  const write = (ops) => (dry ? (plan.push(ops), ops.map(() => ({ _id: 0 }))) : L.write(ops));
  try {
    formRequests(out.form, write);
    if (mode !== '--form') out.email = mail(s, write, dry);
  } finally {
    held.release();
  }
  const waiting = L.one("SELECT COUNT(*) AS n FROM hd_tickets WHERE _deleted = 0 AND triage = 'Pending' AND status NOT IN ('Spam', 'Closed')").n;
  if (dry) out.would = plan;
  else if (waiting && !L.paused(s)) out.triage = Object.assign({ waiting }, L.kick('triage'));
  else if (waiting) out.triage = { waiting, started: false, why: 'Helpdesk is paused: no drafts until it is resumed' };
  return L.done(out);
}

// ── the public form ──────────────────────────────────────────────────────
function verdict(r) {
  if (String(r.hp || '').trim()) return { status: 'Spam', problem: 'A field only bots see was filled' };
  if (Number.isFinite(Number(r.ms)) && Number(r.ms) < 3000) return { status: 'Spam', problem: 'Sent in under 3 seconds' };
  const email = String(r.email || '').trim().toLowerCase();
  if (!L.EMAIL.test(email) || email.length > 200) return { status: 'Rejected', problem: 'The email address is not valid' };
  if (!String(r.message || '').trim()) return { status: 'Rejected', problem: 'The message is empty' };
  if (r.visit) {
    const twin = L.one("SELECT _id FROM hd_requests WHERE visit = ? AND _id < ? AND _deleted = 0 AND status = 'Done' LIMIT 1", String(r.visit), r._id);
    if (twin) return { status: 'Rejected', problem: `Sent twice: the same message arrived before as #${twin._id}` };
  }
  return { status: 'Done', email };
}

function formRequests(tally, write) {
  const seen = new Set();
  for (;;) {
    const rows = L.all(`SELECT * FROM hd_requests WHERE _deleted = 0 AND status = 'New'${seen.size ? ` AND _id NOT IN (${[...seen].join(',')})` : ''} ORDER BY _id LIMIT ${BATCH}`);
    for (const r of rows) {
      seen.add(r._id);
      const v = verdict(r);
      const done = { op: 'update', table: 'hd_requests', id: r._id, when: { status: 'New' }, data: { status: v.status, problem: v.problem || null, processed_at: L.sqlNow() } };
      const ops = [];
      if (v.status === 'Done') {
        const name = String(r.name || '').trim().slice(0, 120);
        const message = String(r.message).trim().slice(0, MAX_BODY);
        const at = L.sqlOf(r._created_at) || L.sqlNow();
        ops.push({ op: 'insert', table: 'hd_tickets', as: 't', data: {
          subject: String(r.subject || '').trim().slice(0, 200) || message.split('\n')[0].slice(0, 80),
          requester_email: v.email, requester_name: name, channel: 'form', request_id: r._id,
          status: 'New', priority: 'Normal', triage: 'Pending', triage_attempts: 0, opened_at: at, last_inbound_at: at } });
        ops.push({ op: 'insert', table: 'hd_messages', data: { ticket_id: '$t._id', direction: 'in', sender: name ? `${name} <${v.email}>` : v.email,
          body: message, at, external_id: `form:${r._id}` } });
        done.data.ticket_id = '$t._id';
      }
      ops.push(done);
      try {
        write(ops);
        tally[v.status === 'Done' ? 'tickets' : v.status.toLowerCase()] += 1;
      } catch (e) {
        if (!/precondition/.test(e.message)) tally.failed = (tally.failed || 0) + 1;
      }
    }
    if (rows.length < BATCH) break;
  }
}

// ── the instance's mail ──────────────────────────────────────────────────
/** The customer's own words: the quoted history under "On … wrote:" is cut when there is text above it. */
function ownWords(text) {
  const t = String(text || '').replace(/\r\n/g, '\n');
  const lines = t.split('\n');
  const cut = lines.findIndex((l, i) => i > 0 && (/^\s*(On|El|Le|Am) .{4,200}(wrote|escribió|a écrit|schrieb):\s*$/i.test(l) || /^-{2,}\s*(Original Message|Mensaje original)/i.test(l)));
  const kept = cut > 0 ? lines.slice(0, cut).join('\n') : t;
  return (kept.trim() || t.trim()).slice(0, MAX_BODY);
}
const plain = (html) => String(html || '').replace(/<(style|script)[\s\S]*?<\/\1>/gi, '').replace(/<br\s*\/?>|<\/p>|<\/div>/gi, '\n')
  .replace(/<[^>]+>/g, '').replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/\n{3,}/g, '\n\n');

function mail(s, write, dry) {
  const res = { tickets: 0, messages: 0, threads: 0, skipped: 0, error: null };
  const cursor = L.toDate(s.email_cursor);
  const since = new Date(cursor ? cursor.getTime() - OVERLAP_MS : Date.now() - FIRST_LOOK_MS).toISOString();
  const box = L.mailInbox({ since, limit: BATCH });
  if (!box.ok) {
    res.error = `The instance mailbox did not answer: ${box.why}`;
    if (!dry) L.write([{ op: 'update', table: 'hd_settings', id: s._id, data: { intake_at: L.sqlNow(), intake_note: res.error } }]);
    return res;
  }
  const doors = new Set(String(s.intake_from || 'inbox,unverified').split(/[\s,]+/).filter(Boolean));
  const known = (id) => !!L.one('SELECT 1 AS x FROM hd_messages WHERE external_id = ?', String(id));
  const threads = new Set();
  for (const m of box.messages) {
    if (!m || !m.id || !m.threadId) continue;
    if (!doors.has(String(m.disposition || 'inbox')) || OWN_DOMAIN.test(L.bareAddress(m.from)) || known(m.id)) { res.skipped += 1; continue; }
    threads.add(m.threadId);
  }
  for (const threadId of threads) {
    const t = L.mailThread(threadId);
    if (!t.ok) { res.error = `Thread ${threadId} could not be read: ${t.why}`; continue; }
    const inbound = (t.thread.messages || []).filter((m) => m.direction === 'in' && m.id && !known(m.id));
    if (!inbound.length) continue;
    res.threads += 1;
    const ticket = L.one("SELECT * FROM hd_tickets WHERE _deleted = 0 AND channel = 'email' AND thread_id = ? ORDER BY _id DESC LIMIT 1", threadId);
    const first = inbound[0];
    const last = inbound[inbound.length - 1];
    const lastAt = L.sqlOf(last.receivedAt) || L.sqlNow();
    const ops = [];
    let ref;
    if (ticket) {
      ref = ticket._id;
      const data = { last_inbound_at: lastAt };
      if (['Pending', 'Solved', 'Closed'].includes(ticket.status)) data.status = 'Open';
      if (ticket.status !== 'Spam') Object.assign(data, { triage: 'Pending', triage_attempts: 0 });
      ops.push({ op: 'update', table: 'hd_tickets', id: ticket._id, data });
    } else {
      ref = '$t._id';
      ops.push({ op: 'insert', table: 'hd_tickets', as: 't', data: {
        subject: String(first.subject || '(No subject)').slice(0, 200), requester_email: L.bareAddress(first.from), requester_name: L.nameOf(first.from).slice(0, 120),
        channel: 'email', thread_id: threadId, status: 'New', priority: 'Normal', triage: 'Pending', triage_attempts: 0,
        opened_at: L.sqlOf(first.receivedAt) || L.sqlNow(), last_inbound_at: lastAt } });
      res.tickets += 1;
    }
    for (const m of inbound) {
      ops.push({ op: 'insert', table: 'hd_messages', data: { ticket_id: ref, direction: 'in', sender: String(m.from || '').slice(0, 300),
        body: ownWords(m.textBody || plain(m.htmlBody)) || '(No text)', at: L.sqlOf(m.receivedAt) || L.sqlNow(), external_id: String(m.id) } });
    }
    try {
      write(ops);
      res.messages += inbound.length;
    } catch (e) {
      res.error = `Thread ${threadId} could not be saved: ${e.message.slice(0, 200)}`;
      if (!ticket) res.tickets -= 1;
    }
  }
  const newest = box.messages.map((m) => L.toDate(m.receivedAt)).filter(Boolean).sort((a, b) => b - a)[0];
  if (box.messages.length >= BATCH) res.note = `The mailbox returned ${BATCH} messages at once: run Check now again if some are missing`;
  const data = { intake_at: L.sqlNow(), intake_note: res.error || res.note || `${res.messages} new ${res.messages === 1 ? 'message' : 'messages'}` };
  if (newest && (!cursor || newest > cursor)) data.email_cursor = newest.toISOString();
  if (!dry) L.write([{ op: 'update', table: 'hd_settings', id: s._id, data }]);
  return res;
}

if (require.main === module) {
  const args = process.argv.slice(2);
  const mode = ['--auto', '--now', '--form'].find((m) => args.includes(m)) || '--auto';
  try { run(mode, args.includes('--dry-run')); } catch (e) { L.done({ ok: false, error: e.message }); process.exitCode = 1; }
}

module.exports = { run, verdict, ownWords };
