'use strict';
/**
 * What every Helpdesk script shares: reading the project's database, writing
 * to it, talking to the instance as the workflow's agent (email, Composio,
 * Telegram, starting a workflow), and the one JSON line a step leaves.
 *
 * Adapted from apps/forms/automations/lib.js (the de-facto SDK). Reads go to
 * the project's SQLite file directly, read-only and parameterised; every write
 * goes through `orch-database batch`: one transaction, and a `when`
 * precondition checked inside the UPDATE, so "this reply is mine to send" is
 * atomic.
 *
 * Off the instance (HD_LOCAL=1) the same batch runs against HD_DB with the
 * same semantics, and everything that would leave the machine is faked:
 *   HD_FAKE_MAIL=<file.json>   the instance mailbox ({ messages: [...] }, the backend's shapes)
 *   HD_FAKE_COMPOSIO=1         GMAIL_SEND_EMAIL answers like Composio; fail@… is refused
 *   HD_OUTBOX=<file>           every reply, Gmail send, Telegram notice and workflow start, one JSON a line
 */
const { DatabaseSync } = require('node:sqlite');
const { execFileSync } = require('child_process');
const fs = require('fs');
const os = require('os');
const path = require('path');

const PROJECT = process.env.HD_PROJECT || (__dirname.match(/projects\/([^/]+)\/apps\/helpdesk/) || [])[1] || 'default';
const STATE = process.env.OPENCLAW_STATE_DIR || '/home/node/.openclaw';
const DB_PATH = process.env.HD_DB || path.join(STATE, 'orchestra', 'projects', PROJECT, 'data', 'data.db');
const LOCAL = process.env.HD_LOCAL === '1';

// ── reading ──────────────────────────────────────────────────────────────
let reader = null;
function db() {
  if (!reader) {
    reader = new DatabaseSync(DB_PATH, { readOnly: true });
    reader.exec('PRAGMA busy_timeout = 5000');
  }
  return reader;
}
const all = (sql, ...params) => db().prepare(sql).all(...params);
const one = (sql, ...params) => db().prepare(sql).get(...params);

function settings() {
  const s = one('SELECT * FROM hd_settings WHERE _deleted = 0 ORDER BY _id LIMIT 1');
  if (!s) throw new Error('Helpdesk has no settings row: it is not installed in this project');
  return s;
}
const paused = (s) => String(s.paused || '').toLowerCase() === 'yes';

/** JSON kept in a text column, or the fallback when it is empty or not JSON. */
function jsonOf(text, fallback) {
  if (text === null || text === undefined || text === '') return fallback;
  if (typeof text === 'object') return text;
  try { return JSON.parse(text); } catch { return fallback; }
}

/** The categories in Settings: a JSON list, or a comma list someone typed. */
function categoriesOf(s) {
  const v = jsonOf(s.categories, null);
  const list = Array.isArray(v) ? v : String(s.categories || '').split(',');
  return [...new Set(list.map((x) => String(x).trim()).filter(Boolean))].slice(0, 30);
}

// ── writing ──────────────────────────────────────────────────────────────
/** One transaction per chunk, all or nothing; the inserted ids in order. Chunks stay under the 128 KB argv limit. */
function write(ops) {
  const chunks = [];
  let cur = [];
  let size = 0;
  for (const op of ops) {
    const n = JSON.stringify(op).length;
    if (cur.length && size + n > 90000) { chunks.push(cur); cur = []; size = 0; }
    cur.push(op);
    size += n;
  }
  if (cur.length) chunks.push(cur);
  const results = [];
  for (const chunk of chunks) results.push(...((LOCAL ? localBatch(chunk) : cliBatch(chunk)).results || []));
  return results;
}

function cliBatch(ops) {
  let out;
  try {
    out = execFileSync('orch-database', ['--project', PROJECT, 'batch', '--ops', JSON.stringify(ops)],
      { encoding: 'utf8', timeout: 60000, maxBuffer: 16 << 20 });
  } catch (e) {
    let j = null;
    try { j = JSON.parse(String(e.stdout || '')); } catch { /* not JSON */ }
    throw new Error((j && j.error) || String(e.stderr || e.message).trim().slice(0, 300));
  }
  const j = JSON.parse(out);
  if (!j.ok) throw new Error(j.error || 'the write failed');
  return j;
}

/** orch-database's run_batch, for local tests: same `as`/`$name._id`, same `when`, same all-or-none. */
function localBatch(ops) {
  const w = new DatabaseSync(DB_PATH);
  w.exec('PRAGMA busy_timeout = 5000');
  const now = sqlNow();
  const named = {};
  const deref = (v) => {
    if (typeof v !== 'string' || !v.startsWith('$')) return v;
    const key = v.slice(1).split('.')[0];
    if (!named[key]) throw new Error(`reference ${v} names a step that has not run`);
    return named[key]._id;
  };
  const results = [];
  w.exec('BEGIN IMMEDIATE');
  try {
    ops.forEach((op, i) => {
      const data = {};
      for (const [k, v] of Object.entries(op.data || {})) if (!k.startsWith('_')) data[k] = deref(v);
      if (op.op === 'insert') {
        const cols = [...Object.keys(data), '_created_at', '_updated_at'];
        const r = w.prepare(`INSERT INTO "${op.table}" (${cols.map((c) => `"${c}"`).join(', ')}) VALUES (${cols.map(() => '?').join(', ')})`)
          .run(...Object.values(data), now, now);
        const id = Number(r.lastInsertRowid);
        if (op.as) named[op.as] = { _id: id };
        results.push({ op: 'insert', table: op.table, _id: id });
      } else {
        const when = op.when || {};
        const id = deref(op.id);
        const r = w.prepare(`UPDATE "${op.table}" SET ${Object.keys(data).map((c) => `"${c}" = ?`).join(', ')}, _updated_at = ? `
          + `WHERE _id = ? AND _deleted = 0${Object.keys(when).map((c) => ` AND "${c}" IS ?`).join('')}`)
          .run(...Object.values(data), now, id, ...Object.values(when));
        if (!r.changes) throw new Error(`op ${i}: row ${id} changed meanwhile (precondition failed)`);
        results.push({ op: 'update', table: op.table, _id: id });
      }
    });
    w.exec('COMMIT');
  } catch (e) {
    w.exec('ROLLBACK');
    w.close();
    throw e;
  }
  w.close();
  return { ok: true, applied: results.length, results };
}

// ── one run at a time ────────────────────────────────────────────────────
const STALE_MS = 150000; // longer than a script step may run (120 s): a file this old was left by a killed run

/**
 * A lock file per agent and job, so a burst (ten people pressing Send, the
 * public form and the schedule at once) has one run doing the work instead of
 * ten racing for the same rows. It saves work; the `when` on every claim is
 * what keeps a reply from going out twice.
 *   lock('send') -> { release() }, or null when another run holds it
 */
function lock(name) {
  let who = process.env.ORCHESTRA_AGENT_ID;
  if (!who) { try { who = os.userInfo().username; } catch { who = 'node'; } }
  const file = path.join(process.env.HD_LOCK_DIR || os.tmpdir(), `orchestra-helpdesk-${PROJECT}-${who}-${name}.lock`);
  const held = { file, release() { try { fs.unlinkSync(file); } catch { /* already gone */ } } };
  for (let i = 0; i < 2; i += 1) {
    try {
      fs.writeFileSync(file, String(process.pid), { flag: 'wx' });
      return held;
    } catch (e) {
      if (e.code !== 'EEXIST') return { file: null, release() {} };
      let age;
      try { age = Date.now() - fs.statSync(file).mtimeMs; } catch { continue; }
      if (age < STALE_MS) return null;
      try { fs.unlinkSync(file); } catch { /* another run took it over first */ }
    }
  }
  return null;
}

// ── time ─────────────────────────────────────────────────────────────────
/** 'YYYY-MM-DD HH:MM:SS' in UTC: the format orch-database stamps rows with. */
const sqlNow = (d = new Date()) => d.toISOString().slice(0, 19).replace('T', ' ');

/** '2026-10-03 10:00:00' (UTC) or an ISO string as a Date. */
function toDate(v) {
  if (!v) return null;
  const s = String(v).trim();
  const iso = s.includes('T') ? s : s.replace(' ', 'T');
  const d = new Date(/[zZ]|[+-]\d\d:?\d\d$/.test(iso) ? iso : `${iso}Z`);
  return Number.isNaN(d.getTime()) ? null : d;
}
const sqlOf = (v) => { const d = toDate(v); return d ? sqlNow(d) : null; };

// ── addresses ────────────────────────────────────────────────────────────
const EMAIL = /^[^\s@<>"',;]+@[^\s@<>"',;]+\.[^\s@<>"',;]{2,}$/;
/** 'Ana Pérez <ana@example.com>' → 'ana@example.com' */
function bareAddress(from) {
  const s = String(from || '').trim();
  const m = s.match(/<([^>]+)>/);
  return (m ? m[1] : s).trim().toLowerCase();
}
/** 'Ana Pérez <ana@example.com>' → 'Ana Pérez' (or '' when there is no name) */
function nameOf(from) {
  const s = String(from || '').trim();
  const m = s.match(/^\s*"?([^"<]*?)"?\s*<[^>]+>\s*$/);
  return m ? m[1].trim() : '';
}

// ── the instance, as this workflow's agent ───────────────────────────────
function identityHeaders() {
  const id = process.env.ORCHESTRA_AGENT_ID;
  const token = process.env.ORCHESTRA_AGENT_TOKEN;
  if (id && token) return { 'x-orchestra-agent': id, 'x-orchestra-agent-token': token };
  const secret = process.env.HOOKS_TOKEN || process.env.OPENCLAW_GATEWAY_TOKEN || '';
  return secret ? { 'x-orchestra-secret': secret } : {};
}

/**
 * One call to the api-server on 127.0.0.1. Headers go to curl on stdin (-K -),
 * never argv, so the token is not in the process list. Never throws:
 *   { ok: true, data }  or  { ok: false, why, code, uncertain }
 * `uncertain` is a timeout or a dropped connection: the server may have acted.
 */
function api(method, route, { body, query, timeoutS = 30 } = {}) {
  const q = (v) => `"${String(v).replace(/[\\"]/g, '\\$&')}"`;
  const qs = query ? Object.entries(query).filter(([, v]) => v !== undefined && v !== null && v !== '')
    .map(([k, v]) => `${encodeURIComponent(k)}=${encodeURIComponent(String(v))}`).join('&') : '';
  const config = [
    `url = ${q(`http://127.0.0.1:${Number(process.env.API_SERVER_PORT || 3001)}${route}${qs ? `?${qs}` : ''}`)}`,
    `request = ${q(method)}`,
    'header = "Content-Type: application/json"',
    ...Object.entries(identityHeaders()).map(([k, v]) => `header = ${q(`${k}: ${v}`)}`),
    ...(body === undefined ? [] : [`data = ${q(JSON.stringify(body))}`]),
  ].join('\n');
  try {
    const out = execFileSync('curl', ['-sS', '-m', String(timeoutS), '-K', '-'], { input: config, timeout: (timeoutS + 5) * 1000, stdio: ['pipe', 'pipe', 'pipe'] }).toString();
    let j = null;
    try { j = JSON.parse(out); } catch { /* reported below */ }
    if (j && j.success) return { ok: true, data: j.data };
    const e = j && j.error;
    return { ok: false, code: (e && e.code) || null, why: String((e && (e.message || e)) || out || 'no answer').trim().slice(0, 300) };
  } catch (e) {
    // curl 28 = timed out, 52 = empty reply, 56 = connection reset: the other side may have acted.
    const uncertain = [28, 52, 56].includes(e.status);
    return { ok: false, uncertain, why: String((e.stderr && e.stderr.toString()) || e.message).trim().slice(0, 300) };
  }
}

// ── outbox: what a local run would have sent ─────────────────────────────
const sent = [];
function record(kind, data) {
  const entry = Object.assign({ kind }, data);
  sent.push(entry);
  if (process.env.HD_OUTBOX) fs.appendFileSync(process.env.HD_OUTBOX, `${JSON.stringify(entry)}\n`);
  return entry;
}

// ── the instance's email (ORC-159) ───────────────────────────────────────
// GET  /api/email/inbox?since=ISO&limit=N → { messages: [{ id, threadId, from, to, subject, preview, disposition, receivedAt, … }] } (inbound only, newest first)
// GET  /api/email/threads/:id             → { threadId, messages: [{ id, direction, from, to, subject, textBody, htmlBody, disposition, receivedAt, … }] }
// POST /api/email/reply { threadId, text } → { ok, messageId, threadId, to }  (refusals: recipient_refused, thread_cap, …)
const fakeMail = () => (process.env.HD_FAKE_MAIL ? jsonOf(fs.readFileSync(process.env.HD_FAKE_MAIL, 'utf8'), { messages: [] }) : null);

function mailInbox({ since, limit = 100 } = {}) {
  const box = fakeMail();
  if (box) {
    const t = since ? toDate(since) : null;
    const messages = box.messages.filter((m) => m.direction === 'in' && (!t || toDate(m.receivedAt) >= t))
      .sort((a, b) => toDate(b.receivedAt) - toDate(a.receivedAt)).slice(0, limit);
    return { ok: true, messages };
  }
  if (LOCAL) return { ok: false, why: 'No mailbox here (HD_FAKE_MAIL is not set)' };
  const r = api('GET', '/api/email/inbox', { query: { since, limit } });
  return r.ok ? { ok: true, messages: (r.data && r.data.messages) || [] } : r;
}

function mailThread(threadId) {
  const box = fakeMail();
  if (box) {
    const messages = box.messages.filter((m) => m.threadId === threadId).sort((a, b) => toDate(a.receivedAt) - toDate(b.receivedAt));
    return messages.length ? { ok: true, thread: { threadId, messages } } : { ok: false, code: 'NOT_FOUND', why: 'Thread not found' };
  }
  if (LOCAL) return { ok: false, why: 'No mailbox here' };
  const r = api('GET', `/api/email/threads/${encodeURIComponent(threadId)}`);
  return r.ok ? { ok: true, thread: r.data } : r;
}

function mailReply(threadId, text) {
  const box = fakeMail();
  if (box) {
    const last = box.messages.filter((m) => m.threadId === threadId).pop();
    if (!last) return { ok: false, code: 'thread_not_found', why: 'Thread not found' };
    if (/refused/.test(last.from)) return { ok: false, code: 'recipient_refused', why: `${bareAddress(last.from)} is not a member, not on the sender list, and has not written in the last 30 days` };
    if (/timeout/.test(last.from)) return { ok: false, uncertain: true, why: 'curl: (28) Operation timed out after 30001 milliseconds' };
    const messageId = `fake-out-${Math.random().toString(36).slice(2, 10)}`;
    box.messages.push({ id: messageId, threadId, direction: 'out', from: 'support@acme.agents.example', to: [bareAddress(last.from)],
      subject: `Re: ${last.subject}`, textBody: text, receivedAt: new Date().toISOString() });
    fs.writeFileSync(process.env.HD_FAKE_MAIL, JSON.stringify(box));
    record('reply', { threadId, to: bareAddress(last.from), text });
    return { ok: true, data: { ok: true, messageId, threadId, to: [bareAddress(last.from)] } };
  }
  if (LOCAL) return { ok: false, why: 'No mailbox here' };
  return api('POST', '/api/email/reply', { body: { threadId, text }, timeoutS: 45 });
}

// ── Composio: the tenant's own Gmail ─────────────────────────────────────
/** POST /api/composio/execute { toolSlug, arguments, account? } → { ok, data } | { ok: false, why, uncertain } */
function composio(slug, args, account) {
  if (process.env.HD_FAKE_COMPOSIO === '1') {
    if (slug !== 'GMAIL_SEND_EMAIL') return { ok: false, why: `fake Composio has no ${slug}` };
    if (/^fail@/.test(String(args.recipient_email))) return { ok: false, why: 'Gmail refused the message: invalid To header (fake)' };
    if (/^slow@/.test(String(args.recipient_email))) return { ok: false, uncertain: true, why: 'curl: (28) Operation timed out (fake)' };
    const id = `fake-gmail-${Math.random().toString(36).slice(2, 10)}`;
    record('gmail', Object.assign({ account: account || null }, args));
    return { ok: true, data: { successful: true, data: { id, threadId: id, labelIds: ['SENT'] } } };
  }
  const body = { toolSlug: slug, arguments: args };
  if (account) body.account = account;
  const r = api('POST', '/api/composio/execute', { body, timeoutS: 60 });
  if (!r.ok) return r;
  if (r.data && r.data.successful === false) return { ok: false, why: String(r.data.error || 'Composio said it failed').slice(0, 300) };
  return r;
}

/** The first `key` anywhere in a nested answer (Composio wraps data in data). */
function pick(obj, key, depth = 0) {
  if (!obj || typeof obj !== 'object' || depth > 5) return undefined;
  if (obj[key] !== undefined && obj[key] !== null && typeof obj[key] !== 'object') return obj[key];
  for (const v of Object.values(obj)) { const hit = pick(v, key, depth + 1); if (hit !== undefined) return hit; }
  return undefined;
}

// ── starting another workflow (the ids install.js wrote) ─────────────────
function workflowIds() {
  try { return JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'workflows.json'), 'utf8')); } catch { return {}; }
}
/** Start Helpdesk's own workflow `key` (triage, send). It carries no data: the run finds its work. */
function kick(key, args = {}) {
  if (LOCAL || process.env.HD_FAKE_KICK === '1') { record('kick', { workflow: key, args }); return { started: true, fake: true }; }
  const id = workflowIds()[key];
  if (!id) return { started: false, why: `No ${key} workflow recorded (reinstall Helpdesk)` };
  const r = api('POST', `/api/platform/workflows/${encodeURIComponent(id)}/run`, { body: { execute: true, argsJson: JSON.stringify(args) } });
  return r.ok ? { started: true, runId: r.data && r.data.runId } : { started: false, why: r.why };
}

// ── telling the team ─────────────────────────────────────────────────────
const TG_CHAT = /^(-?\d{5,20}|@[A-Za-z0-9_]{5,32})$/;
function telegram(to, text) {
  const chat = String(to || '').trim();
  if (!chat) return { sent: false, why: 'No Telegram chat in Settings' };
  if (!TG_CHAT.test(chat)) return { sent: false, why: 'The Telegram chat in Settings is not a chat id or @username' };
  const message = String(text || '').slice(0, 3800);
  if (LOCAL || process.env.HD_FAKE_NOTIFY === '1') { record('telegram', { to: chat, message }); return { sent: true, to: chat, fake: true, message }; }
  const r = api('POST', '/api/channels/telegram/notify', { body: { to: chat, message } });
  return r.ok ? { sent: true, to: chat } : { sent: false, to: chat, why: r.why };
}

/** The one JSON line a workflow step leaves as its output. */
function done(result) {
  process.stdout.write(`${JSON.stringify(result)}\n`);
  return result;
}

/** A link to one ticket in the desk, when Settings knows where the desk lives. */
const ticketLink = (s, id) => (s.desk_url ? `${s.desk_url}#/t/${id}` : '');

module.exports = {
  PROJECT, DB_PATH, LOCAL, all, one, settings, paused, jsonOf, categoriesOf, write, lock, sqlNow, toDate, sqlOf,
  EMAIL, bareAddress, nameOf, identityHeaders, api, record, sent, mailInbox, mailThread, mailReply, composio, pick,
  kick, telegram, done, ticketLink,
};
