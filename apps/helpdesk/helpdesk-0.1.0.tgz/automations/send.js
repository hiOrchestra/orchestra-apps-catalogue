'use strict';
/**
 * Helpdesk · Send. Every reply a person approved (status Approved) goes out,
 * exactly as they approved it:
 *
 *   email tickets  POST /api/email/reply { threadId, text } — the instance's
 *                  own address answers into the customer's thread (the
 *                  platform allows it: they wrote first; at most 5 an hour
 *                  per thread)
 *   form tickets   Composio GMAIL_SEND_EMAIL from the team's connected Gmail
 *                  ({ recipient_email, subject, body, is_html: false }): the
 *                  person never wrote to the instance address, so it may not
 *                  write to them
 *
 * Each reply is claimed first (Approved → Sending, atomic), so two runs never
 * send the same one. A failure is saved on the reply with what to do, and
 * waits for a person (Retry, Edit and retry, Drop) — never retried blindly. A
 * Sending left by a run that died is marked Failed and says it may have gone
 * out. Nothing goes out while Helpdesk is paused: approved replies wait.
 *   node send.js [--auto|--now] [--dry-run]
 */
const L = require('./lib');

const BUDGET_MS = 90000;
const STUCK_MIN = 10;

const MEANING = {
  recipient_refused: 'The workspace address may only answer someone who wrote in the last 30 days. Nothing went out.',
  thread_cap: 'Five replies already went into this conversation in the last hour. Nothing went out: retry later.',
  thread_not_found: 'The mail conversation is gone from the workspace address. Nothing went out.',
  inactive: 'The workspace email address is not active. Nothing went out.',
};

function explain(r, channel) {
  if (r.uncertain) return `No answer in time: it may have gone out. Check ${channel === 'form' ? 'Sent in Gmail' : 'the conversation'} before retrying. (${r.why})`;
  const code = String(r.code || '').toLowerCase();
  if (MEANING[code]) return `${MEANING[code]} (${r.why})`;
  if (channel === 'form' && /connect|auth|account|not found|no active/i.test(r.why || '')) return `Gmail did not take it: is Gmail connected (portal → Integrations)? Nothing went out. (${r.why})`;
  return `It did not go out: ${r.why || 'no reason given'}`;
}

function deliver(m, t, s) {
  const body = String(m.body || '').trim();
  if (!body) return { ok: false, error: 'The reply is empty. Nothing went out.' };
  if (t.channel === 'email') {
    if (!t.thread_id) return { ok: false, error: 'This ticket has no mail conversation to answer into. Nothing went out.' };
    const r = L.mailReply(t.thread_id, body);
    return r.ok ? { ok: true, external: String((r.data && r.data.messageId) || `email:${m._id}`) } : { ok: false, error: explain(r, 'email') };
  }
  if (!L.EMAIL.test(String(t.requester_email || ''))) return { ok: false, error: 'The customer\'s address is not valid. Nothing went out.' };
  const subject = /^re:/i.test(t.subject || '') ? t.subject : `Re: ${t.subject || 'your message'}`;
  const r = L.composio('GMAIL_SEND_EMAIL', { recipient_email: t.requester_email, subject, body, is_html: false }, s.gmail_account || undefined);
  if (!r.ok) return { ok: false, error: explain(r, 'form') };
  const id = L.pick(r.data, 'id');
  return { ok: true, external: `gmail:${id || m._id}` };
}

function run(mode = '--auto', dry = false) {
  const s = L.settings();
  const t0 = Date.now();
  if (L.paused(s)) {
    const n = L.one("SELECT COUNT(*) AS n FROM hd_messages WHERE _deleted = 0 AND status = 'Approved'").n;
    return L.done({ ok: true, mode, paused: true, waiting: n, why: 'Helpdesk is paused: approved replies wait until it is resumed' });
  }
  const held = dry ? { release() {} } : L.lock('send');
  if (!held) return L.done({ ok: true, mode, skipped: 'Another send run is at work' });
  const out = { ok: true, mode, dry: dry || undefined, sent: [], failed: [], stuck: 0 };
  try {
    if (!dry) {
      for (const m of L.all(`SELECT _id FROM hd_messages WHERE _deleted = 0 AND status = 'Sending' AND datetime(_updated_at) < datetime('now', '-${STUCK_MIN} minutes')`)) {
        try {
          L.write([{ op: 'update', table: 'hd_messages', id: m._id, when: { status: 'Sending' },
            data: { status: 'Failed', error: 'The send stopped half-way: it may have gone out. Check before retrying.' } }]);
          out.stuck += 1;
        } catch { /* finished meanwhile */ }
      }
    }
    const queue = L.all("SELECT * FROM hd_messages WHERE _deleted = 0 AND status = 'Approved' AND direction = 'out' ORDER BY _id LIMIT 50");
    for (const m of queue) {
      if (Date.now() - t0 > BUDGET_MS) break;
      const t = L.one('SELECT * FROM hd_tickets WHERE _id = ? AND _deleted = 0', Number(m.ticket_id));
      if (dry) { out.sent.push({ id: m._id, ticket: m.ticket_id, channel: t && t.channel, to: t && t.requester_email, would: true }); continue; }
      try {
        L.write([{ op: 'update', table: 'hd_messages', id: m._id, when: { status: 'Approved' }, data: { status: 'Sending' } }]);
      } catch { continue; } // dropped or taken meanwhile
      const r = !t || t.status === 'Spam' ? { ok: false, error: 'The ticket is gone or marked as spam. Nothing went out.' } : deliver(m, t, s);
      if (!r.ok) {
        L.write([{ op: 'update', table: 'hd_messages', id: m._id, data: { status: 'Failed', error: r.error.slice(0, 500) } }]);
        out.failed.push({ id: m._id, ticket: m.ticket_id, error: r.error });
        continue;
      }
      const now = L.sqlNow();
      const ops = [{ op: 'update', table: 'hd_messages', id: m._id, data: { status: 'Sent', sent_at: now, at: now, external_id: r.external, error: '' } }];
      const tdata = { last_outbound_at: now };
      if (!t.first_response_at) tdata.first_response_at = now;
      if (m.then_status === 'Solved') Object.assign(tdata, { status: 'Solved', solved_at: now });
      else if (['New', 'Open'].includes(t.status)) tdata.status = 'Pending';
      ops.push({ op: 'update', table: 'hd_tickets', id: t._id, data: tdata });
      for (const d of L.all("SELECT _id FROM hd_messages WHERE _deleted = 0 AND ticket_id = ? AND status = 'Draft'", t._id)) {
        ops.push({ op: 'update', table: 'hd_messages', id: d._id, when: { status: 'Draft' }, data: { status: 'Dropped', error: 'A reply went out without it' } });
      }
      try { L.write(ops); } catch (e) {
        // It went out: say so on the reply, whatever else failed.
        L.write([{ op: 'update', table: 'hd_messages', id: m._id, data: { status: 'Sent', sent_at: now, at: now, external_id: r.external } }]);
      }
      out.sent.push({ id: m._id, ticket: t._id, channel: t.channel, to: t.requester_email });
    }
  } finally {
    held.release();
  }
  return L.done(out);
}

if (require.main === module) {
  const args = process.argv.slice(2);
  const mode = ['--auto', '--now'].find((m) => args.includes(m)) || '--auto';
  try { run(mode, args.includes('--dry-run')); } catch (e) { L.done({ ok: false, error: e.message }); process.exitCode = 1; }
}

module.exports = { run, explain };
