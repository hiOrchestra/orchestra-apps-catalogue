SELECT date(COALESCE(t.opened_at, t._created_at)) AS day, COALESCE(NULLIF(t.category, ''), 'Uncategorised') AS category, COUNT(*) AS n
FROM hd_tickets t
WHERE t.status <> 'Spam' AND date(COALESCE(t.opened_at, t._created_at)) >= date('now', '-89 days')
GROUP BY day, category
