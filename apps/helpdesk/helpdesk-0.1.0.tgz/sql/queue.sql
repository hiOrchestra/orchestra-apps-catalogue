SELECT t._id, t.subject, t.requester_name, t.requester_email, t.channel, t.status, t.priority, t.category, t.assignee,
       t.summary, t.triage, t.opened_at, t.last_inbound_at, t.last_outbound_at, t.first_response_at, t.solved_at,
       CASE t.priority WHEN 'Urgent' THEN 1 WHEN 'High' THEN 2 WHEN 'Normal' THEN 3 ELSE 4 END
         || ' ' || COALESCE(t.last_inbound_at, t.opened_at, t._created_at) AS queue_key,
       CASE WHEN t.status IN ('New', 'Open')
             AND (t.last_outbound_at IS NULL OR datetime(t.last_outbound_at) < datetime(t.last_inbound_at))
            THEN 'yes' ELSE 'no' END AS awaiting,
       CASE WHEN t.status IN ('New', 'Open')
             AND (t.last_outbound_at IS NULL OR datetime(t.last_outbound_at) < datetime(t.last_inbound_at))
             AND datetime(COALESCE(t.last_inbound_at, t.opened_at, t._created_at))
                 < datetime('now', '-' || COALESCE((SELECT s.sla_hours FROM hd_settings s ORDER BY s._id LIMIT 1), 24) || ' hours')
            THEN 'yes' ELSE 'no' END AS overdue,
       CASE WHEN EXISTS (SELECT 1 FROM hd_messages m WHERE m.ticket_id = t._id AND m.status = 'Draft') THEN 'yes' ELSE 'no' END AS draft,
       CASE WHEN EXISTS (SELECT 1 FROM hd_messages m WHERE m.ticket_id = t._id AND m.status = 'Failed') THEN 'yes' ELSE 'no' END AS failed
FROM hd_tickets t
