SELECT t._id, COALESCE(NULLIF(t.category, ''), 'Uncategorised') AS category, t.channel, date(t.opened_at) AS day,
       CAST(ROUND((julianday(t.first_response_at) - julianday(t.opened_at)) * 1440) AS INTEGER) AS minutes
FROM hd_tickets t
WHERE t.first_response_at IS NOT NULL AND t.opened_at IS NOT NULL AND t.status <> 'Spam'
