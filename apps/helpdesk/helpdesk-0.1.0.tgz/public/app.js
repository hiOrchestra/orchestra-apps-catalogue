// The contact page. One form; what was typed is kept in this browser until
// it is sent, so a reload or a lost connection loses nothing. Sending: the
// public action `submit` (insert only), retried for about two minutes when
// the platform is busy (429) or the connection drops (5xx, none), then
// `process` asks Helpdesk to make it a ticket. The server checks everything
// again (the trap field, the time, the address): this page is not trusted.
const { el, router } = Orch;

const WAITS = [3, 6, 12, 20, 30, 30, 30]; // seconds between tries: about two minutes
const KEY = 'helpdesk.contact';
const T0 = Date.now();
const LANG = /^es\b/i.test(navigator.language || '') ? 'es' : 'en';
const W = {
  en: {
    title: 'Contact us', lede: 'Tell us what you need. A person from the team reads every message and answers by email.',
    name: 'Your name', email: 'Your email', emailHelp: 'We answer here.', subject: 'Subject', message: 'Your message',
    messageHelp: 'The more detail, the faster we can help: what you tried, what happened, any order or account number.',
    send: 'Send', sending: 'Sending…', retrying: 'The service is busy. Trying again in {s} s…',
    needName: 'Write your name.', needEmail: 'Write a valid email address, so we can answer.', needMessage: 'Write your message.',
    failed: 'It could not be sent. What you wrote is still here: try again in a moment.',
    doneTitle: 'Received', done: 'We answer by email at {email}. Look in your inbox, and in the spam folder just in case.',
    doneSmall: 'Nothing else to do here. If you need to add something, reply to our email when it arrives.', again: 'Write another message',
  },
  es: {
    title: 'Escríbenos', lede: 'Cuéntanos qué necesitas. Una persona del equipo lee cada mensaje y te responde por email.',
    name: 'Tu nombre', email: 'Tu email', emailHelp: 'Te respondemos aquí.', subject: 'Asunto', message: 'Tu mensaje',
    messageHelp: 'Cuanto más detalle, más rápido te ayudamos: qué intentaste, qué pasó, un número de pedido o de cuenta.',
    send: 'Enviar', sending: 'Enviando…', retrying: 'El servicio está ocupado. Lo intentamos de nuevo en {s} s…',
    needName: 'Escribe tu nombre.', needEmail: 'Escribe un email válido para poder responderte.', needMessage: 'Escribe tu mensaje.',
    failed: 'No se pudo enviar. Lo que escribiste sigue aquí: inténtalo de nuevo en un momento.',
    doneTitle: 'Recibido', done: 'Te respondemos por email a {email}. Mira tu bandeja de entrada y, por si acaso, la de spam.',
    doneSmall: 'No hace falta nada más. Si quieres agregar algo, responde a nuestro email cuando llegue.', again: 'Escribir otro mensaje',
  },
}[LANG];
const say = (k, vars) => String(W[k]).replace(/\{(\w+)\}/g, (_, n) => (vars && vars[n] !== undefined ? vars[n] : ''));
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const store = {
  get() { try { return JSON.parse(localStorage.getItem(KEY) || 'null') || {}; } catch { return {}; } },
  set(v) { try { localStorage.setItem(KEY, JSON.stringify(v)); } catch { /* private window: not kept */ } },
  drop() { try { localStorage.removeItem(KEY); } catch { /* nothing kept */ } },
};
const newId = () => (self.crypto && crypto.randomUUID ? crypto.randomUUID() : `${Date.now().toString(36)}${Math.random().toString(36).slice(2)}`);
document.documentElement.lang = LANG;
document.title = W.title;

// The app's own base, as the runtime computes it: a beacon needs it absolute.
const BASE = (() => {
  const p = location.pathname;
  const i = p.indexOf('/canvas/a/');
  return i < 0 ? '.' : `${p.slice(0, i)}/canvas/a/${p.slice(i + 10).split('/')[0]}`;
})();

function input(name, attrs) {
  const base = Object.assign({ class: attrs.tag === 'textarea' ? 'oc-textarea' : 'oc-input', name, id: `sp-${name}` }, attrs.attrs || {});
  if (attrs.tag === 'textarea') return el('textarea', base, attrs.value || '');
  return el('input', Object.assign(base, { value: attrs.value || '' }));
}
let sentTo = ''; // the address of the message just sent, for the thank-you (kept out of the URL)
function row(name, label, control, help) {
  return el('div', { class: 'oc-field' }, [el('label', { class: 'oc-label', for: `sp-${name}` }, label), control, help ? el('span', { class: 'oc-help' }, help) : null]);
}

function form() {
  const kept = store.get();
  const visit = kept.visit || newId(); // the same attempt twice is caught on the server
  const f = {
    name: input('name', { attrs: { autocomplete: 'name', maxlength: '120', required: true }, value: kept.name }),
    email: input('email', { attrs: { type: 'email', autocomplete: 'email', maxlength: '200', required: true, inputmode: 'email' }, value: kept.email }),
    subject: input('subject', { attrs: { maxlength: '200' }, value: kept.subject }),
    message: input('message', { tag: 'textarea', attrs: { rows: '7', maxlength: '20000', required: true }, value: kept.message }),
  };
  const trap = el('div', { class: 'sp-trap', 'aria-hidden': 'true' }, [el('label', {}, ['Website', el('input', { name: 'website', tabindex: '-1', autocomplete: 'off' })])]);
  const error = el('p', { class: 'sp-error', role: 'alert', hidden: true });
  const status = el('p', { class: 'sp-status oc-help', role: 'status' });
  const send = el('button', { class: 'oc-btn oc-btn--primary sp-send', type: 'submit' }, W.send);
  const node = el('form', { class: 'oc-card sp-form', novalidate: true }, [
    row('name', W.name, f.name), row('email', W.email, f.email, W.emailHelp), row('subject', W.subject, f.subject),
    row('message', W.message, f.message, W.messageHelp), trap, error, status, send,
  ]);
  const values = () => Object.fromEntries(Object.entries(f).map(([k, c]) => [k, c.value.trim()]));
  node.addEventListener('input', () => store.set(Object.assign(values(), { visit })));
  node.addEventListener('submit', async (e) => {
    e.preventDefault();
    const v = values();
    const wrong = !v.name ? ['name', 'needName'] : !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v.email) ? ['email', 'needEmail'] : !v.message ? ['message', 'needMessage'] : null;
    Object.values(f).forEach((c) => c.removeAttribute('aria-invalid'));
    if (wrong) {
      error.textContent = W[wrong[1]];
      error.hidden = false;
      f[wrong[0]].setAttribute('aria-invalid', 'true');
      f[wrong[0]].focus();
      return;
    }
    error.hidden = true;
    send.disabled = true;
    status.textContent = W.sending;
    const params = Object.assign(v, { hp: trap.querySelector('input').value, ms: Date.now() - T0, visit, lang: navigator.language || '' });
    try {
      await submit(params, status);
    } catch {
      status.textContent = '';
      error.textContent = W.failed;
      error.hidden = false;
      send.disabled = false;
      return;
    }
    store.drop();
    processNow();
    sentTo = v.email;
    router.go('/sent');
  });
  return node;
}

/** The message, sent; on a busy platform or a lost connection, again after a wait. */
async function submit(params, status) {
  for (let i = 0; ; i += 1) {
    try {
      return await Orch.action('submit', params);
    } catch (e) {
      const passing = !e.status || e.status === 429 || e.status >= 500;
      if (!passing || i >= WAITS.length) throw e;
      for (let s = WAITS[i]; s > 0; s -= 1) { status.textContent = say('retrying', { s }); await sleep(1000); }
      status.textContent = W.sending;
    }
  }
}

/**
 * Asks Helpdesk to make tickets of what arrived. It carries nothing: the run
 * looks for new messages itself. A beacon, so closing the tab right away does
 * not cancel it; if it is refused, the next 15-minute check takes it.
 */
function processNow() {
  const body = new Blob([JSON.stringify({ params: {} })], { type: 'application/json' });
  try {
    if (navigator.sendBeacon && navigator.sendBeacon(`${BASE}/api/actions/process`, body)) return;
  } catch { /* no beacon here: the plain call below */ }
  Orch.action('process', {}).catch(() => { /* picked up by the next check */ });
}

function page() {
  Orch.load('view', async () => [
    el('h1', { class: 'oc-h1' }, W.title),
    el('p', { class: 'oc-lede sp-lede' }, W.lede),
    form(),
  ]);
}

function sent() {
  if (!sentTo) { router.go('/', { replace: true }); return; } // a reload of the thank-you: back to the form
  const to = sentTo;
  const again = el('button', { class: 'oc-btn', type: 'button' }, W.again);
  again.addEventListener('click', () => router.go('/'));
  Orch.load('view', async () => [
    el('h1', { class: 'oc-h1', tabindex: '-1' }, W.doneTitle),
    el('section', { class: 'oc-card sp-done' }, [
      el('p', {}, say('done', { email: to || '—' })),
      el('p', { class: 'sp-small' }, W.doneSmall),
      el('div', {}, again),
    ]),
  ]);
}

router.define({ '/': page, '/sent': sent }, page).start();
