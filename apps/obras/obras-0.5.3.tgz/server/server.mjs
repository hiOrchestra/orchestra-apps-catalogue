// .stack/node_modules/@hono/node-server/dist/index.mjs
import { createServer as createServerHTTP } from "http";
import { Http2ServerRequest as Http2ServerRequest2 } from "http2";
import { Http2ServerRequest } from "http2";
import { Readable } from "stream";
import crypto from "crypto";
var RequestError = class extends Error {
  constructor(message, options) {
    super(message, options);
    this.name = "RequestError";
  }
};
var toRequestError = (e) => {
  if (e instanceof RequestError) {
    return e;
  }
  return new RequestError(e.message, { cause: e });
};
var GlobalRequest = global.Request;
var Request2 = class extends GlobalRequest {
  constructor(input, options) {
    if (typeof input === "object" && getRequestCache in input) {
      input = input[getRequestCache]();
    }
    if (typeof options?.body?.getReader !== "undefined") {
      ;
      options.duplex ??= "half";
    }
    super(input, options);
  }
};
var wrapBodyStream = Symbol("wrapBodyStream");
var newRequestFromIncoming = (method, url, incoming, abortController) => {
  const headerRecord = [];
  const rawHeaders = incoming.rawHeaders;
  for (let i = 0; i < rawHeaders.length; i += 2) {
    const { [i]: key, [i + 1]: value } = rawHeaders;
    if (key.charCodeAt(0) !== /*:*/
    58) {
      headerRecord.push([key, value]);
    }
  }
  const init = {
    method,
    headers: headerRecord,
    signal: abortController.signal
  };
  if (method === "TRACE") {
    init.method = "GET";
    const req = new Request2(url, init);
    Object.defineProperty(req, "method", {
      get() {
        return "TRACE";
      }
    });
    return req;
  }
  if (!(method === "GET" || method === "HEAD")) {
    if ("rawBody" in incoming && incoming.rawBody instanceof Buffer) {
      init.body = new ReadableStream({
        start(controller) {
          controller.enqueue(incoming.rawBody);
          controller.close();
        }
      });
    } else if (incoming[wrapBodyStream]) {
      let reader;
      init.body = new ReadableStream({
        async pull(controller) {
          try {
            reader ||= Readable.toWeb(incoming).getReader();
            const { done, value } = await reader.read();
            if (done) {
              controller.close();
            } else {
              controller.enqueue(value);
            }
          } catch (error) {
            controller.error(error);
          }
        }
      });
    } else {
      init.body = Readable.toWeb(incoming);
    }
  }
  return new Request2(url, init);
};
var getRequestCache = Symbol("getRequestCache");
var requestCache = Symbol("requestCache");
var incomingKey = Symbol("incomingKey");
var urlKey = Symbol("urlKey");
var abortControllerKey = Symbol("abortControllerKey");
var getAbortController = Symbol("getAbortController");
var requestPrototype = {
  get method() {
    return this[incomingKey].method || "GET";
  },
  get url() {
    return this[urlKey];
  },
  [getAbortController]() {
    this[getRequestCache]();
    return this[abortControllerKey];
  },
  [getRequestCache]() {
    this[abortControllerKey] ||= new AbortController();
    return this[requestCache] ||= newRequestFromIncoming(
      this.method,
      this[urlKey],
      this[incomingKey],
      this[abortControllerKey]
    );
  }
};
[
  "body",
  "bodyUsed",
  "cache",
  "credentials",
  "destination",
  "headers",
  "integrity",
  "mode",
  "redirect",
  "referrer",
  "referrerPolicy",
  "signal",
  "keepalive"
].forEach((k) => {
  Object.defineProperty(requestPrototype, k, {
    get() {
      return this[getRequestCache]()[k];
    }
  });
});
["arrayBuffer", "blob", "clone", "formData", "json", "text"].forEach((k) => {
  Object.defineProperty(requestPrototype, k, {
    value: function() {
      return this[getRequestCache]()[k]();
    }
  });
});
Object.setPrototypeOf(requestPrototype, Request2.prototype);
var newRequest = (incoming, defaultHostname) => {
  const req = Object.create(requestPrototype);
  req[incomingKey] = incoming;
  const incomingUrl = incoming.url || "";
  if (incomingUrl[0] !== "/" && // short-circuit for performance. most requests are relative URL.
  (incomingUrl.startsWith("http://") || incomingUrl.startsWith("https://"))) {
    if (incoming instanceof Http2ServerRequest) {
      throw new RequestError("Absolute URL for :path is not allowed in HTTP/2");
    }
    try {
      const url2 = new URL(incomingUrl);
      req[urlKey] = url2.href;
    } catch (e) {
      throw new RequestError("Invalid absolute URL", { cause: e });
    }
    return req;
  }
  const host = (incoming instanceof Http2ServerRequest ? incoming.authority : incoming.headers.host) || defaultHostname;
  if (!host) {
    throw new RequestError("Missing host header");
  }
  let scheme;
  if (incoming instanceof Http2ServerRequest) {
    scheme = incoming.scheme;
    if (!(scheme === "http" || scheme === "https")) {
      throw new RequestError("Unsupported scheme");
    }
  } else {
    scheme = incoming.socket && incoming.socket.encrypted ? "https" : "http";
  }
  const url = new URL(`${scheme}://${host}${incomingUrl}`);
  if (url.hostname.length !== host.length && url.hostname !== host.replace(/:\d+$/, "")) {
    throw new RequestError("Invalid host header");
  }
  req[urlKey] = url.href;
  return req;
};
var responseCache = Symbol("responseCache");
var getResponseCache = Symbol("getResponseCache");
var cacheKey = Symbol("cache");
var GlobalResponse = global.Response;
var Response2 = class _Response {
  #body;
  #init;
  [getResponseCache]() {
    delete this[cacheKey];
    return this[responseCache] ||= new GlobalResponse(this.#body, this.#init);
  }
  constructor(body, init) {
    let headers;
    this.#body = body;
    if (init instanceof _Response) {
      const cachedGlobalResponse = init[responseCache];
      if (cachedGlobalResponse) {
        this.#init = cachedGlobalResponse;
        this[getResponseCache]();
        return;
      } else {
        this.#init = init.#init;
        headers = new Headers(init.#init.headers);
      }
    } else {
      this.#init = init;
    }
    if (typeof body === "string" || typeof body?.getReader !== "undefined" || body instanceof Blob || body instanceof Uint8Array) {
      headers ||= init?.headers || { "content-type": "text/plain; charset=UTF-8" };
      this[cacheKey] = [init?.status || 200, body, headers];
    }
  }
  get headers() {
    const cache = this[cacheKey];
    if (cache) {
      if (!(cache[2] instanceof Headers)) {
        cache[2] = new Headers(cache[2]);
      }
      return cache[2];
    }
    return this[getResponseCache]().headers;
  }
  get status() {
    return this[cacheKey]?.[0] ?? this[getResponseCache]().status;
  }
  get ok() {
    const status = this.status;
    return status >= 200 && status < 300;
  }
};
["body", "bodyUsed", "redirected", "statusText", "trailers", "type", "url"].forEach((k) => {
  Object.defineProperty(Response2.prototype, k, {
    get() {
      return this[getResponseCache]()[k];
    }
  });
});
["arrayBuffer", "blob", "clone", "formData", "json", "text"].forEach((k) => {
  Object.defineProperty(Response2.prototype, k, {
    value: function() {
      return this[getResponseCache]()[k]();
    }
  });
});
Object.setPrototypeOf(Response2, GlobalResponse);
Object.setPrototypeOf(Response2.prototype, GlobalResponse.prototype);
async function readWithoutBlocking(readPromise) {
  return Promise.race([readPromise, Promise.resolve().then(() => Promise.resolve(void 0))]);
}
function writeFromReadableStreamDefaultReader(reader, writable, currentReadPromise) {
  const handleError = () => {
  };
  writable.on("error", handleError);
  (currentReadPromise ?? reader.read()).then(flow, handleStreamError);
  return reader.closed.finally(() => {
    writable.off("error", handleError);
  });
  function handleStreamError(error) {
    if (error) {
      writable.destroy(error);
    }
  }
  function onDrain() {
    reader.read().then(flow, handleStreamError);
  }
  function flow({ done, value }) {
    try {
      if (done) {
        writable.end();
      } else if (!writable.write(value)) {
        writable.once("drain", onDrain);
      } else {
        return reader.read().then(flow, handleStreamError);
      }
    } catch (e) {
      handleStreamError(e);
    }
  }
}
function writeFromReadableStream(stream, writable) {
  if (stream.locked) {
    throw new TypeError("ReadableStream is locked.");
  } else if (writable.destroyed) {
    return;
  }
  return writeFromReadableStreamDefaultReader(stream.getReader(), writable);
}
var buildOutgoingHttpHeaders = (headers) => {
  const res = {};
  if (!(headers instanceof Headers)) {
    headers = new Headers(headers ?? void 0);
  }
  const cookies = [];
  for (const [k, v] of headers) {
    if (k === "set-cookie") {
      cookies.push(v);
    } else {
      res[k] = v;
    }
  }
  if (cookies.length > 0) {
    res["set-cookie"] = cookies;
  }
  res["content-type"] ??= "text/plain; charset=UTF-8";
  return res;
};
var X_ALREADY_SENT = "x-hono-already-sent";
var webFetch = global.fetch;
if (typeof global.crypto === "undefined") {
  global.crypto = crypto;
}
global.fetch = (info, init) => {
  init = {
    // Disable compression handling so people can return the result of a fetch
    // directly in the loader without messing with the Content-Encoding header.
    compress: false,
    ...init
  };
  return webFetch(info, init);
};
var outgoingEnded = Symbol("outgoingEnded");
var handleRequestError = () => new Response(null, {
  status: 400
});
var handleFetchError = (e) => new Response(null, {
  status: e instanceof Error && (e.name === "TimeoutError" || e.constructor.name === "TimeoutError") ? 504 : 500
});
var handleResponseError = (e, outgoing) => {
  const err = e instanceof Error ? e : new Error("unknown error", { cause: e });
  if (err.code === "ERR_STREAM_PREMATURE_CLOSE") {
    console.info("The user aborted a request.");
  } else {
    console.error(e);
    if (!outgoing.headersSent) {
      outgoing.writeHead(500, { "Content-Type": "text/plain" });
    }
    outgoing.end(`Error: ${err.message}`);
    outgoing.destroy(err);
  }
};
var flushHeaders = (outgoing) => {
  if ("flushHeaders" in outgoing && outgoing.writable) {
    outgoing.flushHeaders();
  }
};
var responseViaCache = async (res, outgoing) => {
  let [status, body, header] = res[cacheKey];
  if (header instanceof Headers) {
    header = buildOutgoingHttpHeaders(header);
  }
  if (typeof body === "string") {
    header["Content-Length"] = Buffer.byteLength(body);
  } else if (body instanceof Uint8Array) {
    header["Content-Length"] = body.byteLength;
  } else if (body instanceof Blob) {
    header["Content-Length"] = body.size;
  }
  outgoing.writeHead(status, header);
  if (typeof body === "string" || body instanceof Uint8Array) {
    outgoing.end(body);
  } else if (body instanceof Blob) {
    outgoing.end(new Uint8Array(await body.arrayBuffer()));
  } else {
    flushHeaders(outgoing);
    await writeFromReadableStream(body, outgoing)?.catch(
      (e) => handleResponseError(e, outgoing)
    );
  }
  ;
  outgoing[outgoingEnded]?.();
};
var responseViaResponseObject = async (res, outgoing, options = {}) => {
  if (res instanceof Promise) {
    if (options.errorHandler) {
      try {
        res = await res;
      } catch (err) {
        const errRes = await options.errorHandler(err);
        if (!errRes) {
          return;
        }
        res = errRes;
      }
    } else {
      res = await res.catch(handleFetchError);
    }
  }
  if (cacheKey in res) {
    return responseViaCache(res, outgoing);
  }
  const resHeaderRecord = buildOutgoingHttpHeaders(res.headers);
  if (res.body) {
    const reader = res.body.getReader();
    const values = [];
    let done = false;
    let currentReadPromise = void 0;
    if (resHeaderRecord["transfer-encoding"] !== "chunked") {
      let maxReadCount = 2;
      for (let i = 0; i < maxReadCount; i++) {
        currentReadPromise ||= reader.read();
        const chunk = await readWithoutBlocking(currentReadPromise).catch((e) => {
          console.error(e);
          done = true;
        });
        if (!chunk) {
          if (i === 1) {
            await new Promise((resolve) => setTimeout(resolve));
            maxReadCount = 3;
            continue;
          }
          break;
        }
        currentReadPromise = void 0;
        if (chunk.value) {
          values.push(chunk.value);
        }
        if (chunk.done) {
          done = true;
          break;
        }
      }
      if (done && !("content-length" in resHeaderRecord)) {
        resHeaderRecord["content-length"] = values.reduce((acc, value) => acc + value.length, 0);
      }
    }
    outgoing.writeHead(res.status, resHeaderRecord);
    values.forEach((value) => {
      ;
      outgoing.write(value);
    });
    if (done) {
      outgoing.end();
    } else {
      if (values.length === 0) {
        flushHeaders(outgoing);
      }
      await writeFromReadableStreamDefaultReader(reader, outgoing, currentReadPromise);
    }
  } else if (resHeaderRecord[X_ALREADY_SENT]) {
  } else {
    outgoing.writeHead(res.status, resHeaderRecord);
    outgoing.end();
  }
  ;
  outgoing[outgoingEnded]?.();
};
var getRequestListener = (fetchCallback, options = {}) => {
  const autoCleanupIncoming = options.autoCleanupIncoming ?? true;
  if (options.overrideGlobalObjects !== false && global.Request !== Request2) {
    Object.defineProperty(global, "Request", {
      value: Request2
    });
    Object.defineProperty(global, "Response", {
      value: Response2
    });
  }
  return async (incoming, outgoing) => {
    let res, req;
    try {
      req = newRequest(incoming, options.hostname);
      let incomingEnded = !autoCleanupIncoming || incoming.method === "GET" || incoming.method === "HEAD";
      if (!incomingEnded) {
        ;
        incoming[wrapBodyStream] = true;
        incoming.on("end", () => {
          incomingEnded = true;
        });
        if (incoming instanceof Http2ServerRequest2) {
          ;
          outgoing[outgoingEnded] = () => {
            if (!incomingEnded) {
              setTimeout(() => {
                if (!incomingEnded) {
                  setTimeout(() => {
                    incoming.destroy();
                    outgoing.destroy();
                  });
                }
              });
            }
          };
        }
      }
      outgoing.on("close", () => {
        const abortController = req[abortControllerKey];
        if (abortController) {
          if (incoming.errored) {
            req[abortControllerKey].abort(incoming.errored.toString());
          } else if (!outgoing.writableFinished) {
            req[abortControllerKey].abort("Client connection prematurely closed.");
          }
        }
        if (!incomingEnded) {
          setTimeout(() => {
            if (!incomingEnded) {
              setTimeout(() => {
                incoming.destroy();
              });
            }
          });
        }
      });
      res = fetchCallback(req, { incoming, outgoing });
      if (cacheKey in res) {
        return responseViaCache(res, outgoing);
      }
    } catch (e) {
      if (!res) {
        if (options.errorHandler) {
          res = await options.errorHandler(req ? e : toRequestError(e));
          if (!res) {
            return;
          }
        } else if (!req) {
          res = handleRequestError();
        } else {
          res = handleFetchError(e);
        }
      } else {
        return handleResponseError(e, outgoing);
      }
    }
    try {
      return await responseViaResponseObject(res, outgoing, options);
    } catch (e) {
      return handleResponseError(e, outgoing);
    }
  };
};
var createAdaptorServer = (options) => {
  const fetchCallback = options.fetch;
  const requestListener = getRequestListener(fetchCallback, {
    hostname: options.hostname,
    overrideGlobalObjects: options.overrideGlobalObjects,
    autoCleanupIncoming: options.autoCleanupIncoming
  });
  const createServer = options.createServer || createServerHTTP;
  const server = createServer(options.serverOptions || {}, requestListener);
  return server;
};
var serve = (options, listeningListener) => {
  const server = createAdaptorServer(options);
  server.listen(options?.port ?? 3e3, options.hostname, () => {
    const serverInfo = server.address();
    listeningListener && listeningListener(serverInfo);
  });
  return server;
};

// .stack/node_modules/hono/dist/compose.js
var compose = (middleware, onError, onNotFound) => {
  return (context, next) => {
    let index = -1;
    return dispatch(0);
    async function dispatch(i) {
      if (i <= index) {
        throw new Error("next() called multiple times");
      }
      index = i;
      let res;
      let isError = false;
      let handler;
      if (middleware[i]) {
        handler = middleware[i][0][0];
        context.req.routeIndex = i;
      } else {
        handler = i === middleware.length && next || void 0;
      }
      if (handler) {
        try {
          res = await handler(context, () => dispatch(i + 1));
        } catch (err) {
          if (err instanceof Error && onError) {
            context.error = err;
            res = await onError(err, context);
            isError = true;
          } else {
            throw err;
          }
        }
      } else {
        if (context.finalized === false && onNotFound) {
          res = await onNotFound(context);
        }
      }
      if (res && (context.finalized === false || isError)) {
        context.res = res;
      }
      return context;
    }
  };
};

// .stack/node_modules/hono/dist/request/constants.js
var GET_MATCH_RESULT = /* @__PURE__ */ Symbol();

// .stack/node_modules/hono/dist/utils/body.js
var parseBody = async (request, options = /* @__PURE__ */ Object.create(null)) => {
  const { all = false, dot = false } = options;
  const headers = request instanceof HonoRequest ? request.raw.headers : request.headers;
  const contentType = headers.get("Content-Type");
  if (contentType?.startsWith("multipart/form-data") || contentType?.startsWith("application/x-www-form-urlencoded")) {
    return parseFormData(request, { all, dot });
  }
  return {};
};
async function parseFormData(request, options) {
  const formData = await request.formData();
  if (formData) {
    return convertFormDataToBodyData(formData, options);
  }
  return {};
}
function convertFormDataToBodyData(formData, options) {
  const form = /* @__PURE__ */ Object.create(null);
  formData.forEach((value, key) => {
    const shouldParseAllValues = options.all || key.endsWith("[]");
    if (!shouldParseAllValues) {
      form[key] = value;
    } else {
      handleParsingAllValues(form, key, value);
    }
  });
  if (options.dot) {
    Object.entries(form).forEach(([key, value]) => {
      const shouldParseDotValues = key.includes(".");
      if (shouldParseDotValues) {
        handleParsingNestedValues(form, key, value);
        delete form[key];
      }
    });
  }
  return form;
}
var handleParsingAllValues = (form, key, value) => {
  if (form[key] !== void 0) {
    if (Array.isArray(form[key])) {
      ;
      form[key].push(value);
    } else {
      form[key] = [form[key], value];
    }
  } else {
    if (!key.endsWith("[]")) {
      form[key] = value;
    } else {
      form[key] = [value];
    }
  }
};
var handleParsingNestedValues = (form, key, value) => {
  let nestedForm = form;
  const keys = key.split(".");
  keys.forEach((key2, index) => {
    if (index === keys.length - 1) {
      nestedForm[key2] = value;
    } else {
      if (!nestedForm[key2] || typeof nestedForm[key2] !== "object" || Array.isArray(nestedForm[key2]) || nestedForm[key2] instanceof File) {
        nestedForm[key2] = /* @__PURE__ */ Object.create(null);
      }
      nestedForm = nestedForm[key2];
    }
  });
};

// .stack/node_modules/hono/dist/utils/url.js
var splitPath = (path) => {
  const paths = path.split("/");
  if (paths[0] === "") {
    paths.shift();
  }
  return paths;
};
var splitRoutingPath = (routePath) => {
  const { groups, path } = extractGroupsFromPath(routePath);
  const paths = splitPath(path);
  return replaceGroupMarks(paths, groups);
};
var extractGroupsFromPath = (path) => {
  const groups = [];
  path = path.replace(/\{[^}]+\}/g, (match2, index) => {
    const mark2 = `@${index}`;
    groups.push([mark2, match2]);
    return mark2;
  });
  return { groups, path };
};
var replaceGroupMarks = (paths, groups) => {
  for (let i = groups.length - 1; i >= 0; i--) {
    const [mark2] = groups[i];
    for (let j = paths.length - 1; j >= 0; j--) {
      if (paths[j].includes(mark2)) {
        paths[j] = paths[j].replace(mark2, groups[i][1]);
        break;
      }
    }
  }
  return paths;
};
var patternCache = {};
var getPattern = (label, next) => {
  if (label === "*") {
    return "*";
  }
  const match2 = label.match(/^\:([^\{\}]+)(?:\{(.+)\})?$/);
  if (match2) {
    const cacheKey2 = `${label}#${next}`;
    if (!patternCache[cacheKey2]) {
      if (match2[2]) {
        patternCache[cacheKey2] = next && next[0] !== ":" && next[0] !== "*" ? [cacheKey2, match2[1], new RegExp(`^${match2[2]}(?=/${next})`)] : [label, match2[1], new RegExp(`^${match2[2]}$`)];
      } else {
        patternCache[cacheKey2] = [label, match2[1], true];
      }
    }
    return patternCache[cacheKey2];
  }
  return null;
};
var tryDecode = (str, decoder) => {
  try {
    return decoder(str);
  } catch {
    return str.replace(/(?:%[0-9A-Fa-f]{2})+/g, (match2) => {
      try {
        return decoder(match2);
      } catch {
        return match2;
      }
    });
  }
};
var tryDecodeURI = (str) => tryDecode(str, decodeURI);
var getPath = (request) => {
  const url = request.url;
  const start2 = url.indexOf("/", url.indexOf(":") + 4);
  let i = start2;
  for (; i < url.length; i++) {
    const charCode = url.charCodeAt(i);
    if (charCode === 37) {
      const queryIndex = url.indexOf("?", i);
      const hashIndex = url.indexOf("#", i);
      const end = queryIndex === -1 ? hashIndex === -1 ? void 0 : hashIndex : hashIndex === -1 ? queryIndex : Math.min(queryIndex, hashIndex);
      const path = url.slice(start2, end);
      return tryDecodeURI(path.includes("%25") ? path.replace(/%25/g, "%2525") : path);
    } else if (charCode === 63 || charCode === 35) {
      break;
    }
  }
  return url.slice(start2, i);
};
var getPathNoStrict = (request) => {
  const result = getPath(request);
  return result.length > 1 && result.at(-1) === "/" ? result.slice(0, -1) : result;
};
var mergePath = (base, sub, ...rest) => {
  if (rest.length) {
    sub = mergePath(sub, ...rest);
  }
  return `${base?.[0] === "/" ? "" : "/"}${base}${sub === "/" ? "" : `${base?.at(-1) === "/" ? "" : "/"}${sub?.[0] === "/" ? sub.slice(1) : sub}`}`;
};
var checkOptionalParameter = (path) => {
  if (path.charCodeAt(path.length - 1) !== 63 || !path.includes(":")) {
    return null;
  }
  const segments = path.split("/");
  const results = [];
  let basePath = "";
  segments.forEach((segment) => {
    if (segment !== "" && !/\:/.test(segment)) {
      basePath += "/" + segment;
    } else if (/\:/.test(segment)) {
      if (/\?/.test(segment)) {
        if (results.length === 0 && basePath === "") {
          results.push("/");
        } else {
          results.push(basePath);
        }
        const optionalSegment = segment.replace("?", "");
        basePath += "/" + optionalSegment;
        results.push(basePath);
      } else {
        basePath += "/" + segment;
      }
    }
  });
  return results.filter((v, i, a) => a.indexOf(v) === i);
};
var _decodeURI = (value) => {
  if (!/[%+]/.test(value)) {
    return value;
  }
  if (value.indexOf("+") !== -1) {
    value = value.replace(/\+/g, " ");
  }
  return value.indexOf("%") !== -1 ? tryDecode(value, decodeURIComponent_) : value;
};
var _getQueryParam = (url, key, multiple) => {
  let encoded;
  if (!multiple && key && !/[%+]/.test(key)) {
    let keyIndex2 = url.indexOf("?", 8);
    if (keyIndex2 === -1) {
      return void 0;
    }
    if (!url.startsWith(key, keyIndex2 + 1)) {
      keyIndex2 = url.indexOf(`&${key}`, keyIndex2 + 1);
    }
    while (keyIndex2 !== -1) {
      const trailingKeyCode = url.charCodeAt(keyIndex2 + key.length + 1);
      if (trailingKeyCode === 61) {
        const valueIndex = keyIndex2 + key.length + 2;
        const endIndex = url.indexOf("&", valueIndex);
        return _decodeURI(url.slice(valueIndex, endIndex === -1 ? void 0 : endIndex));
      } else if (trailingKeyCode == 38 || isNaN(trailingKeyCode)) {
        return "";
      }
      keyIndex2 = url.indexOf(`&${key}`, keyIndex2 + 1);
    }
    encoded = /[%+]/.test(url);
    if (!encoded) {
      return void 0;
    }
  }
  const results = {};
  encoded ??= /[%+]/.test(url);
  let keyIndex = url.indexOf("?", 8);
  while (keyIndex !== -1) {
    const nextKeyIndex = url.indexOf("&", keyIndex + 1);
    let valueIndex = url.indexOf("=", keyIndex);
    if (valueIndex > nextKeyIndex && nextKeyIndex !== -1) {
      valueIndex = -1;
    }
    let name = url.slice(
      keyIndex + 1,
      valueIndex === -1 ? nextKeyIndex === -1 ? void 0 : nextKeyIndex : valueIndex
    );
    if (encoded) {
      name = _decodeURI(name);
    }
    keyIndex = nextKeyIndex;
    if (name === "") {
      continue;
    }
    let value;
    if (valueIndex === -1) {
      value = "";
    } else {
      value = url.slice(valueIndex + 1, nextKeyIndex === -1 ? void 0 : nextKeyIndex);
      if (encoded) {
        value = _decodeURI(value);
      }
    }
    if (multiple) {
      if (!(results[name] && Array.isArray(results[name]))) {
        results[name] = [];
      }
      ;
      results[name].push(value);
    } else {
      results[name] ??= value;
    }
  }
  return key ? results[key] : results;
};
var getQueryParam = _getQueryParam;
var getQueryParams = (url, key) => {
  return _getQueryParam(url, key, true);
};
var decodeURIComponent_ = decodeURIComponent;

// .stack/node_modules/hono/dist/request.js
var tryDecodeURIComponent = (str) => tryDecode(str, decodeURIComponent_);
var HonoRequest = class {
  /**
   * `.raw` can get the raw Request object.
   *
   * @see {@link https://hono.dev/docs/api/request#raw}
   *
   * @example
   * ```ts
   * // For Cloudflare Workers
   * app.post('/', async (c) => {
   *   const metadata = c.req.raw.cf?.hostMetadata?
   *   ...
   * })
   * ```
   */
  raw;
  #validatedData;
  // Short name of validatedData
  #matchResult;
  routeIndex = 0;
  /**
   * `.path` can get the pathname of the request.
   *
   * @see {@link https://hono.dev/docs/api/request#path}
   *
   * @example
   * ```ts
   * app.get('/about/me', (c) => {
   *   const pathname = c.req.path // `/about/me`
   * })
   * ```
   */
  path;
  bodyCache = {};
  constructor(request, path = "/", matchResult = [[]]) {
    this.raw = request;
    this.path = path;
    this.#matchResult = matchResult;
    this.#validatedData = {};
  }
  param(key) {
    return key ? this.#getDecodedParam(key) : this.#getAllDecodedParams();
  }
  #getDecodedParam(key) {
    const paramKey = this.#matchResult[0][this.routeIndex][1][key];
    const param = this.#getParamValue(paramKey);
    return param && /\%/.test(param) ? tryDecodeURIComponent(param) : param;
  }
  #getAllDecodedParams() {
    const decoded = {};
    const keys = Object.keys(this.#matchResult[0][this.routeIndex][1]);
    for (const key of keys) {
      const value = this.#getParamValue(this.#matchResult[0][this.routeIndex][1][key]);
      if (value !== void 0) {
        decoded[key] = /\%/.test(value) ? tryDecodeURIComponent(value) : value;
      }
    }
    return decoded;
  }
  #getParamValue(paramKey) {
    return this.#matchResult[1] ? this.#matchResult[1][paramKey] : paramKey;
  }
  query(key) {
    return getQueryParam(this.url, key);
  }
  queries(key) {
    return getQueryParams(this.url, key);
  }
  header(name) {
    if (name) {
      return this.raw.headers.get(name) ?? void 0;
    }
    const headerData = {};
    this.raw.headers.forEach((value, key) => {
      headerData[key] = value;
    });
    return headerData;
  }
  async parseBody(options) {
    return this.bodyCache.parsedBody ??= await parseBody(this, options);
  }
  #cachedBody = (key) => {
    const { bodyCache, raw: raw2 } = this;
    const cachedBody = bodyCache[key];
    if (cachedBody) {
      return cachedBody;
    }
    const anyCachedKey = Object.keys(bodyCache)[0];
    if (anyCachedKey) {
      return bodyCache[anyCachedKey].then((body) => {
        if (anyCachedKey === "json") {
          body = JSON.stringify(body);
        }
        return new Response(body)[key]();
      });
    }
    return bodyCache[key] = raw2[key]();
  };
  /**
   * `.json()` can parse Request body of type `application/json`
   *
   * @see {@link https://hono.dev/docs/api/request#json}
   *
   * @example
   * ```ts
   * app.post('/entry', async (c) => {
   *   const body = await c.req.json()
   * })
   * ```
   */
  json() {
    return this.#cachedBody("text").then((text2) => JSON.parse(text2));
  }
  /**
   * `.text()` can parse Request body of type `text/plain`
   *
   * @see {@link https://hono.dev/docs/api/request#text}
   *
   * @example
   * ```ts
   * app.post('/entry', async (c) => {
   *   const body = await c.req.text()
   * })
   * ```
   */
  text() {
    return this.#cachedBody("text");
  }
  /**
   * `.arrayBuffer()` parse Request body as an `ArrayBuffer`
   *
   * @see {@link https://hono.dev/docs/api/request#arraybuffer}
   *
   * @example
   * ```ts
   * app.post('/entry', async (c) => {
   *   const body = await c.req.arrayBuffer()
   * })
   * ```
   */
  arrayBuffer() {
    return this.#cachedBody("arrayBuffer");
  }
  /**
   * Parses the request body as a `Blob`.
   * @example
   * ```ts
   * app.post('/entry', async (c) => {
   *   const body = await c.req.blob();
   * });
   * ```
   * @see https://hono.dev/docs/api/request#blob
   */
  blob() {
    return this.#cachedBody("blob");
  }
  /**
   * Parses the request body as `FormData`.
   * @example
   * ```ts
   * app.post('/entry', async (c) => {
   *   const body = await c.req.formData();
   * });
   * ```
   * @see https://hono.dev/docs/api/request#formdata
   */
  formData() {
    return this.#cachedBody("formData");
  }
  /**
   * Adds validated data to the request.
   *
   * @param target - The target of the validation.
   * @param data - The validated data to add.
   */
  addValidatedData(target, data) {
    this.#validatedData[target] = data;
  }
  valid(target) {
    return this.#validatedData[target];
  }
  /**
   * `.url()` can get the request url strings.
   *
   * @see {@link https://hono.dev/docs/api/request#url}
   *
   * @example
   * ```ts
   * app.get('/about/me', (c) => {
   *   const url = c.req.url // `http://localhost:8787/about/me`
   *   ...
   * })
   * ```
   */
  get url() {
    return this.raw.url;
  }
  /**
   * `.method()` can get the method name of the request.
   *
   * @see {@link https://hono.dev/docs/api/request#method}
   *
   * @example
   * ```ts
   * app.get('/about/me', (c) => {
   *   const method = c.req.method // `GET`
   * })
   * ```
   */
  get method() {
    return this.raw.method;
  }
  get [GET_MATCH_RESULT]() {
    return this.#matchResult;
  }
  /**
   * `.matchedRoutes()` can return a matched route in the handler
   *
   * @deprecated
   *
   * Use matchedRoutes helper defined in "hono/route" instead.
   *
   * @see {@link https://hono.dev/docs/api/request#matchedroutes}
   *
   * @example
   * ```ts
   * app.use('*', async function logger(c, next) {
   *   await next()
   *   c.req.matchedRoutes.forEach(({ handler, method, path }, i) => {
   *     const name = handler.name || (handler.length < 2 ? '[handler]' : '[middleware]')
   *     console.log(
   *       method,
   *       ' ',
   *       path,
   *       ' '.repeat(Math.max(10 - path.length, 0)),
   *       name,
   *       i === c.req.routeIndex ? '<- respond from here' : ''
   *     )
   *   })
   * })
   * ```
   */
  get matchedRoutes() {
    return this.#matchResult[0].map(([[, route]]) => route);
  }
  /**
   * `routePath()` can retrieve the path registered within the handler
   *
   * @deprecated
   *
   * Use routePath helper defined in "hono/route" instead.
   *
   * @see {@link https://hono.dev/docs/api/request#routepath}
   *
   * @example
   * ```ts
   * app.get('/posts/:id', (c) => {
   *   return c.json({ path: c.req.routePath })
   * })
   * ```
   */
  get routePath() {
    return this.#matchResult[0].map(([[, route]]) => route)[this.routeIndex].path;
  }
};

// .stack/node_modules/hono/dist/utils/html.js
var HtmlEscapedCallbackPhase = {
  Stringify: 1,
  BeforeStream: 2,
  Stream: 3
};
var raw = (value, callbacks) => {
  const escapedString = new String(value);
  escapedString.isEscaped = true;
  escapedString.callbacks = callbacks;
  return escapedString;
};
var resolveCallback = async (str, phase, preserveCallbacks, context, buffer) => {
  if (typeof str === "object" && !(str instanceof String)) {
    if (!(str instanceof Promise)) {
      str = str.toString();
    }
    if (str instanceof Promise) {
      str = await str;
    }
  }
  const callbacks = str.callbacks;
  if (!callbacks?.length) {
    return Promise.resolve(str);
  }
  if (buffer) {
    buffer[0] += str;
  } else {
    buffer = [str];
  }
  const resStr = Promise.all(callbacks.map((c) => c({ phase, buffer, context }))).then(
    (res) => Promise.all(
      res.filter(Boolean).map((str2) => resolveCallback(str2, phase, false, context, buffer))
    ).then(() => buffer[0])
  );
  if (preserveCallbacks) {
    return raw(await resStr, callbacks);
  } else {
    return resStr;
  }
};

// .stack/node_modules/hono/dist/context.js
var TEXT_PLAIN = "text/plain; charset=UTF-8";
var setDefaultContentType = (contentType, headers) => {
  return {
    "Content-Type": contentType,
    ...headers
  };
};
var createResponseInstance = (body, init) => new Response(body, init);
var Context = class {
  #rawRequest;
  #req;
  /**
   * `.env` can get bindings (environment variables, secrets, KV namespaces, D1 database, R2 bucket etc.) in Cloudflare Workers.
   *
   * @see {@link https://hono.dev/docs/api/context#env}
   *
   * @example
   * ```ts
   * // Environment object for Cloudflare Workers
   * app.get('*', async c => {
   *   const counter = c.env.COUNTER
   * })
   * ```
   */
  env = {};
  #var;
  finalized = false;
  /**
   * `.error` can get the error object from the middleware if the Handler throws an error.
   *
   * @see {@link https://hono.dev/docs/api/context#error}
   *
   * @example
   * ```ts
   * app.use('*', async (c, next) => {
   *   await next()
   *   if (c.error) {
   *     // do something...
   *   }
   * })
   * ```
   */
  error;
  #status;
  #executionCtx;
  #res;
  #layout;
  #renderer;
  #notFoundHandler;
  #preparedHeaders;
  #matchResult;
  #path;
  /**
   * Creates an instance of the Context class.
   *
   * @param req - The Request object.
   * @param options - Optional configuration options for the context.
   */
  constructor(req, options) {
    this.#rawRequest = req;
    if (options) {
      this.#executionCtx = options.executionCtx;
      this.env = options.env;
      this.#notFoundHandler = options.notFoundHandler;
      this.#path = options.path;
      this.#matchResult = options.matchResult;
    }
  }
  /**
   * `.req` is the instance of {@link HonoRequest}.
   */
  get req() {
    this.#req ??= new HonoRequest(this.#rawRequest, this.#path, this.#matchResult);
    return this.#req;
  }
  /**
   * @see {@link https://hono.dev/docs/api/context#event}
   * The FetchEvent associated with the current request.
   *
   * @throws Will throw an error if the context does not have a FetchEvent.
   */
  get event() {
    if (this.#executionCtx && "respondWith" in this.#executionCtx) {
      return this.#executionCtx;
    } else {
      throw Error("This context has no FetchEvent");
    }
  }
  /**
   * @see {@link https://hono.dev/docs/api/context#executionctx}
   * The ExecutionContext associated with the current request.
   *
   * @throws Will throw an error if the context does not have an ExecutionContext.
   */
  get executionCtx() {
    if (this.#executionCtx) {
      return this.#executionCtx;
    } else {
      throw Error("This context has no ExecutionContext");
    }
  }
  /**
   * @see {@link https://hono.dev/docs/api/context#res}
   * The Response object for the current request.
   */
  get res() {
    return this.#res ||= createResponseInstance(null, {
      headers: this.#preparedHeaders ??= new Headers()
    });
  }
  /**
   * Sets the Response object for the current request.
   *
   * @param _res - The Response object to set.
   */
  set res(_res) {
    if (this.#res && _res) {
      _res = createResponseInstance(_res.body, _res);
      for (const [k, v] of this.#res.headers.entries()) {
        if (k === "content-type") {
          continue;
        }
        if (k === "set-cookie") {
          const cookies = this.#res.headers.getSetCookie();
          _res.headers.delete("set-cookie");
          for (const cookie of cookies) {
            _res.headers.append("set-cookie", cookie);
          }
        } else {
          _res.headers.set(k, v);
        }
      }
    }
    this.#res = _res;
    this.finalized = true;
  }
  /**
   * `.render()` can create a response within a layout.
   *
   * @see {@link https://hono.dev/docs/api/context#render-setrenderer}
   *
   * @example
   * ```ts
   * app.get('/', (c) => {
   *   return c.render('Hello!')
   * })
   * ```
   */
  render = (...args) => {
    this.#renderer ??= (content) => this.html(content);
    return this.#renderer(...args);
  };
  /**
   * Sets the layout for the response.
   *
   * @param layout - The layout to set.
   * @returns The layout function.
   */
  setLayout = (layout) => this.#layout = layout;
  /**
   * Gets the current layout for the response.
   *
   * @returns The current layout function.
   */
  getLayout = () => this.#layout;
  /**
   * `.setRenderer()` can set the layout in the custom middleware.
   *
   * @see {@link https://hono.dev/docs/api/context#render-setrenderer}
   *
   * @example
   * ```tsx
   * app.use('*', async (c, next) => {
   *   c.setRenderer((content) => {
   *     return c.html(
   *       <html>
   *         <body>
   *           <p>{content}</p>
   *         </body>
   *       </html>
   *     )
   *   })
   *   await next()
   * })
   * ```
   */
  setRenderer = (renderer) => {
    this.#renderer = renderer;
  };
  /**
   * `.header()` can set headers.
   *
   * @see {@link https://hono.dev/docs/api/context#header}
   *
   * @example
   * ```ts
   * app.get('/welcome', (c) => {
   *   // Set headers
   *   c.header('X-Message', 'Hello!')
   *   c.header('Content-Type', 'text/plain')
   *
   *   return c.body('Thank you for coming')
   * })
   * ```
   */
  header = (name, value, options) => {
    if (this.finalized) {
      this.#res = createResponseInstance(this.#res.body, this.#res);
    }
    const headers = this.#res ? this.#res.headers : this.#preparedHeaders ??= new Headers();
    if (value === void 0) {
      headers.delete(name);
    } else if (options?.append) {
      headers.append(name, value);
    } else {
      headers.set(name, value);
    }
  };
  status = (status) => {
    this.#status = status;
  };
  /**
   * `.set()` can set the value specified by the key.
   *
   * @see {@link https://hono.dev/docs/api/context#set-get}
   *
   * @example
   * ```ts
   * app.use('*', async (c, next) => {
   *   c.set('message', 'Hono is hot!!')
   *   await next()
   * })
   * ```
   */
  set = (key, value) => {
    this.#var ??= /* @__PURE__ */ new Map();
    this.#var.set(key, value);
  };
  /**
   * `.get()` can use the value specified by the key.
   *
   * @see {@link https://hono.dev/docs/api/context#set-get}
   *
   * @example
   * ```ts
   * app.get('/', (c) => {
   *   const message = c.get('message')
   *   return c.text(`The message is "${message}"`)
   * })
   * ```
   */
  get = (key) => {
    return this.#var ? this.#var.get(key) : void 0;
  };
  /**
   * `.var` can access the value of a variable.
   *
   * @see {@link https://hono.dev/docs/api/context#var}
   *
   * @example
   * ```ts
   * const result = c.var.client.oneMethod()
   * ```
   */
  // c.var.propName is a read-only
  get var() {
    if (!this.#var) {
      return {};
    }
    return Object.fromEntries(this.#var);
  }
  #newResponse(data, arg, headers) {
    const responseHeaders = this.#res ? new Headers(this.#res.headers) : this.#preparedHeaders ?? new Headers();
    if (typeof arg === "object" && "headers" in arg) {
      const argHeaders = arg.headers instanceof Headers ? arg.headers : new Headers(arg.headers);
      for (const [key, value] of argHeaders) {
        if (key.toLowerCase() === "set-cookie") {
          responseHeaders.append(key, value);
        } else {
          responseHeaders.set(key, value);
        }
      }
    }
    if (headers) {
      for (const [k, v] of Object.entries(headers)) {
        if (typeof v === "string") {
          responseHeaders.set(k, v);
        } else {
          responseHeaders.delete(k);
          for (const v2 of v) {
            responseHeaders.append(k, v2);
          }
        }
      }
    }
    const status = typeof arg === "number" ? arg : arg?.status ?? this.#status;
    return createResponseInstance(data, { status, headers: responseHeaders });
  }
  newResponse = (...args) => this.#newResponse(...args);
  /**
   * `.body()` can return the HTTP response.
   * You can set headers with `.header()` and set HTTP status code with `.status`.
   * This can also be set in `.text()`, `.json()` and so on.
   *
   * @see {@link https://hono.dev/docs/api/context#body}
   *
   * @example
   * ```ts
   * app.get('/welcome', (c) => {
   *   // Set headers
   *   c.header('X-Message', 'Hello!')
   *   c.header('Content-Type', 'text/plain')
   *   // Set HTTP status code
   *   c.status(201)
   *
   *   // Return the response body
   *   return c.body('Thank you for coming')
   * })
   * ```
   */
  body = (data, arg, headers) => this.#newResponse(data, arg, headers);
  #useFastPath() {
    return !this.#preparedHeaders && !this.#status && !this.finalized;
  }
  /**
   * `.text()` can render text as `Content-Type:text/plain`.
   *
   * @see {@link https://hono.dev/docs/api/context#text}
   *
   * @example
   * ```ts
   * app.get('/say', (c) => {
   *   return c.text('Hello!')
   * })
   * ```
   */
  text = (text2, arg, headers) => {
    return this.#useFastPath() && !arg && !headers ? createResponseInstance(text2) : this.#newResponse(
      text2,
      arg,
      setDefaultContentType(TEXT_PLAIN, headers)
    );
  };
  /**
   * `.json()` can render JSON as `Content-Type:application/json`.
   *
   * @see {@link https://hono.dev/docs/api/context#json}
   *
   * @example
   * ```ts
   * app.get('/api', (c) => {
   *   return c.json({ message: 'Hello!' })
   * })
   * ```
   */
  json = (object, arg, headers) => {
    return this.#useFastPath() && !arg && !headers ? Response.json(object) : this.#newResponse(
      JSON.stringify(object),
      arg,
      setDefaultContentType("application/json", headers)
    );
  };
  html = (html, arg, headers) => {
    const res = (html2) => this.#newResponse(html2, arg, setDefaultContentType("text/html; charset=UTF-8", headers));
    return typeof html === "object" ? resolveCallback(html, HtmlEscapedCallbackPhase.Stringify, false, {}).then(res) : res(html);
  };
  /**
   * `.redirect()` can Redirect, default status code is 302.
   *
   * @see {@link https://hono.dev/docs/api/context#redirect}
   *
   * @example
   * ```ts
   * app.get('/redirect', (c) => {
   *   return c.redirect('/')
   * })
   * app.get('/redirect-permanently', (c) => {
   *   return c.redirect('/', 301)
   * })
   * ```
   */
  redirect = (location, status) => {
    const locationString = String(location);
    this.header(
      "Location",
      // Multibyes should be encoded
      // eslint-disable-next-line no-control-regex
      !/[^\x00-\xFF]/.test(locationString) ? locationString : encodeURI(locationString)
    );
    return this.newResponse(null, status ?? 302);
  };
  /**
   * `.notFound()` can return the Not Found Response.
   *
   * @see {@link https://hono.dev/docs/api/context#notfound}
   *
   * @example
   * ```ts
   * app.get('/notfound', (c) => {
   *   return c.notFound()
   * })
   * ```
   */
  notFound = () => {
    this.#notFoundHandler ??= () => createResponseInstance();
    return this.#notFoundHandler(this);
  };
};

// .stack/node_modules/hono/dist/router.js
var METHOD_NAME_ALL = "ALL";
var METHOD_NAME_ALL_LOWERCASE = "all";
var METHODS = ["get", "post", "put", "delete", "options", "patch"];
var MESSAGE_MATCHER_IS_ALREADY_BUILT = "Can not add a route since the matcher is already built.";
var UnsupportedPathError = class extends Error {
};

// .stack/node_modules/hono/dist/utils/constants.js
var COMPOSED_HANDLER = "__COMPOSED_HANDLER";

// .stack/node_modules/hono/dist/hono-base.js
var notFoundHandler = (c) => {
  return c.text("404 Not Found", 404);
};
var errorHandler = (err, c) => {
  if ("getResponse" in err) {
    const res = err.getResponse();
    return c.newResponse(res.body, res);
  }
  console.error(err);
  return c.text("Internal Server Error", 500);
};
var Hono = class _Hono {
  get;
  post;
  put;
  delete;
  options;
  patch;
  all;
  on;
  use;
  /*
    This class is like an abstract class and does not have a router.
    To use it, inherit the class and implement router in the constructor.
  */
  router;
  getPath;
  // Cannot use `#` because it requires visibility at JavaScript runtime.
  _basePath = "/";
  #path = "/";
  routes = [];
  constructor(options = {}) {
    const allMethods = [...METHODS, METHOD_NAME_ALL_LOWERCASE];
    allMethods.forEach((method) => {
      this[method] = (args1, ...args) => {
        if (typeof args1 === "string") {
          this.#path = args1;
        } else {
          this.#addRoute(method, this.#path, args1);
        }
        args.forEach((handler) => {
          this.#addRoute(method, this.#path, handler);
        });
        return this;
      };
    });
    this.on = (method, path, ...handlers) => {
      for (const p of [path].flat()) {
        this.#path = p;
        for (const m of [method].flat()) {
          handlers.map((handler) => {
            this.#addRoute(m.toUpperCase(), this.#path, handler);
          });
        }
      }
      return this;
    };
    this.use = (arg1, ...handlers) => {
      if (typeof arg1 === "string") {
        this.#path = arg1;
      } else {
        this.#path = "*";
        handlers.unshift(arg1);
      }
      handlers.forEach((handler) => {
        this.#addRoute(METHOD_NAME_ALL, this.#path, handler);
      });
      return this;
    };
    const { strict, ...optionsWithoutStrict } = options;
    Object.assign(this, optionsWithoutStrict);
    this.getPath = strict ?? true ? options.getPath ?? getPath : getPathNoStrict;
  }
  #clone() {
    const clone = new _Hono({
      router: this.router,
      getPath: this.getPath
    });
    clone.errorHandler = this.errorHandler;
    clone.#notFoundHandler = this.#notFoundHandler;
    clone.routes = this.routes;
    return clone;
  }
  #notFoundHandler = notFoundHandler;
  // Cannot use `#` because it requires visibility at JavaScript runtime.
  errorHandler = errorHandler;
  /**
   * `.route()` allows grouping other Hono instance in routes.
   *
   * @see {@link https://hono.dev/docs/api/routing#grouping}
   *
   * @param {string} path - base Path
   * @param {Hono} app - other Hono instance
   * @returns {Hono} routed Hono instance
   *
   * @example
   * ```ts
   * const app = new Hono()
   * const app2 = new Hono()
   *
   * app2.get("/user", (c) => c.text("user"))
   * app.route("/api", app2) // GET /api/user
   * ```
   */
  route(path, app) {
    const subApp = this.basePath(path);
    app.routes.map((r) => {
      let handler;
      if (app.errorHandler === errorHandler) {
        handler = r.handler;
      } else {
        handler = async (c, next) => (await compose([], app.errorHandler)(c, () => r.handler(c, next))).res;
        handler[COMPOSED_HANDLER] = r.handler;
      }
      subApp.#addRoute(r.method, r.path, handler);
    });
    return this;
  }
  /**
   * `.basePath()` allows base paths to be specified.
   *
   * @see {@link https://hono.dev/docs/api/routing#base-path}
   *
   * @param {string} path - base Path
   * @returns {Hono} changed Hono instance
   *
   * @example
   * ```ts
   * const api = new Hono().basePath('/api')
   * ```
   */
  basePath(path) {
    const subApp = this.#clone();
    subApp._basePath = mergePath(this._basePath, path);
    return subApp;
  }
  /**
   * `.onError()` handles an error and returns a customized Response.
   *
   * @see {@link https://hono.dev/docs/api/hono#error-handling}
   *
   * @param {ErrorHandler} handler - request Handler for error
   * @returns {Hono} changed Hono instance
   *
   * @example
   * ```ts
   * app.onError((err, c) => {
   *   console.error(`${err}`)
   *   return c.text('Custom Error Message', 500)
   * })
   * ```
   */
  onError = (handler) => {
    this.errorHandler = handler;
    return this;
  };
  /**
   * `.notFound()` allows you to customize a Not Found Response.
   *
   * @see {@link https://hono.dev/docs/api/hono#not-found}
   *
   * @param {NotFoundHandler} handler - request handler for not-found
   * @returns {Hono} changed Hono instance
   *
   * @example
   * ```ts
   * app.notFound((c) => {
   *   return c.text('Custom 404 Message', 404)
   * })
   * ```
   */
  notFound = (handler) => {
    this.#notFoundHandler = handler;
    return this;
  };
  /**
   * `.mount()` allows you to mount applications built with other frameworks into your Hono application.
   *
   * @see {@link https://hono.dev/docs/api/hono#mount}
   *
   * @param {string} path - base Path
   * @param {Function} applicationHandler - other Request Handler
   * @param {MountOptions} [options] - options of `.mount()`
   * @returns {Hono} mounted Hono instance
   *
   * @example
   * ```ts
   * import { Router as IttyRouter } from 'itty-router'
   * import { Hono } from 'hono'
   * // Create itty-router application
   * const ittyRouter = IttyRouter()
   * // GET /itty-router/hello
   * ittyRouter.get('/hello', () => new Response('Hello from itty-router'))
   *
   * const app = new Hono()
   * app.mount('/itty-router', ittyRouter.handle)
   * ```
   *
   * @example
   * ```ts
   * const app = new Hono()
   * // Send the request to another application without modification.
   * app.mount('/app', anotherApp, {
   *   replaceRequest: (req) => req,
   * })
   * ```
   */
  mount(path, applicationHandler, options) {
    let replaceRequest;
    let optionHandler;
    if (options) {
      if (typeof options === "function") {
        optionHandler = options;
      } else {
        optionHandler = options.optionHandler;
        if (options.replaceRequest === false) {
          replaceRequest = (request) => request;
        } else {
          replaceRequest = options.replaceRequest;
        }
      }
    }
    const getOptions = optionHandler ? (c) => {
      const options2 = optionHandler(c);
      return Array.isArray(options2) ? options2 : [options2];
    } : (c) => {
      let executionContext = void 0;
      try {
        executionContext = c.executionCtx;
      } catch {
      }
      return [c.env, executionContext];
    };
    replaceRequest ||= (() => {
      const mergedPath = mergePath(this._basePath, path);
      const pathPrefixLength = mergedPath === "/" ? 0 : mergedPath.length;
      return (request) => {
        const url = new URL(request.url);
        url.pathname = url.pathname.slice(pathPrefixLength) || "/";
        return new Request(url, request);
      };
    })();
    const handler = async (c, next) => {
      const res = await applicationHandler(replaceRequest(c.req.raw), ...getOptions(c));
      if (res) {
        return res;
      }
      await next();
    };
    this.#addRoute(METHOD_NAME_ALL, mergePath(path, "*"), handler);
    return this;
  }
  #addRoute(method, path, handler) {
    method = method.toUpperCase();
    path = mergePath(this._basePath, path);
    const r = { basePath: this._basePath, path, method, handler };
    this.router.add(method, path, [handler, r]);
    this.routes.push(r);
  }
  #handleError(err, c) {
    if (err instanceof Error) {
      return this.errorHandler(err, c);
    }
    throw err;
  }
  #dispatch(request, executionCtx, env, method) {
    if (method === "HEAD") {
      return (async () => new Response(null, await this.#dispatch(request, executionCtx, env, "GET")))();
    }
    const path = this.getPath(request, { env });
    const matchResult = this.router.match(method, path);
    const c = new Context(request, {
      path,
      matchResult,
      env,
      executionCtx,
      notFoundHandler: this.#notFoundHandler
    });
    if (matchResult[0].length === 1) {
      let res;
      try {
        res = matchResult[0][0][0][0](c, async () => {
          c.res = await this.#notFoundHandler(c);
        });
      } catch (err) {
        return this.#handleError(err, c);
      }
      return res instanceof Promise ? res.then(
        (resolved) => resolved || (c.finalized ? c.res : this.#notFoundHandler(c))
      ).catch((err) => this.#handleError(err, c)) : res ?? this.#notFoundHandler(c);
    }
    const composed = compose(matchResult[0], this.errorHandler, this.#notFoundHandler);
    return (async () => {
      try {
        const context = await composed(c);
        if (!context.finalized) {
          throw new Error(
            "Context is not finalized. Did you forget to return a Response object or `await next()`?"
          );
        }
        return context.res;
      } catch (err) {
        return this.#handleError(err, c);
      }
    })();
  }
  /**
   * `.fetch()` will be entry point of your app.
   *
   * @see {@link https://hono.dev/docs/api/hono#fetch}
   *
   * @param {Request} request - request Object of request
   * @param {Env} Env - env Object
   * @param {ExecutionContext} - context of execution
   * @returns {Response | Promise<Response>} response of request
   *
   */
  fetch = (request, ...rest) => {
    return this.#dispatch(request, rest[1], rest[0], request.method);
  };
  /**
   * `.request()` is a useful method for testing.
   * You can pass a URL or pathname to send a GET request.
   * app will return a Response object.
   * ```ts
   * test('GET /hello is ok', async () => {
   *   const res = await app.request('/hello')
   *   expect(res.status).toBe(200)
   * })
   * ```
   * @see https://hono.dev/docs/api/hono#request
   */
  request = (input, requestInit, Env, executionCtx) => {
    if (input instanceof Request) {
      return this.fetch(requestInit ? new Request(input, requestInit) : input, Env, executionCtx);
    }
    input = input.toString();
    return this.fetch(
      new Request(
        /^https?:\/\//.test(input) ? input : `http://localhost${mergePath("/", input)}`,
        requestInit
      ),
      Env,
      executionCtx
    );
  };
  /**
   * `.fire()` automatically adds a global fetch event listener.
   * This can be useful for environments that adhere to the Service Worker API, such as non-ES module Cloudflare Workers.
   * @deprecated
   * Use `fire` from `hono/service-worker` instead.
   * ```ts
   * import { Hono } from 'hono'
   * import { fire } from 'hono/service-worker'
   *
   * const app = new Hono()
   * // ...
   * fire(app)
   * ```
   * @see https://hono.dev/docs/api/hono#fire
   * @see https://developer.mozilla.org/en-US/docs/Web/API/Service_Worker_API
   * @see https://developers.cloudflare.com/workers/reference/migrate-to-module-workers/
   */
  fire = () => {
    addEventListener("fetch", (event) => {
      event.respondWith(this.#dispatch(event.request, event, void 0, event.request.method));
    });
  };
};

// .stack/node_modules/hono/dist/router/reg-exp-router/matcher.js
var emptyParam = [];
function match(method, path) {
  const matchers = this.buildAllMatchers();
  const match2 = ((method2, path2) => {
    const matcher = matchers[method2] || matchers[METHOD_NAME_ALL];
    const staticMatch = matcher[2][path2];
    if (staticMatch) {
      return staticMatch;
    }
    const match3 = path2.match(matcher[0]);
    if (!match3) {
      return [[], emptyParam];
    }
    const index = match3.indexOf("", 1);
    return [matcher[1][index], match3];
  });
  this.match = match2;
  return match2(method, path);
}

// .stack/node_modules/hono/dist/router/reg-exp-router/node.js
var LABEL_REG_EXP_STR = "[^/]+";
var ONLY_WILDCARD_REG_EXP_STR = ".*";
var TAIL_WILDCARD_REG_EXP_STR = "(?:|/.*)";
var PATH_ERROR = /* @__PURE__ */ Symbol();
var regExpMetaChars = new Set(".\\+*[^]$()");
function compareKey(a, b) {
  if (a.length === 1) {
    return b.length === 1 ? a < b ? -1 : 1 : -1;
  }
  if (b.length === 1) {
    return 1;
  }
  if (a === ONLY_WILDCARD_REG_EXP_STR || a === TAIL_WILDCARD_REG_EXP_STR) {
    return 1;
  } else if (b === ONLY_WILDCARD_REG_EXP_STR || b === TAIL_WILDCARD_REG_EXP_STR) {
    return -1;
  }
  if (a === LABEL_REG_EXP_STR) {
    return 1;
  } else if (b === LABEL_REG_EXP_STR) {
    return -1;
  }
  return a.length === b.length ? a < b ? -1 : 1 : b.length - a.length;
}
var Node = class _Node {
  #index;
  #varIndex;
  #children = /* @__PURE__ */ Object.create(null);
  insert(tokens, index, paramMap, context, pathErrorCheckOnly) {
    if (tokens.length === 0) {
      if (this.#index !== void 0) {
        throw PATH_ERROR;
      }
      if (pathErrorCheckOnly) {
        return;
      }
      this.#index = index;
      return;
    }
    const [token, ...restTokens] = tokens;
    const pattern = token === "*" ? restTokens.length === 0 ? ["", "", ONLY_WILDCARD_REG_EXP_STR] : ["", "", LABEL_REG_EXP_STR] : token === "/*" ? ["", "", TAIL_WILDCARD_REG_EXP_STR] : token.match(/^\:([^\{\}]+)(?:\{(.+)\})?$/);
    let node;
    if (pattern) {
      const name = pattern[1];
      let regexpStr = pattern[2] || LABEL_REG_EXP_STR;
      if (name && pattern[2]) {
        if (regexpStr === ".*") {
          throw PATH_ERROR;
        }
        regexpStr = regexpStr.replace(/^\((?!\?:)(?=[^)]+\)$)/, "(?:");
        if (/\((?!\?:)/.test(regexpStr)) {
          throw PATH_ERROR;
        }
      }
      node = this.#children[regexpStr];
      if (!node) {
        if (Object.keys(this.#children).some(
          (k) => k !== ONLY_WILDCARD_REG_EXP_STR && k !== TAIL_WILDCARD_REG_EXP_STR
        )) {
          throw PATH_ERROR;
        }
        if (pathErrorCheckOnly) {
          return;
        }
        node = this.#children[regexpStr] = new _Node();
        if (name !== "") {
          node.#varIndex = context.varIndex++;
        }
      }
      if (!pathErrorCheckOnly && name !== "") {
        paramMap.push([name, node.#varIndex]);
      }
    } else {
      node = this.#children[token];
      if (!node) {
        if (Object.keys(this.#children).some(
          (k) => k.length > 1 && k !== ONLY_WILDCARD_REG_EXP_STR && k !== TAIL_WILDCARD_REG_EXP_STR
        )) {
          throw PATH_ERROR;
        }
        if (pathErrorCheckOnly) {
          return;
        }
        node = this.#children[token] = new _Node();
      }
    }
    node.insert(restTokens, index, paramMap, context, pathErrorCheckOnly);
  }
  buildRegExpStr() {
    const childKeys = Object.keys(this.#children).sort(compareKey);
    const strList = childKeys.map((k) => {
      const c = this.#children[k];
      return (typeof c.#varIndex === "number" ? `(${k})@${c.#varIndex}` : regExpMetaChars.has(k) ? `\\${k}` : k) + c.buildRegExpStr();
    });
    if (typeof this.#index === "number") {
      strList.unshift(`#${this.#index}`);
    }
    if (strList.length === 0) {
      return "";
    }
    if (strList.length === 1) {
      return strList[0];
    }
    return "(?:" + strList.join("|") + ")";
  }
};

// .stack/node_modules/hono/dist/router/reg-exp-router/trie.js
var Trie = class {
  #context = { varIndex: 0 };
  #root = new Node();
  insert(path, index, pathErrorCheckOnly) {
    const paramAssoc = [];
    const groups = [];
    for (let i = 0; ; ) {
      let replaced = false;
      path = path.replace(/\{[^}]+\}/g, (m) => {
        const mark2 = `@\\${i}`;
        groups[i] = [mark2, m];
        i++;
        replaced = true;
        return mark2;
      });
      if (!replaced) {
        break;
      }
    }
    const tokens = path.match(/(?::[^\/]+)|(?:\/\*$)|./g) || [];
    for (let i = groups.length - 1; i >= 0; i--) {
      const [mark2] = groups[i];
      for (let j = tokens.length - 1; j >= 0; j--) {
        if (tokens[j].indexOf(mark2) !== -1) {
          tokens[j] = tokens[j].replace(mark2, groups[i][1]);
          break;
        }
      }
    }
    this.#root.insert(tokens, index, paramAssoc, this.#context, pathErrorCheckOnly);
    return paramAssoc;
  }
  buildRegExp() {
    let regexp = this.#root.buildRegExpStr();
    if (regexp === "") {
      return [/^$/, [], []];
    }
    let captureIndex = 0;
    const indexReplacementMap = [];
    const paramReplacementMap = [];
    regexp = regexp.replace(/#(\d+)|@(\d+)|\.\*\$/g, (_, handlerIndex, paramIndex) => {
      if (handlerIndex !== void 0) {
        indexReplacementMap[++captureIndex] = Number(handlerIndex);
        return "$()";
      }
      if (paramIndex !== void 0) {
        paramReplacementMap[Number(paramIndex)] = ++captureIndex;
        return "";
      }
      return "";
    });
    return [new RegExp(`^${regexp}`), indexReplacementMap, paramReplacementMap];
  }
};

// .stack/node_modules/hono/dist/router/reg-exp-router/router.js
var nullMatcher = [/^$/, [], /* @__PURE__ */ Object.create(null)];
var wildcardRegExpCache = /* @__PURE__ */ Object.create(null);
function buildWildcardRegExp(path) {
  return wildcardRegExpCache[path] ??= new RegExp(
    path === "*" ? "" : `^${path.replace(
      /\/\*$|([.\\+*[^\]$()])/g,
      (_, metaChar) => metaChar ? `\\${metaChar}` : "(?:|/.*)"
    )}$`
  );
}
function clearWildcardRegExpCache() {
  wildcardRegExpCache = /* @__PURE__ */ Object.create(null);
}
function buildMatcherFromPreprocessedRoutes(routes) {
  const trie = new Trie();
  const handlerData = [];
  if (routes.length === 0) {
    return nullMatcher;
  }
  const routesWithStaticPathFlag = routes.map(
    (route) => [!/\*|\/:/.test(route[0]), ...route]
  ).sort(
    ([isStaticA, pathA], [isStaticB, pathB]) => isStaticA ? 1 : isStaticB ? -1 : pathA.length - pathB.length
  );
  const staticMap = /* @__PURE__ */ Object.create(null);
  for (let i = 0, j = -1, len = routesWithStaticPathFlag.length; i < len; i++) {
    const [pathErrorCheckOnly, path, handlers] = routesWithStaticPathFlag[i];
    if (pathErrorCheckOnly) {
      staticMap[path] = [handlers.map(([h]) => [h, /* @__PURE__ */ Object.create(null)]), emptyParam];
    } else {
      j++;
    }
    let paramAssoc;
    try {
      paramAssoc = trie.insert(path, j, pathErrorCheckOnly);
    } catch (e) {
      throw e === PATH_ERROR ? new UnsupportedPathError(path) : e;
    }
    if (pathErrorCheckOnly) {
      continue;
    }
    handlerData[j] = handlers.map(([h, paramCount]) => {
      const paramIndexMap = /* @__PURE__ */ Object.create(null);
      paramCount -= 1;
      for (; paramCount >= 0; paramCount--) {
        const [key, value] = paramAssoc[paramCount];
        paramIndexMap[key] = value;
      }
      return [h, paramIndexMap];
    });
  }
  const [regexp, indexReplacementMap, paramReplacementMap] = trie.buildRegExp();
  for (let i = 0, len = handlerData.length; i < len; i++) {
    for (let j = 0, len2 = handlerData[i].length; j < len2; j++) {
      const map = handlerData[i][j]?.[1];
      if (!map) {
        continue;
      }
      const keys = Object.keys(map);
      for (let k = 0, len3 = keys.length; k < len3; k++) {
        map[keys[k]] = paramReplacementMap[map[keys[k]]];
      }
    }
  }
  const handlerMap = [];
  for (const i in indexReplacementMap) {
    handlerMap[i] = handlerData[indexReplacementMap[i]];
  }
  return [regexp, handlerMap, staticMap];
}
function findMiddleware(middleware, path) {
  if (!middleware) {
    return void 0;
  }
  for (const k of Object.keys(middleware).sort((a, b) => b.length - a.length)) {
    if (buildWildcardRegExp(k).test(path)) {
      return [...middleware[k]];
    }
  }
  return void 0;
}
var RegExpRouter = class {
  name = "RegExpRouter";
  #middleware;
  #routes;
  constructor() {
    this.#middleware = { [METHOD_NAME_ALL]: /* @__PURE__ */ Object.create(null) };
    this.#routes = { [METHOD_NAME_ALL]: /* @__PURE__ */ Object.create(null) };
  }
  add(method, path, handler) {
    const middleware = this.#middleware;
    const routes = this.#routes;
    if (!middleware || !routes) {
      throw new Error(MESSAGE_MATCHER_IS_ALREADY_BUILT);
    }
    if (!middleware[method]) {
      ;
      [middleware, routes].forEach((handlerMap) => {
        handlerMap[method] = /* @__PURE__ */ Object.create(null);
        Object.keys(handlerMap[METHOD_NAME_ALL]).forEach((p) => {
          handlerMap[method][p] = [...handlerMap[METHOD_NAME_ALL][p]];
        });
      });
    }
    if (path === "/*") {
      path = "*";
    }
    const paramCount = (path.match(/\/:/g) || []).length;
    if (/\*$/.test(path)) {
      const re = buildWildcardRegExp(path);
      if (method === METHOD_NAME_ALL) {
        Object.keys(middleware).forEach((m) => {
          middleware[m][path] ||= findMiddleware(middleware[m], path) || findMiddleware(middleware[METHOD_NAME_ALL], path) || [];
        });
      } else {
        middleware[method][path] ||= findMiddleware(middleware[method], path) || findMiddleware(middleware[METHOD_NAME_ALL], path) || [];
      }
      Object.keys(middleware).forEach((m) => {
        if (method === METHOD_NAME_ALL || method === m) {
          Object.keys(middleware[m]).forEach((p) => {
            re.test(p) && middleware[m][p].push([handler, paramCount]);
          });
        }
      });
      Object.keys(routes).forEach((m) => {
        if (method === METHOD_NAME_ALL || method === m) {
          Object.keys(routes[m]).forEach(
            (p) => re.test(p) && routes[m][p].push([handler, paramCount])
          );
        }
      });
      return;
    }
    const paths = checkOptionalParameter(path) || [path];
    for (let i = 0, len = paths.length; i < len; i++) {
      const path2 = paths[i];
      Object.keys(routes).forEach((m) => {
        if (method === METHOD_NAME_ALL || method === m) {
          routes[m][path2] ||= [
            ...findMiddleware(middleware[m], path2) || findMiddleware(middleware[METHOD_NAME_ALL], path2) || []
          ];
          routes[m][path2].push([handler, paramCount - len + i + 1]);
        }
      });
    }
  }
  match = match;
  buildAllMatchers() {
    const matchers = /* @__PURE__ */ Object.create(null);
    Object.keys(this.#routes).concat(Object.keys(this.#middleware)).forEach((method) => {
      matchers[method] ||= this.#buildMatcher(method);
    });
    this.#middleware = this.#routes = void 0;
    clearWildcardRegExpCache();
    return matchers;
  }
  #buildMatcher(method) {
    const routes = [];
    let hasOwnRoute = method === METHOD_NAME_ALL;
    [this.#middleware, this.#routes].forEach((r) => {
      const ownRoute = r[method] ? Object.keys(r[method]).map((path) => [path, r[method][path]]) : [];
      if (ownRoute.length !== 0) {
        hasOwnRoute ||= true;
        routes.push(...ownRoute);
      } else if (method !== METHOD_NAME_ALL) {
        routes.push(
          ...Object.keys(r[METHOD_NAME_ALL]).map((path) => [path, r[METHOD_NAME_ALL][path]])
        );
      }
    });
    if (!hasOwnRoute) {
      return null;
    } else {
      return buildMatcherFromPreprocessedRoutes(routes);
    }
  }
};

// .stack/node_modules/hono/dist/router/smart-router/router.js
var SmartRouter = class {
  name = "SmartRouter";
  #routers = [];
  #routes = [];
  constructor(init) {
    this.#routers = init.routers;
  }
  add(method, path, handler) {
    if (!this.#routes) {
      throw new Error(MESSAGE_MATCHER_IS_ALREADY_BUILT);
    }
    this.#routes.push([method, path, handler]);
  }
  match(method, path) {
    if (!this.#routes) {
      throw new Error("Fatal error");
    }
    const routers = this.#routers;
    const routes = this.#routes;
    const len = routers.length;
    let i = 0;
    let res;
    for (; i < len; i++) {
      const router = routers[i];
      try {
        for (let i2 = 0, len2 = routes.length; i2 < len2; i2++) {
          router.add(...routes[i2]);
        }
        res = router.match(method, path);
      } catch (e) {
        if (e instanceof UnsupportedPathError) {
          continue;
        }
        throw e;
      }
      this.match = router.match.bind(router);
      this.#routers = [router];
      this.#routes = void 0;
      break;
    }
    if (i === len) {
      throw new Error("Fatal error");
    }
    this.name = `SmartRouter + ${this.activeRouter.name}`;
    return res;
  }
  get activeRouter() {
    if (this.#routes || this.#routers.length !== 1) {
      throw new Error("No active router has been determined yet.");
    }
    return this.#routers[0];
  }
};

// .stack/node_modules/hono/dist/router/trie-router/node.js
var emptyParams = /* @__PURE__ */ Object.create(null);
var hasChildren = (children) => {
  for (const _ in children) {
    return true;
  }
  return false;
};
var Node2 = class _Node2 {
  #methods;
  #children;
  #patterns;
  #order = 0;
  #params = emptyParams;
  constructor(method, handler, children) {
    this.#children = children || /* @__PURE__ */ Object.create(null);
    this.#methods = [];
    if (method && handler) {
      const m = /* @__PURE__ */ Object.create(null);
      m[method] = { handler, possibleKeys: [], score: 0 };
      this.#methods = [m];
    }
    this.#patterns = [];
  }
  insert(method, path, handler) {
    this.#order = ++this.#order;
    let curNode = this;
    const parts = splitRoutingPath(path);
    const possibleKeys = [];
    for (let i = 0, len = parts.length; i < len; i++) {
      const p = parts[i];
      const nextP = parts[i + 1];
      const pattern = getPattern(p, nextP);
      const key = Array.isArray(pattern) ? pattern[0] : p;
      if (key in curNode.#children) {
        curNode = curNode.#children[key];
        if (pattern) {
          possibleKeys.push(pattern[1]);
        }
        continue;
      }
      curNode.#children[key] = new _Node2();
      if (pattern) {
        curNode.#patterns.push(pattern);
        possibleKeys.push(pattern[1]);
      }
      curNode = curNode.#children[key];
    }
    curNode.#methods.push({
      [method]: {
        handler,
        possibleKeys: possibleKeys.filter((v, i, a) => a.indexOf(v) === i),
        score: this.#order
      }
    });
    return curNode;
  }
  #pushHandlerSets(handlerSets, node, method, nodeParams, params) {
    for (let i = 0, len = node.#methods.length; i < len; i++) {
      const m = node.#methods[i];
      const handlerSet = m[method] || m[METHOD_NAME_ALL];
      const processedSet = {};
      if (handlerSet !== void 0) {
        handlerSet.params = /* @__PURE__ */ Object.create(null);
        handlerSets.push(handlerSet);
        if (nodeParams !== emptyParams || params && params !== emptyParams) {
          for (let i2 = 0, len2 = handlerSet.possibleKeys.length; i2 < len2; i2++) {
            const key = handlerSet.possibleKeys[i2];
            const processed = processedSet[handlerSet.score];
            handlerSet.params[key] = params?.[key] && !processed ? params[key] : nodeParams[key] ?? params?.[key];
            processedSet[handlerSet.score] = true;
          }
        }
      }
    }
  }
  search(method, path) {
    const handlerSets = [];
    this.#params = emptyParams;
    const curNode = this;
    let curNodes = [curNode];
    const parts = splitPath(path);
    const curNodesQueue = [];
    const len = parts.length;
    let partOffsets = null;
    for (let i = 0; i < len; i++) {
      const part = parts[i];
      const isLast = i === len - 1;
      const tempNodes = [];
      for (let j = 0, len2 = curNodes.length; j < len2; j++) {
        const node = curNodes[j];
        const nextNode = node.#children[part];
        if (nextNode) {
          nextNode.#params = node.#params;
          if (isLast) {
            if (nextNode.#children["*"]) {
              this.#pushHandlerSets(handlerSets, nextNode.#children["*"], method, node.#params);
            }
            this.#pushHandlerSets(handlerSets, nextNode, method, node.#params);
          } else {
            tempNodes.push(nextNode);
          }
        }
        for (let k = 0, len3 = node.#patterns.length; k < len3; k++) {
          const pattern = node.#patterns[k];
          const params = node.#params === emptyParams ? {} : { ...node.#params };
          if (pattern === "*") {
            const astNode = node.#children["*"];
            if (astNode) {
              this.#pushHandlerSets(handlerSets, astNode, method, node.#params);
              astNode.#params = params;
              tempNodes.push(astNode);
            }
            continue;
          }
          const [key, name, matcher] = pattern;
          if (!part && !(matcher instanceof RegExp)) {
            continue;
          }
          const child = node.#children[key];
          if (matcher instanceof RegExp) {
            if (partOffsets === null) {
              partOffsets = new Array(len);
              let offset = path[0] === "/" ? 1 : 0;
              for (let p = 0; p < len; p++) {
                partOffsets[p] = offset;
                offset += parts[p].length + 1;
              }
            }
            const restPathString = path.substring(partOffsets[i]);
            const m = matcher.exec(restPathString);
            if (m) {
              params[name] = m[0];
              this.#pushHandlerSets(handlerSets, child, method, node.#params, params);
              if (hasChildren(child.#children)) {
                child.#params = params;
                const componentCount = m[0].match(/\//)?.length ?? 0;
                const targetCurNodes = curNodesQueue[componentCount] ||= [];
                targetCurNodes.push(child);
              }
              continue;
            }
          }
          if (matcher === true || matcher.test(part)) {
            params[name] = part;
            if (isLast) {
              this.#pushHandlerSets(handlerSets, child, method, params, node.#params);
              if (child.#children["*"]) {
                this.#pushHandlerSets(
                  handlerSets,
                  child.#children["*"],
                  method,
                  params,
                  node.#params
                );
              }
            } else {
              child.#params = params;
              tempNodes.push(child);
            }
          }
        }
      }
      const shifted = curNodesQueue.shift();
      curNodes = shifted ? tempNodes.concat(shifted) : tempNodes;
    }
    if (handlerSets.length > 1) {
      handlerSets.sort((a, b) => {
        return a.score - b.score;
      });
    }
    return [handlerSets.map(({ handler, params }) => [handler, params])];
  }
};

// .stack/node_modules/hono/dist/router/trie-router/router.js
var TrieRouter = class {
  name = "TrieRouter";
  #node;
  constructor() {
    this.#node = new Node2();
  }
  add(method, path, handler) {
    const results = checkOptionalParameter(path);
    if (results) {
      for (let i = 0, len = results.length; i < len; i++) {
        this.#node.insert(method, results[i], handler);
      }
      return;
    }
    this.#node.insert(method, path, handler);
  }
  match(method, path) {
    return this.#node.search(method, path);
  }
};

// .stack/node_modules/hono/dist/hono.js
var Hono2 = class extends Hono {
  /**
   * Creates an instance of the Hono class.
   *
   * @param options - Optional configuration options for the Hono instance.
   */
  constructor(options = {}) {
    super(options);
    this.router = options.router ?? new SmartRouter({
      routers: [new RegExpRouter(), new TrieRouter()]
    });
  }
};

// server/command.mjs
var BY_STATUS = { 400: "BAD_INPUT", 403: "NOT_ALLOWED", 404: "NOT_FOUND", 424: "MISSING_KEYS", 502: "SITE_FAILED", 504: "SITE_TIMEOUT" };
var Refused = class extends Error {
  constructor(message, status = 409, extra = {}) {
    super(message);
    this.status = status;
    this.code = extra.code ?? (/^Only a person/.test(message) ? "PERSON_ONLY" : BY_STATUS[status] ?? "REFUSED");
    if (extra.item !== void 0) this.item = extra.item;
  }
};
var commandsOf = (app) => app.commands ??= [];
var inputNames = (input) => Array.isArray(input) ? input.flatMap((x) => typeof x === "string" ? [x] : Object.keys(x)) : Object.keys(input ?? {});
function command(app, method, path, spec, handler) {
  commandsOf(app).push({ ...spec, method, path, input: spec.input ?? {}, by: spec.by ?? "anyone", read: method === "GET" });
  app.on(method, path, async (c) => {
    const actor = c.req.header("x-actor") || "";
    if (spec.by === "person" && !actor.startsWith("person:")) throw new Refused(`Only a person can do this: ask them. (${spec.name})`, 403);
    const body = method === "GET" ? c.req.query() : await c.req.json().catch(() => ({}));
    const input = {};
    for (const k of inputNames(spec.input)) if (body[k] !== void 0) input[k] = body[k];
    for (const [k, v] of Object.entries(c.req.param())) input[k] = /^\d+$/.test(v) ? Number(v) : v;
    return c.json(await handler(input, { actor }) ?? { ok: true });
  });
}
function mountErrors(app) {
  app.onError((e, c) => c.json({ error: e.message, code: e.code ?? (e.status && e.status < 500 ? "REFUSED" : "FAILED"), ...e.item !== void 0 ? { item: e.item } : {} }, e.status ?? 500));
  app.get("/_commands", (c) => c.json(commandsOf(app)));
}

// server/services/util.mjs
var T = {
  projects: "obras_projects",
  units: "obras_units",
  chapters: "obras_chapters",
  incidents: "obras_incidents",
  notes: "obras_notes",
  visits: "obras_visits",
  procedures: "obras_procedures",
  reports: "obras_reports",
  attachments: "obras_attachments",
  hours: "obras_hours",
  settings: "obras_settings",
  jobs: "obras_jobs",
  companies: "obras_companies",
  people: "obras_people"
};
var LIVE = "_deleted = 0 AND COALESCE(removed, 0) = 0";
var isPerson = (actor) => String(actor || "").startsWith("person:");
var wantsFull = (i, actor) => isPerson(actor) || i.full === true || i.full === "true";
var who = (actor) => String(actor || "").replace(/^(person|agent):/, "") || "agent";
var today = (now = /* @__PURE__ */ new Date()) => new Intl.DateTimeFormat("sv-SE", { timeZone: "Europe/Madrid" }).format(now);
var ISO = /^(\d{4})-(\d{2})-(\d{2})$/;
function dateOf(v, field = "date") {
  if (v === void 0 || v === null || v === "") return null;
  const s = String(v).trim().slice(0, 10);
  const dmy = /^(\d{1,2})[/.-](\d{1,2})[/.-](\d{4})$/.exec(String(v).trim());
  const iso = dmy ? `${dmy[3]}-${dmy[2].padStart(2, "0")}-${dmy[1].padStart(2, "0")}` : s;
  const m = ISO.exec(iso);
  if (!m || Number(m[2]) < 1 || Number(m[2]) > 12 || Number(m[3]) < 1 || Number(m[3]) > 31) throw new Refused(`${field} is a date written YYYY-MM-DD (got "${String(v).slice(0, 30)}").`, 400, { code: "BAD_DATE" });
  return iso;
}
var daysBetween = (from, to) => Math.round((Date.parse(to + "T00:00:00Z") - Date.parse(from + "T00:00:00Z")) / 864e5);
var addDays = (date, n) => new Date(Date.parse(date + "T00:00:00Z") + n * 864e5).toISOString().slice(0, 10);
var text = (v, max = 4e3) => v === void 0 || v === null ? null : String(v).trim().slice(0, max);
var bool = (v) => v === true || v === 1 || v === "1" || v === "true" ? 1 : 0;
function int(v, field = "number") {
  if (v === void 0 || v === null || v === "") return null;
  const n = Number(v);
  if (!Number.isFinite(n)) throw new Refused(`${field} is a number (got "${String(v).slice(0, 30)}").`, 400, { code: "BAD_NUMBER" });
  return Math.round(n);
}
function cents(v, field = "amount") {
  if (v === void 0 || v === null || v === "") return null;
  const n = Number(typeof v === "string" ? v.replace(/\s|€/g, "").replace(/\.(?=\d{3}(\D|$))/g, "").replace(",", ".") : v);
  if (!Number.isFinite(n)) throw new Refused(`${field} is an amount in euros, as a number (got "${String(v).slice(0, 30)}").`, 400, { code: "BAD_NUMBER" });
  return Math.round(n * 100);
}
var euros = (c) => c === void 0 || c === null ? null : c / 100;
function listOf(v, name) {
  if (Array.isArray(v)) return v;
  if (typeof v === "string" && v.trim().startsWith("[")) {
    try {
      const j = JSON.parse(v);
      if (Array.isArray(j)) return j;
    } catch {
    }
  }
  throw new Refused(`${name} is a list: ${name}: [ \u2026 ].`, 400, { code: "BAD_INPUT" });
}
var said = (v) => String(v ?? "").trim().toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "").replace(/[_-]+/g, " ").replace(/\s+/g, " ");
function wordOf(v, words) {
  const k = said(v);
  if (!k) return null;
  for (const [key, list6] of Object.entries(words)) if (said(key) === k || list6.includes(k)) return key;
  return null;
}
function choiceOf(v, words, field) {
  if (v === void 0 || v === null || v === "") return null;
  const key = wordOf(v, words);
  if (key) return key;
  throw new Refused(`${field} is one of: ${Object.keys(words).join(", ")} (got "${String(v).slice(0, 30)}").`, 400, { code: "BAD_CHOICE" });
}
function num(v, field = "number") {
  if (v === void 0 || v === null || v === "") return null;
  const n = Number(typeof v === "string" ? v.trim().replace(",", ".") : v);
  if (!Number.isFinite(n)) throw new Refused(`${field} is a number (got "${String(v).slice(0, 30)}").`, 400, { code: "BAD_NUMBER" });
  return Math.round(n * 100) / 100;
}
function timeOf(v, field = "time") {
  if (v === void 0 || v === null || v === "") return null;
  const m = /^(\d{1,2})(?:\s*[:.h]\s*(\d{2}))?(?::\d{2})?\s*h?$/i.exec(String(v).trim().replace(/^\d{4}-\d{2}-\d{2}[T ]/, "").replace(/(\.\d+)?(Z|[+-]\d{2}:?\d{2})$/, ""));
  if (!m || Number(m[1]) > 24 || Number(m[2] ?? 0) > 59) throw new Refused(`${field} is a time written HH:MM (got "${String(v).slice(0, 30)}").`, 400, { code: "BAD_TIME" });
  return `${m[1].padStart(2, "0")}:${m[2] ?? "00"}`;
}
function yes(v) {
  if (v === true || v === 1) return 1;
  const k = said(v);
  return !k || ["0", "no", "false", "f", "n", "null", "none"].includes(k) ? 0 : 1;
}
var r2 = (n) => Math.round(n * 100) / 100;
function weekOf(date) {
  const d = /* @__PURE__ */ new Date(date + "T00:00:00Z");
  d.setUTCDate(d.getUTCDate() + 4 - (d.getUTCDay() || 7));
  const first = Date.UTC(d.getUTCFullYear(), 0, 1);
  return `${d.getUTCFullYear()}-W${String(Math.ceil(((d - first) / 864e5 + 1) / 7)).padStart(2, "0")}`;
}
function sumBy(rows, keyOf, cols) {
  const by = /* @__PURE__ */ new Map();
  for (const r of rows) {
    const k = keyOf(r);
    if (!by.has(k)) by.set(k, Object.fromEntries(Object.keys(cols).map((c) => [c, 0])));
    const o = by.get(k);
    for (const [c, fn] of Object.entries(cols)) o[c] = r2(o[c] + (Number(fn(r)) || 0));
  }
  return [...by.entries()].map(([key, o]) => ({ key, ...o }));
}
var sent = (o) => Object.fromEntries(Object.entries(o).filter(([, v]) => v !== void 0));
var count = async (db, sql, params = []) => Number((await db.one(sql, params))?.n ?? 0);

// server/services/template.mjs
var C = (code, name, subs = []) => [{ code, name, parent: "" }, ...subs.map(([c, n]) => ({ code: c, name: n, parent: code }))];
var DEFAULT_CHAPTERS = [
  ...C("01", "Inicials", [["11", "Actuacions Pr\xE8vies"], ["12", "Estudis i Inspeccions"]]),
  ...C("02", "Projectes", [["21", "Arquitecte"], ["22", "Arquitecte T\xE8cnic"], ["23", "Altres t\xE8cnics"], ["24", "Altres (OCT)"]]),
  ...C("03", "Execuci\xF3", [
    ["D", "Enderrocs i Previs"],
    ["A", "Condicionament del Terreny"],
    ["C", "Fonamentaci\xF3"],
    ["E", "Estructura"],
    ["F", "Fa\xE7anes i Particions"],
    ["L", "Fusteria, Manyeria, Vidres i Proteccions Solars"],
    ["I", "Instal\xB7lacions"],
    ["N", "A\xEFllaments i Impermeabilitzacions"],
    ["Q", "Cobertes"],
    ["R", "Revestiments i Extradossats"],
    ["S", "Senyalitzaci\xF3 i Equipament"],
    ["G", "Gesti\xF3 de Residus"],
    ["X", "Control de Qualitat i Assaigs"],
    ["Y", "Seguretat i Salut"],
    ["W", "Extres i Opcionals"],
    ["U", "Urbanitzaci\xF3, Jardineria i Altres"],
    ["Z", "Altres"]
  ]),
  ...C("04", "Permisos i Legalitzacions", [["41", "Subministraments"], ["42", "Col\xB7legis Professionals"], ["43", "Permisos, Certificats i Llic\xE8ncies"], ["44", "Dip\xF2sits de Garantia"]]),
  ...C("05", "Escomeses i Consums", [["51", "Escomeses"], ["52", "Consums"]]),
  ...C("06", "Assegurances", [["61", "Obra (TRC, Decennal)"], ["62", "Finca Existent (RC)"]]),
  ...C("07", "Jur\xEDdic i Financer"),
  ...C("08", "Comercial i M\xE0rqueting"),
  ...C("09", "Vendes", [["71", "Habitatges"], ["72", "Locals"], ["73", "Aparcaments"]])
];

// server/services/projects.mjs
var UNIT_KINDS = { habitatge: ["vivienda", "viviendas", "habitatges", "home", "homes", "piso", "pisos"], local: ["locals", "locales", "premises"], aparcament: ["aparcaments", "aparcamiento", "aparcamientos", "parking", "plaza", "plazas"], traster: ["trasters", "trastero", "trasteros", "storage"], altre: ["otro", "otros", "altres", "other"] };
var UNIT_STATES = { available: ["disponible", "lliure", "libre"], reserved: ["reservado", "reservat", "reservada"], sold: ["vendido", "vendida", "venut", "venuda"] };
var PROJECT_STATES = { active: ["activa", "actiu", "activo", "en marcha", "en marxa", "en curso", "en curs", "obert", "oberta", "abierto", "abierta", "en execucio", "en ejecucion"], finished: ["terminada", "terminado", "acabada", "acabat", "finalizada", "finalizado", "finalitzat", "finalitzada", "tancat", "tancada", "cerrado", "cerrada", "entregat", "entregada", "entregado"], archived: ["archivada", "archivado", "arxivada", "arxivat", "inactiu", "inactiva", "inactivo"] };
var UNIT_NAME = { habitatge: "Habitatge", local: "Local", aparcament: "Aparcament", traster: "Traster", altre: "Unitat" };
async function projectOf(db, id) {
  const n = Number(id);
  const p = Number.isInteger(n) && n > 0 ? await db.one(`SELECT * FROM ${T.projects} WHERE _id = ? AND ${LIVE}`, [n]) : null;
  if (!p) throw new Refused(id === void 0 || id === null || id === "" ? "Say which project: project_id. List them with projects." : `There is no project ${id}. List them with projects.`, id ? 404 : 400, { code: id ? "NOT_FOUND" : "PROJECT_REQUIRED", ...id ? { item: id } : {} });
  return p;
}
async function chaptersOf(db, projectId) {
  return (await db.all(`SELECT code, name, parent FROM ${T.chapters} WHERE project_id = ? AND ${LIVE} ORDER BY position, _id`, [projectId])).map((c) => ({ code: c.code, name: c.name, parent: c.parent || "" }));
}
function chapterTree(chapters) {
  const top = chapters.filter((c) => !c.parent).map((c) => ({ code: c.code, name: c.name, subs: [] }));
  for (const c of chapters) if (c.parent) top.find((t) => t.code === c.parent)?.subs.push({ code: c.code, name: c.name });
  return top;
}
function chapterProblems(chapters) {
  const p = [];
  const tops = /* @__PURE__ */ new Set();
  const seen = /* @__PURE__ */ new Set();
  for (const c of chapters) if (!c.parent) tops.add(c.code);
  for (const [i, c] of chapters.entries()) {
    if (!/^[A-Za-z0-9]{1,6}$/.test(c.code || "")) p.push(`Line ${i + 1}: a code is 1 to 6 letters or digits (got "${c.code}").`);
    if (!c.name) p.push(`Line ${i + 1}: ${c.code} has no name.`);
    if (c.parent && !tops.has(c.parent)) p.push(`Line ${i + 1}: ${c.code} is under ${c.parent}, which is not a chapter.`);
    const key = `${c.parent}/${c.code}`;
    if (seen.has(key)) p.push(`Line ${i + 1}: ${c.parent ? c.parent + "/" : ""}${c.code} is repeated.`);
    seen.add(key);
  }
  if (!tops.size) p.push('There is no chapter: at least one line like "03 Execuci\xF3".');
  return p;
}
function parseChapters(input) {
  if (Array.isArray(input)) return input.map((c) => ({ code: String(c.code ?? "").trim(), name: String(c.name ?? "").trim(), parent: String(c.parent ?? c.parent_code ?? "").trim() }));
  const out = [];
  let last = "";
  for (const raw2 of String(input ?? "").split("\n")) {
    if (!raw2.trim()) continue;
    const indented = /^\s+/.test(raw2);
    const m = /^\s*(?:([A-Za-z0-9]+)\/)?([A-Za-z0-9]+)[\s.:—-]+(.+)$/.exec(raw2);
    if (!m) {
      out.push({ code: raw2.trim().slice(0, 12), name: "", parent: "" });
      continue;
    }
    const parent = m[1] || (indented ? last : "");
    if (!parent) last = m[2];
    out.push({ code: m[2], name: m[3].trim(), parent });
  }
  return out;
}
async function insertChapters(db, projectId, chapters) {
  await db.batch(chapters.map((c, i) => ({ op: "insert", table: T.chapters, data: { project_id: projectId, code: c.code, name: c.name, parent: c.parent || "", position: i, removed: 0 } })));
}
function unitsFrom(input, startAt = {}) {
  const out = [];
  const next = { ...startAt };
  for (const u of input) {
    const kind = choiceOf(u.kind ?? "habitatge", UNIT_KINDS, "kind");
    const state = choiceOf(u.state ?? "available", UNIT_STATES, "state");
    const n = u.count === void 0 ? 1 : int(u.count, "count");
    if (n < 1 || n > 500) throw new Refused("count is between 1 and 500.", 400, { code: "BAD_NUMBER" });
    for (let i = 0; i < n; i++) {
      next[kind] = (next[kind] ?? 0) + 1;
      out.push({ kind, state, name: n === 1 && text(u.name, 120) ? text(u.name, 120) : `${text(u.name, 100) || UNIT_NAME[kind]} ${next[kind]}` });
    }
  }
  return out;
}
var shape = (p) => ({ id: p._id, name: p.name, code: p.code || "", address: p.address || "", city: p.city || "", client: p.client || "", group: p.group_name || "", kind: p.kind || "", responsible: p.responsible || "", color: p.color || "", state: p.state || "active", started_on: p.started_on || null, ends_on: p.ends_on || null, notes: p.notes || "", ...p.demo ? { demo: true } : {} });
async function list(db, { state } = {}) {
  const rows = await db.all(`SELECT * FROM ${T.projects} WHERE ${LIVE} ORDER BY CASE COALESCE(state, 'active') WHEN 'active' THEN 0 WHEN 'finished' THEN 1 ELSE 2 END, _id DESC`);
  const open = await db.all(`SELECT project_id, severity, COUNT(*) AS n FROM ${T.incidents} WHERE ${LIVE} AND closed_on IS NULL GROUP BY project_id, severity`);
  const procs = await db.all(`SELECT project_id, COUNT(*) AS n FROM ${T.procedures} WHERE ${LIVE} AND COALESCE(state, 'pending') != 'done' GROUP BY project_id`);
  const want = state ? choiceOf(state, PROJECT_STATES, "state") : null;
  return {
    rows: rows.filter((p) => !want || (p.state || "active") === want).map((p) => {
      const mine = open.filter((o) => o.project_id === p._id);
      const by = (s) => Number(mine.find((o) => o.severity === s)?.n ?? 0);
      return { ...shape(p), open: mine.reduce((a, o) => a + Number(o.n), 0), greu: by("greu"), important: by("important"), lleu: by("lleu"), procedures_open: Number(procs.find((x) => x.project_id === p._id)?.n ?? 0) };
    })
  };
}
async function detail(db, { id }, full) {
  const p = await projectOf(db, id);
  const units = await db.all(`SELECT _id AS id, kind, name, state FROM ${T.units} WHERE project_id = ? AND ${LIVE} ORDER BY kind, _id`, [p._id]);
  const chapters = await chaptersOf(db, p._id);
  const counts = {};
  for (const u of units) {
    counts[u.kind] ??= { total: 0, sold: 0, reserved: 0 };
    counts[u.kind].total++;
    if (u.state === "sold") counts[u.kind].sold++;
    if (u.state === "reserved") counts[u.kind].reserved++;
  }
  return {
    ...shape(p),
    cover_id: p.cover_id || null,
    units: counts,
    ...full ? { unit_rows: units, chapters } : { chapters: chapterTree(chapters).map((c) => `${c.code} ${c.name}${c.subs.length ? ` (${c.subs.map((s) => s.code).join(" ")})` : ""}`) },
    open: await count(db, `SELECT COUNT(*) AS n FROM ${T.incidents} WHERE project_id = ? AND ${LIVE} AND closed_on IS NULL`, [p._id])
  };
}
var fields = (i) => sent({
  name: i.name === void 0 ? void 0 : text(i.name, 200),
  code: i.code === void 0 ? void 0 : text(i.code, 20),
  address: i.address === void 0 ? void 0 : text(i.address, 300),
  city: i.city === void 0 ? void 0 : text(i.city, 200),
  client: i.client === void 0 ? void 0 : text(i.client, 200),
  group_name: i.group === void 0 ? void 0 : text(i.group, 120),
  kind: i.kind === void 0 ? void 0 : text(i.kind, 80),
  responsible: i.responsible === void 0 ? void 0 : text(i.responsible, 120),
  color: i.color === void 0 ? void 0 : text(i.color, 20),
  notes: i.notes === void 0 ? void 0 : text(i.notes),
  started_on: i.started_on === void 0 ? void 0 : dateOf(i.started_on, "started_on"),
  ends_on: i.ends_on === void 0 ? void 0 : dateOf(i.ends_on, "ends_on"),
  state: i.state === void 0 ? void 0 : choiceOf(i.state, PROJECT_STATES, "state") ?? "active"
});
async function add(db, i, { demo = false, now } = {}) {
  const data = fields(i);
  if (!data.name) throw new Refused("A project needs a name: name.", 400, { code: "NAME_REQUIRED" });
  const same3 = await db.one(`SELECT _id FROM ${T.projects} WHERE ${LIVE} AND lower(name) = lower(?)`, [data.name]);
  if (same3) throw new Refused(`There is already a project called "${data.name}" (id ${same3._id}): use it, or give this one another name.`, 409, { code: "ALREADY_THERE", item: same3._id });
  const chapters = i.copy_chapters_from ? await chaptersOf(db, (await projectOf(db, i.copy_chapters_from))._id) : DEFAULT_CHAPTERS;
  const units = i.units === void 0 ? [] : unitsFrom(listOf(i.units, "units"));
  let demoRemoved = false;
  if (!demo) demoRemoved = (await removeDemo(db)).removed > 0;
  const id = await db.insert(T.projects, { state: "active", started_on: today(now), ...data, demo: demo ? 1 : 0, removed: 0 });
  if (!demo) await exampleOff(db);
  await insertChapters(db, id, chapters.length ? chapters : DEFAULT_CHAPTERS);
  if (units.length) await db.batch(units.map((u) => ({ op: "insert", table: T.units, data: { project_id: id, ...u, removed: 0 } })));
  return { id, name: data.name, chapters: chapters.length, units: units.length, ...demoRemoved ? { example_removed: true } : {} };
}
async function update(db, i) {
  const p = await projectOf(db, i.id);
  const data = fields(i);
  if (data.name === "") throw new Refused("A project keeps a name.", 400, { code: "NAME_REQUIRED" });
  if (i.cover_id !== void 0) data.cover_id = int(i.cover_id, "cover_id");
  if (Object.keys(data).length) await db.update(T.projects, p._id, data);
  return { id: p._id, changed: Object.keys(data) };
}
async function archive(db, { id }) {
  const p = await projectOf(db, id);
  await db.update(T.projects, p._id, { state: "archived" });
  return { id: p._id, state: "archived" };
}
async function unitsAdd(db, i) {
  const p = await projectOf(db, i.project_id);
  const have = {};
  for (const r of await db.all(`SELECT kind, COUNT(*) AS n FROM ${T.units} WHERE project_id = ? GROUP BY kind`, [p._id])) have[r.kind] = Number(r.n);
  const units = unitsFrom(listOf(i.units, "units"), have);
  if (!units.length) throw new Refused("Say which units: units: [{ kind, name }] or [{ kind, count }].", 400, { code: "BAD_INPUT" });
  const ids = await db.batch(units.map((u) => ({ op: "insert", table: T.units, data: { project_id: p._id, ...u, removed: 0 } })));
  return { project_id: p._id, added: ids.length, ids };
}
async function unitsUpdate(db, i) {
  const changed = [];
  const skipped = [];
  for (const u of listOf(i.units, "units")) {
    try {
      const row2 = await db.one(`SELECT _id FROM ${T.units} WHERE _id = ? AND ${LIVE}`, [Number(u.id)]);
      if (!row2) throw new Refused("That unit is no longer there.", 404, { code: "NOT_FOUND" });
      const data = u.remove ? { removed: 1 } : sent({ name: u.name === void 0 ? void 0 : text(u.name, 120), kind: u.kind === void 0 ? void 0 : choiceOf(u.kind, UNIT_KINDS, "kind"), state: u.state === void 0 ? void 0 : choiceOf(u.state, UNIT_STATES, "state") });
      if (Object.keys(data).length) await db.update(T.units, row2._id, data);
      changed.push(row2._id);
    } catch (e) {
      if (!(e instanceof Refused)) throw e;
      skipped.push({ id: u.id ?? null, code: e.code, why: e.message });
    }
  }
  return { changed, skipped };
}
async function chaptersSet(db, i) {
  const p = await projectOf(db, i.project_id);
  const next = parseChapters(i.chapters);
  const wrong = chapterProblems(next);
  if (wrong.length) throw new Refused(`The chapters were not saved. ${wrong.slice(0, 5).join(" ")}`, 400, { code: "BAD_CHAPTERS" });
  const used = await db.all(`SELECT DISTINCT chapter, subchapter FROM ${T.incidents} WHERE project_id = ? AND ${LIVE}`, [p._id]);
  const has = (code, parent) => next.some((c) => c.code === code && c.parent === parent);
  const lost = used.filter((u) => u.chapter && !has(u.chapter, "") || u.subchapter && !has(u.subchapter, u.chapter)).map((u) => `${u.chapter}${u.subchapter ? "/" + u.subchapter : ""}`);
  if (lost.length) throw new Refused(`Incidents use ${lost.join(", ")}: keep those lines (the name can change), or move those incidents first.`, 409, { code: "CHAPTER_IN_USE", item: lost });
  for (const c of await db.all(`SELECT _id FROM ${T.chapters} WHERE project_id = ? AND ${LIVE}`, [p._id])) await db.update(T.chapters, c._id, { removed: 1 });
  await insertChapters(db, p._id, next);
  return { project_id: p._id, chapters: next.filter((c) => !c.parent).length, subchapters: next.filter((c) => c.parent).length };
}
async function exampleOff(db) {
  const row2 = await db.one(`SELECT _id, example FROM ${T.settings} WHERE _deleted = 0 ORDER BY _id LIMIT 1`);
  if (row2?.example === "off") return;
  if (row2) await db.update(T.settings, row2._id, { example: "off" });
  else await db.insert(T.settings, { example: "off" });
}
async function removeDemo(db) {
  const demos = await db.all(`SELECT _id FROM ${T.projects} WHERE ${LIVE} AND demo = 1`);
  for (const d of demos) {
    for (const t of [T.incidents, T.units, T.chapters, T.visits, T.procedures, T.reports, T.attachments, T.hours, T.jobs]) for (const r of await db.all(`SELECT _id FROM ${t} WHERE project_id = ? AND ${LIVE}`, [d._id])) await db.update(t, r._id, { removed: 1 });
    await db.update(T.projects, d._id, { removed: 1 });
  }
  if (demos.length) for (const t of [T.companies, T.people]) for (const r of await db.all(`SELECT _id FROM ${t} WHERE source = 'demo' AND ${LIVE}`)) await db.update(t, r._id, { removed: 1 });
  return { removed: demos.length };
}

// server/services/incidents.mjs
var SEVERITIES = { lleu: ["leve", "menor", "minor", "low", "baja", "baixa"], important: ["importante", "moderada", "moderate", "medium", "media", "mitjana"], greu: ["grave", "severe", "high", "alta", "critica", "critical"] };
var INCIDENT_STATES = {
  oberta: ["abierta", "open", "nova", "nueva", "new", "obert", "abierto", "registrada", "detectada"],
  en_curs: ["en curso", "en proces", "en proceso", "in progress", "doing", "en marxa", "en marcha", "en execucio", "en ejecucion", "assignada", "asignada", "en reparacio", "en reparacion"],
  pendent: ["pendiente", "pending", "waiting", "en espera", "esperant", "bloquejada", "bloqueada", "blocked", "aturada", "parada", "pendent de resposta", "pendiente de respuesta"],
  tancada: ["tancat", "cerrada", "cerrado", "closed", "resolta", "resuelta", "resolt", "resuelto", "done", "feta", "hecha", "finalitzada", "finalizada", "solucionada", "validada"]
};
var stateOf = (r) => r.closed_on ? "tancada" : r.state && r.state !== "tancada" ? r.state : "oberta";
var RANK = { greu: 0, important: 1, lleu: 2 };
var plain = (s) => String(s ?? "").trim().toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "");
function resolveChapter(chapters, chapter, subchapter) {
  const tops = chapters.filter((c) => !c.parent);
  const subs = chapters.filter((c) => c.parent);
  const said2 = String(chapter ?? "").trim();
  const saidSub = String(subchapter ?? "").trim();
  if (!said2 && !saidSub) return { chapter: "", subchapter: "" };
  const [a, b] = said2.includes("/") ? said2.split("/").map((x) => x.trim()) : [said2, ""];
  const topBy = (x) => {
    const k = plain(x).split(/\s+/)[0];
    return tops.find((c) => plain(c.code) === k || plain(c.code) === k.padStart(2, "0")) || tops.find((c) => plain(c.name) === plain(x) || plain(`${c.code} ${c.name}`) === plain(x));
  };
  const subBy = (x, parent) => {
    const k = plain(x);
    const of = subs.filter((c) => !parent || c.parent === parent);
    const hit = of.filter((c) => plain(c.code) === k || plain(c.name) === k || plain(`${c.code} ${c.name}`) === k || plain(`${c.code} - ${c.name}`) === k);
    return hit.length === 1 || hit.length > 1 && parent ? hit[0] : hit.find((c) => c.parent === "03") || null;
  };
  let top = a ? topBy(a) : null;
  let sub = null;
  if (!top && a) {
    sub = subBy(a);
    if (sub) top = tops.find((c) => c.code === sub.parent);
  }
  const wantSub = saidSub || b;
  if (wantSub) {
    sub = subBy(wantSub, top?.code);
    if (sub && !top) top = tops.find((c) => c.code === sub.parent);
  }
  if (!top || wantSub && !sub) throw new Refused(`This project has no chapter "${[said2, saidSub].filter(Boolean).join(" / ")}". Its chapters: ${tops.map((c) => `${c.code} ${c.name}`).join(", ")}${top ? `; under ${top.code}: ${subs.filter((c) => c.parent === top.code).map((c) => `${c.code} ${c.name}`).join(", ") || "none"}` : ""}.`, 400, { code: "UNKNOWN_CHAPTER" });
  return { chapter: top.code, subchapter: sub ? sub.code : "" };
}
function delayOf(row2, day) {
  if (row2.delay_days !== null && row2.delay_days !== void 0) return Number(row2.delay_days);
  if (!row2.due_on) return 0;
  return Math.max(0, daysBetween(row2.due_on, row2.closed_on || day));
}
var refOf = (chapter, subchapter, n) => `${chapter || "00"}${subchapter ? "." + subchapter : ""}-${String(n).padStart(3, "0")}`;
var whole = (r, day, names2 = {}) => ({
  id: r._id,
  project_id: r.project_id,
  ref: r.ref,
  title: r.title,
  chapter: r.chapter || "",
  subchapter: r.subchapter || "",
  ...names2.chapter !== void 0 ? { chapter_name: names2.chapter, subchapter_name: names2.subchapter } : {},
  location: r.location || "",
  visit_id: r.visit_id || null,
  started_on: r.started_on,
  reported_by: r.reported_by || "",
  responsible: r.responsible || "",
  due_on: r.due_on || null,
  expected_delay_days: r.expected_delay_days ?? null,
  delay_days: r.delay_days ?? null,
  delay: delayOf(r, day),
  closed_on: r.closed_on || null,
  open: !r.closed_on,
  state: stateOf(r),
  severity: r.severity || "lleu",
  description: r.description || "",
  remarks: r.remarks || "",
  cost_estimated: euros(r.cost_estimated),
  cost_real: euros(r.cost_real),
  cost_approved_on: r.cost_approved_on || null,
  cost_certified: !!r.cost_certified,
  cost_invoiced: !!r.cost_invoiced,
  cost_paid: !!r.cost_paid,
  plan_id: r.plan_id || null,
  pin_x: r.pin_x ?? null,
  pin_y: r.pin_y ?? null
});
var brief = (r, day) => ({ id: r._id, ref: r.ref, title: String(r.title).slice(0, 80), chapter: `${r.chapter || ""}${r.subchapter ? "/" + r.subchapter : ""}`, severity: r.severity || "lleu", ...["en_curs", "pendent"].includes(stateOf(r)) ? { state: stateOf(r) } : {}, ...r.location ? { location: r.location } : {}, ...r.responsible ? { responsible: r.responsible } : {}, started_on: r.started_on, ...delayOf(r, day) ? { delay: delayOf(r, day) } : {}, ...r.closed_on ? { closed_on: r.closed_on } : {} });
async function incidentOf(db, id) {
  const n = Number(id);
  const r = Number.isInteger(n) && n > 0 ? await db.one(`SELECT * FROM ${T.incidents} WHERE _id = ? AND ${LIVE}`, [n]) : null;
  if (!r) throw new Refused(`There is no incident ${id ?? ""}: list them with incidents (each has its id and ref).`, 404, { code: "NOT_FOUND", item: id ?? null });
  return r;
}
async function find(db, { id, ref, project_id }) {
  if (id !== void 0 && id !== null && id !== "") return incidentOf(db, id);
  const rows = ref ? await db.all(`SELECT * FROM ${T.incidents} WHERE lower(ref) = lower(?) AND ${LIVE}${project_id ? " AND project_id = ?" : ""}`, project_id ? [String(ref), Number(project_id)] : [String(ref)]) : [];
  if (rows.length === 1) return rows[0];
  throw new Refused(rows.length ? `Several projects have an incident ${ref}: say project_id too, or use its id.` : `There is no incident ${ref ?? ""}: name it by id or by ref (incidents lists both).`, rows.length ? 409 : 404, { code: rows.length ? "AMBIGUOUS" : "NOT_FOUND", item: ref ?? null });
}
async function list2(db, i, full, now) {
  const day = today(now);
  const exact = ["open", "closed", "all"].includes(i.state) || !i.state ? null : choiceOf(i.state, INCIDENT_STATES, "state");
  const state = exact ? exact === "tancada" ? "closed" : "open" : i.state || "open";
  const conds = [LIVE];
  const params = [];
  if (i.project_id) {
    conds.push("project_id = ?");
    params.push((await projectOf(db, i.project_id))._id);
  } else conds.push(`project_id IN (SELECT _id FROM ${T.projects} WHERE ${LIVE} AND COALESCE(state, 'active') != 'archived')`);
  if (state === "open") conds.push("closed_on IS NULL");
  if (state === "closed") conds.push("closed_on IS NOT NULL");
  if (exact && exact !== "tancada") {
    conds.push("COALESCE(state, 'oberta') = ?");
    params.push(exact);
  }
  if (i.chapter) {
    conds.push("chapter = ?");
    params.push(String(i.chapter).split("/")[0].trim().padStart(2, "0"));
  }
  if (i.severity) {
    conds.push("severity = ?");
    params.push(choiceOf(i.severity, SEVERITIES, "severity"));
  }
  if (i.visit_id) {
    conds.push("visit_id = ?");
    params.push(Number(i.visit_id));
  }
  if (i.since) {
    conds.push("started_on >= ?");
    params.push(dateOf(i.since, "since"));
  }
  if (i.q) {
    conds.push("(lower(title) LIKE ? OR lower(ref) LIKE ? OR lower(COALESCE(location, '')) LIKE ?)");
    const q = `%${String(i.q).toLowerCase()}%`;
    params.push(q, q, q);
  }
  const rows = (await db.all(`SELECT * FROM ${T.incidents} WHERE ${conds.join(" AND ")}`, params)).sort((a, b) => (RANK[a.severity] ?? 3) - (RANK[b.severity] ?? 3) || String(b.started_on).localeCompare(String(a.started_on)) || b._id - a._id);
  if (full) {
    const names2 = new Map((await db.all(`SELECT project_id, code, parent, name FROM ${T.chapters} WHERE ${LIVE}`)).map((c) => [`${c.project_id}|${c.parent || ""}|${c.code}`, c.name]));
    return { total: rows.length, rows: rows.map((r) => whole(r, day, { chapter: names2.get(`${r.project_id}||${r.chapter}`) ?? "", subchapter: names2.get(`${r.project_id}|${r.chapter}|${r.subchapter}`) ?? "" })) };
  }
  const limit = Math.min(Math.max(int(i.limit) ?? 15, 1), 50);
  const from = Math.max(int(i.offset) ?? 0, 0);
  const by = (key) => {
    const o = {};
    for (const r of rows) o[r[key] || "\u2014"] = (o[r[key] || "\u2014"] ?? 0) + 1;
    return o;
  };
  return { state, total: rows.length, by_severity: by("severity"), by_chapter: by("chapter"), rows: rows.slice(from, from + limit).map((r) => brief(r, day)), ...rows.length > from + limit ? { more: `offset: ${from + limit} for the next ${Math.min(limit, rows.length - from - limit)}; or narrow with project_id, chapter, severity, since, q.` } : {} };
}
async function one(db, i, now) {
  const r = await find(db, i);
  const chapters = await chaptersOf(db, r.project_id);
  const p = await db.one(`SELECT name FROM ${T.projects} WHERE _id = ?`, [r.project_id]);
  const notes = await db.all(`SELECT _id AS id, day, text, author FROM ${T.notes} WHERE incident_id = ? AND ${LIVE} ORDER BY day, _id`, [r._id]);
  const files = await db.all(`SELECT _id AS id, kind, name, source, ref, note, CASE WHEN data IS NULL OR data = '' THEN 0 ELSE 1 END AS has_data FROM ${T.attachments} WHERE incident_id = ? AND ${LIVE} ORDER BY _id`, [r._id]);
  return {
    ...whole(r, today(now), { chapter: chapters.find((c) => !c.parent && c.code === r.chapter)?.name ?? "", subchapter: chapters.find((c) => c.parent === r.chapter && c.code === r.subchapter)?.name ?? "" }),
    project: p?.name ?? "",
    notes,
    attachments: files.map((f) => ({ ...f, has_data: !!f.has_data }))
  };
}
function cardFields(i, chapters, before = null) {
  const d = sent({
    title: i.title === void 0 ? void 0 : text(i.title, 200),
    location: i.location === void 0 ? void 0 : text(i.location, 200),
    reported_by: i.reported_by === void 0 ? void 0 : text(i.reported_by, 120),
    responsible: i.responsible === void 0 ? void 0 : text(i.responsible, 120),
    description: i.description === void 0 ? void 0 : text(i.description, 8e3),
    remarks: i.remarks === void 0 ? void 0 : text(i.remarks, 4e3),
    state: i.state === void 0 ? void 0 : choiceOf(i.state, INCIDENT_STATES, "state") ?? "oberta",
    ref: i.ref === void 0 ? void 0 : text(i.ref, 40),
    started_on: i.started_on === void 0 ? void 0 : dateOf(i.started_on, "started_on"),
    due_on: i.due_on === void 0 ? void 0 : dateOf(i.due_on, "due_on"),
    closed_on: i.closed_on === void 0 ? void 0 : dateOf(i.closed_on, "closed_on"),
    cost_approved_on: i.cost_approved_on === void 0 ? void 0 : dateOf(i.cost_approved_on, "cost_approved_on"),
    expected_delay_days: i.expected_delay_days === void 0 ? void 0 : int(i.expected_delay_days, "expected_delay_days"),
    delay_days: i.delay_days === void 0 ? void 0 : int(i.delay_days, "delay_days"),
    severity: i.severity === void 0 ? void 0 : choiceOf(i.severity, SEVERITIES, "severity") ?? "lleu",
    cost_estimated: i.cost_estimated === void 0 ? void 0 : cents(i.cost_estimated, "cost_estimated"),
    cost_real: i.cost_real === void 0 ? void 0 : cents(i.cost_real, "cost_real"),
    cost_certified: i.cost_certified === void 0 ? void 0 : bool(i.cost_certified),
    cost_invoiced: i.cost_invoiced === void 0 ? void 0 : bool(i.cost_invoiced),
    cost_paid: i.cost_paid === void 0 ? void 0 : bool(i.cost_paid),
    visit_id: i.visit_id === void 0 ? void 0 : int(i.visit_id, "visit_id")
  });
  if (i.chapter !== void 0 || i.subchapter !== void 0) Object.assign(d, resolveChapter(chapters, i.chapter ?? before?.chapter, i.subchapter ?? (i.chapter !== void 0 ? "" : before?.subchapter)));
  return d;
}
async function addMany(db, i, actor, now) {
  const p = await projectOf(db, i.project_id);
  const items = listOf(i.items, "items");
  if (!items.length) throw new Refused("Say what was found: items: [{ title, chapter, location, severity, description }].", 400, { code: "BAD_INPUT" });
  if (items.length > 100) throw new Refused("At most 100 incidents in one call: send the rest in another.", 400, { code: "TOO_MANY" });
  const day = today(now);
  const chapters = await chaptersOf(db, p._id);
  let visitId = i.visit_id ? int(i.visit_id, "visit_id") : null;
  if (visitId && !await db.one(`SELECT _id FROM ${T.visits} WHERE _id = ? AND project_id = ? AND ${LIVE}`, [visitId, p._id])) throw new Refused(`Project ${p._id} has no visit ${visitId}: list them with visits, or send visit: { day } to make it.`, 404, { code: "NOT_FOUND", item: visitId });
  let visitOn = null;
  if (!visitId && i.visit && typeof i.visit === "object") {
    visitOn = dateOf(i.visit.day ?? i.visit.on, "visit.day") ?? day;
    const had = await db.one(`SELECT _id FROM ${T.visits} WHERE project_id = ? AND day = ? AND ${LIVE}`, [p._id, visitOn]);
    visitId = had ? had._id : await db.insert(T.visits, { project_id: p._id, day: visitOn, attendees: text(i.visit.attendees, 500) || "", summary: text(i.visit.summary) || "", removed: 0 });
  } else if (visitId) visitOn = (await db.one(`SELECT day FROM ${T.visits} WHERE _id = ?`, [visitId]))?.day ?? null;
  let n = Number((await db.one(`SELECT COUNT(*) AS n FROM ${T.incidents} WHERE project_id = ?`, [p._id]))?.n ?? 0);
  const added = [];
  const skipped = [];
  for (const [index, raw2] of items.entries()) {
    try {
      const it = raw2 && typeof raw2 === "object" ? raw2 : {};
      const d = cardFields({ severity: "lleu", ...it }, chapters);
      d.title = d.title || (d.description ? d.description.split(/[.\n]/)[0].slice(0, 90) : "");
      if (!d.title) throw new Refused("An incident needs a title (a few words) or a description.", 400, { code: "TITLE_REQUIRED" });
      d.started_on = d.started_on ?? visitOn ?? day;
      if (d.state === "tancada" && !d.closed_on) d.closed_on = d.started_on > day ? d.started_on : day;
      d.state = d.closed_on ? "tancada" : d.state ?? "oberta";
      const dup = await db.one(`SELECT _id FROM ${T.incidents} WHERE project_id = ? AND lower(title) = lower(?) AND started_on = ? AND ${LIVE}`, [p._id, d.title, d.started_on]);
      if (dup) throw new Refused("It is already there, with the same title and start date: nothing was added.", 409, { code: "DUPLICATE", item: dup._id });
      n += 1;
      const ref = d.ref || refOf(d.chapter, d.subchapter, n);
      const id = await db.insert(T.incidents, { chapter: "", subchapter: "", ...d, ref, project_id: p._id, visit_id: d.visit_id ?? visitId, reported_by: d.reported_by || who(actor), removed: 0 });
      if (it.note) await db.insert(T.notes, { incident_id: id, day: d.started_on, text: text(it.note), author: who(actor), removed: 0 });
      added.push({ id, ref });
    } catch (e) {
      if (!(e instanceof Refused)) throw e;
      skipped.push({ index, code: e.code, why: e.message, ...e.item !== void 0 ? { item: e.item } : {} });
    }
  }
  return { project_id: p._id, added, ...visitId ? { visit_id: visitId } : {}, skipped };
}
async function updateMany(db, i, actor, now) {
  const changed = [];
  const skipped = [];
  const cache = /* @__PURE__ */ new Map();
  for (const [index, it] of listOf(i.items, "items").entries()) {
    try {
      const r = await find(db, it ?? {});
      if (!cache.has(r.project_id)) cache.set(r.project_id, await chaptersOf(db, r.project_id));
      const d = cardFields(it, cache.get(r.project_id), r);
      if (it.closed_on === null || it.closed_on === "") d.closed_on = null;
      if (d.closed_on) d.state = "tancada";
      else if (d.closed_on === null) d.state = d.state && d.state !== "tancada" ? d.state : "oberta";
      else if (d.state === "tancada" && !r.closed_on) d.closed_on = today(now);
      else if (d.state && d.state !== "tancada" && r.closed_on) d.closed_on = null;
      for (const k of ["due_on", "cost_approved_on", "delay_days", "expected_delay_days", "cost_estimated", "cost_real"]) if (it[k] === null || it[k] === "") d[k] = null;
      if (d.title === "") throw new Refused("An incident keeps a title.", 400, { code: "TITLE_REQUIRED" });
      if (d.closed_on && d.closed_on < (d.started_on ?? r.started_on)) throw new Refused(`It cannot close (${d.closed_on}) before it started (${d.started_on ?? r.started_on}).`, 400, { code: "BAD_DATE" });
      if (Object.keys(d).length) await db.update(T.incidents, r._id, d);
      if (it.note) await db.insert(T.notes, { incident_id: r._id, day: dateOf(it.note_day, "note_day") ?? today(now), text: text(it.note), author: who(actor), removed: 0 });
      changed.push(r._id);
    } catch (e) {
      if (!(e instanceof Refused)) throw e;
      skipped.push({ index, code: e.code, why: e.message, ...e.item !== void 0 ? { item: e.item } : {} });
    }
  }
  return { changed, skipped };
}
async function closeMany(db, i, actor, now) {
  const on = dateOf(i.closed_on, "closed_on") ?? today(now);
  const closed = [];
  const skipped = [];
  for (const id of listOf(i.ids, "ids")) {
    try {
      const r = await incidentOf(db, id);
      if (r.closed_on) throw new Refused(`It was already closed on ${r.closed_on}.`, 409, { code: "ALREADY_CLOSED", item: r._id });
      if (on < r.started_on) throw new Refused(`It cannot close (${on}) before it started (${r.started_on}).`, 400, { code: "BAD_DATE", item: r._id });
      await db.update(T.incidents, r._id, { closed_on: on, state: "tancada" });
      if (i.note) await db.insert(T.notes, { incident_id: r._id, day: on, text: text(i.note), author: who(actor), removed: 0 });
      closed.push(r._id);
    } catch (e) {
      if (!(e instanceof Refused)) throw e;
      skipped.push({ id, code: e.code, why: e.message });
    }
  }
  return { closed, closed_on: on, skipped };
}
async function notesAdd(db, i, actor, now) {
  let added = 0;
  const ids = [];
  const skipped = [];
  for (const [index, it] of listOf(i.items, "items").entries()) {
    try {
      const r = await find(db, { id: it?.incident_id ?? it?.id, ref: it?.ref, project_id: it?.project_id });
      const t = text(it.text);
      if (!t) throw new Refused("A follow-up note needs its text.", 400, { code: "TEXT_REQUIRED" });
      ids.push(await db.insert(T.notes, { incident_id: r._id, day: dateOf(it.day ?? it.on, "day") ?? today(now), text: t, author: who(actor), removed: 0 }));
      added += 1;
    } catch (e) {
      if (!(e instanceof Refused)) throw e;
      skipped.push({ index, code: e.code, why: e.message });
    }
  }
  return { added, ids, skipped };
}
async function noteRemove(db, { id }) {
  const changed = await db.update(T.notes, Number(id), { removed: 1 });
  if (!changed) throw new Refused("That note is no longer there.", 404, { code: "NOT_FOUND", item: id });
  return { id: Number(id), removed: true };
}
async function remove(db, { id }) {
  const r = await incidentOf(db, id);
  await db.update(T.incidents, r._id, { removed: 1 });
  return { id: r._id, removed: true };
}

// server/services/work.mjs
var PROCEDURE_KINDS = { licence: ["llicencia", "licencia", "permis", "permiso", "license", "certificat", "certificado"], connection: ["escomesa", "acometida", "subministrament", "suministro", "supply"], insurance: ["asseguranca", "seguro", "assegurances", "seguros"], deposit: ["diposit", "deposito", "garantia", "aval", "fianza", "fianca"], contract: ["contracte", "contrato"], legal: ["juridic", "juridico", "financer", "financiero", "notaria"], other: ["altre", "otro", "altres", "otros"] };
var PROCEDURE_STATES = { pending: ["pendent", "pendiente", "todo"], in_progress: ["en curs", "en curso", "en tramit", "en tramite", "doing", "started"], blocked: ["bloquejat", "bloqueado", "aturat", "parado"], done: ["fet", "hecho", "tancat", "cerrado", "resolt", "resuelto", "concedida", "concedit"] };
var ORDER = { blocked: 0, in_progress: 1, pending: 2, done: 3 };
var visitOf = async (db, id) => {
  const v = await db.one(`SELECT * FROM ${T.visits} WHERE _id = ? AND ${LIVE}`, [Number(id) || 0]);
  if (!v) throw new Refused(`There is no visit ${id ?? ""}: list them with visits.`, 404, { code: "NOT_FOUND", item: id ?? null });
  return v;
};
async function visitAdd(db, i, now) {
  const p = await projectOf(db, i.project_id);
  const day = dateOf(i.day, "day") ?? today(now);
  const had = await db.one(`SELECT _id FROM ${T.visits} WHERE project_id = ? AND day = ? AND ${LIVE}`, [p._id, day]);
  if (had) {
    const d = sent({ attendees: i.attendees === void 0 ? void 0 : text(i.attendees, 500), summary: i.summary === void 0 ? void 0 : text(i.summary) });
    if (Object.keys(d).length) await db.update(T.visits, had._id, d);
    return { id: had._id, day, existed: true };
  }
  return { id: await db.insert(T.visits, { project_id: p._id, day, attendees: text(i.attendees, 500) || "", summary: text(i.summary) || "", removed: 0 }), day };
}
async function visitUpdate(db, i) {
  const v = await visitOf(db, i.id);
  const d = sent({ day: i.day === void 0 ? void 0 : dateOf(i.day, "day"), attendees: i.attendees === void 0 ? void 0 : text(i.attendees, 500), summary: i.summary === void 0 ? void 0 : text(i.summary) });
  if (Object.keys(d).length) await db.update(T.visits, v._id, d);
  return { id: v._id, changed: Object.keys(d) };
}
async function visits(db, i) {
  const conds = [LIVE];
  const params = [];
  if (i.project_id) {
    conds.push("project_id = ?");
    params.push((await projectOf(db, i.project_id))._id);
  } else conds.push(`project_id IN (SELECT _id FROM ${T.projects} WHERE ${LIVE} AND COALESCE(state, 'active') != 'archived')`);
  const rows = await db.all(`SELECT _id AS id, project_id, day, attendees, summary FROM ${T.visits} WHERE ${conds.join(" AND ")} ORDER BY day DESC, _id DESC LIMIT 200`, params);
  const counts = await db.all(`SELECT visit_id, COUNT(*) AS n, SUM(CASE WHEN closed_on IS NULL THEN 1 ELSE 0 END) AS open FROM ${T.incidents} WHERE ${LIVE} AND visit_id IS NOT NULL GROUP BY visit_id`);
  return { rows: rows.map((v) => {
    const c = counts.find((x) => x.visit_id === v.id);
    return { ...v, incidents: Number(c?.n ?? 0), open: Number(c?.open ?? 0) };
  }) };
}
async function visit(db, { id }) {
  const v = await visitOf(db, id);
  const p = await db.one(`SELECT name FROM ${T.projects} WHERE _id = ?`, [v.project_id]);
  const found = await db.all(`SELECT _id AS id, ref, title, chapter, subchapter, severity, location, closed_on FROM ${T.incidents} WHERE visit_id = ? AND ${LIVE} ORDER BY _id`, [v._id]);
  const files = await db.all(`SELECT _id AS id, kind, name, source, ref, note, CASE WHEN data IS NULL OR data = '' THEN 0 ELSE 1 END AS has_data FROM ${T.attachments} WHERE visit_id = ? AND incident_id IS NULL AND ${LIVE} ORDER BY _id`, [v._id]);
  return { id: v._id, project_id: v.project_id, project: p?.name ?? "", day: v.day, attendees: v.attendees || "", summary: v.summary || "", incidents: found, attachments: files.map((f) => ({ ...f, has_data: !!f.has_data })) };
}
var procFields = (i) => sent({
  title: i.title === void 0 ? void 0 : text(i.title, 200),
  kind: i.kind === void 0 ? void 0 : choiceOf(i.kind, PROCEDURE_KINDS, "kind") ?? "other",
  state: i.state === void 0 ? void 0 : choiceOf(i.state, PROCEDURE_STATES, "state") ?? "pending",
  next_step: i.next_step === void 0 ? void 0 : text(i.next_step, 400),
  next_on: i.next_on === void 0 ? void 0 : dateOf(i.next_on, "next_on"),
  responsible: i.responsible === void 0 ? void 0 : text(i.responsible, 120),
  notes: i.notes === void 0 ? void 0 : text(i.notes),
  done_on: i.done_on === void 0 ? void 0 : dateOf(i.done_on, "done_on"),
  chapter: i.chapter === void 0 ? void 0 : text(i.chapter, 12)
});
async function proceduresAdd(db, i) {
  const p = await projectOf(db, i.project_id);
  const added = [];
  const skipped = [];
  for (const [index, it] of listOf(i.items, "items").entries()) {
    try {
      const d = procFields({ kind: "other", state: "pending", ...it });
      if (!d.title) throw new Refused(`A procedure needs a title ("Llic\xE8ncia d'obres").`, 400, { code: "TITLE_REQUIRED" });
      const dup = await db.one(`SELECT _id FROM ${T.procedures} WHERE project_id = ? AND lower(title) = lower(?) AND ${LIVE}`, [p._id, d.title]);
      if (dup) throw new Refused("It is already there with that title: change it with procedures_update.", 409, { code: "DUPLICATE", item: dup._id });
      added.push(await db.insert(T.procedures, { next_step: "", responsible: "", notes: "", chapter: "", ...d, project_id: p._id, removed: 0 }));
    } catch (e) {
      if (!(e instanceof Refused)) throw e;
      skipped.push({ index, code: e.code, why: e.message, ...e.item !== void 0 ? { item: e.item } : {} });
    }
  }
  return { project_id: p._id, added, skipped };
}
async function proceduresUpdate(db, i, now) {
  const changed = [];
  const skipped = [];
  for (const [index, it] of listOf(i.items, "items").entries()) {
    try {
      const r = await db.one(`SELECT _id, state, done_on FROM ${T.procedures} WHERE _id = ? AND ${LIVE}`, [Number(it?.id) || 0]);
      if (!r) throw new Refused(`There is no procedure ${it?.id ?? ""}: list them with procedures.`, 404, { code: "NOT_FOUND", item: it?.id ?? null });
      const d = it.remove ? { removed: 1 } : procFields(it);
      if (d.title === "") throw new Refused("A procedure keeps a title.", 400, { code: "TITLE_REQUIRED" });
      if (it.next_on === null || it.next_on === "") d.next_on = null;
      if (d.state === "done" && !d.done_on && !r.done_on) d.done_on = today(now);
      if (d.state && d.state !== "done" && d.done_on === void 0) d.done_on = null;
      if (Object.keys(d).length) await db.update(T.procedures, r._id, d);
      changed.push(r._id);
    } catch (e) {
      if (!(e instanceof Refused)) throw e;
      skipped.push({ index, code: e.code, why: e.message });
    }
  }
  return { changed, skipped };
}
async function procedures(db, i, full, now) {
  const conds = [LIVE];
  const params = [];
  if (i.project_id) {
    conds.push("project_id = ?");
    params.push((await projectOf(db, i.project_id))._id);
  } else conds.push(`project_id IN (SELECT _id FROM ${T.projects} WHERE ${LIVE} AND COALESCE(state, 'active') != 'archived')`);
  if (i.state === "open") conds.push(`COALESCE(state, 'pending') != 'done'`);
  else if (i.state) {
    conds.push("state = ?");
    params.push(choiceOf(i.state, PROCEDURE_STATES, "state"));
  }
  const day = today(now);
  const rows = (await db.all(`SELECT _id AS id, project_id, title, kind, state, next_step, next_on, responsible, notes, done_on, chapter FROM ${T.procedures} WHERE ${conds.join(" AND ")}`, params)).sort((a, b) => (ORDER[a.state] ?? 2) - (ORDER[b.state] ?? 2) || String(a.next_on || "9").localeCompare(String(b.next_on || "9")) || a.id - b.id).map((r) => ({ ...r, ...r.state !== "done" && r.next_on && r.next_on < day ? { late: true } : {} }));
  if (full) return { total: rows.length, rows };
  const by = {};
  for (const r of rows) by[r.state || "pending"] = (by[r.state || "pending"] ?? 0) + 1;
  return { total: rows.length, by_state: by, rows: rows.slice(0, 30).map((r) => ({ id: r.id, title: r.title, kind: r.kind, state: r.state, ...r.next_step ? { next_step: r.next_step } : {}, ...r.next_on ? { next_on: r.next_on } : {}, ...r.late ? { late: true } : {}, ...r.done_on ? { done_on: r.done_on } : {} })), ...rows.length > 30 ? { more: "Only the first 30: narrow with project_id or state." } : {} };
}
async function trend(db, i, now) {
  const day = today(now);
  const weeks = Math.min(Math.max(int(i.weeks) ?? 12, 4), 52);
  const monday = addDays(day, -(((/* @__PURE__ */ new Date(day + "T00:00:00Z")).getUTCDay() + 6) % 7));
  const pid = i.project_id ? (await projectOf(db, i.project_id))._id : null;
  const rows = await db.all(`SELECT started_on, closed_on FROM ${T.incidents} WHERE ${LIVE} AND ${pid ? "project_id = ?" : `project_id IN (SELECT _id FROM ${T.projects} WHERE ${LIVE} AND COALESCE(state, 'active') != 'archived')`}`, pid ? [pid] : []);
  const out = [];
  for (let k = weeks - 1; k >= 0; k--) {
    const from = addDays(monday, -7 * k);
    const to = addDays(from, 6);
    out.push({ week: from, opened: rows.filter((r) => r.started_on >= from && r.started_on <= to).length, closed: rows.filter((r) => r.closed_on && r.closed_on >= from && r.closed_on <= to).length, open: rows.filter((r) => r.started_on && r.started_on <= to && (!r.closed_on || r.closed_on > to)).length });
  }
  return { weeks: out };
}
async function week(db, i, now) {
  const day = today(now);
  const days = Math.min(Math.max(int(i.days) ?? 7, 1), 92);
  const since = addDays(day, -days);
  const scope = i.project_id ? [(await projectOf(db, i.project_id))._id] : (await db.all(`SELECT _id FROM ${T.projects} WHERE ${LIVE} AND COALESCE(state, 'active') != 'archived'`)).map((p) => p._id);
  if (!scope.length) return { since, until: day, opened: { count: 0, rows: [] }, closed: { count: 0, rows: [] }, notes: 0, visits: [], procedures_done: [] };
  const inScope = `project_id IN (${scope.map(() => "?").join(",")})`;
  const line2 = (r) => ({ id: r._id, ref: r.ref, title: String(r.title).slice(0, 60), severity: r.severity, ...scope.length > 1 ? { project_id: r.project_id } : {} });
  const first = (rows) => ({ count: rows.length, rows: rows.slice(0, 8).map(line2), ...rows.length > 8 ? { more: "incidents { since, state } lists them all." } : {} });
  const opened = await db.all(`SELECT _id, ref, title, severity, project_id FROM ${T.incidents} WHERE ${LIVE} AND ${inScope} AND started_on > ? ORDER BY started_on DESC LIMIT 200`, [...scope, since]);
  const closed = await db.all(`SELECT _id, ref, title, severity, project_id FROM ${T.incidents} WHERE ${LIVE} AND ${inScope} AND closed_on > ? ORDER BY closed_on DESC LIMIT 200`, [...scope, since]);
  const notes = await db.one(`SELECT COUNT(*) AS n FROM ${T.notes} WHERE ${LIVE} AND day > ? AND incident_id IN (SELECT _id FROM ${T.incidents} WHERE ${LIVE} AND ${inScope})`, [since, ...scope]);
  const seen = await db.all(`SELECT _id AS id, project_id, day FROM ${T.visits} WHERE ${LIVE} AND ${inScope} AND day > ? ORDER BY day DESC`, [...scope, since]);
  const done = await db.all(`SELECT _id AS id, project_id, title, done_on FROM ${T.procedures} WHERE ${LIVE} AND ${inScope} AND done_on > ? ORDER BY done_on DESC`, [...scope, since]);
  return { since, until: day, opened: first(opened), closed: first(closed), notes: Number(notes?.n ?? 0), visits: seen, procedures_done: done };
}

// server/services/files.mjs
var ATTACHMENT_KINDS = { photo: ["foto", "fotografia", "image", "imagen", "imatge"], plan: ["planol", "plano", "planell"], doc: ["document", "documento", "file", "pdf"] };
var DATA = /^data:(image\/(?:jpeg|png|webp)|application\/pdf);base64,[A-Za-z0-9+/=]+$/;
var MAX_DATA = 28e5;
async function add2(db, i) {
  const added = [];
  const skipped = [];
  for (const [index, it] of listOf(i.items, "items").entries()) {
    try {
      const where = { project_id: null, incident_id: null, visit_id: null };
      if (it?.incident_id) {
        const r = await incidentOf(db, it.incident_id);
        where.incident_id = r._id;
        where.project_id = r.project_id;
        where.visit_id = r.visit_id || null;
      } else if (it?.visit_id) {
        const v = await db.one(`SELECT _id, project_id FROM ${T.visits} WHERE _id = ? AND ${LIVE}`, [Number(it.visit_id) || 0]);
        if (!v) throw new Refused(`There is no visit ${it.visit_id}.`, 404, { code: "NOT_FOUND", item: it.visit_id });
        where.visit_id = v._id;
        where.project_id = v.project_id;
      } else where.project_id = (await projectOf(db, it?.project_id ?? i.project_id))._id;
      const kind = choiceOf(it.kind ?? "photo", ATTACHMENT_KINDS, "kind");
      let source;
      let ref = "";
      let data = "";
      if (it.data) {
        if (typeof it.data !== "string" || !DATA.test(it.data)) throw new Refused('data is a data URL of a JPEG, PNG or WebP image, or a PDF ("data:image/jpeg;base64,\u2026").', 400, { code: "BAD_DATA" });
        if (it.data.length > MAX_DATA) throw new Refused("That file is over 2 MB: make the image smaller (1600 px on its long side is plenty), or keep the file in the team's files folder and attach it by path.", 413, { code: "TOO_BIG" });
        source = "upload";
        data = it.data;
      } else if (it.url) {
        if (!/^https:\/\/[^\s]{4,500}$/.test(String(it.url))) throw new Refused("url is an https:// address.", 400, { code: "BAD_INPUT" });
        source = "link";
        ref = String(it.url);
      } else if (it.path) {
        source = "file";
        ref = text(it.path, 500);
      } else throw new Refused("An attachment is one of: data (a data URL), path (where the file is in the team's files folder) or url.", 400, { code: "BAD_INPUT" });
      if (kind === "plan" && source !== "upload") throw new Refused("A plan to place incidents on is an image sent as data (JPEG or PNG): export the page of the PDF as an image first.", 400, { code: "PLAN_NEEDS_IMAGE" });
      added.push(await db.insert(T.attachments, { ...where, kind, name: text(it.name, 200) || (ref ? ref.split("/").pop() : kind), source, ref, data, note: text(it.note, 500) || "", removed: 0 }));
    } catch (e) {
      if (!(e instanceof Refused)) throw e;
      skipped.push({ index, code: e.code, why: e.message });
    }
  }
  return { added, skipped };
}
async function list3(db, i) {
  const p = await projectOf(db, i.project_id);
  const kind = i.kind ? choiceOf(i.kind, ATTACHMENT_KINDS, "kind") : null;
  const rows = await db.all(`SELECT _id AS id, incident_id, visit_id, kind, name, source, ref, note, CASE WHEN data IS NULL OR data = '' THEN 0 ELSE 1 END AS has_data FROM ${T.attachments} WHERE project_id = ? AND ${LIVE}${kind ? " AND kind = ?" : ""} ORDER BY _id DESC LIMIT 200`, kind ? [p._id, kind] : [p._id]);
  return { rows: rows.map((r) => ({ ...r, has_data: !!r.has_data })) };
}
async function one2(db, { id, full }, person) {
  if (!person && full !== true && full !== "true") throw new Refused("A file's bytes are for the screen (they would fill your context). Its name, note and where it is are in incident { id } \u2192 attachments.", 409, { code: "FOR_THE_SCREEN", item: id });
  const r = await db.one(`SELECT _id AS id, project_id, incident_id, kind, name, source, ref, note, data FROM ${T.attachments} WHERE _id = ? AND ${LIVE}`, [Number(id) || 0]);
  if (!r) throw new Refused("That file is no longer there.", 404, { code: "NOT_FOUND", item: id });
  return r;
}
async function remove2(db, { id }) {
  const changed = await db.update(T.attachments, Number(id) || 0, { removed: 1 });
  if (!changed) throw new Refused("That file is no longer there.", 404, { code: "NOT_FOUND", item: id });
  for (const r of await db.all(`SELECT _id FROM ${T.incidents} WHERE plan_id = ? AND ${LIVE}`, [Number(id)])) await db.update(T.incidents, r._id, { plan_id: null, pin_x: null, pin_y: null });
  return { id: Number(id), removed: true };
}
async function pinSet(db, i) {
  const r = await incidentOf(db, i.incident_id ?? i.id);
  if (i.plan_id === null || i.plan_id === "" || i.plan_id === void 0) {
    await db.update(T.incidents, r._id, { plan_id: null, pin_x: null, pin_y: null });
    return { id: r._id, pinned: false };
  }
  const plan = await db.one(`SELECT _id FROM ${T.attachments} WHERE _id = ? AND project_id = ? AND kind = 'plan' AND ${LIVE}`, [Number(i.plan_id) || 0, r.project_id]);
  if (!plan) throw new Refused(`Plan ${i.plan_id} is not one of this project's plans: list them with attachments { project_id, kind: "plan" }.`, 404, { code: "NOT_FOUND", item: i.plan_id });
  const x = Number(i.x);
  const y = Number(i.y);
  if (!(x >= 0 && x <= 1 && y >= 0 && y <= 1)) throw new Refused("x and y say where on the plan, each from 0 to 1 (0.5, 0.5 is its centre).", 400, { code: "BAD_NUMBER" });
  await db.update(T.incidents, r._id, { plan_id: plan._id, pin_x: x, pin_y: y });
  return { id: r._id, pinned: true, plan_id: plan._id };
}
async function planPins(db, { plan_id }) {
  const rows = await db.all(`SELECT _id AS id, ref, title, severity, closed_on, pin_x AS x, pin_y AS y FROM ${T.incidents} WHERE plan_id = ? AND ${LIVE}`, [Number(plan_id) || 0]);
  return { rows };
}

// shared/words.js
var REPORT_LANGUAGES = { ca: "Catal\xE0", es: "Castellano" };
var REPORT_WORDS = {
  ca: {
    months: ["Gener", "Febrer", "Mar\xE7", "Abril", "Maig", "Juny", "Juliol", "Agost", "Setembre", "Octubre", "Novembre", "Desembre"],
    project: "Projecte",
    tracking: "Seguiment de projecte",
    monthly: "Informe de progr\xE9s mensual",
    report: "Informe mensual",
    confidential: "Document confidencial",
    units: { habitatge: "Habitatges", local: "Locals", aparcament: "Aparcaments", traster: "Trasters", altre: "Altres" },
    summary: "Resum executiu",
    outlook: "Properes passes",
    incidents: "Incid\xE8ncies",
    byChapter: "Incid\xE8ncies per cap\xEDtol",
    bySeverity: "Per gravetat",
    management: "Gesti\xF3",
    extraCosts: "Contradictoris",
    sales: "Vendes",
    detail: "Detall",
    photos: "Fotografies",
    open: "Obertes",
    opened: "Noves del mes",
    closed: "Tancades del mes",
    openAtEnd: "Obertes a final de mes",
    severity: { greu: "Greu", important: "Important", lleu: "Lleu" },
    severities: { greu: "Greus", important: "Importants", lleu: "Lleus" },
    ref: "N\xFAm. refer\xE8ncia",
    chapter: "Cap\xEDtol",
    subchapter: "Subcap\xEDtol",
    location: "Ubicaci\xF3",
    started: "Data inici",
    agent: "Agent",
    responsible: "Responsable",
    forecast: "Previsi\xF3",
    delay: "Retard",
    closing: "Tancament",
    severityLabel: "Gravetat",
    days: "dies",
    description: "Descripci\xF3",
    followUp: "Seguiment",
    attached: "Documentaci\xF3 adjunta",
    state: "Estat",
    inProgress: "En curs",
    closedState: "Tancada",
    costForecast: "Cost previsi\xF3",
    costReal: "Cost real",
    approval: "Data aprovaci\xF3",
    certified: "Certificat",
    invoiced: "Facturat",
    paid: "Pagat",
    yes: "S\xED",
    no: "No",
    estimated: "Estimat",
    real: "Real",
    approved: "Aprovats",
    pending: "Pendents d'aprovar",
    total: "Total",
    amount: "Import",
    procedure: "Gesti\xF3",
    next: "Seg\xFCent pas",
    date: "Data",
    sold: "Venuts",
    reserved: "Reservats",
    available: "Disponibles",
    kinds: { licence: "Permisos i llic\xE8ncies", connection: "Escomeses i subministraments", insurance: "Assegurances", deposit: "Dip\xF2sits i garanties", contract: "Contracte", legal: "Jur\xEDdic i financer", other: "Altres gestions" },
    states: { pending: "Pendent", in_progress: "En curs", blocked: "Bloquejat", done: "Fet" },
    work: "Hores i treballs del mes",
    hours: "Hores",
    worker: "Operari",
    ordinary: "Ordin\xE0ries",
    overtime: "Extres",
    travel: "Despla\xE7ament",
    billableJobs: "Treballs facturables",
    concept: "Concepte",
    jobStates: { pendent: "Per facturar", facturat: "Facturat", cobrat: "Cobrat" },
    noHours: "Cap hora registrada aquest mes.",
    noJobs: "Cap treball facturable aquest mes.",
    none: "Cap incid\xE8ncia en aquest per\xEDode.",
    noProcedures: "Cap gesti\xF3 registrada.",
    noSummary: "Resum pendent de redactar.",
    mainIncidents: "Incid\xE8ncies greus i importants",
    draft: "Esborrany",
    page: "P\xE0g."
  },
  es: {
    months: ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"],
    project: "Proyecto",
    tracking: "Seguimiento de proyecto",
    monthly: "Informe de progreso mensual",
    report: "Informe mensual",
    confidential: "Documento confidencial",
    units: { habitatge: "Viviendas", local: "Locales", aparcament: "Aparcamientos", traster: "Trasteros", altre: "Otros" },
    summary: "Resumen ejecutivo",
    outlook: "Pr\xF3ximos pasos",
    incidents: "Incidencias",
    byChapter: "Incidencias por cap\xEDtulo",
    bySeverity: "Por gravedad",
    management: "Gesti\xF3n",
    extraCosts: "Contradictorios",
    sales: "Ventas",
    detail: "Detalle",
    photos: "Fotograf\xEDas",
    open: "Abiertas",
    opened: "Nuevas del mes",
    closed: "Cerradas del mes",
    openAtEnd: "Abiertas a final de mes",
    severity: { greu: "Grave", important: "Importante", lleu: "Leve" },
    severities: { greu: "Graves", important: "Importantes", lleu: "Leves" },
    ref: "N.\xBA referencia",
    chapter: "Cap\xEDtulo",
    subchapter: "Subcap\xEDtulo",
    location: "Ubicaci\xF3n",
    started: "Fecha inicio",
    agent: "Agente",
    responsible: "Responsable",
    forecast: "Previsi\xF3n",
    delay: "Retraso",
    closing: "Cierre",
    severityLabel: "Gravedad",
    days: "d\xEDas",
    description: "Descripci\xF3n",
    followUp: "Seguimiento",
    attached: "Documentaci\xF3n adjunta",
    state: "Estado",
    inProgress: "En curso",
    closedState: "Cerrada",
    costForecast: "Coste previsi\xF3n",
    costReal: "Coste real",
    approval: "Fecha aprobaci\xF3n",
    certified: "Certificado",
    invoiced: "Facturado",
    paid: "Pagado",
    yes: "S\xED",
    no: "No",
    estimated: "Estimado",
    real: "Real",
    approved: "Aprobados",
    pending: "Pendientes de aprobar",
    total: "Total",
    amount: "Importe",
    procedure: "Gesti\xF3n",
    next: "Siguiente paso",
    date: "Fecha",
    sold: "Vendidos",
    reserved: "Reservados",
    available: "Disponibles",
    kinds: { licence: "Permisos y licencias", connection: "Acometidas y suministros", insurance: "Seguros", deposit: "Dep\xF3sitos y garant\xEDas", contract: "Contrato", legal: "Jur\xEDdico y financiero", other: "Otras gestiones" },
    states: { pending: "Pendiente", in_progress: "En curso", blocked: "Bloqueado", done: "Hecho" },
    work: "Horas y trabajos del mes",
    hours: "Horas",
    worker: "Operario",
    ordinary: "Ordinarias",
    overtime: "Extras",
    travel: "Desplazamiento",
    billableJobs: "Trabajos facturables",
    concept: "Concepto",
    jobStates: { pendent: "Por facturar", facturat: "Facturado", cobrat: "Cobrado" },
    noHours: "Ninguna hora registrada este mes.",
    noJobs: "Ning\xFAn trabajo facturable este mes.",
    none: "Ninguna incidencia en este periodo.",
    noProcedures: "Ninguna gesti\xF3n registrada.",
    noSummary: "Resumen pendiente de redactar.",
    mainIncidents: "Incidencias graves e importantes",
    draft: "Borrador",
    page: "P\xE1g."
  }
};
var wordsOf = (language) => REPORT_WORDS[language] ?? REPORT_WORDS.ca;
function periodName(period, language = "ca") {
  const m = /^(\d{4})-(\d{2})$/.exec(String(period ?? ""));
  return m ? `${wordsOf(language).months[Number(m[2]) - 1]} ${m[1]}` : String(period ?? "");
}

// server/services/reports.mjs
var LANGS = { ca: ["catala", "catalan", "cat"], es: ["castellano", "espanol", "spanish", "castella"] };
var PERIOD = /^\d{4}-(0[1-9]|1[0-2])$/;
function previousPeriod(day) {
  const [y, m] = day.split("-").map(Number);
  return m === 1 ? `${y - 1}-12` : `${y}-${String(m - 1).padStart(2, "0")}`;
}
function rangeOf(period) {
  const [y, m] = period.split("-").map(Number);
  return { start: `${period}-01`, end: `${period}-${String(new Date(Date.UTC(y, m, 0)).getUTCDate()).padStart(2, "0")}` };
}
var DEFAULT_SETTINGS = { company_name: "", report_language: "ca", report_accent: "#78716C", report_footer: "", report_work: 0 };
async function settings(db) {
  const row2 = await db.one(`SELECT * FROM ${T.settings} WHERE _deleted = 0 ORDER BY _id LIMIT 1`);
  const s = { id: row2?._id ?? null, ...DEFAULT_SETTINGS, ...Object.fromEntries(Object.keys(DEFAULT_SETTINGS).filter((k) => row2 && row2[k] !== null && row2[k] !== void 0 && row2[k] !== "").map((k) => [k, row2[k]])) };
  return { ...s, report_work: !!s.report_work };
}
async function setSettings(db, i) {
  const d = sent({
    company_name: i.company_name === void 0 ? void 0 : text(i.company_name, 120),
    report_footer: i.report_footer === void 0 ? void 0 : text(i.report_footer, 200),
    report_language: i.report_language === void 0 ? void 0 : choiceOf(i.report_language, LANGS, "report_language") ?? "ca",
    report_accent: i.report_accent === void 0 ? void 0 : text(i.report_accent, 9),
    report_work: i.report_work === void 0 ? void 0 : yes(i.report_work)
  });
  if (d.report_accent && !/^#[0-9a-fA-F]{6}$/.test(d.report_accent)) throw new Refused("The colour is written like #78716C (a # and six letters or digits).", 400, { code: "BAD_COLOUR" });
  const row2 = await db.one(`SELECT _id FROM ${T.settings} WHERE _deleted = 0 ORDER BY _id LIMIT 1`);
  if (row2) {
    if (Object.keys(d).length) await db.update(T.settings, row2._id, d);
  } else await db.insert(T.settings, { ...DEFAULT_SETTINGS, ...d });
  return settings(db);
}
async function assemble(db, report) {
  const p = await db.one(`SELECT * FROM ${T.projects} WHERE _id = ?`, [report.project_id]);
  const { start: start2, end } = rangeOf(report.period);
  const chapters = await chaptersOf(db, p._id);
  const tops = chapters.filter((c) => !c.parent);
  const nameOf = (code, parent = "") => chapters.find((c) => c.code === code && c.parent === parent)?.name ?? "";
  const rows = await db.all(`SELECT * FROM ${T.incidents} WHERE project_id = ? AND ${LIVE} AND started_on <= ? AND (closed_on IS NULL OR closed_on >= ?) ORDER BY chapter, started_on, _id`, [p._id, end, start2]);
  const ids = rows.map((r) => r._id);
  const marks = ids.map(() => "?").join(",");
  const notes = ids.length ? await db.all(`SELECT incident_id, day, text FROM ${T.notes} WHERE ${LIVE} AND day <= ? AND incident_id IN (${marks}) ORDER BY day, _id`, [end, ...ids]) : [];
  const photos = ids.length ? await db.all(`SELECT _id AS id, incident_id, name FROM ${T.attachments} WHERE ${LIVE} AND kind = 'photo' AND data != '' AND incident_id IN (${marks}) ORDER BY _id`, ids) : [];
  const RANK3 = { greu: 0, important: 1, lleu: 2 };
  const incidents = rows.map((r) => {
    const open = !r.closed_on || r.closed_on > end;
    return {
      id: r._id,
      ref: r.ref,
      title: r.title,
      chapter: r.chapter || "",
      chapter_name: nameOf(r.chapter),
      subchapter: r.subchapter || "",
      subchapter_name: r.subchapter ? nameOf(r.subchapter, r.chapter) : "",
      location: r.location || "",
      started_on: r.started_on,
      reported_by: r.reported_by || "",
      responsible: r.responsible || "",
      due_on: r.due_on || null,
      expected_delay_days: r.expected_delay_days ?? null,
      delay: delayOf({ ...r, closed_on: open ? null : r.closed_on }, end),
      closed_on: open ? null : r.closed_on,
      open,
      new: r.started_on >= start2,
      severity: r.severity || "lleu",
      description: r.description || "",
      cost_estimated: euros(r.cost_estimated),
      cost_real: euros(r.cost_real),
      cost_approved_on: r.cost_approved_on || null,
      cost_certified: !!r.cost_certified,
      cost_invoiced: !!r.cost_invoiced,
      cost_paid: !!r.cost_paid,
      notes: notes.filter((n) => n.incident_id === r._id).map((n) => ({ day: n.day, text: n.text })),
      photos: photos.filter((f) => f.incident_id === r._id).slice(0, 4).map((f) => ({ id: f.id, name: f.name }))
    };
  }).sort((a, b) => a.chapter.localeCompare(b.chapter) || RANK3[a.severity] - RANK3[b.severity] || a.started_on.localeCompare(b.started_on));
  const stillOpen = incidents.filter((x) => x.open);
  const sev = (list6, s) => list6.filter((x) => x.severity === s).length;
  const withCost = incidents.filter((x) => x.cost_estimated !== null || x.cost_real !== null);
  const sum = (list6, k) => list6.reduce((a, x) => a + (x[k] ?? 0), 0);
  const units = {};
  for (const u of await db.all(`SELECT kind, state, COUNT(*) AS n FROM ${T.units} WHERE project_id = ? AND ${LIVE} GROUP BY kind, state`, [p._id])) {
    units[u.kind] ??= { total: 0, sold: 0, reserved: 0 };
    units[u.kind].total += Number(u.n);
    if (u.state === "sold") units[u.kind].sold += Number(u.n);
    if (u.state === "reserved") units[u.kind].reserved += Number(u.n);
  }
  const procedures2 = (await db.all(`SELECT _id AS id, title, kind, state, next_step, next_on, responsible, done_on FROM ${T.procedures} WHERE project_id = ? AND ${LIVE} ORDER BY kind, _id`, [p._id])).map((r) => ({ ...r, state: r.state || "pending" }));
  const work = (await settings(db)).report_work ? await workOf(db, p._id, start2, end) : null;
  const gallery = await db.all(`SELECT _id AS id, name FROM ${T.attachments} WHERE project_id = ? AND ${LIVE} AND kind = 'photo' AND data != '' ORDER BY _id DESC LIMIT 12`, [p._id]);
  return {
    project: { id: p._id, name: p.name, address: p.address || "", city: p.city || "", client: p.client || "", cover_id: p.cover_id || null },
    period: report.period,
    start: start2,
    end,
    units,
    totals: { in_play: incidents.length, open: stillOpen.length, opened: incidents.filter((x) => x.new).length, closed: incidents.length - stillOpen.length, greu: sev(stillOpen, "greu"), important: sev(stillOpen, "important"), lleu: sev(stillOpen, "lleu") },
    by_chapter: tops.map((c) => {
      const mine = stillOpen.filter((x) => x.chapter === c.code);
      return { code: c.code, name: c.name, greu: sev(mine, "greu"), important: sev(mine, "important"), lleu: sev(mine, "lleu"), open: mine.length, closed: incidents.filter((x) => x.chapter === c.code && !x.open).length };
    }),
    costs: {
      count: withCost.length,
      estimated: sum(withCost, "cost_estimated"),
      real: sum(withCost, "cost_real"),
      approved: withCost.filter((x) => x.cost_approved_on).length,
      pending: withCost.filter((x) => !x.cost_approved_on).length,
      certified: withCost.filter((x) => x.cost_certified).length,
      invoiced: withCost.filter((x) => x.cost_invoiced).length,
      paid: withCost.filter((x) => x.cost_paid).length,
      by_chapter: tops.map((c) => {
        const mine = withCost.filter((x) => x.chapter === c.code);
        return { code: c.code, name: c.name, count: mine.length, estimated: sum(mine, "cost_estimated"), real: sum(mine, "cost_real") };
      }).filter((c) => c.count)
    },
    procedures: { total: procedures2.length, done: procedures2.filter((x) => x.state === "done").length, rows: procedures2 },
    ...work ? { work } : {},
    incidents,
    gallery
  };
}
async function workOf(db, projectId, start2, end) {
  const lines = await db.all(`SELECT worker, hours, hours_overtime, hours_travel, km FROM ${T.hours} WHERE project_id = ? AND ${LIVE} AND day >= ? AND day <= ? AND COALESCE(state, 'pendent') != 'rebutjat'`, [projectId, start2, end]);
  const jobs2 = (await db.all(`SELECT day, worker, concept, hours, total, state FROM ${T.jobs} WHERE project_id = ? AND ${LIVE} AND day >= ? AND day <= ? AND COALESCE(billable, 1) = 1 ORDER BY day, _id`, [projectId, start2, end])).map((j) => ({ day: j.day, worker: j.worker || "", concept: j.concept, hours: Number(j.hours || 0), total: euros(j.total), state: j.state || "pendent" }));
  if (!lines.length && !jobs2.length) return null;
  const sum = (list6, k) => r2(list6.reduce((a, x) => a + Number(x[k] || 0), 0));
  return {
    hours: { lines: lines.length, total: sum(lines, "hours"), overtime: sum(lines, "hours_overtime"), travel: sum(lines, "hours_travel"), km: sum(lines, "km"), by_worker: sumBy(lines, (x) => x.worker, { hours: (x) => x.hours, overtime: (x) => x.hours_overtime, travel: (x) => x.hours_travel }).sort((a, b) => b.hours - a.hours).map(({ key, ...o }) => ({ worker: key, ...o })) },
    jobs: { lines: jobs2.length, hours: sum(jobs2, "hours"), total: sum(jobs2, "total"), rows: jobs2 }
  };
}
var reportOf = async (db, id) => {
  const r = await db.one(`SELECT * FROM ${T.reports} WHERE _id = ? AND ${LIVE}`, [Number(id) || 0]);
  if (!r) throw new Refused(`There is no report ${id ?? ""}: list them with reports, or make the month's with report_draft { project_id }.`, 404, { code: "NOT_FOUND", item: id ?? null });
  return r;
};
var head = (r) => ({ id: r._id, project_id: r.project_id, period: r.period, period_name: periodName(r.period, r.language || "ca"), language: r.language || "ca", state: r.state || "draft", has_summary: !!(r.summary && r.summary.trim()), reviewed_on: r.reviewed_on || null, sent_on: r.sent_on || null });
function figures(data) {
  return {
    incidents: data.totals,
    by_chapter: data.by_chapter.filter((c) => c.open || c.closed).map((c) => ({ chapter: `${c.code} ${c.name}`, open: c.open, greu: c.greu, important: c.important, closed: c.closed })),
    extra_costs: { count: data.costs.count, estimated: data.costs.estimated, real: data.costs.real, pending_approval: data.costs.pending },
    procedures: { total: data.procedures.total, done: data.procedures.done, under_way: data.procedures.rows.filter((x) => x.state !== "done").slice(0, 8).map((x) => ({ title: x.title, state: x.state, ...x.next_step ? { next_step: x.next_step } : {} })) },
    ...data.work ? { work: { hours: data.work.hours.total, overtime: data.work.hours.overtime, workers: data.work.hours.by_worker.length, jobs: data.work.jobs.lines, jobs_total: data.work.jobs.total } } : {},
    main: data.incidents.filter((x) => x.severity !== "lleu").slice(0, 10).map((x) => ({ ref: x.ref, title: x.title, severity: x.severity, open: x.open, ...x.delay ? { delay: x.delay } : {}, ...x.notes.length ? { last_note: x.notes[x.notes.length - 1].text.slice(0, 160) } : {} }))
  };
}
async function draft(db, i, now) {
  const p = await projectOf(db, i.project_id);
  const period = i.period ? String(i.period).trim() : previousPeriod(today(now));
  if (!PERIOD.test(period)) throw new Refused(`period is a month written YYYY-MM (got "${String(i.period).slice(0, 20)}").`, 400, { code: "BAD_PERIOD" });
  let r = await db.one(`SELECT * FROM ${T.reports} WHERE project_id = ? AND period = ? AND ${LIVE}`, [p._id, period]);
  const existed = !!r;
  if (!r) {
    const language = i.language ? choiceOf(i.language, LANGS, "language") : (await settings(db)).report_language;
    const id = await db.insert(T.reports, { project_id: p._id, period, language, state: "draft", summary: "", outlook: "", snapshot: "", removed: 0 });
    r = await db.one(`SELECT * FROM ${T.reports} WHERE _id = ?`, [id]);
  }
  const data = r.snapshot ? JSON.parse(r.snapshot) : await assemble(db, r);
  return {
    ...head(r),
    ...existed ? { existed: true } : {},
    project: p.name,
    figures: figures(data),
    write: r.state === "reviewed" ? "The person already reviewed this one: nothing to write." : `Write its two texts in ${REPORT_LANGUAGES[r.language || "ca"]} with report_write { id: ${r._id}, summary, outlook }: summary = the month in 5 to 8 lines for the client (what happened, what is serious, what it costs, what was solved); outlook = what comes next month. Only what these figures and the incidents say. Then tell the person it is ready to review: page informe/${r._id}.`
  };
}
async function write(db, i) {
  const r = await reportOf(db, i.id);
  if (r.state === "reviewed") throw new Refused("The person already reviewed this report, so it is kept as it was. To change it they press \xABVolver a borrador\xBB on its page.", 409, { code: "ALREADY_REVIEWED", item: r._id });
  const d = sent({ summary: i.summary === void 0 ? void 0 : text(i.summary, 6e3), outlook: i.outlook === void 0 ? void 0 : text(i.outlook, 4e3), language: i.language === void 0 ? void 0 : choiceOf(i.language, LANGS, "language") ?? "ca" });
  if (!Object.keys(d).length) throw new Refused("Say what to write: summary, outlook (or language).", 400, { code: "BAD_INPUT" });
  await db.update(T.reports, r._id, d);
  return { id: r._id, written: Object.keys(d) };
}
async function review(db, { id }, actor, now) {
  const r = await reportOf(db, id);
  if (r.state === "reviewed") return head(r);
  if (!r.summary || !r.summary.trim()) throw new Refused("The report has no summary yet: write it (or ask your agent to) before marking it as reviewed.", 409, { code: "NO_SUMMARY", item: r._id });
  await db.update(T.reports, r._id, { state: "reviewed", reviewed_on: today(now), reviewed_by: who(actor), snapshot: JSON.stringify(await assemble(db, r)) });
  return head(await reportOf(db, id));
}
async function markSent(db, { id, sent: flag, sent_on }, now) {
  const r = await reportOf(db, id);
  const off = flag === false || flag === "false";
  if (!off && r.state !== "reviewed") throw new Refused("Only a reviewed report is sent: the person reviews it first (\xABDar por revisado\xBB on its page).", 409, { code: "NOT_REVIEWED", item: r._id });
  await db.update(T.reports, r._id, { sent_on: off ? null : dateOf(sent_on, "sent_on") ?? today(now) });
  return head(await reportOf(db, id));
}
async function reopen(db, { id }) {
  const r = await reportOf(db, id);
  await db.update(T.reports, r._id, { state: "draft", reviewed_on: null, reviewed_by: null, sent_on: null, snapshot: "" });
  return head(await reportOf(db, id));
}
async function list4(db, i) {
  const conds = [LIVE];
  const params = [];
  if (i.project_id) {
    conds.push("project_id = ?");
    params.push((await projectOf(db, i.project_id))._id);
  }
  const names2 = Object.fromEntries((await db.all(`SELECT _id, name FROM ${T.projects} WHERE ${LIVE}`)).map((p) => [p._id, p.name]));
  return { rows: (await db.all(`SELECT * FROM ${T.reports} WHERE ${conds.join(" AND ")} ORDER BY period DESC, _id DESC LIMIT 100`, params)).filter((r) => names2[r.project_id]).map((r) => ({ ...head(r), project: names2[r.project_id] })) };
}
async function one3(db, { id }, full) {
  const r = await reportOf(db, id);
  const data = r.snapshot ? JSON.parse(r.snapshot) : await assemble(db, r);
  if (!full) return { ...head(r), project: data.project.name, summary: r.summary || "", outlook: r.outlook || "", figures: figures(data) };
  const s = await settings(db);
  return { ...head(r), summary: r.summary || "", outlook: r.outlook || "", reviewed_by: r.reviewed_by || null, frozen: !!r.snapshot, data, settings: { company_name: s.company_name, report_accent: s.report_accent, report_footer: s.report_footer } };
}
async function toPrepare(db, now) {
  const period = previousPeriod(today(now));
  const { end } = rangeOf(period);
  const have = new Set((await db.all(`SELECT project_id FROM ${T.reports} WHERE period = ? AND ${LIVE}`, [period])).map((r) => r.project_id));
  const projects = await db.all(`SELECT _id, name, started_on FROM ${T.projects} WHERE ${LIVE} AND COALESCE(state, 'active') = 'active' AND COALESCE(demo, 0) = 0`);
  return { items: projects.filter((p) => !have.has(p._id) && (!p.started_on || p.started_on <= end)).map((p) => ({ key: `report:${p._id}:${period}`, text: `The monthly report of ${p.name} for ${period} is not prepared yet.`, project_id: p._id, project: p.name, period })) };
}
async function pageNeeds(db) {
  const s = await settings(db);
  return { needs: s.company_name ? [] : [{ id: "company_name", kind: "setting", door: "settings", section: "general", place: "informes", title: "Di con qu\xE9 nombre se firman los informes", unlocks: "El nombre de tu empresa sale en la portada y en el pie de cada informe mensual." }] };
}

// server/services/hours.mjs
var HOUR_STATES = {
  pendent: ["pendiente", "pending", "per validar", "por validar", "nou", "nuevo", "registrat", "registrado", "enviat", "enviado", "esborrany", "borrador"],
  validat: ["validada", "validado", "validated", "aprovat", "aprovada", "aprobado", "aprobada", "approved", "ok", "correcte", "correcto", "conforme"],
  rebutjat: ["rebutjada", "rechazado", "rechazada", "rejected", "denegat", "denegada", "denegado", "no conforme"]
};
var minutes = (t) => {
  const [h, m] = t.split(":").map(Number);
  return h * 60 + m;
};
function settle(d, before = {}) {
  const v = (k) => d[k] !== void 0 ? d[k] : before[k] ?? null;
  const over = v("hours_overtime") ?? 0;
  const travel = v("hours_travel") ?? 0;
  let ordinary = d.hours_ordinary !== void 0 ? d.hours_ordinary : d.hours !== void 0 ? d.hours : before.hours_ordinary ?? (before.hours != null ? r2(before.hours - (before.hours_overtime ?? 0)) : null);
  if ((ordinary === null || ordinary === void 0) && v("time_in") && v("time_out")) {
    const span = minutes(v("time_out")) - minutes(v("time_in")) - (v("break_min") ?? 0);
    if (span <= 0) return "time_out is after time_in, and the break is shorter than the time between them.";
    ordinary = Math.max(0, r2(span / 60 - over));
  }
  ordinary ??= 0;
  if (ordinary < 0 || over < 0 || travel < 0) return "Hours are not negative.";
  if (ordinary + over > 24 || travel > 24) return "A line is one day of one worker: at most 24 hours.";
  if (!(ordinary + over + travel > 0)) return "A line of hours needs its hours: hours (ordinary), hours_overtime, hours_travel, or time_in and time_out.";
  return { hours_ordinary: ordinary, hours_overtime: over, hours_travel: travel, hours: r2(ordinary + over) };
}
function lineFields(i) {
  const t = (k, max) => i[k] === void 0 ? void 0 : text(i[k], max) ?? "";
  const n = (k) => i[k] === void 0 ? void 0 : num(i[k], k);
  return sent({
    worker: t("worker", 120),
    day: i.day === void 0 ? void 0 : dateOf(i.day, "day"),
    site: t("site", 200),
    company: t("company", 200),
    time_in: i.time_in === void 0 ? void 0 : timeOf(i.time_in, "time_in"),
    time_out: i.time_out === void 0 ? void 0 : timeOf(i.time_out, "time_out"),
    break_min: i.break_min === void 0 ? void 0 : int(i.break_min, "break_min"),
    hours: n("hours"),
    hours_ordinary: n("hours_ordinary"),
    hours_overtime: n("hours_overtime"),
    hours_travel: n("hours_travel"),
    km: n("km"),
    task: t("task", 400),
    validated_by: t("validated_by", 120),
    state: i.state === void 0 ? void 0 : choiceOf(i.state, HOUR_STATES, "state") ?? "pendent",
    paid: i.paid === void 0 ? void 0 : yes(i.paid),
    notes: t("notes", 2e3),
    origin: t("origin", 60)
  });
}
function newLine(i) {
  const d = lineFields(i);
  if (!d.worker || !d.day) throw new Refused("A line of hours is { worker, day (YYYY-MM-DD), hours, \u2026 }: this one lacks who or which day.", 400, { code: "BAD_INPUT" });
  const h = settle(d);
  if (typeof h === "string") throw new Refused(h, 400, { code: "BAD_HOURS" });
  return { site: "", company: "", task: "", validated_by: "", notes: "", origin: "", state: "pendent", paid: 0, ...d, ...h };
}
var skip = (list6, index, e) => {
  if (!(e instanceof Refused)) throw e;
  list6.push({ index, code: e.code, why: e.message, ...e.item !== void 0 ? { item: e.item } : {} });
};
async function hoursAdd(db, i) {
  const fixed = i.project_id ? (await projectOf(db, i.project_id))._id : null;
  const added = [];
  const skipped = [];
  const items = listOf(i.items, "items");
  if (items.length > 200) throw new Refused("At most 200 lines in one call: send the rest in another.", 400, { code: "TOO_MANY" });
  for (const [index, it] of items.entries()) {
    try {
      const pid = it?.project_id ? (await projectOf(db, it.project_id))._id : fixed ?? (await projectOf(db, void 0))._id;
      const d = newLine(it ?? {});
      const dup = await db.one(`SELECT _id FROM ${T.hours} WHERE project_id = ? AND lower(worker) = lower(?) AND day = ? AND COALESCE(task, '') = ? AND COALESCE(time_in, '') = ? AND ${LIVE}`, [pid, d.worker, d.day, d.task, d.time_in ?? ""]);
      if (dup) throw new Refused("That line is already there (same worker, project, day, task and entry time): change it with hours_update.", 409, { code: "DUPLICATE", item: dup._id });
      added.push(await db.insert(T.hours, { ...d, project_id: pid, source: "", removed: 0 }));
    } catch (e) {
      skip(skipped, index, e);
    }
  }
  return { added, skipped };
}
async function hoursUpdate(db, i) {
  const changed = [];
  const skipped = [];
  for (const [index, it] of listOf(i.items, "items").entries()) {
    try {
      const r = await db.one(`SELECT * FROM ${T.hours} WHERE _id = ? AND ${LIVE}`, [Number(it?.id) || 0]);
      if (!r) throw new Refused(`There is no line of hours ${it?.id ?? ""}: hours { full: true } lists them with their ids.`, 404, { code: "NOT_FOUND", item: it?.id ?? null });
      const d = lineFields(it);
      if (d.worker === "") throw new Refused("A line keeps its worker.", 400, { code: "BAD_INPUT" });
      if (it.project_id !== void 0) d.project_id = (await projectOf(db, it.project_id))._id;
      for (const k of ["time_in", "time_out", "break_min", "km"]) if (it[k] === null || it[k] === "") d[k] = null;
      if (["hours", "hours_ordinary", "hours_overtime", "hours_travel", "time_in", "time_out", "break_min"].some((k) => d[k] !== void 0)) {
        const h = settle(d, r);
        if (typeof h === "string") throw new Refused(h, 400, { code: "BAD_HOURS" });
        Object.assign(d, h);
      }
      if (Object.keys(d).length) await db.update(T.hours, r._id, d);
      changed.push(r._id);
    } catch (e) {
      skip(skipped, index, e);
    }
  }
  return { changed, skipped };
}
async function filter(db, i, now, { range = true } = {}) {
  const conds = [LIVE];
  const params = [];
  const day = today(now);
  const from = dateOf(i.from, "from") ?? (range ? `${day.slice(0, 7)}-01` : null);
  const to = dateOf(i.to, "to") ?? (range ? day : null);
  if (from) {
    conds.push("day >= ?");
    params.push(from);
  }
  if (to) {
    conds.push("day <= ?");
    params.push(to);
  }
  if (i.project_id) {
    conds.push("project_id = ?");
    params.push((await projectOf(db, i.project_id))._id);
  }
  if (i.worker) {
    conds.push("lower(worker) = lower(?)");
    params.push(String(i.worker).trim());
  }
  if (i.company) {
    conds.push("lower(COALESCE(company, '')) = lower(?)");
    params.push(String(i.company).trim());
  }
  if (i.state) {
    conds.push("COALESCE(state, 'pendent') = ?");
    params.push(choiceOf(i.state, HOUR_STATES, "state"));
  }
  if (i.paid !== void 0 && i.paid !== null && i.paid !== "") {
    conds.push("COALESCE(paid, 0) = ?");
    params.push(yes(i.paid));
  }
  return { conds, params, from, to };
}
async function hoursMark(db, i, actor, now) {
  const set = sent({ state: i.state === void 0 ? void 0 : choiceOf(i.state, HOUR_STATES, "state"), paid: i.paid === void 0 ? void 0 : yes(i.paid), validated_by: i.validated_by === void 0 ? void 0 : text(i.validated_by, 120) });
  if (set.state === void 0 && set.paid === void 0) throw new Refused("Say what to mark: state (validat | rebutjat | pendent) or paid (true | false).", 400, { code: "BAD_INPUT" });
  if (set.state === "validat" && !set.validated_by && isPerson(actor)) set.validated_by = who(actor);
  let rows;
  if (i.ids !== void 0) {
    const ids = listOf(i.ids, "ids").map(Number).filter((n) => Number.isInteger(n) && n > 0);
    rows = ids.length ? await db.all(`SELECT _id, hours, hours_travel FROM ${T.hours} WHERE ${LIVE} AND _id IN (${ids.map(() => "?").join(",")})`, ids) : [];
  } else {
    if (![i.worker, i.project_id, i.company, i.from, i.to].some((x) => x !== void 0 && x !== null && x !== "")) throw new Refused("Say which lines: ids, or a filter (worker, project_id, company, from, to). Nothing was changed.", 400, { code: "WHICH_LINES" });
    const f = await filter(db, { ...i, state: void 0, paid: void 0 }, now, { range: false });
    if (set.state && set.state !== "pendent") f.conds.push("COALESCE(state, 'pendent') = 'pendent'");
    else if (set.paid !== void 0 && set.state === void 0) {
      f.conds.push("COALESCE(paid, 0) = ?");
      f.params.push(set.paid ? 0 : 1);
      f.conds.push("COALESCE(state, 'pendent') != 'rebutjat'");
    }
    rows = await db.all(`SELECT _id, hours, hours_travel FROM ${T.hours} WHERE ${f.conds.join(" AND ")}`, f.params);
  }
  for (const r of rows) await db.update(T.hours, r._id, set);
  return { changed: rows.length, hours: r2(rows.reduce((a, r) => a + Number(r.hours || 0), 0)), set };
}
async function hoursRemove(db, { id }) {
  const changed = await db.update(T.hours, Number(id) || 0, { removed: 1 });
  if (!changed) throw new Refused("That line is no longer there.", 404, { code: "NOT_FOUND", item: id });
  return { id: Number(id), removed: true };
}
var shape2 = (r) => ({
  id: r._id,
  project_id: r.project_id,
  worker: r.worker,
  day: r.day,
  site: r.site || "",
  company: r.company || "",
  time_in: r.time_in || null,
  time_out: r.time_out || null,
  break_min: r.break_min ?? null,
  hours: Number(r.hours || 0),
  hours_ordinary: r.hours_ordinary ?? r2(Number(r.hours || 0) - Number(r.hours_overtime || 0)),
  hours_overtime: Number(r.hours_overtime || 0),
  hours_travel: Number(r.hours_travel || 0),
  km: Number(r.km || 0),
  task: r.task || "",
  validated_by: r.validated_by || "",
  state: r.state || "pendent",
  paid: !!r.paid,
  notes: r.notes || "",
  origin: r.origin || ""
});
var COLS = { hours: (r) => r.hours, overtime: (r) => r.hours_overtime, travel: (r) => r.hours_travel, km: (r) => r.km, pending: (r) => r.state === "pendent" ? r.hours : 0, unpaid: (r) => !r.paid && r.state !== "rebutjat" ? r.hours : 0 };
var lean = (o) => Object.fromEntries(Object.entries(o).filter(([k, v]) => k === "hours" || v !== 0));
function summary(rows, { by, names: names2 = {} } = {}) {
  const good = rows.filter((r) => r.state !== "rebutjat");
  const sum = (list7, k) => r2(list7.reduce((a, r) => a + Number(r[k] || 0), 0));
  const pending2 = good.filter((r) => r.state === "pendent");
  const unpaid = good.filter((r) => !r.paid);
  const list6 = (keyOf, name) => sumBy(good, keyOf, COLS).sort((a, b) => b.hours - a.hours).map(({ key, ...o }) => ({ [name]: key, ...lean(o) }));
  return {
    lines: rows.length,
    total: sum(good, "hours"),
    ordinary: sum(good, "hours_ordinary"),
    overtime: sum(good, "hours_overtime"),
    travel: sum(good, "hours_travel"),
    km: sum(good, "km"),
    pending: { lines: pending2.length, hours: sum(pending2, "hours") },
    unpaid: { lines: unpaid.length, hours: sum(unpaid, "hours") },
    ...rows.length - good.length ? { rejected: rows.length - good.length } : {},
    by_worker: list6((r) => r.worker, "worker"),
    by_project: list6((r) => r.project_id, "project_id").map((p) => ({ ...p, project: names2[p.project_id] ?? "" })),
    ...by ? { by_period: sumBy(good, (r) => by === "week" ? weekOf(r.day) : r.day.slice(0, 7), COLS).sort((a, b) => a.key.localeCompare(b.key)).map(({ key, ...o }) => ({ period: key, ...lean(o) })) } : {}
  };
}
async function hours(db, i, full, now) {
  const f = await filter(db, i, now);
  const by = i.by === "week" || i.by === "month" ? i.by : i.by ? choiceOf(i.by, { week: ["setmana", "semana"], month: ["mes"] }, "by") : null;
  const rows = (await db.all(`SELECT * FROM ${T.hours} WHERE ${f.conds.join(" AND ")} ORDER BY day DESC, _id DESC LIMIT 2000`, f.params)).map(shape2);
  const names2 = Object.fromEntries((await db.all(`SELECT _id, name FROM ${T.projects} WHERE ${LIVE}`)).map((p) => [p._id, p.name]));
  const s = summary(rows, { by, names: names2 });
  const base = { from: f.from, to: f.to, ...s, by_worker: s.by_worker.slice(0, 25), by_project: s.by_project.slice(0, 25), ...s.by_period ? { by_period: s.by_period.slice(-26) } : {} };
  return full ? { ...base, by_worker: s.by_worker, by_project: s.by_project, rows } : base;
}

// server/services/jobs.mjs
var JOB_STATES = {
  pendent: ["pendiente", "pending", "per facturar", "por facturar", "obert", "abierto", "nou", "nuevo", "fet", "hecho", "realitzat", "realizado", "en curs", "en curso"],
  facturat: ["facturada", "facturado", "invoiced", "enviat", "enviada", "enviado"],
  cobrat: ["cobrada", "cobrado", "pagat", "pagada", "pagado", "paid", "liquidat", "liquidado"]
};
var totalOf = (hours2, rate) => rate === null || rate === void 0 ? null : Math.round(Number(hours2 || 0) * rate);
function jobFields(i) {
  const t = (k, max) => i[k] === void 0 ? void 0 : text(i[k], max) ?? "";
  const n = (k) => i[k] === void 0 ? void 0 : num(i[k], k);
  return sent({
    day: i.day === void 0 ? void 0 : dateOf(i.day, "day"),
    worker: t("worker", 120),
    client: t("client", 200),
    property: t("property", 200),
    town: t("town", 120),
    concept: t("concept", 200),
    description: t("description", 4e3),
    hours: n("hours"),
    hours_travel: n("hours_travel"),
    km: n("km"),
    rate: i.rate === void 0 ? void 0 : cents(i.rate, "rate"),
    billable: i.billable === void 0 ? void 0 : yes(i.billable),
    state: i.state === void 0 ? void 0 : choiceOf(i.state, JOB_STATES, "state") ?? "pendent",
    registered: i.registered === void 0 ? void 0 : yes(i.registered),
    total: i.total === void 0 ? void 0 : cents(i.total, "total"),
    notes: t("notes", 2e3)
  });
}
function newJob(i) {
  const d = jobFields(i);
  d.concept = d.concept || (d.description ? d.description.split(/[.\n]/)[0].slice(0, 90) : "");
  if (!d.day || !d.concept) throw new Refused("A job is { day (YYYY-MM-DD), concept, client, hours, rate, \u2026 }: this one lacks its day or its concept.", 400, { code: "BAD_INPUT" });
  if ((d.hours ?? 0) < 0 || (d.hours_travel ?? 0) < 0) throw new Refused("Hours are not negative.", 400, { code: "BAD_HOURS" });
  const row2 = { worker: "", client: "", property: "", town: "", description: "", hours: 0, hours_travel: 0, km: 0, rate: null, billable: 1, state: "pendent", registered: 0, notes: "", ...d };
  row2.total = d.total ?? totalOf(row2.hours, row2.rate);
  return row2;
}
var skip2 = (list6, index, e) => {
  if (!(e instanceof Refused)) throw e;
  list6.push({ index, code: e.code, why: e.message, ...e.item !== void 0 ? { item: e.item } : {} });
};
async function jobsAdd(db, i) {
  const fixed = i.project_id ? await projectOf(db, i.project_id) : null;
  const added = [];
  const skipped = [];
  const items = listOf(i.items, "items");
  if (items.length > 200) throw new Refused("At most 200 jobs in one call: send the rest in another.", 400, { code: "TOO_MANY" });
  for (const [index, it] of items.entries()) {
    try {
      const p = it?.project_id ? await projectOf(db, it.project_id) : fixed;
      const d = newJob(it ?? {});
      if (!d.client && p?.client) d.client = p.client;
      const dup = await db.one(`SELECT _id FROM ${T.jobs} WHERE day = ? AND lower(COALESCE(worker, '')) = lower(?) AND lower(COALESCE(client, '')) = lower(?) AND lower(concept) = lower(?) AND ${LIVE}`, [d.day, d.worker, d.client, d.concept]);
      if (dup) throw new Refused("That job is already there (same day, worker, client and concept): change it with jobs_update.", 409, { code: "DUPLICATE", item: dup._id });
      added.push(await db.insert(T.jobs, { ...d, project_id: p?._id ?? null, source: "", removed: 0 }));
    } catch (e) {
      skip2(skipped, index, e);
    }
  }
  return { added, skipped };
}
async function jobsUpdate(db, i) {
  const changed = [];
  const skipped = [];
  for (const [index, it] of listOf(i.items, "items").entries()) {
    try {
      const r = await db.one(`SELECT * FROM ${T.jobs} WHERE _id = ? AND ${LIVE}`, [Number(it?.id) || 0]);
      if (!r) throw new Refused(`There is no job ${it?.id ?? ""}: list them with jobs.`, 404, { code: "NOT_FOUND", item: it?.id ?? null });
      const d = jobFields(it);
      if (d.concept === "") throw new Refused("A job keeps its concept.", 400, { code: "BAD_INPUT" });
      if (it.project_id !== void 0) d.project_id = it.project_id === null || it.project_id === "" ? null : (await projectOf(db, it.project_id))._id;
      if (it.rate === null || it.rate === "") d.rate = null;
      if (it.total === null || it.total === "") d.total = null;
      const computed = r.total === null || r.total === void 0 || r.total === totalOf(r.hours, r.rate);
      const fresh = () => totalOf(d.hours ?? r.hours, d.rate !== void 0 ? d.rate : r.rate);
      if (d.total === null) d.total = fresh();
      else if (d.total === void 0 && computed && (d.hours !== void 0 || d.rate !== void 0)) d.total = fresh();
      if (Object.keys(d).length) await db.update(T.jobs, r._id, d);
      changed.push(r._id);
    } catch (e) {
      skip2(skipped, index, e);
    }
  }
  return { changed, skipped };
}
async function jobsMark(db, i) {
  const set = sent({ state: i.state === void 0 ? void 0 : choiceOf(i.state, JOB_STATES, "state"), registered: i.registered === void 0 ? void 0 : yes(i.registered) });
  if (set.state === void 0 && set.registered === void 0) throw new Refused("Say what to mark: state (facturat | cobrat | pendent) or registered (true | false).", 400, { code: "BAD_INPUT" });
  let rows;
  if (i.ids !== void 0) {
    const ids = listOf(i.ids, "ids").map(Number).filter((n) => Number.isInteger(n) && n > 0);
    rows = ids.length ? await db.all(`SELECT _id, total FROM ${T.jobs} WHERE ${LIVE} AND _id IN (${ids.map(() => "?").join(",")})`, ids) : [];
  } else {
    if (![i.client, i.worker, i.project_id, i.from, i.to].some((x) => x !== void 0 && x !== null && x !== "")) throw new Refused("Say which jobs: ids, or a filter (client, worker, project_id, from, to). Nothing was changed.", 400, { code: "WHICH_JOBS" });
    const conds = [LIVE];
    const params = [];
    const from = dateOf(i.from, "from");
    const to = dateOf(i.to, "to");
    if (from) {
      conds.push("day >= ?");
      params.push(from);
    }
    if (to) {
      conds.push("day <= ?");
      params.push(to);
    }
    if (i.project_id) {
      conds.push("project_id = ?");
      params.push((await projectOf(db, i.project_id))._id);
    }
    for (const k of ["client", "worker"]) if (i[k]) {
      conds.push(`lower(COALESCE(${k}, '')) = lower(?)`);
      params.push(String(i[k]).trim());
    }
    if (set.state) {
      conds.push("COALESCE(billable, 1) = 1");
      conds.push("COALESCE(state, 'pendent') = ?");
      params.push(set.state === "facturat" ? "pendent" : set.state === "cobrat" ? "facturat" : "facturat");
    } else {
      conds.push("COALESCE(registered, 0) = ?");
      params.push(set.registered ? 0 : 1);
    }
    rows = await db.all(`SELECT _id, total FROM ${T.jobs} WHERE ${conds.join(" AND ")}`, params);
  }
  for (const r of rows) await db.update(T.jobs, r._id, set);
  return { changed: rows.length, total: r2(rows.reduce((a, r) => a + Number(r.total || 0), 0) / 100), set: { ...set, ...set.registered !== void 0 ? { registered: !!set.registered } : {} } };
}
async function jobRemove(db, { id }) {
  const changed = await db.update(T.jobs, Number(id) || 0, { removed: 1 });
  if (!changed) throw new Refused("That job is no longer there.", 404, { code: "NOT_FOUND", item: id });
  return { id: Number(id), removed: true };
}
var shape3 = (r) => ({
  id: r._id,
  project_id: r.project_id ?? null,
  day: r.day,
  worker: r.worker || "",
  client: r.client || "",
  property: r.property || "",
  town: r.town || "",
  concept: r.concept,
  description: r.description || "",
  hours: Number(r.hours || 0),
  hours_travel: Number(r.hours_travel || 0),
  km: Number(r.km || 0),
  rate: euros(r.rate),
  billable: r.billable === null || r.billable === void 0 ? true : !!r.billable,
  state: r.state || "pendent",
  registered: !!r.registered,
  total: euros(r.total),
  notes: r.notes || ""
});
function summary2(rows) {
  const sum = (list6, k) => r2(list6.reduce((a, r) => a + Number(r[k] || 0), 0));
  const part = (list6) => ({ lines: list6.length, total: sum(list6, "total") });
  const billable = rows.filter((r) => r.billable);
  const toInvoice = billable.filter((r) => r.state === "pendent");
  return {
    lines: rows.length,
    hours: sum(rows, "hours"),
    travel: sum(rows, "hours_travel"),
    km: sum(rows, "km"),
    total: sum(billable, "total"),
    to_invoice: part(toInvoice),
    invoiced: part(billable.filter((r) => r.state === "facturat")),
    paid: part(billable.filter((r) => r.state === "cobrat")),
    not_registered: rows.filter((r) => !r.registered).length,
    by_client: sumBy(billable, (r) => r.client || "\u2014", { lines: () => 1, hours: (r) => r.hours, total: (r) => r.total, to_invoice: (r) => r.state === "pendent" ? r.total : 0 }).sort((a, b) => b.total - a.total).map(({ key, ...o }) => ({ client: key, ...o }))
  };
}
async function jobs(db, i, full) {
  const conds = [LIVE];
  const params = [];
  const from = dateOf(i.from, "from");
  const to = dateOf(i.to, "to");
  if (from) {
    conds.push("day >= ?");
    params.push(from);
  }
  if (to) {
    conds.push("day <= ?");
    params.push(to);
  }
  if (i.project_id) {
    conds.push("project_id = ?");
    params.push((await projectOf(db, i.project_id))._id);
  }
  for (const k of ["client", "worker"]) if (i[k]) {
    conds.push(`lower(COALESCE(${k}, '')) = lower(?)`);
    params.push(String(i[k]).trim());
  }
  if (i.state) {
    conds.push("COALESCE(state, 'pendent') = ?");
    params.push(choiceOf(i.state, JOB_STATES, "state"));
  }
  for (const [k, none] of [["billable", 1], ["registered", 0]]) if (i[k] !== void 0 && i[k] !== null && i[k] !== "") {
    conds.push(`COALESCE(${k}, ${none}) = ?`);
    params.push(yes(i[k]));
  }
  const rows = (await db.all(`SELECT * FROM ${T.jobs} WHERE ${conds.join(" AND ")} ORDER BY day DESC, _id DESC LIMIT 2000`, params)).map(shape3);
  const s = summary2(rows);
  if (full) return { ...s, rows };
  const limit = 8;
  return {
    ...s,
    by_client: s.by_client.slice(0, 8),
    rows: rows.slice(0, limit).map((r) => ({ id: r.id, day: r.day, ...r.client ? { client: r.client } : {}, concept: r.concept.slice(0, 60), ...r.worker ? { worker: r.worker } : {}, hours: r.hours, ...r.total !== null ? { total: r.total } : {}, state: r.state, ...r.billable ? {} : { billable: false } })),
    ...rows.length > limit ? { more: `Only the newest ${limit}: narrow with client, state, from, to.` } : {}
  };
}

// server/services/directory.mjs
var KINDS = {
  company: { table: T.companies, fields: { name: 200, kind: 80, contact: 200, email: 200, phone: 60, notes: 2e3 }, read: "companies" },
  person: { table: T.people, fields: { name: 200, role: 120, area: 120, company: 200, kind: 80, email: 200, phone: 60, notes: 2e3 }, read: "people" }
};
var same = (s) => String(s ?? "").trim().toLowerCase();
function entryFields(kind, i) {
  const d = {};
  for (const [k, max] of Object.entries(KINDS[kind].fields)) if (i[k] !== void 0) d[k] = text(i[k], max) ?? "";
  if (i.active !== void 0) d.active = yes(i.active);
  return sent(d);
}
async function save(db, kind, i) {
  const K = KINDS[kind];
  const added = [];
  const changed = [];
  const skipped = [];
  const items = listOf(i.items, "items");
  if (items.length > 200) throw new Refused("At most 200 in one call: send the rest in another.", 400, { code: "TOO_MANY" });
  for (const [index, it] of items.entries()) {
    try {
      if (it?.id) {
        const r = await db.one(`SELECT _id FROM ${K.table} WHERE _id = ? AND ${LIVE}`, [Number(it.id) || 0]);
        if (!r) throw new Refused(`There is no ${kind} ${it.id}: list them with ${K.read}.`, 404, { code: "NOT_FOUND", item: it.id });
        const d2 = it.remove ? { removed: 1 } : entryFields(kind, it);
        if (d2.name === "") throw new Refused("It keeps a name.", 400, { code: "NAME_REQUIRED" });
        if (Object.keys(d2).length) await db.update(K.table, r._id, d2);
        changed.push(r._id);
        continue;
      }
      const d = entryFields(kind, it ?? {});
      if (!d.name) throw new Refused(`A ${kind} needs a name.`, 400, { code: "NAME_REQUIRED" });
      const dup = await db.one(`SELECT _id FROM ${K.table} WHERE lower(name) = lower(?) AND ${LIVE}`, [d.name]);
      if (dup) throw new Refused(`"${d.name}" is already there: change it by its id.`, 409, { code: "DUPLICATE", item: dup._id });
      added.push(await db.insert(K.table, { ...Object.fromEntries(Object.keys(K.fields).map((k) => [k, ""])), active: 1, ...d, source: "", removed: 0 }));
    } catch (e) {
      if (!(e instanceof Refused)) throw e;
      skipped.push({ index, code: e.code, why: e.message, ...e.item !== void 0 ? { item: e.item } : {} });
    }
  }
  return { added, changed, skipped };
}
var lean2 = (o) => Object.fromEntries(Object.entries(o).filter(([k, v]) => k === "id" || k === "name" || v !== "" && v !== 0 && v !== null && v !== void 0));
var wanted = (rows, i) => rows.filter((r) => (!i.kind || same(r.kind) === same(i.kind)) && (!i.q || [r.name, r.kind, r.role, r.company, r.contact, r.area].some((x) => same(x).includes(same(i.q)))) && (i.active === void 0 || i.active === "" || !!yes(i.active) === (r.active === null || r.active === void 0 ? true : !!r.active)));
async function openBy(db) {
  const rows = await db.all(`SELECT lower(responsible) AS who, COUNT(*) AS n FROM ${T.incidents} WHERE ${LIVE} AND closed_on IS NULL AND COALESCE(responsible, '') != '' GROUP BY lower(responsible)`);
  return Object.fromEntries(rows.map((r) => [r.who, Number(r.n)]));
}
async function companies(db, i, full) {
  const all = await db.all(`SELECT * FROM ${T.companies} WHERE ${LIVE} ORDER BY lower(name)`);
  const open = await openBy(db);
  const people2 = await db.all(`SELECT lower(company) AS c, COUNT(*) AS n FROM ${T.people} WHERE ${LIVE} AND COALESCE(company, '') != '' GROUP BY lower(company)`);
  const rows = wanted(all, i).map((r) => ({ id: r._id, name: r.name, kind: r.kind || "", contact: r.contact || "", email: r.email || "", phone: r.phone || "", notes: r.notes || "", active: r.active === null || r.active === void 0 ? true : !!r.active, people: Number(people2.find((p) => p.c === same(r.name))?.n ?? 0), incidents_open: open[same(r.name)] ?? 0 }));
  if (full) return { total: rows.length, rows };
  return { total: rows.length, rows: rows.slice(0, 40).map(({ notes, active, ...r }) => lean2({ ...r, ...active ? {} : { inactive: true } })), ...rows.length > 40 ? { more: "Only the first 40: narrow with kind or q." } : {} };
}
async function people(db, i, full, now) {
  const all = await db.all(`SELECT * FROM ${T.people} WHERE ${LIVE} ORDER BY lower(name)`);
  const open = await openBy(db);
  const day = today(now);
  const hours2 = await db.all(`SELECT lower(worker) AS w, SUM(hours) AS h FROM ${T.hours} WHERE ${LIVE} AND day >= ? AND day <= ? AND COALESCE(state, 'pendent') != 'rebutjat' GROUP BY lower(worker)`, [`${day.slice(0, 7)}-01`, day]);
  const rows = wanted(all, { ...i, ...i.company ? { q: void 0 } : {} }).filter((r) => !i.company || same(r.company) === same(i.company)).map((r) => ({ id: r._id, name: r.name, role: r.role || "", area: r.area || "", company: r.company || "", kind: r.kind || "", email: r.email || "", phone: r.phone || "", notes: r.notes || "", active: r.active === null || r.active === void 0 ? true : !!r.active, incidents_open: open[same(r.name)] ?? 0, hours_month: Math.round(Number(hours2.find((h) => h.w === same(r.name))?.h ?? 0) * 100) / 100 }));
  if (full) return { total: rows.length, rows };
  return { total: rows.length, rows: rows.slice(0, 40).map(({ notes, active, ...r }) => lean2({ ...r, ...active ? {} : { inactive: true } })), ...rows.length > 40 ? { more: "Only the first 40: narrow with company, kind or q." } : {} };
}
async function names(db) {
  const active = `${LIVE} AND COALESCE(active, 1) = 1`;
  return { people: (await db.all(`SELECT name FROM ${T.people} WHERE ${active} ORDER BY lower(name)`)).map((r) => r.name), companies: (await db.all(`SELECT name FROM ${T.companies} WHERE ${active} ORDER BY lower(name)`)).map((r) => r.name) };
}

// server/services/import.mjs
var plain2 = (s) => String(s ?? "").trim().toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/[^a-z0-9]/g, "");
var PROJECT = ["projecte", "proyecto", "project", "obra", "projectid", "obraid", "projecteid", "proyectoid", "nomobra", "nombreobra"];
var STATE = ["estat", "estado", "status", "state"];
var REMARKS = ["observacions", "observaciones", "observacio", "observacion", "remarks", "comentaris", "comentarios", "notes", "notas"];
var TRAVEL = ["horesdesplacament", "horasdesplazamiento", "desplacament", "desplazamiento", "horesviatge", "horasviaje", "travel", "hourstravel"];
var KM = ["kmdesplacament", "kmdesplazamiento", "km", "quilometres", "kilometros", "kilometres"];
var DAY = ["data", "fecha", "dia", "day", "date"];
var ACTIVE = ["actiu", "activa", "activo", "active"];
var KIND = ["tipus", "tipo", "type", "kind"];
var EMAIL = ["email", "correu", "correo", "mail", "correuelectronic", "correoelectronico"];
var PHONE = ["telefon", "telefono", "phone", "tel", "mobil", "movil"];
var COLUMNS = {
  incidents: {
    project: PROJECT,
    ref: ["ref", "referencia", "numreferencia", "numref", "numero", "num", "codi", "codigo", "code"],
    title: ["titol", "title", "titulo", "nom", "nombre", "assumpte", "asunto", "resum", "resumen"],
    description: ["descripcio", "descripcion", "description", "detall", "detalle"],
    severity: ["gravetat", "gravedad", "severity", "prioritat", "prioridad", "priority"],
    state: STATE,
    responsible: ["responsable", "responsible", "assignat", "asignado", "assignee"],
    chapter: ["capitol", "capitulo", "chapter", "categoria"],
    subchapter: ["subcapitol", "subcapitulo", "subchapter"],
    location: ["ubicacio", "ubicacion", "location", "lloc", "lugar", "zona", "localitzacio", "localizacion"],
    started_on: ["datacreacio", "datainici", "fechainicio", "fechacreacion", "startedon", "inici", "inicio", "data", "fecha", "createdat", "created"],
    due_on: ["datalimit", "fechalimite", "limit", "limite", "deadline", "venciment", "vencimiento", "dueon", "dataprevista", "fechaprevista"],
    closed_on: ["datatancament", "tancament", "cierre", "fechacierre", "closedat", "closedon", "dataresolucio", "fecharesolucion"],
    attachments: ["adjunts", "adjuntos", "attachments", "fitxers", "archivos", "fotos", "documents", "documentos", "documentacio"],
    remarks: REMARKS,
    reported_by: ["agent", "agente", "autor", "creador", "reportedby", "creatper", "creadopor", "informador"],
    forecast: ["previsio", "prevision"],
    delay_days: ["retard", "retraso", "retras", "diesretard", "diasretraso", "delay", "delaydays"],
    expected_delay_days: ["previsioretard", "retardprevist", "retrasoprevisto", "expecteddelay", "expecteddelaydays"],
    cost_estimated: ["costprevisio", "costprevist", "costeprevision", "costeprevisto", "pptinicial", "estimat", "estimado", "costestimated"],
    cost_real: ["costreal", "costereal"],
    cost_approved_on: ["dataaprovacio", "fechaaprobacion", "aprovacio", "aprobacion", "costapprovedon"],
    cost_certified: ["certificat", "certificado", "certified"],
    cost_invoiced: ["facturat", "facturado", "invoiced"],
    cost_paid: ["pagat", "pagado", "paid"]
  },
  history: {
    incident: ["incidenciaid", "incidencia", "incidentid", "incident", "idincidencia"],
    day: DAY,
    field: ["camp", "campo", "field"],
    before: ["valoranterior", "anterior", "abans", "antes", "before", "oldvalue"],
    after: ["valornou", "valornuevo", "nou", "nuevo", "despres", "despues", "after", "newvalue"],
    author: ["usuari", "usuario", "user", "autor", "author"],
    text: ["observacio", "observacion", "observacions", "observaciones", "nota", "note", "comentari", "comentario"]
  },
  hours: {
    day: DAY,
    worker: ["operari", "operario", "treballador", "trabajador", "worker", "nom", "nombre", "name", "empleat", "empleado"],
    project: PROJECT,
    site: ["obra", "lloc", "lugar", "site", "finca", "ubicacio", "ubicacion"],
    company: ["empresa", "company", "subcontracta", "subcontrata"],
    time_in: ["horaentrada", "entrada", "horainici", "horainicio", "timein", "start"],
    time_out: ["horasortida", "horasalida", "sortida", "salida", "horafi", "horafin", "timeout", "end"],
    break_min: ["pausamin", "pausa", "descans", "descanso", "breakmin", "break"],
    hours_ordinary: ["horesordinaries", "horasordinarias", "ordinaries", "ordinarias", "horesnormals", "horasnormales", "hores", "horas", "hours", "h", "total", "horestreballades", "horastrabajadas"],
    hours_overtime: ["horesextres", "horasextras", "horasextra", "horesextra", "extres", "extras", "overtime"],
    hours_travel: TRAVEL,
    km: KM,
    task: ["tasca", "tarea", "task", "concepte", "concepto", "feina", "trabajo", "descripcio", "descripcion"],
    validated_by: ["responsablevalidacio", "responsablevalidacion", "validatper", "validadopor", "validador", "validatedby", "responsable"],
    state: STATE,
    paid: ["pagat", "pagado", "paid"],
    notes: REMARKS,
    origin: ["origen", "origin", "font", "fuente"]
  },
  jobs: {
    day: DAY,
    worker: ["treballador", "trabajador", "operari", "operario", "worker", "tecnic", "tecnico"],
    project: PROJECT,
    property: ["finca", "immoble", "inmueble", "property", "adreca", "direccio", "direccion", "lloc", "lugar"],
    town: ["localitat", "localidad", "municipi", "municipio", "poblacio", "poblacion", "town", "city", "ciutat", "ciudad"],
    concept: ["concepte", "concepto", "concept", "tasca", "tarea", "titol", "titulo"],
    description: ["descripcio", "descripcion", "description", "detall", "detalle"],
    hours: ["horestreball", "horastrabajo", "hores", "horas", "hours"],
    hours_travel: TRAVEL,
    km: KM,
    rate: ["tarifahora", "tarifa", "preuhora", "preciohora", "rate", "hourlyrate"],
    billable: ["facturable", "billable"],
    client: ["client", "cliente", "customer"],
    notes: REMARKS,
    state: STATE,
    registered: ["registratclient", "registradocliente", "registrat", "registrado", "registered"],
    total: ["importtotal", "importetotal", "import", "importe", "total", "amount"]
  },
  projects: {
    name: ["nom", "nombre", "name", "projecte", "proyecto", "obra", "titol", "titulo"],
    code: ["codi", "codigo", "code", "ref"],
    group: ["grup", "grupo", "group"],
    client: ["client", "cliente", "promotor", "promotora", "propietari", "propietario"],
    kind: KIND,
    state: STATE,
    active: ACTIVE,
    responsible: ["responsable", "responsible"],
    color: ["color", "colour"],
    notes: ["descripcio", "descripcion", "description", "notes", "notas", "observacions", "observaciones"],
    address: ["adreca", "direccio", "direccion", "address"],
    city: ["municipi", "municipio", "ciutat", "ciudad", "city", "poblacio", "poblacion"],
    started_on: ["datainici", "fechainicio", "inici", "inicio"]
  },
  companies: { name: ["nom", "nombre", "name", "empresa", "raosocial", "razonsocial"], kind: KIND, contact: ["contacteprincipal", "contactoprincipal", "contacte", "contacto", "contact"], email: EMAIL, phone: PHONE, notes: REMARKS, active: ACTIVE },
  people: { name: ["nom", "nombre", "name", "persona"], role: ["rol", "role", "carrec", "cargo"], area: ["area"], company: ["empresa", "company"], kind: KIND, email: EMAIL, phone: PHONE, active: ACTIVE, notes: REMARKS }
};
var TABLES = { incidencies: "incidents", incidencies_historial: "history", hores_operaris: "hours", treballs: "jobs", projectes: "projects", projectes_config: "projects", empreses: "companies", persones: "people" };
var NOT_DATA = /^(agents|agentes|eixos|ejes)(_|$)|^(arees_operatives|areas_operativas)$/;
var KINDS2 = Object.keys(COLUMNS);
var ID_COLUMNS = ["id", "_id", "rowid"];
var PHOTO = /\.(jpe?g|png|webp|heic|gif)(\?|#|$)/i;
function mappingOf(kind, columns, given = {}) {
  const fields2 = COLUMNS[kind];
  const map = {};
  for (const [theirs, ours] of Object.entries(given || {})) if (fields2[ours] && columns.includes(theirs)) map[ours] = theirs;
  for (const [field, names2] of Object.entries(fields2)) if (!map[field]) {
    const hit = names2.map((n) => columns.find((c) => plain2(c) === n && !Object.values(map).includes(c))).find(Boolean);
    if (hit) map[field] = hit;
  }
  const used = new Set(Object.values(map));
  return { map, unmapped: columns.filter((c) => !used.has(c) && !ID_COLUMNS.includes(plain2(c)) && !/^_/.test(c)) };
}
var mark = (s) => {
  let a = 2166136261;
  let b = 461845907;
  for (let i = 0; i < s.length; i++) {
    const c = s.charCodeAt(i);
    a = Math.imul(a ^ c, 16777619);
    b = Math.imul(b ^ c, 2246822507);
    b ^= b >>> 13;
  }
  return (a >>> 0).toString(36) + (b >>> 0).toString(36);
};
function sourcesOf(table) {
  const times = /* @__PURE__ */ new Map();
  return (row2) => {
    const id = row2.id ?? row2._id ?? row2.rowid;
    if (id !== void 0 && id !== null && id !== "") return `${table}:${id}`;
    const m = mark(JSON.stringify(Object.keys(row2).sort().map((k) => [k, row2[k] ?? null])));
    const n = (times.get(m) ?? 0) + 1;
    times.set(m, n);
    return `${table}:#${m}${n > 1 ? "." + n : ""}`;
  };
}
function attachmentsOf(v) {
  if (v === void 0 || v === null || v === "") return [];
  let list6 = v;
  if (typeof v === "string") {
    const s = v.trim();
    try {
      list6 = /^[[{]/.test(s) ? JSON.parse(s) : s.split(/[\n;,|]+/);
    } catch {
      list6 = s.split(/[\n;,|]+/);
    }
  }
  if (!Array.isArray(list6)) list6 = [list6];
  return list6.map((x) => {
    const o = x && typeof x === "object" ? x : { ref: String(x ?? "").trim() };
    const ref = String(o.url ?? o.path ?? o.ref ?? o.file ?? o.href ?? o.src ?? "").trim();
    if (!ref) return null;
    const name = text(o.name ?? o.nom ?? o.title ?? o.filename, 200) || decodeURIComponent(ref.split(/[?#]/)[0].split("/").pop() || ref).slice(0, 200);
    return /^https:\/\//i.test(ref) ? { name, url: ref } : { name, path: ref.slice(0, 500) };
  }).filter(Boolean);
}
async function importRows(db, i, actor, now) {
  const tableName = text(i.table, 60) || "";
  if (NOT_DATA.test(tableName.trim().toLowerCase())) throw new Refused(`${tableName} describes the company's old agents, not its works: it is not this module's data. Leave it where it is.`, 400, { code: "NOT_MODULE_DATA" });
  const kind = KINDS2.includes(i.kind) ? i.kind : !i.kind ? TABLES[tableName.toLowerCase()] ?? null : null;
  if (!kind) throw new Refused(`kind is one of: ${KINDS2.join(", ")}${i.kind ? "" : " (or a table this module knows by name: " + Object.keys(TABLES).join(", ") + ")"}.`, 400, { code: "BAD_CHOICE" });
  const rows = listOf(i.rows, "rows").filter((r) => r && typeof r === "object");
  if (!rows.length) throw new Refused("Send the rows as they are in the old table: rows: [{ column: value, \u2026 }].", 400, { code: "BAD_INPUT" });
  if (rows.length > 500) throw new Refused("At most 500 rows in one call: send the rest in another (a row sent twice is added once).", 400, { code: "TOO_MANY" });
  const dry = !(i.dry_run === false || i.dry_run === "false");
  const table = tableName || kind;
  const day = today(now);
  const { map, unmapped } = mappingOf(kind, [...new Set(rows.flatMap((r) => Object.keys(r)))], typeof i.map === "object" ? i.map : {});
  const get = (row2, field) => {
    const v = map[field] ? row2[map[field]] : void 0;
    return v === null || v === "" ? void 0 : v;
  };
  const out = { added: 0, updated: 0, already: 0, problems: [] };
  const problem = (index, e) => {
    if (!(e instanceof Refused)) throw e;
    if (out.problems.length < 12) out.problems.push({ index, code: e.code, why: e.message });
    out.failed = (out.failed ?? 0) + 1;
  };
  const values = {};
  const unknown = {};
  const overrides = typeof i.values === "object" && i.values ? i.values : {};
  const word = (field, v, words, fallback) => {
    if (v === void 0) return fallback;
    const theirs = String(v).trim();
    const key = (overrides[field] && Object.keys(words).includes(overrides[field][theirs]) ? overrides[field][theirs] : null) ?? wordOf(v, words);
    if (Object.keys(values[field] ??= {}).length < 12) values[field][theirs] = key ?? fallback;
    if (!key) (unknown[field] ??= /* @__PURE__ */ new Set()).add(theirs);
    return key ?? fallback;
  };
  const dateIn = (row2, f) => {
    const v = get(row2, f);
    return v === void 0 ? null : dateOf(String(v).trim().slice(0, 10), map[f]);
  };
  const sourceOf = sourcesOf(table);
  const TABLE_OF = { incidents: T.incidents, hours: T.hours, jobs: T.jobs, history: T.notes, companies: T.companies, people: T.people };
  const seen = TABLE_OF[kind] ? new Set((await db.all(`SELECT source FROM ${TABLE_OF[kind]} WHERE ${LIVE} AND source LIKE ?`, [table + ":%"])).map((r) => r.source)) : /* @__PURE__ */ new Set();
  const projects = ["incidents", "hours", "jobs", "projects"].includes(kind) ? await db.all(`SELECT * FROM ${T.projects} WHERE ${LIVE}`) : [];
  const fixed = i.project_id ? (await projectOf(db, i.project_id))._id : null;
  const given = typeof i.project_map === "object" && i.project_map ? i.project_map : {};
  const findProject = (said2) => projects.find((p) => plain2(p.name) === plain2(said2) || p.code && plain2(p.code) === plain2(said2));
  const projectFor = (row2, optional = false) => {
    const said2 = get(row2, "project");
    if (said2 !== void 0 && Object.hasOwn(given, String(said2))) return given[String(said2)] === null ? null : Number(given[String(said2)]);
    if (said2 !== void 0) {
      const hit = findProject(said2);
      if (hit) return hit._id;
    }
    if (fixed) return fixed;
    if (said2 === void 0 && optional) return null;
    throw new Refused(said2 === void 0 ? "This row names no project: send project_id, or map its project column." : `No project here is called "${String(said2).slice(0, 60)}": import the projects first (kind: projects), or send project_map: { "${String(said2).slice(0, 40)}": <project id${optional ? ", or null for none" : ""}> }.`, 400, { code: "UNKNOWN_PROJECT" });
  };
  const chapterCache = /* @__PURE__ */ new Map();
  const counters = /* @__PURE__ */ new Map();
  for (const [index, row2] of rows.entries()) {
    try {
      const source = sourceOf(row2);
      if (kind === "projects") {
        const name = text(get(row2, "name"), 200);
        if (!name) throw new Refused("This row has no name for the project.", 400, { code: "NAME_REQUIRED" });
        const stateSaid2 = get(row2, "state");
        const inactive = map.active && get(row2, "active") !== void 0 && !yes(get(row2, "active"));
        const data = { code: text(get(row2, "code"), 20), client: text(get(row2, "client"), 200), group: text(get(row2, "group"), 120), kind: text(get(row2, "kind"), 80), responsible: text(get(row2, "responsible"), 120), color: text(get(row2, "color"), 20), notes: text(get(row2, "notes")), address: text(get(row2, "address"), 300), city: text(get(row2, "city"), 200) };
        const had = projects.find((p) => plain2(p.name) === plain2(name) || p.code && plain2(p.code) === plain2(name) || data.code && p.code && plain2(p.code) === plain2(data.code));
        if (had) {
          const fill = Object.fromEntries(Object.entries(data).filter(([k, v]) => v && !had[k === "group" ? "group_name" : k]).map(([k, v]) => [k === "group" ? "group_name" : k, v]));
          if (inactive && (had.state || "active") === "active") fill.state = "finished";
          if (!Object.keys(fill).length) {
            out.already++;
            continue;
          }
          if (!dry && had._id > 0) await db.update(T.projects, had._id, fill);
          Object.assign(had, fill);
          out.updated++;
          continue;
        }
        const state = stateSaid2 !== void 0 ? word("state", stateSaid2, PROJECT_STATES, "active") : inactive ? "finished" : "active";
        const started2 = dateIn(row2, "started_on") ?? void 0;
        const card = Object.fromEntries(Object.entries({ ...data, state, started_on: started2 }).filter(([, v]) => v));
        if (!dry) {
          const made = await add(db, { name, ...card }, { now });
          projects.push({ _id: made.id, name, ...card, group_name: card.group });
        } else projects.push({ _id: -1, name, ...card, group_name: card.group });
        out.added++;
        continue;
      }
      if (kind === "companies" || kind === "people") {
        const one5 = kind === "companies" ? "company" : "person";
        const d = entryFields(one5, Object.fromEntries(Object.keys(COLUMNS[kind]).map((k) => [k, get(row2, k)])));
        if (!d.name) throw new Refused("This row has no name.", 400, { code: "NAME_REQUIRED" });
        const had = await db.one(`SELECT * FROM ${TABLE_OF[kind]} WHERE lower(name) = lower(?) AND ${LIVE}`, [d.name]);
        if (had || seen.has("name:" + plain2(d.name))) {
          const fill = had ? Object.fromEntries(Object.entries(d).filter(([k, v]) => k !== "name" && k !== "active" && v && !had[k])) : {};
          if (!Object.keys(fill).length) {
            out.already++;
            continue;
          }
          if (!dry) await db.update(TABLE_OF[kind], had._id, fill);
          out.updated++;
          continue;
        }
        seen.add("name:" + plain2(d.name));
        if (!dry) await db.insert(TABLE_OF[kind], { ...Object.fromEntries(Object.keys(COLUMNS[kind]).map((k) => [k, ""])), active: 1, ...d, source, removed: 0 });
        out.added++;
        continue;
      }
      if (seen.has(source)) {
        out.already++;
        continue;
      }
      if (kind === "history") {
        const of = get(row2, "incident");
        if (of === void 0) throw new Refused("This row does not say which incident it is about.", 400, { code: "BAD_INPUT" });
        const incident = await db.one(`SELECT _id, started_on FROM ${T.incidents} WHERE source = ? AND ${LIVE}`, [`${text(i.incidents_table, 60) || "incidencies"}:${of}`]);
        if (!incident) throw new Refused(`No incident here came from row ${String(of).slice(0, 30)} of the old incidents table: import the incidents first (and say incidents_table if it was not "incidencies").`, 400, { code: "UNKNOWN_INCIDENT" });
        const change = [get(row2, "field") !== void 0 ? `${get(row2, "field")}:` : "", get(row2, "before") !== void 0 || get(row2, "after") !== void 0 ? `${get(row2, "before") ?? "\u2014"} \u2192 ${get(row2, "after") ?? "\u2014"}` : ""].filter(Boolean).join(" ");
        const said2 = text(get(row2, "text"), 2e3) || "";
        const line2 = [change, said2].filter(Boolean).join(change && said2 ? ". " : "");
        if (!line2) throw new Refused("This row of history says nothing (no field, values or remark).", 400, { code: "TEXT_REQUIRED" });
        if (!dry) await db.insert(T.notes, { incident_id: incident._id, day: dateIn(row2, "day") ?? incident.started_on, text: line2, author: text(get(row2, "author"), 120) || "", source, removed: 0 });
        seen.add(source);
        out.added++;
        continue;
      }
      if (kind === "hours") {
        const pid2 = projectFor(row2);
        const d = lineFields({
          worker: get(row2, "worker"),
          day: dateIn(row2, "day") ?? void 0,
          site: get(row2, "site"),
          company: get(row2, "company"),
          time_in: get(row2, "time_in"),
          time_out: get(row2, "time_out"),
          break_min: get(row2, "break_min"),
          hours_ordinary: get(row2, "hours_ordinary"),
          hours_overtime: get(row2, "hours_overtime"),
          hours_travel: get(row2, "hours_travel"),
          km: get(row2, "km"),
          task: get(row2, "task"),
          validated_by: get(row2, "validated_by"),
          state: word("state", get(row2, "state"), HOUR_STATES, "pendent"),
          paid: map.paid ? get(row2, "paid") ?? 0 : void 0,
          notes: get(row2, "notes"),
          origin: get(row2, "origin")
        });
        if (!d.worker || !d.day) throw new Refused("A row of hours needs who (worker) and its day.", 400, { code: "BAD_INPUT" });
        let h = settle(d);
        if (typeof h === "string" && /needs its hours/.test(h)) {
          h = { hours_ordinary: 0, hours_overtime: 0, hours_travel: 0, hours: 0 };
          out.zero_hours = (out.zero_hours ?? 0) + 1;
        }
        if (typeof h === "string") throw new Refused(h, 400, { code: "BAD_HOURS" });
        if (!dry && pid2 > 0) await db.insert(T.hours, { site: "", company: "", task: "", validated_by: "", notes: "", origin: "", paid: 0, ...d, ...h, project_id: pid2, source, removed: 0 });
        seen.add(source);
        out.added++;
        continue;
      }
      if (kind === "jobs") {
        const pid2 = projectFor(row2, true);
        const d = newJob({
          day: dateIn(row2, "day") ?? void 0,
          worker: get(row2, "worker"),
          client: get(row2, "client"),
          property: get(row2, "property"),
          town: get(row2, "town"),
          concept: get(row2, "concept"),
          description: get(row2, "description"),
          hours: get(row2, "hours"),
          hours_travel: get(row2, "hours_travel"),
          km: get(row2, "km"),
          rate: get(row2, "rate"),
          billable: map.billable ? get(row2, "billable") ?? 0 : void 0,
          state: word("state", get(row2, "state"), JOB_STATES, "pendent"),
          registered: map.registered ? get(row2, "registered") ?? 0 : void 0,
          total: get(row2, "total"),
          notes: get(row2, "notes")
        });
        if (get(row2, "total") !== void 0 && d.rate !== null && d.total !== totalOf(d.hours, d.rate)) out.total_differs = (out.total_differs ?? 0) + 1;
        if (!d.client && pid2 > 0) d.client = projects.find((p) => p._id === pid2)?.client || "";
        if (!dry && (pid2 === null || pid2 > 0)) await db.insert(T.jobs, { ...d, project_id: pid2, source, removed: 0 });
        seen.add(source);
        out.added++;
        continue;
      }
      const pid = projectFor(row2);
      const description = text(get(row2, "description"), 8e3) || "";
      const title = text(get(row2, "title"), 200) || description.split(/[.\n]/)[0].slice(0, 90);
      if (!title) throw new Refused("This row has neither a title nor a description.", 400, { code: "TITLE_REQUIRED" });
      const started = dateIn(row2, "started_on") ?? day;
      const forecast = get(row2, "forecast");
      const forecastIsDate = forecast !== void 0 && /\d{1,4}[-/.]\d{1,2}[-/.]\d{1,4}/.test(String(forecast));
      const severity = word("severity", get(row2, "severity"), SEVERITIES, "lleu");
      const stateSaid = word("state", get(row2, "state"), INCIDENT_STATES, "oberta");
      let closed = dateIn(row2, "closed_on");
      if (!closed && stateSaid === "tancada") closed = started > day ? started : day;
      if (closed && closed < started) closed = started;
      let chapter = { chapter: "", subchapter: "" };
      let extra = "";
      if (pid > 0 && (get(row2, "chapter") !== void 0 || get(row2, "subchapter") !== void 0)) {
        if (!chapterCache.has(pid)) chapterCache.set(pid, await chaptersOf(db, pid));
        try {
          chapter = resolveChapter(chapterCache.get(pid), get(row2, "chapter"), get(row2, "subchapter"));
        } catch {
          out.without_chapter = (out.without_chapter ?? 0) + 1;
          extra = `

[${[get(row2, "chapter"), get(row2, "subchapter")].filter((x) => x !== void 0).join(" / ")}]`;
        }
      }
      const files = attachmentsOf(get(row2, "attachments"));
      if (files.length) out.attachments = (out.attachments ?? 0) + files.length;
      if (!dry && pid > 0) {
        if (!counters.has(pid)) counters.set(pid, Number((await db.one(`SELECT COUNT(*) AS n FROM ${T.incidents} WHERE project_id = ?`, [pid]))?.n ?? 0));
        counters.set(pid, counters.get(pid) + 1);
        const id = await db.insert(T.incidents, {
          project_id: pid,
          ref: text(get(row2, "ref"), 40) || refOf(chapter.chapter, chapter.subchapter, counters.get(pid)),
          title,
          ...chapter,
          location: text(get(row2, "location"), 200) || "",
          started_on: started,
          reported_by: text(get(row2, "reported_by"), 120) || who(actor),
          responsible: text(get(row2, "responsible"), 120) || "",
          due_on: dateIn(row2, "due_on") ?? (forecastIsDate ? dateOf(String(forecast).slice(0, 10), "forecast") : null),
          expected_delay_days: int(get(row2, "expected_delay_days") ?? (forecast !== void 0 && !forecastIsDate && Number.isFinite(Number(forecast)) ? forecast : void 0)),
          delay_days: Number.isFinite(Number(get(row2, "delay_days"))) ? int(get(row2, "delay_days")) : null,
          closed_on: closed,
          state: closed ? "tancada" : stateSaid,
          severity,
          description: description + extra,
          remarks: text(get(row2, "remarks"), 4e3) || "",
          cost_estimated: cents(get(row2, "cost_estimated")),
          cost_real: cents(get(row2, "cost_real")),
          cost_approved_on: dateIn(row2, "cost_approved_on"),
          cost_certified: bool(get(row2, "cost_certified")),
          cost_invoiced: bool(get(row2, "cost_invoiced")),
          cost_paid: bool(get(row2, "cost_paid")),
          source,
          removed: 0
        });
        if (files.length) await db.batch(files.map((f) => ({ op: "insert", table: T.attachments, data: { project_id: pid, incident_id: id, visit_id: null, kind: PHOTO.test(f.url ?? f.path) ? "photo" : "doc", name: f.name, source: f.url ? "link" : "file", ref: f.url ?? f.path, data: "", note: "", removed: 0 } })));
      }
      seen.add(source);
      out.added++;
    } catch (e) {
      problem(index, e);
    }
  }
  const unknownValues = Object.fromEntries(Object.entries(unknown).map(([k, set]) => [k, [...set].slice(0, 12)]));
  const NEXT = { projects: "companies and people, then incidents, hours and jobs", companies: "people", people: "incidents", incidents: "history (its incidencia_id finds each incident), then hours and jobs", history: "hours and jobs", hours: "jobs", jobs: null };
  return {
    kind,
    table,
    dry_run: dry,
    rows: rows.length,
    [dry ? "would_add" : "added"]: out.added,
    ...out.updated ? { [dry ? "would_update" : "updated"]: out.updated } : {},
    already: out.already,
    ...out.failed ? { failed: out.failed } : {},
    ...out.without_chapter ? { without_chapter: out.without_chapter } : {},
    ...out.attachments ? { attachments: out.attachments } : {},
    ...out.zero_hours ? { zero_hours: out.zero_hours } : {},
    ...out.total_differs ? { total_differs: out.total_differs, total_how: "Rows whose total is not work hours \xD7 rate (this module's formula): kept as they came." } : {},
    problems: out.problems,
    mapping: map,
    unmapped,
    ...Object.keys(values).length ? { values } : {},
    ...Object.keys(unknownValues).length ? { unknown_values: unknownValues, unknown_how: 'These words were not recognised and took the default shown in values: say what each means with values: { "<field>": { "<their word>": "<one of ours>" } }.' } : {},
    ...dry ? { next: out.added || out.updated ? 'Nothing was written. Show the person these counts; if the mapping is right, send the same call with dry_run: false. A column left out goes in map: { "<their column>": "<field>" }.' : "Nothing to add: every row is already here." } : NEXT[kind] ? { next: `Next: ${NEXT[kind]}.` } : {}
  };
}

// server/services/demo.mjs
async function load(db, now) {
  if (await db.one(`SELECT _id FROM ${T.projects} WHERE ${LIVE} LIMIT 1`)) throw new Refused("The example is only for a module with no project yet: there is one already.", 409, { code: "NOT_EMPTY" });
  const day = today(now);
  const d = (n) => addDays(day, n);
  const who2 = "person:Ejemplo";
  const { id } = await add(db, {
    name: "Edifici Roure 21 (ejemplo)",
    code: "R21",
    group: "Promocions",
    kind: "Obra nova",
    responsible: "Direcci\xF3 facultativa",
    color: "#B7AD98",
    address: "C/ del Roure, 21",
    city: "08400 Granollers",
    client: "Promocions Montnegre, SL",
    started_on: d(-210),
    ends_on: d(240),
    units: [{ kind: "habitatge", count: 12 }, { kind: "local", count: 1 }, { kind: "aparcament", count: 10 }, { kind: "traster", count: 6 }]
  }, { demo: true, now });
  const units = await db.all(`SELECT _id, kind FROM ${T.units} WHERE project_id = ? ORDER BY _id`, [id]);
  const homes = units.filter((u) => u.kind === "habitatge");
  const parks = units.filter((u) => u.kind === "aparcament");
  await unitsUpdate(db, { units: [...homes.slice(0, 3).map((u) => ({ id: u._id, state: "sold" })), ...homes.slice(3, 5).map((u) => ({ id: u._id, state: "reserved" })), ...parks.slice(0, 2).map((u) => ({ id: u._id, state: "sold" }))] });
  const first = await addMany(db, { project_id: id, items: [
    { title: "Filtraci\xF3 d'aigua al mur de contenci\xF3 del soterrani -2", chapter: "03", subchapter: "C", location: "Soterrani -2, mur nord", severity: "greu", responsible: "Constructora Montseny, SL", reported_by: "Direcci\xF3 facultativa", started_on: d(-75), due_on: d(-40), expected_delay_days: 20, cost_estimated: 18500, cost_real: 21300, cost_approved_on: d(-50), cost_certified: true, description: "Apareixen filtracions al mur nord despr\xE9s de les pluges. Cal impermeabilitzar per l'intrad\xF3s i revisar el drenatge perimetral." },
    { title: "Fissura en una biga de la planta 3", chapter: "03", subchapter: "E", location: "Planta 3, eix B-4", severity: "greu", responsible: "Estructurista", reported_by: "Direcci\xF3 facultativa", started_on: d(-32), due_on: d(-10), expected_delay_days: 15, cost_estimated: 9e3, description: "Fissura a 45\xB0 prop del suport. L'estructurista demana testimonis i una prova de c\xE0rrega abans de continuar amb la planta 4." },
    { title: "Recorregut dels baixants incompatible amb el fals sostre", chapter: "03", subchapter: "I", location: "Planta baixa, local", severity: "important", responsible: "Enginyeria", started_on: d(-41), due_on: d(-20), cost_estimated: 4200, cost_real: 3900, cost_approved_on: d(-25), description: "Els baixants de la P1 creuen el local a una al\xE7ada que no deixa el fals sostre previst. Es proposa desviar-los pel pati." },
    { title: "Trobada de la fa\xE7ana ventilada amb la fusteria sense resoldre", chapter: "03", subchapter: "F", location: "Fa\xE7ana principal, P1 a P4", severity: "important", responsible: "Direcci\xF3 facultativa", started_on: d(-20), due_on: d(10), description: "Falta el detall constructiu del remat entre el panell i el premarc. La constructora no pot demanar el material." },
    { title: "Requeriment de l'Ajuntament per l'ocupaci\xF3 de la via p\xFAblica", chapter: "04", subchapter: "43", location: "Carrer del Roure", severity: "important", responsible: "Promotora", started_on: d(-18), due_on: d(-3), description: "L'Ajuntament demana ampliar el pas de vianants al costat de la bastida abans de renovar el perm\xEDs." },
    { title: "L'escomesa el\xE8ctrica demana una nova CGP", chapter: "05", subchapter: "51", location: "Fa\xE7ana, planta baixa", severity: "important", responsible: "Enginyeria", started_on: d(-55), due_on: d(-15), cost_estimated: 6e3, description: "La companyia no accepta la ubicaci\xF3 prevista de la caixa general de protecci\xF3. Cal un n\xEDnxol nou a fa\xE7ana." },
    { title: "Pl\xE0nol d'acabats de la planta 2 desactualitzat", chapter: "02", subchapter: "21", location: "Oficina t\xE8cnica", severity: "lleu", responsible: "Arquitecte", started_on: d(-27), closed_on: d(-19), description: "El pl\xE0nol en obra no recull el canvi de distribuci\xF3 del 2n 2a." }
  ] }, who2, now);
  const v1 = await addMany(db, { project_id: id, visit: { day: d(-12), attendees: "Direcci\xF3 facultativa, cap d'obra, promotora", summary: "Visita setmanal. Estructura de la planta 4 en curs; comencen els tancaments de la planta 1." }, items: [
    { title: "Enrajolat del bany amb un to diferent del de la mostra", chapter: "03", subchapter: "R", location: "2n 1a, bany principal", severity: "lleu", responsible: "Constructora Montseny, SL", description: "El lot rebut no coincideix amb la mostra aprovada." },
    { title: "Portes interiors rebudes amb cops", chapter: "03", subchapter: "L", location: "Magatzem d'obra", severity: "lleu", responsible: "Constructora Montseny, SL", description: "Quatre fulles amb cops als cantells." }
  ] }, who2, now);
  const v2 = await addMany(db, { project_id: id, visit: { day: d(-5), attendees: "Direcci\xF3 facultativa, cap d'obra", summary: "Visita setmanal. Es revisa la coberta abans d'impermeabilitzar." }, items: [
    { title: "Barana provisional incompleta a l'escala", chapter: "03", subchapter: "Y", location: "Escala, P4 a P5", severity: "lleu", responsible: "Coordinador de seguretat", description: "Falta el tram entre replans." },
    { title: "L\xE0mina impermeable mal solapada a la terrassa", chapter: "03", subchapter: "N", location: "Coberta, terrassa est", severity: "lleu", responsible: "Constructora Montseny, SL", description: "Solapaments de menys de 10 cm en dos punts." },
    { title: "Pendents de coberta insuficients a la zona d'instal\xB7lacions", chapter: "03", subchapter: "Q", location: "Coberta", severity: "important", responsible: "Direcci\xF3 facultativa", due_on: d(14), expected_delay_days: 7, description: "L'aigua queda embassada al voltant de les bancades. Cal refer el morter de pendents abans de la l\xE0mina." }
  ] }, who2, now);
  const [a, b, c] = first.added;
  await notesAdd(db, { items: [
    { incident_id: a.id, day: d(-68), text: "La constructora presenta una proposta d'impermeabilitzaci\xF3 per l'intrad\xF3s." },
    { incident_id: a.id, day: d(-50), text: "La promotora aprova el contradictori. Comencen els treballs." },
    { incident_id: a.id, day: d(-21), text: "Executat el 80 %. Falta el tram de la rampa." },
    { incident_id: b.id, day: d(-28), text: "Col\xB7locats els testimonis. Lectura setmanal." },
    { incident_id: b.id, day: d(-9), text: "Els testimonis no es mouen. Pendent de la prova de c\xE0rrega." },
    { incident_id: c.id, day: d(-25), text: "Aprovat el desviament pel pati." }
  ] }, who2, now);
  await closeMany(db, { ids: [v1.added[1].id], closed_on: d(-4), note: "El prove\xEFdor substitueix les quatre fulles." }, who2, now);
  await closeMany(db, { ids: [v2.added[0].id], closed_on: d(-3), note: "Barana completada." }, who2, now);
  await proceduresAdd(db, { project_id: id, items: [
    { title: "Llic\xE8ncia d'obres majors", kind: "licence", state: "done", done_on: d(-200), responsible: "Promotora" },
    { title: "Ocupaci\xF3 de la via p\xFAblica (bastida)", kind: "licence", state: "in_progress", next_step: "Respondre el requeriment de l'Ajuntament", next_on: d(-2), responsible: "Promotora" },
    { title: "Escomesa el\xE8ctrica definitiva", kind: "connection", state: "blocked", next_step: "Esperar la valoraci\xF3 de la companyia per la nova CGP", responsible: "Enginyeria" },
    { title: "Escomesa d'aigua", kind: "connection", state: "pending", next_step: "Sol\xB7licitar-la quan acabi l'estructura", next_on: d(30), responsible: "Constructora Montseny, SL" },
    { title: "Asseguran\xE7a tot risc construcci\xF3", kind: "insurance", state: "done", done_on: d(-205) },
    { title: "Asseguran\xE7a decennal", kind: "insurance", state: "in_progress", next_step: "Enviar l'informe de l'OCT a l'asseguradora", next_on: d(7) },
    { title: "Dip\xF2sit de garantia de residus", kind: "deposit", state: "done", done_on: d(-198) },
    { title: "Contracte amb la constructora", kind: "contract", state: "done", done_on: d(-215) }
  ] });
  for (const [name, kind, contact] of [["Constructora Montseny, SL", "Constructora", "Laia Puig"], ["Instal\xB7lacions Bes\xF2s", "Industrial", "Marc Soler"], ["Promocions Montnegre, SL", "Client", "Anna Ribas"]]) await db.insert(T.companies, { name, kind, contact, email: "", phone: "", notes: "", active: 1, source: "demo", removed: 0 });
  for (const [name, role, company, kind] of [["Pau Serra", "Oficial 1a", "Constructora Montseny, SL", "Operari"], ["Nil Font", "Oficial 2a", "Constructora Montseny, SL", "Operari"], ["Jan Vila", "Instal\xB7lador", "Instal\xB7lacions Bes\xF2s", "Operari"], ["Laia Puig", "Cap d'obra", "Constructora Montseny, SL", "T\xE8cnic"]]) await db.insert(T.people, { name, role, area: "Obra", company, kind, email: "", phone: "", notes: "", active: 1, source: "demo", removed: 0 });
  const crew = [["Pau Serra", "Constructora Montseny, SL", "Encofrat P4"], ["Nil Font", "Constructora Montseny, SL", "Tancaments P1"], ["Jan Vila", "Instal\xB7lacions Bes\xF2s", "Instal\xB7lacions"]];
  await hoursAdd(db, { project_id: id, items: Array.from({ length: 24 }, (_, k) => {
    const [worker, company, task] = crew[k % 3];
    const n = Math.floor(k / 3);
    return { worker, company, task, day: d(-1 - n - 30 * (n > 5 ? 1 : 0)), time_in: "08:00", time_out: k % 4 ? "17:00" : "18:30", break_min: 60, hours: 8, hours_overtime: k % 4 ? 0 : 1.5, hours_travel: k % 3 === 2 ? 0.5 : 0, km: k % 3 === 2 ? 24 : 0, state: n > 1 ? "validat" : "pendent", validated_by: n > 1 ? "Laia Puig" : "", paid: n > 3, origin: "manual" };
  }) });
  await jobsAdd(db, { project_id: id, items: [
    { day: d(-33), worker: "Jan Vila", concept: "Reparaci\xF3 d'una fuita al local", property: "C/ del Roure, 21, local", town: "Granollers", hours: 3, hours_travel: 0.5, km: 24, rate: 42, state: "facturat", registered: true },
    { day: d(-6), worker: "Pau Serra", concept: "Ajust de portes a l'habitatge mostra", property: "C/ del Roure, 21, 1r 1a", town: "Granollers", hours: 4.5, rate: 38 }
  ] });
  const report = await draft(db, { project_id: id }, now);
  await write(db, { id: report.id, summary: "Durant el mes l'obra ha avan\xE7at amb l'estructura de la planta 4 i l'inici dels tancaments.\n\nSegueixen obertes dues incid\xE8ncies greus: les filtracions del soterrani -2, amb els treballs executats al 80 %, i la fissura de la biga de la planta 3, pendent de la prova de c\xE0rrega.\n\nEls contradictoris aprovats sumen 25.200 \u20AC de cost real; en queden dos pendents de valorar.", outlook: "Prova de c\xE0rrega de la biga de la planta 3.\nResposta al requeriment de l'Ajuntament per la bastida.\nDetall de la trobada de fa\xE7ana amb la fusteria." });
  return { id, incidents: first.added.length + v1.added.length + v2.added.length, report_id: report.id };
}
var starting = null;
function start(db, now) {
  starting ??= begin(db, now).finally(() => {
    starting = null;
  });
  return starting;
}
async function begin(db, now) {
  if (await db.one(`SELECT _id FROM ${T.projects} WHERE ${LIVE} AND demo = 1 LIMIT 1`)) return { loaded: false, why: "ALREADY_ON" };
  const s = await db.one(`SELECT example FROM ${T.settings} WHERE _deleted = 0 ORDER BY _id LIMIT 1`);
  if (s?.example === "off") return { loaded: false, why: "SWITCHED_OFF" };
  const real = await db.one(`SELECT _id FROM ${T.projects} WHERE COALESCE(demo, 0) = 0 LIMIT 1`);
  const gone = real ? null : await db.one(`SELECT _id FROM ${T.projects} WHERE demo = 1 LIMIT 1`);
  if (real || gone) {
    await exampleOff(db);
    return { loaded: false, why: real ? "REAL_PROJECT" : "SWITCHED_OFF" };
  }
  return { loaded: true, ...await load(db, now) };
}
async function remove3(db) {
  const r = await removeDemo(db);
  await exampleOff(db);
  return r;
}
async function present(db) {
  const projects = await db.all(`SELECT _id, name FROM ${T.projects} WHERE ${LIVE} AND demo = 1 ORDER BY _id`);
  if (!projects.length) return null;
  const names2 = [];
  for (const t of [T.companies, T.people]) for (const r of await db.all(`SELECT name FROM ${t} WHERE source = 'demo' AND ${LIVE}`)) names2.push(r.name);
  return { projects: projects.map((p) => ({ id: p._id, name: p.name })), names: names2 };
}
function marked(answer, ex) {
  if (!ex || !answer || typeof answer !== "object" || Array.isArray(answer)) return answer;
  const ids = new Set(ex.projects.map((p) => p.id));
  const titles = new Set(ex.projects.map((p) => p.name));
  const who2 = new Set(ex.names.map((n) => String(n).toLowerCase()));
  const said2 = [...who2, ...[...titles].map((t) => t.toLowerCase())];
  const invented = (v) => ids.has(v.project_id) || titles.has(v.project) || ids.has(v.id) && titles.has(v.name) || [v.name, v.worker, v.client].some((n) => typeof n === "string" && who2.has(n.toLowerCase())) || typeof v.text === "string" && said2.some((n) => v.text.toLowerCase().includes(n));
  const mark2 = (v) => {
    if (Array.isArray(v)) {
      for (const x of v) mark2(x);
      return;
    }
    if (!v || typeof v !== "object") return;
    if (invented(v)) v.example = true;
    for (const x of Object.values(v)) mark2(x);
  };
  mark2(answer);
  const list6 = ex.projects.map((p) => `${p.id} \xAB${p.name}\xBB`).join(", ");
  return { about_example: `Project ${list6} is an invented EXAMPLE the person sees until they add their first real project; there is no real project yet. Whatever is marked example: true, and every figure counted from it, is invented: never report, count or act on it as real.`, ...answer };
}

// server/services/journeys.mjs
var plain3 = (s) => String(s ?? "").trim().toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "");
var RANK2 = { greu: 0, important: 1, lleu: 2 };
function matchProject(rows, said2) {
  const k = plain3(said2);
  if (!k) return [];
  const exact = rows.filter((p) => plain3(p.code) === k || plain3(p.name) === k);
  const hits = exact.length ? exact : rows.filter((p) => plain3(p.name).includes(k));
  const live = hits.filter((p) => (p.state || "active") !== "archived");
  return hits.length > 1 && live.length ? live : hits;
}
async function projectBy(db, i) {
  if (i.project_id !== void 0 && i.project_id !== null && i.project_id !== "") return projectOf(db, i.project_id);
  const rows = await db.all(`SELECT * FROM ${T.projects} WHERE ${LIVE}`);
  const names2 = rows.filter((p) => (p.state || "active") !== "archived").slice(0, 12).map((p) => `${p.name} (id ${p._id})`).join(", ") || "none yet";
  if (!plain3(i.project)) throw new Refused(`Say which project: project_id, or project (a piece of its name or its code). There are: ${names2}.`, 400, { code: "PROJECT_REQUIRED" });
  const hits = matchProject(rows, i.project);
  if (hits.length === 1) return hits[0];
  throw new Refused(hits.length ? `Several projects match "${i.project}": ${hits.map((p) => `${p.name} (id ${p._id})`).join(", ")}. Say project_id.` : `No project matches "${i.project}". There are: ${names2}.`, hits.length ? 409 : 404, { code: hits.length ? "AMBIGUOUS" : "NOT_FOUND", item: String(i.project) });
}
async function named(db, i) {
  return i.project && !i.project_id ? { ...i, project_id: (await projectBy(db, i))._id } : i;
}
var line = (r, day, max = 70) => ({ id: r._id, ref: r.ref, title: String(r.title).slice(0, max), severity: r.severity || "lleu", ...r.location ? { location: r.location } : {}, ...delayOf(r, day) ? { delay: delayOf(r, day) } : {} });
function attention({ day, period, projects, incidents, procedures: procedures2, reports, hours: hours2, jobs: jobs2 }) {
  const name = Object.fromEntries(projects.map((p) => [p._id, p.name]));
  const items = [];
  const open = incidents.filter((r) => !r.closed_on && name[r.project_id]);
  const of = (r) => ({ id: r._id, project_id: r.project_id, project: name[r.project_id], ref: r.ref, title: r.title, severity: r.severity || "lleu", location: r.location || "", responsible: r.responsible || "", started_on: r.started_on, due_on: r.due_on || null, delay: delayOf(r, day) });
  for (const r of open.filter((x) => x.severity === "greu").sort((a, b) => delayOf(b, day) - delayOf(a, day) || String(a.started_on).localeCompare(String(b.started_on))))
    items.push({ kind: "severe", whose: "person", key: "incident:" + r._id, ...of(r), text: `${name[r.project_id]}: ${r.ref} ${String(r.title).slice(0, 70)} \u2014 greu, open since ${r.started_on}${delayOf(r, day) ? `, ${delayOf(r, day)} days late` : ""}.` });
  for (const r of open.filter((x) => x.severity !== "greu" && delayOf(x, day) > 0).sort((a, b) => delayOf(b, day) - delayOf(a, day)))
    items.push({ kind: "late", whose: "person", key: "incident:" + r._id, ...of(r), text: `${name[r.project_id]}: ${r.ref} ${String(r.title).slice(0, 70)} \u2014 ${delayOf(r, day)} days late (${r.severity || "lleu"}).` });
  for (const p of procedures2.filter((x) => name[x.project_id] && (x.state || "pending") !== "done" && (x.state === "blocked" || x.next_on && x.next_on < day)).sort((a, b) => (a.state === "blocked" ? 0 : 1) - (b.state === "blocked" ? 0 : 1) || String(a.next_on || "9").localeCompare(String(b.next_on || "9")))) {
    const late = p.next_on && p.next_on < day ? daysBetween(p.next_on, day) : 0;
    items.push({
      kind: "procedure",
      whose: "person",
      key: "procedure:" + p._id,
      id: p._id,
      project_id: p.project_id,
      project: name[p.project_id],
      title: p.title,
      state: p.state || "pending",
      next_step: p.next_step || "",
      next_on: p.next_on || null,
      late,
      text: `${name[p.project_id]}: ${p.title} \u2014 ${p.state === "blocked" ? "blocked" : `${late} days past its next step`}${p.next_step ? `: ${String(p.next_step).slice(0, 80)}` : ""}.`
    });
  }
  const { end } = rangeOf(period);
  for (const p of projects.filter((x) => (x.state || "active") === "active" && (!x.started_on || x.started_on <= end))) {
    const r = reports.find((x) => x.project_id === p._id && x.period === period);
    const state = reportState(r);
    if (state === "sent" || state === "missing" && p.demo) continue;
    const said2 = { missing: "is not prepared yet: reports_draft", draft: "has no summary yet: reports_draft, then reports_write", written: "is written: the person reviews it", reviewed: "is reviewed: the person sends it to the client and marks it sent" }[state];
    items.push({ kind: "report", whose: state === "missing" || state === "draft" ? "agent" : "person", key: `report:${p._id}:${period}`, id: r?._id ?? null, project_id: p._id, project: p.name, period, state, text: `${p.name}: the report of ${period} ${said2}.` });
  }
  const byWorker = /* @__PURE__ */ new Map();
  for (const h of hours2.filter((x) => (x.state || "pendent") === "pendent")) {
    const w = byWorker.get(h.worker) ?? { worker: h.worker, lines: 0, hours: 0, from: h.day, to: h.day };
    w.lines += 1;
    w.hours += Number(h.hours || 0);
    if (h.day < w.from) w.from = h.day;
    if (h.day > w.to) w.to = h.day;
    byWorker.set(h.worker, w);
  }
  for (const w of [...byWorker.values()].sort((a, b) => b.hours - a.hours))
    items.push({ kind: "hours", whose: "person", key: "hours:" + w.worker, worker: w.worker, lines: w.lines, hours: r2(w.hours), from: w.from, to: w.to, text: `${w.worker}: ${w.lines} line${w.lines === 1 ? "" : "s"} of hours to validate (${r2(w.hours)} h, ${w.from} to ${w.to}).` });
  const byClient = /* @__PURE__ */ new Map();
  for (const j of jobs2.filter((x) => (x.billable === null || x.billable === void 0 || x.billable) && (x.state || "pendent") === "pendent")) {
    const k = j.client || "\u2014";
    const c = byClient.get(k) ?? { client: k, lines: 0, total: 0 };
    c.lines += 1;
    c.total += Number(j.total || 0);
    byClient.set(k, c);
  }
  for (const c of [...byClient.values()].sort((a, b) => b.total - a.total))
    items.push({ kind: "jobs", whose: "person", key: "jobs:" + c.client, client: c.client, lines: c.lines, total: c.total / 100, text: `${c.client}: ${c.lines} job${c.lines === 1 ? "" : "s"} to invoice (${c.total / 100} \u20AC).` });
  const n = (k) => items.filter((x) => x.kind === k).length;
  const sum = (k, f) => r2(items.filter((x) => x.kind === k).reduce((a, x) => a + Number(x[f] || 0), 0));
  return { items, counts: { severe: n("severe"), late: n("late"), procedures: n("procedure"), reports: n("report"), hours_lines: sum("hours", "lines"), hours: sum("hours", "hours"), jobs_lines: sum("jobs", "lines"), jobs_total: sum("jobs", "total") } };
}
var reportState = (r) => !r ? "missing" : r.sent_on ? "sent" : r.state === "reviewed" ? "reviewed" : r.summary && String(r.summary).trim() ? "written" : "draft";
async function rowsFor(db, projectId = null) {
  const scope = projectId ? "project_id = ?" : `project_id IN (SELECT _id FROM ${T.projects} WHERE ${LIVE} AND COALESCE(state, 'active') != 'archived')`;
  const params = projectId ? [projectId] : [];
  return {
    projects: await db.all(`SELECT * FROM ${T.projects} WHERE ${LIVE} AND COALESCE(state, 'active') != 'archived'${projectId ? " AND _id = ?" : ""}`, params),
    incidents: await db.all(`SELECT * FROM ${T.incidents} WHERE ${LIVE} AND closed_on IS NULL AND ${scope}`, params),
    procedures: await db.all(`SELECT * FROM ${T.procedures} WHERE ${LIVE} AND ${scope}`, params),
    reports: await db.all(`SELECT * FROM ${T.reports} WHERE ${LIVE} AND ${scope}`, params),
    hours: await db.all(`SELECT worker, day, hours, state FROM ${T.hours} WHERE ${LIVE} AND COALESCE(state, 'pendent') = 'pendent'${projectId ? " AND project_id = ?" : ""}`, params),
    jobs: await db.all(`SELECT client, total, state, billable FROM ${T.jobs} WHERE ${LIVE} AND COALESCE(state, 'pendent') = 'pendent'${projectId ? " AND project_id = ?" : ""}`, params)
  };
}
async function pending(db, i, full, now) {
  const day = today(now);
  const period = previousPeriod(day);
  const rows = await rowsFor(db);
  const { items, counts } = attention({ day, period, ...rows });
  const { rows: list6 } = await list(db);
  const late = /* @__PURE__ */ new Map();
  for (const r of rows.incidents) if (delayOf(r, day) > 0) late.set(r.project_id, (late.get(r.project_id) ?? 0) + 1);
  const procLate = /* @__PURE__ */ new Map();
  for (const p of rows.procedures) if ((p.state || "pending") !== "done" && (p.state === "blocked" || p.next_on && p.next_on < day)) procLate.set(p.project_id, (procLate.get(p.project_id) ?? 0) + 1);
  const last = Object.fromEntries((await db.all(`SELECT project_id, MAX(day) AS day FROM ${T.visits} WHERE ${LIVE} GROUP BY project_id`)).map((v) => [v.project_id, v.day]));
  const projects = list6.filter((p) => p.state !== "archived").map((p) => ({
    id: p.id,
    name: p.name,
    ...p.code ? { code: p.code } : {},
    ...p.demo ? { example: true } : {},
    ...p.state !== "active" ? { state: p.state } : {},
    open: p.open,
    greu: p.greu,
    late: late.get(p.id) ?? 0,
    procedures_open: p.procedures_open,
    procedures_stuck: procLate.get(p.id) ?? 0,
    last_visit: last[p.id] ?? null,
    ...full ? { important: p.important, lleu: p.lleu, client: p.client, address: p.address, city: p.city, demo: !!p.demo } : {}
  }));
  if (full) return { today: day, period, counts, items, projects };
  const limit = 12;
  return {
    today: day,
    counts,
    items: items.slice(0, limit).map((x) => ({ kind: x.kind, ...x.id ? { id: x.id } : {}, ...x.project_id ? { project_id: x.project_id } : {}, ...x.whose === "agent" ? { yours: true } : {}, text: x.text })),
    ...items.length > limit ? { more: `${items.length - limit} more: project_status { project } for one project's, hours and jobs for those.` } : {},
    projects,
    ...projects.length ? {} : { next: "No project yet: project_add { name, address, city, client, units: [{ kind, count }] }." }
  };
}
async function projectStatus(db, i, full, now) {
  const p = await projectBy(db, i);
  const day = today(now);
  const period = previousPeriod(day);
  const chapters = await chaptersOf(db, p._id);
  const all = await db.all(`SELECT * FROM ${T.incidents} WHERE project_id = ? AND ${LIVE}`, [p._id]);
  const open = all.filter((r) => !r.closed_on).sort((a, b) => (RANK2[a.severity] ?? 3) - (RANK2[b.severity] ?? 3) || delayOf(b, day) - delayOf(a, day) || String(a.started_on).localeCompare(String(b.started_on)));
  const n = (s) => open.filter((r) => r.severity === s).length;
  const byChapter = chapters.filter((c) => !c.parent).map((c) => {
    const mine = open.filter((r) => r.chapter === c.code);
    return { code: c.code, name: c.name, open: mine.length, greu: mine.filter((r) => r.severity === "greu").length };
  }).filter((c) => c.open);
  const none = open.filter((r) => !r.chapter).length;
  const withCost = all.filter((r) => r.cost_estimated !== null && r.cost_estimated !== void 0 || r.cost_real !== null && r.cost_real !== void 0);
  const money = (list6, k) => euros(list6.reduce((a, r) => a + Number(r[k] || 0), 0));
  const procs = await db.all(`SELECT * FROM ${T.procedures} WHERE project_id = ? AND ${LIVE}`, [p._id]);
  const under = procs.filter((x) => (x.state || "pending") !== "done").sort((a, b) => (a.state === "blocked" ? 0 : 1) - (b.state === "blocked" ? 0 : 1) || String(a.next_on || "9").localeCompare(String(b.next_on || "9")));
  const stuck = under.filter((x) => x.state === "blocked" || x.next_on && x.next_on < day);
  const visits2 = (await visits(db, { project_id: p._id })).rows;
  const units = await db.all(`SELECT kind, state FROM ${T.units} WHERE project_id = ? AND ${LIVE}`, [p._id]);
  const month = day.slice(0, 7);
  const hrs = await db.all(`SELECT hours, state FROM ${T.hours} WHERE project_id = ? AND ${LIVE} AND day >= ? AND COALESCE(state, 'pendent') != 'rebutjat'`, [p._id, `${month}-01`]);
  const report = await db.one(`SELECT * FROM ${T.reports} WHERE project_id = ? AND period = ? AND ${LIVE}`, [p._id, period]);
  const rows = await rowsFor(db, p._id);
  const waiting = attention({ day, period, ...rows, projects: [p] }).items;
  const out = {
    id: p._id,
    name: p.name,
    ...p.code ? { code: p.code } : {},
    ...p.demo ? { example: true } : {},
    state: p.state || "active",
    client: p.client || "",
    address: [p.address, p.city].filter(Boolean).join(", "),
    today: day,
    incidents: {
      open: open.length,
      greu: n("greu"),
      important: n("important"),
      lleu: n("lleu"),
      late: open.filter((r) => delayOf(r, day) > 0).length,
      closed: all.length - open.length,
      by_chapter: full ? [...byChapter, ...none ? [{ code: "", name: "", open: none, greu: 0 }] : []] : byChapter.map((c) => `${c.code} ${c.name}: ${c.open}${c.greu ? ` (${c.greu} greu)` : ""}`),
      rows: open.slice(0, 6).map((r) => line(r, day, full ? 200 : 60)),
      ...open.length > 6 && !full ? { more: "incidents { project_id } lists them all." } : {}
    },
    procedures: {
      under_way: under.length,
      stuck: stuck.length,
      done: procs.length - under.length,
      rows: under.slice(0, 6).map((x) => ({ id: x._id, title: x.title, state: x.state || "pending", ...x.next_step ? { next_step: String(x.next_step).slice(0, 90) } : {}, ...x.next_on ? { next_on: x.next_on } : {}, ...x.next_on && x.next_on < day ? { late: true } : {} }))
    },
    visits: { total: visits2.length, ...visits2[0] ? { last: visits2[0].day, days_since: daysBetween(visits2[0].day, day) } : {}, rows: visits2.slice(0, 3).map((v) => ({ id: v.id, day: v.day, incidents: v.incidents, open: v.open })) },
    extra_costs: { count: withCost.length, estimated: money(withCost, "cost_estimated"), real: money(withCost, "cost_real"), approved: withCost.filter((r) => r.cost_approved_on).length, certified: withCost.filter((r) => r.cost_certified).length, invoiced: withCost.filter((r) => r.cost_invoiced).length, paid: withCost.filter((r) => r.cost_paid).length },
    units: { total: units.length, sold: units.filter((u) => u.state === "sold").length, reserved: units.filter((u) => u.state === "reserved").length },
    hours_this_month: { hours: r2(hrs.reduce((a, h) => a + Number(h.hours || 0), 0)), to_validate: hrs.filter((h) => (h.state || "pendent") === "pendent").length },
    report: { period, state: reportState(report), ...report ? { id: report._id } : {} }
  };
  if (full) return { ...out, waiting };
  return { ...out, waiting: waiting.filter((x) => x.kind === "procedure" || x.kind === "report" || x.kind === "hours").slice(0, 6).map((x) => x.text) };
}
async function visitPrepare(db, i, full, now) {
  const p = await projectBy(db, i);
  const day = dateOf(i.day, "day") ?? today(now);
  const chapters = await chaptersOf(db, p._id);
  const open = (await db.all(`SELECT * FROM ${T.incidents} WHERE project_id = ? AND ${LIVE} AND closed_on IS NULL`, [p._id])).sort((a, b) => plain3(a.location || "zz").localeCompare(plain3(b.location || "zz")) || (RANK2[a.severity] ?? 3) - (RANK2[b.severity] ?? 3));
  const visits2 = (await visits(db, { project_id: p._id })).rows;
  const todays = visits2.find((v) => v.day === day);
  const last = visits2.find((v) => v.day < day);
  const found = todays ? await db.all(`SELECT * FROM ${T.incidents} WHERE visit_id = ? AND ${LIVE} ORDER BY _id DESC`, [todays.id]) : [];
  const limit = full ? 500 : 25;
  return {
    project_id: p._id,
    project: p.name,
    day,
    ...todays ? { visit_today: { id: todays.id, incidents: todays.incidents, ...full ? { attendees: todays.attendees, summary: todays.summary, rows: found.map((r) => ({ ...line(r, day, 200), closed_on: r.closed_on || null })) } : {} } } : {},
    ...last ? { last_visit: { id: last.id, day: last.day, found: last.incidents, still_open: last.open } } : {},
    open: { total: open.length, rows: open.slice(0, limit).map((r) => ({ ...line(r, day, full ? 200 : 50), ...full ? { responsible: r.responsible || "", started_on: r.started_on, due_on: r.due_on || null } : {} })), ...open.length > limit ? { more: `Only the first ${limit}: incidents { project_id: ${p._id}, offset } for the rest.` } : {} },
    chapters: full ? chapters : chapterTree(chapters).map((c) => `${c.code} ${c.name}${c.subs.length ? ` (${c.subs.map((s) => s.code).join(" ")})` : ""}`),
    ...full ? {} : { then: "After the visit, ONE visit_record { project_id, day, attendees, summary, found: [{ title, description, chapter, location, severity, responsible, due_on, photos: [{ name, path }] }], closed: [{ ref, note }], notes: [{ ref, text }] }." }
  };
}
async function visitRecord(db, i, actor, now) {
  const p = await projectBy(db, i);
  const found = i.found === void 0 || i.found === null ? [] : listOf(i.found, "found");
  const closed = i.closed === void 0 || i.closed === null ? [] : listOf(i.closed, "closed");
  const notes = i.notes === void 0 || i.notes === null ? [] : listOf(i.notes, "notes");
  const visit2 = await visitAdd(db, { project_id: p._id, day: i.day, attendees: i.attendees, summary: i.summary }, now);
  const skipped = [];
  const skip3 = (where, list6) => {
    for (const s of list6) skipped.push({ in: where, index: s.index ?? null, code: s.code, why: s.why, ...s.item !== void 0 ? { item: s.item } : {} });
  };
  let added = [];
  let photos = 0;
  if (found.length) {
    const r = await addMany(db, { project_id: p._id, visit_id: visit2.id, items: found }, actor, now);
    added = r.added;
    skip3("found", r.skipped);
    const out = new Set(r.skipped.map((s) => s.index));
    const kept = found.map((it, index) => ({ it, index })).filter((x) => !out.has(x.index));
    const files = kept.flatMap(({ it }, k) => (Array.isArray(it?.photos) ? it.photos : []).map((f) => ({ ...typeof f === "string" ? { path: f } : f, incident_id: added[k].id, kind: f?.kind ?? "photo" })));
    if (files.length) {
      const a = await add2(db, { items: files });
      photos = a.added.length;
      skip3("photos", a.skipped);
    }
  }
  const one5 = (x) => x && typeof x === "object" ? { id: x.id ?? x.incident_id, ref: x.ref, project_id: p._id } : /^\d+$/.test(String(x)) ? { id: Number(x) } : { ref: String(x), project_id: p._id };
  let done = [];
  if (closed.length) {
    const r = await updateMany(db, { items: closed.map((x) => ({ ...one5(x), closed_on: visit2.day, ...x?.note ? { note: x.note, note_day: visit2.day } : {} })) }, actor, now);
    done = r.changed;
    skip3("closed", r.skipped);
  }
  let said2 = 0;
  if (notes.length) {
    const r = await notesAdd(db, { items: notes.map((x) => ({ ...one5(x), incident_id: x?.id ?? x?.incident_id, text: x?.text ?? x?.note, day: visit2.day })) }, actor, now);
    said2 = r.added;
    skip3("notes", r.skipped);
  }
  return { project_id: p._id, visit_id: visit2.id, day: visit2.day, ...visit2.existed ? { existed: true } : {}, added, closed: done, notes: said2, photos, skipped };
}
var PERIOD2 = /^\d{4}-(0[1-9]|1[0-2])$/;
var periodOf = (v, now) => {
  const period = v ? String(v).trim() : previousPeriod(today(now));
  if (!PERIOD2.test(period)) throw new Refused(`period is a month written YYYY-MM (got "${String(v).slice(0, 20)}").`, 400, { code: "BAD_PERIOD" });
  return period;
};
async function monthRows(db, period) {
  const { end } = rangeOf(period);
  const reports = await db.all(`SELECT * FROM ${T.reports} WHERE period = ? AND ${LIVE}`, [period]);
  const projects = await db.all(`SELECT * FROM ${T.projects} WHERE ${LIVE} ORDER BY _id DESC`);
  return projects.filter((p) => reports.some((r) => r.project_id === p._id) || (p.state || "active") === "active" && (!p.started_on || p.started_on <= end)).map((p) => {
    const r = reports.find((x) => x.project_id === p._id);
    return { project_id: p._id, project: p.name, ...p.demo ? { example: true } : {}, state: reportState(r), ...r ? { id: r._id, ...r.reviewed_on ? { reviewed_on: r.reviewed_on } : {}, ...r.sent_on ? { sent_on: r.sent_on } : {} } : {} };
  });
}
async function monthClose(db, i, now) {
  const period = periodOf(i.period, now);
  const rows = await monthRows(db, period);
  const counts = {};
  for (const r of rows) counts[r.state] = (counts[r.state] ?? 0) + 1;
  return { period, counts, rows };
}
async function reportsDraft(db, i, now) {
  const period = periodOf(i.period, now);
  const ids = i.project_ids === void 0 || i.project_ids === null ? null : listOf(i.project_ids, "project_ids").map(Number);
  const chosen = i.project || i.project_id ? [(await projectBy(db, i))._id] : ids;
  const rows = (await monthRows(db, period)).filter((r) => chosen ? chosen.includes(r.project_id) : !r.example);
  const todo = rows.filter((r) => r.state === "missing" || r.state === "draft");
  const limit = 4;
  const reports = [];
  for (const r of todo.slice(0, limit)) {
    const d = await draft(db, { project_id: r.project_id, period, language: i.language }, now);
    reports.push({ id: d.id, project_id: d.project_id, project: d.project, language: d.language, figures: d.figures });
  }
  return {
    period,
    reports,
    ...todo.length > limit ? { more: `${todo.length - limit} more to write: call reports_draft again after writing these.` } : {},
    ...rows.length > todo.length ? { already: rows.filter((r) => r.state !== "missing" && r.state !== "draft").map((r) => ({ project: r.project, state: r.state })) } : {},
    write: reports.length ? "Write each one's two texts in ITS language (ca = catal\xE0, es = castellano) with ONE reports_write { items: [{ id, summary, outlook }] }: summary = the month in 5 to 8 lines for the client (what happened, what is serious, what it costs, what was solved); outlook = what comes next month. Only what its figures say. Then tell the person they are ready to review, in Informes." : "Nothing to write for that month."
  };
}
async function reportsWrite(db, i, now) {
  const written = [];
  const skipped = [];
  for (const [index, it] of listOf(i.items, "items").entries()) {
    try {
      let id = it?.id;
      if (!id) {
        const p = await projectBy(db, it ?? {});
        const period = periodOf(it.period ?? i.period, now);
        id = (await db.one(`SELECT _id FROM ${T.reports} WHERE project_id = ? AND period = ? AND ${LIVE}`, [p._id, period]))?._id ?? (await draft(db, { project_id: p._id, period }, now)).id;
      }
      written.push((await write(db, { id, summary: it.summary, outlook: it.outlook, language: it.language })).id);
    } catch (e) {
      if (!(e instanceof Refused)) throw e;
      skipped.push({ index, code: e.code, why: e.message, ...e.item !== void 0 ? { item: e.item } : {} });
    }
  }
  return { written, skipped };
}

// server/services/participants.mjs
var same2 = (s) => String(s ?? "").trim().toLowerCase();
var round = (n) => Math.round(Number(n || 0) * 100) / 100;
function groupOf(kind, type = "company") {
  const k = same2(kind).normalize("NFD").replace(/[̀-ͯ]/g, "");
  if (/client|promotor|propiet|inversor|owner|comunitat|comunidad/.test(k)) return "promoter";
  if (/constructor|contratista|contractista|builder/.test(k)) return "builder";
  if (/industrial|subcontrat|instal|gremi/.test(k)) return "subcontractor";
  if (/proveidor|proveedor|supplier|subministr|suministr/.test(k)) return "supplier";
  if (/tecnic|arquitect|aparellador|enginy|ingenier|direccio|direccion|facultativ|\bdf\b|estructur|coordinador/.test(k)) return "technical";
  if (/operari|oficial|peo|peon|encarregat|encargado|worker|treballador|trabajador/.test(k)) return "worker";
  return type === "person" ? k ? "other" : "worker" : "other";
}
async function read(db, now) {
  const day = today(now);
  const month = [`${day.slice(0, 7)}-01`, day];
  const [companies2, people2, projects, incidents, hours2, jobs2] = await Promise.all([
    db.all(`SELECT * FROM ${T.companies} WHERE ${LIVE} ORDER BY lower(name)`),
    db.all(`SELECT * FROM ${T.people} WHERE ${LIVE} ORDER BY lower(name)`),
    db.all(`SELECT _id, name, client, responsible, state FROM ${T.projects} WHERE ${LIVE}`),
    db.all(`SELECT _id, project_id, ref, title, severity, responsible, due_on, location FROM ${T.incidents} WHERE ${LIVE} AND closed_on IS NULL`),
    db.all(`SELECT project_id, worker, company, hours, state, paid, day FROM ${T.hours} WHERE ${LIVE} AND COALESCE(state, 'pendent') != 'rebutjat'`),
    db.all(`SELECT project_id, worker, client, total, hours, rate, state, billable FROM ${T.jobs} WHERE ${LIVE}`)
  ]);
  const by = /* @__PURE__ */ new Map();
  const of = (name) => {
    const k = same2(name);
    if (!k) return null;
    if (!by.has(k)) by.set(k, { name: String(name).trim(), projects: /* @__PURE__ */ new Set(), incidents: [], hours_month: 0, hours_pending: 0, hours_unpaid: 0, done: { lines: 0, hours: 0 }, billed: { lines: 0, to_invoice: 0, invoiced: 0, paid: 0 }, as: /* @__PURE__ */ new Set() });
    return by.get(k);
  };
  const company = Object.fromEntries(people2.map((p) => [same2(p.name), p.company || ""]));
  for (const p of projects) {
    const c = of(p.client);
    if (c) {
      c.projects.add(p._id);
      c.as.add("promoter");
    }
    const r = of(p.responsible);
    if (r) {
      r.projects.add(p._id);
      r.as.add("technical");
    }
  }
  for (const x of incidents) {
    const r = of(x.responsible);
    if (r) {
      r.projects.add(x.project_id);
      r.incidents.push(x);
    }
  }
  for (const h of hours2) {
    for (const [who2, role] of [[h.worker, "worker"], [h.company || company[same2(h.worker)], null]]) {
      const w = of(who2);
      if (!w) continue;
      if (role) w.as.add(role);
      if (h.project_id) w.projects.add(h.project_id);
      if (h.day >= month[0] && h.day <= month[1]) w.hours_month += Number(h.hours || 0);
      if ((h.state || "pendent") === "pendent") w.hours_pending += Number(h.hours || 0);
      if (!h.paid) w.hours_unpaid += Number(h.hours || 0);
    }
  }
  for (const j of jobs2) {
    const total = Number(j.total ?? totalOf(j.hours, j.rate) ?? 0) / 100;
    for (const who2 of [j.worker, company[same2(j.worker)]]) {
      const w = of(who2);
      if (!w) continue;
      if (j.project_id) w.projects.add(j.project_id);
      w.done.lines += 1;
      w.done.hours += Number(j.hours || 0);
    }
    const c = of(j.client);
    if (c) {
      c.as.add("promoter");
      if (j.project_id) c.projects.add(j.project_id);
      c.billed.lines += 1;
      if (j.billable === 0) continue;
      const st = j.state || "pendent";
      c.billed[st === "cobrat" ? "paid" : st === "facturat" ? "invoiced" : "to_invoice"] += Number(total || 0);
    }
  }
  return { companies: companies2, people: people2, projects, by };
}
function row(type, r, seen, staff) {
  const s = seen ?? { projects: /* @__PURE__ */ new Set(), incidents: [], hours_month: 0, hours_pending: 0, hours_unpaid: 0, done: { lines: 0, hours: 0 }, billed: { lines: 0, to_invoice: 0, invoiced: 0, paid: 0 }, as: /* @__PURE__ */ new Set() };
  const kind = type === "person" ? r.kind || r.role || "" : r.kind || "";
  const guessed = groupOf(type === "person" ? `${r.kind || ""} ${r.role || ""}` : kind, type);
  return {
    type,
    id: r._id ?? null,
    name: r.name,
    kind,
    group: guessed === "other" && s.as.size ? [...s.as][0] : guessed,
    ...type === "person" ? { role: r.role || "", company: r.company || "", area: r.area || "" } : { contact: r.contact || "", people: staff ?? 0 },
    email: r.email || "",
    phone: r.phone || "",
    notes: r.notes || "",
    active: r.active === null || r.active === void 0 ? true : !!r.active,
    ...r._id ? {} : { unlisted: true },
    projects: [...s.projects],
    incidents_open: s.incidents.length,
    hours_month: round(s.hours_month),
    hours_pending: round(s.hours_pending),
    hours_unpaid: round(s.hours_unpaid),
    jobs_done: { lines: s.done.lines, hours: round(s.done.hours) },
    jobs_billed: { lines: s.billed.lines, to_invoice: round(s.billed.to_invoice), invoiced: round(s.billed.invoiced), paid: round(s.billed.paid) }
  };
}
async function list5(db, i, full, now) {
  const { companies: companies2, people: people2, projects, by } = await read(db, now);
  const listed = new Set([...companies2, ...people2].map((r) => same2(r.name)));
  const rows = [
    ...companies2.map((c) => row("company", c, by.get(same2(c.name)), people2.filter((p) => same2(p.company) === same2(c.name)).length)),
    ...people2.map((p) => row("person", p, by.get(same2(p.name)))),
    // a name the works use that has no card: a company unless it only ever worked hours or jobs
    ...[...by.entries()].filter(([k]) => !listed.has(k)).map(([, s]) => row(s.as.has("worker") && !s.as.has("promoter") ? "person" : "company", { name: s.name }, s))
  ];
  const live = new Set(projects.map((p) => p._id));
  const pid = Number(i.project_id) || null;
  const q = same2(i.q);
  const out = rows.map((r) => ({ ...r, projects: r.projects.filter((p) => live.has(p)) })).filter((r) => (!pid || r.projects.includes(pid)) && (!i.group || r.group === i.group) && (!q || [r.name, r.kind, r.role, r.company, r.contact].some((x) => same2(x).includes(q))));
  const groups = {};
  for (const r of out) groups[r.group] = (groups[r.group] ?? 0) + 1;
  if (full) return { total: out.length, groups, rows: out };
  const name = Object.fromEntries(projects.map((p) => [p._id, p.name]));
  const brief2 = (r) => Object.fromEntries(Object.entries({ type: r.type, id: r.id, name: r.name, group: r.group, kind: r.kind, company: r.company, projects: r.projects.map((p) => name[p]), incidents_open: r.incidents_open, hours_month: r.hours_month, to_invoice: r.jobs_billed.to_invoice, unlisted: r.unlisted }).filter(([k, v]) => k === "name" || v !== "" && v !== 0 && v !== null && v !== void 0 && !(Array.isArray(v) && !v.length)));
  return { total: out.length, groups, rows: out.slice(0, 40).map(brief2), ...out.length > 40 ? { more: "Only the first 40: narrow with project_id, group or q." } : {} };
}
async function one4(db, i, now) {
  const all = (await list5(db, {}, true, now)).rows;
  const r = i.id ? all.find((x) => x.type === (i.type === "person" ? "person" : "company") && x.id === Number(i.id)) : all.find((x) => same2(x.name) === same2(i.name));
  if (!r) throw new Refused("Nobody of the works is called that: list them with participants.", 404, { code: "NOT_FOUND" });
  const names2 = Object.fromEntries((await db.all(`SELECT _id, name FROM ${T.projects} WHERE ${LIVE}`)).map((p) => [p._id, p.name]));
  const incidents = await db.all(`SELECT _id, project_id, ref, title, severity, due_on, location FROM ${T.incidents} WHERE ${LIVE} AND closed_on IS NULL AND lower(COALESCE(responsible, '')) = lower(?) ORDER BY CASE severity WHEN 'greu' THEN 0 WHEN 'important' THEN 1 ELSE 2 END, due_on`, [r.name]);
  return {
    ...r,
    projects: r.projects.map((id) => ({ id, name: names2[id] })),
    incidents: incidents.map((x) => ({ id: x._id, project_id: x.project_id, ref: x.ref, title: x.title, severity: x.severity || "lleu", due_on: x.due_on || null, location: x.location || "" })),
    ...r.type === "company" ? { staff: all.filter((p) => p.type === "person" && same2(p.company) === same2(r.name)).map((p) => ({ id: p.id, name: p.name, role: p.role, phone: p.phone, email: p.email, hours_month: p.hours_month })) } : {}
  };
}

// server/routes/obras.mjs
var CARD = { title: "a few words", description: "text", chapter: 'code or name: "03", "03/E", "Estructura"', subchapter: "code or name", location: 'where: "2n 1a, bany"', severity: "lleu | important | greu", responsible: "who must solve it", reported_by: "who found it", started_on: "YYYY-MM-DD", due_on: "YYYY-MM-DD it should be solved by", expected_delay_days: "days of delay it may cause", delay_days: "days of delay it causes today (by hand; else counted from due_on)", closed_on: "YYYY-MM-DD, or null to reopen", state: "oberta | en_curs | pendent | tancada (tancada closes it today)", remarks: "text (observacions)", cost_estimated: "euros", cost_real: "euros", cost_approved_on: "YYYY-MM-DD", cost_certified: "boolean", cost_invoiced: "boolean", cost_paid: "boolean", ref: "its reference, when it has one already" };
function obras_default(app, db, deps = {}) {
  const now = () => deps.now ? deps.now() : /* @__PURE__ */ new Date();
  const command2 = (a, method, path, spec, handler) => command(a, method, path, spec, async (i, ctx) => {
    const out = await handler(i, ctx);
    return isPerson(ctx.actor) ? out : marked(out, await present(db));
  });
  const BY_NAME = 'a piece of its name or its code ("roure", "R21"), instead of project_id';
  command2(app, "GET", "/pending", { name: "pending", summary: "What waits across every project, in order, and every project in a line: START HERE. Severe and late incidents, stuck procedures, reports, hours to validate, jobs to invoice.", input: { full: "true for every line whole" } }, (i, { actor }) => pending(db, i, wantsFull(i, actor), now()));
  command2(app, "GET", "/status", { name: "project_status", summary: "How ONE project stands, in one read: incidents (counts, by chapter, worst first), procedures, last visits, extra costs, units, hours, last month's report.", input: { project_id: "project id", project: BY_NAME, full: "true for a screen" } }, (i, { actor }) => projectStatus(db, i, wantsFull(i, actor), now()));
  command2(app, "GET", "/visit/prepare", { name: "visit_prepare", summary: "Before a site visit, in one read: what is open in that project by where it is, its chapters, the last visit and today's if there is one.", input: { project_id: "project id", project: BY_NAME, day: "YYYY-MM-DD, today unless said", full: "true for a screen" } }, (i, { actor }) => visitPrepare(db, i, wantsFull(i, actor), now()));
  command2(app, "POST", "/visit/record", { name: "visit_record", summary: "A whole site visit in ONE call: found [{ title, description, chapter, location, severity, responsible, due_on, cost_estimated, photos: [{ name, path }] }] are new incidents under that day's visit; closed [{ id or ref, note }] were seen solved; notes [{ id or ref, text }] are follow-up. Sent twice, nothing is added twice. Answers { visit_id, added: [{ id, ref }], closed, notes, photos, skipped }.", input: { project_id: "project id", project: BY_NAME, day: "YYYY-MM-DD, today unless said", attendees: "who was there", summary: "the visit in a few lines", found: "list of new incidents", closed: "list of { id or ref, note }", notes: "list of { id or ref, text }" } }, (i, { actor }) => visitRecord(db, i, actor, now()));
  command2(app, "GET", "/month", { name: "reports_month", summary: "Where each project's report of a month stands (last month unless period): missing, draft, written, reviewed, sent.", input: { period: "YYYY-MM" } }, (i) => monthClose(db, i, now()));
  command2(app, "POST", "/reports/draft-all", { name: "reports_draft", summary: "Makes the month's report of every project that lacks it and answers each one still to write in figures: all in one call. period (last month unless said); project or project_ids for some only.", input: { period: "YYYY-MM", project_id: "project id", project: BY_NAME, project_ids: "list of project ids", language: "ca | es (the setting unless said)" } }, (i) => reportsDraft(db, i, now()));
  command2(app, "POST", "/reports/write-all", { name: "reports_write", summary: "Writes the texts of several reports in one call: items [{ id (or project + period), summary, outlook }]. Answers { written, skipped }; a reviewed one is skipped (ALREADY_REVIEWED).", input: { items: "list of { id, summary, outlook }", period: "YYYY-MM, for items named by project" } }, (i) => reportsWrite(db, i, now()));
  command2(app, "GET", "/trend", { name: "incidents_trend", summary: "Incidents week by week, for a chart: opened, closed and how many stood open at each week's end. weeks (12 unless said); project_id for one project.", input: { project_id: "project id", project: BY_NAME, weeks: "number, 4 to 52" } }, async (i) => trend(db, await named(db, i), now()));
  command2(app, "GET", "/week", { name: "week", summary: "What moved in the last days: incidents opened and closed, notes, visits, procedures done. days (7 unless said); project_id for one project.", input: { project_id: "project id", project: BY_NAME, days: "number, 1 to 92" } }, async (i) => week(db, await named(db, i), now()));
  command2(app, "GET", "/projects", { name: "projects", of: "project", summary: "The projects (obras), each with its code, group, client and how much is open. state: active | finished | archived.", input: { state: "active | finished | archived" } }, (i) => list(db, i));
  command2(app, "GET", "/projects/:id", { name: "project", on: "project", summary: "One project: its card, its units counted by kind and its chapters with their sub-chapter codes. full=true lists every unit and chapter.", input: { full: "true for every unit and chapter" } }, (i, { actor }) => detail(db, i, wantsFull(i, actor)));
  command2(app, "POST", "/projects", { name: "project_add", summary: "A new project with the default chapters 01\u201309 and, if given, its units. units: [{ kind: habitatge | local | aparcament | traster | altre, count }] or [{ kind, name }]. copy_chapters_from: another project's id.", input: { name: "text", code: "short code", group: "the group it belongs to", kind: "what kind of project", responsible: "who runs it", color: "its colour, like #B7AD98", address: "text", city: "postcode and town", client: "the client who hired you to manage it (promoter, investor, owner)", started_on: "YYYY-MM-DD", ends_on: "YYYY-MM-DD it is expected to end", notes: "text", units: "list", copy_chapters_from: "project id" } }, (i) => add(db, i, { now: now() }));
  command2(app, "POST", "/projects/:id", { name: "project_update", on: "project", summary: "Changes a project's card: only the fields sent. state: active | finished | archived.", input: { name: "text", code: "text", group: "text", kind: "text", responsible: "text", color: "text", address: "text", city: "text", client: "text", started_on: "YYYY-MM-DD", ends_on: "YYYY-MM-DD it is expected to end", notes: "text", state: "active | finished | archived", cover_id: "attachment id of the photo on the report's cover" } }, (i) => update(db, i));
  command2(app, "POST", "/projects/:id/archive", { name: "project_archive", on: "project", by: "person", confirm: true, label: { es: "Archivar", en: "Archive" }, summary: "Archives a project: nothing is lost, it stops showing among the active ones. A person's decision." }, (i) => archive(db, i));
  command2(app, "POST", "/units", { name: "units_add", summary: "Adds units to a project in one call: units [{ kind, count }] (\xABHabitatge 1\xBB\u2026) or [{ kind, name, state }]. state: available | reserved | sold.", input: { project_id: "project id", project: BY_NAME, units: "list" } }, async (i) => unitsAdd(db, await named(db, i)));
  command2(app, "POST", "/units/update", { name: "units_update", summary: "Changes several units in one call: units [{ id, name?, kind?, state?, remove? }]. Answers { changed, skipped }.", input: { units: "list" } }, (i) => unitsUpdate(db, i));
  command2(app, "POST", "/chapters", { name: "chapters_set", summary: `Replaces a project's chapters, whole. chapters: [{ code, name, parent }] (parent "" for a chapter) or lines of text ("03 Execuci\xF3", "03/E Estructura"). A chapter in use cannot leave.`, input: { project_id: "project id", chapters: "list, or text with one per line" } }, (i) => chaptersSet(db, i));
  command2(app, "GET", "/incidents", { name: "incidents", of: "incident", summary: "The incidents: open ones unless said, worst first \u2014 figures by severity and chapter, then rows. state: open | closed | all, or one of oberta, en_curs, pendent, tancada; project_id, chapter, severity, visit_id, since (YYYY-MM-DD), q; limit/offset; full=true every row whole.", input: { project_id: "project id", project: BY_NAME, state: "open | closed | all | oberta | en_curs | pendent | tancada", chapter: "chapter code", severity: "lleu | important | greu", visit_id: "visit id", since: "YYYY-MM-DD: started on or after", q: "words of its title, ref or location", limit: "rows, 15 unless said (50 at most)", offset: "rows to skip", full: "true for every row whole" } }, async (i, { actor }) => list2(db, await named(db, i), wantsFull(i, actor), now()));
  command2(app, "GET", "/incidents/:id", { name: "incident", on: "incident", summary: "One incident whole: its card, its extra cost, its follow-up notes and the names of what is attached." }, (i) => one(db, i, now()));
  command2(app, "POST", "/incidents", { name: "incidents_add", summary: "Adds MANY incidents in one call \u2014 what a site visit found. items: [{ title, description, chapter, location, severity, responsible, \u2026 }]; visit: { day, attendees, summary } groups them under that day's visit. Sent twice, nothing is added twice. Answers { added: [{ id, ref }], visit_id, skipped }.", input: { project_id: "project id", project: BY_NAME, visit_id: "an existing visit", visit: "{ day, attendees, summary }: makes or finds the visit of that day", items: `list of { ${Object.keys(CARD).filter((k) => !["closed_on", "delay_days"].includes(k)).join(", ")}, note }` } }, async (i, { actor }) => addMany(db, await named(db, i), actor, now()));
  command2(app, "POST", "/incidents/update", { name: "incidents_update", summary: "Changes several incidents in one call: items [{ id (or ref + project_id), \u2026only what changes, note? }]. Closing one is its closed_on; null reopens it. Answers { changed, skipped }.", input: { items: `list of { id, ${Object.keys(CARD).join(", ")}, note }` } }, (i, { actor }) => updateMany(db, i, actor, now()));
  command2(app, "POST", "/incidents/close", { name: "incidents_close", summary: "Closes several incidents on one date (today unless said), with one line of how it ended in each one's history. ids, closed_on, note.", input: { ids: "list of incident ids", closed_on: "YYYY-MM-DD", note: "how it was solved" } }, (i, { actor }) => closeMany(db, i, actor, now()));
  command2(app, "POST", "/incidents/:id/remove", { name: "incident_remove", on: "incident", by: "person", confirm: true, label: { es: "Quitar", en: "Remove" }, summary: "Takes an incident away (a mistake, a duplicate). A person's decision; to end one that was real, close it." }, (i) => remove(db, i));
  command2(app, "POST", "/notes", { name: "notes_add", summary: "Adds dated follow-up notes to incidents, several in one call: items [{ incident_id (or ref + project_id), text, day? }].", input: { items: "list of { incident_id, text, day }" } }, (i, { actor }) => notesAdd(db, i, actor, now()));
  command2(app, "POST", "/notes/:id/remove", { name: "note_remove", by: "person", summary: "Takes one follow-up note away. A person's decision." }, (i) => noteRemove(db, i));
  command2(app, "GET", "/visits", { name: "visits", of: "visit", summary: "The site visits, newest first, each with how many incidents it found and how many are still open. project_id for one project.", input: { project_id: "project id", project: BY_NAME } }, async (i) => visits(db, await named(db, i)));
  command2(app, "GET", "/visits/:id", { name: "visit", on: "visit", summary: "One visit: its day, who was there, its summary and the incidents found that day." }, (i) => visit(db, i));
  command2(app, "POST", "/visits", { name: "visit_add", summary: "The visit of a day (one per project and day; adding it again answers the one there is). To add it WITH what was found, use incidents_add with visit.", input: { project_id: "project id", day: "YYYY-MM-DD, today unless said", attendees: "who was there", summary: "text" } }, (i) => visitAdd(db, i, now()));
  command2(app, "POST", "/visits/:id", { name: "visit_update", on: "visit", summary: "Changes a visit's day, attendees or summary.", input: { day: "YYYY-MM-DD", attendees: "text", summary: "text" } }, (i) => visitUpdate(db, i));
  command2(app, "GET", "/procedures", { name: "procedures", of: "procedure", summary: "The procedures (licences, connections, insurance, deposits\u2026), what is under way first, each with its state and next step. project_id; state: open | pending | in_progress | blocked | done.", input: { project_id: "project id", project: BY_NAME, state: "open | pending | in_progress | blocked | done", full: "true for every row whole" } }, async (i, { actor }) => procedures(db, await named(db, i), wantsFull(i, actor), now()));
  command2(app, "POST", "/procedures", { name: "procedures_add", summary: "Adds several procedures in one call: items [{ title, kind, state, next_step, next_on, responsible, notes }]. kind: licence | connection | insurance | deposit | contract | legal | other.", input: { project_id: "project id", project: BY_NAME, items: "list" } }, async (i) => proceduresAdd(db, await named(db, i)));
  command2(app, "POST", "/procedures/update", { name: "procedures_update", summary: "Changes several procedures in one call: items [{ id, state?, next_step?, next_on?, \u2026, remove? }]. state done sets its date. Answers { changed, skipped }.", input: { items: "list" } }, (i) => proceduresUpdate(db, i, now()));
  command2(app, "POST", "/attachments", { name: "attachments_add", summary: "Attaches files, several in one call: items [{ incident_id | visit_id | project_id, kind: photo | plan | doc, name, note, and ONE of path (in the team's files folder), url, or data (a data URL under 2 MB) }].", input: { project_id: "project id, for items that name none", items: "list" } }, (i) => add2(db, i));
  command2(app, "GET", "/attachments", { name: "attachments", summary: "What a project has attached, names only. kind: photo | plan | doc.", input: { project_id: "project id", project: BY_NAME, kind: "photo | plan | doc" } }, async (i) => list3(db, await named(db, i)));
  command2(app, "GET", "/attachments/:id", { name: "attachment", summary: "One file with its bytes, for the screen. An agent is refused: a file's name, note and place are in incident.", input: { full: "true to get the bytes anyway (large)" } }, (i, { actor }) => one2(db, i, isPerson(actor)));
  command2(app, "POST", "/attachments/:id/remove", { name: "attachment_remove", by: "person", summary: "Takes an attached file away. A person's decision." }, (i) => remove2(db, i));
  command2(app, "POST", "/pin", { name: "pin_set", summary: "Places an incident on one of its project's plans: incident_id, plan_id, x and y from 0 to 1. plan_id null takes the pin away.", input: { incident_id: "incident id", plan_id: "attachment id of the plan, or null", x: "0 to 1 from the left", y: "0 to 1 from the top" } }, (i) => pinSet(db, i));
  command2(app, "GET", "/plans/:plan_id/pins", { name: "plan_pins", summary: "The incidents placed on one plan, each with where." }, (i) => planPins(db, i));
  command2(app, "GET", "/reports", { name: "reports", of: "report", summary: "The monthly reports there are, newest month first. project_id for one project.", input: { project_id: "project id" } }, (i) => list4(db, i));
  command2(app, "GET", "/reports/to-prepare", { name: "reports_to_prepare", summary: "The projects whose report of last month is not made yet (the trigger): { items: [{ key, text, project_id, project, period }] }." }, () => toPrepare(db, now()));
  command2(app, "GET", "/reports/:id", { name: "report", on: "report", summary: "One report: its two texts and the month in figures. full=true answers everything its page draws (large).", input: { full: "true for everything the page draws" } }, (i, { actor }) => one3(db, i, wantsFull(i, actor)));
  command2(app, "POST", "/reports", { name: "report_draft", summary: "Makes (or finds) a project's report of a month \u2014 last month unless period (YYYY-MM) \u2014 and answers the month in figures and what to write.", input: { project_id: "project id", period: "YYYY-MM", language: "ca | es (the setting unless said)" } }, (i) => draft(db, i, now()));
  command2(app, "POST", "/reports/:id/write", { name: "report_write", on: "report", summary: "Writes a report's texts, in the report's language: summary (the month in 5 to 8 lines) and outlook (what comes next). Refused once reviewed.", input: { summary: "text", outlook: "text", language: "ca | es" } }, (i) => write(db, i));
  command2(app, "POST", "/reports/:id/review", { name: "report_review", on: "report", by: "person", label: { es: "Dar por revisado", en: "Mark as reviewed" }, summary: "The person's yes to a report: from then it keeps that day's figures. A person's decision." }, (i, { actor }) => review(db, i, actor, now()));
  command2(app, "POST", "/reports/:id/sent", { name: "report_sent", on: "report", by: "person", label: { es: "Marcar enviado", en: "Mark as sent" }, summary: "The client has the report: marks a reviewed one as sent today (sent: false takes the mark away). A person's decision.", input: { sent: "false to take the mark away", sent_on: "YYYY-MM-DD" } }, (i) => markSent(db, i, now()));
  command2(app, "POST", "/reports/:id/reopen", { name: "report_reopen", on: "report", by: "person", label: { es: "Volver a borrador", en: "Back to draft" }, summary: "Takes a reviewed report back to a draft, with today's figures. A person's decision." }, (i) => reopen(db, i));
  const LINE = "worker, day, hours (ordinary), hours_overtime, hours_travel, km, time_in, time_out, break_min, task, site, company, validated_by, state, paid, notes, origin, project_id";
  command2(app, "GET", "/hours", { name: "hours", of: "timesheet", summary: "The timesheet summed over a time (this month unless from/to): totals, pending validation, unpaid, by worker and by project. by: week | month adds by_period; worker or project_id narrows to one's detail; state, paid, company filter; full=true every line.", input: { project_id: "project id", project: BY_NAME, worker: "name", company: "name", from: "YYYY-MM-DD", to: "YYYY-MM-DD", state: "pendent | validat | rebutjat", paid: "true | false", by: "week | month", full: "true for every line" } }, async (i, { actor }) => hours(db, await named(db, i), wantsFull(i, actor), now()));
  command2(app, "POST", "/hours", { name: "hours_add", summary: `Adds lines of hours, several in one call: items [{ ${LINE} }]. hours alone is ordinary hours; with time_in and time_out and no hours they are counted, less break_min. The same line twice is added once.`, input: { project_id: "project id, for items that name none", project: BY_NAME, items: "list" } }, async (i) => hoursAdd(db, await named(db, i)));
  command2(app, "POST", "/hours/update", { name: "hours_update", summary: "Changes several lines of hours in one call: items [{ id, \u2026only what changes }]. Answers { changed, skipped }.", input: { items: `list of { id, ${LINE} }` } }, (i) => hoursUpdate(db, i));
  command2(app, "POST", "/hours/mark", { name: "hours_mark", summary: "Validates, rejects or marks as paid MANY lines in one call: ids, or a filter (worker, project_id, company, from, to) that takes the ones still to validate (or still unpaid). state: validat | rebutjat | pendent; paid: true | false. Answers { changed, hours }.", input: { ids: "list of line ids", worker: "name", project_id: "project id", company: "name", from: "YYYY-MM-DD", to: "YYYY-MM-DD", state: "validat | rebutjat | pendent", paid: "true | false", validated_by: "who validates" } }, (i, { actor }) => hoursMark(db, i, actor, now()));
  command2(app, "POST", "/hours/:id/remove", { name: "hours_remove", by: "person", summary: "Takes one line of hours away. A person's decision." }, (i) => hoursRemove(db, i));
  const JOB = "day, concept, client, worker, property, town, description, hours, hours_travel, km, rate (euros an hour), total (euros; hours \xD7 rate unless said), billable, state, registered, notes, project_id";
  command2(app, "GET", "/jobs", { name: "jobs", of: "job", summary: "Billable jobs for clients, newest first, summed: to invoice, invoiced, paid, and by client. client, worker, project_id, state (pendent | facturat | cobrat), billable, registered, from, to narrow it; full=true every row whole.", input: { project_id: "project id", project: BY_NAME, client: "name", worker: "name", state: "pendent | facturat | cobrat", billable: "true | false", registered: "true | false: registered with the client", from: "YYYY-MM-DD", to: "YYYY-MM-DD", full: "true for every row whole" } }, async (i, { actor }) => jobs(db, await named(db, i), wantsFull(i, actor)));
  command2(app, "POST", "/jobs", { name: "jobs_add", summary: `Adds billable jobs, several in one call: items [{ ${JOB} }]. A job may have no project. The same day, worker, client and concept twice is added once.`, input: { project_id: "project id, for items that name none (optional)", project: BY_NAME, items: "list" } }, async (i) => jobsAdd(db, await named(db, i)));
  command2(app, "POST", "/jobs/update", { name: "jobs_update", summary: "Changes several jobs in one call: items [{ id, \u2026only what changes }] \u2014 invoiced is state: facturat, paid is state: cobrat, registered: true once the client has it. Answers { changed, skipped }.", input: { items: `list of { id, ${JOB} }` } }, (i) => jobsUpdate(db, i));
  command2(app, "POST", "/jobs/mark", { name: "jobs_mark", summary: "Marks MANY jobs invoiced, paid or registered in one call: ids, or a filter (client, worker, project_id, from, to) \u2014 facturat takes those still to invoice, cobrat the invoiced ones. state: facturat | cobrat | pendent; registered: true | false. Answers { changed, total }.", input: { ids: "list of job ids", client: "name", worker: "name", project_id: "project id", from: "YYYY-MM-DD", to: "YYYY-MM-DD", state: "facturat | cobrat | pendent", registered: "true | false" } }, (i) => jobsMark(db, i));
  command2(app, "POST", "/jobs/:id/remove", { name: "job_remove", on: "job", by: "person", confirm: true, label: { es: "Quitar", en: "Remove" }, summary: "Takes one billable job away. A person's decision." }, (i) => jobRemove(db, i));
  command2(app, "GET", "/companies", { name: "companies", of: "company", summary: "The companies (contractors, suppliers, clients), each with its kind, contact, people listed and open incidents it answers for. kind, q, active narrow it.", input: { kind: "its kind, as written", q: "words of its name, kind or contact", active: "true | false", full: "true for every row whole" } }, (i, { actor }) => companies(db, i, wantsFull(i, actor)));
  command2(app, "POST", "/companies", { name: "companies_save", summary: "Adds or changes companies, several in one call: items [{ name, kind, contact, email, phone, notes, active }]; with id it changes that one (remove: true takes it away). Answers { added, changed, skipped }.", input: { items: "list" } }, (i) => save(db, "company", i));
  command2(app, "GET", "/people", { name: "people", of: "person", summary: "The people (workers, technicians, contacts), each with role, area, company, open incidents they answer for and hours this month. company, kind, q, active narrow it.", input: { company: "name", kind: "its kind, as written", q: "words of the name, role or area", active: "true | false", full: "true for every row whole" } }, (i, { actor }) => people(db, i, wantsFull(i, actor), now()));
  command2(app, "POST", "/people", { name: "people_save", summary: "Adds or changes people, several in one call: items [{ name, role, area, company, kind, email, phone, notes, active }]; with id it changes that one (remove: true takes it away). Answers { added, changed, skipped }.", input: { items: "list" } }, (i) => save(db, "person", i));
  command2(app, "GET", "/participants", { name: "participants", summary: "Everyone involved in the works (intervinientes): companies and people, each with its group, the projects it is in, open incidents it answers for, hours and jobs. project_id for one project; group: promoter | builder | subcontractor | supplier | technical | worker | other; q.", input: { project_id: "project id", project: BY_NAME, group: "promoter | builder | subcontractor | supplier | technical | worker | other", q: "words of its name, kind, role or company", full: "true for every field" } }, async (i, { actor }) => list5(db, await named(db, i), wantsFull(i, actor), now()));
  command2(app, "GET", "/participants/one", { name: "participant", summary: "One of those involved, whole: its card, its projects, the open incidents it answers for and, for a company, its people. type (company | person) + id, or name.", input: { type: "company | person", id: "its id", name: "its name, instead of type and id" } }, (i) => one4(db, i, now()));
  command2(app, "GET", "/names", { name: "names", summary: "The names of the active people and companies, for a form that asks \xABwho\xBB: { people, companies }." }, () => names(db));
  command2(app, "POST", "/import", { name: "import_rows", summary: "Brings rows of an old table in, mapping their columns by name. kind: projects | companies | people | incidents | history | hours | jobs (read from table when it is one the module knows). dry_run (the default) only answers counts, the mapping and how each word was read; dry_run: false writes. A row sent twice is added once.", input: { kind: "projects | companies | people | incidents | history | hours | jobs", rows: "list of rows as they are in the old table (500 at most)", table: "the old table's name: part of where each row is remembered to come from", project_id: "the project, when the rows name none", project_map: '{ "<their project value>": <project id> }', map: '{ "<their column>": "<field>" } for what was not recognised', values: '{ "<field>": { "<their word>": "<ours>" } } for a state or severity that was not recognised', incidents_table: "for history: the name the incidents were imported under (incidencies unless said)", dry_run: "false to write" } }, (i, { actor }) => importRows(db, i, actor, now()));
  command2(app, "GET", "/settings", { name: "settings", of: "config", summary: "The module's settings: the name reports are signed with, their language (ca | es), colour and footer." }, () => settings(db));
  command2(app, "POST", "/settings/:id", { name: "set_settings", on: "config", by: "admin", partial: true, summary: "Changes the settings: company_name, report_language (ca | es), report_accent (#RRGGBB), report_footer, report_work (true adds the month's hours and jobs to the report).", input: ["company_name", "report_language", "report_accent", "report_footer", "report_work"] }, (i) => setSettings(db, i));
  command2(app, "GET", "/needs", { name: "page_needs", summary: "What a page still needs to be complete: { needs: [{ id, kind, title, unlocks, door, place }] }. Empty when nothing is missing." }, () => pageNeeds(db));
  command2(app, "POST", "/example", { name: "example_load", by: "person", summary: "Loads the example project (invented) into a module with no project yet. A person's button." }, () => load(db, now()));
  command2(app, "POST", "/example/remove", { name: "example_remove", summary: "Takes the example project away with everything in it, and keeps it off. It also leaves by itself when the first real project is added." }, () => remove3(db));
  command2(app, "POST", "/example/start", { name: "example_start", by: "person", summary: "Shows the example on a person's first visit: only while the company has no project and nobody switched it off. The page calls it." }, () => start(db, now()));
}

// server/app.mjs
function createApp(db, deps = {}) {
  const app = new Hono2();
  mountErrors(app);
  obras_default(app, db, deps);
  return app;
}

// server/db.mjs
function dataClient(url = process.env.APP_DATA_URL, token = process.env.APP_DATA_TOKEN) {
  const call = async (path, body) => {
    const r = await fetch(`${url}${path}`, { method: "POST", headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` }, body: JSON.stringify(body) });
    const j = await r.json().catch(() => null);
    if (!r.ok || !j) throw new Error(j?.error ?? `Data ${r.status}`);
    return j;
  };
  return {
    all: async (sql, params = []) => (await call("/all", { sql, params })).rows,
    one: async (sql, params = []) => (await call("/all", { sql, params })).rows[0] ?? null,
    insert: async (table, data) => (await call("/batch", { ops: [{ op: "insert", table, data }] })).ids[0],
    update: async (table, id, data, where = {}) => (await call("/update", { table, id, data, where })).changed,
    batch: async (ops) => (await call("/batch", { ops })).ids,
    // Which of the modules app.json `suggests` are installed for the company: [{ module, installed, name, version, for, unlocks }].
    // Read when asked, never kept; nothing of the other module is reachable (the guide: «Modules unlock each other»).
    peers: async () => (await call("/peers", {})).peers,
    // One read command another module EXPORTS and app.json `reads` declares: { installed: false } when that module is
    // not installed, else { installed: true, result }. Never its tables, never a write (the guide: «Reading another module»).
    read: async (module, command2, params = {}) => call("/read", { module, command: command2, params })
  };
}

// server/main.mjs
serve({ fetch: createApp(dataClient()).fetch, hostname: "127.0.0.1", port: Number(process.env.PORT) });
