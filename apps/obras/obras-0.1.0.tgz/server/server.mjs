// .stack/node_modules/@hono/node-server/dist/index.mjs
import { createServer as createServerHTTP } from "http";
import { Http2ServerRequest as Http2ServerRequest2 } from "http2";
import { Http2ServerRequest } from "http2";
import { Readable } from "stream";
import crypto from "crypto";
var RequestError = class extends Error {
  constructor(message, options) {
    super(message, options);
    this.name = "RequestError";
  }
};
var toRequestError = (e) => {
  if (e instanceof RequestError) {
    return e;
  }
  return new RequestError(e.message, { cause: e });
};
var GlobalRequest = global.Request;
var Request2 = class extends GlobalRequest {
  constructor(input, options) {
    if (typeof input === "object" && getRequestCache in input) {
      input = input[getRequestCache]();
    }
    if (typeof options?.body?.getReader !== "undefined") {
      ;
      options.duplex ??= "half";
    }
    super(input, options);
  }
};
var wrapBodyStream = Symbol("wrapBodyStream");
var newRequestFromIncoming = (method, url, incoming, abortController) => {
  const headerRecord = [];
  const rawHeaders = incoming.rawHeaders;
  for (let i = 0; i < rawHeaders.length; i += 2) {
    const { [i]: key, [i + 1]: value } = rawHeaders;
    if (key.charCodeAt(0) !== /*:*/
    58) {
      headerRecord.push([key, value]);
    }
  }
  const init = {
    method,
    headers: headerRecord,
    signal: abortController.signal
  };
  if (method === "TRACE") {
    init.method = "GET";
    const req = new Request2(url, init);
    Object.defineProperty(req, "method", {
      get() {
        return "TRACE";
      }
    });
    return req;
  }
  if (!(method === "GET" || method === "HEAD")) {
    if ("rawBody" in incoming && incoming.rawBody instanceof Buffer) {
      init.body = new ReadableStream({
        start(controller) {
          controller.enqueue(incoming.rawBody);
          controller.close();
        }
      });
    } else if (incoming[wrapBodyStream]) {
      let reader;
      init.body = new ReadableStream({
        async pull(controller) {
          try {
            reader ||= Readable.toWeb(incoming).getReader();
            const { done, value } = await reader.read();
            if (done) {
              controller.close();
            } else {
              controller.enqueue(value);
            }
          } catch (error) {
            controller.error(error);
          }
        }
      });
    } else {
      init.body = Readable.toWeb(incoming);
    }
  }
  return new Request2(url, init);
};
var getRequestCache = Symbol("getRequestCache");
var requestCache = Symbol("requestCache");
var incomingKey = Symbol("incomingKey");
var urlKey = Symbol("urlKey");
var abortControllerKey = Symbol("abortControllerKey");
var getAbortController = Symbol("getAbortController");
var requestPrototype = {
  get method() {
    return this[incomingKey].method || "GET";
  },
  get url() {
    return this[urlKey];
  },
  [getAbortController]() {
    this[getRequestCache]();
    return this[abortControllerKey];
  },
  [getRequestCache]() {
    this[abortControllerKey] ||= new AbortController();
    return this[requestCache] ||= newRequestFromIncoming(
      this.method,
      this[urlKey],
      this[incomingKey],
      this[abortControllerKey]
    );
  }
};
[
  "body",
  "bodyUsed",
  "cache",
  "credentials",
  "destination",
  "headers",
  "integrity",
  "mode",
  "redirect",
  "referrer",
  "referrerPolicy",
  "signal",
  "keepalive"
].forEach((k) => {
  Object.defineProperty(requestPrototype, k, {
    get() {
      return this[getRequestCache]()[k];
    }
  });
});
["arrayBuffer", "blob", "clone", "formData", "json", "text"].forEach((k) => {
  Object.defineProperty(requestPrototype, k, {
    value: function() {
      return this[getRequestCache]()[k]();
    }
  });
});
Object.setPrototypeOf(requestPrototype, Request2.prototype);
var newRequest = (incoming, defaultHostname) => {
  const req = Object.create(requestPrototype);
  req[incomingKey] = incoming;
  const incomingUrl = incoming.url || "";
  if (incomingUrl[0] !== "/" && // short-circuit for performance. most requests are relative URL.
  (incomingUrl.startsWith("http://") || incomingUrl.startsWith("https://"))) {
    if (incoming instanceof Http2ServerRequest) {
      throw new RequestError("Absolute URL for :path is not allowed in HTTP/2");
    }
    try {
      const url2 = new URL(incomingUrl);
      req[urlKey] = url2.href;
    } catch (e) {
      throw new RequestError("Invalid absolute URL", { cause: e });
    }
    return req;
  }
  const host = (incoming instanceof Http2ServerRequest ? incoming.authority : incoming.headers.host) || defaultHostname;
  if (!host) {
    throw new RequestError("Missing host header");
  }
  let scheme;
  if (incoming instanceof Http2ServerRequest) {
    scheme = incoming.scheme;
    if (!(scheme === "http" || scheme === "https")) {
      throw new RequestError("Unsupported scheme");
    }
  } else {
    scheme = incoming.socket && incoming.socket.encrypted ? "https" : "http";
  }
  const url = new URL(`${scheme}://${host}${incomingUrl}`);
  if (url.hostname.length !== host.length && url.hostname !== host.replace(/:\d+$/, "")) {
    throw new RequestError("Invalid host header");
  }
  req[urlKey] = url.href;
  return req;
};
var responseCache = Symbol("responseCache");
var getResponseCache = Symbol("getResponseCache");
var cacheKey = Symbol("cache");
var GlobalResponse = global.Response;
var Response2 = class _Response {
  #body;
  #init;
  [getResponseCache]() {
    delete this[cacheKey];
    return this[responseCache] ||= new GlobalResponse(this.#body, this.#init);
  }
  constructor(body, init) {
    let headers;
    this.#body = body;
    if (init instanceof _Response) {
      const cachedGlobalResponse = init[responseCache];
      if (cachedGlobalResponse) {
        this.#init = cachedGlobalResponse;
        this[getResponseCache]();
        return;
      } else {
        this.#init = init.#init;
        headers = new Headers(init.#init.headers);
      }
    } else {
      this.#init = init;
    }
    if (typeof body === "string" || typeof body?.getReader !== "undefined" || body instanceof Blob || body instanceof Uint8Array) {
      headers ||= init?.headers || { "content-type": "text/plain; charset=UTF-8" };
      this[cacheKey] = [init?.status || 200, body, headers];
    }
  }
  get headers() {
    const cache = this[cacheKey];
    if (cache) {
      if (!(cache[2] instanceof Headers)) {
        cache[2] = new Headers(cache[2]);
      }
      return cache[2];
    }
    return this[getResponseCache]().headers;
  }
  get status() {
    return this[cacheKey]?.[0] ?? this[getResponseCache]().status;
  }
  get ok() {
    const status = this.status;
    return status >= 200 && status < 300;
  }
};
["body", "bodyUsed", "redirected", "statusText", "trailers", "type", "url"].forEach((k) => {
  Object.defineProperty(Response2.prototype, k, {
    get() {
      return this[getResponseCache]()[k];
    }
  });
});
["arrayBuffer", "blob", "clone", "formData", "json", "text"].forEach((k) => {
  Object.defineProperty(Response2.prototype, k, {
    value: function() {
      return this[getResponseCache]()[k]();
    }
  });
});
Object.setPrototypeOf(Response2, GlobalResponse);
Object.setPrototypeOf(Response2.prototype, GlobalResponse.prototype);
async function readWithoutBlocking(readPromise) {
  return Promise.race([readPromise, Promise.resolve().then(() => Promise.resolve(void 0))]);
}
function writeFromReadableStreamDefaultReader(reader, writable, currentReadPromise) {
  const handleError = () => {
  };
  writable.on("error", handleError);
  (currentReadPromise ?? reader.read()).then(flow, handleStreamError);
  return reader.closed.finally(() => {
    writable.off("error", handleError);
  });
  function handleStreamError(error) {
    if (error) {
      writable.destroy(error);
    }
  }
  function onDrain() {
    reader.read().then(flow, handleStreamError);
  }
  function flow({ done, value }) {
    try {
      if (done) {
        writable.end();
      } else if (!writable.write(value)) {
        writable.once("drain", onDrain);
      } else {
        return reader.read().then(flow, handleStreamError);
      }
    } catch (e) {
      handleStreamError(e);
    }
  }
}
function writeFromReadableStream(stream, writable) {
  if (stream.locked) {
    throw new TypeError("ReadableStream is locked.");
  } else if (writable.destroyed) {
    return;
  }
  return writeFromReadableStreamDefaultReader(stream.getReader(), writable);
}
var buildOutgoingHttpHeaders = (headers) => {
  const res = {};
  if (!(headers instanceof Headers)) {
    headers = new Headers(headers ?? void 0);
  }
  const cookies = [];
  for (const [k, v] of headers) {
    if (k === "set-cookie") {
      cookies.push(v);
    } else {
      res[k] = v;
    }
  }
  if (cookies.length > 0) {
    res["set-cookie"] = cookies;
  }
  res["content-type"] ??= "text/plain; charset=UTF-8";
  return res;
};
var X_ALREADY_SENT = "x-hono-already-sent";
var webFetch = global.fetch;
if (typeof global.crypto === "undefined") {
  global.crypto = crypto;
}
global.fetch = (info, init) => {
  init = {
    // Disable compression handling so people can return the result of a fetch
    // directly in the loader without messing with the Content-Encoding header.
    compress: false,
    ...init
  };
  return webFetch(info, init);
};
var outgoingEnded = Symbol("outgoingEnded");
var handleRequestError = () => new Response(null, {
  status: 400
});
var handleFetchError = (e) => new Response(null, {
  status: e instanceof Error && (e.name === "TimeoutError" || e.constructor.name === "TimeoutError") ? 504 : 500
});
var handleResponseError = (e, outgoing) => {
  const err = e instanceof Error ? e : new Error("unknown error", { cause: e });
  if (err.code === "ERR_STREAM_PREMATURE_CLOSE") {
    console.info("The user aborted a request.");
  } else {
    console.error(e);
    if (!outgoing.headersSent) {
      outgoing.writeHead(500, { "Content-Type": "text/plain" });
    }
    outgoing.end(`Error: ${err.message}`);
    outgoing.destroy(err);
  }
};
var flushHeaders = (outgoing) => {
  if ("flushHeaders" in outgoing && outgoing.writable) {
    outgoing.flushHeaders();
  }
};
var responseViaCache = async (res, outgoing) => {
  let [status, body, header] = res[cacheKey];
  if (header instanceof Headers) {
    header = buildOutgoingHttpHeaders(header);
  }
  if (typeof body === "string") {
    header["Content-Length"] = Buffer.byteLength(body);
  } else if (body instanceof Uint8Array) {
    header["Content-Length"] = body.byteLength;
  } else if (body instanceof Blob) {
    header["Content-Length"] = body.size;
  }
  outgoing.writeHead(status, header);
  if (typeof body === "string" || body instanceof Uint8Array) {
    outgoing.end(body);
  } else if (body instanceof Blob) {
    outgoing.end(new Uint8Array(await body.arrayBuffer()));
  } else {
    flushHeaders(outgoing);
    await writeFromReadableStream(body, outgoing)?.catch(
      (e) => handleResponseError(e, outgoing)
    );
  }
  ;
  outgoing[outgoingEnded]?.();
};
var responseViaResponseObject = async (res, outgoing, options = {}) => {
  if (res instanceof Promise) {
    if (options.errorHandler) {
      try {
        res = await res;
      } catch (err) {
        const errRes = await options.errorHandler(err);
        if (!errRes) {
          return;
        }
        res = errRes;
      }
    } else {
      res = await res.catch(handleFetchError);
    }
  }
  if (cacheKey in res) {
    return responseViaCache(res, outgoing);
  }
  const resHeaderRecord = buildOutgoingHttpHeaders(res.headers);
  if (res.body) {
    const reader = res.body.getReader();
    const values = [];
    let done = false;
    let currentReadPromise = void 0;
    if (resHeaderRecord["transfer-encoding"] !== "chunked") {
      let maxReadCount = 2;
      for (let i = 0; i < maxReadCount; i++) {
        currentReadPromise ||= reader.read();
        const chunk = await readWithoutBlocking(currentReadPromise).catch((e) => {
          console.error(e);
          done = true;
        });
        if (!chunk) {
          if (i === 1) {
            await new Promise((resolve) => setTimeout(resolve));
            maxReadCount = 3;
            continue;
          }
          break;
        }
        currentReadPromise = void 0;
        if (chunk.value) {
          values.push(chunk.value);
        }
        if (chunk.done) {
          done = true;
          break;
        }
      }
      if (done && !("content-length" in resHeaderRecord)) {
        resHeaderRecord["content-length"] = values.reduce((acc, value) => acc + value.length, 0);
      }
    }
    outgoing.writeHead(res.status, resHeaderRecord);
    values.forEach((value) => {
      ;
      outgoing.write(value);
    });
    if (done) {
      outgoing.end();
    } else {
      if (values.length === 0) {
        flushHeaders(outgoing);
      }
      await writeFromReadableStreamDefaultReader(reader, outgoing, currentReadPromise);
    }
  } else if (resHeaderRecord[X_ALREADY_SENT]) {
  } else {
    outgoing.writeHead(res.status, resHeaderRecord);
    outgoing.end();
  }
  ;
  outgoing[outgoingEnded]?.();
};
var getRequestListener = (fetchCallback, options = {}) => {
  const autoCleanupIncoming = options.autoCleanupIncoming ?? true;
  if (options.overrideGlobalObjects !== false && global.Request !== Request2) {
    Object.defineProperty(global, "Request", {
      value: Request2
    });
    Object.defineProperty(global, "Response", {
      value: Response2
    });
  }
  return async (incoming, outgoing) => {
    let res, req;
    try {
      req = newRequest(incoming, options.hostname);
      let incomingEnded = !autoCleanupIncoming || incoming.method === "GET" || incoming.method === "HEAD";
      if (!incomingEnded) {
        ;
        incoming[wrapBodyStream] = true;
        incoming.on("end", () => {
          incomingEnded = true;
        });
        if (incoming instanceof Http2ServerRequest2) {
          ;
          outgoing[outgoingEnded] = () => {
            if (!incomingEnded) {
              setTimeout(() => {
                if (!incomingEnded) {
                  setTimeout(() => {
                    incoming.destroy();
                    outgoing.destroy();
                  });
                }
              });
            }
          };
        }
      }
      outgoing.on("close", () => {
        const abortController = req[abortControllerKey];
        if (abortController) {
          if (incoming.errored) {
            req[abortControllerKey].abort(incoming.errored.toString());
          } else if (!outgoing.writableFinished) {
            req[abortControllerKey].abort("Client connection prematurely closed.");
          }
        }
        if (!incomingEnded) {
          setTimeout(() => {
            if (!incomingEnded) {
              setTimeout(() => {
                incoming.destroy();
              });
            }
          });
        }
      });
      res = fetchCallback(req, { incoming, outgoing });
      if (cacheKey in res) {
        return responseViaCache(res, outgoing);
      }
    } catch (e) {
      if (!res) {
        if (options.errorHandler) {
          res = await options.errorHandler(req ? e : toRequestError(e));
          if (!res) {
            return;
          }
        } else if (!req) {
          res = handleRequestError();
        } else {
          res = handleFetchError(e);
        }
      } else {
        return handleResponseError(e, outgoing);
      }
    }
    try {
      return await responseViaResponseObject(res, outgoing, options);
    } catch (e) {
      return handleResponseError(e, outgoing);
    }
  };
};
var createAdaptorServer = (options) => {
  const fetchCallback = options.fetch;
  const requestListener = getRequestListener(fetchCallback, {
    hostname: options.hostname,
    overrideGlobalObjects: options.overrideGlobalObjects,
    autoCleanupIncoming: options.autoCleanupIncoming
  });
  const createServer = options.createServer || createServerHTTP;
  const server = createServer(options.serverOptions || {}, requestListener);
  return server;
};
var serve = (options, listeningListener) => {
  const server = createAdaptorServer(options);
  server.listen(options?.port ?? 3e3, options.hostname, () => {
    const serverInfo = server.address();
    listeningListener && listeningListener(serverInfo);
  });
  return server;
};

// .stack/node_modules/hono/dist/compose.js
var compose = (middleware, onError, onNotFound) => {
  return (context, next) => {
    let index = -1;
    return dispatch(0);
    async function dispatch(i) {
      if (i <= index) {
        throw new Error("next() called multiple times");
      }
      index = i;
      let res;
      let isError = false;
      let handler;
      if (middleware[i]) {
        handler = middleware[i][0][0];
        context.req.routeIndex = i;
      } else {
        handler = i === middleware.length && next || void 0;
      }
      if (handler) {
        try {
          res = await handler(context, () => dispatch(i + 1));
        } catch (err) {
          if (err instanceof Error && onError) {
            context.error = err;
            res = await onError(err, context);
            isError = true;
          } else {
            throw err;
          }
        }
      } else {
        if (context.finalized === false && onNotFound) {
          res = await onNotFound(context);
        }
      }
      if (res && (context.finalized === false || isError)) {
        context.res = res;
      }
      return context;
    }
  };
};

// .stack/node_modules/hono/dist/request/constants.js
var GET_MATCH_RESULT = /* @__PURE__ */ Symbol();

// .stack/node_modules/hono/dist/utils/body.js
var parseBody = async (request, options = /* @__PURE__ */ Object.create(null)) => {
  const { all = false, dot = false } = options;
  const headers = request instanceof HonoRequest ? request.raw.headers : request.headers;
  const contentType = headers.get("Content-Type");
  if (contentType?.startsWith("multipart/form-data") || contentType?.startsWith("application/x-www-form-urlencoded")) {
    return parseFormData(request, { all, dot });
  }
  return {};
};
async function parseFormData(request, options) {
  const formData = await request.formData();
  if (formData) {
    return convertFormDataToBodyData(formData, options);
  }
  return {};
}
function convertFormDataToBodyData(formData, options) {
  const form = /* @__PURE__ */ Object.create(null);
  formData.forEach((value, key) => {
    const shouldParseAllValues = options.all || key.endsWith("[]");
    if (!shouldParseAllValues) {
      form[key] = value;
    } else {
      handleParsingAllValues(form, key, value);
    }
  });
  if (options.dot) {
    Object.entries(form).forEach(([key, value]) => {
      const shouldParseDotValues = key.includes(".");
      if (shouldParseDotValues) {
        handleParsingNestedValues(form, key, value);
        delete form[key];
      }
    });
  }
  return form;
}
var handleParsingAllValues = (form, key, value) => {
  if (form[key] !== void 0) {
    if (Array.isArray(form[key])) {
      ;
      form[key].push(value);
    } else {
      form[key] = [form[key], value];
    }
  } else {
    if (!key.endsWith("[]")) {
      form[key] = value;
    } else {
      form[key] = [value];
    }
  }
};
var handleParsingNestedValues = (form, key, value) => {
  let nestedForm = form;
  const keys = key.split(".");
  keys.forEach((key2, index) => {
    if (index === keys.length - 1) {
      nestedForm[key2] = value;
    } else {
      if (!nestedForm[key2] || typeof nestedForm[key2] !== "object" || Array.isArray(nestedForm[key2]) || nestedForm[key2] instanceof File) {
        nestedForm[key2] = /* @__PURE__ */ Object.create(null);
      }
      nestedForm = nestedForm[key2];
    }
  });
};

// .stack/node_modules/hono/dist/utils/url.js
var splitPath = (path) => {
  const paths = path.split("/");
  if (paths[0] === "") {
    paths.shift();
  }
  return paths;
};
var splitRoutingPath = (routePath) => {
  const { groups, path } = extractGroupsFromPath(routePath);
  const paths = splitPath(path);
  return replaceGroupMarks(paths, groups);
};
var extractGroupsFromPath = (path) => {
  const groups = [];
  path = path.replace(/\{[^}]+\}/g, (match2, index) => {
    const mark = `@${index}`;
    groups.push([mark, match2]);
    return mark;
  });
  return { groups, path };
};
var replaceGroupMarks = (paths, groups) => {
  for (let i = groups.length - 1; i >= 0; i--) {
    const [mark] = groups[i];
    for (let j = paths.length - 1; j >= 0; j--) {
      if (paths[j].includes(mark)) {
        paths[j] = paths[j].replace(mark, groups[i][1]);
        break;
      }
    }
  }
  return paths;
};
var patternCache = {};
var getPattern = (label, next) => {
  if (label === "*") {
    return "*";
  }
  const match2 = label.match(/^\:([^\{\}]+)(?:\{(.+)\})?$/);
  if (match2) {
    const cacheKey2 = `${label}#${next}`;
    if (!patternCache[cacheKey2]) {
      if (match2[2]) {
        patternCache[cacheKey2] = next && next[0] !== ":" && next[0] !== "*" ? [cacheKey2, match2[1], new RegExp(`^${match2[2]}(?=/${next})`)] : [label, match2[1], new RegExp(`^${match2[2]}$`)];
      } else {
        patternCache[cacheKey2] = [label, match2[1], true];
      }
    }
    return patternCache[cacheKey2];
  }
  return null;
};
var tryDecode = (str, decoder) => {
  try {
    return decoder(str);
  } catch {
    return str.replace(/(?:%[0-9A-Fa-f]{2})+/g, (match2) => {
      try {
        return decoder(match2);
      } catch {
        return match2;
      }
    });
  }
};
var tryDecodeURI = (str) => tryDecode(str, decodeURI);
var getPath = (request) => {
  const url = request.url;
  const start = url.indexOf("/", url.indexOf(":") + 4);
  let i = start;
  for (; i < url.length; i++) {
    const charCode = url.charCodeAt(i);
    if (charCode === 37) {
      const queryIndex = url.indexOf("?", i);
      const hashIndex = url.indexOf("#", i);
      const end = queryIndex === -1 ? hashIndex === -1 ? void 0 : hashIndex : hashIndex === -1 ? queryIndex : Math.min(queryIndex, hashIndex);
      const path = url.slice(start, end);
      return tryDecodeURI(path.includes("%25") ? path.replace(/%25/g, "%2525") : path);
    } else if (charCode === 63 || charCode === 35) {
      break;
    }
  }
  return url.slice(start, i);
};
var getPathNoStrict = (request) => {
  const result = getPath(request);
  return result.length > 1 && result.at(-1) === "/" ? result.slice(0, -1) : result;
};
var mergePath = (base, sub, ...rest) => {
  if (rest.length) {
    sub = mergePath(sub, ...rest);
  }
  return `${base?.[0] === "/" ? "" : "/"}${base}${sub === "/" ? "" : `${base?.at(-1) === "/" ? "" : "/"}${sub?.[0] === "/" ? sub.slice(1) : sub}`}`;
};
var checkOptionalParameter = (path) => {
  if (path.charCodeAt(path.length - 1) !== 63 || !path.includes(":")) {
    return null;
  }
  const segments = path.split("/");
  const results = [];
  let basePath = "";
  segments.forEach((segment) => {
    if (segment !== "" && !/\:/.test(segment)) {
      basePath += "/" + segment;
    } else if (/\:/.test(segment)) {
      if (/\?/.test(segment)) {
        if (results.length === 0 && basePath === "") {
          results.push("/");
        } else {
          results.push(basePath);
        }
        const optionalSegment = segment.replace("?", "");
        basePath += "/" + optionalSegment;
        results.push(basePath);
      } else {
        basePath += "/" + segment;
      }
    }
  });
  return results.filter((v, i, a) => a.indexOf(v) === i);
};
var _decodeURI = (value) => {
  if (!/[%+]/.test(value)) {
    return value;
  }
  if (value.indexOf("+") !== -1) {
    value = value.replace(/\+/g, " ");
  }
  return value.indexOf("%") !== -1 ? tryDecode(value, decodeURIComponent_) : value;
};
var _getQueryParam = (url, key, multiple) => {
  let encoded;
  if (!multiple && key && !/[%+]/.test(key)) {
    let keyIndex2 = url.indexOf("?", 8);
    if (keyIndex2 === -1) {
      return void 0;
    }
    if (!url.startsWith(key, keyIndex2 + 1)) {
      keyIndex2 = url.indexOf(`&${key}`, keyIndex2 + 1);
    }
    while (keyIndex2 !== -1) {
      const trailingKeyCode = url.charCodeAt(keyIndex2 + key.length + 1);
      if (trailingKeyCode === 61) {
        const valueIndex = keyIndex2 + key.length + 2;
        const endIndex = url.indexOf("&", valueIndex);
        return _decodeURI(url.slice(valueIndex, endIndex === -1 ? void 0 : endIndex));
      } else if (trailingKeyCode == 38 || isNaN(trailingKeyCode)) {
        return "";
      }
      keyIndex2 = url.indexOf(`&${key}`, keyIndex2 + 1);
    }
    encoded = /[%+]/.test(url);
    if (!encoded) {
      return void 0;
    }
  }
  const results = {};
  encoded ??= /[%+]/.test(url);
  let keyIndex = url.indexOf("?", 8);
  while (keyIndex !== -1) {
    const nextKeyIndex = url.indexOf("&", keyIndex + 1);
    let valueIndex = url.indexOf("=", keyIndex);
    if (valueIndex > nextKeyIndex && nextKeyIndex !== -1) {
      valueIndex = -1;
    }
    let name = url.slice(
      keyIndex + 1,
      valueIndex === -1 ? nextKeyIndex === -1 ? void 0 : nextKeyIndex : valueIndex
    );
    if (encoded) {
      name = _decodeURI(name);
    }
    keyIndex = nextKeyIndex;
    if (name === "") {
      continue;
    }
    let value;
    if (valueIndex === -1) {
      value = "";
    } else {
      value = url.slice(valueIndex + 1, nextKeyIndex === -1 ? void 0 : nextKeyIndex);
      if (encoded) {
        value = _decodeURI(value);
      }
    }
    if (multiple) {
      if (!(results[name] && Array.isArray(results[name]))) {
        results[name] = [];
      }
      ;
      results[name].push(value);
    } else {
      results[name] ??= value;
    }
  }
  return key ? results[key] : results;
};
var getQueryParam = _getQueryParam;
var getQueryParams = (url, key) => {
  return _getQueryParam(url, key, true);
};
var decodeURIComponent_ = decodeURIComponent;

// .stack/node_modules/hono/dist/request.js
var tryDecodeURIComponent = (str) => tryDecode(str, decodeURIComponent_);
var HonoRequest = class {
  /**
   * `.raw` can get the raw Request object.
   *
   * @see {@link https://hono.dev/docs/api/request#raw}
   *
   * @example
   * ```ts
   * // For Cloudflare Workers
   * app.post('/', async (c) => {
   *   const metadata = c.req.raw.cf?.hostMetadata?
   *   ...
   * })
   * ```
   */
  raw;
  #validatedData;
  // Short name of validatedData
  #matchResult;
  routeIndex = 0;
  /**
   * `.path` can get the pathname of the request.
   *
   * @see {@link https://hono.dev/docs/api/request#path}
   *
   * @example
   * ```ts
   * app.get('/about/me', (c) => {
   *   const pathname = c.req.path // `/about/me`
   * })
   * ```
   */
  path;
  bodyCache = {};
  constructor(request, path = "/", matchResult = [[]]) {
    this.raw = request;
    this.path = path;
    this.#matchResult = matchResult;
    this.#validatedData = {};
  }
  param(key) {
    return key ? this.#getDecodedParam(key) : this.#getAllDecodedParams();
  }
  #getDecodedParam(key) {
    const paramKey = this.#matchResult[0][this.routeIndex][1][key];
    const param = this.#getParamValue(paramKey);
    return param && /\%/.test(param) ? tryDecodeURIComponent(param) : param;
  }
  #getAllDecodedParams() {
    const decoded = {};
    const keys = Object.keys(this.#matchResult[0][this.routeIndex][1]);
    for (const key of keys) {
      const value = this.#getParamValue(this.#matchResult[0][this.routeIndex][1][key]);
      if (value !== void 0) {
        decoded[key] = /\%/.test(value) ? tryDecodeURIComponent(value) : value;
      }
    }
    return decoded;
  }
  #getParamValue(paramKey) {
    return this.#matchResult[1] ? this.#matchResult[1][paramKey] : paramKey;
  }
  query(key) {
    return getQueryParam(this.url, key);
  }
  queries(key) {
    return getQueryParams(this.url, key);
  }
  header(name) {
    if (name) {
      return this.raw.headers.get(name) ?? void 0;
    }
    const headerData = {};
    this.raw.headers.forEach((value, key) => {
      headerData[key] = value;
    });
    return headerData;
  }
  async parseBody(options) {
    return this.bodyCache.parsedBody ??= await parseBody(this, options);
  }
  #cachedBody = (key) => {
    const { bodyCache, raw: raw2 } = this;
    const cachedBody = bodyCache[key];
    if (cachedBody) {
      return cachedBody;
    }
    const anyCachedKey = Object.keys(bodyCache)[0];
    if (anyCachedKey) {
      return bodyCache[anyCachedKey].then((body) => {
        if (anyCachedKey === "json") {
          body = JSON.stringify(body);
        }
        return new Response(body)[key]();
      });
    }
    return bodyCache[key] = raw2[key]();
  };
  /**
   * `.json()` can parse Request body of type `application/json`
   *
   * @see {@link https://hono.dev/docs/api/request#json}
   *
   * @example
   * ```ts
   * app.post('/entry', async (c) => {
   *   const body = await c.req.json()
   * })
   * ```
   */
  json() {
    return this.#cachedBody("text").then((text2) => JSON.parse(text2));
  }
  /**
   * `.text()` can parse Request body of type `text/plain`
   *
   * @see {@link https://hono.dev/docs/api/request#text}
   *
   * @example
   * ```ts
   * app.post('/entry', async (c) => {
   *   const body = await c.req.text()
   * })
   * ```
   */
  text() {
    return this.#cachedBody("text");
  }
  /**
   * `.arrayBuffer()` parse Request body as an `ArrayBuffer`
   *
   * @see {@link https://hono.dev/docs/api/request#arraybuffer}
   *
   * @example
   * ```ts
   * app.post('/entry', async (c) => {
   *   const body = await c.req.arrayBuffer()
   * })
   * ```
   */
  arrayBuffer() {
    return this.#cachedBody("arrayBuffer");
  }
  /**
   * Parses the request body as a `Blob`.
   * @example
   * ```ts
   * app.post('/entry', async (c) => {
   *   const body = await c.req.blob();
   * });
   * ```
   * @see https://hono.dev/docs/api/request#blob
   */
  blob() {
    return this.#cachedBody("blob");
  }
  /**
   * Parses the request body as `FormData`.
   * @example
   * ```ts
   * app.post('/entry', async (c) => {
   *   const body = await c.req.formData();
   * });
   * ```
   * @see https://hono.dev/docs/api/request#formdata
   */
  formData() {
    return this.#cachedBody("formData");
  }
  /**
   * Adds validated data to the request.
   *
   * @param target - The target of the validation.
   * @param data - The validated data to add.
   */
  addValidatedData(target, data) {
    this.#validatedData[target] = data;
  }
  valid(target) {
    return this.#validatedData[target];
  }
  /**
   * `.url()` can get the request url strings.
   *
   * @see {@link https://hono.dev/docs/api/request#url}
   *
   * @example
   * ```ts
   * app.get('/about/me', (c) => {
   *   const url = c.req.url // `http://localhost:8787/about/me`
   *   ...
   * })
   * ```
   */
  get url() {
    return this.raw.url;
  }
  /**
   * `.method()` can get the method name of the request.
   *
   * @see {@link https://hono.dev/docs/api/request#method}
   *
   * @example
   * ```ts
   * app.get('/about/me', (c) => {
   *   const method = c.req.method // `GET`
   * })
   * ```
   */
  get method() {
    return this.raw.method;
  }
  get [GET_MATCH_RESULT]() {
    return this.#matchResult;
  }
  /**
   * `.matchedRoutes()` can return a matched route in the handler
   *
   * @deprecated
   *
   * Use matchedRoutes helper defined in "hono/route" instead.
   *
   * @see {@link https://hono.dev/docs/api/request#matchedroutes}
   *
   * @example
   * ```ts
   * app.use('*', async function logger(c, next) {
   *   await next()
   *   c.req.matchedRoutes.forEach(({ handler, method, path }, i) => {
   *     const name = handler.name || (handler.length < 2 ? '[handler]' : '[middleware]')
   *     console.log(
   *       method,
   *       ' ',
   *       path,
   *       ' '.repeat(Math.max(10 - path.length, 0)),
   *       name,
   *       i === c.req.routeIndex ? '<- respond from here' : ''
   *     )
   *   })
   * })
   * ```
   */
  get matchedRoutes() {
    return this.#matchResult[0].map(([[, route]]) => route);
  }
  /**
   * `routePath()` can retrieve the path registered within the handler
   *
   * @deprecated
   *
   * Use routePath helper defined in "hono/route" instead.
   *
   * @see {@link https://hono.dev/docs/api/request#routepath}
   *
   * @example
   * ```ts
   * app.get('/posts/:id', (c) => {
   *   return c.json({ path: c.req.routePath })
   * })
   * ```
   */
  get routePath() {
    return this.#matchResult[0].map(([[, route]]) => route)[this.routeIndex].path;
  }
};

// .stack/node_modules/hono/dist/utils/html.js
var HtmlEscapedCallbackPhase = {
  Stringify: 1,
  BeforeStream: 2,
  Stream: 3
};
var raw = (value, callbacks) => {
  const escapedString = new String(value);
  escapedString.isEscaped = true;
  escapedString.callbacks = callbacks;
  return escapedString;
};
var resolveCallback = async (str, phase, preserveCallbacks, context, buffer) => {
  if (typeof str === "object" && !(str instanceof String)) {
    if (!(str instanceof Promise)) {
      str = str.toString();
    }
    if (str instanceof Promise) {
      str = await str;
    }
  }
  const callbacks = str.callbacks;
  if (!callbacks?.length) {
    return Promise.resolve(str);
  }
  if (buffer) {
    buffer[0] += str;
  } else {
    buffer = [str];
  }
  const resStr = Promise.all(callbacks.map((c) => c({ phase, buffer, context }))).then(
    (res) => Promise.all(
      res.filter(Boolean).map((str2) => resolveCallback(str2, phase, false, context, buffer))
    ).then(() => buffer[0])
  );
  if (preserveCallbacks) {
    return raw(await resStr, callbacks);
  } else {
    return resStr;
  }
};

// .stack/node_modules/hono/dist/context.js
var TEXT_PLAIN = "text/plain; charset=UTF-8";
var setDefaultContentType = (contentType, headers) => {
  return {
    "Content-Type": contentType,
    ...headers
  };
};
var createResponseInstance = (body, init) => new Response(body, init);
var Context = class {
  #rawRequest;
  #req;
  /**
   * `.env` can get bindings (environment variables, secrets, KV namespaces, D1 database, R2 bucket etc.) in Cloudflare Workers.
   *
   * @see {@link https://hono.dev/docs/api/context#env}
   *
   * @example
   * ```ts
   * // Environment object for Cloudflare Workers
   * app.get('*', async c => {
   *   const counter = c.env.COUNTER
   * })
   * ```
   */
  env = {};
  #var;
  finalized = false;
  /**
   * `.error` can get the error object from the middleware if the Handler throws an error.
   *
   * @see {@link https://hono.dev/docs/api/context#error}
   *
   * @example
   * ```ts
   * app.use('*', async (c, next) => {
   *   await next()
   *   if (c.error) {
   *     // do something...
   *   }
   * })
   * ```
   */
  error;
  #status;
  #executionCtx;
  #res;
  #layout;
  #renderer;
  #notFoundHandler;
  #preparedHeaders;
  #matchResult;
  #path;
  /**
   * Creates an instance of the Context class.
   *
   * @param req - The Request object.
   * @param options - Optional configuration options for the context.
   */
  constructor(req, options) {
    this.#rawRequest = req;
    if (options) {
      this.#executionCtx = options.executionCtx;
      this.env = options.env;
      this.#notFoundHandler = options.notFoundHandler;
      this.#path = options.path;
      this.#matchResult = options.matchResult;
    }
  }
  /**
   * `.req` is the instance of {@link HonoRequest}.
   */
  get req() {
    this.#req ??= new HonoRequest(this.#rawRequest, this.#path, this.#matchResult);
    return this.#req;
  }
  /**
   * @see {@link https://hono.dev/docs/api/context#event}
   * The FetchEvent associated with the current request.
   *
   * @throws Will throw an error if the context does not have a FetchEvent.
   */
  get event() {
    if (this.#executionCtx && "respondWith" in this.#executionCtx) {
      return this.#executionCtx;
    } else {
      throw Error("This context has no FetchEvent");
    }
  }
  /**
   * @see {@link https://hono.dev/docs/api/context#executionctx}
   * The ExecutionContext associated with the current request.
   *
   * @throws Will throw an error if the context does not have an ExecutionContext.
   */
  get executionCtx() {
    if (this.#executionCtx) {
      return this.#executionCtx;
    } else {
      throw Error("This context has no ExecutionContext");
    }
  }
  /**
   * @see {@link https://hono.dev/docs/api/context#res}
   * The Response object for the current request.
   */
  get res() {
    return this.#res ||= createResponseInstance(null, {
      headers: this.#preparedHeaders ??= new Headers()
    });
  }
  /**
   * Sets the Response object for the current request.
   *
   * @param _res - The Response object to set.
   */
  set res(_res) {
    if (this.#res && _res) {
      _res = createResponseInstance(_res.body, _res);
      for (const [k, v] of this.#res.headers.entries()) {
        if (k === "content-type") {
          continue;
        }
        if (k === "set-cookie") {
          const cookies = this.#res.headers.getSetCookie();
          _res.headers.delete("set-cookie");
          for (const cookie of cookies) {
            _res.headers.append("set-cookie", cookie);
          }
        } else {
          _res.headers.set(k, v);
        }
      }
    }
    this.#res = _res;
    this.finalized = true;
  }
  /**
   * `.render()` can create a response within a layout.
   *
   * @see {@link https://hono.dev/docs/api/context#render-setrenderer}
   *
   * @example
   * ```ts
   * app.get('/', (c) => {
   *   return c.render('Hello!')
   * })
   * ```
   */
  render = (...args) => {
    this.#renderer ??= (content) => this.html(content);
    return this.#renderer(...args);
  };
  /**
   * Sets the layout for the response.
   *
   * @param layout - The layout to set.
   * @returns The layout function.
   */
  setLayout = (layout) => this.#layout = layout;
  /**
   * Gets the current layout for the response.
   *
   * @returns The current layout function.
   */
  getLayout = () => this.#layout;
  /**
   * `.setRenderer()` can set the layout in the custom middleware.
   *
   * @see {@link https://hono.dev/docs/api/context#render-setrenderer}
   *
   * @example
   * ```tsx
   * app.use('*', async (c, next) => {
   *   c.setRenderer((content) => {
   *     return c.html(
   *       <html>
   *         <body>
   *           <p>{content}</p>
   *         </body>
   *       </html>
   *     )
   *   })
   *   await next()
   * })
   * ```
   */
  setRenderer = (renderer) => {
    this.#renderer = renderer;
  };
  /**
   * `.header()` can set headers.
   *
   * @see {@link https://hono.dev/docs/api/context#header}
   *
   * @example
   * ```ts
   * app.get('/welcome', (c) => {
   *   // Set headers
   *   c.header('X-Message', 'Hello!')
   *   c.header('Content-Type', 'text/plain')
   *
   *   return c.body('Thank you for coming')
   * })
   * ```
   */
  header = (name, value, options) => {
    if (this.finalized) {
      this.#res = createResponseInstance(this.#res.body, this.#res);
    }
    const headers = this.#res ? this.#res.headers : this.#preparedHeaders ??= new Headers();
    if (value === void 0) {
      headers.delete(name);
    } else if (options?.append) {
      headers.append(name, value);
    } else {
      headers.set(name, value);
    }
  };
  status = (status) => {
    this.#status = status;
  };
  /**
   * `.set()` can set the value specified by the key.
   *
   * @see {@link https://hono.dev/docs/api/context#set-get}
   *
   * @example
   * ```ts
   * app.use('*', async (c, next) => {
   *   c.set('message', 'Hono is hot!!')
   *   await next()
   * })
   * ```
   */
  set = (key, value) => {
    this.#var ??= /* @__PURE__ */ new Map();
    this.#var.set(key, value);
  };
  /**
   * `.get()` can use the value specified by the key.
   *
   * @see {@link https://hono.dev/docs/api/context#set-get}
   *
   * @example
   * ```ts
   * app.get('/', (c) => {
   *   const message = c.get('message')
   *   return c.text(`The message is "${message}"`)
   * })
   * ```
   */
  get = (key) => {
    return this.#var ? this.#var.get(key) : void 0;
  };
  /**
   * `.var` can access the value of a variable.
   *
   * @see {@link https://hono.dev/docs/api/context#var}
   *
   * @example
   * ```ts
   * const result = c.var.client.oneMethod()
   * ```
   */
  // c.var.propName is a read-only
  get var() {
    if (!this.#var) {
      return {};
    }
    return Object.fromEntries(this.#var);
  }
  #newResponse(data, arg, headers) {
    const responseHeaders = this.#res ? new Headers(this.#res.headers) : this.#preparedHeaders ?? new Headers();
    if (typeof arg === "object" && "headers" in arg) {
      const argHeaders = arg.headers instanceof Headers ? arg.headers : new Headers(arg.headers);
      for (const [key, value] of argHeaders) {
        if (key.toLowerCase() === "set-cookie") {
          responseHeaders.append(key, value);
        } else {
          responseHeaders.set(key, value);
        }
      }
    }
    if (headers) {
      for (const [k, v] of Object.entries(headers)) {
        if (typeof v === "string") {
          responseHeaders.set(k, v);
        } else {
          responseHeaders.delete(k);
          for (const v2 of v) {
            responseHeaders.append(k, v2);
          }
        }
      }
    }
    const status = typeof arg === "number" ? arg : arg?.status ?? this.#status;
    return createResponseInstance(data, { status, headers: responseHeaders });
  }
  newResponse = (...args) => this.#newResponse(...args);
  /**
   * `.body()` can return the HTTP response.
   * You can set headers with `.header()` and set HTTP status code with `.status`.
   * This can also be set in `.text()`, `.json()` and so on.
   *
   * @see {@link https://hono.dev/docs/api/context#body}
   *
   * @example
   * ```ts
   * app.get('/welcome', (c) => {
   *   // Set headers
   *   c.header('X-Message', 'Hello!')
   *   c.header('Content-Type', 'text/plain')
   *   // Set HTTP status code
   *   c.status(201)
   *
   *   // Return the response body
   *   return c.body('Thank you for coming')
   * })
   * ```
   */
  body = (data, arg, headers) => this.#newResponse(data, arg, headers);
  #useFastPath() {
    return !this.#preparedHeaders && !this.#status && !this.finalized;
  }
  /**
   * `.text()` can render text as `Content-Type:text/plain`.
   *
   * @see {@link https://hono.dev/docs/api/context#text}
   *
   * @example
   * ```ts
   * app.get('/say', (c) => {
   *   return c.text('Hello!')
   * })
   * ```
   */
  text = (text2, arg, headers) => {
    return this.#useFastPath() && !arg && !headers ? createResponseInstance(text2) : this.#newResponse(
      text2,
      arg,
      setDefaultContentType(TEXT_PLAIN, headers)
    );
  };
  /**
   * `.json()` can render JSON as `Content-Type:application/json`.
   *
   * @see {@link https://hono.dev/docs/api/context#json}
   *
   * @example
   * ```ts
   * app.get('/api', (c) => {
   *   return c.json({ message: 'Hello!' })
   * })
   * ```
   */
  json = (object, arg, headers) => {
    return this.#useFastPath() && !arg && !headers ? Response.json(object) : this.#newResponse(
      JSON.stringify(object),
      arg,
      setDefaultContentType("application/json", headers)
    );
  };
  html = (html, arg, headers) => {
    const res = (html2) => this.#newResponse(html2, arg, setDefaultContentType("text/html; charset=UTF-8", headers));
    return typeof html === "object" ? resolveCallback(html, HtmlEscapedCallbackPhase.Stringify, false, {}).then(res) : res(html);
  };
  /**
   * `.redirect()` can Redirect, default status code is 302.
   *
   * @see {@link https://hono.dev/docs/api/context#redirect}
   *
   * @example
   * ```ts
   * app.get('/redirect', (c) => {
   *   return c.redirect('/')
   * })
   * app.get('/redirect-permanently', (c) => {
   *   return c.redirect('/', 301)
   * })
   * ```
   */
  redirect = (location, status) => {
    const locationString = String(location);
    this.header(
      "Location",
      // Multibyes should be encoded
      // eslint-disable-next-line no-control-regex
      !/[^\x00-\xFF]/.test(locationString) ? locationString : encodeURI(locationString)
    );
    return this.newResponse(null, status ?? 302);
  };
  /**
   * `.notFound()` can return the Not Found Response.
   *
   * @see {@link https://hono.dev/docs/api/context#notfound}
   *
   * @example
   * ```ts
   * app.get('/notfound', (c) => {
   *   return c.notFound()
   * })
   * ```
   */
  notFound = () => {
    this.#notFoundHandler ??= () => createResponseInstance();
    return this.#notFoundHandler(this);
  };
};

// .stack/node_modules/hono/dist/router.js
var METHOD_NAME_ALL = "ALL";
var METHOD_NAME_ALL_LOWERCASE = "all";
var METHODS = ["get", "post", "put", "delete", "options", "patch"];
var MESSAGE_MATCHER_IS_ALREADY_BUILT = "Can not add a route since the matcher is already built.";
var UnsupportedPathError = class extends Error {
};

// .stack/node_modules/hono/dist/utils/constants.js
var COMPOSED_HANDLER = "__COMPOSED_HANDLER";

// .stack/node_modules/hono/dist/hono-base.js
var notFoundHandler = (c) => {
  return c.text("404 Not Found", 404);
};
var errorHandler = (err, c) => {
  if ("getResponse" in err) {
    const res = err.getResponse();
    return c.newResponse(res.body, res);
  }
  console.error(err);
  return c.text("Internal Server Error", 500);
};
var Hono = class _Hono {
  get;
  post;
  put;
  delete;
  options;
  patch;
  all;
  on;
  use;
  /*
    This class is like an abstract class and does not have a router.
    To use it, inherit the class and implement router in the constructor.
  */
  router;
  getPath;
  // Cannot use `#` because it requires visibility at JavaScript runtime.
  _basePath = "/";
  #path = "/";
  routes = [];
  constructor(options = {}) {
    const allMethods = [...METHODS, METHOD_NAME_ALL_LOWERCASE];
    allMethods.forEach((method) => {
      this[method] = (args1, ...args) => {
        if (typeof args1 === "string") {
          this.#path = args1;
        } else {
          this.#addRoute(method, this.#path, args1);
        }
        args.forEach((handler) => {
          this.#addRoute(method, this.#path, handler);
        });
        return this;
      };
    });
    this.on = (method, path, ...handlers) => {
      for (const p of [path].flat()) {
        this.#path = p;
        for (const m of [method].flat()) {
          handlers.map((handler) => {
            this.#addRoute(m.toUpperCase(), this.#path, handler);
          });
        }
      }
      return this;
    };
    this.use = (arg1, ...handlers) => {
      if (typeof arg1 === "string") {
        this.#path = arg1;
      } else {
        this.#path = "*";
        handlers.unshift(arg1);
      }
      handlers.forEach((handler) => {
        this.#addRoute(METHOD_NAME_ALL, this.#path, handler);
      });
      return this;
    };
    const { strict, ...optionsWithoutStrict } = options;
    Object.assign(this, optionsWithoutStrict);
    this.getPath = strict ?? true ? options.getPath ?? getPath : getPathNoStrict;
  }
  #clone() {
    const clone = new _Hono({
      router: this.router,
      getPath: this.getPath
    });
    clone.errorHandler = this.errorHandler;
    clone.#notFoundHandler = this.#notFoundHandler;
    clone.routes = this.routes;
    return clone;
  }
  #notFoundHandler = notFoundHandler;
  // Cannot use `#` because it requires visibility at JavaScript runtime.
  errorHandler = errorHandler;
  /**
   * `.route()` allows grouping other Hono instance in routes.
   *
   * @see {@link https://hono.dev/docs/api/routing#grouping}
   *
   * @param {string} path - base Path
   * @param {Hono} app - other Hono instance
   * @returns {Hono} routed Hono instance
   *
   * @example
   * ```ts
   * const app = new Hono()
   * const app2 = new Hono()
   *
   * app2.get("/user", (c) => c.text("user"))
   * app.route("/api", app2) // GET /api/user
   * ```
   */
  route(path, app) {
    const subApp = this.basePath(path);
    app.routes.map((r) => {
      let handler;
      if (app.errorHandler === errorHandler) {
        handler = r.handler;
      } else {
        handler = async (c, next) => (await compose([], app.errorHandler)(c, () => r.handler(c, next))).res;
        handler[COMPOSED_HANDLER] = r.handler;
      }
      subApp.#addRoute(r.method, r.path, handler);
    });
    return this;
  }
  /**
   * `.basePath()` allows base paths to be specified.
   *
   * @see {@link https://hono.dev/docs/api/routing#base-path}
   *
   * @param {string} path - base Path
   * @returns {Hono} changed Hono instance
   *
   * @example
   * ```ts
   * const api = new Hono().basePath('/api')
   * ```
   */
  basePath(path) {
    const subApp = this.#clone();
    subApp._basePath = mergePath(this._basePath, path);
    return subApp;
  }
  /**
   * `.onError()` handles an error and returns a customized Response.
   *
   * @see {@link https://hono.dev/docs/api/hono#error-handling}
   *
   * @param {ErrorHandler} handler - request Handler for error
   * @returns {Hono} changed Hono instance
   *
   * @example
   * ```ts
   * app.onError((err, c) => {
   *   console.error(`${err}`)
   *   return c.text('Custom Error Message', 500)
   * })
   * ```
   */
  onError = (handler) => {
    this.errorHandler = handler;
    return this;
  };
  /**
   * `.notFound()` allows you to customize a Not Found Response.
   *
   * @see {@link https://hono.dev/docs/api/hono#not-found}
   *
   * @param {NotFoundHandler} handler - request handler for not-found
   * @returns {Hono} changed Hono instance
   *
   * @example
   * ```ts
   * app.notFound((c) => {
   *   return c.text('Custom 404 Message', 404)
   * })
   * ```
   */
  notFound = (handler) => {
    this.#notFoundHandler = handler;
    return this;
  };
  /**
   * `.mount()` allows you to mount applications built with other frameworks into your Hono application.
   *
   * @see {@link https://hono.dev/docs/api/hono#mount}
   *
   * @param {string} path - base Path
   * @param {Function} applicationHandler - other Request Handler
   * @param {MountOptions} [options] - options of `.mount()`
   * @returns {Hono} mounted Hono instance
   *
   * @example
   * ```ts
   * import { Router as IttyRouter } from 'itty-router'
   * import { Hono } from 'hono'
   * // Create itty-router application
   * const ittyRouter = IttyRouter()
   * // GET /itty-router/hello
   * ittyRouter.get('/hello', () => new Response('Hello from itty-router'))
   *
   * const app = new Hono()
   * app.mount('/itty-router', ittyRouter.handle)
   * ```
   *
   * @example
   * ```ts
   * const app = new Hono()
   * // Send the request to another application without modification.
   * app.mount('/app', anotherApp, {
   *   replaceRequest: (req) => req,
   * })
   * ```
   */
  mount(path, applicationHandler, options) {
    let replaceRequest;
    let optionHandler;
    if (options) {
      if (typeof options === "function") {
        optionHandler = options;
      } else {
        optionHandler = options.optionHandler;
        if (options.replaceRequest === false) {
          replaceRequest = (request) => request;
        } else {
          replaceRequest = options.replaceRequest;
        }
      }
    }
    const getOptions = optionHandler ? (c) => {
      const options2 = optionHandler(c);
      return Array.isArray(options2) ? options2 : [options2];
    } : (c) => {
      let executionContext = void 0;
      try {
        executionContext = c.executionCtx;
      } catch {
      }
      return [c.env, executionContext];
    };
    replaceRequest ||= (() => {
      const mergedPath = mergePath(this._basePath, path);
      const pathPrefixLength = mergedPath === "/" ? 0 : mergedPath.length;
      return (request) => {
        const url = new URL(request.url);
        url.pathname = url.pathname.slice(pathPrefixLength) || "/";
        return new Request(url, request);
      };
    })();
    const handler = async (c, next) => {
      const res = await applicationHandler(replaceRequest(c.req.raw), ...getOptions(c));
      if (res) {
        return res;
      }
      await next();
    };
    this.#addRoute(METHOD_NAME_ALL, mergePath(path, "*"), handler);
    return this;
  }
  #addRoute(method, path, handler) {
    method = method.toUpperCase();
    path = mergePath(this._basePath, path);
    const r = { basePath: this._basePath, path, method, handler };
    this.router.add(method, path, [handler, r]);
    this.routes.push(r);
  }
  #handleError(err, c) {
    if (err instanceof Error) {
      return this.errorHandler(err, c);
    }
    throw err;
  }
  #dispatch(request, executionCtx, env, method) {
    if (method === "HEAD") {
      return (async () => new Response(null, await this.#dispatch(request, executionCtx, env, "GET")))();
    }
    const path = this.getPath(request, { env });
    const matchResult = this.router.match(method, path);
    const c = new Context(request, {
      path,
      matchResult,
      env,
      executionCtx,
      notFoundHandler: this.#notFoundHandler
    });
    if (matchResult[0].length === 1) {
      let res;
      try {
        res = matchResult[0][0][0][0](c, async () => {
          c.res = await this.#notFoundHandler(c);
        });
      } catch (err) {
        return this.#handleError(err, c);
      }
      return res instanceof Promise ? res.then(
        (resolved) => resolved || (c.finalized ? c.res : this.#notFoundHandler(c))
      ).catch((err) => this.#handleError(err, c)) : res ?? this.#notFoundHandler(c);
    }
    const composed = compose(matchResult[0], this.errorHandler, this.#notFoundHandler);
    return (async () => {
      try {
        const context = await composed(c);
        if (!context.finalized) {
          throw new Error(
            "Context is not finalized. Did you forget to return a Response object or `await next()`?"
          );
        }
        return context.res;
      } catch (err) {
        return this.#handleError(err, c);
      }
    })();
  }
  /**
   * `.fetch()` will be entry point of your app.
   *
   * @see {@link https://hono.dev/docs/api/hono#fetch}
   *
   * @param {Request} request - request Object of request
   * @param {Env} Env - env Object
   * @param {ExecutionContext} - context of execution
   * @returns {Response | Promise<Response>} response of request
   *
   */
  fetch = (request, ...rest) => {
    return this.#dispatch(request, rest[1], rest[0], request.method);
  };
  /**
   * `.request()` is a useful method for testing.
   * You can pass a URL or pathname to send a GET request.
   * app will return a Response object.
   * ```ts
   * test('GET /hello is ok', async () => {
   *   const res = await app.request('/hello')
   *   expect(res.status).toBe(200)
   * })
   * ```
   * @see https://hono.dev/docs/api/hono#request
   */
  request = (input, requestInit, Env, executionCtx) => {
    if (input instanceof Request) {
      return this.fetch(requestInit ? new Request(input, requestInit) : input, Env, executionCtx);
    }
    input = input.toString();
    return this.fetch(
      new Request(
        /^https?:\/\//.test(input) ? input : `http://localhost${mergePath("/", input)}`,
        requestInit
      ),
      Env,
      executionCtx
    );
  };
  /**
   * `.fire()` automatically adds a global fetch event listener.
   * This can be useful for environments that adhere to the Service Worker API, such as non-ES module Cloudflare Workers.
   * @deprecated
   * Use `fire` from `hono/service-worker` instead.
   * ```ts
   * import { Hono } from 'hono'
   * import { fire } from 'hono/service-worker'
   *
   * const app = new Hono()
   * // ...
   * fire(app)
   * ```
   * @see https://hono.dev/docs/api/hono#fire
   * @see https://developer.mozilla.org/en-US/docs/Web/API/Service_Worker_API
   * @see https://developers.cloudflare.com/workers/reference/migrate-to-module-workers/
   */
  fire = () => {
    addEventListener("fetch", (event) => {
      event.respondWith(this.#dispatch(event.request, event, void 0, event.request.method));
    });
  };
};

// .stack/node_modules/hono/dist/router/reg-exp-router/matcher.js
var emptyParam = [];
function match(method, path) {
  const matchers = this.buildAllMatchers();
  const match2 = ((method2, path2) => {
    const matcher = matchers[method2] || matchers[METHOD_NAME_ALL];
    const staticMatch = matcher[2][path2];
    if (staticMatch) {
      return staticMatch;
    }
    const match3 = path2.match(matcher[0]);
    if (!match3) {
      return [[], emptyParam];
    }
    const index = match3.indexOf("", 1);
    return [matcher[1][index], match3];
  });
  this.match = match2;
  return match2(method, path);
}

// .stack/node_modules/hono/dist/router/reg-exp-router/node.js
var LABEL_REG_EXP_STR = "[^/]+";
var ONLY_WILDCARD_REG_EXP_STR = ".*";
var TAIL_WILDCARD_REG_EXP_STR = "(?:|/.*)";
var PATH_ERROR = /* @__PURE__ */ Symbol();
var regExpMetaChars = new Set(".\\+*[^]$()");
function compareKey(a, b) {
  if (a.length === 1) {
    return b.length === 1 ? a < b ? -1 : 1 : -1;
  }
  if (b.length === 1) {
    return 1;
  }
  if (a === ONLY_WILDCARD_REG_EXP_STR || a === TAIL_WILDCARD_REG_EXP_STR) {
    return 1;
  } else if (b === ONLY_WILDCARD_REG_EXP_STR || b === TAIL_WILDCARD_REG_EXP_STR) {
    return -1;
  }
  if (a === LABEL_REG_EXP_STR) {
    return 1;
  } else if (b === LABEL_REG_EXP_STR) {
    return -1;
  }
  return a.length === b.length ? a < b ? -1 : 1 : b.length - a.length;
}
var Node = class _Node {
  #index;
  #varIndex;
  #children = /* @__PURE__ */ Object.create(null);
  insert(tokens, index, paramMap, context, pathErrorCheckOnly) {
    if (tokens.length === 0) {
      if (this.#index !== void 0) {
        throw PATH_ERROR;
      }
      if (pathErrorCheckOnly) {
        return;
      }
      this.#index = index;
      return;
    }
    const [token, ...restTokens] = tokens;
    const pattern = token === "*" ? restTokens.length === 0 ? ["", "", ONLY_WILDCARD_REG_EXP_STR] : ["", "", LABEL_REG_EXP_STR] : token === "/*" ? ["", "", TAIL_WILDCARD_REG_EXP_STR] : token.match(/^\:([^\{\}]+)(?:\{(.+)\})?$/);
    let node;
    if (pattern) {
      const name = pattern[1];
      let regexpStr = pattern[2] || LABEL_REG_EXP_STR;
      if (name && pattern[2]) {
        if (regexpStr === ".*") {
          throw PATH_ERROR;
        }
        regexpStr = regexpStr.replace(/^\((?!\?:)(?=[^)]+\)$)/, "(?:");
        if (/\((?!\?:)/.test(regexpStr)) {
          throw PATH_ERROR;
        }
      }
      node = this.#children[regexpStr];
      if (!node) {
        if (Object.keys(this.#children).some(
          (k) => k !== ONLY_WILDCARD_REG_EXP_STR && k !== TAIL_WILDCARD_REG_EXP_STR
        )) {
          throw PATH_ERROR;
        }
        if (pathErrorCheckOnly) {
          return;
        }
        node = this.#children[regexpStr] = new _Node();
        if (name !== "") {
          node.#varIndex = context.varIndex++;
        }
      }
      if (!pathErrorCheckOnly && name !== "") {
        paramMap.push([name, node.#varIndex]);
      }
    } else {
      node = this.#children[token];
      if (!node) {
        if (Object.keys(this.#children).some(
          (k) => k.length > 1 && k !== ONLY_WILDCARD_REG_EXP_STR && k !== TAIL_WILDCARD_REG_EXP_STR
        )) {
          throw PATH_ERROR;
        }
        if (pathErrorCheckOnly) {
          return;
        }
        node = this.#children[token] = new _Node();
      }
    }
    node.insert(restTokens, index, paramMap, context, pathErrorCheckOnly);
  }
  buildRegExpStr() {
    const childKeys = Object.keys(this.#children).sort(compareKey);
    const strList = childKeys.map((k) => {
      const c = this.#children[k];
      return (typeof c.#varIndex === "number" ? `(${k})@${c.#varIndex}` : regExpMetaChars.has(k) ? `\\${k}` : k) + c.buildRegExpStr();
    });
    if (typeof this.#index === "number") {
      strList.unshift(`#${this.#index}`);
    }
    if (strList.length === 0) {
      return "";
    }
    if (strList.length === 1) {
      return strList[0];
    }
    return "(?:" + strList.join("|") + ")";
  }
};

// .stack/node_modules/hono/dist/router/reg-exp-router/trie.js
var Trie = class {
  #context = { varIndex: 0 };
  #root = new Node();
  insert(path, index, pathErrorCheckOnly) {
    const paramAssoc = [];
    const groups = [];
    for (let i = 0; ; ) {
      let replaced = false;
      path = path.replace(/\{[^}]+\}/g, (m) => {
        const mark = `@\\${i}`;
        groups[i] = [mark, m];
        i++;
        replaced = true;
        return mark;
      });
      if (!replaced) {
        break;
      }
    }
    const tokens = path.match(/(?::[^\/]+)|(?:\/\*$)|./g) || [];
    for (let i = groups.length - 1; i >= 0; i--) {
      const [mark] = groups[i];
      for (let j = tokens.length - 1; j >= 0; j--) {
        if (tokens[j].indexOf(mark) !== -1) {
          tokens[j] = tokens[j].replace(mark, groups[i][1]);
          break;
        }
      }
    }
    this.#root.insert(tokens, index, paramAssoc, this.#context, pathErrorCheckOnly);
    return paramAssoc;
  }
  buildRegExp() {
    let regexp = this.#root.buildRegExpStr();
    if (regexp === "") {
      return [/^$/, [], []];
    }
    let captureIndex = 0;
    const indexReplacementMap = [];
    const paramReplacementMap = [];
    regexp = regexp.replace(/#(\d+)|@(\d+)|\.\*\$/g, (_, handlerIndex, paramIndex) => {
      if (handlerIndex !== void 0) {
        indexReplacementMap[++captureIndex] = Number(handlerIndex);
        return "$()";
      }
      if (paramIndex !== void 0) {
        paramReplacementMap[Number(paramIndex)] = ++captureIndex;
        return "";
      }
      return "";
    });
    return [new RegExp(`^${regexp}`), indexReplacementMap, paramReplacementMap];
  }
};

// .stack/node_modules/hono/dist/router/reg-exp-router/router.js
var nullMatcher = [/^$/, [], /* @__PURE__ */ Object.create(null)];
var wildcardRegExpCache = /* @__PURE__ */ Object.create(null);
function buildWildcardRegExp(path) {
  return wildcardRegExpCache[path] ??= new RegExp(
    path === "*" ? "" : `^${path.replace(
      /\/\*$|([.\\+*[^\]$()])/g,
      (_, metaChar) => metaChar ? `\\${metaChar}` : "(?:|/.*)"
    )}$`
  );
}
function clearWildcardRegExpCache() {
  wildcardRegExpCache = /* @__PURE__ */ Object.create(null);
}
function buildMatcherFromPreprocessedRoutes(routes) {
  const trie = new Trie();
  const handlerData = [];
  if (routes.length === 0) {
    return nullMatcher;
  }
  const routesWithStaticPathFlag = routes.map(
    (route) => [!/\*|\/:/.test(route[0]), ...route]
  ).sort(
    ([isStaticA, pathA], [isStaticB, pathB]) => isStaticA ? 1 : isStaticB ? -1 : pathA.length - pathB.length
  );
  const staticMap = /* @__PURE__ */ Object.create(null);
  for (let i = 0, j = -1, len = routesWithStaticPathFlag.length; i < len; i++) {
    const [pathErrorCheckOnly, path, handlers] = routesWithStaticPathFlag[i];
    if (pathErrorCheckOnly) {
      staticMap[path] = [handlers.map(([h]) => [h, /* @__PURE__ */ Object.create(null)]), emptyParam];
    } else {
      j++;
    }
    let paramAssoc;
    try {
      paramAssoc = trie.insert(path, j, pathErrorCheckOnly);
    } catch (e) {
      throw e === PATH_ERROR ? new UnsupportedPathError(path) : e;
    }
    if (pathErrorCheckOnly) {
      continue;
    }
    handlerData[j] = handlers.map(([h, paramCount]) => {
      const paramIndexMap = /* @__PURE__ */ Object.create(null);
      paramCount -= 1;
      for (; paramCount >= 0; paramCount--) {
        const [key, value] = paramAssoc[paramCount];
        paramIndexMap[key] = value;
      }
      return [h, paramIndexMap];
    });
  }
  const [regexp, indexReplacementMap, paramReplacementMap] = trie.buildRegExp();
  for (let i = 0, len = handlerData.length; i < len; i++) {
    for (let j = 0, len2 = handlerData[i].length; j < len2; j++) {
      const map = handlerData[i][j]?.[1];
      if (!map) {
        continue;
      }
      const keys = Object.keys(map);
      for (let k = 0, len3 = keys.length; k < len3; k++) {
        map[keys[k]] = paramReplacementMap[map[keys[k]]];
      }
    }
  }
  const handlerMap = [];
  for (const i in indexReplacementMap) {
    handlerMap[i] = handlerData[indexReplacementMap[i]];
  }
  return [regexp, handlerMap, staticMap];
}
function findMiddleware(middleware, path) {
  if (!middleware) {
    return void 0;
  }
  for (const k of Object.keys(middleware).sort((a, b) => b.length - a.length)) {
    if (buildWildcardRegExp(k).test(path)) {
      return [...middleware[k]];
    }
  }
  return void 0;
}
var RegExpRouter = class {
  name = "RegExpRouter";
  #middleware;
  #routes;
  constructor() {
    this.#middleware = { [METHOD_NAME_ALL]: /* @__PURE__ */ Object.create(null) };
    this.#routes = { [METHOD_NAME_ALL]: /* @__PURE__ */ Object.create(null) };
  }
  add(method, path, handler) {
    const middleware = this.#middleware;
    const routes = this.#routes;
    if (!middleware || !routes) {
      throw new Error(MESSAGE_MATCHER_IS_ALREADY_BUILT);
    }
    if (!middleware[method]) {
      ;
      [middleware, routes].forEach((handlerMap) => {
        handlerMap[method] = /* @__PURE__ */ Object.create(null);
        Object.keys(handlerMap[METHOD_NAME_ALL]).forEach((p) => {
          handlerMap[method][p] = [...handlerMap[METHOD_NAME_ALL][p]];
        });
      });
    }
    if (path === "/*") {
      path = "*";
    }
    const paramCount = (path.match(/\/:/g) || []).length;
    if (/\*$/.test(path)) {
      const re = buildWildcardRegExp(path);
      if (method === METHOD_NAME_ALL) {
        Object.keys(middleware).forEach((m) => {
          middleware[m][path] ||= findMiddleware(middleware[m], path) || findMiddleware(middleware[METHOD_NAME_ALL], path) || [];
        });
      } else {
        middleware[method][path] ||= findMiddleware(middleware[method], path) || findMiddleware(middleware[METHOD_NAME_ALL], path) || [];
      }
      Object.keys(middleware).forEach((m) => {
        if (method === METHOD_NAME_ALL || method === m) {
          Object.keys(middleware[m]).forEach((p) => {
            re.test(p) && middleware[m][p].push([handler, paramCount]);
          });
        }
      });
      Object.keys(routes).forEach((m) => {
        if (method === METHOD_NAME_ALL || method === m) {
          Object.keys(routes[m]).forEach(
            (p) => re.test(p) && routes[m][p].push([handler, paramCount])
          );
        }
      });
      return;
    }
    const paths = checkOptionalParameter(path) || [path];
    for (let i = 0, len = paths.length; i < len; i++) {
      const path2 = paths[i];
      Object.keys(routes).forEach((m) => {
        if (method === METHOD_NAME_ALL || method === m) {
          routes[m][path2] ||= [
            ...findMiddleware(middleware[m], path2) || findMiddleware(middleware[METHOD_NAME_ALL], path2) || []
          ];
          routes[m][path2].push([handler, paramCount - len + i + 1]);
        }
      });
    }
  }
  match = match;
  buildAllMatchers() {
    const matchers = /* @__PURE__ */ Object.create(null);
    Object.keys(this.#routes).concat(Object.keys(this.#middleware)).forEach((method) => {
      matchers[method] ||= this.#buildMatcher(method);
    });
    this.#middleware = this.#routes = void 0;
    clearWildcardRegExpCache();
    return matchers;
  }
  #buildMatcher(method) {
    const routes = [];
    let hasOwnRoute = method === METHOD_NAME_ALL;
    [this.#middleware, this.#routes].forEach((r) => {
      const ownRoute = r[method] ? Object.keys(r[method]).map((path) => [path, r[method][path]]) : [];
      if (ownRoute.length !== 0) {
        hasOwnRoute ||= true;
        routes.push(...ownRoute);
      } else if (method !== METHOD_NAME_ALL) {
        routes.push(
          ...Object.keys(r[METHOD_NAME_ALL]).map((path) => [path, r[METHOD_NAME_ALL][path]])
        );
      }
    });
    if (!hasOwnRoute) {
      return null;
    } else {
      return buildMatcherFromPreprocessedRoutes(routes);
    }
  }
};

// .stack/node_modules/hono/dist/router/smart-router/router.js
var SmartRouter = class {
  name = "SmartRouter";
  #routers = [];
  #routes = [];
  constructor(init) {
    this.#routers = init.routers;
  }
  add(method, path, handler) {
    if (!this.#routes) {
      throw new Error(MESSAGE_MATCHER_IS_ALREADY_BUILT);
    }
    this.#routes.push([method, path, handler]);
  }
  match(method, path) {
    if (!this.#routes) {
      throw new Error("Fatal error");
    }
    const routers = this.#routers;
    const routes = this.#routes;
    const len = routers.length;
    let i = 0;
    let res;
    for (; i < len; i++) {
      const router = routers[i];
      try {
        for (let i2 = 0, len2 = routes.length; i2 < len2; i2++) {
          router.add(...routes[i2]);
        }
        res = router.match(method, path);
      } catch (e) {
        if (e instanceof UnsupportedPathError) {
          continue;
        }
        throw e;
      }
      this.match = router.match.bind(router);
      this.#routers = [router];
      this.#routes = void 0;
      break;
    }
    if (i === len) {
      throw new Error("Fatal error");
    }
    this.name = `SmartRouter + ${this.activeRouter.name}`;
    return res;
  }
  get activeRouter() {
    if (this.#routes || this.#routers.length !== 1) {
      throw new Error("No active router has been determined yet.");
    }
    return this.#routers[0];
  }
};

// .stack/node_modules/hono/dist/router/trie-router/node.js
var emptyParams = /* @__PURE__ */ Object.create(null);
var hasChildren = (children) => {
  for (const _ in children) {
    return true;
  }
  return false;
};
var Node2 = class _Node2 {
  #methods;
  #children;
  #patterns;
  #order = 0;
  #params = emptyParams;
  constructor(method, handler, children) {
    this.#children = children || /* @__PURE__ */ Object.create(null);
    this.#methods = [];
    if (method && handler) {
      const m = /* @__PURE__ */ Object.create(null);
      m[method] = { handler, possibleKeys: [], score: 0 };
      this.#methods = [m];
    }
    this.#patterns = [];
  }
  insert(method, path, handler) {
    this.#order = ++this.#order;
    let curNode = this;
    const parts = splitRoutingPath(path);
    const possibleKeys = [];
    for (let i = 0, len = parts.length; i < len; i++) {
      const p = parts[i];
      const nextP = parts[i + 1];
      const pattern = getPattern(p, nextP);
      const key = Array.isArray(pattern) ? pattern[0] : p;
      if (key in curNode.#children) {
        curNode = curNode.#children[key];
        if (pattern) {
          possibleKeys.push(pattern[1]);
        }
        continue;
      }
      curNode.#children[key] = new _Node2();
      if (pattern) {
        curNode.#patterns.push(pattern);
        possibleKeys.push(pattern[1]);
      }
      curNode = curNode.#children[key];
    }
    curNode.#methods.push({
      [method]: {
        handler,
        possibleKeys: possibleKeys.filter((v, i, a) => a.indexOf(v) === i),
        score: this.#order
      }
    });
    return curNode;
  }
  #pushHandlerSets(handlerSets, node, method, nodeParams, params) {
    for (let i = 0, len = node.#methods.length; i < len; i++) {
      const m = node.#methods[i];
      const handlerSet = m[method] || m[METHOD_NAME_ALL];
      const processedSet = {};
      if (handlerSet !== void 0) {
        handlerSet.params = /* @__PURE__ */ Object.create(null);
        handlerSets.push(handlerSet);
        if (nodeParams !== emptyParams || params && params !== emptyParams) {
          for (let i2 = 0, len2 = handlerSet.possibleKeys.length; i2 < len2; i2++) {
            const key = handlerSet.possibleKeys[i2];
            const processed = processedSet[handlerSet.score];
            handlerSet.params[key] = params?.[key] && !processed ? params[key] : nodeParams[key] ?? params?.[key];
            processedSet[handlerSet.score] = true;
          }
        }
      }
    }
  }
  search(method, path) {
    const handlerSets = [];
    this.#params = emptyParams;
    const curNode = this;
    let curNodes = [curNode];
    const parts = splitPath(path);
    const curNodesQueue = [];
    const len = parts.length;
    let partOffsets = null;
    for (let i = 0; i < len; i++) {
      const part = parts[i];
      const isLast = i === len - 1;
      const tempNodes = [];
      for (let j = 0, len2 = curNodes.length; j < len2; j++) {
        const node = curNodes[j];
        const nextNode = node.#children[part];
        if (nextNode) {
          nextNode.#params = node.#params;
          if (isLast) {
            if (nextNode.#children["*"]) {
              this.#pushHandlerSets(handlerSets, nextNode.#children["*"], method, node.#params);
            }
            this.#pushHandlerSets(handlerSets, nextNode, method, node.#params);
          } else {
            tempNodes.push(nextNode);
          }
        }
        for (let k = 0, len3 = node.#patterns.length; k < len3; k++) {
          const pattern = node.#patterns[k];
          const params = node.#params === emptyParams ? {} : { ...node.#params };
          if (pattern === "*") {
            const astNode = node.#children["*"];
            if (astNode) {
              this.#pushHandlerSets(handlerSets, astNode, method, node.#params);
              astNode.#params = params;
              tempNodes.push(astNode);
            }
            continue;
          }
          const [key, name, matcher] = pattern;
          if (!part && !(matcher instanceof RegExp)) {
            continue;
          }
          const child = node.#children[key];
          if (matcher instanceof RegExp) {
            if (partOffsets === null) {
              partOffsets = new Array(len);
              let offset = path[0] === "/" ? 1 : 0;
              for (let p = 0; p < len; p++) {
                partOffsets[p] = offset;
                offset += parts[p].length + 1;
              }
            }
            const restPathString = path.substring(partOffsets[i]);
            const m = matcher.exec(restPathString);
            if (m) {
              params[name] = m[0];
              this.#pushHandlerSets(handlerSets, child, method, node.#params, params);
              if (hasChildren(child.#children)) {
                child.#params = params;
                const componentCount = m[0].match(/\//)?.length ?? 0;
                const targetCurNodes = curNodesQueue[componentCount] ||= [];
                targetCurNodes.push(child);
              }
              continue;
            }
          }
          if (matcher === true || matcher.test(part)) {
            params[name] = part;
            if (isLast) {
              this.#pushHandlerSets(handlerSets, child, method, params, node.#params);
              if (child.#children["*"]) {
                this.#pushHandlerSets(
                  handlerSets,
                  child.#children["*"],
                  method,
                  params,
                  node.#params
                );
              }
            } else {
              child.#params = params;
              tempNodes.push(child);
            }
          }
        }
      }
      const shifted = curNodesQueue.shift();
      curNodes = shifted ? tempNodes.concat(shifted) : tempNodes;
    }
    if (handlerSets.length > 1) {
      handlerSets.sort((a, b) => {
        return a.score - b.score;
      });
    }
    return [handlerSets.map(({ handler, params }) => [handler, params])];
  }
};

// .stack/node_modules/hono/dist/router/trie-router/router.js
var TrieRouter = class {
  name = "TrieRouter";
  #node;
  constructor() {
    this.#node = new Node2();
  }
  add(method, path, handler) {
    const results = checkOptionalParameter(path);
    if (results) {
      for (let i = 0, len = results.length; i < len; i++) {
        this.#node.insert(method, results[i], handler);
      }
      return;
    }
    this.#node.insert(method, path, handler);
  }
  match(method, path) {
    return this.#node.search(method, path);
  }
};

// .stack/node_modules/hono/dist/hono.js
var Hono2 = class extends Hono {
  /**
   * Creates an instance of the Hono class.
   *
   * @param options - Optional configuration options for the Hono instance.
   */
  constructor(options = {}) {
    super(options);
    this.router = options.router ?? new SmartRouter({
      routers: [new RegExpRouter(), new TrieRouter()]
    });
  }
};

// server/command.mjs
var BY_STATUS = { 400: "BAD_INPUT", 403: "NOT_ALLOWED", 404: "NOT_FOUND", 424: "MISSING_KEYS", 502: "SITE_FAILED", 504: "SITE_TIMEOUT" };
var Refused = class extends Error {
  constructor(message, status = 409, extra = {}) {
    super(message);
    this.status = status;
    this.code = extra.code ?? (/^Only a person/.test(message) ? "PERSON_ONLY" : BY_STATUS[status] ?? "REFUSED");
    if (extra.item !== void 0) this.item = extra.item;
  }
};
var commandsOf = (app) => app.commands ??= [];
var inputNames = (input) => Array.isArray(input) ? input.flatMap((x) => typeof x === "string" ? [x] : Object.keys(x)) : Object.keys(input ?? {});
function command(app, method, path, spec, handler) {
  commandsOf(app).push({ ...spec, method, path, input: spec.input ?? {}, by: spec.by ?? "anyone", read: method === "GET" });
  app.on(method, path, async (c) => {
    const actor = c.req.header("x-actor") || "";
    if (spec.by === "person" && !actor.startsWith("person:")) throw new Refused(`Only a person can do this: ask them. (${spec.name})`, 403);
    const body = method === "GET" ? c.req.query() : await c.req.json().catch(() => ({}));
    const input = {};
    for (const k of inputNames(spec.input)) if (body[k] !== void 0) input[k] = body[k];
    for (const [k, v] of Object.entries(c.req.param())) input[k] = /^\d+$/.test(v) ? Number(v) : v;
    return c.json(await handler(input, { actor }) ?? { ok: true });
  });
}
function mountErrors(app) {
  app.onError((e, c) => c.json({ error: e.message, code: e.code ?? (e.status && e.status < 500 ? "REFUSED" : "FAILED"), ...e.item !== void 0 ? { item: e.item } : {} }, e.status ?? 500));
  app.get("/_commands", (c) => c.json(commandsOf(app)));
}

// server/services/util.mjs
var T = {
  projects: "obras_projects",
  units: "obras_units",
  chapters: "obras_chapters",
  incidents: "obras_incidents",
  notes: "obras_notes",
  visits: "obras_visits",
  procedures: "obras_procedures",
  reports: "obras_reports",
  attachments: "obras_attachments",
  hours: "obras_hours",
  settings: "obras_settings"
};
var LIVE = "_deleted = 0 AND COALESCE(removed, 0) = 0";
var isPerson = (actor) => String(actor || "").startsWith("person:");
var wantsFull = (i, actor) => isPerson(actor) || i.full === true || i.full === "true";
var who = (actor) => String(actor || "").replace(/^(person|agent):/, "") || "agent";
var today = (now = /* @__PURE__ */ new Date()) => new Intl.DateTimeFormat("sv-SE", { timeZone: "Europe/Madrid" }).format(now);
var ISO = /^(\d{4})-(\d{2})-(\d{2})$/;
function dateOf(v, field = "date") {
  if (v === void 0 || v === null || v === "") return null;
  const s = String(v).trim().slice(0, 10);
  const dmy = /^(\d{1,2})[/.-](\d{1,2})[/.-](\d{4})$/.exec(String(v).trim());
  const iso = dmy ? `${dmy[3]}-${dmy[2].padStart(2, "0")}-${dmy[1].padStart(2, "0")}` : s;
  const m = ISO.exec(iso);
  if (!m || Number(m[2]) < 1 || Number(m[2]) > 12 || Number(m[3]) < 1 || Number(m[3]) > 31) throw new Refused(`${field} is a date written YYYY-MM-DD (got "${String(v).slice(0, 30)}").`, 400, { code: "BAD_DATE" });
  return iso;
}
var daysBetween = (from, to) => Math.round((Date.parse(to + "T00:00:00Z") - Date.parse(from + "T00:00:00Z")) / 864e5);
var addDays = (date, n) => new Date(Date.parse(date + "T00:00:00Z") + n * 864e5).toISOString().slice(0, 10);
var text = (v, max = 4e3) => v === void 0 || v === null ? null : String(v).trim().slice(0, max);
var bool = (v) => v === true || v === 1 || v === "1" || v === "true" ? 1 : 0;
function int(v, field = "number") {
  if (v === void 0 || v === null || v === "") return null;
  const n = Number(v);
  if (!Number.isFinite(n)) throw new Refused(`${field} is a number (got "${String(v).slice(0, 30)}").`, 400, { code: "BAD_NUMBER" });
  return Math.round(n);
}
function cents(v, field = "amount") {
  if (v === void 0 || v === null || v === "") return null;
  const n = Number(typeof v === "string" ? v.replace(/\s|€/g, "").replace(/\.(?=\d{3}(\D|$))/g, "").replace(",", ".") : v);
  if (!Number.isFinite(n)) throw new Refused(`${field} is an amount in euros, as a number (got "${String(v).slice(0, 30)}").`, 400, { code: "BAD_NUMBER" });
  return Math.round(n * 100);
}
var euros = (c) => c === void 0 || c === null ? null : c / 100;
function listOf(v, name) {
  if (Array.isArray(v)) return v;
  if (typeof v === "string" && v.trim().startsWith("[")) {
    try {
      const j = JSON.parse(v);
      if (Array.isArray(j)) return j;
    } catch {
    }
  }
  throw new Refused(`${name} is a list: ${name}: [ \u2026 ].`, 400, { code: "BAD_INPUT" });
}
function choiceOf(v, words, field) {
  if (v === void 0 || v === null || v === "") return null;
  const k = String(v).trim().toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "");
  for (const [key, list5] of Object.entries(words)) if (key === k || list5.includes(k)) return key;
  throw new Refused(`${field} is one of: ${Object.keys(words).join(", ")} (got "${String(v).slice(0, 30)}").`, 400, { code: "BAD_CHOICE" });
}
var sent = (o) => Object.fromEntries(Object.entries(o).filter(([, v]) => v !== void 0));
var count = async (db, sql, params = []) => Number((await db.one(sql, params))?.n ?? 0);

// server/services/template.mjs
var C = (code, name, subs = []) => [{ code, name, parent: "" }, ...subs.map(([c, n]) => ({ code: c, name: n, parent: code }))];
var DEFAULT_CHAPTERS = [
  ...C("01", "Inicials", [["11", "Actuacions Pr\xE8vies"], ["12", "Estudis i Inspeccions"]]),
  ...C("02", "Projectes", [["21", "Arquitecte"], ["22", "Arquitecte T\xE8cnic"], ["23", "Altres t\xE8cnics"], ["24", "Altres (OCT)"]]),
  ...C("03", "Execuci\xF3", [
    ["D", "Enderrocs i Previs"],
    ["A", "Condicionament del Terreny"],
    ["C", "Fonamentaci\xF3"],
    ["E", "Estructura"],
    ["F", "Fa\xE7anes i Particions"],
    ["L", "Fusteria, Manyeria, Vidres i Proteccions Solars"],
    ["I", "Instal\xB7lacions"],
    ["N", "A\xEFllaments i Impermeabilitzacions"],
    ["Q", "Cobertes"],
    ["R", "Revestiments i Extradossats"],
    ["S", "Senyalitzaci\xF3 i Equipament"],
    ["G", "Gesti\xF3 de Residus"],
    ["X", "Control de Qualitat i Assaigs"],
    ["Y", "Seguretat i Salut"],
    ["W", "Extres i Opcionals"],
    ["U", "Urbanitzaci\xF3, Jardineria i Altres"],
    ["Z", "Altres"]
  ]),
  ...C("04", "Permisos i Legalitzacions", [["41", "Subministraments"], ["42", "Col\xB7legis Professionals"], ["43", "Permisos, Certificats i Llic\xE8ncies"], ["44", "Dip\xF2sits de Garantia"]]),
  ...C("05", "Escomeses i Consums", [["51", "Escomeses"], ["52", "Consums"]]),
  ...C("06", "Assegurances", [["61", "Obra (TRC, Decennal)"], ["62", "Finca Existent (RC)"]]),
  ...C("07", "Jur\xEDdic i Financer"),
  ...C("08", "Comercial i M\xE0rqueting"),
  ...C("09", "Vendes", [["71", "Habitatges"], ["72", "Locals"], ["73", "Aparcaments"]])
];

// server/services/projects.mjs
var UNIT_KINDS = { habitatge: ["vivienda", "viviendas", "habitatges", "home", "homes", "piso", "pisos"], local: ["locals", "locales", "premises"], aparcament: ["aparcaments", "aparcamiento", "aparcamientos", "parking", "plaza", "plazas"], traster: ["trasters", "trastero", "trasteros", "storage"], altre: ["otro", "otros", "altres", "other"] };
var UNIT_STATES = { available: ["disponible", "lliure", "libre"], reserved: ["reservado", "reservat", "reservada"], sold: ["vendido", "vendida", "venut", "venuda"] };
var PROJECT_STATES = { active: ["activa", "en marcha", "en curso", "en curs"], finished: ["terminada", "acabada", "finalizada"], archived: ["archivada", "arxivada"] };
var UNIT_NAME = { habitatge: "Habitatge", local: "Local", aparcament: "Aparcament", traster: "Traster", altre: "Unitat" };
async function projectOf(db, id) {
  const n = Number(id);
  const p = Number.isInteger(n) && n > 0 ? await db.one(`SELECT * FROM ${T.projects} WHERE _id = ? AND ${LIVE}`, [n]) : null;
  if (!p) throw new Refused(id === void 0 || id === null || id === "" ? "Say which project: project_id. List them with projects." : `There is no project ${id}. List them with projects.`, id ? 404 : 400, { code: id ? "NOT_FOUND" : "PROJECT_REQUIRED", ...id ? { item: id } : {} });
  return p;
}
async function chaptersOf(db, projectId) {
  return (await db.all(`SELECT code, name, parent FROM ${T.chapters} WHERE project_id = ? AND ${LIVE} ORDER BY position, _id`, [projectId])).map((c) => ({ code: c.code, name: c.name, parent: c.parent || "" }));
}
function chapterTree(chapters) {
  const top = chapters.filter((c) => !c.parent).map((c) => ({ code: c.code, name: c.name, subs: [] }));
  for (const c of chapters) if (c.parent) top.find((t) => t.code === c.parent)?.subs.push({ code: c.code, name: c.name });
  return top;
}
function chapterProblems(chapters) {
  const p = [];
  const tops = /* @__PURE__ */ new Set();
  const seen = /* @__PURE__ */ new Set();
  for (const c of chapters) if (!c.parent) tops.add(c.code);
  for (const [i, c] of chapters.entries()) {
    if (!/^[A-Za-z0-9]{1,6}$/.test(c.code || "")) p.push(`Line ${i + 1}: a code is 1 to 6 letters or digits (got "${c.code}").`);
    if (!c.name) p.push(`Line ${i + 1}: ${c.code} has no name.`);
    if (c.parent && !tops.has(c.parent)) p.push(`Line ${i + 1}: ${c.code} is under ${c.parent}, which is not a chapter.`);
    const key = `${c.parent}/${c.code}`;
    if (seen.has(key)) p.push(`Line ${i + 1}: ${c.parent ? c.parent + "/" : ""}${c.code} is repeated.`);
    seen.add(key);
  }
  if (!tops.size) p.push('There is no chapter: at least one line like "03 Execuci\xF3".');
  return p;
}
function parseChapters(input) {
  if (Array.isArray(input)) return input.map((c) => ({ code: String(c.code ?? "").trim(), name: String(c.name ?? "").trim(), parent: String(c.parent ?? c.parent_code ?? "").trim() }));
  const out = [];
  let last = "";
  for (const raw2 of String(input ?? "").split("\n")) {
    if (!raw2.trim()) continue;
    const indented = /^\s+/.test(raw2);
    const m = /^\s*(?:([A-Za-z0-9]+)\/)?([A-Za-z0-9]+)[\s.:—-]+(.+)$/.exec(raw2);
    if (!m) {
      out.push({ code: raw2.trim().slice(0, 12), name: "", parent: "" });
      continue;
    }
    const parent = m[1] || (indented ? last : "");
    if (!parent) last = m[2];
    out.push({ code: m[2], name: m[3].trim(), parent });
  }
  return out;
}
async function insertChapters(db, projectId, chapters) {
  await db.batch(chapters.map((c, i) => ({ op: "insert", table: T.chapters, data: { project_id: projectId, code: c.code, name: c.name, parent: c.parent || "", position: i, removed: 0 } })));
}
function unitsFrom(input, startAt = {}) {
  const out = [];
  const next = { ...startAt };
  for (const u of input) {
    const kind = choiceOf(u.kind ?? "habitatge", UNIT_KINDS, "kind");
    const state = choiceOf(u.state ?? "available", UNIT_STATES, "state");
    const n = u.count === void 0 ? 1 : int(u.count, "count");
    if (n < 1 || n > 500) throw new Refused("count is between 1 and 500.", 400, { code: "BAD_NUMBER" });
    for (let i = 0; i < n; i++) {
      next[kind] = (next[kind] ?? 0) + 1;
      out.push({ kind, state, name: n === 1 && text(u.name, 120) ? text(u.name, 120) : `${text(u.name, 100) || UNIT_NAME[kind]} ${next[kind]}` });
    }
  }
  return out;
}
var shape = (p) => ({ id: p._id, name: p.name, code: p.code || "", address: p.address || "", city: p.city || "", client: p.client || "", state: p.state || "active", started_on: p.started_on || null, notes: p.notes || "", ...p.demo ? { demo: true } : {} });
async function list(db, { state } = {}) {
  const rows = await db.all(`SELECT * FROM ${T.projects} WHERE ${LIVE} ORDER BY CASE COALESCE(state, 'active') WHEN 'active' THEN 0 WHEN 'finished' THEN 1 ELSE 2 END, _id DESC`);
  const open = await db.all(`SELECT project_id, severity, COUNT(*) AS n FROM ${T.incidents} WHERE ${LIVE} AND closed_on IS NULL GROUP BY project_id, severity`);
  const procs = await db.all(`SELECT project_id, COUNT(*) AS n FROM ${T.procedures} WHERE ${LIVE} AND COALESCE(state, 'pending') != 'done' GROUP BY project_id`);
  const want = state ? choiceOf(state, PROJECT_STATES, "state") : null;
  return {
    rows: rows.filter((p) => !want || (p.state || "active") === want).map((p) => {
      const mine = open.filter((o) => o.project_id === p._id);
      const by = (s) => Number(mine.find((o) => o.severity === s)?.n ?? 0);
      return { ...shape(p), open: mine.reduce((a, o) => a + Number(o.n), 0), greu: by("greu"), important: by("important"), lleu: by("lleu"), procedures_open: Number(procs.find((x) => x.project_id === p._id)?.n ?? 0) };
    })
  };
}
async function detail(db, { id }, full) {
  const p = await projectOf(db, id);
  const units = await db.all(`SELECT _id AS id, kind, name, state FROM ${T.units} WHERE project_id = ? AND ${LIVE} ORDER BY kind, _id`, [p._id]);
  const chapters = await chaptersOf(db, p._id);
  const counts = {};
  for (const u of units) {
    counts[u.kind] ??= { total: 0, sold: 0, reserved: 0 };
    counts[u.kind].total++;
    if (u.state === "sold") counts[u.kind].sold++;
    if (u.state === "reserved") counts[u.kind].reserved++;
  }
  return {
    ...shape(p),
    cover_id: p.cover_id || null,
    units: counts,
    ...full ? { unit_rows: units, chapters } : { chapters: chapterTree(chapters).map((c) => `${c.code} ${c.name}${c.subs.length ? ` (${c.subs.map((s) => s.code).join(" ")})` : ""}`) },
    open: await count(db, `SELECT COUNT(*) AS n FROM ${T.incidents} WHERE project_id = ? AND ${LIVE} AND closed_on IS NULL`, [p._id])
  };
}
var fields = (i) => sent({
  name: i.name === void 0 ? void 0 : text(i.name, 200),
  code: i.code === void 0 ? void 0 : text(i.code, 20),
  address: i.address === void 0 ? void 0 : text(i.address, 300),
  city: i.city === void 0 ? void 0 : text(i.city, 200),
  client: i.client === void 0 ? void 0 : text(i.client, 200),
  notes: i.notes === void 0 ? void 0 : text(i.notes),
  started_on: i.started_on === void 0 ? void 0 : dateOf(i.started_on, "started_on"),
  state: i.state === void 0 ? void 0 : choiceOf(i.state, PROJECT_STATES, "state") ?? "active"
});
async function add(db, i, { demo = false, now } = {}) {
  const data = fields(i);
  if (!data.name) throw new Refused("A project needs a name: name.", 400, { code: "NAME_REQUIRED" });
  const same = await db.one(`SELECT _id FROM ${T.projects} WHERE ${LIVE} AND lower(name) = lower(?)`, [data.name]);
  if (same) throw new Refused(`There is already a project called "${data.name}" (id ${same._id}): use it, or give this one another name.`, 409, { code: "ALREADY_THERE", item: same._id });
  const chapters = i.copy_chapters_from ? await chaptersOf(db, (await projectOf(db, i.copy_chapters_from))._id) : DEFAULT_CHAPTERS;
  const units = i.units === void 0 ? [] : unitsFrom(listOf(i.units, "units"));
  let demoRemoved = false;
  if (!demo) demoRemoved = (await removeDemo(db)).removed > 0;
  const id = await db.insert(T.projects, { state: "active", started_on: today(now), ...data, demo: demo ? 1 : 0, removed: 0 });
  await insertChapters(db, id, chapters.length ? chapters : DEFAULT_CHAPTERS);
  if (units.length) await db.batch(units.map((u) => ({ op: "insert", table: T.units, data: { project_id: id, ...u, removed: 0 } })));
  return { id, name: data.name, chapters: chapters.length, units: units.length, ...demoRemoved ? { example_removed: true } : {} };
}
async function update(db, i) {
  const p = await projectOf(db, i.id);
  const data = fields(i);
  if (data.name === "") throw new Refused("A project keeps a name.", 400, { code: "NAME_REQUIRED" });
  if (i.cover_id !== void 0) data.cover_id = int(i.cover_id, "cover_id");
  if (Object.keys(data).length) await db.update(T.projects, p._id, data);
  return { id: p._id, changed: Object.keys(data) };
}
async function archive(db, { id }) {
  const p = await projectOf(db, id);
  await db.update(T.projects, p._id, { state: "archived" });
  return { id: p._id, state: "archived" };
}
async function unitsAdd(db, i) {
  const p = await projectOf(db, i.project_id);
  const have = {};
  for (const r of await db.all(`SELECT kind, COUNT(*) AS n FROM ${T.units} WHERE project_id = ? GROUP BY kind`, [p._id])) have[r.kind] = Number(r.n);
  const units = unitsFrom(listOf(i.units, "units"), have);
  if (!units.length) throw new Refused("Say which units: units: [{ kind, name }] or [{ kind, count }].", 400, { code: "BAD_INPUT" });
  const ids = await db.batch(units.map((u) => ({ op: "insert", table: T.units, data: { project_id: p._id, ...u, removed: 0 } })));
  return { project_id: p._id, added: ids.length, ids };
}
async function unitsUpdate(db, i) {
  const changed = [];
  const skipped = [];
  for (const u of listOf(i.units, "units")) {
    try {
      const row = await db.one(`SELECT _id FROM ${T.units} WHERE _id = ? AND ${LIVE}`, [Number(u.id)]);
      if (!row) throw new Refused("That unit is no longer there.", 404, { code: "NOT_FOUND" });
      const data = u.remove ? { removed: 1 } : sent({ name: u.name === void 0 ? void 0 : text(u.name, 120), kind: u.kind === void 0 ? void 0 : choiceOf(u.kind, UNIT_KINDS, "kind"), state: u.state === void 0 ? void 0 : choiceOf(u.state, UNIT_STATES, "state") });
      if (Object.keys(data).length) await db.update(T.units, row._id, data);
      changed.push(row._id);
    } catch (e) {
      if (!(e instanceof Refused)) throw e;
      skipped.push({ id: u.id ?? null, code: e.code, why: e.message });
    }
  }
  return { changed, skipped };
}
async function chaptersSet(db, i) {
  const p = await projectOf(db, i.project_id);
  const next = parseChapters(i.chapters);
  const wrong = chapterProblems(next);
  if (wrong.length) throw new Refused(`The chapters were not saved. ${wrong.slice(0, 5).join(" ")}`, 400, { code: "BAD_CHAPTERS" });
  const used = await db.all(`SELECT DISTINCT chapter, subchapter FROM ${T.incidents} WHERE project_id = ? AND ${LIVE}`, [p._id]);
  const has = (code, parent) => next.some((c) => c.code === code && c.parent === parent);
  const lost = used.filter((u) => u.chapter && !has(u.chapter, "") || u.subchapter && !has(u.subchapter, u.chapter)).map((u) => `${u.chapter}${u.subchapter ? "/" + u.subchapter : ""}`);
  if (lost.length) throw new Refused(`Incidents use ${lost.join(", ")}: keep those lines (the name can change), or move those incidents first.`, 409, { code: "CHAPTER_IN_USE", item: lost });
  for (const c of await db.all(`SELECT _id FROM ${T.chapters} WHERE project_id = ? AND ${LIVE}`, [p._id])) await db.update(T.chapters, c._id, { removed: 1 });
  await insertChapters(db, p._id, next);
  return { project_id: p._id, chapters: next.filter((c) => !c.parent).length, subchapters: next.filter((c) => c.parent).length };
}
async function removeDemo(db) {
  const demos = await db.all(`SELECT _id FROM ${T.projects} WHERE ${LIVE} AND demo = 1`);
  for (const d of demos) {
    for (const t of [T.incidents, T.units, T.chapters, T.visits, T.procedures, T.reports, T.attachments, T.hours]) for (const r of await db.all(`SELECT _id FROM ${t} WHERE project_id = ? AND ${LIVE}`, [d._id])) await db.update(t, r._id, { removed: 1 });
    await db.update(T.projects, d._id, { removed: 1 });
  }
  return { removed: demos.length };
}

// server/services/incidents.mjs
var SEVERITIES = { lleu: ["leve", "menor", "minor", "low", "baja", "baixa"], important: ["importante", "moderada", "moderate", "medium", "media", "mitjana"], greu: ["grave", "severe", "high", "alta", "critica", "critical"] };
var RANK = { greu: 0, important: 1, lleu: 2 };
var plain = (s) => String(s ?? "").trim().toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "");
function resolveChapter(chapters, chapter, subchapter) {
  const tops = chapters.filter((c) => !c.parent);
  const subs = chapters.filter((c) => c.parent);
  const said = String(chapter ?? "").trim();
  const saidSub = String(subchapter ?? "").trim();
  if (!said && !saidSub) return { chapter: "", subchapter: "" };
  const [a, b] = said.includes("/") ? said.split("/").map((x) => x.trim()) : [said, ""];
  const topBy = (x) => {
    const k = plain(x).split(/\s+/)[0];
    return tops.find((c) => plain(c.code) === k || plain(c.code) === k.padStart(2, "0")) || tops.find((c) => plain(c.name) === plain(x) || plain(`${c.code} ${c.name}`) === plain(x));
  };
  const subBy = (x, parent) => {
    const k = plain(x);
    const of = subs.filter((c) => !parent || c.parent === parent);
    const hit = of.filter((c) => plain(c.code) === k || plain(c.name) === k || plain(`${c.code} ${c.name}`) === k || plain(`${c.code} - ${c.name}`) === k);
    return hit.length === 1 || hit.length > 1 && parent ? hit[0] : hit.find((c) => c.parent === "03") || null;
  };
  let top = a ? topBy(a) : null;
  let sub = null;
  if (!top && a) {
    sub = subBy(a);
    if (sub) top = tops.find((c) => c.code === sub.parent);
  }
  const wantSub = saidSub || b;
  if (wantSub) {
    sub = subBy(wantSub, top?.code);
    if (sub && !top) top = tops.find((c) => c.code === sub.parent);
  }
  if (!top || wantSub && !sub) throw new Refused(`This project has no chapter "${[said, saidSub].filter(Boolean).join(" / ")}". Its chapters: ${tops.map((c) => `${c.code} ${c.name}`).join(", ")}${top ? `; under ${top.code}: ${subs.filter((c) => c.parent === top.code).map((c) => `${c.code} ${c.name}`).join(", ") || "none"}` : ""}.`, 400, { code: "UNKNOWN_CHAPTER" });
  return { chapter: top.code, subchapter: sub ? sub.code : "" };
}
function delayOf(row, day) {
  if (row.delay_days !== null && row.delay_days !== void 0) return Number(row.delay_days);
  if (!row.due_on) return 0;
  return Math.max(0, daysBetween(row.due_on, row.closed_on || day));
}
var refOf = (chapter, subchapter, n) => `${chapter || "00"}${subchapter ? "." + subchapter : ""}-${String(n).padStart(3, "0")}`;
var whole = (r, day, names = {}) => ({
  id: r._id,
  project_id: r.project_id,
  ref: r.ref,
  title: r.title,
  chapter: r.chapter || "",
  subchapter: r.subchapter || "",
  ...names.chapter !== void 0 ? { chapter_name: names.chapter, subchapter_name: names.subchapter } : {},
  location: r.location || "",
  visit_id: r.visit_id || null,
  started_on: r.started_on,
  reported_by: r.reported_by || "",
  responsible: r.responsible || "",
  due_on: r.due_on || null,
  expected_delay_days: r.expected_delay_days ?? null,
  delay_days: r.delay_days ?? null,
  delay: delayOf(r, day),
  closed_on: r.closed_on || null,
  open: !r.closed_on,
  severity: r.severity || "lleu",
  description: r.description || "",
  cost_estimated: euros(r.cost_estimated),
  cost_real: euros(r.cost_real),
  cost_approved_on: r.cost_approved_on || null,
  cost_certified: !!r.cost_certified,
  cost_invoiced: !!r.cost_invoiced,
  cost_paid: !!r.cost_paid,
  plan_id: r.plan_id || null,
  pin_x: r.pin_x ?? null,
  pin_y: r.pin_y ?? null
});
var brief = (r, day) => ({ id: r._id, ref: r.ref, title: String(r.title).slice(0, 80), chapter: `${r.chapter || ""}${r.subchapter ? "/" + r.subchapter : ""}`, severity: r.severity || "lleu", ...r.location ? { location: r.location } : {}, ...r.responsible ? { responsible: r.responsible } : {}, started_on: r.started_on, ...delayOf(r, day) ? { delay: delayOf(r, day) } : {}, ...r.closed_on ? { closed_on: r.closed_on } : {} });
async function incidentOf(db, id) {
  const n = Number(id);
  const r = Number.isInteger(n) && n > 0 ? await db.one(`SELECT * FROM ${T.incidents} WHERE _id = ? AND ${LIVE}`, [n]) : null;
  if (!r) throw new Refused(`There is no incident ${id ?? ""}: list them with incidents (each has its id and ref).`, 404, { code: "NOT_FOUND", item: id ?? null });
  return r;
}
async function find(db, { id, ref, project_id }) {
  if (id !== void 0 && id !== null && id !== "") return incidentOf(db, id);
  const rows = ref ? await db.all(`SELECT * FROM ${T.incidents} WHERE lower(ref) = lower(?) AND ${LIVE}${project_id ? " AND project_id = ?" : ""}`, project_id ? [String(ref), Number(project_id)] : [String(ref)]) : [];
  if (rows.length === 1) return rows[0];
  throw new Refused(rows.length ? `Several projects have an incident ${ref}: say project_id too, or use its id.` : `There is no incident ${ref ?? ""}: name it by id or by ref (incidents lists both).`, rows.length ? 409 : 404, { code: rows.length ? "AMBIGUOUS" : "NOT_FOUND", item: ref ?? null });
}
async function list2(db, i, full, now) {
  const day = today(now);
  const state = ["open", "closed", "all"].includes(i.state) ? i.state : "open";
  const conds = [LIVE];
  const params = [];
  if (i.project_id) {
    conds.push("project_id = ?");
    params.push((await projectOf(db, i.project_id))._id);
  } else conds.push(`project_id IN (SELECT _id FROM ${T.projects} WHERE ${LIVE} AND COALESCE(state, 'active') != 'archived')`);
  if (state === "open") conds.push("closed_on IS NULL");
  if (state === "closed") conds.push("closed_on IS NOT NULL");
  if (i.chapter) {
    conds.push("chapter = ?");
    params.push(String(i.chapter).split("/")[0].trim().padStart(2, "0"));
  }
  if (i.severity) {
    conds.push("severity = ?");
    params.push(choiceOf(i.severity, SEVERITIES, "severity"));
  }
  if (i.visit_id) {
    conds.push("visit_id = ?");
    params.push(Number(i.visit_id));
  }
  if (i.since) {
    conds.push("started_on >= ?");
    params.push(dateOf(i.since, "since"));
  }
  if (i.q) {
    conds.push("(lower(title) LIKE ? OR lower(ref) LIKE ? OR lower(COALESCE(location, '')) LIKE ?)");
    const q = `%${String(i.q).toLowerCase()}%`;
    params.push(q, q, q);
  }
  const rows = (await db.all(`SELECT * FROM ${T.incidents} WHERE ${conds.join(" AND ")}`, params)).sort((a, b) => (RANK[a.severity] ?? 3) - (RANK[b.severity] ?? 3) || String(b.started_on).localeCompare(String(a.started_on)) || b._id - a._id);
  if (full) {
    const names = new Map((await db.all(`SELECT project_id, code, parent, name FROM ${T.chapters} WHERE ${LIVE}`)).map((c) => [`${c.project_id}|${c.parent || ""}|${c.code}`, c.name]));
    return { total: rows.length, rows: rows.map((r) => whole(r, day, { chapter: names.get(`${r.project_id}||${r.chapter}`) ?? "", subchapter: names.get(`${r.project_id}|${r.chapter}|${r.subchapter}`) ?? "" })) };
  }
  const limit = Math.min(Math.max(int(i.limit) ?? 15, 1), 50);
  const from = Math.max(int(i.offset) ?? 0, 0);
  const by = (key) => {
    const o = {};
    for (const r of rows) o[r[key] || "\u2014"] = (o[r[key] || "\u2014"] ?? 0) + 1;
    return o;
  };
  return { state, total: rows.length, by_severity: by("severity"), by_chapter: by("chapter"), rows: rows.slice(from, from + limit).map((r) => brief(r, day)), ...rows.length > from + limit ? { more: `offset: ${from + limit} for the next ${Math.min(limit, rows.length - from - limit)}; or narrow with project_id, chapter, severity, since, q.` } : {} };
}
async function one(db, i, now) {
  const r = await find(db, i);
  const chapters = await chaptersOf(db, r.project_id);
  const p = await db.one(`SELECT name FROM ${T.projects} WHERE _id = ?`, [r.project_id]);
  const notes = await db.all(`SELECT _id AS id, day, text, author FROM ${T.notes} WHERE incident_id = ? AND ${LIVE} ORDER BY day, _id`, [r._id]);
  const files = await db.all(`SELECT _id AS id, kind, name, source, ref, note, CASE WHEN data IS NULL OR data = '' THEN 0 ELSE 1 END AS has_data FROM ${T.attachments} WHERE incident_id = ? AND ${LIVE} ORDER BY _id`, [r._id]);
  return {
    ...whole(r, today(now), { chapter: chapters.find((c) => !c.parent && c.code === r.chapter)?.name ?? "", subchapter: chapters.find((c) => c.parent === r.chapter && c.code === r.subchapter)?.name ?? "" }),
    project: p?.name ?? "",
    notes,
    attachments: files.map((f) => ({ ...f, has_data: !!f.has_data }))
  };
}
function cardFields(i, chapters, before = null) {
  const d = sent({
    title: i.title === void 0 ? void 0 : text(i.title, 200),
    location: i.location === void 0 ? void 0 : text(i.location, 200),
    reported_by: i.reported_by === void 0 ? void 0 : text(i.reported_by, 120),
    responsible: i.responsible === void 0 ? void 0 : text(i.responsible, 120),
    description: i.description === void 0 ? void 0 : text(i.description, 8e3),
    ref: i.ref === void 0 ? void 0 : text(i.ref, 40),
    started_on: i.started_on === void 0 ? void 0 : dateOf(i.started_on, "started_on"),
    due_on: i.due_on === void 0 ? void 0 : dateOf(i.due_on, "due_on"),
    closed_on: i.closed_on === void 0 ? void 0 : dateOf(i.closed_on, "closed_on"),
    cost_approved_on: i.cost_approved_on === void 0 ? void 0 : dateOf(i.cost_approved_on, "cost_approved_on"),
    expected_delay_days: i.expected_delay_days === void 0 ? void 0 : int(i.expected_delay_days, "expected_delay_days"),
    delay_days: i.delay_days === void 0 ? void 0 : int(i.delay_days, "delay_days"),
    severity: i.severity === void 0 ? void 0 : choiceOf(i.severity, SEVERITIES, "severity") ?? "lleu",
    cost_estimated: i.cost_estimated === void 0 ? void 0 : cents(i.cost_estimated, "cost_estimated"),
    cost_real: i.cost_real === void 0 ? void 0 : cents(i.cost_real, "cost_real"),
    cost_certified: i.cost_certified === void 0 ? void 0 : bool(i.cost_certified),
    cost_invoiced: i.cost_invoiced === void 0 ? void 0 : bool(i.cost_invoiced),
    cost_paid: i.cost_paid === void 0 ? void 0 : bool(i.cost_paid),
    visit_id: i.visit_id === void 0 ? void 0 : int(i.visit_id, "visit_id")
  });
  if (i.chapter !== void 0 || i.subchapter !== void 0) Object.assign(d, resolveChapter(chapters, i.chapter ?? before?.chapter, i.subchapter ?? (i.chapter !== void 0 ? "" : before?.subchapter)));
  return d;
}
async function addMany(db, i, actor, now) {
  const p = await projectOf(db, i.project_id);
  const items = listOf(i.items, "items");
  if (!items.length) throw new Refused("Say what was found: items: [{ title, chapter, location, severity, description }].", 400, { code: "BAD_INPUT" });
  if (items.length > 100) throw new Refused("At most 100 incidents in one call: send the rest in another.", 400, { code: "TOO_MANY" });
  const day = today(now);
  const chapters = await chaptersOf(db, p._id);
  let visitId = i.visit_id ? int(i.visit_id, "visit_id") : null;
  if (visitId && !await db.one(`SELECT _id FROM ${T.visits} WHERE _id = ? AND project_id = ? AND ${LIVE}`, [visitId, p._id])) throw new Refused(`Project ${p._id} has no visit ${visitId}: list them with visits, or send visit: { day } to make it.`, 404, { code: "NOT_FOUND", item: visitId });
  let visitOn = null;
  if (!visitId && i.visit && typeof i.visit === "object") {
    visitOn = dateOf(i.visit.day ?? i.visit.on, "visit.day") ?? day;
    const had = await db.one(`SELECT _id FROM ${T.visits} WHERE project_id = ? AND day = ? AND ${LIVE}`, [p._id, visitOn]);
    visitId = had ? had._id : await db.insert(T.visits, { project_id: p._id, day: visitOn, attendees: text(i.visit.attendees, 500) || "", summary: text(i.visit.summary) || "", removed: 0 });
  } else if (visitId) visitOn = (await db.one(`SELECT day FROM ${T.visits} WHERE _id = ?`, [visitId]))?.day ?? null;
  let n = Number((await db.one(`SELECT COUNT(*) AS n FROM ${T.incidents} WHERE project_id = ?`, [p._id]))?.n ?? 0);
  const added = [];
  const skipped = [];
  for (const [index, raw2] of items.entries()) {
    try {
      const it = raw2 && typeof raw2 === "object" ? raw2 : {};
      const d = cardFields({ severity: "lleu", ...it }, chapters);
      d.title = d.title || (d.description ? d.description.split(/[.\n]/)[0].slice(0, 90) : "");
      if (!d.title) throw new Refused("An incident needs a title (a few words) or a description.", 400, { code: "TITLE_REQUIRED" });
      d.started_on = d.started_on ?? visitOn ?? day;
      const dup = await db.one(`SELECT _id FROM ${T.incidents} WHERE project_id = ? AND lower(title) = lower(?) AND started_on = ? AND ${LIVE}`, [p._id, d.title, d.started_on]);
      if (dup) throw new Refused("It is already there, with the same title and start date: nothing was added.", 409, { code: "DUPLICATE", item: dup._id });
      n += 1;
      const ref = d.ref || refOf(d.chapter, d.subchapter, n);
      const id = await db.insert(T.incidents, { chapter: "", subchapter: "", ...d, ref, project_id: p._id, visit_id: d.visit_id ?? visitId, reported_by: d.reported_by || who(actor), removed: 0 });
      if (it.note) await db.insert(T.notes, { incident_id: id, day: d.started_on, text: text(it.note), author: who(actor), removed: 0 });
      added.push({ id, ref });
    } catch (e) {
      if (!(e instanceof Refused)) throw e;
      skipped.push({ index, code: e.code, why: e.message, ...e.item !== void 0 ? { item: e.item } : {} });
    }
  }
  return { project_id: p._id, added, ...visitId ? { visit_id: visitId } : {}, skipped };
}
async function updateMany(db, i, actor, now) {
  const changed = [];
  const skipped = [];
  const cache = /* @__PURE__ */ new Map();
  for (const [index, it] of listOf(i.items, "items").entries()) {
    try {
      const r = await find(db, it ?? {});
      if (!cache.has(r.project_id)) cache.set(r.project_id, await chaptersOf(db, r.project_id));
      const d = cardFields(it, cache.get(r.project_id), r);
      if (it.closed_on === null || it.closed_on === "") d.closed_on = null;
      for (const k of ["due_on", "cost_approved_on", "delay_days", "expected_delay_days", "cost_estimated", "cost_real"]) if (it[k] === null || it[k] === "") d[k] = null;
      if (d.title === "") throw new Refused("An incident keeps a title.", 400, { code: "TITLE_REQUIRED" });
      if (d.closed_on && d.closed_on < (d.started_on ?? r.started_on)) throw new Refused(`It cannot close (${d.closed_on}) before it started (${d.started_on ?? r.started_on}).`, 400, { code: "BAD_DATE" });
      if (Object.keys(d).length) await db.update(T.incidents, r._id, d);
      if (it.note) await db.insert(T.notes, { incident_id: r._id, day: dateOf(it.note_day, "note_day") ?? today(now), text: text(it.note), author: who(actor), removed: 0 });
      changed.push(r._id);
    } catch (e) {
      if (!(e instanceof Refused)) throw e;
      skipped.push({ index, code: e.code, why: e.message, ...e.item !== void 0 ? { item: e.item } : {} });
    }
  }
  return { changed, skipped };
}
async function closeMany(db, i, actor, now) {
  const on = dateOf(i.closed_on, "closed_on") ?? today(now);
  const closed = [];
  const skipped = [];
  for (const id of listOf(i.ids, "ids")) {
    try {
      const r = await incidentOf(db, id);
      if (r.closed_on) throw new Refused(`It was already closed on ${r.closed_on}.`, 409, { code: "ALREADY_CLOSED", item: r._id });
      if (on < r.started_on) throw new Refused(`It cannot close (${on}) before it started (${r.started_on}).`, 400, { code: "BAD_DATE", item: r._id });
      await db.update(T.incidents, r._id, { closed_on: on });
      if (i.note) await db.insert(T.notes, { incident_id: r._id, day: on, text: text(i.note), author: who(actor), removed: 0 });
      closed.push(r._id);
    } catch (e) {
      if (!(e instanceof Refused)) throw e;
      skipped.push({ id, code: e.code, why: e.message });
    }
  }
  return { closed, closed_on: on, skipped };
}
async function notesAdd(db, i, actor, now) {
  let added = 0;
  const ids = [];
  const skipped = [];
  for (const [index, it] of listOf(i.items, "items").entries()) {
    try {
      const r = await find(db, { id: it?.incident_id ?? it?.id, ref: it?.ref, project_id: it?.project_id });
      const t = text(it.text);
      if (!t) throw new Refused("A follow-up note needs its text.", 400, { code: "TEXT_REQUIRED" });
      ids.push(await db.insert(T.notes, { incident_id: r._id, day: dateOf(it.day ?? it.on, "day") ?? today(now), text: t, author: who(actor), removed: 0 }));
      added += 1;
    } catch (e) {
      if (!(e instanceof Refused)) throw e;
      skipped.push({ index, code: e.code, why: e.message });
    }
  }
  return { added, ids, skipped };
}
async function noteRemove(db, { id }) {
  const changed = await db.update(T.notes, Number(id), { removed: 1 });
  if (!changed) throw new Refused("That note is no longer there.", 404, { code: "NOT_FOUND", item: id });
  return { id: Number(id), removed: true };
}
async function remove(db, { id }) {
  const r = await incidentOf(db, id);
  await db.update(T.incidents, r._id, { removed: 1 });
  return { id: r._id, removed: true };
}

// server/services/work.mjs
var PROCEDURE_KINDS = { licence: ["llicencia", "licencia", "permis", "permiso", "license", "certificat", "certificado"], connection: ["escomesa", "acometida", "subministrament", "suministro", "supply"], insurance: ["asseguranca", "seguro", "assegurances", "seguros"], deposit: ["diposit", "deposito", "garantia", "aval", "fianza", "fianca"], contract: ["contracte", "contrato"], legal: ["juridic", "juridico", "financer", "financiero", "notaria"], other: ["altre", "otro", "altres", "otros"] };
var PROCEDURE_STATES = { pending: ["pendent", "pendiente", "todo"], in_progress: ["en curs", "en curso", "en tramit", "en tramite", "doing", "started"], blocked: ["bloquejat", "bloqueado", "aturat", "parado"], done: ["fet", "hecho", "tancat", "cerrado", "resolt", "resuelto", "concedida", "concedit"] };
var ORDER = { blocked: 0, in_progress: 1, pending: 2, done: 3 };
var visitOf = async (db, id) => {
  const v = await db.one(`SELECT * FROM ${T.visits} WHERE _id = ? AND ${LIVE}`, [Number(id) || 0]);
  if (!v) throw new Refused(`There is no visit ${id ?? ""}: list them with visits.`, 404, { code: "NOT_FOUND", item: id ?? null });
  return v;
};
async function visitAdd(db, i, now) {
  const p = await projectOf(db, i.project_id);
  const day = dateOf(i.day, "day") ?? today(now);
  const had = await db.one(`SELECT _id FROM ${T.visits} WHERE project_id = ? AND day = ? AND ${LIVE}`, [p._id, day]);
  if (had) {
    const d = sent({ attendees: i.attendees === void 0 ? void 0 : text(i.attendees, 500), summary: i.summary === void 0 ? void 0 : text(i.summary) });
    if (Object.keys(d).length) await db.update(T.visits, had._id, d);
    return { id: had._id, day, existed: true };
  }
  return { id: await db.insert(T.visits, { project_id: p._id, day, attendees: text(i.attendees, 500) || "", summary: text(i.summary) || "", removed: 0 }), day };
}
async function visitUpdate(db, i) {
  const v = await visitOf(db, i.id);
  const d = sent({ day: i.day === void 0 ? void 0 : dateOf(i.day, "day"), attendees: i.attendees === void 0 ? void 0 : text(i.attendees, 500), summary: i.summary === void 0 ? void 0 : text(i.summary) });
  if (Object.keys(d).length) await db.update(T.visits, v._id, d);
  return { id: v._id, changed: Object.keys(d) };
}
async function visits(db, i) {
  const conds = [LIVE];
  const params = [];
  if (i.project_id) {
    conds.push("project_id = ?");
    params.push((await projectOf(db, i.project_id))._id);
  } else conds.push(`project_id IN (SELECT _id FROM ${T.projects} WHERE ${LIVE} AND COALESCE(state, 'active') != 'archived')`);
  const rows = await db.all(`SELECT _id AS id, project_id, day, attendees, summary FROM ${T.visits} WHERE ${conds.join(" AND ")} ORDER BY day DESC, _id DESC LIMIT 200`, params);
  const counts = await db.all(`SELECT visit_id, COUNT(*) AS n, SUM(CASE WHEN closed_on IS NULL THEN 1 ELSE 0 END) AS open FROM ${T.incidents} WHERE ${LIVE} AND visit_id IS NOT NULL GROUP BY visit_id`);
  return { rows: rows.map((v) => {
    const c = counts.find((x) => x.visit_id === v.id);
    return { ...v, incidents: Number(c?.n ?? 0), open: Number(c?.open ?? 0) };
  }) };
}
async function visit(db, { id }) {
  const v = await visitOf(db, id);
  const p = await db.one(`SELECT name FROM ${T.projects} WHERE _id = ?`, [v.project_id]);
  const found = await db.all(`SELECT _id AS id, ref, title, chapter, subchapter, severity, location, closed_on FROM ${T.incidents} WHERE visit_id = ? AND ${LIVE} ORDER BY _id`, [v._id]);
  const files = await db.all(`SELECT _id AS id, kind, name, source, ref, note, CASE WHEN data IS NULL OR data = '' THEN 0 ELSE 1 END AS has_data FROM ${T.attachments} WHERE visit_id = ? AND incident_id IS NULL AND ${LIVE} ORDER BY _id`, [v._id]);
  return { id: v._id, project_id: v.project_id, project: p?.name ?? "", day: v.day, attendees: v.attendees || "", summary: v.summary || "", incidents: found, attachments: files.map((f) => ({ ...f, has_data: !!f.has_data })) };
}
var procFields = (i) => sent({
  title: i.title === void 0 ? void 0 : text(i.title, 200),
  kind: i.kind === void 0 ? void 0 : choiceOf(i.kind, PROCEDURE_KINDS, "kind") ?? "other",
  state: i.state === void 0 ? void 0 : choiceOf(i.state, PROCEDURE_STATES, "state") ?? "pending",
  next_step: i.next_step === void 0 ? void 0 : text(i.next_step, 400),
  next_on: i.next_on === void 0 ? void 0 : dateOf(i.next_on, "next_on"),
  responsible: i.responsible === void 0 ? void 0 : text(i.responsible, 120),
  notes: i.notes === void 0 ? void 0 : text(i.notes),
  done_on: i.done_on === void 0 ? void 0 : dateOf(i.done_on, "done_on"),
  chapter: i.chapter === void 0 ? void 0 : text(i.chapter, 12)
});
async function proceduresAdd(db, i) {
  const p = await projectOf(db, i.project_id);
  const added = [];
  const skipped = [];
  for (const [index, it] of listOf(i.items, "items").entries()) {
    try {
      const d = procFields({ kind: "other", state: "pending", ...it });
      if (!d.title) throw new Refused(`A procedure needs a title ("Llic\xE8ncia d'obres").`, 400, { code: "TITLE_REQUIRED" });
      const dup = await db.one(`SELECT _id FROM ${T.procedures} WHERE project_id = ? AND lower(title) = lower(?) AND ${LIVE}`, [p._id, d.title]);
      if (dup) throw new Refused("It is already there with that title: change it with procedures_update.", 409, { code: "DUPLICATE", item: dup._id });
      added.push(await db.insert(T.procedures, { next_step: "", responsible: "", notes: "", chapter: "", ...d, project_id: p._id, removed: 0 }));
    } catch (e) {
      if (!(e instanceof Refused)) throw e;
      skipped.push({ index, code: e.code, why: e.message, ...e.item !== void 0 ? { item: e.item } : {} });
    }
  }
  return { project_id: p._id, added, skipped };
}
async function proceduresUpdate(db, i, now) {
  const changed = [];
  const skipped = [];
  for (const [index, it] of listOf(i.items, "items").entries()) {
    try {
      const r = await db.one(`SELECT _id, state, done_on FROM ${T.procedures} WHERE _id = ? AND ${LIVE}`, [Number(it?.id) || 0]);
      if (!r) throw new Refused(`There is no procedure ${it?.id ?? ""}: list them with procedures.`, 404, { code: "NOT_FOUND", item: it?.id ?? null });
      const d = it.remove ? { removed: 1 } : procFields(it);
      if (d.title === "") throw new Refused("A procedure keeps a title.", 400, { code: "TITLE_REQUIRED" });
      if (it.next_on === null || it.next_on === "") d.next_on = null;
      if (d.state === "done" && !d.done_on && !r.done_on) d.done_on = today(now);
      if (d.state && d.state !== "done" && d.done_on === void 0) d.done_on = null;
      if (Object.keys(d).length) await db.update(T.procedures, r._id, d);
      changed.push(r._id);
    } catch (e) {
      if (!(e instanceof Refused)) throw e;
      skipped.push({ index, code: e.code, why: e.message });
    }
  }
  return { changed, skipped };
}
async function procedures(db, i, full, now) {
  const conds = [LIVE];
  const params = [];
  if (i.project_id) {
    conds.push("project_id = ?");
    params.push((await projectOf(db, i.project_id))._id);
  } else conds.push(`project_id IN (SELECT _id FROM ${T.projects} WHERE ${LIVE} AND COALESCE(state, 'active') != 'archived')`);
  if (i.state === "open") conds.push(`COALESCE(state, 'pending') != 'done'`);
  else if (i.state) {
    conds.push("state = ?");
    params.push(choiceOf(i.state, PROCEDURE_STATES, "state"));
  }
  const day = today(now);
  const rows = (await db.all(`SELECT _id AS id, project_id, title, kind, state, next_step, next_on, responsible, notes, done_on, chapter FROM ${T.procedures} WHERE ${conds.join(" AND ")}`, params)).sort((a, b) => (ORDER[a.state] ?? 2) - (ORDER[b.state] ?? 2) || String(a.next_on || "9").localeCompare(String(b.next_on || "9")) || a.id - b.id).map((r) => ({ ...r, ...r.state !== "done" && r.next_on && r.next_on < day ? { late: true } : {} }));
  if (full) return { total: rows.length, rows };
  const by = {};
  for (const r of rows) by[r.state || "pending"] = (by[r.state || "pending"] ?? 0) + 1;
  return { total: rows.length, by_state: by, rows: rows.slice(0, 30).map((r) => ({ id: r.id, title: r.title, kind: r.kind, state: r.state, ...r.next_step ? { next_step: r.next_step } : {}, ...r.next_on ? { next_on: r.next_on } : {}, ...r.late ? { late: true } : {}, ...r.done_on ? { done_on: r.done_on } : {} })), ...rows.length > 30 ? { more: "Only the first 30: narrow with project_id or state." } : {} };
}
async function overview(db, now) {
  const day = today(now);
  const { rows } = await list(db);
  const live = rows.filter((p) => p.state !== "archived");
  const late = await db.all(`SELECT project_id, COUNT(*) AS n FROM ${T.procedures} WHERE ${LIVE} AND COALESCE(state, 'pending') != 'done' AND next_on IS NOT NULL AND next_on < ? GROUP BY project_id`, [day]);
  const last = await db.all(`SELECT project_id, MAX(day) AS day FROM ${T.visits} WHERE ${LIVE} GROUP BY project_id`);
  return {
    today: day,
    projects: live.map((p) => ({ id: p.id, name: p.name, ...p.demo ? { example: true } : {}, open: p.open, greu: p.greu, important: p.important, procedures_open: p.procedures_open, procedures_late: Number(late.find((x) => x.project_id === p.id)?.n ?? 0), last_visit: last.find((x) => x.project_id === p.id)?.day ?? null })),
    ...live.length ? {} : { next: "No project yet: project_add { name, address, city, client, units: [{ kind, count }] }." }
  };
}
async function week(db, i, now) {
  const day = today(now);
  const days = Math.min(Math.max(int(i.days) ?? 7, 1), 92);
  const since = addDays(day, -days);
  const scope = i.project_id ? [(await projectOf(db, i.project_id))._id] : (await db.all(`SELECT _id FROM ${T.projects} WHERE ${LIVE} AND COALESCE(state, 'active') != 'archived'`)).map((p) => p._id);
  if (!scope.length) return { since, until: day, opened: { count: 0, rows: [] }, closed: { count: 0, rows: [] }, notes: 0, visits: [], procedures_done: [] };
  const inScope = `project_id IN (${scope.map(() => "?").join(",")})`;
  const line = (r) => ({ id: r._id, ref: r.ref, title: String(r.title).slice(0, 60), severity: r.severity, ...scope.length > 1 ? { project_id: r.project_id } : {} });
  const first = (rows) => ({ count: rows.length, rows: rows.slice(0, 10).map(line), ...rows.length > 10 ? { more: "incidents { since, state } lists them all." } : {} });
  const opened = await db.all(`SELECT _id, ref, title, severity, project_id FROM ${T.incidents} WHERE ${LIVE} AND ${inScope} AND started_on > ? ORDER BY started_on DESC LIMIT 200`, [...scope, since]);
  const closed = await db.all(`SELECT _id, ref, title, severity, project_id FROM ${T.incidents} WHERE ${LIVE} AND ${inScope} AND closed_on > ? ORDER BY closed_on DESC LIMIT 200`, [...scope, since]);
  const notes = await db.one(`SELECT COUNT(*) AS n FROM ${T.notes} WHERE ${LIVE} AND day > ? AND incident_id IN (SELECT _id FROM ${T.incidents} WHERE ${LIVE} AND ${inScope})`, [since, ...scope]);
  const seen = await db.all(`SELECT _id AS id, project_id, day FROM ${T.visits} WHERE ${LIVE} AND ${inScope} AND day > ? ORDER BY day DESC`, [...scope, since]);
  const done = await db.all(`SELECT _id AS id, project_id, title, done_on FROM ${T.procedures} WHERE ${LIVE} AND ${inScope} AND done_on > ? ORDER BY done_on DESC`, [...scope, since]);
  return { since, until: day, opened: first(opened), closed: first(closed), notes: Number(notes?.n ?? 0), visits: seen, procedures_done: done };
}

// server/services/files.mjs
var ATTACHMENT_KINDS = { photo: ["foto", "fotografia", "image", "imagen", "imatge"], plan: ["planol", "plano", "planell"], doc: ["document", "documento", "file", "pdf"] };
var DATA = /^data:(image\/(?:jpeg|png|webp)|application\/pdf);base64,[A-Za-z0-9+/=]+$/;
var MAX_DATA = 28e5;
async function add2(db, i) {
  const added = [];
  const skipped = [];
  for (const [index, it] of listOf(i.items, "items").entries()) {
    try {
      const where = { project_id: null, incident_id: null, visit_id: null };
      if (it?.incident_id) {
        const r = await incidentOf(db, it.incident_id);
        where.incident_id = r._id;
        where.project_id = r.project_id;
        where.visit_id = r.visit_id || null;
      } else if (it?.visit_id) {
        const v = await db.one(`SELECT _id, project_id FROM ${T.visits} WHERE _id = ? AND ${LIVE}`, [Number(it.visit_id) || 0]);
        if (!v) throw new Refused(`There is no visit ${it.visit_id}.`, 404, { code: "NOT_FOUND", item: it.visit_id });
        where.visit_id = v._id;
        where.project_id = v.project_id;
      } else where.project_id = (await projectOf(db, it?.project_id ?? i.project_id))._id;
      const kind = choiceOf(it.kind ?? "photo", ATTACHMENT_KINDS, "kind");
      let source;
      let ref = "";
      let data = "";
      if (it.data) {
        if (typeof it.data !== "string" || !DATA.test(it.data)) throw new Refused('data is a data URL of a JPEG, PNG or WebP image, or a PDF ("data:image/jpeg;base64,\u2026").', 400, { code: "BAD_DATA" });
        if (it.data.length > MAX_DATA) throw new Refused("That file is over 2 MB: make the image smaller (1600 px on its long side is plenty), or keep the file in the team's files folder and attach it by path.", 413, { code: "TOO_BIG" });
        source = "upload";
        data = it.data;
      } else if (it.url) {
        if (!/^https:\/\/[^\s]{4,500}$/.test(String(it.url))) throw new Refused("url is an https:// address.", 400, { code: "BAD_INPUT" });
        source = "link";
        ref = String(it.url);
      } else if (it.path) {
        source = "file";
        ref = text(it.path, 500);
      } else throw new Refused("An attachment is one of: data (a data URL), path (where the file is in the team's files folder) or url.", 400, { code: "BAD_INPUT" });
      if (kind === "plan" && source !== "upload") throw new Refused("A plan to place incidents on is an image sent as data (JPEG or PNG): export the page of the PDF as an image first.", 400, { code: "PLAN_NEEDS_IMAGE" });
      added.push(await db.insert(T.attachments, { ...where, kind, name: text(it.name, 200) || (ref ? ref.split("/").pop() : kind), source, ref, data, note: text(it.note, 500) || "", removed: 0 }));
    } catch (e) {
      if (!(e instanceof Refused)) throw e;
      skipped.push({ index, code: e.code, why: e.message });
    }
  }
  return { added, skipped };
}
async function list3(db, i) {
  const p = await projectOf(db, i.project_id);
  const kind = i.kind ? choiceOf(i.kind, ATTACHMENT_KINDS, "kind") : null;
  const rows = await db.all(`SELECT _id AS id, incident_id, visit_id, kind, name, source, ref, note, CASE WHEN data IS NULL OR data = '' THEN 0 ELSE 1 END AS has_data FROM ${T.attachments} WHERE project_id = ? AND ${LIVE}${kind ? " AND kind = ?" : ""} ORDER BY _id DESC LIMIT 200`, kind ? [p._id, kind] : [p._id]);
  return { rows: rows.map((r) => ({ ...r, has_data: !!r.has_data })) };
}
async function one2(db, { id, full }, person) {
  if (!person && full !== true && full !== "true") throw new Refused("A file's bytes are for the screen (they would fill your context). Its name, note and where it is are in incident { id } \u2192 attachments.", 409, { code: "FOR_THE_SCREEN", item: id });
  const r = await db.one(`SELECT _id AS id, project_id, incident_id, kind, name, source, ref, note, data FROM ${T.attachments} WHERE _id = ? AND ${LIVE}`, [Number(id) || 0]);
  if (!r) throw new Refused("That file is no longer there.", 404, { code: "NOT_FOUND", item: id });
  return r;
}
async function remove2(db, { id }) {
  const changed = await db.update(T.attachments, Number(id) || 0, { removed: 1 });
  if (!changed) throw new Refused("That file is no longer there.", 404, { code: "NOT_FOUND", item: id });
  for (const r of await db.all(`SELECT _id FROM ${T.incidents} WHERE plan_id = ? AND ${LIVE}`, [Number(id)])) await db.update(T.incidents, r._id, { plan_id: null, pin_x: null, pin_y: null });
  return { id: Number(id), removed: true };
}
async function pinSet(db, i) {
  const r = await incidentOf(db, i.incident_id ?? i.id);
  if (i.plan_id === null || i.plan_id === "" || i.plan_id === void 0) {
    await db.update(T.incidents, r._id, { plan_id: null, pin_x: null, pin_y: null });
    return { id: r._id, pinned: false };
  }
  const plan = await db.one(`SELECT _id FROM ${T.attachments} WHERE _id = ? AND project_id = ? AND kind = 'plan' AND ${LIVE}`, [Number(i.plan_id) || 0, r.project_id]);
  if (!plan) throw new Refused(`Plan ${i.plan_id} is not one of this project's plans: list them with attachments { project_id, kind: "plan" }.`, 404, { code: "NOT_FOUND", item: i.plan_id });
  const x = Number(i.x);
  const y = Number(i.y);
  if (!(x >= 0 && x <= 1 && y >= 0 && y <= 1)) throw new Refused("x and y say where on the plan, each from 0 to 1 (0.5, 0.5 is its centre).", 400, { code: "BAD_NUMBER" });
  await db.update(T.incidents, r._id, { plan_id: plan._id, pin_x: x, pin_y: y });
  return { id: r._id, pinned: true, plan_id: plan._id };
}
async function planPins(db, { plan_id }) {
  const rows = await db.all(`SELECT _id AS id, ref, title, severity, closed_on, pin_x AS x, pin_y AS y FROM ${T.incidents} WHERE plan_id = ? AND ${LIVE}`, [Number(plan_id) || 0]);
  return { rows };
}

// shared/words.js
var REPORT_LANGUAGES = { ca: "Catal\xE0", es: "Castellano" };
var REPORT_WORDS = {
  ca: {
    months: ["Gener", "Febrer", "Mar\xE7", "Abril", "Maig", "Juny", "Juliol", "Agost", "Setembre", "Octubre", "Novembre", "Desembre"],
    project: "Projecte",
    tracking: "Seguiment de projecte",
    monthly: "Informe de progr\xE9s mensual",
    report: "Informe mensual",
    confidential: "Document confidencial",
    units: { habitatge: "Habitatges", local: "Locals", aparcament: "Aparcaments", traster: "Trasters", altre: "Altres" },
    summary: "Resum executiu",
    outlook: "Properes passes",
    incidents: "Incid\xE8ncies",
    byChapter: "Incid\xE8ncies per cap\xEDtol",
    bySeverity: "Per gravetat",
    management: "Gesti\xF3",
    extraCosts: "Contradictoris",
    sales: "Vendes",
    detail: "Detall",
    photos: "Fotografies",
    open: "Obertes",
    opened: "Noves del mes",
    closed: "Tancades del mes",
    openAtEnd: "Obertes a final de mes",
    severity: { greu: "Greu", important: "Important", lleu: "Lleu" },
    severities: { greu: "Greus", important: "Importants", lleu: "Lleus" },
    ref: "N\xFAm. refer\xE8ncia",
    chapter: "Cap\xEDtol",
    subchapter: "Subcap\xEDtol",
    location: "Ubicaci\xF3",
    started: "Data inici",
    agent: "Agent",
    responsible: "Responsable",
    forecast: "Previsi\xF3",
    delay: "Retard",
    closing: "Tancament",
    severityLabel: "Gravetat",
    days: "dies",
    description: "Descripci\xF3",
    followUp: "Seguiment",
    attached: "Documentaci\xF3 adjunta",
    state: "Estat",
    inProgress: "En curs",
    closedState: "Tancada",
    costForecast: "Cost previsi\xF3",
    costReal: "Cost real",
    approval: "Data aprovaci\xF3",
    certified: "Certificat",
    invoiced: "Facturat",
    paid: "Pagat",
    yes: "S\xED",
    no: "No",
    estimated: "Estimat",
    real: "Real",
    approved: "Aprovats",
    pending: "Pendents d'aprovar",
    total: "Total",
    amount: "Import",
    procedure: "Gesti\xF3",
    next: "Seg\xFCent pas",
    date: "Data",
    sold: "Venuts",
    reserved: "Reservats",
    available: "Disponibles",
    kinds: { licence: "Permisos i llic\xE8ncies", connection: "Escomeses i subministraments", insurance: "Assegurances", deposit: "Dip\xF2sits i garanties", contract: "Contracte", legal: "Jur\xEDdic i financer", other: "Altres gestions" },
    states: { pending: "Pendent", in_progress: "En curs", blocked: "Bloquejat", done: "Fet" },
    none: "Cap incid\xE8ncia en aquest per\xEDode.",
    noProcedures: "Cap gesti\xF3 registrada.",
    noSummary: "Resum pendent de redactar.",
    mainIncidents: "Incid\xE8ncies greus i importants",
    draft: "Esborrany",
    page: "P\xE0g."
  },
  es: {
    months: ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"],
    project: "Proyecto",
    tracking: "Seguimiento de proyecto",
    monthly: "Informe de progreso mensual",
    report: "Informe mensual",
    confidential: "Documento confidencial",
    units: { habitatge: "Viviendas", local: "Locales", aparcament: "Aparcamientos", traster: "Trasteros", altre: "Otros" },
    summary: "Resumen ejecutivo",
    outlook: "Pr\xF3ximos pasos",
    incidents: "Incidencias",
    byChapter: "Incidencias por cap\xEDtulo",
    bySeverity: "Por gravedad",
    management: "Gesti\xF3n",
    extraCosts: "Contradictorios",
    sales: "Ventas",
    detail: "Detalle",
    photos: "Fotograf\xEDas",
    open: "Abiertas",
    opened: "Nuevas del mes",
    closed: "Cerradas del mes",
    openAtEnd: "Abiertas a final de mes",
    severity: { greu: "Grave", important: "Importante", lleu: "Leve" },
    severities: { greu: "Graves", important: "Importantes", lleu: "Leves" },
    ref: "N.\xBA referencia",
    chapter: "Cap\xEDtulo",
    subchapter: "Subcap\xEDtulo",
    location: "Ubicaci\xF3n",
    started: "Fecha inicio",
    agent: "Agente",
    responsible: "Responsable",
    forecast: "Previsi\xF3n",
    delay: "Retraso",
    closing: "Cierre",
    severityLabel: "Gravedad",
    days: "d\xEDas",
    description: "Descripci\xF3n",
    followUp: "Seguimiento",
    attached: "Documentaci\xF3n adjunta",
    state: "Estado",
    inProgress: "En curso",
    closedState: "Cerrada",
    costForecast: "Coste previsi\xF3n",
    costReal: "Coste real",
    approval: "Fecha aprobaci\xF3n",
    certified: "Certificado",
    invoiced: "Facturado",
    paid: "Pagado",
    yes: "S\xED",
    no: "No",
    estimated: "Estimado",
    real: "Real",
    approved: "Aprobados",
    pending: "Pendientes de aprobar",
    total: "Total",
    amount: "Importe",
    procedure: "Gesti\xF3n",
    next: "Siguiente paso",
    date: "Fecha",
    sold: "Vendidos",
    reserved: "Reservados",
    available: "Disponibles",
    kinds: { licence: "Permisos y licencias", connection: "Acometidas y suministros", insurance: "Seguros", deposit: "Dep\xF3sitos y garant\xEDas", contract: "Contrato", legal: "Jur\xEDdico y financiero", other: "Otras gestiones" },
    states: { pending: "Pendiente", in_progress: "En curso", blocked: "Bloqueado", done: "Hecho" },
    none: "Ninguna incidencia en este periodo.",
    noProcedures: "Ninguna gesti\xF3n registrada.",
    noSummary: "Resumen pendiente de redactar.",
    mainIncidents: "Incidencias graves e importantes",
    draft: "Borrador",
    page: "P\xE1g."
  }
};
var wordsOf = (language) => REPORT_WORDS[language] ?? REPORT_WORDS.ca;
function periodName(period, language = "ca") {
  const m = /^(\d{4})-(\d{2})$/.exec(String(period ?? ""));
  return m ? `${wordsOf(language).months[Number(m[2]) - 1]} ${m[1]}` : String(period ?? "");
}

// server/services/reports.mjs
var LANGS = { ca: ["catala", "catalan", "cat"], es: ["castellano", "espanol", "spanish", "castella"] };
var PERIOD = /^\d{4}-(0[1-9]|1[0-2])$/;
function previousPeriod(day) {
  const [y, m] = day.split("-").map(Number);
  return m === 1 ? `${y - 1}-12` : `${y}-${String(m - 1).padStart(2, "0")}`;
}
function rangeOf(period) {
  const [y, m] = period.split("-").map(Number);
  return { start: `${period}-01`, end: `${period}-${String(new Date(Date.UTC(y, m, 0)).getUTCDate()).padStart(2, "0")}` };
}
var DEFAULT_SETTINGS = { company_name: "", report_language: "ca", report_accent: "#A8A29E", report_footer: "" };
async function settings(db) {
  const row = await db.one(`SELECT * FROM ${T.settings} WHERE _deleted = 0 ORDER BY _id LIMIT 1`);
  return { id: row?._id ?? null, ...DEFAULT_SETTINGS, ...Object.fromEntries(Object.keys(DEFAULT_SETTINGS).filter((k) => row && row[k] !== null && row[k] !== void 0 && row[k] !== "").map((k) => [k, row[k]])) };
}
async function setSettings(db, i) {
  const d = sent({
    company_name: i.company_name === void 0 ? void 0 : text(i.company_name, 120),
    report_footer: i.report_footer === void 0 ? void 0 : text(i.report_footer, 200),
    report_language: i.report_language === void 0 ? void 0 : choiceOf(i.report_language, LANGS, "report_language") ?? "ca",
    report_accent: i.report_accent === void 0 ? void 0 : text(i.report_accent, 9)
  });
  if (d.report_accent && !/^#[0-9a-fA-F]{6}$/.test(d.report_accent)) throw new Refused("The colour is written like #B7AD98 (a # and six letters or digits).", 400, { code: "BAD_COLOUR" });
  const row = await db.one(`SELECT _id FROM ${T.settings} WHERE _deleted = 0 ORDER BY _id LIMIT 1`);
  if (row) {
    if (Object.keys(d).length) await db.update(T.settings, row._id, d);
  } else await db.insert(T.settings, { ...DEFAULT_SETTINGS, ...d });
  return settings(db);
}
async function assemble(db, report) {
  const p = await db.one(`SELECT * FROM ${T.projects} WHERE _id = ?`, [report.project_id]);
  const { start, end } = rangeOf(report.period);
  const chapters = await chaptersOf(db, p._id);
  const tops = chapters.filter((c) => !c.parent);
  const nameOf = (code, parent = "") => chapters.find((c) => c.code === code && c.parent === parent)?.name ?? "";
  const rows = await db.all(`SELECT * FROM ${T.incidents} WHERE project_id = ? AND ${LIVE} AND started_on <= ? AND (closed_on IS NULL OR closed_on >= ?) ORDER BY chapter, started_on, _id`, [p._id, end, start]);
  const ids = rows.map((r) => r._id);
  const marks = ids.map(() => "?").join(",");
  const notes = ids.length ? await db.all(`SELECT incident_id, day, text FROM ${T.notes} WHERE ${LIVE} AND day <= ? AND incident_id IN (${marks}) ORDER BY day, _id`, [end, ...ids]) : [];
  const photos = ids.length ? await db.all(`SELECT _id AS id, incident_id, name FROM ${T.attachments} WHERE ${LIVE} AND kind = 'photo' AND data != '' AND incident_id IN (${marks}) ORDER BY _id`, ids) : [];
  const RANK2 = { greu: 0, important: 1, lleu: 2 };
  const incidents = rows.map((r) => {
    const open = !r.closed_on || r.closed_on > end;
    return {
      id: r._id,
      ref: r.ref,
      title: r.title,
      chapter: r.chapter || "",
      chapter_name: nameOf(r.chapter),
      subchapter: r.subchapter || "",
      subchapter_name: r.subchapter ? nameOf(r.subchapter, r.chapter) : "",
      location: r.location || "",
      started_on: r.started_on,
      reported_by: r.reported_by || "",
      responsible: r.responsible || "",
      due_on: r.due_on || null,
      expected_delay_days: r.expected_delay_days ?? null,
      delay: delayOf({ ...r, closed_on: open ? null : r.closed_on }, end),
      closed_on: open ? null : r.closed_on,
      open,
      new: r.started_on >= start,
      severity: r.severity || "lleu",
      description: r.description || "",
      cost_estimated: euros(r.cost_estimated),
      cost_real: euros(r.cost_real),
      cost_approved_on: r.cost_approved_on || null,
      cost_certified: !!r.cost_certified,
      cost_invoiced: !!r.cost_invoiced,
      cost_paid: !!r.cost_paid,
      notes: notes.filter((n) => n.incident_id === r._id).map((n) => ({ day: n.day, text: n.text })),
      photos: photos.filter((f) => f.incident_id === r._id).slice(0, 4).map((f) => ({ id: f.id, name: f.name }))
    };
  }).sort((a, b) => a.chapter.localeCompare(b.chapter) || RANK2[a.severity] - RANK2[b.severity] || a.started_on.localeCompare(b.started_on));
  const stillOpen = incidents.filter((x) => x.open);
  const sev = (list5, s) => list5.filter((x) => x.severity === s).length;
  const withCost = incidents.filter((x) => x.cost_estimated !== null || x.cost_real !== null);
  const sum = (list5, k) => list5.reduce((a, x) => a + (x[k] ?? 0), 0);
  const units = {};
  for (const u of await db.all(`SELECT kind, state, COUNT(*) AS n FROM ${T.units} WHERE project_id = ? AND ${LIVE} GROUP BY kind, state`, [p._id])) {
    units[u.kind] ??= { total: 0, sold: 0, reserved: 0 };
    units[u.kind].total += Number(u.n);
    if (u.state === "sold") units[u.kind].sold += Number(u.n);
    if (u.state === "reserved") units[u.kind].reserved += Number(u.n);
  }
  const procedures2 = (await db.all(`SELECT _id AS id, title, kind, state, next_step, next_on, responsible, done_on FROM ${T.procedures} WHERE project_id = ? AND ${LIVE} ORDER BY kind, _id`, [p._id])).map((r) => ({ ...r, state: r.state || "pending" }));
  const gallery = await db.all(`SELECT _id AS id, name FROM ${T.attachments} WHERE project_id = ? AND ${LIVE} AND kind = 'photo' AND data != '' ORDER BY _id DESC LIMIT 12`, [p._id]);
  return {
    project: { id: p._id, name: p.name, address: p.address || "", city: p.city || "", client: p.client || "", cover_id: p.cover_id || null },
    period: report.period,
    start,
    end,
    units,
    totals: { in_play: incidents.length, open: stillOpen.length, opened: incidents.filter((x) => x.new).length, closed: incidents.length - stillOpen.length, greu: sev(stillOpen, "greu"), important: sev(stillOpen, "important"), lleu: sev(stillOpen, "lleu") },
    by_chapter: tops.map((c) => {
      const mine = stillOpen.filter((x) => x.chapter === c.code);
      return { code: c.code, name: c.name, greu: sev(mine, "greu"), important: sev(mine, "important"), lleu: sev(mine, "lleu"), open: mine.length, closed: incidents.filter((x) => x.chapter === c.code && !x.open).length };
    }),
    costs: {
      count: withCost.length,
      estimated: sum(withCost, "cost_estimated"),
      real: sum(withCost, "cost_real"),
      approved: withCost.filter((x) => x.cost_approved_on).length,
      pending: withCost.filter((x) => !x.cost_approved_on).length,
      certified: withCost.filter((x) => x.cost_certified).length,
      invoiced: withCost.filter((x) => x.cost_invoiced).length,
      paid: withCost.filter((x) => x.cost_paid).length,
      by_chapter: tops.map((c) => {
        const mine = withCost.filter((x) => x.chapter === c.code);
        return { code: c.code, name: c.name, count: mine.length, estimated: sum(mine, "cost_estimated"), real: sum(mine, "cost_real") };
      }).filter((c) => c.count)
    },
    procedures: { total: procedures2.length, done: procedures2.filter((x) => x.state === "done").length, rows: procedures2 },
    incidents,
    gallery
  };
}
var reportOf = async (db, id) => {
  const r = await db.one(`SELECT * FROM ${T.reports} WHERE _id = ? AND ${LIVE}`, [Number(id) || 0]);
  if (!r) throw new Refused(`There is no report ${id ?? ""}: list them with reports, or make the month's with report_draft { project_id }.`, 404, { code: "NOT_FOUND", item: id ?? null });
  return r;
};
var head = (r) => ({ id: r._id, project_id: r.project_id, period: r.period, period_name: periodName(r.period, r.language || "ca"), language: r.language || "ca", state: r.state || "draft", has_summary: !!(r.summary && r.summary.trim()), reviewed_on: r.reviewed_on || null });
function figures(data) {
  return {
    incidents: data.totals,
    by_chapter: data.by_chapter.filter((c) => c.open || c.closed).map((c) => ({ chapter: `${c.code} ${c.name}`, open: c.open, greu: c.greu, important: c.important, closed: c.closed })),
    extra_costs: { count: data.costs.count, estimated: data.costs.estimated, real: data.costs.real, pending_approval: data.costs.pending },
    procedures: { total: data.procedures.total, done: data.procedures.done, under_way: data.procedures.rows.filter((x) => x.state !== "done").slice(0, 8).map((x) => ({ title: x.title, state: x.state, ...x.next_step ? { next_step: x.next_step } : {} })) },
    main: data.incidents.filter((x) => x.severity !== "lleu").slice(0, 10).map((x) => ({ ref: x.ref, title: x.title, severity: x.severity, open: x.open, ...x.delay ? { delay: x.delay } : {}, ...x.notes.length ? { last_note: x.notes[x.notes.length - 1].text.slice(0, 160) } : {} }))
  };
}
async function draft(db, i, now) {
  const p = await projectOf(db, i.project_id);
  const period = i.period ? String(i.period).trim() : previousPeriod(today(now));
  if (!PERIOD.test(period)) throw new Refused(`period is a month written YYYY-MM (got "${String(i.period).slice(0, 20)}").`, 400, { code: "BAD_PERIOD" });
  let r = await db.one(`SELECT * FROM ${T.reports} WHERE project_id = ? AND period = ? AND ${LIVE}`, [p._id, period]);
  const existed = !!r;
  if (!r) {
    const language = i.language ? choiceOf(i.language, LANGS, "language") : (await settings(db)).report_language;
    const id = await db.insert(T.reports, { project_id: p._id, period, language, state: "draft", summary: "", outlook: "", snapshot: "", removed: 0 });
    r = await db.one(`SELECT * FROM ${T.reports} WHERE _id = ?`, [id]);
  }
  const data = r.snapshot ? JSON.parse(r.snapshot) : await assemble(db, r);
  return {
    ...head(r),
    ...existed ? { existed: true } : {},
    project: p.name,
    figures: figures(data),
    write: r.state === "reviewed" ? "The person already reviewed this one: nothing to write." : `Write its two texts in ${REPORT_LANGUAGES[r.language || "ca"]} with report_write { id: ${r._id}, summary, outlook }: summary = the month in 5 to 8 lines for the client (what happened, what is serious, what it costs, what was solved); outlook = what comes next month. Only what these figures and the incidents say. Then tell the person it is ready to review: page informe/${r._id}.`
  };
}
async function write(db, i) {
  const r = await reportOf(db, i.id);
  if (r.state === "reviewed") throw new Refused("The person already reviewed this report, so it is kept as it was. To change it they press \xABVolver a borrador\xBB on its page.", 409, { code: "ALREADY_REVIEWED", item: r._id });
  const d = sent({ summary: i.summary === void 0 ? void 0 : text(i.summary, 6e3), outlook: i.outlook === void 0 ? void 0 : text(i.outlook, 4e3), language: i.language === void 0 ? void 0 : choiceOf(i.language, LANGS, "language") ?? "ca" });
  if (!Object.keys(d).length) throw new Refused("Say what to write: summary, outlook (or language).", 400, { code: "BAD_INPUT" });
  await db.update(T.reports, r._id, d);
  return { id: r._id, written: Object.keys(d) };
}
async function review(db, { id }, actor, now) {
  const r = await reportOf(db, id);
  if (r.state === "reviewed") return head(r);
  if (!r.summary || !r.summary.trim()) throw new Refused("The report has no summary yet: write it (or ask your agent to) before marking it as reviewed.", 409, { code: "NO_SUMMARY", item: r._id });
  await db.update(T.reports, r._id, { state: "reviewed", reviewed_on: today(now), reviewed_by: who(actor), snapshot: JSON.stringify(await assemble(db, r)) });
  return head(await reportOf(db, id));
}
async function reopen(db, { id }) {
  const r = await reportOf(db, id);
  await db.update(T.reports, r._id, { state: "draft", reviewed_on: null, reviewed_by: null, snapshot: "" });
  return head(await reportOf(db, id));
}
async function list4(db, i) {
  const conds = [LIVE];
  const params = [];
  if (i.project_id) {
    conds.push("project_id = ?");
    params.push((await projectOf(db, i.project_id))._id);
  }
  const names = Object.fromEntries((await db.all(`SELECT _id, name FROM ${T.projects} WHERE ${LIVE}`)).map((p) => [p._id, p.name]));
  return { rows: (await db.all(`SELECT * FROM ${T.reports} WHERE ${conds.join(" AND ")} ORDER BY period DESC, _id DESC LIMIT 100`, params)).filter((r) => names[r.project_id]).map((r) => ({ ...head(r), project: names[r.project_id] })) };
}
async function one3(db, { id }, full) {
  const r = await reportOf(db, id);
  const data = r.snapshot ? JSON.parse(r.snapshot) : await assemble(db, r);
  if (!full) return { ...head(r), project: data.project.name, summary: r.summary || "", outlook: r.outlook || "", figures: figures(data) };
  const s = await settings(db);
  return { ...head(r), summary: r.summary || "", outlook: r.outlook || "", reviewed_by: r.reviewed_by || null, frozen: !!r.snapshot, data, settings: { company_name: s.company_name, report_accent: s.report_accent, report_footer: s.report_footer } };
}
async function toPrepare(db, now) {
  const period = previousPeriod(today(now));
  const { end } = rangeOf(period);
  const have = new Set((await db.all(`SELECT project_id FROM ${T.reports} WHERE period = ? AND ${LIVE}`, [period])).map((r) => r.project_id));
  const projects = await db.all(`SELECT _id, name, started_on FROM ${T.projects} WHERE ${LIVE} AND COALESCE(state, 'active') = 'active' AND COALESCE(demo, 0) = 0`);
  return { items: projects.filter((p) => !have.has(p._id) && (!p.started_on || p.started_on <= end)).map((p) => ({ key: `report:${p._id}:${period}`, text: `The monthly report of ${p.name} for ${period} is not prepared yet.`, project_id: p._id, project: p.name, period })) };
}
async function pageNeeds(db) {
  const s = await settings(db);
  return { needs: s.company_name ? [] : [{ id: "company_name", kind: "setting", door: "settings", section: "general", place: "informes", title: "Di con qu\xE9 nombre se firman los informes", unlocks: "El nombre de tu empresa sale en la portada y en el pie de cada informe mensual." }] };
}

// server/services/import.mjs
var plain2 = (s) => String(s ?? "").trim().toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/[^a-z0-9]/g, "");
var COLUMNS = {
  incidents: {
    project: ["projecte", "proyecto", "obra", "project", "projectid", "obraid", "projecteid", "proyectoid", "nomobra", "nombreobra"],
    ref: ["ref", "referencia", "numreferencia", "numref", "numero", "num", "codi", "codigo", "code"],
    title: ["title", "titol", "titulo", "nom", "nombre", "assumpte", "asunto", "resum", "resumen"],
    chapter: ["capitol", "capitulo", "chapter", "categoria"],
    subchapter: ["subcapitol", "subcapitulo", "subchapter"],
    location: ["ubicacio", "ubicacion", "location", "lloc", "lugar", "zona", "localitzacio", "localizacion"],
    started_on: ["datainici", "fechainicio", "startedon", "inici", "inicio", "data", "fecha", "datacreacio", "fechacreacion", "createdat", "created"],
    reported_by: ["agent", "agente", "autor", "creador", "reportedby", "creatper", "creadopor", "informador"],
    responsible: ["responsable", "responsible", "assignat", "asignado", "assignee"],
    due_on: ["datalimit", "fechalimite", "limit", "limite", "deadline", "venciment", "vencimiento", "dueon", "dataprevista", "fechaprevista"],
    forecast: ["previsio", "prevision"],
    delay_days: ["retard", "retraso", "retras", "diesretard", "diasretraso", "delay", "delaydays"],
    expected_delay_days: ["previsioretard", "retardprevist", "retrasoprevisto", "expecteddelay", "expecteddelaydays"],
    closed_on: ["tancament", "cierre", "datatancament", "fechacierre", "closedat", "closedon", "dataresolucio", "fecharesolucion"],
    severity: ["gravetat", "gravedad", "severity", "prioritat", "prioridad", "priority"],
    state: ["estat", "estado", "status", "state"],
    description: ["descripcio", "descripcion", "description", "detall", "detalle", "notes", "notas", "observacions", "observaciones"],
    cost_estimated: ["costprevisio", "costprevist", "costeprevision", "costeprevisto", "pptinicial", "estimat", "estimado", "costestimated"],
    cost_real: ["costreal", "costereal"],
    cost_approved_on: ["dataaprovacio", "fechaaprobacion", "aprovacio", "aprobacion", "costapprovedon"],
    cost_certified: ["certificat", "certificado", "certified"],
    cost_invoiced: ["facturat", "facturado", "invoiced"],
    cost_paid: ["pagat", "pagado", "paid"]
  },
  hours: {
    project: ["projecte", "proyecto", "obra", "project", "projectid", "obraid", "projecteid", "proyectoid", "nomobra", "nombreobra"],
    worker: ["operari", "operario", "treballador", "trabajador", "worker", "nom", "nombre", "name", "empleat", "empleado"],
    day: ["data", "fecha", "dia", "day", "date"],
    hours: ["hores", "horas", "hours", "h", "total", "horestreballades", "horastrabajadas"],
    task: ["tasca", "tarea", "task", "concepte", "concepto", "feina", "trabajo", "notes", "notas", "observacions", "observaciones", "descripcio", "descripcion"]
  },
  projects: {
    name: ["nom", "nombre", "name", "projecte", "proyecto", "obra", "titol", "titulo"],
    code: ["codi", "codigo", "code", "ref"],
    address: ["adreca", "direccio", "direccion", "address"],
    city: ["municipi", "municipio", "ciutat", "ciudad", "city", "poblacio", "poblacion"],
    client: ["client", "cliente", "promotor", "promotora", "propietari", "propietario"],
    started_on: ["datainici", "fechainicio", "inici", "inicio"]
  }
};
var CLOSED = ["tancada", "tancat", "cerrada", "cerrado", "closed", "resolta", "resuelta", "resolt", "resuelto", "done", "feta", "hecha"];
var ID_COLUMNS = ["id", "_id", "rowid"];
function mappingOf(kind, columns, given = {}) {
  const fields2 = COLUMNS[kind];
  const map = {};
  for (const [theirs, ours] of Object.entries(given || {})) if (fields2[ours] && columns.includes(theirs)) map[ours] = theirs;
  for (const [field, names] of Object.entries(fields2)) if (!map[field]) {
    const hit = names.map((n) => columns.find((c) => plain2(c) === n && !Object.values(map).includes(c))).find(Boolean);
    if (hit) map[field] = hit;
  }
  const used = new Set(Object.values(map));
  return { map, unmapped: columns.filter((c) => !used.has(c) && !ID_COLUMNS.includes(plain2(c)) && !/^_/.test(c)) };
}
var keyOf = (table, row, index) => {
  const id = row.id ?? row._id ?? row.rowid;
  return `${table}:${id !== void 0 && id !== null && id !== "" ? id : "row" + index}`;
};
async function importRows(db, i, actor, now) {
  const kind = ["incidents", "hours", "projects"].includes(i.kind) ? i.kind : null;
  if (!kind) throw new Refused("kind is one of: incidents, hours, projects.", 400, { code: "BAD_CHOICE" });
  const rows = listOf(i.rows, "rows").filter((r) => r && typeof r === "object");
  if (!rows.length) throw new Refused("Send the rows as they are in the old table: rows: [{ column: value, \u2026 }].", 400, { code: "BAD_INPUT" });
  if (rows.length > 500) throw new Refused("At most 500 rows in one call: send the rest in another (a row sent twice is added once).", 400, { code: "TOO_MANY" });
  const dry = !(i.dry_run === false || i.dry_run === "false");
  const table = text(i.table, 60) || kind;
  const day = today(now);
  const { map, unmapped } = mappingOf(kind, [...new Set(rows.flatMap((r) => Object.keys(r)))], typeof i.map === "object" ? i.map : {});
  const get = (row, field) => {
    const v = map[field] ? row[map[field]] : void 0;
    return v === null || v === "" ? void 0 : v;
  };
  const projects = await db.all(`SELECT _id, name, code FROM ${T.projects} WHERE ${LIVE}`);
  const fixed = i.project_id ? (await projectOf(db, i.project_id))._id : null;
  const given = typeof i.project_map === "object" && i.project_map ? i.project_map : {};
  const projectFor = (row) => {
    const said = get(row, "project");
    if (said !== void 0 && given[String(said)] !== void 0) return Number(given[String(said)]);
    if (said !== void 0) {
      const hit = projects.find((p) => plain2(p.name) === plain2(said) || p.code && plain2(p.code) === plain2(said));
      if (hit) return hit._id;
    }
    if (fixed) return fixed;
    throw new Refused(said === void 0 ? "This row names no project: send project_id, or map its project column." : `No project here is called "${String(said).slice(0, 60)}": import the projects first (kind: projects), or send project_map: { "${String(said).slice(0, 40)}": <project id> }.`, 400, { code: "UNKNOWN_PROJECT" });
  };
  const out = { added: 0, already: 0, problems: [] };
  const problem = (index, e) => {
    if (!(e instanceof Refused)) throw e;
    if (out.problems.length < 12) out.problems.push({ index, code: e.code, why: e.message });
    out.failed = (out.failed ?? 0) + 1;
  };
  const chapterCache = /* @__PURE__ */ new Map();
  const counters = /* @__PURE__ */ new Map();
  for (const [index, row] of rows.entries()) {
    try {
      const source = keyOf(table, row, index);
      if (kind === "projects") {
        const name = text(get(row, "name"), 200);
        if (!name) throw new Refused("This row has no name for the project.", 400, { code: "NAME_REQUIRED" });
        if (projects.some((p) => plain2(p.name) === plain2(name))) {
          out.already++;
          continue;
        }
        if (!dry) {
          const made = await add(db, { name, code: get(row, "code"), address: get(row, "address"), city: get(row, "city"), client: get(row, "client"), started_on: get(row, "started_on") ? dateOf(String(get(row, "started_on")).slice(0, 10), "started_on") : void 0 }, { now });
          projects.push({ _id: made.id, name, code: get(row, "code") ?? "" });
        } else projects.push({ _id: -1, name, code: "" });
        out.added++;
        continue;
      }
      const pid = projectFor(row);
      if (kind === "hours") {
        const worker = text(get(row, "worker"), 120);
        const hours2 = Number(String(get(row, "hours") ?? "").replace(",", "."));
        if (!worker || !(hours2 > 0 && hours2 <= 24)) throw new Refused("A row of hours needs who (worker) and how many hours (0 to 24).", 400, { code: "BAD_INPUT" });
        const d = dateOf(String(get(row, "day") ?? "").slice(0, 10), "day");
        if (!d) throw new Refused("A row of hours needs its day.", 400, { code: "BAD_DATE" });
        if (await db.one(`SELECT _id FROM ${T.hours} WHERE source = ? AND ${LIVE}`, [source])) {
          out.already++;
          continue;
        }
        if (!dry && pid > 0) await db.insert(T.hours, { project_id: pid, worker, day: d, hours: hours2, task: text(get(row, "task"), 400) || "", source, removed: 0 });
        out.added++;
        continue;
      }
      if (await db.one(`SELECT _id FROM ${T.incidents} WHERE source = ? AND ${LIVE}`, [source])) {
        out.already++;
        continue;
      }
      const description = text(get(row, "description"), 8e3) || "";
      const title = text(get(row, "title"), 200) || description.split(/[.\n]/)[0].slice(0, 90);
      if (!title) throw new Refused("This row has neither a title nor a description.", 400, { code: "TITLE_REQUIRED" });
      const dateIn = (f) => {
        const v = get(row, f);
        return v === void 0 ? null : dateOf(String(v).slice(0, 10), f);
      };
      const started = dateIn("started_on") ?? day;
      const forecast = get(row, "forecast");
      const forecastIsDate = forecast !== void 0 && /\d{1,4}[-/.]\d{1,2}[-/.]\d{1,4}/.test(String(forecast));
      let severity = "lleu";
      const sev = get(row, "severity");
      if (sev !== void 0) {
        const k = plain2(sev);
        severity = Object.entries(SEVERITIES).find(([key, list5]) => key === k || list5.includes(k))?.[0] ?? "lleu";
      }
      let closed = dateIn("closed_on");
      if (!closed && CLOSED.includes(plain2(get(row, "state")))) closed = started > day ? started : day;
      let chapter = { chapter: "", subchapter: "" };
      let extra = "";
      if (pid > 0 && (get(row, "chapter") !== void 0 || get(row, "subchapter") !== void 0)) {
        if (!chapterCache.has(pid)) chapterCache.set(pid, await chaptersOf(db, pid));
        try {
          chapter = resolveChapter(chapterCache.get(pid), get(row, "chapter"), get(row, "subchapter"));
        } catch {
          out.without_chapter = (out.without_chapter ?? 0) + 1;
          extra = `

[${[get(row, "chapter"), get(row, "subchapter")].filter((x) => x !== void 0).join(" / ")}]`;
        }
      }
      if (!dry && pid > 0) {
        if (!counters.has(pid)) counters.set(pid, Number((await db.one(`SELECT COUNT(*) AS n FROM ${T.incidents} WHERE project_id = ?`, [pid]))?.n ?? 0));
        counters.set(pid, counters.get(pid) + 1);
        await db.insert(T.incidents, {
          project_id: pid,
          ref: text(get(row, "ref"), 40) || refOf(chapter.chapter, chapter.subchapter, counters.get(pid)),
          title,
          ...chapter,
          location: text(get(row, "location"), 200) || "",
          started_on: started,
          reported_by: text(get(row, "reported_by"), 120) || who(actor),
          responsible: text(get(row, "responsible"), 120) || "",
          due_on: dateIn("due_on") ?? (forecastIsDate ? dateOf(String(forecast).slice(0, 10), "forecast") : null),
          expected_delay_days: int(get(row, "expected_delay_days") ?? (forecast !== void 0 && !forecastIsDate && Number.isFinite(Number(forecast)) ? forecast : void 0)),
          delay_days: Number.isFinite(Number(get(row, "delay_days"))) ? int(get(row, "delay_days")) : null,
          closed_on: closed && closed < started ? started : closed,
          severity,
          description: description + extra,
          cost_estimated: cents(get(row, "cost_estimated")),
          cost_real: cents(get(row, "cost_real")),
          cost_approved_on: dateIn("cost_approved_on"),
          cost_certified: bool(get(row, "cost_certified")),
          cost_invoiced: bool(get(row, "cost_invoiced")),
          cost_paid: bool(get(row, "cost_paid")),
          source,
          removed: 0
        });
      }
      out.added++;
    } catch (e) {
      problem(index, e);
    }
  }
  return {
    kind,
    dry_run: dry,
    rows: rows.length,
    [dry ? "would_add" : "added"]: out.added,
    already: out.already,
    ...out.failed ? { failed: out.failed } : {},
    ...out.without_chapter ? { without_chapter: out.without_chapter } : {},
    problems: out.problems,
    mapping: map,
    unmapped,
    ...dry ? { next: out.added ? 'Nothing was written. If the mapping is right, send the same call with dry_run: false; a column that was left out goes in map: { "<their column>": "<field>" }.' : "Nothing to add." } : {}
  };
}
async function hoursAdd(db, i) {
  const fixed = i.project_id ? (await projectOf(db, i.project_id))._id : null;
  const added = [];
  const skipped = [];
  for (const [index, it] of listOf(i.items, "items").entries()) {
    try {
      const pid = it?.project_id ? (await projectOf(db, it.project_id))._id : fixed ?? (await projectOf(db, void 0))._id;
      const worker = text(it.worker, 120);
      const hours2 = Number(String(it.hours ?? "").replace(",", "."));
      const d = dateOf(it.day, "day");
      if (!worker || !d || !(hours2 > 0 && hours2 <= 24)) throw new Refused("A line of hours is { worker, day (YYYY-MM-DD), hours (0 to 24), task? }.", 400, { code: "BAD_INPUT" });
      const task = text(it.task, 400) || "";
      const dup = await db.one(`SELECT _id FROM ${T.hours} WHERE project_id = ? AND lower(worker) = lower(?) AND day = ? AND COALESCE(task, '') = ? AND ${LIVE}`, [pid, worker, d, task]);
      if (dup) throw new Refused("That line is already there (same worker, project, day and task): change it with the hours screen, or give its task.", 409, { code: "DUPLICATE", item: dup._id });
      added.push(await db.insert(T.hours, { project_id: pid, worker, day: d, hours: hours2, task, source: "", removed: 0 }));
    } catch (e) {
      if (!(e instanceof Refused)) throw e;
      skipped.push({ index, code: e.code, why: e.message, ...e.item !== void 0 ? { item: e.item } : {} });
    }
  }
  return { added, skipped };
}
async function hoursRemove(db, { id }) {
  const changed = await db.update(T.hours, Number(id) || 0, { removed: 1 });
  if (!changed) throw new Refused("That line is no longer there.", 404, { code: "NOT_FOUND", item: id });
  return { id: Number(id), removed: true };
}
async function hours(db, i, full, now) {
  const day = today(now);
  const from = dateOf(i.from, "from") ?? `${day.slice(0, 7)}-01`;
  const to = dateOf(i.to, "to") ?? day;
  const conds = [LIVE, "day >= ?", "day <= ?"];
  const params = [from, to];
  if (i.project_id) {
    conds.push("project_id = ?");
    params.push((await projectOf(db, i.project_id))._id);
  }
  if (i.worker) {
    conds.push("lower(worker) = lower(?)");
    params.push(String(i.worker));
  }
  const rows = await db.all(`SELECT _id AS id, project_id, worker, day, hours, task FROM ${T.hours} WHERE ${conds.join(" AND ")} ORDER BY day DESC, _id DESC`, params);
  const sum = (key) => {
    const o = {};
    for (const r of rows) o[r[key]] = Math.round(((o[r[key]] ?? 0) + Number(r.hours)) * 100) / 100;
    return o;
  };
  const base = { from, to, total: Math.round(rows.reduce((a, r) => a + Number(r.hours), 0) * 100) / 100, lines: rows.length, by_worker: sum("worker"), by_project: sum("project_id") };
  return full ? { ...base, rows } : base;
}

// server/services/demo.mjs
async function load(db, now) {
  if (await db.one(`SELECT _id FROM ${T.projects} WHERE ${LIVE} LIMIT 1`)) throw new Refused("The example is only for a module with no project yet: there is one already.", 409, { code: "NOT_EMPTY" });
  const day = today(now);
  const d = (n) => addDays(day, n);
  const who2 = "person:Ejemplo";
  const { id } = await add(db, {
    name: "Edifici Roure 21 (ejemplo)",
    code: "R21",
    address: "C/ del Roure, 21",
    city: "08400 Granollers",
    client: "Promocions Montnegre, SL",
    started_on: d(-210),
    units: [{ kind: "habitatge", count: 12 }, { kind: "local", count: 1 }, { kind: "aparcament", count: 10 }, { kind: "traster", count: 6 }]
  }, { demo: true, now });
  const units = await db.all(`SELECT _id, kind FROM ${T.units} WHERE project_id = ? ORDER BY _id`, [id]);
  const homes = units.filter((u) => u.kind === "habitatge");
  const parks = units.filter((u) => u.kind === "aparcament");
  await unitsUpdate(db, { units: [...homes.slice(0, 3).map((u) => ({ id: u._id, state: "sold" })), ...homes.slice(3, 5).map((u) => ({ id: u._id, state: "reserved" })), ...parks.slice(0, 2).map((u) => ({ id: u._id, state: "sold" }))] });
  const first = await addMany(db, { project_id: id, items: [
    { title: "Filtraci\xF3 d'aigua al mur de contenci\xF3 del soterrani -2", chapter: "03", subchapter: "C", location: "Soterrani -2, mur nord", severity: "greu", responsible: "Constructora", reported_by: "Direcci\xF3 facultativa", started_on: d(-75), due_on: d(-40), expected_delay_days: 20, cost_estimated: 18500, cost_real: 21300, cost_approved_on: d(-50), cost_certified: true, description: "Apareixen filtracions al mur nord despr\xE9s de les pluges. Cal impermeabilitzar per l'intrad\xF3s i revisar el drenatge perimetral." },
    { title: "Fissura en una biga de la planta 3", chapter: "03", subchapter: "E", location: "Planta 3, eix B-4", severity: "greu", responsible: "Estructurista", reported_by: "Direcci\xF3 facultativa", started_on: d(-32), due_on: d(-10), expected_delay_days: 15, cost_estimated: 9e3, description: "Fissura a 45\xB0 prop del suport. L'estructurista demana testimonis i una prova de c\xE0rrega abans de continuar amb la planta 4." },
    { title: "Recorregut dels baixants incompatible amb el fals sostre", chapter: "03", subchapter: "I", location: "Planta baixa, local", severity: "important", responsible: "Enginyeria", started_on: d(-41), due_on: d(-20), cost_estimated: 4200, cost_real: 3900, cost_approved_on: d(-25), description: "Els baixants de la P1 creuen el local a una al\xE7ada que no deixa el fals sostre previst. Es proposa desviar-los pel pati." },
    { title: "Trobada de la fa\xE7ana ventilada amb la fusteria sense resoldre", chapter: "03", subchapter: "F", location: "Fa\xE7ana principal, P1 a P4", severity: "important", responsible: "Direcci\xF3 facultativa", started_on: d(-20), due_on: d(10), description: "Falta el detall constructiu del remat entre el panell i el premarc. La constructora no pot demanar el material." },
    { title: "Requeriment de l'Ajuntament per l'ocupaci\xF3 de la via p\xFAblica", chapter: "04", subchapter: "43", location: "Carrer del Roure", severity: "important", responsible: "Promotora", started_on: d(-18), due_on: d(-3), description: "L'Ajuntament demana ampliar el pas de vianants al costat de la bastida abans de renovar el perm\xEDs." },
    { title: "L'escomesa el\xE8ctrica demana una nova CGP", chapter: "05", subchapter: "51", location: "Fa\xE7ana, planta baixa", severity: "important", responsible: "Enginyeria", started_on: d(-55), due_on: d(-15), cost_estimated: 6e3, description: "La companyia no accepta la ubicaci\xF3 prevista de la caixa general de protecci\xF3. Cal un n\xEDnxol nou a fa\xE7ana." },
    { title: "Pl\xE0nol d'acabats de la planta 2 desactualitzat", chapter: "02", subchapter: "21", location: "Oficina t\xE8cnica", severity: "lleu", responsible: "Arquitecte", started_on: d(-27), closed_on: d(-19), description: "El pl\xE0nol en obra no recull el canvi de distribuci\xF3 del 2n 2a." }
  ] }, who2, now);
  const v1 = await addMany(db, { project_id: id, visit: { day: d(-12), attendees: "Direcci\xF3 facultativa, cap d'obra, promotora", summary: "Visita setmanal. Estructura de la planta 4 en curs; comencen els tancaments de la planta 1." }, items: [
    { title: "Enrajolat del bany amb un to diferent del de la mostra", chapter: "03", subchapter: "R", location: "2n 1a, bany principal", severity: "lleu", responsible: "Constructora", description: "El lot rebut no coincideix amb la mostra aprovada." },
    { title: "Portes interiors rebudes amb cops", chapter: "03", subchapter: "L", location: "Magatzem d'obra", severity: "lleu", responsible: "Constructora", description: "Quatre fulles amb cops als cantells." }
  ] }, who2, now);
  const v2 = await addMany(db, { project_id: id, visit: { day: d(-5), attendees: "Direcci\xF3 facultativa, cap d'obra", summary: "Visita setmanal. Es revisa la coberta abans d'impermeabilitzar." }, items: [
    { title: "Barana provisional incompleta a l'escala", chapter: "03", subchapter: "Y", location: "Escala, P4 a P5", severity: "lleu", responsible: "Coordinador de seguretat", description: "Falta el tram entre replans." },
    { title: "L\xE0mina impermeable mal solapada a la terrassa", chapter: "03", subchapter: "N", location: "Coberta, terrassa est", severity: "lleu", responsible: "Constructora", description: "Solapaments de menys de 10 cm en dos punts." },
    { title: "Pendents de coberta insuficients a la zona d'instal\xB7lacions", chapter: "03", subchapter: "Q", location: "Coberta", severity: "important", responsible: "Direcci\xF3 facultativa", due_on: d(14), expected_delay_days: 7, description: "L'aigua queda embassada al voltant de les bancades. Cal refer el morter de pendents abans de la l\xE0mina." }
  ] }, who2, now);
  const [a, b, c] = first.added;
  await notesAdd(db, { items: [
    { incident_id: a.id, day: d(-68), text: "La constructora presenta una proposta d'impermeabilitzaci\xF3 per l'intrad\xF3s." },
    { incident_id: a.id, day: d(-50), text: "La promotora aprova el contradictori. Comencen els treballs." },
    { incident_id: a.id, day: d(-21), text: "Executat el 80 %. Falta el tram de la rampa." },
    { incident_id: b.id, day: d(-28), text: "Col\xB7locats els testimonis. Lectura setmanal." },
    { incident_id: b.id, day: d(-9), text: "Els testimonis no es mouen. Pendent de la prova de c\xE0rrega." },
    { incident_id: c.id, day: d(-25), text: "Aprovat el desviament pel pati." }
  ] }, who2, now);
  await closeMany(db, { ids: [v1.added[1].id], closed_on: d(-4), note: "El prove\xEFdor substitueix les quatre fulles." }, who2, now);
  await closeMany(db, { ids: [v2.added[0].id], closed_on: d(-3), note: "Barana completada." }, who2, now);
  await proceduresAdd(db, { project_id: id, items: [
    { title: "Llic\xE8ncia d'obres majors", kind: "licence", state: "done", done_on: d(-200), responsible: "Promotora" },
    { title: "Ocupaci\xF3 de la via p\xFAblica (bastida)", kind: "licence", state: "in_progress", next_step: "Respondre el requeriment de l'Ajuntament", next_on: d(-2), responsible: "Promotora" },
    { title: "Escomesa el\xE8ctrica definitiva", kind: "connection", state: "blocked", next_step: "Esperar la valoraci\xF3 de la companyia per la nova CGP", responsible: "Enginyeria" },
    { title: "Escomesa d'aigua", kind: "connection", state: "pending", next_step: "Sol\xB7licitar-la quan acabi l'estructura", next_on: d(30), responsible: "Constructora" },
    { title: "Asseguran\xE7a tot risc construcci\xF3", kind: "insurance", state: "done", done_on: d(-205) },
    { title: "Asseguran\xE7a decennal", kind: "insurance", state: "in_progress", next_step: "Enviar l'informe de l'OCT a l'asseguradora", next_on: d(7) },
    { title: "Dip\xF2sit de garantia de residus", kind: "deposit", state: "done", done_on: d(-198) },
    { title: "Contracte amb la constructora", kind: "contract", state: "done", done_on: d(-215) }
  ] });
  const report = await draft(db, { project_id: id }, now);
  await write(db, { id: report.id, summary: "Durant el mes l'obra ha avan\xE7at amb l'estructura de la planta 4 i l'inici dels tancaments.\n\nSegueixen obertes dues incid\xE8ncies greus: les filtracions del soterrani -2, amb els treballs executats al 80 %, i la fissura de la biga de la planta 3, pendent de la prova de c\xE0rrega.\n\nEls contradictoris aprovats sumen 25.200 \u20AC de cost real; en queden dos pendents de valorar.", outlook: "Prova de c\xE0rrega de la biga de la planta 3.\nResposta al requeriment de l'Ajuntament per la bastida.\nDetall de la trobada de fa\xE7ana amb la fusteria." });
  return { id, incidents: first.added.length + v1.added.length + v2.added.length, report_id: report.id };
}

// server/routes/obras.mjs
var CARD = { title: "a few words", description: "text", chapter: 'code or name: "03", "03/E", "Estructura"', subchapter: "code or name", location: 'where: "2n 1a, bany"', severity: "lleu | important | greu", responsible: "who must solve it", reported_by: "who found it", started_on: "YYYY-MM-DD", due_on: "YYYY-MM-DD it should be solved by", expected_delay_days: "days of delay it may cause", delay_days: "days of delay it causes today (by hand; else counted from due_on)", closed_on: "YYYY-MM-DD, or null to reopen", cost_estimated: "euros", cost_real: "euros", cost_approved_on: "YYYY-MM-DD", cost_certified: "boolean", cost_invoiced: "boolean", cost_paid: "boolean", ref: "its reference, when it has one already" };
function obras_default(app, db, deps = {}) {
  const now = () => deps.now ? deps.now() : /* @__PURE__ */ new Date();
  command(app, "GET", "/overview", { name: "overview", summary: "Where every project stands, one line each: START HERE. Open incidents (greu, important), procedures under way and late, last visit." }, () => overview(db, now()));
  command(app, "GET", "/week", { name: "week", summary: "What moved in the last days: incidents opened and closed, notes, visits, procedures done. days (7 unless said); project_id for one project.", input: { project_id: "project id", days: "number, 1 to 92" } }, (i) => week(db, i, now()));
  command(app, "GET", "/projects", { name: "projects", of: "project", summary: "The projects (obras), each with how much is open. state: active | finished | archived.", input: { state: "active | finished | archived" } }, (i) => list(db, i));
  command(app, "GET", "/projects/:id", { name: "project", on: "project", summary: "One project: its card, its units counted by kind and its chapters with their sub-chapter codes. full=true lists every unit and chapter.", input: { full: "true for every unit and chapter" } }, (i, { actor }) => detail(db, i, wantsFull(i, actor)));
  command(app, "POST", "/projects", { name: "project_add", summary: "A new project with the default chapters 01\u201309 and, if given, its units. units: [{ kind: habitatge | local | aparcament | traster | altre, count }] or [{ kind, name }]. copy_chapters_from: another project's id.", input: { name: "text", code: "short code", address: "text", city: "postcode and town", client: "client or owner", started_on: "YYYY-MM-DD", notes: "text", units: "list", copy_chapters_from: "project id" } }, (i) => add(db, i, { now: now() }));
  command(app, "POST", "/projects/:id", { name: "project_update", on: "project", summary: "Changes a project's card: only the fields sent. state: active | finished | archived.", input: { name: "text", code: "text", address: "text", city: "text", client: "text", started_on: "YYYY-MM-DD", notes: "text", state: "active | finished | archived", cover_id: "attachment id of the photo on the report's cover" } }, (i) => update(db, i));
  command(app, "POST", "/projects/:id/archive", { name: "project_archive", on: "project", by: "person", confirm: true, label: { es: "Archivar", en: "Archive" }, summary: "Archives a project: nothing is lost, it stops showing among the active ones. A person's decision." }, (i) => archive(db, i));
  command(app, "POST", "/units", { name: "units_add", summary: "Adds units to a project in one call: units [{ kind, count }] (\xABHabitatge 1\xBB\u2026) or [{ kind, name, state }]. state: available | reserved | sold.", input: { project_id: "project id", units: "list" } }, (i) => unitsAdd(db, i));
  command(app, "POST", "/units/update", { name: "units_update", summary: "Changes several units in one call: units [{ id, name?, kind?, state?, remove? }]. Answers { changed, skipped }.", input: { units: "list" } }, (i) => unitsUpdate(db, i));
  command(app, "POST", "/chapters", { name: "chapters_set", summary: `Replaces a project's chapters, whole. chapters: [{ code, name, parent }] (parent "" for a chapter) or lines of text ("03 Execuci\xF3", "03/E Estructura"). A chapter in use cannot leave.`, input: { project_id: "project id", chapters: "list, or text with one per line" } }, (i) => chaptersSet(db, i));
  command(app, "GET", "/incidents", { name: "incidents", of: "incident", summary: "The incidents: open ones unless said, worst first \u2014 figures by severity and chapter, then rows. state: open | closed | all; project_id, chapter, severity, visit_id, since (YYYY-MM-DD), q; limit/offset; full=true every row whole.", input: { project_id: "project id", state: "open | closed | all", chapter: "chapter code", severity: "lleu | important | greu", visit_id: "visit id", since: "YYYY-MM-DD: started on or after", q: "words of its title, ref or location", limit: "rows, 15 unless said (50 at most)", offset: "rows to skip", full: "true for every row whole" } }, (i, { actor }) => list2(db, i, wantsFull(i, actor), now()));
  command(app, "GET", "/incidents/:id", { name: "incident", on: "incident", summary: "One incident whole: its card, its extra cost, its follow-up notes and the names of what is attached." }, (i) => one(db, i, now()));
  command(app, "POST", "/incidents", { name: "incidents_add", summary: "Adds MANY incidents in one call \u2014 what a site visit found. items: [{ title, description, chapter, location, severity, responsible, \u2026 }]; visit: { day, attendees, summary } groups them under that day's visit. Sent twice, nothing is added twice. Answers { added: [{ id, ref }], visit_id, skipped }.", input: { project_id: "project id", visit_id: "an existing visit", visit: "{ day, attendees, summary }: makes or finds the visit of that day", items: `list of { ${Object.keys(CARD).filter((k) => !["closed_on", "delay_days"].includes(k)).join(", ")}, note }` } }, (i, { actor }) => addMany(db, i, actor, now()));
  command(app, "POST", "/incidents/update", { name: "incidents_update", summary: "Changes several incidents in one call: items [{ id (or ref + project_id), \u2026only what changes, note? }]. Closing one is its closed_on; null reopens it. Answers { changed, skipped }.", input: { items: `list of { id, ${Object.keys(CARD).join(", ")}, note }` } }, (i, { actor }) => updateMany(db, i, actor, now()));
  command(app, "POST", "/incidents/close", { name: "incidents_close", summary: "Closes several incidents on one date (today unless said), with one line of how it ended in each one's history. ids, closed_on, note.", input: { ids: "list of incident ids", closed_on: "YYYY-MM-DD", note: "how it was solved" } }, (i, { actor }) => closeMany(db, i, actor, now()));
  command(app, "POST", "/incidents/:id/remove", { name: "incident_remove", on: "incident", by: "person", confirm: true, label: { es: "Quitar", en: "Remove" }, summary: "Takes an incident away (a mistake, a duplicate). A person's decision; to end one that was real, close it." }, (i) => remove(db, i));
  command(app, "POST", "/notes", { name: "notes_add", summary: "Adds dated follow-up notes to incidents, several in one call: items [{ incident_id (or ref + project_id), text, day? }].", input: { items: "list of { incident_id, text, day }" } }, (i, { actor }) => notesAdd(db, i, actor, now()));
  command(app, "POST", "/notes/:id/remove", { name: "note_remove", by: "person", summary: "Takes one follow-up note away. A person's decision." }, (i) => noteRemove(db, i));
  command(app, "GET", "/visits", { name: "visits", of: "visit", summary: "The site visits, newest first, each with how many incidents it found and how many are still open. project_id for one project.", input: { project_id: "project id" } }, (i) => visits(db, i));
  command(app, "GET", "/visits/:id", { name: "visit", on: "visit", summary: "One visit: its day, who was there, its summary and the incidents found that day." }, (i) => visit(db, i));
  command(app, "POST", "/visits", { name: "visit_add", summary: "The visit of a day (one per project and day; adding it again answers the one there is). To add it WITH what was found, use incidents_add with visit.", input: { project_id: "project id", day: "YYYY-MM-DD, today unless said", attendees: "who was there", summary: "text" } }, (i) => visitAdd(db, i, now()));
  command(app, "POST", "/visits/:id", { name: "visit_update", on: "visit", summary: "Changes a visit's day, attendees or summary.", input: { day: "YYYY-MM-DD", attendees: "text", summary: "text" } }, (i) => visitUpdate(db, i));
  command(app, "GET", "/procedures", { name: "procedures", of: "procedure", summary: "The procedures (licences, connections, insurance, deposits\u2026), what is under way first, each with its state and next step. project_id; state: open | pending | in_progress | blocked | done.", input: { project_id: "project id", state: "open | pending | in_progress | blocked | done", full: "true for every row whole" } }, (i, { actor }) => procedures(db, i, wantsFull(i, actor), now()));
  command(app, "POST", "/procedures", { name: "procedures_add", summary: "Adds several procedures in one call: items [{ title, kind, state, next_step, next_on, responsible, notes }]. kind: licence | connection | insurance | deposit | contract | legal | other.", input: { project_id: "project id", items: "list" } }, (i) => proceduresAdd(db, i));
  command(app, "POST", "/procedures/update", { name: "procedures_update", summary: "Changes several procedures in one call: items [{ id, state?, next_step?, next_on?, \u2026, remove? }]. state done sets its date. Answers { changed, skipped }.", input: { items: "list" } }, (i) => proceduresUpdate(db, i, now()));
  command(app, "POST", "/attachments", { name: "attachments_add", summary: "Attaches files, several in one call: items [{ incident_id | visit_id | project_id, kind: photo | plan | doc, name, note, and ONE of path (in the team's files folder), url, or data (a data URL under 2 MB) }].", input: { project_id: "project id, for items that name none", items: "list" } }, (i) => add2(db, i));
  command(app, "GET", "/attachments", { name: "attachments", summary: "What a project has attached, names only. kind: photo | plan | doc.", input: { project_id: "project id", kind: "photo | plan | doc" } }, (i) => list3(db, i));
  command(app, "GET", "/attachments/:id", { name: "attachment", summary: "One file with its bytes, for the screen. An agent is refused: a file's name, note and place are in incident.", input: { full: "true to get the bytes anyway (large)" } }, (i, { actor }) => one2(db, i, isPerson(actor)));
  command(app, "POST", "/attachments/:id/remove", { name: "attachment_remove", by: "person", summary: "Takes an attached file away. A person's decision." }, (i) => remove2(db, i));
  command(app, "POST", "/pin", { name: "pin_set", summary: "Places an incident on one of its project's plans: incident_id, plan_id, x and y from 0 to 1. plan_id null takes the pin away.", input: { incident_id: "incident id", plan_id: "attachment id of the plan, or null", x: "0 to 1 from the left", y: "0 to 1 from the top" } }, (i) => pinSet(db, i));
  command(app, "GET", "/plans/:plan_id/pins", { name: "plan_pins", summary: "The incidents placed on one plan, each with where." }, (i) => planPins(db, i));
  command(app, "GET", "/reports", { name: "reports", of: "report", summary: "The monthly reports there are, newest month first. project_id for one project.", input: { project_id: "project id" } }, (i) => list4(db, i));
  command(app, "GET", "/reports/to-prepare", { name: "reports_to_prepare", summary: "The projects whose report of last month is not made yet (the trigger): { items: [{ key, text, project_id, project, period }] }." }, () => toPrepare(db, now()));
  command(app, "GET", "/reports/:id", { name: "report", on: "report", summary: "One report: its two texts and the month in figures. full=true answers everything its page draws (large).", input: { full: "true for everything the page draws" } }, (i, { actor }) => one3(db, i, wantsFull(i, actor)));
  command(app, "POST", "/reports", { name: "report_draft", summary: "Makes (or finds) a project's report of a month \u2014 last month unless period (YYYY-MM) \u2014 and answers the month in figures and what to write.", input: { project_id: "project id", period: "YYYY-MM", language: "ca | es (the setting unless said)" } }, (i) => draft(db, i, now()));
  command(app, "POST", "/reports/:id/write", { name: "report_write", on: "report", summary: "Writes a report's texts, in the report's language: summary (the month in 5 to 8 lines) and outlook (what comes next). Refused once reviewed.", input: { summary: "text", outlook: "text", language: "ca | es" } }, (i) => write(db, i));
  command(app, "POST", "/reports/:id/review", { name: "report_review", on: "report", by: "person", label: { es: "Dar por revisado", en: "Mark as reviewed" }, summary: "The person's yes to a report: from then it keeps that day's figures. A person's decision." }, (i, { actor }) => review(db, i, actor, now()));
  command(app, "POST", "/reports/:id/reopen", { name: "report_reopen", on: "report", by: "person", label: { es: "Volver a borrador", en: "Back to draft" }, summary: "Takes a reviewed report back to a draft, with today's figures. A person's decision." }, (i) => reopen(db, i));
  command(app, "GET", "/hours", { name: "hours", of: "timesheet", summary: "Hours worked, summed by worker and by project over a time (this month unless from/to). project_id, worker; full=true every line.", input: { project_id: "project id", worker: "name", from: "YYYY-MM-DD", to: "YYYY-MM-DD", full: "true for every line" } }, (i, { actor }) => hours(db, i, wantsFull(i, actor), now()));
  command(app, "POST", "/hours", { name: "hours_add", summary: "Adds lines of hours, several in one call: items [{ worker, day, hours, task?, project_id? }]. The same line twice is added once.", input: { project_id: "project id, for items that name none", items: "list" } }, (i) => hoursAdd(db, i));
  command(app, "POST", "/hours/:id/remove", { name: "hours_remove", by: "person", summary: "Takes one line of hours away. A person's decision." }, (i) => hoursRemove(db, i));
  command(app, "POST", "/import", { name: "import_rows", summary: "Brings rows of an old table in as incidents, hours or projects, mapping their columns by name. dry_run (the default) only answers what it would do; dry_run: false writes. A row sent twice is added once.", input: { kind: "incidents | hours | projects", rows: "list of rows as they are in the old table (500 at most)", table: "the old table's name: part of where each row is remembered to come from", project_id: "the project, when the rows name none", project_map: '{ "<their project value>": <project id> }', map: '{ "<their column>": "<field>" } for what was not recognised', dry_run: "false to write" } }, (i, { actor }) => importRows(db, i, actor, now()));
  command(app, "GET", "/settings", { name: "settings", of: "config", summary: "The module's settings: the name reports are signed with, their language (ca | es), colour and footer." }, () => settings(db));
  command(app, "POST", "/settings/:id", { name: "set_settings", on: "config", by: "admin", partial: true, summary: "Changes the settings: company_name, report_language (ca | es), report_accent (#RRGGBB), report_footer.", input: ["company_name", "report_language", "report_accent", "report_footer"] }, (i) => setSettings(db, i));
  command(app, "GET", "/needs", { name: "page_needs", summary: "What a page still needs to be complete: { needs: [{ id, kind, title, unlocks, door, place }] }. Empty when nothing is missing." }, () => pageNeeds(db));
  command(app, "POST", "/example", { name: "example_load", by: "person", summary: "Loads the example project (invented) into a module with no project yet. A person's button." }, () => load(db, now()));
  command(app, "POST", "/example/remove", { name: "example_remove", summary: "Takes the example project away with everything in it. It also leaves by itself when the first real project is added." }, () => removeDemo(db));
}

// server/app.mjs
function createApp(db, deps = {}) {
  const app = new Hono2();
  mountErrors(app);
  obras_default(app, db, deps);
  return app;
}

// server/db.mjs
function dataClient(url = process.env.APP_DATA_URL, token = process.env.APP_DATA_TOKEN) {
  const call = async (path, body) => {
    const r = await fetch(`${url}${path}`, { method: "POST", headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` }, body: JSON.stringify(body) });
    const j = await r.json().catch(() => null);
    if (!r.ok || !j) throw new Error(j?.error ?? `Data ${r.status}`);
    return j;
  };
  return {
    all: async (sql, params = []) => (await call("/all", { sql, params })).rows,
    one: async (sql, params = []) => (await call("/all", { sql, params })).rows[0] ?? null,
    insert: async (table, data) => (await call("/batch", { ops: [{ op: "insert", table, data }] })).ids[0],
    update: async (table, id, data, where = {}) => (await call("/update", { table, id, data, where })).changed,
    batch: async (ops) => (await call("/batch", { ops })).ids,
    // Which of the modules app.json `suggests` are installed for the company: [{ module, installed, name, version, for, unlocks }].
    // Read when asked, never kept; nothing of the other module is reachable (the guide: «Modules unlock each other»).
    peers: async () => (await call("/peers", {})).peers,
    // One read command another module EXPORTS and app.json `reads` declares: { installed: false } when that module is
    // not installed, else { installed: true, result }. Never its tables, never a write (the guide: «Reading another module»).
    read: async (module, command2, params = {}) => call("/read", { module, command: command2, params })
  };
}

// server/main.mjs
serve({ fetch: createApp(dataClient()).fetch, hostname: "127.0.0.1", port: Number(process.env.PORT) });
