// One post: the editor beside its preview and notes. What can be done
// follows its status — a draft is approved (it goes to the account's next
// free time, or the one chosen), saved, rewritten by the agent (with an
// instruction, or the notes), or dropped; an approved post can change until
// it goes out, go back to draft, or go out now; a failed one says why.
// /new and /new/:account/:at write a new post (compose.js).
import { A, C, T, accountSaid, accounts, act, at, badge, field, fromInput, input, net, pillars, select, settings, statusOf, takenOf, toInput, area, unwatch, watchFor, whereSaid, whereShort } from '../data.js';
import { preview } from './preview.js';
import { addNote, notesPanel } from './notes.js';
import { compose } from './compose.js';
import { askRewrite, published, sentence } from './postbits.js';

const { el, router } = Orch;

export function render(params = {}) {
  if (params.fresh) return compose(params);
  const id = Number(params.id);
  Orch.load('view', async () => {
    const s = await settings(true);
    const p = await Orch.db.get(T.posts, id);
    if (!p) return el('div', { class: 'oc-state' }, [el('p', 'This post is not here.'), router.link('/', 'To the week')]);
    const [list, notes, allPillars] = await Promise.all([accounts(), Orch.db.list(T.notes, { filter: { post_id: id }, sort: '_id:asc', limit: 100 }), pillars()]);
    const pillar = p.pillar_id ? allPillars.find((x) => x._id === p.pillar_id) : null;
    const acct = list.find((a) => a._id === p.account_id) || null;
    const st = statusOf(p);
    if (p.status === 'Writing' || p.status === 'Publishing') {
      watchFor('post', { was: `${p.status}·${p.tries || 0}`, read: async () => { const x = await Orch.db.get(T.posts, id); return x ? `${x.status}·${x.tries || 0}` : 'gone'; },
        here: () => location.hash === `#/post/${id}`, redraw: () => render(params) });
    } else unwatch('post');
    const editable = p.status === 'Draft' || p.status === 'Scheduled';
    const again = () => render(params);

    const net0 = (acct && acct.network) || p.network;
    // On X a thread is several posts, each within the limit: the box takes them all; the counter says each one.
    const text = area(p.text || '', 12, { maxlength: String(net0 === 'x' ? C.limitOf('x', acct) * C.NETWORKS.x.thread + 200 : C.netOf(net0).limit), readonly: !editable, 'aria-label': 'The post' });
    const who = select(p.account_id || '', [['', 'Choose an account'], ...list.filter((a) => a.active === 'yes' || a._id === p.account_id).map((a) => [a._id, accountSaid(a)])]);
    who.disabled = p.status !== 'Draft';
    const time = input(toInput(p.publish_at), { type: 'datetime-local', 'aria-label': 'When it goes out' });
    time.disabled = !editable;
    const counter = el('span', { class: 'oc-value po-count' });
    const pvBox = el('div');
    const current = () => list.find((a) => a._id === Number(who.value)) || acct;
    const redraw = () => {
      const a = current();
      const n = (a && a.network) || p.network || 'linkedin';
      const limit = C.limitOf(n, a);
      if (n === 'x') {
        // Each post of a thread counts on its own (a line holding only --- starts the next one), with the number it goes out with.
        const lens = C.numberThread(C.partsOf(text.value)).map((t) => C.xLength(t));
        const over = lens.some((l) => l > limit) || lens.length > C.NETWORKS.x.thread;
        counter.textContent = lens.length > 1 ? `Thread · ${lens.length} posts · ${lens.map((l) => `${l}`).join(' · ')} / ${limit} each` : `${lens[0] || 0} / ${limit} · X counts a link as 23 · a line with --- starts a thread`;
        counter.classList.toggle('po-count--over', over);
      } else {
        const len = [...String(text.value)].length;
        counter.textContent = `${len} / ${limit}`;
        counter.classList.toggle('po-count--over', len > limit);
      }
      pvBox.replaceChildren(preview({ account: a, network: n, text: text.value, notes: notes.rows || [],
        onSelect: p.status === 'Draft' ? async (sel) => { if (await addNote(p, sel)) again(); } : null }));
    };
    text.addEventListener('input', redraw);
    who.addEventListener('change', redraw);
    redraw();
    // The editor grows with the text (no big empty box, no inner scroll).
    const fit = () => { text.style.height = 'auto'; text.style.height = `${Math.max(180, text.scrollHeight + 4)}px`; };
    text.addEventListener('input', fit);
    requestAnimationFrame(fit);

    const values = () => {
      const a = current();
      return { id, text: String(text.value).trim(), account_id: a ? a._id : null, network: a ? a.network : p.network, publish_at: fromInput(time.value) };
    };
    const nextFree = async (a) => {
      const taken = await takenOf(a._id, id);
      return C.freeSlots({ slots: a.slots, taken, tz: s.timezone || 'UTC', from: new Date(), count: 1, days: 60 })[0] || null;
    };
    const busy = (b, fn) => async () => { b.disabled = true; try { await fn(); } finally { b.disabled = false; } };

    const tools = [];
    if (p.status === 'Draft') {
      const approve = el('button', { type: 'button', class: 'oc-btn oc-btn--primary' }, 'Approve');
      const label = () => { const a = current(); approve.textContent = a ? `Approve · ${whereShort(a)}` : 'Approve'; };
      who.addEventListener('change', label);
      label();
      approve.addEventListener('click', busy(approve, async () => {
        const v = values();
        const a = current();
        if (!a) { Orch.toast('Choose the account it goes out as.', { error: true }); who.focus(); return; }
        if (a.active !== 'yes') { Orch.toast(`${a.name} is off: turn it on in Settings first.`, { error: true }); return; }
        const c = C.checkDraft(C.finalText(v.text, s), a.network, a);
        if (!c.ok) { Orch.toast(`It cannot go out: ${c.why}.`, { error: true }); return; }
        let when = v.publish_at;
        if (!when || new Date(when).getTime() < Date.now() + 60000) when = await nextFree(a);
        if (!when) { Orch.toast(`${a.name} has no free time in the next weeks: choose one, or add times in Settings.`, { error: true }); return; }
        if (await act(A.approve, Object.assign(v, { publish_at: when }), `Approved: ${at(when)}, on ${whereSaid(a)}.`)) router.go('/');
      }));
      const save = el('button', { type: 'button', class: 'oc-btn' }, 'Save');
      save.addEventListener('click', busy(save, async () => { if (await act(A.saveDraft, values(), 'Saved.')) again(); }));
      const another = el('button', { type: 'button', class: 'oc-btn' }, 'Another version');
      another.addEventListener('click', () => askRewrite(p, A.rewrite, again));
      const open = (notes.rows || []).filter((n) => !n.resolved_at).length;
      const withNotes = open ? el('button', { type: 'button', class: 'oc-btn' }, `Rewrite with my ${open} note${open === 1 ? '' : 's'}`) : null;
      if (withNotes) withNotes.addEventListener('click', busy(withNotes, async () => { if (await act(A.rewrite, { id, rewrite_note: 'Fix the notes.' }, 'Rewriting it…')) again(); }));
      const drop = el('button', { type: 'button', class: 'oc-btn oc-btn--ghost po-danger' }, 'Drop');
      drop.addEventListener('click', async () => { if (await Orch.confirm('Drop this draft? It stays in the list of dropped posts, and its idea is not used again.', { yes: 'Drop it' }) && await act(A.drop, { id }, 'Dropped.')) router.go('/'); });
      tools.push(approve, save, another, withNotes, drop);
    } else if (p.status === 'Scheduled') {
      const save = el('button', { type: 'button', class: 'oc-btn oc-btn--primary' }, 'Save');
      save.addEventListener('click', busy(save, async () => {
        const v = values();
        if (!v.publish_at || new Date(v.publish_at).getTime() < Date.now()) { Orch.toast('Choose a time ahead, or use Publish now.', { error: true }); return; }
        if (await act(A.saveScheduled, { id, text: v.text, publish_at: v.publish_at }, 'Saved.')) again();
      }));
      const back = el('button', { type: 'button', class: 'oc-btn' }, 'Back to draft');
      back.addEventListener('click', busy(back, async () => { if (await act(A.unschedule, { id }, 'Back to draft: it will not go out.')) again(); }));
      const now = el('button', { type: 'button', class: 'oc-btn oc-btn--ghost' }, 'Publish now');
      now.addEventListener('click', async () => {
        const a = current();
        const said = s.rehearsal === 'yes' ? `Rehearsal is on: it is checked and marked for ${whereSaid(a)}, nothing goes out.` : `It goes out now on ${whereSaid(a)}, for everyone to see.`;
        if (!await Orch.confirm(`Publish now? ${said}`, { yes: 'Publish now' })) return;
        if (!await act(A.publishNow, { id, publish_at: C.isoZ(new Date()) }, s.rehearsal === 'yes' ? 'Rehearsing it…' : 'Going out…')) return;
        // The run starts on its own a moment later: watch the post until it is no longer Scheduled, then show it.
        now.disabled = true; now.textContent = s.rehearsal === 'yes' ? 'Rehearsing…' : 'Going out…';
        watchFor('post', { was: 'Scheduled', read: async () => { const x = await Orch.db.get(T.posts, id); return x ? x.status : 'gone'; },
          here: () => location.hash === `#/post/${id}`, redraw: again, first: 3000 });
      });
      tools.push(save, back, now);
    } else if (p.status === 'Published' && p.rehearsed === 'yes') {
      // Rehearsed: nothing went out, so it can become a draft again and be approved for real (its time kept if still ahead).
      const back = el('button', { type: 'button', class: 'oc-btn oc-btn--primary' }, 'Back to draft');
      back.addEventListener('click', busy(back, async () => {
        const ahead = p.publish_at && new Date(p.publish_at).getTime() > Date.now() + 60000 ? p.publish_at : null;
        if (await act(A.unrehearse, { id, publish_at: ahead }, 'Back to draft: approve it when you want it to go out for real.')) again();
      }));
      tools.push(back);
    } else if (p.status === 'Failed') {
      const back = el('button', { type: 'button', class: 'oc-btn oc-btn--primary' }, 'Back to draft');
      back.addEventListener('click', async () => {
        if (p.unsure === 'yes' && !await Orch.confirm(`It may already be live on ${net(p.network)}. Look at the account first: approving it again could publish it twice.`, { yes: 'I looked: back to draft' })) return;
        if (await act(A.retry, { id }, 'Back to draft.')) again();
      });
      const another = el('button', { type: 'button', class: 'oc-btn' }, 'Another version');
      another.addEventListener('click', () => askRewrite(p, A.rewriteFailed, again));
      tools.push(back, another);
    }

    const title = acct ? `${acct.network === 'linkedin' ? (acct.kind === 'person' ? 'LinkedIn' : 'LinkedIn page') : net(acct.network)} · ${acct.name}` : 'A post';
    return el('div', { class: 'po-page' }, [
      el('header', { class: 'po-posthead' }, [
        router.link('/', '← Week', { class: 'po-back' }),
        el('div', { class: 'po-posthead__line' }, [el('h1', { class: 'oc-h1 po-title' }, title), badge(st)]),
        el('p', { class: 'oc-lede po-posthead__lede' }, sentence(p, s)),
      ]),
      p.error && p.status !== 'Published' ? el('p', { class: p.status === 'Failed' ? 'po-bad po-box' : 'po-warn' }, p.error) : null,
      el('div', { class: 'po-split' }, [
        el('div', { class: 'po-editor' }, [
          el('label', { class: 'oc-field' }, [el('span', { class: 'oc-label' }, 'The post'), text]),
          el('div', { class: 'po-editor__under' }, [counter, s.signature_auto === 'yes' && s.signature ? el('span', { class: 'oc-help' }, 'Your signature is added when it goes out.') : null]),
          p.status === 'Published' ? published(p) : null,
          tools.length ? el('div', { class: 'po-actions po-actions--bar' }, tools.filter(Boolean)) : null,
        ]),
        el('aside', { class: 'po-side' }, [
          el('section', { class: 'po-side__block' }, [el('h2', { class: 'po-side__title' }, 'Preview'), pvBox]),
          el('section', { class: 'po-side__block' }, [el('h2', { class: 'po-side__title' }, 'Details'),
            el('div', { class: 'po-details-grid' }, [
              field('Goes out as', who),
              field('When', time, p.status === 'Draft' ? 'Empty or past: the account\'s next free time when you approve.' : `In ${s.timezone || 'UTC'}.`),
              pillar ? el('div', { class: 'oc-field' }, [el('span', { class: 'oc-label' }, 'Pillar'), el('span', { class: 'po-side__pillar' }, [router.link('/pillars', pillar.name), pillar.belief ? el('span', { class: 'po-muted po-small' }, pillar.belief) : null])]) : null,
            ])]),
          notesPanel(notes.rows || [], { editable: p.status === 'Draft', again }),
        ]),
      ]),
    ]);
  });
}
