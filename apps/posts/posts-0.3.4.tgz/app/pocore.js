/**
 * Posts · what the desk and the scripts must agree on: the networks and their
 * limits, the posting times of an account (days and local hours, Postiz's
 * postingTimes), the next free slot, time in the workspace's zone, the
 * signature, the "…see more" fold, what an agent's draft may be, and a
 * post's link. Pure functions, no database, no DOM. test/sync.js copies it
 * to app/ and automations/.
 */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.PoCore = api;
}(typeof self !== 'undefined' ? self : this, () => {
  'use strict';

  const langOf = (v) => (v === 'en' ? 'en' : 'es');
  /**
   * The networks Posts publishes to (read live on staging 2026-10-10).
   * LinkedIn and Facebook through Composio; X through the `twitter` skill and
   * the account's own keys (Integrations → X), because Composio cannot
   * connect X. Text only for now: none of them takes our own image bytes.
   *   via     composio toolkit, or skill
   *   kinds   who an account is on that network
   *   limit   characters of a post (X counts its own way: the skill checks);
   *           on X an account with X Premium may go to `long`, and a thread
   *           is up to `thread` posts, each one within the limit
   *   fold    what shows before "…see more"; cost: what X charges per post
   */
  const NETWORKS = {
    linkedin: { name: 'LinkedIn', via: 'composio', toolkit: 'linkedin', limit: 3000, fold: 210, kinds: { person: 'Profile', organization: 'Company page' } },
    x: { name: 'X', via: 'skill', skill: 'twitter', limit: 280, long: 25000, thread: 10, fold: 280, kinds: { account: 'Account' }, cost: { post: 0.015, link: 0.2 } },
    facebook: { name: 'Facebook', via: 'composio', toolkit: 'facebook', limit: 63206, fold: 480, kinds: { page: 'Page' } },
  };
  const netOf = (n) => NETWORKS[n] || NETWORKS.linkedin;
  /** An X account with X Premium posts up to 25,000 characters (Settings → Accounts says so). */
  const premiumOf = (account) => !!account && account.network === 'x' && account.premium === 'yes';
  /** The characters one post may have, for this network and account. */
  const limitOf = (network, account) => (network === 'x' && premiumOf(account) ? NETWORKS.x.long : netOf(network).limit);
  /** A line holding only --- separates the posts of an X thread (the twitter skill's own format). */
  const THREAD_SEP = /^[ \t]*---[ \t]*$/m;
  /** The posts of a text: one, or each post of an X thread. */
  const partsOf = (text) => String(text || '').split(new RegExp(THREAD_SEP.source, 'gm')).map((x) => x.trim()).filter(Boolean);
  /** About as X counts: every link 23 (the twitter skill counts exactly before anything goes out). */
  function xLength(text) {
    const links = String(text || '').match(/https?:\/\/\S+/g) || [];
    return [...String(text || '').replace(/https?:\/\/\S+/g, '')].length + links.length * 23;
  }
  const LIMIT = NETWORKS.linkedin.limit;
  const FOLD = NETWORKS.linkedin.fold;
  const URN = /^urn:li:(person|organization):[A-Za-z0-9_-]+$/;
  const POST_URN = /urn:li:(?:share|ugcPost|activity):\d+/;
  const kindOf = (urn) => ((String(urn || '').match(URN) || [])[1] || '');
  /** The post on its network. */
  function postUrl(network, ref) {
    const r = String(ref || '');
    if (network === 'x') return /^\d{5,25}$/.test(r) ? `https://x.com/i/web/status/${r}` : '';
    if (network === 'facebook') return /^\d+_\d+$/.test(r) ? `https://www.facebook.com/${r.replace('_', '/posts/')}` : '';
    return POST_URN.test(r) ? `https://www.linkedin.com/feed/update/${r.match(POST_URN)[0]}/` : '';
  }

  // ── time in the workspace's zone ───────────────────────────────────────
  const DAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  const DAYS_ES = ['lun', 'mar', 'mié', 'jue', 'vie', 'sáb', 'dom'];
  function zoneOk(tz) { try { new Intl.DateTimeFormat('en', { timeZone: tz }); return true; } catch { return false; } }
  /** A moment's wall clock in a zone: { y, m, d, hh, mm, dow (1 = Monday), ymd, hm }. */
  function local(date, tz) {
    const p = Object.fromEntries(new Intl.DateTimeFormat('en-US', { timeZone: zoneOk(tz) ? tz : 'UTC', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', weekday: 'short', hourCycle: 'h23' })
      .formatToParts(date).map((x) => [x.type, x.value]));
    const out = { y: +p.year, m: +p.month, d: +p.day, hh: +p.hour % 24, mm: +p.minute, dow: DAYS.indexOf(p.weekday) + 1 };
    out.ymd = `${p.year}-${p.month}-${p.day}`;
    out.hm = `${String(out.hh).padStart(2, '0')}:${p.minute}`;
    return out;
  }
  /** The moment a wall clock ('YYYY-MM-DD', 'HH:MM') in a zone stands for. */
  function zoned(ymd, hm, tz) {
    const [y, m, d] = ymd.split('-').map(Number);
    const [hh, mm] = hm.split(':').map(Number);
    let t = Date.UTC(y, m - 1, d, hh, mm);
    for (let i = 0; i < 3; i += 1) {
      const l = local(new Date(t), tz);
      const diff = Date.UTC(l.y, l.m - 1, l.d, l.hh, l.mm) - Date.UTC(y, m - 1, d, hh, mm);
      if (!diff) break;
      t -= diff;
    }
    return new Date(t);
  }
  const addDays = (ymd, n) => { const t = new Date(`${ymd}T12:00:00Z`); t.setUTCDate(t.getUTCDate() + n); return t.toISOString().slice(0, 10); };
  /** The Monday of the week a day is in. */
  const monday = (ymd) => { const t = new Date(`${ymd}T12:00:00Z`); return addDays(ymd, -((t.getUTCDay() + 6) % 7)); };
  const dowOf = (ymd) => ((new Date(`${ymd}T12:00:00Z`).getUTCDay() + 6) % 7) + 1;
  const isoZ = (d) => `${new Date(d).toISOString().slice(0, 16)}:00Z`;
  const HM = /^([01]\d|2[0-3]):[0-5]\d$/;

  // ── an account's posting times ─────────────────────────────────────────
  /** Weekdays at 09:00: a sane start; each account changes its own. */
  const DEFAULT_SLOTS = [1, 2, 3, 4, 5].map((d) => ({ d, t: '09:00' }));
  /** An account's slots as [{ d: 1..7 (Monday 1), t: 'HH:MM' }], sorted, without repeats. */
  function slotsOf(text) {
    let list = text;
    if (typeof text === 'string') { try { list = JSON.parse(text); } catch { list = null; } }
    if (!Array.isArray(list)) return [];
    const seen = new Set();
    return list.map((x) => ({ d: Number(x && x.d), t: String((x && x.t) || '') }))
      .filter((x) => x.d >= 1 && x.d <= 7 && HM.test(x.t) && !seen.has(`${x.d} ${x.t}`) && seen.add(`${x.d} ${x.t}`))
      .sort((a, b) => a.d - b.d || a.t.localeCompare(b.t));
  }
  /** Slots from the form: the days ticked × the times written ("09:00, 13:30"). */
  function slotsFrom(days, times) {
    const ts = String(times || '').split(/[\s,;]+/).map((x) => x.trim().replace(/^(\d):/, '0$1:')).filter((x) => HM.test(x));
    return slotsOf(days.flatMap((d) => ts.map((t) => ({ d, t }))));
  }
  /** "Mon–Fri 09:00" and the like, for a row. */
  function slotsSaid(slots, lang) {
    const list = slotsOf(slots);
    if (!list.length) return lang === 'es' ? 'sin horarios' : 'no times';
    const names = lang === 'es' ? DAYS_ES : DAYS;
    const byTime = {};
    for (const s of list) (byTime[s.t] = byTime[s.t] || []).push(s.d);
    const days = (ds) => {
      const out = [];
      for (let i = 0; i < ds.length; i += 1) {
        let j = i;
        while (j + 1 < ds.length && ds[j + 1] === ds[j] + 1) j += 1;
        out.push(j - i >= 2 ? `${names[ds[i] - 1]}–${names[ds[j] - 1]}` : ds.slice(i, j + 1).map((x) => names[x - 1]).join(', '));
        i = j;
      }
      return out.join(', ');
    };
    return Object.entries(byTime).map(([t, ds]) => `${days(ds)} ${t}`).join(' · ');
  }
  /**
   * The next free moments of an account, from `from` on: its slots in the
   * zone, minus the times already taken (ISO strings, compared to the
   * minute). [ISO …], at most `count`, looking `days` ahead.
   */
  function freeSlots({ slots, taken = [], tz, from = new Date(), count = 1, days = 28 }) {
    const list = slotsOf(slots);
    if (!list.length) return [];
    const busy = new Set(taken.filter(Boolean).map((x) => isoZ(x)));
    const out = [];
    const start = local(from, tz).ymd;
    for (let i = 0; i < days && out.length < count; i += 1) {
      const ymd = addDays(start, i);
      for (const s of list.filter((x) => x.d === dowOf(ymd))) {
        const at = zoned(ymd, s.t, tz);
        if (at.getTime() <= from.getTime() + 60000) continue;
        const z = isoZ(at);
        if (busy.has(z)) continue;
        out.push(z);
        if (out.length >= count) break;
      }
    }
    return out;
  }

  // ── the text ───────────────────────────────────────────────────────────
  /** The text that goes out: the signature after a blank line, when it goes on its own and is not there yet. */
  function finalText(text, s) {
    const t = String(text || '').trim();
    const sig = String((s && s.signature) || '').trim();
    if (!sig || !s || s.signature_auto !== 'yes' || t.endsWith(sig)) return t;
    return `${t}\n\n${sig}`;
  }
  /** What shows before "…see more": the network's fold, or three lines. */
  function folded(text, network) {
    const FOLD = netOf(network).fold;
    const t = String(text || '');
    const lines = t.split('\n');
    const byLines = lines.length > 3 ? lines.slice(0, 3).join('\n').length : t.length;
    if (byLines <= FOLD && byLines < t.length) return { head: t.slice(0, byLines), more: true };
    if (t.length <= FOLD) return { head: t, more: false };
    // Cut by characters: not in the middle of a word.
    return { head: t.slice(0, FOLD).replace(/\s+\S*$/, ''), more: true };
  }
  /** Something left to fill in: [a word] (not an @[mention](urn…)), {{x}}, a line of only "…", lorem ipsum. */
  const PLACEHOLDER = /(?<!@)\[[^\]\n]{1,40}\](?!\(urn:li:)|\{\{|^\s*(?:…|\.\.\.)\s*$|lorem ipsum/im;
  /**
   * An agent's draft, cleaned, or why it is refused: { ok, text } / { ok: false, why }.
   * Quotes around it go; a placeholder, an empty text or one over the limit is refused.
   */
  function checkDraft(raw, network, account) {
    let t = String(raw == null ? '' : raw).replace(/\r\n/g, '\n').trim();
    if (/^["“«].*["”»]$/s.test(t)) t = t.slice(1, -1).trim();
    t = t.replace(/\n{3,}/g, '\n\n');
    if (t.length < 40) return { ok: false, why: 'too short or empty' };
    if (PLACEHOLDER.test(t)) return { ok: false, why: 'it has a placeholder to fill in' };
    if (network === 'x') {
      // One post, or a thread: each post within the limit (280, or 25,000 with X Premium).
      const parts = partsOf(t);
      const max = limitOf('x', account);
      if (parts.length > NETWORKS.x.thread) return { ok: false, why: `a thread of ${parts.length} posts; at most ${NETWORKS.x.thread}` };
      const over = parts.map((x, i) => ({ n: i + 1, len: xLength(x) })).filter((x) => x.len > max);
      if (over.length) {
        const o = over[0];
        return { ok: false, why: parts.length > 1 ? `post ${o.n} of the thread has ${o.len} characters as X counts them; each post is at most ${max}` : `${o.len} characters as X counts them; the limit is ${max}${max < NETWORKS.x.long ? ' (write a thread of short posts, or turn on X Premium for the account)' : ''}` };
      }
      return { ok: true, text: parts.join('\n\n---\n\n'), parts: parts.length };
    }
    const LIMIT = netOf(network).limit;
    if (t.length > LIMIT) return { ok: false, why: `over ${LIMIT} characters (${t.length})` };
    return { ok: true, text: t, parts: 1 };
  }
  /**
   * An X text too long for one post, made of paragraphs: packed into a thread
   * at its paragraph breaks (each post as full as fits). Null when a paragraph
   * alone is too long or it would take more than the thread allows. Agents
   * asked for a thread kept answering one long post (staging, 2026-10-12): the
   * script does the split, and the person still reviews the draft.
   */
  function packThread(text, account) {
    const max = limitOf('x', account);
    const paras = String(text || '').replace(/\r\n/g, '\n').split(/\n[ \t]*\n/).map((x) => x.trim()).filter(Boolean);
    if (paras.length < 2 || paras.some((x) => xLength(x) > max)) return null;
    const posts = [];
    for (const p of paras) {
      const last = posts.length ? `${posts[posts.length - 1]}\n\n${p}` : null;
      if (last && xLength(last) <= max) posts[posts.length - 1] = last;
      else posts.push(p);
    }
    return posts.length > 1 && posts.length <= NETWORKS.x.thread ? posts.join('\n\n---\n\n') : null;
  }
  /** What the agent answers: one object per post it was given. */
  /**
   * A LinkedIn text as its API reads it ("little" format, Posts API): every
   * reserved character | { } @ [ ] ( ) < > # \ * _ ~ escaped with a backslash,
   * or the post is cut or shown wrong from the first one (LinkedIn's docs:
   * "even if those characters are not used in one of the supported elements").
   * Kept as elements: a mention @[Name](urn:li:person|organization:id), and a
   * #hashtag (a word with a letter in it), sent as {hashtag|\#|word}.
   * Composio passes `commentary` through as it is (its own example is a raw mention).
   */
  const LITTLE_RESERVED = /[|{}@[\]()<>#\\*_~]/g;
  const LITTLE_TOKEN = /@\[[^\]\n]{1,200}\]\(urn:li:(?:person|organization):[A-Za-z0-9_-]+\)|(?<![\p{L}\p{N}_&\\/])#([\p{L}\p{N}_]*\p{L}[\p{L}\p{N}_]*)/gu;
  function littleText(text) {
    const s = String(text || '');
    let out = '';
    let at = 0;
    for (const m of s.matchAll(LITTLE_TOKEN)) {
      out += s.slice(at, m.index).replace(LITTLE_RESERVED, (c) => `\\${c}`);
      out += m[1] ? `{hashtag|\\#|${m[1]}}` : m[0];
      at = m.index + m[0].length;
    }
    return out + s.slice(at).replace(LITTLE_RESERVED, (c) => `\\${c}`);
  }

  const ANSWER = '{"items":[{"id":<id>,"text":"the post, ready to publish (an X thread: its posts separated by a line holding only ---)","note":"one line: what it is about and why now"}]}';
  /** How each network reads, for the agent. */
  const STYLE = {
    linkedin: 'LinkedIn: a first line that makes people click "…see more" (about 200 characters show), short paragraphs, one idea, plain words, 2 to 4 good hashtags (the topics people follow and search, that place the post: one or two woven into a sentence where the word belongs, the rest at the end; never a block of many, never a made-up one), no emoji walls. Up to 3000 characters; most good posts are 600-1300.',
    x: 'X: a thread of 4 to 10 posts when the idea is a story, steps or proof (most are), its posts separated by a line holding only ---, each one at most 280 characters (a link counts as 23). A thread exists because the story did not fit in one post, so it must read that way: every post is full, 220 to 280 characters (only the last may be shorter), never a line on its own; when a post comes out short, tell more of the story in it rather than adding another post; or one short post of at most 280 characters when the point is small and lands alone. The first post stands alone: the point or the hook in the first words, it must make sense to someone who never opens the rest; each next post adds one thing; the last one lands it. Do not number the posts unless the order matters. No hashtags unless one really helps. Each post costs US$0.015, a post with a link US$0.20: a link only when it is the point, best in the last post.',
    x_long: 'X with X Premium: a thread of 4 to 10 posts separated by a line holding only --- when it is a story or steps (most are), every post full, 220 to 280 characters (only the last may be shorter), never a line on its own, one long post of up to about 2000 characters when it reads better in one piece (X shows about the first 280 before "Show more": put the point there), or one short post (under 280 characters reads best) when the point is small and lands alone. The point in the first words. No hashtags unless one really helps. Each post costs US$0.015, a post with a link US$0.20: a link only when it is the point.',
    x_short: 'X, a short: one post of at most 280 characters, never a thread. Light and human: a question you would really like answered by people building with agents, an ironic or funny observation, a quick take. It still makes sense to a stranger scrolling past, with no story set up and no lesson at the end. No hashtags.',
    facebook: 'A Facebook page: friendly and short (most good posts are under 500 characters), one clear thing to do or know, a link when there is one.',
  };

  /** How this account's network reads, for the agent. */
  const styleOf = (network, account) => (network === 'x' && premiumOf(account) ? STYLE.x_long : STYLE[network] || STYLE.linkedin);

  // ── pillars: the directions every post leans on ────────────────────────
  /**
   * Which pillar each of the next n posts leans on: the active pillar furthest
   * below its share (weight / total weight) of the recent posts, the slots
   * taken so far counted too. recent: pillar ids of the last posts (newest
   * first; null for posts with none). Ties: the pillar used longest ago, then
   * the first. No active pillar: n nulls.
   */
  function pillarsFor(pillars, recent, n) {
    const on = (pillars || []).filter((p) => p && p.active !== 'no' && (Number(p.weight) || 0) > 0);
    if (!on.length) return Array(Math.max(0, n)).fill(null);
    const total = on.reduce((a, p) => a + Number(p.weight), 0);
    const ids = (recent || []).slice();
    const out = [];
    for (let k = 0; k < n; k += 1) {
      const counted = ids.filter((x) => x != null);
      const len = counted.length || 1;
      const lastAt = (id) => { const i = ids.indexOf(id); return i < 0 ? Infinity : i; };
      const score = (p) => Number(p.weight) / total - counted.filter((x) => x === p._id).length / len;
      const best = on.slice().sort((a, b) => (score(b) - score(a)) || (lastAt(b._id) - lastAt(a._id)) || (a._id - b._id))[0];
      out.push(best._id);
      ids.unshift(best._id);
    }
    return out;
  }

  /** A pillar as the writer reads it. */
  const pillarSaid = (p) => (p ? { name: p.name || '', believe: p.belief || '', angle: p.angle || undefined, against: p.against || undefined, references: p.refs || undefined } : null);

  // ── the words of a status ──────────────────────────────────────────────
  const STATUS = ['Writing', 'Draft', 'Scheduled', 'Publishing', 'Published', 'Failed', 'Dropped'];

  return {
    langOf, NETWORKS, netOf, premiumOf, limitOf, THREAD_SEP, partsOf, xLength, styleOf, STYLE, LIMIT, FOLD, URN, POST_URN, kindOf, postUrl, DAYS, DAYS_ES, zoneOk, local, zoned, addDays, monday, dowOf, isoZ, HM,
    DEFAULT_SLOTS, slotsOf, slotsFrom, slotsSaid, freeSlots, finalText, folded, checkDraft, packThread, littleText, ANSWER, STATUS, pillarsFor, pillarSaid,
  };
}));
