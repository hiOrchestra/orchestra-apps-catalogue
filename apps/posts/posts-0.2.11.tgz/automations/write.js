'use strict';
/**
 * Posts · Write: the posts waiting to be written (status Writing — the weekly
 * proposal, Write it on an idea, Another version, Rewrite with my notes).
 *
 *   pick   claims up to 6 (claimed_at, atomic), and gives the agent everything
 *          it needs as one JSON: the voice, the examples, what to avoid, each
 *          post's network and account, its pillar (what we believe, our angle,
 *          what we push against, references), its idea (and the page of its link,
 *          the text of its file from Files), its template, and — to rewrite —
 *          the current text, the person's instruction and their notes; plus
 *          the last posts (not to repeat them) and the ones that did best.
 *   save   reads the agent's JSON (PRIOR), checks each text (pocore.checkDraft)
 *          and saves it as a Draft; a missing or refused one is tried again
 *          by the next run, three times, then says why.
 *
 * The agent only answers JSON: it never writes to the database.
 *   node write.js pick | save
 */
const { execFileSync } = require('child_process');
const fs = require('fs');
const os = require('os');
const path = require('path');
const L = require('./lib');
const C = require('./pocore');

const MAX = 6;
const STALE_MIN = 30;
const TRIES = 3;
const LANG = { es: 'Spanish', en: 'English' };

/** The readable text of a web page, at most n characters (a link on an idea). */
function pageText(url, n = 4000) {
  if (!/^https?:\/\//i.test(url || '')) return '';
  if (process.env.PO_FAKE_FEEDS) { try { return String(JSON.parse(fs.readFileSync(process.env.PO_FAKE_FEEDS, 'utf8')).pages[url] || '').slice(0, n); } catch { return ''; } }
  try {
    const html = execFileSync('curl', ['-sSL', '--max-time', '15', '--max-filesize', '3000000', '-A', 'Mozilla/5.0 (compatible; OrchestraPosts/0.1)', url], { encoding: 'utf8', timeout: 20000, maxBuffer: 8 << 20 });
    return html.replace(/<(script|style|noscript|svg|nav|footer|header)[\s\S]*?<\/\1>/gi, ' ').replace(/<[^>]+>/g, ' ').replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&')
      .replace(/&#39;|&apos;/g, "'").replace(/&quot;/g, '"').replace(/\s+/g, ' ').trim().slice(0, n);
  } catch { return ''; }
}
/** The text of a file in Files (md, txt, html, pdf, docx), at most n characters. */
function fileText(id, name, n = 6000) {
  if (!id) return '';
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'posts-file-'));
  try {
    const ext = String(path.extname(name || '').slice(1) || 'txt').toLowerCase();
    const file = path.join(dir, `f.${ext}`);
    if (!L.fileDownload(id, file).ok) return '';
    if (ext === 'pdf') return execFileSync('pdftotext', ['-layout', file, '-'], { encoding: 'utf8', timeout: 30000 }).slice(0, n);
    if (['docx', 'odt', 'html', 'htm'].includes(ext)) return execFileSync('pandoc', [file, '-t', 'plain', '--wrap=none'], { encoding: 'utf8', timeout: 30000 }).slice(0, n);
    return fs.readFileSync(file, 'utf8').slice(0, n);
  } catch { return ''; } finally { fs.rmSync(dir, { recursive: true, force: true }); }
}
const accountSaid = (a) => (a ? `${C.netOf(a.network).name} · ${C.netOf(a.network).kinds[a.kind] || a.kind} · ${a.name}${a.handle ? ` (${a.network === 'x' ? '@' : ''}${a.handle})` : ''}` : 'no account');

function pick() {
  const s = L.settings();
  const now = L.sqlNow();
  const stale = L.sqlNow(new Date(L.now().getTime() - STALE_MIN * 60000));
  const rows = L.all(`SELECT * FROM po_posts WHERE _deleted = 0 AND status = 'Writing' AND (tries IS NULL OR tries < ${TRIES})
    AND (claimed_at IS NULL OR claimed_at <= ?) ORDER BY COALESCE(publish_at, '9999'), _id LIMIT ${MAX}`, stale);
  const mine = [];
  for (const p of rows) {
    try { L.write([{ op: 'update', table: 'po_posts', id: p._id, when: { status: 'Writing', claimed_at: p.claimed_at }, data: { claimed_at: now } }]); mine.push(p); } catch { /* another run took it */ }
  }
  if (!mine.length) return { ok: true, items: [], instructions: 'Nothing to write: answer {"items":[]}.' };
  const accounts = new Map(L.all('SELECT * FROM po_accounts WHERE _deleted = 0').map((a) => [a._id, a]));
  const pillars = L.all("SELECT * FROM po_pillars WHERE _deleted = 0 ORDER BY _id");
  const pillarById = new Map(pillars.map((x) => [x._id, x]));
  const items = mine.map((p) => {
    const a = accounts.get(p.account_id);
    const network = (a && a.network) || p.network || 'linkedin';
    const idea = p.idea_id ? L.one('SELECT * FROM po_ideas WHERE _id = ?', p.idea_id) : null;
    const tpl = p.template_id ? L.one('SELECT name, body FROM po_templates WHERE _id = ?', p.template_id) : null;
    const notes = L.all('SELECT quote, text FROM po_notes WHERE _deleted = 0 AND post_id = ? AND resolved_at IS NULL ORDER BY _id', p._id);
    const siblings = p.group_key ? L.all("SELECT p.text, a.network, a.name FROM po_posts p LEFT JOIN po_accounts a ON a._id = p.account_id WHERE p._deleted = 0 AND p.group_key = ? AND p._id <> ? AND p.text IS NOT NULL AND p.text <> ''", p.group_key, p._id) : [];
    const item = { id: p._id, network, account: accountSaid(a), style: C.styleOf(network, a), limit: C.limitOf(network, a), goes_out: p.publish_at || null };
    const pid = p.pillar_id != null ? p.pillar_id : (idea && idea.pillar_id != null ? idea.pillar_id : null);
    if (pid != null && pillarById.has(pid)) item.pillar = C.pillarSaid(pillarById.get(pid));
    if (network === 'x') item.thread_max = C.NETWORKS.x.thread;
    // Tried before and refused: say why, so this try does not repeat it.
    if (Number(p.tries) > 0 && p.error) item.last_try_refused = p.error;
    if (p.brief) item.brief = p.brief;
    if (idea) {
      item.idea = { text: idea.text || '', why_it_matters: idea.why || undefined, url: idea.url || undefined, from: idea.source === 'feed' ? 'a feed the person follows' : idea.source === 'agent' ? 'you' : 'the person' };
      if (idea.url) item.idea.page = pageText(idea.url) || undefined;
      if (idea.file_id) item.idea.file = fileText(idea.file_id, idea.file_name) || undefined;
    }
    if (tpl) item.template = tpl;
    if (p.text && (p.rewrite_note || notes.length)) item.rewrite = { current: p.text, instruction: p.rewrite_note || undefined, notes: notes.length ? notes : undefined };
    if (siblings.length) item.other_versions = siblings.map((x) => ({ network: x.network, account: x.name, text: x.text.slice(0, 600) }));
    return item;
  });
  const recent = L.all("SELECT text FROM po_posts WHERE _deleted = 0 AND status = 'Published' ORDER BY published_at DESC LIMIT 8").map((x) => String(x.text).slice(0, 280));
  const best = L.all("SELECT text, reactions FROM po_posts WHERE _deleted = 0 AND status = 'Published' AND reactions > 0 ORDER BY reactions DESC LIMIT 3").map((x) => ({ reactions: x.reactions, text: String(x.text).slice(0, 500) }));
  const who = s.company_name || 'the person';
  const instructions = [
    `You write social media posts for ${who}, in ${LANG[C.langOf(s.language)]}, as the account each item names (a person writes as "I", a company page as "we"). The ideas, the pillars, the angles and the opinions are ${who}'s: you only find the words, the way ${who} would say them.`,
    `Write it the way ${who} would tell it to a friend over coffee, not the way a company writes an update: first person, contractions, plain words, a mix of short and long sentences, a bit of humour or self-deprecation when it comes naturally. Warm, direct, opinionated.`,
    'The first line decides everything: a stranger scrolling must want the next line. Open on tension from the reader\'s side: a problem they recognise, a surprising fact, a sharp opinion, a small confession. Never open with "This week we…", a summary, or a question to the audience.',
    'Write for a stranger scrolling past: someone who has never heard of them, their company or their project. Every post sets its own scene in a few plain words, worked into the story (who they are when it matters, what they were trying to do, why it was hard), so it makes sense with nothing before it. Use an outsider\'s words: "the server", not "the instance"; "the program that runs our agents", not the product\'s name, unless the reader would know it. Never assume they read an earlier post. Never the same words as in `recent` or another item of this batch.',
    'Then the story: one real moment, specific (a time, a number, a sentence someone said). Then the turn: what surprised them or what they got wrong. Then what they think now, with conviction: take the side of the post\'s pillar; this is an opinion, not a report.',
    'End like a person, on something concrete: what they do now, what they still do not know, or the plain thing they would say to a friend. Never a two-part aphorism or a line built for a poster ("X isn\'t Y. Z is.", "Saying done isn\'t done.", "Don\'t A. B."), never a moral that sums up the post. A closing question only when it is one specific thing they would genuinely want answered, never "Thoughts?", "Agree?" or anything asking for likes.',
    'The items of one batch go out the same week to the same people: give each its own shape (a story, a sharp take, a confession, a mistake, a short observation, a question they are stuck on) and its own opening and ending. Two that open alike, end alike or make the same point is a failure: tell each one from its own idea.',
    'An idea with `why_it_matters` carries what it meant to them: that is the heart of the post, build around it.',
    'It must read as if they wrote it themselves at their desk. Never sound produced or automated: no "Here\'s the thing", no "Let\'s dive in", no "In today\'s world", no emoji threads, no headers, no bullet lists they would not type, no numbering of thread posts, no tidy closing summary, no perfectly balanced structure.',
    'Write for who reads them there: `voice.audience` says who that is on each network. Use that reader\'s words and the details they would care about; when the reader is not technical, leave out what only builders follow (runtimes, heaps, APIs) or say it in their terms.',
    'Each network reads differently: follow the item\'s `style` and keep every post under its `limit` (on X a thread is several posts, each one under the limit, separated by a line holding only ---). On X the first post works alone and hooks; each next post adds one beat. Give a story the room it needs: on X a thread, not one squeezed post; a single short post only when the point is small and lands alone (a quick observation, a question, a joke).',
    'An item with `last_try_refused` was written before and refused for that reason: fix exactly that this time.',
    'Use only what is given: the idea, its why, its page or file, the pillar and its references, the voice and its background. Never invent a number, a name, a customer, a quote, a feeling or an event. The examples show the voice only: never retell their stories or reuse their lines. A `brief` from the person stands for the idea.',
    'Every item with a `pillar` leans on it: the pillar is what they believe (`believe`), from where they say it (`angle`) and what they push against (`against`). The post takes that side in its own words through its own story: never quote the pillar or state it as a slogan. Its `references` are for grounding: cite one only when it truly carries the point.',
    'To rewrite: keep what the person did not ask to change; follow the instruction, and fix every note (a quote of their text and what they said about it).',
    'Other versions of the same idea for other accounts may be given: say the same thing in this network\'s way, not the same words.',
    'Never leave a placeholder ([…], {{…}}, a line of "…"), never add a link that was not given, no "As an AI". A template is a shape to follow, filled in completely.',
    `Answer ONLY one JSON object: ${C.ANSWER}`,
  ].join('\n');
  return {
    ok: true, instructions,
    // Pillars replace the topics: with one on, the topics are not sent (two lists pulled two ways).
    voice: { how: s.voice || '', audience: s.audience || undefined, topics: pillars.some((x) => x.active !== 'no') ? undefined : (s.topics || ''), pillars: pillars.filter((x) => x.active !== 'no').map((x) => x.name).filter(Boolean), examples: s.examples || '', avoid: s.avoid || '', signature_added_later: s.signature_auto === 'yes' ? s.signature : undefined },
    today: C.local(L.now(), s.timezone || 'UTC').ymd,
    recent, best, items,
  };
}

function save() {
  const picked = L.stepOut('STEP_pick');
  const answer = L.jsonIn(process.env.PRIOR || '') || {};
  const got = new Map((Array.isArray(answer.items) ? answer.items : []).filter((x) => x && x.id != null).map((x) => [Number(x.id), x]));
  const ids = (picked.items || []).map((x) => Number(x.id));
  // Without the pick's output (a run by hand), what this run claimed is what is claimed and Writing.
  const list = ids.length ? ids : L.all("SELECT _id FROM po_posts WHERE _deleted = 0 AND status = 'Writing' AND claimed_at IS NOT NULL").map((x) => x._id);
  const out = { ok: true, saved: 0, retry: 0, gave_up: 0, refused: [] };
  for (const id of list) {
    const p = L.one('SELECT * FROM po_posts WHERE _id = ? AND _deleted = 0', id);
    if (!p || p.status !== 'Writing') continue;
    const a = got.get(id);
    const acct = L.one('SELECT * FROM po_accounts WHERE _id = ?', p.account_id) || null;
    const net = (acct && acct.network) || p.network;
    let c = a ? C.checkDraft(a.text, net, acct) : { ok: false, why: 'the agent did not answer for it' };
    // X: one post too long, in paragraphs → a thread split at them (the person reviews it).
    let split = false;
    if (!c.ok && a && net === 'x' && C.partsOf(a.text).length === 1) {
      const packed = C.packThread(a.text, acct);
      const again = packed ? C.checkDraft(packed, net, acct) : null;
      if (again && again.ok) { c = again; split = true; }
    }
    if (c.ok) {
      const ops = [{ op: 'update', table: 'po_posts', id, when: { status: 'Writing' }, data: { status: 'Draft', text: c.text, agent_note: L.clean(split ? `${a.note || ''} (Too long for one post: split into a thread at its paragraphs.)`.trim() : a.note, 300) || null, version: (Number(p.version) || 0) + 1,
        claimed_at: null, rewrite_note: null, error: null, tries: 0 } }];
      if (p.text) for (const n of L.all('SELECT _id FROM po_notes WHERE _deleted = 0 AND post_id = ? AND resolved_at IS NULL', id)) ops.push({ op: 'update', table: 'po_notes', id: n._id, data: { resolved_at: L.isoZ(), by: 'rewritten' } });
      if (p.idea_id) ops.push({ op: 'update', table: 'po_ideas', id: p.idea_id, data: { status: 'Used', post_id: id } });
      try { L.write(ops); out.saved += 1; } catch { /* moved meanwhile */ }
      continue;
    }
    out.refused.push({ id, why: c.why });
    const tries = (Number(p.tries) || 0) + 1;
    if (tries < TRIES) { L.write([{ op: 'update', table: 'po_posts', id, data: { tries, claimed_at: null, error: `Attempt ${tries}: ${c.why}` } }]); out.retry += 1; continue; }
    // Given up: a rewrite goes back to the draft it was; a new post says it could not be written.
    L.write([{ op: 'update', table: 'po_posts', id, data: p.text ? { status: 'Draft', tries: 0, claimed_at: null, error: `It could not be rewritten (${c.why}). The draft is as it was.` }
      : { status: 'Failed', tries, claimed_at: null, error: `It could not be written (${c.why}). Ask for another version, or write it yourself.` } }]);
    out.gave_up += 1;
  }
  return out;
}

if (require.main === module) {
  const cmd = process.argv[2];
  try { L.done(cmd === 'save' ? save() : pick()); } catch (e) { L.done({ ok: false, error: e.message, items: [] }); process.exitCode = 1; }
}
module.exports = { pick, save, pageText, fileText };
