'use strict';
/**
 * Posts · Publish: every Scheduled post whose time came. Each is CLAIMED
 * before its network is called (Scheduled → Publishing, atomic), so none goes
 * out twice; one left Publishing (a run that died) is Failed after 15 minutes
 * and says it may have gone out — never published again blind.
 *
 * The text that goes out is the post's, with the signature when Settings add
 * it on their own. Rehearsal (Settings, on until a person turns it off): no
 * network is called; X's own count and price are still checked (free); the
 * post is marked Published · rehearsed, without a link.
 *
 * X, out of rehearsal, goes through the agent (xjobs.js: the keys reach the
 * agent's commands, not this script): its posts stay Scheduled here, and
 * Posts · X is started.
 *   node publish.js [--auto]
 */
const L = require('./lib');
const C = require('./pocore');
const N = require('./networks');
const X = require('./xjobs');

const STALE_MIN = 15;
const MAX = 10;

function tell(s, text) { if (s.notify_telegram) L.telegram(s.notify_telegram, text); }

function run() {
  const held = L.lock('publish');
  if (!held) return { ok: true, skipped: 'Another run is publishing' };
  try {
    const s = L.settings();
    const out = { ok: true, published: 0, rehearsed: 0, failed: 0 };
    const stale = L.isoZ(new Date(L.now().getTime() - STALE_MIN * 60000));
    for (const p of L.all("SELECT _id, claimed_at FROM po_posts WHERE _deleted = 0 AND status = 'Publishing' AND (claimed_at IS NULL OR claimed_at <= ?)", stale)) {
      try {
        L.write([{ op: 'update', table: 'po_posts', id: p._id, when: { status: 'Publishing' }, data: { status: 'Failed', unsure: 'yes',
          error: 'The publish did not finish, so it may or may not be live. Look at the account before publishing again.' } }]);
        out.failed += 1;
      } catch { /* moved */ }
    }
    const due = L.all(`SELECT * FROM po_posts WHERE _deleted = 0 AND status = 'Scheduled' AND publish_at IS NOT NULL AND publish_at <= ? ORDER BY publish_at, _id LIMIT ${MAX}`, L.isoZ());
    for (const p of due) {
      try { L.write([{ op: 'update', table: 'po_posts', id: p._id, when: { status: 'Scheduled' }, data: { status: 'Publishing', claimed_at: L.isoZ(), error: null } }]); } catch { continue; }
      const fail = (why, extra = {}) => {
        L.write([{ op: 'update', table: 'po_posts', id: p._id, data: Object.assign({ status: 'Failed', error: String(why).slice(0, 500), claimed_at: null }, extra) }]);
        out.failed += 1;
        tell(s, `Posts: a post could not be published (${String(why).slice(0, 160)}). ${s.desk_url ? `${s.desk_url}#/post/${p._id}` : ''}`);
      };
      const a = L.one('SELECT * FROM po_accounts WHERE _id = ? AND _deleted = 0', p.account_id);
      if (!a) { fail('Its account is not in Posts any more: choose another one and approve it again.'); continue; }
      if (a.active !== 'yes') { fail(`${a.name} is off in Settings: turn it on, or choose another account, and approve it again.`); continue; }
      const net = C.netOf(a.network);
      const text = C.finalText(p.text, s);
      const c = C.checkDraft(text, a.network);
      if (!c.ok) { fail(`The text cannot go out: ${c.why}.`); continue; }
      const ad = N.adapter(a.network);
      if (a.network === 'x' && s.rehearsal !== 'yes' && !X.direct()) {
        // Back to Scheduled: Posts · X claims it with the agent.
        L.write([{ op: 'update', table: 'po_posts', id: p._id, when: { status: 'Publishing' }, data: { status: 'Scheduled', claimed_at: null } }]);
        out.to_x = (out.to_x || 0) + 1;
        continue;
      }
      if (s.rehearsal === 'yes') {
        let cost = null;
        if (a.network === 'x') { const k = ad.check(text); if (!k.ok) { fail(`X would refuse it: ${k.why}`); continue; } cost = k.cost; }
        L.write([{ op: 'update', table: 'po_posts', id: p._id, data: { status: 'Published', rehearsed: 'yes', published_at: L.isoZ(), claimed_at: null, cost_usd: cost, url: null, ref: null } }]);
        out.rehearsed += 1;
        continue;
      }
      const r = ad.publish(a, text);
      if (!r.ok) {
        if (r.unsure) fail(`${net.name} did not answer clearly (${r.why}), so it may be live. Look at ${a.name} before publishing it again.`, { unsure: 'yes' });
        else fail(`${net.name} did not take it: nothing went out. ${r.notConnected ? `Connect ${net.name} in Integrations, then` : 'Fix it, then'} approve it again. (${r.why})`);
        continue;
      }
      L.write([{ op: 'update', table: 'po_posts', id: p._id, data: { status: 'Published', rehearsed: null, ref: r.ref, url: r.url || null, published_at: L.isoZ(), claimed_at: null, cost_usd: r.cost == null ? null : r.cost, unsure: null } }]);
      out.published += 1;
      tell(s, `Posts: published on ${net.name} as ${a.name}. ${r.url || ''}`);
    }
    if (out.to_x) out.x = L.kick('x');
    return out;
  } finally { held.release(); }
}

if (require.main === module) {
  try { L.done(run()); } catch (e) { L.done({ ok: false, error: e.message }); process.exitCode = 1; }
}
module.exports = { run };
