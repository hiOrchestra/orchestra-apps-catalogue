'use strict';
/**
 * What every Posts script shares (Expenses' lib.js, the SDK the platform does
 * not have yet): reading the project's database, writing to it, talking to
 * the instance as the workflow's agent (Files, Composio, workflows,
 * Telegram), and the one JSON line a step leaves.
 *
 * Reads go to the project's SQLite file directly, read-only and
 * parameterised. Every write goes through `orch-database batch`: one
 * transaction, and a `when` precondition checked inside the UPDATE.
 *
 * Locally (PO_LOCAL=1) the same batch runs against PO_DB with the same
 * semantics; Files is a folder (PO_FAKE_FILES: index.json + the files),
 * the networks answer from PO_FAKE_NET (networks.js), feeds from PO_FAKE_FEEDS, notices and workflow
 * starts are recorded in PO_RECORD, not sent. PO_NOW pins the clock.
 */
const { DatabaseSync } = require('node:sqlite');
const { execFileSync } = require('child_process');
const crypto = require('crypto');
const fs = require('fs');
const os = require('os');
const path = require('path');

const PROJECT = process.env.PO_PROJECT || (__dirname.match(/projects\/([^/]+)\/apps\/posts/) || [])[1] || 'default';
const STATE = process.env.OPENCLAW_STATE_DIR || '/home/node/.openclaw';
const DB_PATH = process.env.PO_DB || path.join(STATE, 'orchestra', 'projects', PROJECT, 'data', 'data.db');
const LOCAL = process.env.PO_LOCAL === '1';
/** Where the app keeps what is not in the database: workflows.json. */
const HOME = process.env.PO_HOME || path.join(__dirname, '..');

// ── reading ──────────────────────────────────────────────────────────────
let reader = null;
function db() {
  if (!reader) {
    reader = new DatabaseSync(DB_PATH, { readOnly: true });
    reader.exec('PRAGMA busy_timeout = 5000');
  }
  return reader;
}
/** A fresh reader: after a write in this process, the old one may hold an older snapshot. */
function reread() { if (reader) { try { reader.close(); } catch { /* closed */ } } reader = null; }
const all = (sql, ...params) => db().prepare(sql).all(...params);
const one = (sql, ...params) => db().prepare(sql).get(...params);

function settings() {
  const s = one('SELECT * FROM po_settings WHERE _deleted = 0 ORDER BY _id LIMIT 1');
  if (!s) throw new Error('Posts has no settings row: it is not installed in this project');
  return s;
}
function jsonOf(text, fallback) {
  if (text === null || text === undefined || text === '') return fallback;
  if (typeof text === 'object') return text;
  try { return JSON.parse(text); } catch { return fallback; }
}

// ── writing ──────────────────────────────────────────────────────────────
/** One transaction per chunk (an argv string over 128 KB is refused), all or nothing; the inserted ids in order. */
function write(ops) {
  const chunks = [];
  let cur = [];
  let size = 0;
  for (const op of ops) {
    const n = JSON.stringify(op).length;
    if (cur.length && size + n > 90000) { chunks.push(cur); cur = []; size = 0; }
    cur.push(op);
    size += n;
  }
  if (cur.length) chunks.push(cur);
  const results = [];
  for (const chunk of chunks) results.push(...((LOCAL ? localBatch(chunk) : cliBatch(chunk)).results || []));
  reread();
  return results;
}

function cliBatch(ops) {
  let out;
  try {
    out = execFileSync('orch-database', ['--project', PROJECT, 'batch', '--ops', JSON.stringify(ops)],
      { encoding: 'utf8', timeout: 60000, maxBuffer: 16 << 20 });
  } catch (e) {
    let j = null;
    try { j = JSON.parse(String(e.stdout || '')); } catch { /* not JSON */ }
    throw new Error((j && j.error) || String(e.stderr || e.message).trim().slice(0, 300));
  }
  const j = JSON.parse(out);
  if (!j.ok) throw new Error(j.error || 'the write failed');
  return j;
}

/** orch-database's run_batch, for local tests: same `when`, same all-or-none, same results. */
function localBatch(ops) {
  const w = new DatabaseSync(DB_PATH);
  w.exec('PRAGMA busy_timeout = 5000');
  const stamp = sqlNow();
  const results = [];
  w.exec('BEGIN IMMEDIATE');
  try {
    ops.forEach((op, i) => {
      const data = {};
      for (const [k, v] of Object.entries(op.data || {})) if (!k.startsWith('_')) data[k] = v;
      if (op.op === 'insert') {
        const cols = [...Object.keys(data), '_created_at', '_updated_at'];
        const r = w.prepare(`INSERT INTO "${op.table}" (${cols.map((c) => `"${c}"`).join(', ')}) VALUES (${cols.map(() => '?').join(', ')})`)
          .run(...Object.values(data), stamp, stamp);
        results.push({ op: 'insert', table: op.table, _id: Number(r.lastInsertRowid) });
      } else {
        const when = op.when || {};
        const r = w.prepare(`UPDATE "${op.table}" SET ${Object.keys(data).map((c) => `"${c}" = ?`).join(', ')}, _updated_at = ? `
          + `WHERE _id = ? AND _deleted = 0${Object.keys(when).map((c) => ` AND "${c}" IS ?`).join('')}`)
          .run(...Object.values(data), stamp, op.id, ...Object.values(when));
        if (!r.changes) throw new Error(`op ${i}: row ${op.id} changed meanwhile (precondition failed)`);
        results.push({ op: 'update', table: op.table, _id: op.id });
      }
    });
    w.exec('COMMIT');
  } catch (e) {
    w.exec('ROLLBACK');
    w.close();
    throw e;
  }
  w.close();
  return { ok: true, applied: results.length, results };
}

/** Soft-delete rows by id (integers only, so the WHERE is safe to build). */
function softDelete(table, ids) {
  const list = ids.filter((x) => Number.isInteger(x));
  if (!list.length) return 0;
  const where = `_id IN (${list.join(',')})`;
  if (LOCAL) {
    const w = new DatabaseSync(DB_PATH);
    const r = w.prepare(`UPDATE "${table}" SET _deleted = 1, _updated_at = ? WHERE ${where}`).run(sqlNow());
    w.close();
    reread();
    return r.changes;
  }
  const out = JSON.parse(execFileSync('orch-database', ['--project', PROJECT, 'delete', table, '--where', where], { encoding: 'utf8', timeout: 60000 }));
  if (out.ok === false) throw new Error(out.error || 'the delete failed');
  reread();
  return out.affected || 0;
}

// ── one run at a time ────────────────────────────────────────────────────
const STALE_MS = 200000; // longer than a step may run: a file this old was left by a killed run
/**
 * A lock file per job: a burst of runs has one doing the work at a time.
 * A run that finds it held WAITS for it (up to waitMs, 50 s by default), so
 * work that arrived meanwhile (a second envelope, a code asked right after
 * opening) is done now and not at the next half-hourly check. What keeps a
 * write single is every `when`.
 *   lock('prepare') -> { release() }, or null when it stayed held
 */
function lock(name, waitMs = Number(process.env.PO_LOCK_WAIT_MS || 50000)) {
  let who = process.env.ORCHESTRA_AGENT_ID;
  if (!who) { try { who = os.userInfo().username; } catch { who = 'node'; } }
  const file = path.join(process.env.PO_LOCK_DIR || os.tmpdir(), `orchestra-posts-${PROJECT}-${who}-${name}.lock`);
  const held = { file, release() { try { fs.unlinkSync(file); } catch { /* already gone */ } } };
  const until = Date.now() + waitMs;
  for (;;) {
    try {
      fs.writeFileSync(file, String(process.pid), { flag: 'wx' });
      return held;
    } catch (e) {
      if (e.code !== 'EEXIST') return { file: null, release() {} };
      let age = 0;
      try { age = Date.now() - fs.statSync(file).mtimeMs; } catch { continue; }
      if (age >= STALE_MS) { try { fs.unlinkSync(file); } catch { /* another run took it over first */ } continue; }
      if (Date.now() >= until) return null;
      Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, 250);
    }
  }
}

// ── time ─────────────────────────────────────────────────────────────────
const now = () => (process.env.PO_NOW ? new Date(process.env.PO_NOW) : new Date());
/** 'YYYY-MM-DD HH:MM:SS' in UTC: the format orch-database stamps rows with. */
const sqlNow = (d = now()) => d.toISOString().slice(0, 19).replace('T', ' ');
const isoZ = (d = now()) => `${d.toISOString().slice(0, 19)}Z`;
function toDate(v) {
  if (!v) return null;
  const s = String(v).trim();
  const x = s.includes('T') ? s : s.replace(' ', 'T');
  const d = new Date(/[zZ]|[+-]\d\d:?\d\d$/.test(x) ? x : `${x}Z`);
  return Number.isNaN(d.getTime()) ? null : d;
}

// ── the instance, as this workflow's agent ───────────────────────────────
function identityHeaders() {
  const id = process.env.ORCHESTRA_AGENT_ID;
  const token = process.env.ORCHESTRA_AGENT_TOKEN;
  if (id && token) return { 'x-orchestra-agent': id, 'x-orchestra-agent-token': token };
  const secret = process.env.HOOKS_TOKEN || process.env.OPENCLAW_GATEWAY_TOKEN || '';
  return secret ? { 'x-orchestra-secret': secret } : {};
}
const BASE = () => `http://127.0.0.1:${Number(process.env.API_SERVER_PORT || 3001)}`;
const q = (v) => `"${String(v).replace(/[\\"]/g, '\\$&')}"`;
/**
 * A call to the instance's api-server. Headers go to curl on stdin (-K -),
 * never argv. A body larger than a config line takes a file (`bodyFile`);
 * `out` saves the answer to a file instead (a download). Never throws; a
 * timeout says so (`timedOut`): the other side may have acted.
 */
function api(method, route, body, seconds = 30, { out, bodyFile } = {}) {
  // A large body (a PDF in base64) goes from a file, not a config line.
  if (!bodyFile && body !== undefined) {
    const json = JSON.stringify(body);
    if (json.length > 100000) {
      const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'posts-body-'));
      try { fs.writeFileSync(path.join(dir, 'b.json'), json); return api(method, route, undefined, seconds, { out, bodyFile: path.join(dir, 'b.json') }); } finally { fs.rmSync(dir, { recursive: true, force: true }); }
    }
  }
  const config = [
    `url = ${q(`${BASE()}${route}`)}`,
    `request = ${q(method)}`,
    'header = "Content-Type: application/json"',
    ...Object.entries(identityHeaders()).map(([k, v]) => `header = ${q(`${k}: ${v}`)}`),
    ...(bodyFile ? [`data-binary = ${q(`@${bodyFile}`)}`] : body === undefined ? [] : [`data = ${q(JSON.stringify(body))}`]),
    ...(out ? [`output = ${q(out)}`, 'fail'] : []),
  ].join('\n');
  try {
    const text = execFileSync('curl', ['-sS', '-m', String(seconds), '-K', '-'], { input: config, timeout: (seconds + 5) * 1000, stdio: ['pipe', 'pipe', 'pipe'], maxBuffer: 32 << 20 }).toString();
    if (out) return { ok: true };
    let j = null;
    try { j = JSON.parse(text); } catch { /* reported below */ }
    if (j && j.success) return { ok: true, data: j.data };
    return { ok: false, why: String((j && j.error && (j.error.message || j.error)) || text).trim().slice(0, 300) };
  } catch (e) {
    const why = String((e.stderr && e.stderr.toString()) || e.message).trim().slice(0, 300);
    return { ok: false, why, timedOut: /timed out|ETIMEDOUT|\(28\)/i.test(why) };
  }
}

/** One Composio action for this tenant's connected account: { ok, data } or { ok: false, why, timedOut }. */
function composio(slug, args, seconds = 60) {
  if (process.env.PO_FAKE_NET) return require('./networks').fake(slug, args);
  const r = api('POST', '/api/composio/execute', { toolSlug: slug, arguments: args }, seconds);
  if (!r.ok) return r;
  const d = r.data || {};
  if (d.successful === false || d.error) return { ok: false, why: String(d.error || 'Composio said it did not work').slice(0, 300) };
  return { ok: true, data: d.data !== undefined ? d.data : d };
}

// ── Orchestra Files ──────────────────────────────────────────────────────
const FAKE_FILES = process.env.PO_FAKE_FILES;
const fakeIndex = () => { try { return JSON.parse(fs.readFileSync(path.join(FAKE_FILES, 'index.json'), 'utf8')); } catch { return { files: [] }; } };
/** The workspace's files this agent may see: [{ id, name, type, size, folder, project, updatedAt }]. */
function filesList() {
  if (FAKE_FILES) return { ok: true, files: fakeIndex().files };
  const files = [];
  for (let offset = 0; offset < 5000;) {
    const r = api('GET', `/api/platform/files?limit=500&offset=${offset}&sort=mtime`, undefined, 30);
    if (!r.ok) return r;
    files.push(...(r.data.files || []));
    if (!r.data.truncated) break;
    offset = r.data.nextOffset || offset + 500;
  }
  return { ok: true, files };
}
/** One file's bytes into `dest`: { ok } or { ok: false, why }. */
function fileDownload(id, dest) {
  if (FAKE_FILES) {
    const f = fakeIndex().files.find((x) => x.id === id);
    if (!f) return { ok: false, why: 'Not found', notFound: true };
    fs.copyFileSync(path.join(FAKE_FILES, f.filename || `${f.id}.${f.type}`), dest);
    return { ok: true };
  }
  const r = api('GET', `/api/platform/files/${encodeURIComponent(id)}/download`, undefined, 120, { out: dest });
  if (!r.ok) return Object.assign(r, { notFound: /404/.test(r.why || '') });
  return r;
}
/** A new file in Files from bytes: { ok, file: { id } } or { ok: false, why }. */
function fileUpload({ name, type, bytes, folder, description }) {
  if (FAKE_FILES) {
    const idx = fakeIndex();
    const id = `f${crypto.randomBytes(5).toString('hex')}`;
    fs.writeFileSync(path.join(FAKE_FILES, `${id}.${type}`), bytes);
    const entry = { id, name, type, filename: `${id}.${type}`, size: bytes.length, folder: folder || null, project: PROJECT, description: description || '', updatedAt: new Date().toISOString() };
    idx.files.push(entry);
    fs.writeFileSync(path.join(FAKE_FILES, 'index.json'), JSON.stringify(idx, null, 1));
    return { ok: true, file: entry };
  }
  const tmp = path.join(fs.mkdtempSync(path.join(os.tmpdir(), 'posts-up-')), 'body.json');
  try {
    fs.writeFileSync(tmp, JSON.stringify({ name: `${name}.${type}`, contentBase64: Buffer.from(bytes).toString('base64'), type, folder: folder || undefined, project: PROJECT, description: description || '' }));
    const r = api('POST', '/api/platform/files/upload', undefined, 120, { bodyFile: tmp });
    return r.ok ? { ok: true, file: r.data } : r;
  } finally { fs.rmSync(path.dirname(tmp), { recursive: true, force: true }); }
}

// ── the app's workflows ──────────────────────────────────────────────────
const RECORD = process.env.PO_RECORD;
function record(kind, data) {
  if (!RECORD) return;
  let list = [];
  try { list = JSON.parse(fs.readFileSync(RECORD, 'utf8')); } catch { /* first */ }
  list.push(Object.assign({ kind }, data));
  fs.writeFileSync(RECORD, JSON.stringify(list));
}
function workflowIds() { try { return JSON.parse(fs.readFileSync(path.join(HOME, 'workflows.json'), 'utf8')); } catch { return {}; } }
/** Start one of the app's workflows now (it carries only `mode`). */
function kick(key, mode = '--auto') {
  if (LOCAL || process.env.PO_FAKE_KICK === '1') { record('kick', { workflow: key, mode }); return { started: true, fake: true }; }
  const id = workflowIds()[key];
  if (!id) return { started: false, why: `No ${key} workflow recorded (install Posts again)` };
  const r = api('POST', `/api/platform/workflows/${encodeURIComponent(id)}/run`, { execute: true, argsJson: JSON.stringify({ mode }) });
  return r.ok ? { started: true } : { started: false, why: r.why };
}

// ── telling the owner ────────────────────────────────────────────────────
const TG_CHAT = /^(-?\d{5,20}|@[A-Za-z0-9_]{5,32})$/;
function telegram(to, text) {
  const chat = String(to || '').trim();
  if (!chat) return { sent: false, why: 'No Telegram chat in Settings' };
  if (!TG_CHAT.test(chat)) return { sent: false, why: 'The Telegram chat in Settings is not a chat id or @username' };
  const message = String(text || '').slice(0, 3800);
  if (LOCAL) { record('telegram', { to: chat, message }); return { sent: true, fake: true }; }
  const r = api('POST', '/api/channels/telegram/notify', { to: chat, message });
  return r.ok ? { sent: true } : { sent: false, why: r.why };
}

/** The one JSON line a workflow step leaves as its output. */
function done(result) { process.stdout.write(`${JSON.stringify(result)}\n`); return result; }
/** Clean text for a column: a string, trimmed, at most n characters. */
const clean = (v, n = 500) => String(v == null ? '' : v).replace(/\r\n/g, '\n').trim().slice(0, n);
const sha256 = (data) => crypto.createHash('sha256').update(data).digest('hex');

/**
 * The model's JSON, wherever it is: bare, fenced, or inside a step wrapper's
 * `content`; raw newlines inside its strings are read too (Invoices' jsonIn).
 */
function jsonIn(text) {
  const grab = (t) => {
    const s = String(t || '').replace(/```(?:json)?/gi, '');
    const starts = [s.indexOf('{'), s.indexOf('[')].filter((i) => i >= 0);
    if (!starts.length) return null;
    const a = Math.min(...starts);
    const b = Math.max(s.lastIndexOf('}'), s.lastIndexOf(']'));
    if (b <= a) return null;
    const body = s.slice(a, b + 1);
    try { return JSON.parse(body); } catch { /* maybe raw newlines in strings */ }
    try { return JSON.parse(body.replace(/"(?:[^"\\]|\\.)*"/gs, (m) => m.replace(/\n/g, '\\n').replace(/\r/g, ''))); } catch { return null; }
  };
  const j = grab(text);
  if (j && !Array.isArray(j) && typeof j.content === 'string') { const inner = grab(j.content); if (inner) return inner; }
  if (j && !Array.isArray(j) && typeof j.text === 'string' && !j.items) { const inner = grab(j.text); if (inner) return inner; }
  return j;
}
/** A previous step's output (STEP_<id> or PRIOR): its JSON, or {}. */
function stepOut(name) {
  const t = String(process.env[name] || '').trim();
  if (!t) return {};
  try { return JSON.parse(t.split('\n').pop()); } catch { return jsonIn(t) || {}; }
}

module.exports = {
  PROJECT, DB_PATH, LOCAL, HOME, all, one, reread, settings, jsonOf, write, softDelete, lock,
  now, sqlNow, isoZ, toDate, identityHeaders, api, composio, filesList, fileDownload, fileUpload,
  record, workflowIds, kick, telegram, sha256, done, clean, jsonIn, stepOut,
};
