'use strict';
/**
 * Posts · X, through the agent. X's four keys (Integrations → X) reach the
 * agent's own commands but not a workflow's script (the workflow executor
 * hands a step only the agent's identity; the store's variables go to the
 * agent's exec alone — 2026-10-10). So what needs the keys is done by the
 * agent, one exact x.py command each, and checked here:
 *
 *   pick   the jobs, claimed: each due X post (Scheduled → Publishing, its
 *          text in outbox/<id>.txt), each X post due for its numbers (a day
 *          and a week after), each self-reply whose number was reached, and
 *          "whoami" when a person asked to look for accounts. Out of
 *          rehearsal only (rehearsal never calls X: publish.js checks free).
 *   save   reads what the agent ran (PRIOR: {items:[{id, exit, out}]}, `out`
 *          being x.py's own JSON) and records it. A post whose run is missing
 *          or unclear is Failed "may be live": never published again blind.
 *
 * When the keys do reach scripts (PO_X_DIRECT=1, or X_ACCESS_TOKEN in the
 * environment), publish.js and watch.js call x.py themselves and this has
 * nothing to do.
 *   node xjobs.js pick | save
 */
const fs = require('fs');
const path = require('path');
const L = require('./lib');
const C = require('./pocore');

const DAY = 86400000;
const OUTBOX = () => process.env.PO_OUTBOX || path.join(L.HOME, 'outbox');
/**
 * Whether X's keys reach this script usable: then nothing goes through the
 * agent. A sealed sentinel (oc-sent-…) or a store reference is not usable:
 * OAuth 1.0a signs with the value itself.
 */
const usable = (v) => !!v && !/^(oc-sent-|orchestra:\/\/)/.test(String(v));
const direct = () => (process.env.PO_X_DIRECT ? process.env.PO_X_DIRECT === '1'
  : ['X_API_KEY', 'X_API_KEY_SECRET', 'X_ACCESS_TOKEN', 'X_ACCESS_TOKEN_SECRET'].every((k) => usable(process.env[k])));

const plugsOf = (p) => L.jsonOf(p.plugs_done, {}) || {};
function writeText(name, text) {
  fs.mkdirSync(OUTBOX(), { recursive: true });
  const file = path.join(OUTBOX(), name);
  fs.writeFileSync(file, text);
  return file;
}

/** What is due for X now, without claiming: for the .where and for publish.js. */
function due(s = L.settings()) {
  if (direct() || s.rehearsal === 'yes') return { post: 0, read: 0, whoami: false };
  const post = L.one("SELECT COUNT(*) AS n FROM po_posts WHERE _deleted = 0 AND network = 'x' AND status = 'Scheduled' AND publish_at <= ?", L.isoZ()).n;
  return { post, whoami: !!s.x_asked_at };
}

function pick() {
  const s = L.settings();
  const jobs = [];
  if (direct()) return { ok: true, jobs, note: 'X keys reach scripts here: publish.js and watch.js call X themselves.' };
  if (s.x_asked_at) jobs.push({ id: 'whoami', args: ['whoami'] });
  if (s.rehearsal !== 'yes') {
    // Due posts, claimed one by one.
    for (const p of L.all("SELECT p.*, a.active FROM po_posts p JOIN po_accounts a ON a._id = p.account_id WHERE p._deleted = 0 AND p.network = 'x' AND p.status = 'Scheduled' AND p.publish_at <= ? ORDER BY p.publish_at LIMIT 5", L.isoZ())) {
      if (p.active !== 'yes') continue; // publish.js says why
      const text = C.finalText(p.text, s);
      if (!C.checkDraft(text, 'x').ok) continue; // publish.js says why
      try { L.write([{ op: 'update', table: 'po_posts', id: p._id, when: { status: 'Scheduled' }, data: { status: 'Publishing', claimed_at: L.isoZ(), error: null } }]); } catch { continue; }
      jobs.push({ id: `post-${p._id}`, args: ['post', '--file', writeText(`${p._id}.txt`, text)] });
    }
    // Numbers: a day after, a week after. Replies: once the number is reached (known from a read).
    const since = L.isoZ(new Date(L.now().getTime() - 14 * DAY));
    for (const p of L.all(`SELECT p.*, a.reply_at, a.reply_text FROM po_posts p JOIN po_accounts a ON a._id = p.account_id
      WHERE p._deleted = 0 AND p.network = 'x' AND p.status = 'Published' AND p.rehearsed IS NULL AND p.ref IS NOT NULL AND p.published_at >= ?`, since)) {
      const age = L.now().getTime() - (L.toDate(p.published_at) || L.now()).getTime();
      const checks = Number(p.checks) || 0;
      if ((checks === 0 && age >= DAY) || (checks === 1 && age >= 7 * DAY)) jobs.push({ id: `read-${p._id}`, args: ['read', p.ref] });
      if (p.reply_at && p.reply_text && Number(p.reactions) >= Number(p.reply_at) && !plugsOf(p).reply) {
        jobs.push({ id: `reply-${p._id}`, args: ['post', '--reply-to', p.ref, '--file', writeText(`r${p._id}.txt`, String(p.reply_text).slice(0, 270))] });
      }
    }
  }
  return {
    ok: true, jobs,
    instructions: jobs.length ? [
      'Run each job with the twitter skill\'s script, exactly once, in order: python3 <the twitter skill>/scripts/x.py <args…> — the args as given, nothing added or changed.',
      'Never run a job twice, even if it fails: a failed post may still be live. Never post anything that is not a job here.',
      'Answer ONLY one JSON object: {"items":[{"id":"<job id>","exit":<exit code>,"out":<the JSON x.py printed, as is>}]}',
    ].join('\n') : 'Nothing to do: answer {"items":[]}.',
  };
}

function save() {
  const picked = L.stepOut('STEP_pick');
  const answer = L.jsonIn(process.env.PRIOR || '') || {};
  const got = new Map((Array.isArray(answer.items) ? answer.items : []).filter((x) => x && x.id).map((x) => [String(x.id), x]));
  const s = L.settings();
  const out = { ok: true, published: 0, failed: 0, read: 0, replies: 0, whoami: null };
  for (const job of picked.jobs || []) {
    const r = got.get(job.id);
    const o = r && (typeof r.out === 'string' ? L.jsonIn(r.out) : r.out);
    const [kind, idText] = job.id.split('-');
    const id = Number(idText);
    if (kind === 'whoami') {
      const data = { x_asked_at: null, x_at: L.sqlNow() };
      if (o && o.ok && o.id) {
        const have = L.one("SELECT * FROM po_accounts WHERE _deleted = 0 AND network = 'x' AND ref = ?", String(o.id));
        L.write([have ? { op: 'update', table: 'po_accounts', id: have._id, data: { name: o.name || o.username, handle: o.username || null, found_at: L.sqlNow(), note: null } }
          : { op: 'insert', table: 'po_accounts', data: { network: 'x', kind: 'account', ref: String(o.id), name: o.name || o.username, handle: o.username || null, active: 'no', slots: JSON.stringify(C.DEFAULT_SLOTS), found_at: L.sqlNow() } }]);
        data.x_note = null;
        out.whoami = o.username || o.id;
      } else data.x_note = `X: ${String((o && (o.error || (o.problems || []).join('; '))) || 'the agent did not say').slice(0, 200)}`;
      L.write([{ op: 'update', table: 'po_settings', id: s._id, data }]);
      continue;
    }
    const p = L.one('SELECT * FROM po_posts WHERE _id = ?', id);
    if (!p) continue;
    if (kind === 'post') {
      try { fs.unlinkSync(path.join(OUTBOX(), `${id}.txt`)); } catch { /* gone */ }
      if (p.status !== 'Publishing') continue;
      if (o && o.ok && o.id) {
        L.write([{ op: 'update', table: 'po_posts', id, data: { status: 'Published', ref: String(o.id), url: o.url || C.postUrl('x', o.id), published_at: L.isoZ(), claimed_at: null, cost_usd: o.cost_usd == null ? null : o.cost_usd, unsure: null, rehearsed: null } }]);
        out.published += 1;
        if (s.notify_telegram) L.telegram(s.notify_telegram, `Posts: published on X. ${o.url || ''}`);
      } else {
        // x.py: exit 2 / sent:false = nothing went out. Anything else, or no answer: it may have.
        const nothing = r && (Number(r.exit) === 2 || (o && o.sent === false));
        const why = String((o && (o.error || (o.problems || []).join('; ') || (o.posts && o.posts[0] && (o.posts[0].issues || []).join('; ')))) || (r ? 'X did not take it' : 'the agent did not report this job')).slice(0, 300);
        L.write([{ op: 'update', table: 'po_posts', id, data: nothing ? { status: 'Failed', claimed_at: null, error: `X did not take it: nothing went out. Fix it, then approve it again. (${why})` }
          : { status: 'Failed', claimed_at: null, unsure: 'yes', error: `X did not answer clearly (${why}), so it may be live. Look at the account before publishing it again.` } }]);
        out.failed += 1;
      }
    } else if (kind === 'read') {
      if (o && o.ok && o.post) {
        L.write([{ op: 'update', table: 'po_posts', id, data: { reactions: Number(o.post.likes || 0) + Number(o.post.reposts || 0), comments: Number(o.post.replies || 0), reactions_at: L.sqlNow(), checks: (Number(p.checks) || 0) + 1 } }]);
        out.read += 1;
      }
    } else if (kind === 'reply') {
      try { fs.unlinkSync(path.join(OUTBOX(), `r${id}.txt`)); } catch { /* gone */ }
      const done = plugsOf(p);
      // A reply runs once: even unclear, it is not tried again.
      done.reply = o && o.ok ? L.isoZ() : `failed: ${String((o && o.error) || 'no clear answer').slice(0, 160)}`;
      L.write([{ op: 'update', table: 'po_posts', id, data: { plugs_done: JSON.stringify(done) } }]);
      if (o && o.ok) out.replies += 1;
    }
  }
  return out;
}

if (require.main === module) {
  const cmd = process.argv[2];
  try { L.done(cmd === 'save' ? save() : pick()); } catch (e) { L.done({ ok: false, error: e.message, jobs: [] }); process.exitCode = 1; }
}
module.exports = { pick, save, due, direct };
