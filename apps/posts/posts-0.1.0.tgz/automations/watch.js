'use strict';
/**
 * Posts · Watch, every hour (and on a person's click):
 *
 *   propose   on Settings' day and hour (Monday 08:00 by default), or when a
 *             person presses "Propose the week": N posts to write, spread
 *             over the free slots of the next 7 days of the accounts that are
 *             on, each with the oldest new idea (or "one of the topics");
 *             then Write starts. Once a week, by proposed_week.
 *   feeds     what is new in the feeds (feeds.js)
 *   counts    reactions of what went out in the last 14 days: LinkedIn and
 *             Facebook each hour; X twice (a day after, a week after), since
 *             X charges each read
 *   plugs     once per post, when its reactions reach the account's number:
 *             repost (LinkedIn), or a first comment / self-reply (Postiz's
 *             autoRepostPost and autoPlugPost)
 *   stats     each LinkedIn company page's last 14 days, every 6 hours
 *   unstick   a post left Writing over 30 minutes goes back to Write
 *
 * Rehearsal (Settings) calls no network: counts, plugs and stats wait.
 *   node watch.js [--auto|--propose|--feeds]
 */
const L = require('./lib');
const C = require('./pocore');
const N = require('./networks');
const F = require('./feeds');
const X = require('./xjobs');

const DAY = 86400000;
const STATS_EVERY_H = 6;

/** Whether the weekly proposal is due now: Settings' day and hour passed this week, and this week was not proposed. */
function proposalDue(s, asked) {
  if (asked) return true;
  const tz = s.timezone || 'UTC';
  const now = C.local(L.now(), tz);
  const week = C.monday(now.ymd);
  if (s.proposed_week === week) return false;
  const day = Number(s.propose_day) || 1;
  if (now.dow < day) return false;
  return now.dow > day || now.hm >= (C.HM.test(s.propose_time || '') ? s.propose_time : '08:00');
}

function propose(s, { asked = false } = {}) {
  const out = { proposed: 0, note: null };
  if (!proposalDue(s, asked)) return out;
  const tz = s.timezone || 'UTC';
  const week = C.monday(C.local(L.now(), tz).ymd);
  const done = (note) => { L.write([{ op: 'update', table: 'po_settings', id: s._id, data: { proposed_week: week, propose_asked_at: null } }]); out.note = note; return out; };
  const count = Math.max(0, Math.min(14, Number(s.propose_count) || 0));
  if (!count) return done('Settings ask for 0 posts a week');
  const accounts = L.all("SELECT * FROM po_accounts WHERE _deleted = 0 AND active = 'yes' ORDER BY _id");
  if (!accounts.length) return done('No account is on: turn one on in Settings');
  // Each account's free slots of the next 7 days, then taken in turns, earliest first.
  const queues = accounts.map((a) => {
    const taken = L.all("SELECT publish_at FROM po_posts WHERE _deleted = 0 AND account_id = ? AND status NOT IN ('Dropped', 'Failed') AND publish_at IS NOT NULL", a._id).map((x) => x.publish_at);
    return { a, free: C.freeSlots({ slots: a.slots, taken, tz, from: L.now(), count, days: 7 }) };
  }).filter((q) => q.free.length);
  if (!queues.length) return done('No free time in the next 7 days: every slot has a post, or the accounts have no times');
  const chosen = [];
  for (let round = 0; chosen.length < count && queues.some((q) => q.free.length); round += 1) {
    for (const q of queues.slice().sort((x, y) => (x.free[0] || '~').localeCompare(y.free[0] || '~'))) {
      if (chosen.length >= count || !q.free.length) continue;
      chosen.push({ a: q.a, at: q.free.shift() });
    }
  }
  chosen.sort((x, y) => x.at.localeCompare(y.at));
  const ideas = L.all("SELECT * FROM po_ideas WHERE _deleted = 0 AND status = 'New' ORDER BY _id LIMIT ?", chosen.length);
  const ops = [];
  chosen.forEach((c, i) => {
    const idea = ideas[i];
    ops.push({ op: 'insert', table: 'po_posts', data: { account_id: c.a._id, network: c.a.network, status: 'Writing', publish_at: c.at, idea_id: idea ? idea._id : null,
      brief: idea ? null : 'One of the topics, not one of the recent posts again.', source: 'agent', created_by: 'weekly proposal', week, version: 0, tries: 0 } });
    if (idea) ops.push({ op: 'update', table: 'po_ideas', id: idea._id, data: { status: 'Used' } });
  });
  ops.push({ op: 'update', table: 'po_settings', id: s._id, data: { proposed_week: week, propose_asked_at: null } });
  L.write(ops);
  out.proposed = chosen.length;
  return out;
}

const plugsOf = (p) => L.jsonOf(p.plugs_done, {}) || {};
function counts(s) {
  const out = { counted: 0, plugs: 0, errors: [] };
  const since = L.isoZ(new Date(L.now().getTime() - 14 * DAY));
  const hourAgo = L.sqlNow(new Date(L.now().getTime() - 55 * 60000));
  const rows = L.all(`SELECT p.*, a.network AS a_network, a.ref AS a_ref, a.name AS a_name, a.repost_at, a.reply_at, a.reply_text
    FROM po_posts p JOIN po_accounts a ON a._id = p.account_id WHERE p._deleted = 0 AND p.status = 'Published' AND p.rehearsed IS NULL AND p.ref IS NOT NULL AND p.published_at >= ?`, since);
  for (const p of rows) {
    if (p.a_network === 'x' && !X.direct()) continue; // Posts · X reads it, through the agent
    const age = L.now().getTime() - (L.toDate(p.published_at) || L.now()).getTime();
    const checks = Number(p.checks) || 0;
    // X charges each read: a day after, and a week after. The others: each hour.
    const due = p.a_network === 'x' ? (checks === 0 && age >= DAY) || (checks === 1 && age >= 7 * DAY) : (!p.reactions_at || p.reactions_at <= hourAgo);
    if (!due) continue;
    const a = { network: p.a_network, ref: p.a_ref, name: p.a_name };
    const r = N.adapter(a.network).counts(a, p.ref);
    if (!r.ok) { out.errors.push(`${p._id}: ${r.why}`); continue; }
    const data = { reactions: r.reactions == null ? p.reactions : r.reactions, comments: r.comments == null ? p.comments : r.comments, reactions_at: L.sqlNow(), checks: checks + 1 };
    const done = plugsOf(p);
    const n = Number(data.reactions) || 0;
    if (p.repost_at && n >= Number(p.repost_at) && !done.repost && a.network === 'linkedin') {
      const x = N.adapter(a.network).repost(a, p.ref);
      done.repost = x.ok ? L.isoZ() : `failed: ${x.why}`;
      if (x.ok) out.plugs += 1;
    }
    if (p.reply_at && p.reply_text && n >= Number(p.reply_at) && !done.reply) {
      const x = N.adapter(a.network).reply(a, p.ref, String(p.reply_text).slice(0, 1200));
      done.reply = x.ok ? L.isoZ() : `failed: ${x.why}`;
      if (x.ok) out.plugs += 1;
    }
    data.plugs_done = Object.keys(done).length ? JSON.stringify(done) : null;
    L.write([{ op: 'update', table: 'po_posts', id: p._id, data }]);
    out.counted += 1;
  }
  return out;
}

function stats(s) {
  const last = L.toDate(s.stats_at);
  if (last && L.now().getTime() - last.getTime() < STATS_EVERY_H * 3600000) return { skipped: 'recent' };
  const out = { pages: 0, days: 0, errors: [] };
  const to = new Date(Date.UTC(L.now().getUTCFullYear(), L.now().getUTCMonth(), L.now().getUTCDate()));
  const from = new Date(to.getTime() - 14 * DAY);
  for (const a of L.all("SELECT * FROM po_accounts WHERE _deleted = 0 AND active = 'yes' AND network = 'linkedin' AND kind = 'organization'")) {
    const r = N.adapter('linkedin').stats(a, from, to);
    if (!r.ok) { out.errors.push(`${a.name}: ${r.why}`); continue; }
    const have = new Map(L.all('SELECT _id, day FROM po_stats WHERE _deleted = 0 AND account_id = ?', a._id).map((x) => [x.day, x._id]));
    L.write(r.days.map((d) => (have.has(d.day) ? { op: 'update', table: 'po_stats', id: have.get(d.day), data: d } : { op: 'insert', table: 'po_stats', data: Object.assign({ account_id: a._id }, d) })));
    out.pages += 1;
    out.days += r.days.length;
  }
  L.write([{ op: 'update', table: 'po_settings', id: s._id, data: { stats_at: L.sqlNow() } }]);
  return out;
}

function unstick() {
  const stale = L.sqlNow(new Date(L.now().getTime() - 30 * 60000));
  return L.one("SELECT COUNT(*) AS n FROM po_posts WHERE _deleted = 0 AND status = 'Writing' AND (tries IS NULL OR tries < 3) AND (claimed_at IS NULL OR claimed_at <= ?)", stale).n;
}

function run(mode = '--auto') {
  const held = L.lock('watch');
  if (!held) return { ok: true, skipped: 'Another run is watching' };
  try {
    const s = L.settings();
    const out = { ok: true, mode };
    const asked = mode === '--propose' || !!s.propose_asked_at; // propose() clears it
    if (mode === '--auto' || mode === '--propose') out.propose = propose(s, { asked });
    if (mode === '--auto' || mode === '--feeds') out.feeds = F.check(L.settings());
    if (mode === '--auto' && s.rehearsal !== 'yes') { out.counts = counts(s); out.stats = stats(L.settings()); }
    L.write([{ op: 'update', table: 'po_settings', id: s._id, data: { watch_at: L.sqlNow() } }]);
    if (unstick()) out.write = L.kick('write');
    return out;
  } finally { held.release(); }
}

if (require.main === module) {
  const a = process.argv.slice(2);
  const mode = ['--propose', '--feeds'].find((m) => a.includes(m)) || '--auto';
  try { L.done(run(mode)); } catch (e) { L.done({ ok: false, error: e.message }); process.exitCode = 1; }
}
module.exports = { run, propose, proposalDue, counts, stats };
