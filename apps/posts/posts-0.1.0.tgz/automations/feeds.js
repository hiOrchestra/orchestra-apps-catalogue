'use strict';
/**
 * Posts · the feeds a person follows (RSS or Atom: a blog, a newsletter, a
 * changelog, Google Alerts), read without a library: what is new becomes an
 * idea (Postiz's AutoPost), or a post to write when the feed says so.
 *
 * The first read takes only the 3 newest (a feed with 50 old items is not 50
 * ideas); later reads take what was not seen, 5 at most per feed. The keys
 * seen (guid, id or link) are kept, the last 200.
 *   require('./feeds').check(s) → { checked, ideas, drafts, notes }
 */
const { execFileSync } = require('child_process');
const fs = require('fs');
const L = require('./lib');
const C = require('./pocore');

const FIRST = 3;
const EACH = 5;
const KEEP = 200;

function fetchFeed(url) {
  if (process.env.PO_FAKE_FEEDS) {
    try { const d = JSON.parse(fs.readFileSync(process.env.PO_FAKE_FEEDS, 'utf8')); return d.feeds[url] ? { ok: true, xml: d.feeds[url] } : { ok: false, why: 'The feed answered 404' }; } catch { return { ok: false, why: 'no fake feed' }; }
  }
  if (!/^https?:\/\//i.test(url)) return { ok: false, why: 'Not a web address' };
  try {
    return { ok: true, xml: execFileSync('curl', ['-sSL', '--fail', '--max-time', '20', '--max-filesize', '5000000', '-A', 'Mozilla/5.0 (compatible; OrchestraPosts/0.1)', url], { encoding: 'utf8', timeout: 25000, maxBuffer: 8 << 20 }) };
  } catch (e) { return { ok: false, why: String(e.stderr || e.message).trim().slice(0, 200) }; }
}

const unwrap = (t) => String(t || '').replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1');
const strip = (t) => unwrap(t).replace(/<[^>]+>/g, ' ').replace(/&lt;/g, '<').replace(/&gt;/g, '>').replace(/&quot;/g, '"').replace(/&#39;|&apos;/g, "'").replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&').replace(/\s+/g, ' ').trim();
const tag = (xml, name) => { const m = xml.match(new RegExp(`<${name}(?:\\s[^>]*)?>([\\s\\S]*?)</${name}>`, 'i')); return m ? m[1] : ''; };
/** The feed's title and items, newest first as feeds list them: [{ key, title, link, summary }]. */
function parse(xml) {
  const text = String(xml || '');
  const atom = /<feed[\s>]/i.test(text) && !/<rss[\s>]/i.test(text);
  const blocks = text.match(atom ? /<entry[\s>][\s\S]*?<\/entry>/gi : /<item[\s>][\s\S]*?<\/item>/gi) || [];
  const items = blocks.map((b) => {
    const link = atom ? ((b.match(/<link[^>]*rel=["']alternate["'][^>]*href=["']([^"']+)/i) || b.match(/<link[^>]*href=["']([^"']+)/i) || [])[1] || '') : strip(tag(b, 'link'));
    const key = strip(tag(b, atom ? 'id' : 'guid')) || link || strip(tag(b, 'title'));
    return { key: key.slice(0, 300), title: strip(tag(b, 'title')).slice(0, 300), link: link.trim().slice(0, 1000), summary: strip(tag(b, atom ? 'summary' : 'description') || tag(b, 'content')).slice(0, 800) };
  }).filter((x) => x.key && (x.title || x.summary));
  const head = atom ? text.split(/<entry[\s>]/i)[0] : text.split(/<item[\s>]/i)[0];
  return { title: strip(tag(head, 'title')).slice(0, 200), items };
}

/** Read every active feed; new items → ideas, or posts to write. */
function check(s) {
  const out = { checked: 0, ideas: 0, drafts: 0, notes: [] };
  const accounts = new Map(L.all("SELECT * FROM po_accounts WHERE _deleted = 0 AND active = 'yes'").map((a) => [a._id, a]));
  for (const f of L.all("SELECT * FROM po_feeds WHERE _deleted = 0 AND active = 'yes' ORDER BY _id")) {
    out.checked += 1;
    const r = fetchFeed(f.url);
    if (!r.ok) { L.write([{ op: 'update', table: 'po_feeds', id: f._id, data: { checked_at: L.sqlNow(), note: `It could not be read: ${r.why}` } }]); out.notes.push(`${f.url}: ${r.why}`); continue; }
    const feed = parse(r.xml);
    if (!feed.items.length) { L.write([{ op: 'update', table: 'po_feeds', id: f._id, data: { checked_at: L.sqlNow(), note: 'Nothing in it looks like an RSS or Atom item.' } }]); continue; }
    const seen = L.jsonOf(f.seen, null);
    const first = !Array.isArray(seen);
    const known = new Set(first ? [] : seen);
    const fresh = feed.items.filter((x) => !known.has(x.key)).slice(0, first ? FIRST : EACH);
    const ops = [];
    const account = accounts.get(f.account_id) || null;
    for (const it of fresh) {
      const text = [it.title, it.summary && it.summary !== it.title ? it.summary : ''].filter(Boolean).join('\n\n').slice(0, 1200);
      ops.push({ op: 'insert', table: 'po_ideas', data: { text, url: it.link || null, source: 'feed', feed_id: f._id, item_key: it.key, status: f.auto_draft === 'yes' && account ? 'Used' : 'New', created_by: feed.title || f.url } });
    }
    const all = [...new Set([...feed.items.map((x) => x.key), ...(first ? [] : seen)])].slice(0, KEEP);
    ops.push({ op: 'update', table: 'po_feeds', id: f._id, data: { title: f.title || feed.title || null, seen: JSON.stringify(all), checked_at: L.sqlNow(), note: null } });
    let res = [];
    try { res = L.write(ops); } catch (e) { out.notes.push(`${f.url}: ${e.message}`); continue; }
    out.ideas += fresh.length;
    // A feed that writes on its own: each new idea is a post to write, at the account's next free time.
    if (f.auto_draft === 'yes' && account && fresh.length) {
      const ids = res.filter((x) => x && x.op === 'insert' && x.table === 'po_ideas').map((x) => x._id || x.id);
      const taken = L.all("SELECT publish_at FROM po_posts WHERE _deleted = 0 AND account_id = ? AND status NOT IN ('Dropped', 'Failed') AND publish_at IS NOT NULL", account._id).map((x) => x.publish_at);
      const slots = C.freeSlots({ slots: account.slots, taken, tz: s.timezone || 'UTC', from: L.now(), count: ids.length, days: 21 });
      L.write(ids.map((id, i) => ({ op: 'insert', table: 'po_posts', data: { account_id: account._id, network: account.network, status: 'Writing', idea_id: id, publish_at: slots[i] || null, source: 'feed', created_by: feed.title || f.url, version: 0, tries: 0 } })));
      out.drafts += ids.length;
    }
  }
  return out;
}

module.exports = { check, parse, fetchFeed };
