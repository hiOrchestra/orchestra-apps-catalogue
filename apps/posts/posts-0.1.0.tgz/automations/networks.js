'use strict';
/**
 * Every call Posts makes to a social network, one adapter per network with
 * the same five verbs, and nothing else. When a network renames an argument,
 * this is the only file to change.
 *
 *   find()                        the accounts this workspace can post as
 *   publish(account, text)        { ok, ref, url } or { ok: false, why, unsure }
 *   counts(account, ref)          { ok, reactions, comments } (null when the network does not say)
 *   repost(account, ref)          the account shares its own post again
 *   reply(account, ref, text)     a first comment / self-reply under the post
 *
 * LinkedIn and Facebook go through Composio (lib.composio, as the workflow's
 * agent); X goes through the `twitter` catalogue skill's x.py with the four
 * keys Integrations → X stored for the account (Composio cannot connect X).
 * Argument names were read live on staging 2026-10-10:
 *   LINKEDIN_CREATE_LINKED_IN_POST  author, commentary (≤3000, @[Name](urn) mentions), visibility, reshareContext.parent
 *   LINKEDIN_CREATE_COMMENT_ON_POST actor, object, target_urn, message.text
 *   LINKEDIN_LIST_REACTIONS         entity, count · LINKEDIN_GET_MY_INFO · LINKEDIN_GET_COMPANY_INFO
 *   FACEBOOK_LIST_MANAGED_PAGES · FACEBOOK_CREATE_POST page_id, message, link · FACEBOOK_GET_POST_REACTIONS post_id, summary
 *   FACEBOOK_CREATE_COMMENT object_id, message
 *   x.py whoami · post --file F [--reply-to ID] · read ID · status · check --file F (free, sends nothing)
 * A write is never retried here: a timeout says `unsure` (it may have gone).
 *
 * PO_FAKE_NET=<file.json> answers every network from that file, for tests
 * and the harness: { me, pages, fbPages, x, connected: [...], fail: {verb: why},
 * timeout: [verb…], reactions: {ref: n}, sent: [] } — every write is appended
 * to `sent`.
 */
const { execFileSync } = require('child_process');
const fs = require('fs');
const os = require('os');
const path = require('path');
const L = require('./lib');
const C = require('./pocore');

const FAKE = process.env.PO_FAKE_NET;
const fakeData = () => { try { return JSON.parse(fs.readFileSync(FAKE, 'utf8')); } catch { return {}; } };
const fakeSave = (d) => fs.writeFileSync(FAKE, JSON.stringify(d));
const NOT_CONNECTED = /no connected account|not connected|connection.*(not found|expired|revoked)|auth.*(expired|revoked)|invalid_grant/i;

/** The first value under `key` anywhere in a Composio answer. */
function valueAt(obj, key, depth = 0) {
  if (!obj || typeof obj !== 'object' || depth > 6) return undefined;
  if (obj[key] !== undefined && obj[key] !== null && typeof obj[key] !== 'object') return obj[key];
  for (const v of Object.values(obj)) { const f = valueAt(v, key, depth + 1); if (f !== undefined) return f; }
  return undefined;
}
const failed = (r) => ({ ok: false, why: String(r.why || 'it did not work').slice(0, 300), unsure: !!r.timedOut, notConnected: NOT_CONNECTED.test(String(r.why || '')) });

/** Which Composio toolkits are connected: Set, or null when it cannot be read. */
function connected() {
  if (FAKE) return new Set(fakeData().connected || ['linkedin', 'x']);
  const r = L.api('GET', '/api/composio/connections?view=brief', undefined, 20);
  if (!r.ok) return null;
  const d = r.data || {};
  const list = Array.isArray(d.connections) ? d.connections.filter((c) => !c.status || /^active$/i.test(c.status)).map((c) => String(c.toolkit && (c.toolkit.slug || c.toolkit) || '').toLowerCase())
    : (d.toolkits || []).map((t) => String(t.slug || t).toLowerCase());
  return new Set(list);
}

// ── LinkedIn (Composio) ──────────────────────────────────────────────────
const linkedin = {
  find() {
    const out = [];
    const me = L.composio('LINKEDIN_GET_MY_INFO', {}, 30);
    if (!me.ok) return Object.assign(failed(me), { accounts: [] });
    const id = valueAt(me.data, 'id');
    const first = valueAt(me.data, 'localizedFirstName') || '';
    const last = valueAt(me.data, 'localizedLastName') || '';
    if (id) out.push({ network: 'linkedin', kind: 'person', ref: `urn:li:person:${id}`, name: `${first} ${last}`.trim() || 'LinkedIn profile', handle: valueAt(me.data, 'vanityName') || '' });
    // Pages the person administers: Composio answers one page's details, or a list.
    const pages = L.composio('LINKEDIN_GET_COMPANY_INFO', { count: 100 }, 30);
    if (pages.ok) {
      const d = pages.data || {};
      const list = Array.isArray(d.elements) ? d.elements : Array.isArray(d) ? d : [d];
      for (const o of list) {
        const oid = o && (o.id || (String(o.organization || o.organizationTarget || '').match(/\d+$/) || [])[0]);
        if (!oid) continue;
        out.push({ network: 'linkedin', kind: 'organization', ref: `urn:li:organization:${oid}`, name: o.localizedName || (o.name && o.name.localized && Object.values(o.name.localized)[0]) || `Page ${oid}`, handle: o.vanityName || '' });
      }
    }
    return { ok: true, accounts: out };
  },
  publish(a, text) {
    const r = L.composio('LINKEDIN_CREATE_LINKED_IN_POST', { author: a.ref, commentary: text, visibility: 'PUBLIC', lifecycleState: 'PUBLISHED' }, 90);
    if (!r.ok) return failed(r);
    const ref = (JSON.stringify(r.data || {}).match(C.POST_URN) || [])[0];
    if (!ref) return { ok: false, why: 'LinkedIn answered without the post\'s id: look at the profile before publishing again', unsure: true };
    return { ok: true, ref, url: C.postUrl('linkedin', ref) };
  },
  counts(a, ref) {
    const r = L.composio('LINKEDIN_LIST_REACTIONS', { entity: ref, count: 100 }, 30);
    if (!r.ok) return failed(r);
    const total = valueAt(r.data, 'total');
    const elements = (JSON.stringify(r.data || {}).match(/"reactionType"/g) || []).length;
    return { ok: true, reactions: Number.isFinite(Number(total)) ? Number(total) : elements, comments: null };
  },
  repost(a, ref) {
    const r = L.composio('LINKEDIN_CREATE_LINKED_IN_POST', { author: a.ref, commentary: '', visibility: 'PUBLIC', reshareContext: { parent: ref } }, 60);
    return r.ok ? { ok: true } : failed(r);
  },
  /** A company page's days: [{ day, impressions, clicks, reactions, comments, shares }]. */
  stats(a, from, to) {
    const id = String(a.ref).replace(/^urn:li:organization:/, '');
    const r = L.composio('LINKEDIN_GET_SHARE_STATS', { organizational_entity: `urn:li:organization:${id}`, time_intervals: `(timeRange:(start:${from.getTime()},end:${to.getTime()}),timeGranularityType:DAY)` }, 40);
    if (!r.ok) return failed(r);
    const d = r.data || {};
    const list = Array.isArray(d.elements) ? d.elements : (Array.isArray(d) ? d : []);
    return { ok: true, days: list.filter((e) => e && e.timeRange && e.totalShareStatistics).map((e) => {
      const t = e.totalShareStatistics;
      return { day: new Date(Number(e.timeRange.start)).toISOString().slice(0, 10), impressions: t.impressionCount || 0, clicks: t.clickCount || 0, reactions: t.likeCount || 0, comments: t.commentCount || 0, shares: t.shareCount || 0 };
    }) };
  },
  reply(a, ref, text) {
    const r = L.composio('LINKEDIN_CREATE_COMMENT_ON_POST', { actor: a.ref, object: ref, target_urn: ref, message: { text } }, 60);
    return r.ok ? { ok: true } : failed(r);
  },
};

// ── Facebook pages (Composio) ────────────────────────────────────────────
const facebook = {
  find() {
    const r = L.composio('FACEBOOK_LIST_MANAGED_PAGES', { limit: 50, fields: 'id,name,username' }, 30);
    if (!r.ok) return Object.assign(failed(r), { accounts: [] });
    const d = r.data || {};
    const list = Array.isArray(d.data) ? d.data : Array.isArray(d) ? d : (valueAt(d, 'id') ? [d] : []);
    return { ok: true, accounts: list.filter((p) => p && p.id).map((p) => ({ network: 'facebook', kind: 'page', ref: String(p.id), name: p.name || `Page ${p.id}`, handle: p.username || '' })) };
  },
  publish(a, text) {
    const link = (text.match(/https?:\/\/\S+/) || [])[0];
    const r = L.composio('FACEBOOK_CREATE_POST', Object.assign({ page_id: a.ref, message: text, published: true }, link ? { link } : {}), 90);
    if (!r.ok) return failed(r);
    const ref = String(valueAt(r.data, 'id') || '');
    if (!/^\d+_\d+$/.test(ref)) return { ok: false, why: 'Facebook answered without the post\'s id: look at the page before publishing again', unsure: true };
    return { ok: true, ref, url: C.postUrl('facebook', ref) };
  },
  counts(a, ref) {
    const r = L.composio('FACEBOOK_GET_POST_REACTIONS', { post_id: ref, summary: true, limit: 1 }, 30);
    if (!r.ok) return failed(r);
    const n = valueAt(r.data, 'total_count');
    return { ok: true, reactions: Number.isFinite(Number(n)) ? Number(n) : null, comments: null };
  },
  repost() { return { ok: false, why: 'A Facebook page cannot share its own post again here' }; },
  reply(a, ref, text) {
    const r = L.composio('FACEBOOK_CREATE_COMMENT', { object_id: ref, message: text }, 60);
    return r.ok ? { ok: true } : failed(r);
  },
};

// ── X (the twitter skill, with the account's own keys) ───────────────────
const X_SCRIPT = () => process.env.PO_X_SCRIPT || path.join(process.env.OPENCLAW_STATE_DIR || '/home/node/.openclaw', 'skills', 'twitter', 'scripts', 'x.py');
/** x.py's one JSON object, with its exit code: 0 done, 1 X refused or unreachable, 2 nothing was sent. */
function xpy(args, text, seconds = 60) {
  if (FAKE) return fakeX(args, text);
  if (!fs.existsSync(X_SCRIPT())) return { code: 2, out: { ok: false, error: 'The X skill is not installed: connect X in Integrations → X' } };
  let dir = null;
  const full = [X_SCRIPT(), ...args];
  if (text !== undefined) {
    dir = fs.mkdtempSync(path.join(os.tmpdir(), 'posts-x-'));
    fs.writeFileSync(path.join(dir, 'post.txt'), text);
    full.push('--file', path.join(dir, 'post.txt'));
  }
  try {
    const raw = execFileSync('python3', full, { encoding: 'utf8', timeout: seconds * 1000, stdio: ['ignore', 'pipe', 'pipe'] });
    return { code: 0, out: JSON.parse(raw) };
  } catch (e) {
    let out = {};
    try { out = JSON.parse(String(e.stdout || '')); } catch { out = { ok: false, error: String(e.stderr || e.message).trim().slice(0, 300) }; }
    return { code: e.status == null ? 1 : e.status, out, timedOut: e.signal === 'SIGTERM' || /ETIMEDOUT/.test(String(e.message)) };
  } finally { if (dir) fs.rmSync(dir, { recursive: true, force: true }); }
}
const xWhy = (r) => String((r.out && (r.out.error || (r.out.problems || []).join('; ') || (r.out.posts && r.out.posts[0] && r.out.posts[0].issues.join('; ')))) || 'X did not take it').slice(0, 300)
  + (r.out && r.out.fix ? ` — ${String(r.out.fix).slice(0, 160)}` : '');
const x = {
  find() {
    const r = xpy(['whoami'], undefined, 30);
    if (r.code !== 0 || !r.out.ok) return { ok: false, why: xWhy(r), notConnected: r.code === 2, accounts: [] };
    return { ok: true, accounts: [{ network: 'x', kind: 'account', ref: String(r.out.id), name: r.out.name || r.out.username, handle: r.out.username || '' }] };
  },
  /** Free: X's own count of the text and its price. Sends nothing. */
  check(text) {
    // x.py may not be readable from a workflow's script (it is the skill's, linked for the agent): count here then.
    let readable = !!FAKE;
    try { fs.accessSync(X_SCRIPT(), fs.constants.R_OK); readable = true; } catch { /* the estimate below */ }
    if (!readable) {
      const links = String(text).match(/https?:\/\/\S+/g) || [];
      const length = [...String(text).replace(/https?:\/\/\S+/g, '')].length + links.length * 23;
      return length > 280 ? { ok: false, why: `${length} characters as X counts them; the limit is 280`, length } : { ok: true, length, cost: links.length ? C.NETWORKS.x.cost.link : C.NETWORKS.x.cost.post, estimated: true };
    }
    const r = xpy(['check'], text, 20);
    const p = (r.out.posts || [])[0] || {};
    return { ok: r.code === 0 && r.out.ok, why: r.code === 0 ? null : xWhy(r), cost: r.out.total_cost_usd, length: p.length };
  },
  publish(a, text) {
    const r = xpy(['post'], text, 90);
    if (r.code === 0 && r.out.ok) return { ok: true, ref: String(r.out.id), url: r.out.url || C.postUrl('x', r.out.id), cost: r.out.cost_usd };
    // Exit 2: nothing was sent. Exit 1 after a timeout or without an answer: it may have gone.
    return { ok: false, why: xWhy(r), unsure: r.code !== 2 && (r.timedOut || !r.out || r.out.sent !== false), notConnected: r.code === 2 && /not set|connect X/i.test(xWhy(r)) };
  },
  counts(a, ref) {
    const r = xpy(['read', ref], undefined, 30);
    if (r.code !== 0 || !r.out.ok) return { ok: false, why: xWhy(r) };
    const p = r.out.post || {};
    return { ok: true, reactions: Number(p.likes || 0) + Number(p.reposts || 0), comments: Number(p.replies || 0), cost: r.out.cost_usd };
  },
  repost() { return { ok: false, why: 'The X skill does not repost' }; },
  reply(a, ref, text) {
    const r = xpy(['post', '--reply-to', ref], text, 60);
    return r.code === 0 && r.out.ok ? { ok: true } : { ok: false, why: xWhy(r), unsure: r.code === 1 };
  },
};

const ADAPTERS = { linkedin, facebook, x };
const adapter = (network) => ADAPTERS[network] || null;

// ── the fake, for tests and the local harness ────────────────────────────
function fakeComposio(slug, args) {
  const d = fakeData();
  const verb = /CREATE_LINKED_IN_POST|FACEBOOK_CREATE_POST/.test(slug) ? (args.reshareContext ? 'repost' : 'publish') : /COMMENT/.test(slug) ? 'reply' : /REACTIONS/.test(slug) ? 'counts' : /STATS/.test(slug) ? 'stats' : 'find';
  if (d.fail && d.fail[verb]) return { ok: false, why: d.fail[verb] };
  if ((d.timeout || []).includes(verb)) return { ok: false, why: 'Operation timed out (28)', timedOut: true };
  const toolkit = slug.startsWith('FACEBOOK_') ? 'facebook' : 'linkedin';
  if (Array.isArray(d.connected) && !d.connected.includes(toolkit)) return { ok: false, why: `No connected account found for toolkit ${toolkit} (fake)` };
  if (slug === 'LINKEDIN_GET_MY_INFO') return { ok: true, data: d.me || { id: 'Fk3Person', localizedFirstName: 'Ana', localizedLastName: 'Test', vanityName: 'ana-test' } };
  if (slug === 'LINKEDIN_GET_COMPANY_INFO') return d.pages === null ? { ok: false, why: 'No organizations found where you have the specified role.' } : { ok: true, data: d.pages || { id: 4242, localizedName: 'Lumen Studio', vanityName: 'lumen-studio' } };
  if (slug === 'LINKEDIN_GET_SHARE_STATS') {
    const m = String(args.time_intervals).match(/start:(\d+),end:(\d+)/);
    const elements = [];
    for (let t = Number(m[1]); t < Number(m[2]); t += 86400000) elements.push({ timeRange: { start: t, end: t + 86400000 }, totalShareStatistics: { impressionCount: 120 + (t / 86400000 % 7) * 30, clickCount: 4, likeCount: 9, commentCount: 1, shareCount: 1 } });
    return { ok: true, data: { elements } };
  }
  if (slug === 'FACEBOOK_LIST_MANAGED_PAGES') return { ok: true, data: { data: d.fbPages || [{ id: '1001', name: 'Lumen on Facebook' }] } };
  if (/REACTIONS/.test(slug)) {
    const n = (d.reactions || {})[args.entity || args.post_id] || 0;
    return { ok: true, data: slug.startsWith('FACEBOOK_') ? { summary: { total_count: n } } : { paging: { total: n }, elements: [] } };
  }
  d.sent = d.sent || [];
  d.sent.push(Object.assign({ slug }, args));
  fakeSave(d);
  if (slug === 'FACEBOOK_CREATE_POST') return { ok: true, data: { id: `1001_${9000 + d.sent.length}` } };
  if (slug === 'FACEBOOK_CREATE_COMMENT') return { ok: true, data: { id: `c${d.sent.length}` } };
  if (/COMMENT/.test(slug)) return { ok: true, data: { id: `comment-${d.sent.length}` } };
  return { ok: true, data: { id: `urn:li:share:${7300000000000000000 + d.sent.length}` } };
}
function fakeX(args, text) {
  const d = fakeData();
  const cmd = args[0];
  if (cmd === 'check') {
    const n = [...String(text || '')].length;
    return n > 280 ? { code: 2, out: { ok: false, sent: false, posts: [{ length: n, issues: [`${n} characters as X counts them; the limit is 280`] }] } } : { code: 0, out: { ok: true, sent: false, posts: [{ length: n }], total_cost_usd: /https?:\/\//.test(text) ? 0.2 : 0.015 } };
  }
  const verb = cmd === 'whoami' ? 'find' : cmd === 'read' ? 'counts' : args.includes('--reply-to') ? 'reply' : 'publish';
  if (Array.isArray(d.connected) && !d.connected.includes('x')) return { code: 2, out: { ok: false, sent: false, problems: ['X_API_KEY is not set'], fix: 'Connect X in the Orchestra portal, Integrations → X.' } };
  if (d.fail && d.fail[verb]) return { code: 1, out: { ok: false, error: d.fail[verb] } };
  if ((d.timeout || []).includes(verb)) return { code: 1, out: {}, timedOut: true };
  if (cmd === 'whoami') return { code: 0, out: Object.assign({ ok: true, id: '555000', username: 'lumen_test', name: 'Lumen' }, d.x || {}) };
  if (cmd === 'read') return { code: 0, out: { ok: true, post: { id: args[1], likes: (d.reactions || {})[args[1]] || 0, reposts: 0, replies: 0 }, cost_usd: 0.005 } };
  if (cmd === 'post' && [...String(text || '')].length > 280) return { code: 2, out: { ok: false, sent: false, posts: [{ issues: ['over 280'] }] } };
  d.sent = d.sent || [];
  d.sent.push({ x: cmd, args, text });
  fakeSave(d);
  const id = String(1840000000000000000 + d.sent.length);
  return { code: 0, out: { ok: true, id, url: `https://x.com/i/web/status/${id}`, cost_usd: /https?:\/\//.test(text) ? 0.2 : 0.015 } };
}

module.exports = { adapter, connected, ADAPTERS, fake: fakeComposio, valueAt, xpy };
