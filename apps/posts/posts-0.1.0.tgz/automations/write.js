'use strict';
/**
 * Posts · Write: the posts waiting to be written (status Writing — the weekly
 * proposal, Write it on an idea, Another version, Rewrite with my notes).
 *
 *   pick   claims up to 6 (claimed_at, atomic), and gives the agent everything
 *          it needs as one JSON: the voice, the examples, what to avoid, each
 *          post's network and account, its idea (and the page of its link,
 *          the text of its file from Files), its template, and — to rewrite —
 *          the current text, the person's instruction and their notes; plus
 *          the last posts (not to repeat them) and the ones that did best.
 *   save   reads the agent's JSON (PRIOR), checks each text (pocore.checkDraft)
 *          and saves it as a Draft; a missing or refused one is tried again
 *          by the next run, three times, then says why.
 *
 * The agent only answers JSON: it never writes to the database.
 *   node write.js pick | save
 */
const { execFileSync } = require('child_process');
const fs = require('fs');
const os = require('os');
const path = require('path');
const L = require('./lib');
const C = require('./pocore');

const MAX = 6;
const STALE_MIN = 30;
const TRIES = 3;
const LANG = { es: 'Spanish', en: 'English' };

/** The readable text of a web page, at most n characters (a link on an idea). */
function pageText(url, n = 4000) {
  if (!/^https?:\/\//i.test(url || '')) return '';
  if (process.env.PO_FAKE_FEEDS) { try { return String(JSON.parse(fs.readFileSync(process.env.PO_FAKE_FEEDS, 'utf8')).pages[url] || '').slice(0, n); } catch { return ''; } }
  try {
    const html = execFileSync('curl', ['-sSL', '--max-time', '15', '--max-filesize', '3000000', '-A', 'Mozilla/5.0 (compatible; OrchestraPosts/0.1)', url], { encoding: 'utf8', timeout: 20000, maxBuffer: 8 << 20 });
    return html.replace(/<(script|style|noscript|svg|nav|footer|header)[\s\S]*?<\/\1>/gi, ' ').replace(/<[^>]+>/g, ' ').replace(/&nbsp;/g, ' ').replace(/&amp;/g, '&')
      .replace(/&#39;|&apos;/g, "'").replace(/&quot;/g, '"').replace(/\s+/g, ' ').trim().slice(0, n);
  } catch { return ''; }
}
/** The text of a file in Files (md, txt, html, pdf, docx), at most n characters. */
function fileText(id, name, n = 6000) {
  if (!id) return '';
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'posts-file-'));
  try {
    const ext = String(path.extname(name || '').slice(1) || 'txt').toLowerCase();
    const file = path.join(dir, `f.${ext}`);
    if (!L.fileDownload(id, file).ok) return '';
    if (ext === 'pdf') return execFileSync('pdftotext', ['-layout', file, '-'], { encoding: 'utf8', timeout: 30000 }).slice(0, n);
    if (['docx', 'odt', 'html', 'htm'].includes(ext)) return execFileSync('pandoc', [file, '-t', 'plain', '--wrap=none'], { encoding: 'utf8', timeout: 30000 }).slice(0, n);
    return fs.readFileSync(file, 'utf8').slice(0, n);
  } catch { return ''; } finally { fs.rmSync(dir, { recursive: true, force: true }); }
}
const accountSaid = (a) => (a ? `${C.netOf(a.network).name} · ${C.netOf(a.network).kinds[a.kind] || a.kind} · ${a.name}${a.handle ? ` (${a.network === 'x' ? '@' : ''}${a.handle})` : ''}` : 'no account');

function pick() {
  const s = L.settings();
  const now = L.sqlNow();
  const stale = L.sqlNow(new Date(L.now().getTime() - STALE_MIN * 60000));
  const rows = L.all(`SELECT * FROM po_posts WHERE _deleted = 0 AND status = 'Writing' AND (tries IS NULL OR tries < ${TRIES})
    AND (claimed_at IS NULL OR claimed_at <= ?) ORDER BY COALESCE(publish_at, '9999'), _id LIMIT ${MAX}`, stale);
  const mine = [];
  for (const p of rows) {
    try { L.write([{ op: 'update', table: 'po_posts', id: p._id, when: { status: 'Writing', claimed_at: p.claimed_at }, data: { claimed_at: now } }]); mine.push(p); } catch { /* another run took it */ }
  }
  if (!mine.length) return { ok: true, items: [], instructions: 'Nothing to write: answer {"items":[]}.' };
  const accounts = new Map(L.all('SELECT * FROM po_accounts WHERE _deleted = 0').map((a) => [a._id, a]));
  const items = mine.map((p) => {
    const a = accounts.get(p.account_id);
    const network = (a && a.network) || p.network || 'linkedin';
    const idea = p.idea_id ? L.one('SELECT * FROM po_ideas WHERE _id = ?', p.idea_id) : null;
    const tpl = p.template_id ? L.one('SELECT name, body FROM po_templates WHERE _id = ?', p.template_id) : null;
    const notes = L.all('SELECT quote, text FROM po_notes WHERE _deleted = 0 AND post_id = ? AND resolved_at IS NULL ORDER BY _id', p._id);
    const siblings = p.group_key ? L.all("SELECT p.text, a.network, a.name FROM po_posts p LEFT JOIN po_accounts a ON a._id = p.account_id WHERE p._deleted = 0 AND p.group_key = ? AND p._id <> ? AND p.text IS NOT NULL AND p.text <> ''", p.group_key, p._id) : [];
    const item = { id: p._id, network, account: accountSaid(a), style: C.STYLE[network], limit: C.netOf(network).limit, goes_out: p.publish_at || null };
    if (p.brief) item.brief = p.brief;
    if (idea) {
      item.idea = { text: idea.text || '', url: idea.url || undefined, from: idea.source === 'feed' ? 'a feed the person follows' : idea.source === 'agent' ? 'you' : 'the person' };
      if (idea.url) item.idea.page = pageText(idea.url) || undefined;
      if (idea.file_id) item.idea.file = fileText(idea.file_id, idea.file_name) || undefined;
    }
    if (tpl) item.template = tpl;
    if (p.text && (p.rewrite_note || notes.length)) item.rewrite = { current: p.text, instruction: p.rewrite_note || undefined, notes: notes.length ? notes : undefined };
    if (siblings.length) item.other_versions = siblings.map((x) => ({ network: x.network, account: x.name, text: x.text.slice(0, 600) }));
    return item;
  });
  const recent = L.all("SELECT text FROM po_posts WHERE _deleted = 0 AND status = 'Published' ORDER BY published_at DESC LIMIT 8").map((x) => String(x.text).slice(0, 280));
  const best = L.all("SELECT text, reactions FROM po_posts WHERE _deleted = 0 AND status = 'Published' AND reactions > 0 ORDER BY reactions DESC LIMIT 3").map((x) => ({ reactions: x.reactions, text: String(x.text).slice(0, 500) }));
  const instructions = [
    `You write social media posts for ${s.company_name || 'the company'}, in ${LANG[C.langOf(s.language)]}, as the account each item names (a person writes as "I", a company page as "we").`,
    'Write each item, ready to publish, in the voice below. Each network reads differently: follow the item\'s `style` and stay under its `limit`.',
    'From an idea: the post is about that idea; use its page or file for facts, never invent numbers, names, quotes or results. Without an idea: one of the topics, and not one of the recent posts again.',
    'To rewrite: keep what the person did not ask to change; follow the instruction, and fix every note (a quote of their text and what they said about it).',
    'Other versions of the same idea for other accounts may be given: say the same thing in this network\'s way, not the same words.',
    'Never leave a placeholder ([…], {{…}}, a line of "…"), never add a link that was not given, no "As an AI". A template is a shape to follow, filled in completely.',
    `Answer ONLY one JSON object: ${C.ANSWER}`,
  ].join('\n');
  return {
    ok: true, instructions,
    voice: { how: s.voice || '', topics: s.topics || '', examples: s.examples || '', avoid: s.avoid || '', signature_added_later: s.signature_auto === 'yes' ? s.signature : undefined },
    today: C.local(L.now(), s.timezone || 'UTC').ymd,
    recent, best, items,
  };
}

function save() {
  const picked = L.stepOut('STEP_pick');
  const answer = L.jsonIn(process.env.PRIOR || '') || {};
  const got = new Map((Array.isArray(answer.items) ? answer.items : []).filter((x) => x && x.id != null).map((x) => [Number(x.id), x]));
  const ids = (picked.items || []).map((x) => Number(x.id));
  // Without the pick's output (a run by hand), what this run claimed is what is claimed and Writing.
  const list = ids.length ? ids : L.all("SELECT _id FROM po_posts WHERE _deleted = 0 AND status = 'Writing' AND claimed_at IS NOT NULL").map((x) => x._id);
  const out = { ok: true, saved: 0, retry: 0, gave_up: 0, refused: [] };
  for (const id of list) {
    const p = L.one('SELECT * FROM po_posts WHERE _id = ? AND _deleted = 0', id);
    if (!p || p.status !== 'Writing') continue;
    const a = got.get(id);
    const net = (L.one('SELECT network FROM po_accounts WHERE _id = ?', p.account_id) || {}).network || p.network;
    const c = a ? C.checkDraft(a.text, net) : { ok: false, why: 'the agent did not answer for it' };
    if (c.ok) {
      const ops = [{ op: 'update', table: 'po_posts', id, when: { status: 'Writing' }, data: { status: 'Draft', text: c.text, agent_note: L.clean(a.note, 300) || null, version: (Number(p.version) || 0) + 1,
        claimed_at: null, rewrite_note: null, error: null, tries: 0 } }];
      if (p.text) for (const n of L.all('SELECT _id FROM po_notes WHERE _deleted = 0 AND post_id = ? AND resolved_at IS NULL', id)) ops.push({ op: 'update', table: 'po_notes', id: n._id, data: { resolved_at: L.isoZ(), by: 'rewritten' } });
      if (p.idea_id) ops.push({ op: 'update', table: 'po_ideas', id: p.idea_id, data: { status: 'Used', post_id: id } });
      try { L.write(ops); out.saved += 1; } catch { /* moved meanwhile */ }
      continue;
    }
    out.refused.push({ id, why: c.why });
    const tries = (Number(p.tries) || 0) + 1;
    if (tries < TRIES) { L.write([{ op: 'update', table: 'po_posts', id, data: { tries, claimed_at: null, error: `Attempt ${tries}: ${c.why}` } }]); out.retry += 1; continue; }
    // Given up: a rewrite goes back to the draft it was; a new post says it could not be written.
    L.write([{ op: 'update', table: 'po_posts', id, data: p.text ? { status: 'Draft', tries: 0, claimed_at: null, error: `It could not be rewritten (${c.why}). The draft is as it was.` }
      : { status: 'Failed', tries, claimed_at: null, error: `It could not be written (${c.why}). Ask for another version, or write it yourself.` } }]);
    out.gave_up += 1;
  }
  return out;
}

if (require.main === module) {
  const cmd = process.argv[2];
  try { L.done(cmd === 'save' ? save() : pick()); } catch (e) { L.done({ ok: false, error: e.message, items: [] }); process.exitCode = 1; }
}
module.exports = { pick, save, pageText, fileText };
