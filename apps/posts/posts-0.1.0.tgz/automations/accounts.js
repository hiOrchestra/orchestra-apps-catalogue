'use strict';
/**
 * Posts · the accounts this workspace can post as: the LinkedIn profile and
 * the pages it administers, the Facebook pages, the X account. Asked from
 * Settings (Look for accounts). A new account comes in off, with weekday
 * 09:00 slots; one already here keeps what the person set (only its name
 * follows the network). An account that is gone is left, with a note.
 *
 * Each network is asked only when it is connected (Composio for LinkedIn and
 * Facebook; for X, the skill's keys — whoami is one paid read, ≤ US$0.01, so
 * it runs only here, on a person's click).
 *   node accounts.js
 */
const L = require('./lib');
const C = require('./pocore');
const N = require('./networks');
const X = require('./xjobs');

function run() {
  const s = L.settings();
  const conn = N.connected();
  const out = { ok: true, found: 0, added: 0, notes: [] };
  const have = L.all('SELECT * FROM po_accounts WHERE _deleted = 0');
  const seen = new Set();
  for (const network of Object.keys(C.NETWORKS)) {
    const net = C.NETWORKS[network];
    if (net.via === 'composio' && conn && !conn.has(net.toolkit)) { out.notes.push(`${net.name}: not connected in Integrations`); continue; }
    if (network === 'x' && !X.direct()) {
      // The keys reach the agent, not this script: Posts · X asks who they belong to.
      L.write([{ op: 'update', table: 'po_settings', id: s._id, data: { x_asked_at: L.sqlNow(), x_note: null } }]);
      out.x = L.kick('x');
      continue;
    }
    const r = N.adapter(network).find();
    if (!r.ok) { out.notes.push(`${net.name}: ${r.notConnected ? 'not connected' : r.why}`); continue; }
    const ops = [];
    for (const a of r.accounts) {
      seen.add(`${a.network} ${a.ref}`);
      out.found += 1;
      const old = have.find((x) => x.network === a.network && x.ref === a.ref);
      if (old) ops.push({ op: 'update', table: 'po_accounts', id: old._id, data: { name: a.name, handle: a.handle || null, kind: a.kind, found_at: L.sqlNow(), note: null } });
      else {
        ops.push({ op: 'insert', table: 'po_accounts', data: Object.assign({}, a, { active: 'no', slots: JSON.stringify(C.DEFAULT_SLOTS), found_at: L.sqlNow() }) });
        out.added += 1;
      }
    }
    if (ops.length) L.write(ops);
  }
  const gone = have.filter((x) => !seen.has(`${x.network} ${x.ref}`) && !(x.network === 'x' && !X.direct()) && !out.notes.some((n) => n.startsWith(C.netOf(x.network).name)));
  if (gone.length) L.write(gone.map((x) => ({ op: 'update', table: 'po_accounts', id: x._id, data: { note: 'Not found the last time: it may have been disconnected, or you are no longer its admin.' } })));
  L.write([{ op: 'update', table: 'po_settings', id: s._id, data: { accounts_at: L.sqlNow(), accounts_note: out.notes.join(' · ').slice(0, 500) || null } }]);
  return out;
}

if (require.main === module) {
  try { L.done(run()); } catch (e) { L.done({ ok: false, error: e.message }); process.exitCode = 1; }
}
module.exports = { run };
