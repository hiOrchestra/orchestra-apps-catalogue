'use strict';
/**
 * Posts · what an agent may do in chat (the skill app-posts): read the week,
 * the drafts and the numbers, and write down an idea. It never approves,
 * schedules, publishes or deletes: those are a person's clicks in the desk.
 *
 *   node posts.js week                      what goes out in the next 7 days, and what waits for review
 *   node posts.js idea --text "…" [--url U] an idea for the next proposal (or Write it in the desk)
 *   node posts.js ideas                     the ideas not used yet
 *   node posts.js done [--days 30]          what went out, with its reactions
 *   node posts.js where                     the desk, the accounts, and how a week is proposed
 */
const L = require('./lib');
const C = require('./pocore');

const arg = (a, k) => { const i = a.indexOf(k); return i >= 0 ? a[i + 1] : undefined; };
const desk = (s, p = '') => (s.desk_url ? `${s.desk_url}#/${p}` : null);
const when = (s, iso) => {
  if (!iso) return null;
  const l = C.local(new Date(iso), s.timezone || 'UTC');
  return `${C.DAYS[l.dow - 1]} ${l.ymd} ${l.hm}`;
};
const line = (s, p) => ({ id: p._id, status: p.status === 'Published' && p.rehearsed === 'yes' ? 'Rehearsed' : p.status, when: when(s, p.publish_at), account: `${C.netOf(p.network).name} · ${p.account || '?'}`,
  text: String(p.text || p.brief || '').slice(0, 160), url: p.url || undefined, reactions: p.reactions == null ? undefined : p.reactions, error: p.error || undefined });
const POSTS = 'SELECT p.*, a.name AS account FROM po_posts p LEFT JOIN po_accounts a ON a._id = p.account_id WHERE p._deleted = 0';

function run(a) {
  const s = L.settings();
  const cmd = a[0];
  if (cmd === 'week') {
    const to = L.isoZ(new Date(L.now().getTime() + 7 * 86400000));
    const coming = L.all(`${POSTS} AND p.status IN ('Scheduled', 'Writing', 'Draft') AND p.publish_at IS NOT NULL AND p.publish_at <= ? ORDER BY p.publish_at`, to).map((p) => line(s, p));
    const review = L.all(`${POSTS} AND p.status IN ('Draft', 'Failed') ORDER BY p.publish_at`).map((p) => line(s, p));
    return { ok: true, coming, to_review: review, desk: desk(s), rehearsal: s.rehearsal === 'yes',
      tell_the_person: review.length ? `${review.length} wait for review in the desk. Only a person approves.` : 'Nothing waits for review.' };
  }
  if (cmd === 'idea') {
    const text = L.clean(arg(a, '--text'), 2000);
    const url = L.clean(arg(a, '--url'), 1000);
    if (text.length < 3) return { ok: false, error: '--text is the idea, in a few words or a paragraph' };
    if (url && !/^https?:\/\//i.test(url)) return { ok: false, error: '--url must be a web address' };
    const [r] = L.write([{ op: 'insert', table: 'po_ideas', data: { text, url: url || null, source: 'agent', status: 'New', created_by: process.env.ORCHESTRA_AGENT_ID || 'agent' } }]);
    return { ok: true, id: r && r._id, tell_the_person: 'Written down. It goes into the next weekly proposal, or press Write it in Ideas.', desk: desk(s, 'ideas') };
  }
  if (cmd === 'ideas') return { ok: true, ideas: L.all("SELECT _id AS id, text, url, source FROM po_ideas WHERE _deleted = 0 AND status = 'New' ORDER BY _id DESC LIMIT 50") };
  if (cmd === 'done') {
    const days = Math.max(1, Math.min(365, Number(arg(a, '--days')) || 30));
    const since = L.isoZ(new Date(L.now().getTime() - days * 86400000));
    return { ok: true, published: L.all(`${POSTS} AND p.status = 'Published' AND p.published_at >= ? ORDER BY p.published_at DESC LIMIT 60`, since).map((p) => line(s, p)) };
  }
  if (cmd === 'where') {
    const accounts = L.all('SELECT network, kind, name, handle, active, slots FROM po_accounts WHERE _deleted = 0 ORDER BY network, _id')
      .map((x) => ({ network: C.netOf(x.network).name, who: `${C.netOf(x.network).kinds[x.kind] || x.kind} · ${x.name}`, on: x.active === 'yes', times: C.slotsSaid(x.slots, 'en') }));
    return { ok: true, desk: desk(s), accounts, proposal: `${s.propose_count || 0} posts, ${C.DAYS[(Number(s.propose_day) || 1) - 1]} ${s.propose_time || '08:00'} (${s.timezone})`, rehearsal: s.rehearsal === 'yes' };
  }
  return { ok: false, error: 'week | idea --text "…" [--url U] | ideas | done [--days N] | where' };
}

if (require.main === module) {
  try { L.done(run(process.argv.slice(2))); } catch (e) { L.done({ ok: false, error: e.message }); process.exitCode = 1; }
}
module.exports = { run };
