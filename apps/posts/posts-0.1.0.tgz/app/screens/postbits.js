// The parts of a post's page that are not the editor: the sentence under
// its title, what a published post did, and asking for another version.
import { act, ago, area, at, field, net, sheet } from '../data.js';

const { el } = Orch;

export function sentence(p, s) {
  if (p.status === 'Writing') return 'The agent is writing it. This page looks again on its own.';
  if (p.status === 'Publishing') return 'Going out now.';
  if (p.status === 'Published') return p.rehearsed === 'yes' ? `Rehearsed ${at(p.published_at)}: checked, nothing went out.` : `Published ${at(p.published_at)}.`;
  if (p.status === 'Scheduled') return `Approved. It goes out ${at(p.publish_at)}${s.rehearsal === 'yes' ? ' (in rehearsal: nothing goes out)' : ''}. It can still change.`;
  if (p.status === 'Failed') return 'It did not go out.';
  if (p.status === 'Dropped') return 'Dropped.';
  const from = p.source === 'agent' ? `Written by the agent${p.created_by === 'weekly proposal' ? ' for the week' : ''}` : p.source === 'feed' ? `From a feed (${p.created_by || ''})` : 'Written by you';
  return `${from}${p.version > 1 ? `, version ${p.version}` : ''}${p.agent_note ? `: ${String(p.agent_note).trim().replace(/[.\s]+$/, '')}` : ''}. Read it as it will look, then approve.`;
}

export function published(p) {
  const done = (() => { try { return JSON.parse(p.plugs_done || '{}'); } catch { return {}; } })();
  return el('dl', { class: 'po-facts' }, [
    p.url ? el('div', [el('dt', 'On ' + net(p.network)), el('dd', el('a', { href: p.url, target: '_blank', rel: 'noopener' }, 'Open the post ↗'))]) : null,
    p.reactions != null ? el('div', [el('dt', 'Reactions'), el('dd', `${p.reactions}${p.comments ? ` · ${p.comments} comments` : ''}${p.reactions_at ? ` (${ago(p.reactions_at)})` : ''}`)]) : null,
    p.cost_usd ? el('div', [el('dt', 'Cost'), el('dd', `US$${Number(p.cost_usd).toFixed(3)}${p.rehearsed === 'yes' ? ' (had it gone out)' : ''}`)]) : null,
    done.repost ? el('div', [el('dt', 'Repost'), el('dd', String(done.repost).startsWith('failed') ? done.repost : `done ${ago(done.repost)}`)]) : null,
    done.reply ? el('div', [el('dt', 'First comment'), el('dd', String(done.reply).startsWith('failed') ? done.reply : `done ${ago(done.reply)}`)]) : null,
  ]);
}

export function askRewrite(p, action, again) {
  const what = area('', 3, { maxlength: '600', placeholder: 'Shorter · a stronger first line · less salesy · end with a question…' });
  const go = el('button', { type: 'submit', class: 'oc-btn oc-btn--primary' }, 'Ask the agent');
  const f = el('form', { class: 'oc-stack' }, [el('p', { class: 'oc-help' }, 'The agent writes it again, keeping what you do not ask to change. Your notes go with it.'), field('What should change', what), el('div', { class: 'oc-row' }, go)]);
  const d = sheet(f, { title: 'Another version' });
  setTimeout(() => what.focus(), 50);
  f.addEventListener('submit', async (e) => {
    e.preventDefault();
    go.disabled = true;
    const ok = await act(action, { id: p._id, rewrite_note: String(what.value).trim() || 'Another version, different from this one.' }, 'The agent is writing it.');
    d.close();
    if (ok) again();
  });
}
