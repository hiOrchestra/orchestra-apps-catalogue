// Published: what went out and how it did. Reactions per post (LinkedIn and
// Facebook each hour, X a day and a week after — X charges each read), and
// each LinkedIn company page's last 14 days (impressions, clicks, reactions).
// Rehearsed posts are listed apart: they never went out.
import { C, T, V, at, head, net, netTag, settings, short } from '../data.js';

const { el, router } = Orch;

export function render() {
  Orch.load('view', async () => {
    const s = await settings(true);
    const since = C.isoZ(new Date(Date.now() - 30 * 86400000));
    const [rows, stats, accts] = await Promise.all([
      Orch.db.view(V.posts, { filter: { status: 'Published' }, sort: 'published_at:desc', limit: 200 }),
      Orch.db.list(T.stats, { sort: 'day:desc', limit: 300 }),
      Orch.db.list(T.accounts, { limit: 100 }),
    ]);
    const all = rows.rows || [];
    const live = all.filter((p) => p.rehearsed !== 'yes');
    const rehearsed = all.filter((p) => p.rehearsed === 'yes');
    const month = live.filter((p) => p.published_at >= since);
    const reactions = month.reduce((n, p) => n + (Number(p.reactions) || 0), 0);
    const best = month.slice().sort((a, b) => (Number(b.reactions) || 0) - (Number(a.reactions) || 0))[0];
    const cost = month.reduce((n, p) => n + (Number(p.cost_usd) || 0), 0);
    return el('div', { class: 'oc-stack oc-stack--loose' }, [
      head('Published', 'What went out and how it did. The agent reads this to write the next week.', null),
      el('div', { class: 'po-kpis' }, [
        kpi('Last 30 days', String(month.length), month.length === 1 ? 'post' : 'posts'),
        kpi('Reactions', String(reactions), month.length ? `${(reactions / month.length).toFixed(1)} a post` : '—'),
        kpi('Best', best ? String(best.reactions || 0) : '—', best ? short(best.text, 40) : 'nothing yet'),
        kpi('X cost', cost ? `US$${cost.toFixed(2)}` : '—', 'what X charged'),
      ]),
      pages(stats.rows || [], accts.rows || []),
      el('section', { class: 'oc-stack' }, [
        el('h2', { class: 'oc-h2' }, 'Posts'),
        live.length ? el('ul', { class: 'po-rows' }, live.map(rowOf)) : el('p', { class: 'oc-card po-empty' }, s.rehearsal === 'yes' ? 'Nothing went out yet: rehearsal is on (Settings).' : 'Nothing went out yet.'),
      ]),
      rehearsed.length ? el('details', { class: 'po-details' }, [el('summary', `Rehearsed (${rehearsed.length}): checked, never sent`), el('ul', { class: 'po-rows' }, rehearsed.map(rowOf))]) : null,
    ]);
  });
}

const kpi = (label, value, sub) => el('div', [el('span', { class: 'oc-label' }, label), el('span', { class: 'oc-kpi__value' }, value), el('span', { class: 'oc-help' }, sub)]);

function rowOf(p) {
  return el('li', { class: 'po-row' }, router.link(`/post/${p._id}`, [
    el('span', { class: 'po-row__first oc-value' }, at(p.published_at)),
    el('span', { class: 'po-row__name' }, [el('span', short(p.text, 130)), el('span', { class: 'po-row__sub' }, [netTag(p.network), ` ${p.account_name || ''}`])]),
    el('span', { class: 'po-row__right' }, p.rehearsed === 'yes' ? el('span', { class: 'oc-badge' }, 'Rehearsed') : el('span', { class: 'oc-value' }, p.reactions == null ? '—' : `${p.reactions} reaction${p.reactions === 1 ? '' : 's'}`)),
  ], { class: 'po-row__open' }));
}

function pages(stats, accts) {
  const orgs = accts.filter((a) => a.network === 'linkedin' && a.kind === 'organization' && stats.some((x) => x.account_id === a._id));
  if (!orgs.length) return null;
  return el('section', { class: 'oc-stack' }, [
    el('h2', { class: 'oc-h2' }, 'Company pages, last 14 days'),
    el('table', { class: 'po-table' }, [
      el('thead', el('tr', [el('th', 'Page'), el('th', { class: 'r' }, 'Impressions'), el('th', { class: 'r' }, 'Clicks'), el('th', { class: 'r' }, 'Reactions'), el('th', { class: 'r' }, 'Comments'), el('th', { class: 'r' }, 'Shares')])),
      el('tbody', orgs.map((a) => {
        const mine = stats.filter((x) => x.account_id === a._id).slice(0, 14);
        const sum = (k) => mine.reduce((n, x) => n + (Number(x[k]) || 0), 0);
        return el('tr', [el('td', `${a.name} · ${net(a.network)}`), ...['impressions', 'clicks', 'reactions', 'comments', 'shares'].map((k) => el('td', { class: 'r' }, String(sum(k))))]);
      })),
    ]),
  ]);
}
