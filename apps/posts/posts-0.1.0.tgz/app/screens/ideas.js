// Ideas: what to write about. Yours (and what you told the agent in chat),
// and what the feeds bring (a blog, a newsletter, a changelog: Postiz's
// AutoPost). The weekly proposal takes the oldest first; Write it asks the
// agent now. A feed can also write a draft for each new item on its own.
import { A, C, T, accountSaid, accounts, act, ago, area, field, head, input, select, settings, short } from '../data.js';

const { el, router } = Orch;

export function render() {
  Orch.load('view', async () => {
    const s = await settings(true);
    const [ideas, used, feeds, list] = await Promise.all([
      Orch.db.list(T.ideas, { filter: { status: 'New' }, sort: '_id:desc', limit: 200 }),
      Orch.db.list(T.ideas, { filter: { status: ['Used', 'Dropped'] }, sort: '_id:desc', limit: 50 }),
      Orch.db.list(T.feeds, { sort: '_id:asc', limit: 50 }),
      accounts(),
    ]);
    const on = list.filter((a) => a.active === 'yes');
    const text = area('', 3, { maxlength: '2000', placeholder: 'A thought, a customer question, something you learned this week…' });
    const url = input('', { type: 'url', maxlength: '1000', placeholder: 'https://… (optional: the agent reads the page)' });
    const add = el('button', { type: 'submit', class: 'oc-btn oc-btn--primary' }, 'Add the idea');
    const form = el('form', { class: 'oc-card oc-stack po-form' }, [field('An idea', text), field('A link', url), el('div', { class: 'oc-row' }, add)]);
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      if (!String(text.value).trim()) { text.focus(); return; }
      if (url.value && !/^https?:\/\//i.test(url.value)) { Orch.toast('The link must start with https://', { error: true }); return; }
      add.disabled = true;
      if (await act(A.addIdea, { text: String(text.value).trim(), url: String(url.value).trim() || null }, 'Added.')) render();
      add.disabled = false;
    });
    const fromFeed = (i) => (feeds.rows || []).find((f) => f._id === i.feed_id);
    return el('div', { class: 'oc-stack oc-stack--loose' }, [
      head('Ideas', 'What to write about. The weekly proposal takes the oldest first; Write it asks the agent now.', null),
      form,
      el('section', { class: 'oc-stack' }, [
        el('h2', { class: 'oc-h2' }, `${(ideas.rows || []).length} not used yet`),
        (ideas.rows || []).length ? el('ul', { class: 'po-rows' }, ideas.rows.map((i) => el('li', { class: 'po-row po-row--static' }, [
          el('div', { class: 'po-row__open', style: 'cursor:default' }, [
            el('span', { class: 'po-row__first oc-value' }, i.source === 'feed' ? 'Feed' : i.source === 'agent' ? 'Agent' : 'You'),
            el('span', { class: 'po-row__name' }, [el('span', short(i.text, 140)), el('span', { class: 'po-row__sub' }, [i.url ? el('a', { href: i.url, target: '_blank', rel: 'noopener' }, short(i.url.replace(/^https?:\/\//, ''), 60)) : '', i.url ? ' · ' : '',
              i.source === 'feed' && fromFeed(i) ? `${fromFeed(i).title || fromFeed(i).url} · ` : '', ago(i._created_at)])]),
            el('span', { class: 'po-row__right' }, [
              on.length ? router.link(`/write/${i._id}`, 'Write it', { class: 'oc-btn oc-btn--sm' }) : null,
              el('button', { type: 'button', class: 'oc-btn oc-btn--sm oc-btn--ghost', onClick: async () => { if (await act(A.dropIdea, { id: i._id }, 'Dropped.')) render(); } }, 'Drop'),
            ]),
          ]),
        ]))) : el('p', { class: 'po-empty oc-card' }, 'No ideas waiting. The agent writes from your topics when there are none.'),
      ]),
      feedsSection(s, feeds.rows || [], on),
      (used.rows || []).length ? el('details', { class: 'po-details' }, [el('summary', `Used and dropped (${used.rows.length})`),
        el('ul', { class: 'po-mini' }, used.rows.map((i) => el('li', { class: 'oc-row' }, [el('span', { class: 'po-grow' }, `${i.status === 'Used' ? 'Used' : 'Dropped'} · ${short(i.text, 110)}`),
          i.status === 'Used' && i.post_id ? router.link(`/post/${i.post_id}`, 'The post', { class: 'oc-small' }) : null,
          i.status === 'Dropped' ? el('button', { type: 'button', class: 'po-linkish', onClick: async () => { if (await act(A.restoreIdea, { id: i._id })) render(); } }, 'Bring back') : null])))]) : null,
    ]);
  });
}

function feedsSection(s, feeds, on) {
  const url = input('', { type: 'url', maxlength: '1000', placeholder: 'https://yourblog.com/feed.xml' });
  const auto = el('input', { type: 'checkbox' });
  const acct = select(on[0] ? on[0]._id : '', on.map((a) => [a._id, accountSaid(a)]));
  const add = el('button', { type: 'submit', class: 'oc-btn' }, 'Follow the feed');
  const form = el('form', { class: 'oc-stack' }, [
    field('Feed address (RSS or Atom)', url, 'Your blog, a newsletter, your product\'s changelog, a Google Alert. Each new item becomes an idea.'),
    el('label', { class: 'po-check' }, [auto, el('span', 'Also ask the agent for a draft of each new item, for:')]), acct,
    el('div', { class: 'oc-row' }, add),
  ]);
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    if (!/^https?:\/\//i.test(url.value)) { url.focus(); Orch.toast('A feed address starts with https://', { error: true }); return; }
    add.disabled = true;
    if (await act(A.addFeed, { url: String(url.value).trim(), auto_draft: auto.checked ? 'yes' : 'no', account_id: acct.value ? Number(acct.value) : null, mode: '--feeds' }, 'Following it. Its newest items come in a minute.')) setTimeout(render, 5000);
    add.disabled = false;
  });
  const readNow = el('button', { type: 'button', class: 'oc-btn oc-btn--sm' }, 'Read the feeds now');
  readNow.addEventListener('click', async () => { readNow.disabled = true; if (await act(A.readFeeds, { mode: '--feeds' }, 'Reading them…')) setTimeout(render, 6000); });
  return el('section', { class: 'oc-stack' }, [
    el('div', { class: 'oc-row oc-row--between' }, [el('h2', { class: 'oc-h2' }, 'Feeds'), feeds.length ? readNow : null]),
    feeds.length ? el('ul', { class: 'po-rows' }, feeds.map((f) => el('li', { class: 'po-row po-row--static' }, el('div', { class: 'po-row__open', style: 'cursor:default' }, [
      el('span', { class: 'po-row__first oc-value' }, f.active === 'yes' ? (f.auto_draft === 'yes' ? 'Drafts' : 'Ideas') : 'Off'),
      el('span', { class: 'po-row__name' }, [el('span', f.title || f.url), el('span', { class: 'po-row__sub' }, [f.note ? el('span', { class: 'po-bad' }, f.note) : (f.checked_at ? `Read ${ago(f.checked_at)}` : 'Not read yet'), f.title ? ` · ${short(f.url, 60)}` : ''])]),
      el('span', { class: 'po-row__right' }, el('button', { type: 'button', class: 'oc-btn oc-btn--sm oc-btn--ghost', onClick: async () => { if (await act(A.updateFeed, { id: f._id, active: f.active === 'yes' ? 'no' : 'yes' })) render(); } }, f.active === 'yes' ? 'Stop' : 'Follow again')),
    ])))) : null,
    el('div', { class: 'oc-card po-form' }, form),
  ]);
}
