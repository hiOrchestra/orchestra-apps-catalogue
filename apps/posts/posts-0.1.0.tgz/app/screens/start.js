// Getting started: what the first week needs, checked from the data each
// time (never ticked by hand), gone once done or hidden. The steps follow
// listing.json's setup: a network connected and an account on, how you
// write, and the first week.
import { A, C, INTEGRATIONS, PORTAL, X_DOOR, act, area, field, input } from '../data.js';

const { el, router } = Orch;

export const accountsDone = (list) => list.some((a) => a.active === 'yes');
export const voiceDone = (s) => !!(String(s.voice || '').trim() || String(s.examples || '').trim());

export function startCard(s, again) {
  if (s.onboarding_dismissed_at) return null;
  const card = el('section', { class: 'oc-card oc-card--pad0 po-start', 'aria-label': 'Getting started' }, el('p', { class: 'po-start__lede oc-help' }, 'Looking…'));
  (async () => {
    const [accts, posts] = await Promise.all([Orch.db.list('po_accounts', { limit: 100 }), Orch.db.count('po_posts', {})]);
    const list = accts.rows || [];
    const steps = [
      { title: 'Your accounts', done: accountsDone(list), body: () => accountsStep(s, list, again) },
      { title: 'How you write', done: voiceDone(s), body: () => voiceStep(s, again) },
      { title: 'The first week', done: (Number(posts) || 0) > 0, body: () => weekStep(s, again) },
    ];
    if (steps.every((x) => x.done)) { card.remove(); return; }
    const open = steps.find((x) => !x.done);
    card.replaceChildren(...[
      el('div', { class: 'po-start__head' }, [el('h2', { class: 'oc-h2' }, 'Getting started'), el('span', { class: 'oc-value oc-muted' }, `${steps.filter((x) => x.done).length} of ${steps.length}`)]),
      el('p', { class: 'oc-help po-start__lede' }, 'Three things before the agent writes your first week. Nothing goes out without your approval.'),
      el('ol', { class: 'po-steps' }, steps.map((x, i) => el('li', { class: `po-step${x.done ? ' po-step--done' : ''}` }, [
        el('div', { class: 'po-step__head' }, [el('span', { class: 'oc-value po-step__n' }, String(i + 1).padStart(2, '0')), el('span', { class: 'po-step__title' }, x.title),
          el('span', { class: `oc-badge${x.done ? ' oc-badge--good' : ''}` }, x.done ? 'Done' : 'To do')]),
        x === open ? el('div', { class: 'po-step__body' }, x.body()) : null,
      ]))),
    ]);
  })().catch(() => card.remove());
  return card;
}

function accountsStep(s, list, again) {
  const look = el('button', { type: 'button', class: 'oc-btn oc-btn--primary' }, list.length ? 'Look again' : 'Look for accounts');
  look.addEventListener('click', async () => { look.disabled = true; look.textContent = 'Looking…'; if (await act(A.findAccounts, { id: s._id })) setTimeout(again, 8000); });
  return el('div', { class: 'oc-stack po-start__form' }, [
    el('p', { class: 'po-step__why' }, ['Connect where you post: LinkedIn (your profile and the company pages you run) and Facebook pages in ', PORTAL(INTEGRATIONS),
      ', X in ', PORTAL(X_DOOR), ' (with your own X keys: X charges about US$0.015 a post). Then look for the accounts here and turn on the ones Posts writes for.']),
    list.length ? el('ul', { class: 'po-mini' }, list.map((a) => el('li', { class: 'oc-row' }, [
      el('span', { class: 'po-grow' }, `${a.name} · ${C.netOf(a.network).kinds[a.kind] || a.kind} on ${C.netOf(a.network).name}`),
      el('button', { type: 'button', class: `oc-btn oc-btn--sm${a.active === 'yes' ? '' : ' oc-btn--primary'}`, onClick: async () => { if (await act(A.updateAccount, { id: a._id, active: a.active === 'yes' ? 'no' : 'yes' })) again(); } }, a.active === 'yes' ? 'Turn off' : 'Turn on'),
    ]))) : null,
    s.accounts_note ? el('p', { class: 'oc-help' }, s.accounts_note) : null,
    el('div', { class: 'oc-row' }, [look, router.link('/settings', 'Times and more in Settings', { class: 'oc-small' })]),
  ]);
}

function voiceStep(s, again) {
  const company = input(s.company_name, { maxlength: '160', placeholder: 'Lumen Studio' });
  const voice = area(s.voice, 3, { maxlength: '2000', placeholder: 'Direct and warm, first person, short sentences. We explain how we work; we never sell hard.' });
  const topics = area(s.topics, 3, { maxlength: '2000', placeholder: 'One per line: what we learn building X · behind the scenes · our customers\' questions' });
  const examples = area(s.examples, 5, { maxlength: '8000', placeholder: 'Paste two or three posts you liked, yours or not. Separate them with a line of ---' });
  const save = el('button', { type: 'submit', class: 'oc-btn oc-btn--primary' }, 'Save and continue');
  const f = el('form', { class: 'oc-stack po-start__form' }, [
    el('p', { class: 'po-step__why' }, 'The agent writes as you: how you sound, what you talk about, and a few posts to learn the tone from. You can change all of it in Settings.'),
    field('Company or brand', company), field('How you write', voice), field('What you talk about', topics), field('Posts to learn from', examples),
    el('div', { class: 'oc-row' }, save),
  ]);
  f.addEventListener('submit', async (e) => {
    e.preventDefault();
    if (!String(voice.value).trim() && !String(examples.value).trim()) { voice.focus(); Orch.toast('Write how you sound, or paste a post or two.', { error: true }); return; }
    save.disabled = true;
    if (await act(A.settings, { id: s._id, company_name: String(company.value).trim(), voice: String(voice.value).trim(), topics: String(topics.value).trim(), examples: String(examples.value).trim() }, 'Saved.')) again();
    save.disabled = false;
  });
  return f;
}

function weekStep(s, again) {
  const go = el('button', { type: 'button', class: 'oc-btn oc-btn--primary' }, 'Propose the week');
  go.addEventListener('click', async () => { go.disabled = true; go.textContent = 'Asking the agent…'; if (await act(A.proposeNow, { id: s._id, mode: '--propose' })) setTimeout(again, 4000); });
  return el('div', { class: 'oc-stack po-start__form' }, [
    el('p', { class: 'po-step__why' }, `Every ${C.DAYS[(Number(s.propose_day) || 1) - 1]} at ${s.propose_time || '08:00'} the agent writes ${s.propose_count || 3} posts for the free times of the week. Ask for the first week now; you review each one before it goes anywhere.`),
    el('div', { class: 'oc-row' }, [go, el('button', { type: 'button', class: 'po-linkish', onClick: async () => { if (await act(A.dismissStart, { id: s._id })) again(); } }, 'Hide this')]),
  ]);
}
