// The notes on a draft (Postiz's anchored comments): a quote of the text and
// what the person says about it. "Rewrite with my notes" sends the open ones
// to the agent; a rewrite resolves them. Resolve by hand when fixed by hand.
import { A, act, ago, area, sheet } from '../data.js';

const { el } = Orch;

/** Ask for a note on a quote; resolves to true when one was saved. */
export function addNote(post, sel) {
  return new Promise((resolve) => {
    const text = area('', 3, { maxlength: '1000', placeholder: 'What is wrong with it, or what you want instead' });
    const save = el('button', { type: 'submit', class: 'oc-btn oc-btn--primary' }, 'Add the note');
    const f = el('form', { class: 'oc-stack' }, [
      el('blockquote', { class: 'po-quote' }, `“${sel.quote}”`),
      text,
      el('div', { class: 'oc-row' }, save),
    ]);
    const d = sheet(f, { title: 'A note on this' });
    setTimeout(() => text.focus(), 50);
    f.addEventListener('submit', async (e) => {
      e.preventDefault();
      if (!String(text.value).trim()) { text.focus(); return; }
      save.disabled = true;
      const ok = await act(A.addNote, { post_id: post._id, quote: sel.quote, start: sel.start, end: sel.end, text: String(text.value).trim() }, 'Note added.');
      d.close();
      resolve(!!ok);
    });
  });
}

export function notesPanel(notes, { editable, again }) {
  const open = notes.filter((n) => !n.resolved_at);
  const closed = notes.filter((n) => n.resolved_at);
  if (!notes.length) return null;
  return el('section', { class: 'po-notes', 'aria-label': 'Notes' }, [
    el('h2', { class: 'oc-h3' }, open.length ? `${open.length} open note${open.length === 1 ? '' : 's'}` : 'Notes'),
    el('ul', { class: 'po-notes__list' }, [...open, ...closed].map((n) => el('li', { class: `po-note${n.resolved_at ? ' po-note--done' : ''}` }, [
      el('blockquote', { class: 'po-quote' }, `“${n.quote || ''}”`),
      el('p', n.text),
      el('div', { class: 'po-note__foot' }, [
        el('span', `${n.by === 'rewritten' ? 'Fixed in a rewrite' : n.by || ''}${n.resolved_at && n.by !== 'rewritten' ? ' · resolved' : ''} · ${ago(n._created_at)}`),
        editable && !n.resolved_at ? el('button', { type: 'button', class: 'po-linkish', onClick: async () => { if (await act(A.resolveNote, { id: n._id })) again(); } }, 'Resolve') : null,
      ]),
    ]))),
  ]);
}
