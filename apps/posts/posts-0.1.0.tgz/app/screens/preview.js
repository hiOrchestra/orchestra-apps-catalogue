// A post as its network shows it in the feed: who, the text up to "…see
// more" (it opens), and the person's open notes marked in it. Selecting a
// piece of the text offers a note on it (notes.js keeps them).
import { C } from '../data.js';

const { el } = Orch;

const MORE = { linkedin: '…see more', x: '', facebook: 'See more' };

/** The text with the quotes of open notes marked, as nodes. */
function marked(text, quotes) {
  const t = String(text || '');
  const spans = [];
  for (const q of quotes.filter(Boolean)) {
    const i = t.indexOf(q);
    if (i >= 0 && !spans.some(([a, b]) => i < b && i + q.length > a)) spans.push([i, i + q.length]);
  }
  spans.sort((a, b) => a[0] - b[0]);
  const out = [];
  let at = 0;
  for (const [a, b] of spans) { if (a > at) out.push(t.slice(at, a)); out.push(el('mark', { class: 'po-mark' }, t.slice(a, b))); at = b; }
  if (at < t.length) out.push(t.slice(at));
  return out;
}

/**
 * preview({ account, network, text, notes, onSelect }) → element.
 * onSelect({ quote, start, end }) is called when the person selects text in it.
 */
export function preview({ account, network, text, notes = [], onSelect }) {
  const n = network || (account && account.network) || 'linkedin';
  const name = (account && account.name) || 'No account yet';
  const who = account ? `${C.netOf(n).kinds[account.kind] || ''}${account.handle ? ` · ${n === 'x' ? '@' : ''}${account.handle}` : ''}` : '';
  const body = el('div', { class: 'po-pv__text' });
  const quotes = notes.filter((x) => !x.resolved_at).map((x) => x.quote);
  let open = false;
  const draw = () => {
    const f = C.folded(text, n);
    const nodes = open || !f.more ? marked(text, quotes) : marked(f.head, quotes);
    body.replaceChildren(...nodes, ...(f.more && !open && MORE[n] ? [el('button', { type: 'button', class: 'po-pv__more', onClick: () => { open = true; draw(); } }, MORE[n])] : []));
  };
  draw();
  if (onSelect) {
    body.addEventListener('mouseup', () => {
      const sel = window.getSelection();
      const q = sel ? String(sel).trim() : '';
      if (!q || q.length < 3 || !body.contains(sel.anchorNode)) return;
      const start = String(text || '').indexOf(q);
      onSelect({ quote: q.slice(0, 300), start: start >= 0 ? start : null, end: start >= 0 ? start + q.length : null });
    });
  }
  const empty = !String(text || '').trim();
  return el('figure', { class: `po-pv po-pv--${n}`, 'aria-label': `How it looks on ${C.netOf(n).name}` }, [
    el('div', { class: 'po-pv__head' }, [
      el('span', { class: 'po-pv__avatar', 'aria-hidden': 'true' }, name.trim().charAt(0).toUpperCase() || '?'),
      el('span', { class: 'po-pv__who' }, [el('span', { class: 'po-pv__name' }, name), el('span', { class: 'po-pv__sub' }, [who, who ? ' · ' : '', C.netOf(n).name])]),
    ]),
    empty ? el('p', { class: 'po-pv__empty' }, 'The text shows here as it will look.') : body,
    el('figcaption', { class: 'po-pv__foot' }, onSelect && !empty ? 'Select a piece of the text to leave a note on it.' : ''),
  ]);
}
