// Home: the next seven days. On top what waits for a person (drafts to
// review, posts that failed), then seven days from today (or from the day in
// the address): each day's posts at their times, and the
// free times of the accounts that are on (a free time opens a new post
// there). Propose the week asks the agent now instead of on Settings' day.
// While the agent writes, the page looks again on its own.
import { A, C, T, V, act, at, badge, dayName, head, net, netTag, settings, short, statusOf, tz } from '../data.js';
import { startCard } from './start.js';

const { el, router } = Orch;

export function render({ from } = {}) {
  Orch.load('view', async () => {
    const s = await settings(true);
    if (!s._id) return el('p', { class: 'oc-state' }, 'Posts is not installed in this project.');
    const today = C.local(new Date(), tz()).ymd;
    const first = /^\d{4}-\d{2}-\d{2}$/.test(from || '') ? from : today;
    const days = Array.from({ length: 7 }, (_, i) => C.addDays(first, i));
    const start = C.isoZ(C.zoned(first, '00:00', tz()));
    const end = C.isoZ(C.zoned(C.addDays(first, 7), '00:00', tz()));
    const [inWeek, review, writing, accts] = await Promise.all([
      Orch.db.view(V.posts, { filter: { publish_at: { gte: start, lt: end }, status: ['Writing', 'Draft', 'Scheduled', 'Publishing', 'Published', 'Failed'] }, sort: 'publish_at:asc', limit: 300 }),
      Orch.db.view(V.posts, { filter: { status: ['Draft', 'Failed'] }, sort: 'publish_at:asc', limit: 100 }),
      Orch.db.count(T.posts, { filter: { status: 'Writing' } }),
      Orch.db.list(T.accounts, { filter: { active: 'yes' }, sort: '_id:asc', limit: 50 }),
    ]);
    const posts = inWeek.rows || [];
    const busy = Number(writing) || 0;
    if (busy) setTimeout(() => { if (/^#\/?(week\/[\d-]+)?$/.test(location.hash) || location.hash === '') render({ from }); }, 10000);
    const propose = el('button', { type: 'button', class: 'oc-btn', onClick: async () => {
      if (!(accts.rows || []).length) { Orch.toast('Turn on an account in Settings first.', { error: true }); return; }
      propose.disabled = true; propose.textContent = 'Asking the agent…';
      if (await act(A.proposeNow, { id: s._id, mode: '--propose' })) setTimeout(() => render({ from }), 4000);
    } }, 'Propose the week');
    const nav = el('div', { class: 'po-weeknav' }, [
      router.link(`/week/${C.addDays(first, -7)}`, '← Earlier', { class: 'oc-btn oc-btn--sm oc-btn--ghost' }),
      first !== today ? router.link('/', 'Today', { class: 'oc-btn oc-btn--sm oc-btn--ghost' }) : null,
      router.link(`/week/${C.addDays(first, 7)}`, 'Later →', { class: 'oc-btn oc-btn--sm oc-btn--ghost' }),
    ]);
    return el('div', { class: 'oc-stack oc-stack--loose' }, [
      head(weekTitle(first, today), 'What goes out, where, and the free times. Nothing goes out without your approval.', [propose, router.link('/new', 'New post', { class: 'oc-btn oc-btn--primary' })]),
      s.rehearsal === 'yes' ? el('p', { class: 'po-warn', role: 'note' }, ['Rehearsal: approved posts are checked and marked at their time, but nothing goes to the networks. ', router.link('/settings', 'Turn it off in Settings'), ' when you are ready.']) : null,
      startCard(s, () => render({ from })),
      busy ? el('p', { class: 'po-warn', role: 'status' }, `The agent is writing ${busy} post${busy === 1 ? '' : 's'}… They appear here in a minute or two.`) : null,
      toReview(review.rows || []),
      el('section', { class: 'oc-stack' }, [el('div', { class: 'oc-row oc-row--between' }, [el('h2', { class: 'oc-h2' }, first === today ? 'The next 7 days' : `From ${dayName(first)}`), nav]),
        el('div', { class: 'po-week' }, days.map((d) => dayColumn(d, today, posts, accts.rows || [])))]),
    ]);
  });
}

function weekTitle(first, today) {
  if (first === today) return 'This week';
  return first < today ? 'Earlier' : 'Later';
}

function toReview(list) {
  if (!list.length) return null;
  return el('section', { class: 'oc-stack' }, [
    el('h2', { class: 'oc-h2' }, `${list.length} to review`),
    el('ul', { class: 'po-rows' }, list.map((p) => el('li', { class: 'po-row' }, router.link(`/post/${p._id}`, [
      el('span', { class: 'po-row__first oc-value' }, p.publish_at ? at(p.publish_at) : 'No time'),
      el('span', { class: 'po-row__name' }, [el('span', short(p.text || p.brief || '(empty)', 120)),
        el('span', { class: 'po-row__sub' }, [netTag(p.network), ` ${p.account_name || 'no account'}`, p.open_notes ? ` · ${p.open_notes} note${p.open_notes === 1 ? '' : 's'}` : '', p.status === 'Failed' && p.error ? ` · ${short(p.error, 90)}` : ''])]),
      el('span', { class: 'po-row__right' }, badge(statusOf(p))),
    ], { class: 'po-row__open' })))),
  ]);
}

function dayColumn(ymd, today, posts, accts) {
  const mine = posts.filter((p) => C.local(new Date(p.publish_at), tz()).ymd === ymd);
  const items = mine.map((p) => ({ hm: C.local(new Date(p.publish_at), tz()).hm, node: card(p) }));
  // The free times of the accounts that are on, still ahead.
  for (const a of accts) {
    for (const sl of C.slotsOf(a.slots).filter((x) => x.d === C.dowOf(ymd))) {
      const iso = C.isoZ(C.zoned(ymd, sl.t, tz()));
      if (new Date(iso).getTime() < Date.now() + 60000) continue;
      if (mine.some((p) => p.account_id === a._id && C.isoZ(p.publish_at) === iso)) continue;
      items.push({ hm: sl.t, node: router.link(`/new/${a._id}/${encodeURIComponent(iso)}`, [el('span', { class: 'oc-value' }, sl.t), el('span', ` ${a.name} · ${net(a.network)}`)], { class: 'po-free', title: 'A free time: write a post for it' }) });
    }
  }
  items.sort((x, y) => x.hm.localeCompare(y.hm));
  return el('section', { class: `po-day${ymd === today ? ' po-day--today' : ''}${ymd < today ? ' po-day--past' : ''}`, 'aria-label': dayName(ymd) }, [
    el('h3', { class: 'po-day__name' }, dayName(ymd)),
    items.length ? el('div', { class: 'po-day__items' }, items.map((x) => x.node)) : el('p', { class: 'po-day__none' }, 'Nothing'),
  ]);
}

function card(p) {
  const st = statusOf(p);
  return router.link(`/post/${p._id}`, [
    el('span', { class: 'po-card__top' }, [el('span', { class: 'oc-value' }, at(p.publish_at, { day: false })), netTag(p.network), badge(st)]),
    el('span', { class: 'po-card__who' }, p.account_name || '—'),
    el('span', { class: 'po-card__text' }, short(p.text || (p.status === 'Writing' ? 'The agent is writing it…' : p.brief) || '', 110)),
  ], { class: `po-card po-card--${st.toLowerCase()}` });
}
