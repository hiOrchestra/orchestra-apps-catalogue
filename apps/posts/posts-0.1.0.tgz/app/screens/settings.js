// Settings: the company and language, how you write (the agent's voice),
// the signature, the weekly proposal, the accounts and their times
// (accounts.js), rehearsal, templates and Telegram. One form per section;
// rehearsal has its own two-step control, since turning it off is what lets
// posts reach real people.
import { A, C, accounts, act, area, field, head, input, select, settings, sheet } from '../data.js';
import { accountsSection } from './accounts.js';

const { el } = Orch;
const ZONES = ['Europe/Madrid', 'Europe/London', 'Europe/Lisbon', 'Europe/Paris', 'Europe/Berlin', 'America/New_York', 'America/Chicago', 'America/Los_Angeles',
  'America/Mexico_City', 'America/Bogota', 'America/Lima', 'America/Santiago', 'America/Argentina/Buenos_Aires', 'America/Sao_Paulo', 'UTC'];

export function render() {
  Orch.load('view', async () => {
    const s = await settings(true);
    const [list, tpls] = await Promise.all([accounts(), Orch.db.list('po_templates', { sort: '_id:asc', limit: 100 })]);
    const again = () => render();
    const c = {
      company_name: input(s.company_name, { maxlength: '160' }),
      language: select(C.langOf(s.language), [['es', 'Español'], ['en', 'English']]),
      timezone: select(s.timezone || 'Europe/Madrid', [...new Set([s.timezone || 'Europe/Madrid', ...ZONES])].map((z) => [z, z])),
      voice: area(s.voice, 3, { maxlength: '2000' }),
      topics: area(s.topics, 4, { maxlength: '2000' }),
      examples: area(s.examples, 6, { maxlength: '8000', placeholder: 'Two or three posts to learn the tone from, separated by a line of ---' }),
      avoid: area(s.avoid, 2, { maxlength: '1000', placeholder: 'Words, topics or habits the agent never uses: emoji walls, "game changer", politics…' }),
      signature: area(s.signature, 2, { maxlength: '400', placeholder: 'Follow me for more on…' }),
      signature_auto: select(s.signature_auto === 'yes' ? 'yes' : 'no', [['no', 'No: the agent may use it'], ['yes', 'Yes: added under every post']]),
      propose_day: select(Number(s.propose_day) || 1, C.DAYS.map((d, i) => [i + 1, d])),
      propose_time: input(s.propose_time || '08:00', { type: 'time' }),
      propose_count: input(s.propose_count == null ? 3 : s.propose_count, { type: 'number', min: '0', max: '14' }),
      notify_telegram: input(s.notify_telegram, { maxlength: '40', placeholder: '@channel or chat id' }),
    };
    const save = el('button', { type: 'submit', class: 'oc-btn oc-btn--primary' }, 'Save');
    const f = el('form', { class: 'oc-stack oc-stack--loose' }, [
      el('section', { class: 'oc-card oc-stack po-form' }, [el('h2', { class: 'oc-h2' }, 'Your company'),
        el('div', { class: 'po-three' }, [field('Company or brand', c.company_name), field('Posts written in', c.language), field('Time zone', c.timezone, 'Posting times and the proposal are in it.')])]),
      el('section', { class: 'oc-card oc-stack po-form' }, [el('h2', { class: 'oc-h2' }, 'How you write'),
        field('Your voice', c.voice, 'How you sound: person, tone, sentence length, what you never do.'),
        field('What you talk about', c.topics, 'One per line. Without ideas, the agent writes about these.'),
        field('Posts to learn from', c.examples),
        field('Never', c.avoid)]),
      el('section', { class: 'oc-card oc-stack po-form' }, [el('h2', { class: 'oc-h2' }, 'Signature'),
        el('div', { class: 'po-two' }, [field('The signature', c.signature), field('Add it on its own', c.signature_auto, 'Added when the post goes out, so drafts stay short.')])]),
      el('section', { class: 'oc-card oc-stack po-form' }, [el('h2', { class: 'oc-h2' }, 'The weekly proposal'),
        el('p', { class: 'oc-help' }, 'Once a week the agent writes posts for the free times of the next 7 days, from your ideas first. They wait for your approval.'),
        el('div', { class: 'po-three' }, [field('Day', c.propose_day), field('At', c.propose_time), field('How many', c.propose_count, '0 turns it off.')])]),
      el('section', { class: 'oc-card oc-stack po-form' }, [el('h2', { class: 'oc-h2' }, 'Telegram'), field('Tell me when a post goes out or fails', c.notify_telegram, 'Optional.')]),
      el('div', { class: 'oc-row' }, save),
    ]);
    f.addEventListener('submit', async (e) => {
      e.preventDefault();
      if (!C.HM.test(c.propose_time.value)) { c.propose_time.focus(); return; }
      save.disabled = true;
      const p = { id: s._id };
      for (const [k, n] of Object.entries(c)) p[k] = String(n.value).trim();
      p.propose_day = Number(p.propose_day);
      p.propose_count = Math.max(0, Math.min(14, Math.round(Number(p.propose_count) || 0)));
      if (await act(A.settings, p, 'Saved.')) again();
      save.disabled = false;
    });
    return el('div', { class: 'oc-stack oc-stack--loose' }, [
      head('Settings', 'How the agent writes, where posts go and when.', null),
      rehearsal(s, list, again),
      accountsSection(s, list, again),
      f,
      templates((tpls.rows || []).filter((t) => t.dropped !== 'yes'), again),
    ]);
  });
}

function rehearsal(s, list, again) {
  const on = s.rehearsal === 'yes';
  const live = list.filter((a) => a.active === 'yes');
  const b = el('button', { type: 'button', class: `oc-btn${on ? ' oc-btn--primary' : ''}` }, on ? 'Turn rehearsal off…' : 'Back to rehearsal');
  b.addEventListener('click', async () => {
    if (!on) { if (await act(A.rehearsal, { id: s._id, rehearsal: 'yes' }, 'Rehearsal is on: nothing goes out.')) again(); return; }
    // Two steps: the second names who will start posting for real, and stays off until acknowledged.
    const ack = el('input', { type: 'checkbox' });
    const go = el('button', { type: 'button', class: 'oc-btn oc-btn--primary', disabled: true }, 'Turn it off');
    ack.addEventListener('change', () => { go.disabled = !ack.checked; });
    const body = el('div', { class: 'oc-stack' }, [
      el('p', 'From now on, every approved post goes out at its time, for everyone to see:'),
      live.length ? el('ul', { class: 'po-mini' }, live.map((a) => el('li', `${a.name} · ${C.netOf(a.network).kinds[a.kind] || a.kind} on ${C.netOf(a.network).name}`))) : el('p', { class: 'po-bad' }, 'No account is on yet.'),
      el('label', { class: 'po-check' }, [ack, el('span', 'I understand: approved posts will be published on these accounts.')]),
      el('div', { class: 'oc-row' }, go),
    ]);
    const d = sheet(body, { title: 'Turn rehearsal off?' });
    go.addEventListener('click', async () => { go.disabled = true; const ok = await act(A.rehearsal, { id: s._id, rehearsal: 'no' }, 'Rehearsal is off: approved posts go out at their time.'); d.close(); if (ok) again(); });
  });
  return el('section', { class: `oc-card oc-stack po-form${on ? ' po-rehearsal' : ''}` }, [
    el('div', { class: 'oc-row oc-row--between' }, [el('h2', { class: 'oc-h2' }, on ? 'Rehearsal is on' : 'Live'), b]),
    el('p', { class: 'oc-help' }, on ? 'Approved posts are checked and marked at their time, but nothing goes to any network. Try the whole week this way, then turn it off.'
      : 'Approved posts go out at their time. Back to rehearsal stops that at once; what was already published stays.'),
  ]);
}

function templates(list, again) {
  const name = input('', { maxlength: '80', placeholder: 'Lesson learned' });
  const body = area('', 4, { maxlength: '3000' });
  const add = el('button', { type: 'submit', class: 'oc-btn' }, 'Add the template');
  const f = el('form', { class: 'oc-stack' }, [el('div', { class: 'po-two' }, [field('Name', name), field('The shape', body)]), el('div', { class: 'oc-row' }, add)]);
  f.addEventListener('submit', async (e) => {
    e.preventDefault();
    if (!String(name.value).trim() || !String(body.value).trim()) return;
    add.disabled = true;
    if (await act(A.addTemplate, { name: String(name.value).trim(), body: String(body.value) }, 'Added.')) again();
    add.disabled = false;
  });
  return el('section', { class: 'oc-card oc-stack po-form' }, [
    el('h2', { class: 'oc-h2' }, 'Templates'),
    el('p', { class: 'oc-help' }, 'Shapes a post can follow. The agent fills them in completely; you can start from one when you write yourself.'),
    list.length ? el('ul', { class: 'po-mini' }, list.map((t) => el('li', { class: 'oc-row' }, [el('span', { class: 'po-grow' }, t.name),
      el('button', { type: 'button', class: 'po-linkish', onClick: async () => { if (await Orch.confirm(`Remove the template "${t.name}"? Posts written with it stay as they are.`, { yes: 'Remove' }) && await act(A.updateTemplate, { id: t._id, dropped: 'yes' }, 'Removed.')) again(); } }, 'Remove')]))) : null,
    f,
  ]);
}
