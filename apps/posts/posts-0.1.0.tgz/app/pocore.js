/**
 * Posts · what the desk and the scripts must agree on: the networks and their
 * limits, the posting times of an account (days and local hours, Postiz's
 * postingTimes), the next free slot, time in the workspace's zone, the
 * signature, the "…see more" fold, what an agent's draft may be, and a
 * post's link. Pure functions, no database, no DOM. test/sync.js copies it
 * to app/ and automations/.
 */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.PoCore = api;
}(typeof self !== 'undefined' ? self : this, () => {
  'use strict';

  const langOf = (v) => (v === 'en' ? 'en' : 'es');
  /**
   * The networks Posts publishes to (read live on staging 2026-10-10).
   * LinkedIn and Facebook through Composio; X through the `twitter` skill and
   * the account's own keys (Integrations → X), because Composio cannot
   * connect X. Text only for now: none of them takes our own image bytes.
   *   via     composio toolkit, or skill
   *   kinds   who an account is on that network
   *   limit   characters of a post (X counts its own way: the skill checks);
   *   fold    what shows before "…see more"; cost: what X charges per post
   */
  const NETWORKS = {
    linkedin: { name: 'LinkedIn', via: 'composio', toolkit: 'linkedin', limit: 3000, fold: 210, kinds: { person: 'Profile', organization: 'Company page' } },
    x: { name: 'X', via: 'skill', skill: 'twitter', limit: 280, fold: 280, kinds: { account: 'Account' }, cost: { post: 0.015, link: 0.2 } },
    facebook: { name: 'Facebook', via: 'composio', toolkit: 'facebook', limit: 63206, fold: 480, kinds: { page: 'Page' } },
  };
  const netOf = (n) => NETWORKS[n] || NETWORKS.linkedin;
  const LIMIT = NETWORKS.linkedin.limit;
  const FOLD = NETWORKS.linkedin.fold;
  const URN = /^urn:li:(person|organization):[A-Za-z0-9_-]+$/;
  const POST_URN = /urn:li:(?:share|ugcPost|activity):\d+/;
  const kindOf = (urn) => ((String(urn || '').match(URN) || [])[1] || '');
  /** The post on its network. */
  function postUrl(network, ref) {
    const r = String(ref || '');
    if (network === 'x') return /^\d{5,25}$/.test(r) ? `https://x.com/i/web/status/${r}` : '';
    if (network === 'facebook') return /^\d+_\d+$/.test(r) ? `https://www.facebook.com/${r.replace('_', '/posts/')}` : '';
    return POST_URN.test(r) ? `https://www.linkedin.com/feed/update/${r.match(POST_URN)[0]}/` : '';
  }

  // ── time in the workspace's zone ───────────────────────────────────────
  const DAYS = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  const DAYS_ES = ['lun', 'mar', 'mié', 'jue', 'vie', 'sáb', 'dom'];
  function zoneOk(tz) { try { new Intl.DateTimeFormat('en', { timeZone: tz }); return true; } catch { return false; } }
  /** A moment's wall clock in a zone: { y, m, d, hh, mm, dow (1 = Monday), ymd, hm }. */
  function local(date, tz) {
    const p = Object.fromEntries(new Intl.DateTimeFormat('en-US', { timeZone: zoneOk(tz) ? tz : 'UTC', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', weekday: 'short', hourCycle: 'h23' })
      .formatToParts(date).map((x) => [x.type, x.value]));
    const out = { y: +p.year, m: +p.month, d: +p.day, hh: +p.hour % 24, mm: +p.minute, dow: DAYS.indexOf(p.weekday) + 1 };
    out.ymd = `${p.year}-${p.month}-${p.day}`;
    out.hm = `${String(out.hh).padStart(2, '0')}:${p.minute}`;
    return out;
  }
  /** The moment a wall clock ('YYYY-MM-DD', 'HH:MM') in a zone stands for. */
  function zoned(ymd, hm, tz) {
    const [y, m, d] = ymd.split('-').map(Number);
    const [hh, mm] = hm.split(':').map(Number);
    let t = Date.UTC(y, m - 1, d, hh, mm);
    for (let i = 0; i < 3; i += 1) {
      const l = local(new Date(t), tz);
      const diff = Date.UTC(l.y, l.m - 1, l.d, l.hh, l.mm) - Date.UTC(y, m - 1, d, hh, mm);
      if (!diff) break;
      t -= diff;
    }
    return new Date(t);
  }
  const addDays = (ymd, n) => { const t = new Date(`${ymd}T12:00:00Z`); t.setUTCDate(t.getUTCDate() + n); return t.toISOString().slice(0, 10); };
  /** The Monday of the week a day is in. */
  const monday = (ymd) => { const t = new Date(`${ymd}T12:00:00Z`); return addDays(ymd, -((t.getUTCDay() + 6) % 7)); };
  const dowOf = (ymd) => ((new Date(`${ymd}T12:00:00Z`).getUTCDay() + 6) % 7) + 1;
  const isoZ = (d) => `${new Date(d).toISOString().slice(0, 16)}:00Z`;
  const HM = /^([01]\d|2[0-3]):[0-5]\d$/;

  // ── an account's posting times ─────────────────────────────────────────
  /** Weekdays at 09:00: a sane start; each account changes its own. */
  const DEFAULT_SLOTS = [1, 2, 3, 4, 5].map((d) => ({ d, t: '09:00' }));
  /** An account's slots as [{ d: 1..7 (Monday 1), t: 'HH:MM' }], sorted, without repeats. */
  function slotsOf(text) {
    let list = text;
    if (typeof text === 'string') { try { list = JSON.parse(text); } catch { list = null; } }
    if (!Array.isArray(list)) return [];
    const seen = new Set();
    return list.map((x) => ({ d: Number(x && x.d), t: String((x && x.t) || '') }))
      .filter((x) => x.d >= 1 && x.d <= 7 && HM.test(x.t) && !seen.has(`${x.d} ${x.t}`) && seen.add(`${x.d} ${x.t}`))
      .sort((a, b) => a.d - b.d || a.t.localeCompare(b.t));
  }
  /** Slots from the form: the days ticked × the times written ("09:00, 13:30"). */
  function slotsFrom(days, times) {
    const ts = String(times || '').split(/[\s,;]+/).map((x) => x.trim().replace(/^(\d):/, '0$1:')).filter((x) => HM.test(x));
    return slotsOf(days.flatMap((d) => ts.map((t) => ({ d, t }))));
  }
  /** "Mon–Fri 09:00" and the like, for a row. */
  function slotsSaid(slots, lang) {
    const list = slotsOf(slots);
    if (!list.length) return lang === 'es' ? 'sin horarios' : 'no times';
    const names = lang === 'es' ? DAYS_ES : DAYS;
    const byTime = {};
    for (const s of list) (byTime[s.t] = byTime[s.t] || []).push(s.d);
    const days = (ds) => {
      const out = [];
      for (let i = 0; i < ds.length; i += 1) {
        let j = i;
        while (j + 1 < ds.length && ds[j + 1] === ds[j] + 1) j += 1;
        out.push(j - i >= 2 ? `${names[ds[i] - 1]}–${names[ds[j] - 1]}` : ds.slice(i, j + 1).map((x) => names[x - 1]).join(', '));
        i = j;
      }
      return out.join(', ');
    };
    return Object.entries(byTime).map(([t, ds]) => `${days(ds)} ${t}`).join(' · ');
  }
  /**
   * The next free moments of an account, from `from` on: its slots in the
   * zone, minus the times already taken (ISO strings, compared to the
   * minute). [ISO …], at most `count`, looking `days` ahead.
   */
  function freeSlots({ slots, taken = [], tz, from = new Date(), count = 1, days = 28 }) {
    const list = slotsOf(slots);
    if (!list.length) return [];
    const busy = new Set(taken.filter(Boolean).map((x) => isoZ(x)));
    const out = [];
    const start = local(from, tz).ymd;
    for (let i = 0; i < days && out.length < count; i += 1) {
      const ymd = addDays(start, i);
      for (const s of list.filter((x) => x.d === dowOf(ymd))) {
        const at = zoned(ymd, s.t, tz);
        if (at.getTime() <= from.getTime() + 60000) continue;
        const z = isoZ(at);
        if (busy.has(z)) continue;
        out.push(z);
        if (out.length >= count) break;
      }
    }
    return out;
  }

  // ── the text ───────────────────────────────────────────────────────────
  /** The text that goes out: the signature after a blank line, when it goes on its own and is not there yet. */
  function finalText(text, s) {
    const t = String(text || '').trim();
    const sig = String((s && s.signature) || '').trim();
    if (!sig || !s || s.signature_auto !== 'yes' || t.endsWith(sig)) return t;
    return `${t}\n\n${sig}`;
  }
  /** What shows before "…see more": the network's fold, or three lines. */
  function folded(text, network) {
    const FOLD = netOf(network).fold;
    const t = String(text || '');
    const lines = t.split('\n');
    const byLines = lines.length > 3 ? lines.slice(0, 3).join('\n').length : t.length;
    if (byLines <= FOLD && byLines < t.length) return { head: t.slice(0, byLines), more: true };
    if (t.length <= FOLD) return { head: t, more: false };
    // Cut by characters: not in the middle of a word.
    return { head: t.slice(0, FOLD).replace(/\s+\S*$/, ''), more: true };
  }
  /** Something left to fill in: [a word] (not an @[mention](urn…)), {{x}}, a line of only "…", lorem ipsum. */
  const PLACEHOLDER = /(?<!@)\[[^\]\n]{1,40}\](?!\(urn:li:)|\{\{|^\s*(?:…|\.\.\.)\s*$|lorem ipsum/im;
  /**
   * An agent's draft, cleaned, or why it is refused: { ok, text } / { ok: false, why }.
   * Quotes around it go; a placeholder, an empty text or one over the limit is refused.
   */
  function checkDraft(raw, network) {
    const LIMIT = netOf(network).limit;
    let t = String(raw == null ? '' : raw).replace(/\r\n/g, '\n').trim();
    if (/^["“«].*["”»]$/s.test(t)) t = t.slice(1, -1).trim();
    t = t.replace(/\n{3,}/g, '\n\n');
    if (t.length < 40) return { ok: false, why: 'too short or empty' };
    if (t.length > LIMIT) return { ok: false, why: `over ${LIMIT} characters (${t.length})` };
    if (PLACEHOLDER.test(t)) return { ok: false, why: 'it has a placeholder to fill in' };
    return { ok: true, text: t };
  }
  /** What the agent answers: one object per post it was given. */
  const ANSWER = '{"items":[{"id":<id>,"text":"the post, ready to publish","note":"one line: what it is about and why now"}]}';
  /** How each network reads, for the agent. */
  const STYLE = {
    linkedin: 'LinkedIn: a first line that makes people click "…see more" (about 200 characters show), short paragraphs, one idea, plain words, at most 3 hashtags at the end, no emoji walls. Up to 3000 characters; most good posts are 600-1300.',
    x: 'X: one post of at most 280 characters (a link counts as 23), the point in the first words, no hashtags unless one really helps. A link makes the post cost US$0.20 instead of US$0.015: leave it out unless it is the point.',
    facebook: 'A Facebook page: friendly and short (most good posts are under 500 characters), one clear thing to do or know, a link when there is one.',
  };

  // ── the words of a status ──────────────────────────────────────────────
  const STATUS = ['Writing', 'Draft', 'Scheduled', 'Publishing', 'Published', 'Failed', 'Dropped'];

  return {
    langOf, NETWORKS, netOf, STYLE, LIMIT, FOLD, URN, POST_URN, kindOf, postUrl, DAYS, DAYS_ES, zoneOk, local, zoned, addDays, monday, dowOf, isoZ, HM,
    DEFAULT_SLOTS, slotsOf, slotsFrom, slotsSaid, freeSlots, finalText, folded, checkDraft, ANSWER, STATUS,
  };
}));
