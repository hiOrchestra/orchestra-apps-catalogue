// What the desk reads, the only things it writes, and what the screens share.
// Posts are written by the agent and published on the instance (write.js,
// publish.js), never here. pocore.js holds the rules the scripts share:
// networks, posting times, the fold, what a draft may be.
import './pocore.js';

export const C = self.PoCore;
const { el } = Orch;

export const T = { settings: 'po_settings', accounts: 'po_accounts', ideas: 'po_ideas', feeds: 'po_feeds', posts: 'po_posts', notes: 'po_notes', templates: 'po_templates', stats: 'po_stats' };
export const V = { posts: 'posts' };
export const A = {
  newPost: 'new_post', writePost: 'write_post', saveDraft: 'save_draft', saveScheduled: 'save_scheduled', approve: 'approve_post', unschedule: 'unschedule_post',
  publishNow: 'publish_now', rewrite: 'rewrite_post', drop: 'drop_post', retry: 'retry_post', rewriteFailed: 'rewrite_failed', addNote: 'add_note', resolveNote: 'resolve_note',
  addIdea: 'add_idea', dropIdea: 'drop_idea', restoreIdea: 'restore_idea', addFeed: 'add_feed', updateFeed: 'update_feed', readFeeds: 'read_feeds',
  addTemplate: 'add_template', updateTemplate: 'update_template', settings: 'update_settings', rehearsal: 'set_rehearsal', proposeNow: 'propose_now',
  findAccounts: 'find_accounts', updateAccount: 'update_account', dismissStart: 'dismiss_start',
};

const PORTAL_ORIGIN = (() => {
  try {
    const o = document.referrer ? new URL(document.referrer).origin : '';
    if (/^https:\/\/([a-z0-9-]+\.)*(hiorchestra\.com|orchestra-portal[a-z0-9-]*\.up\.railway\.app)$/.test(o)) return o;
  } catch { /* no referrer */ }
  return 'https://hiorchestra.com';
})();
export const PORTAL = (p) => el('a', { href: `${PORTAL_ORIGIN}/portal/${p[0]}`, target: '_top', rel: 'noopener' }, p[1]);
export const INTEGRATIONS = ['integrations', 'Integrations'];
export const X_DOOR = ['integrations/x', 'Integrations → X'];
export const FILES = ['files', 'Files'];

export async function act(name, params, done) {
  try {
    const r = await Orch.action(name, params);
    if (done) Orch.toast(done);
    return r || {};
  } catch (e) {
    Orch.toast(e.status === 409 ? 'It changed in the meantime: look again.' : (e.message || 'That did not work.'), { error: true });
    return null;
  }
}

let cached = null;
export async function settings(fresh) {
  if (!cached || fresh) cached = (await Orch.db.list(T.settings, { sort: '_id:asc', limit: 1 })).rows[0] || {};
  return cached;
}
export const tz = () => (cached && C.zoneOk(cached.timezone) ? cached.timezone : 'UTC');
export async function accounts() { return (await Orch.db.list(T.accounts, { sort: '_id:asc', limit: 100 })).rows || []; }

// The desk speaks English; the posts' own language is Settings' (the agent writes in it).
const LOCALE = () => 'en-GB';
export const when = (v) => { if (!v) return null; const s = String(v).trim(); const d = new Date(/[zZ]|[+-]\d\d:?\d\d$/.test(s) ? s : `${s.replace(' ', 'T')}Z`); return Number.isNaN(d.getTime()) ? null : d; };
export const ago = (v) => { const d = when(v); return d ? Orch.fmt.ago(d.toISOString()) : ''; };
/** "Tue 14 Oct, 09:00" in the workspace's zone. */
export function at(v, { day = true } = {}) {
  const d = when(v);
  if (!d) return '—';
  const o = { timeZone: tz(), hour: '2-digit', minute: '2-digit', hourCycle: 'h23' };
  if (day) Object.assign(o, { weekday: 'short', day: 'numeric', month: 'short' });
  return new Intl.DateTimeFormat(LOCALE(), o).format(d);
}
export const dayName = (ymd) => new Intl.DateTimeFormat(LOCALE(), { weekday: 'long', day: 'numeric', month: 'short', timeZone: 'UTC' }).format(new Date(`${ymd}T12:00:00Z`));
export const net = (n) => C.netOf(n).name;
export const accountSaid = (a) => (a ? `${a.name} · ${C.netOf(a.network).kinds[a.kind] || a.kind} on ${net(a.network)}` : 'No account');
export const short = (t, n = 90) => { const s = String(t || '').replace(/\s+/g, ' ').trim(); return s.length > n ? `${s.slice(0, n - 1)}…` : s; };

const TONE = { Draft: 'accent', Scheduled: 'good', Published: 'good', Failed: 'bad', Writing: '', Publishing: 'accent', Dropped: '', Rehearsed: '' };
const SAID = { Draft: 'To review', Writing: 'Writing…', Publishing: 'Going out…' };
export const statusOf = (p) => (p.status === 'Published' && p.rehearsed === 'yes' ? 'Rehearsed' : p.status);
export const badge = (state, said) => el('span', { class: `oc-badge${TONE[state] ? ` oc-badge--${TONE[state]}` : ''}` }, said || SAID[state] || state || '—');
export const netTag = (n) => el('span', { class: `po-net po-net--${n}` }, net(n));

export function sheet(content, opts) {
  const d = Orch.dialog(content, opts);
  window.addEventListener('hashchange', () => { try { d.close(); } catch { /* closed */ } }, { once: true });
  return d;
}
export const head = (title, lede, tools) => el('header', { class: 'po-head' }, [
  el('div', { class: 'po-head__title' }, [el('h1', { class: 'oc-h1 oc-h1--collection' }, title), lede ? el('p', { class: 'oc-lede' }, lede) : null]),
  tools ? el('div', { class: 'po-head__tools' }, tools) : null,
]);
export const input = (value, attrs) => el('input', Object.assign({ class: 'oc-input', value: value == null ? '' : String(value) }, attrs || {}));
export const area = (value, rows, attrs) => el('textarea', Object.assign({ class: 'oc-textarea', rows: String(rows || 3) }, attrs || {}), value == null ? '' : String(value));
export const field = (label, control, help) => el('label', { class: 'oc-field' }, [el('span', { class: 'oc-label' }, label), control, help ? el('span', { class: 'oc-help' }, help) : null]);
export const select = (value, options) => el('select', { class: 'oc-select' }, options.map(([v, label]) => el('option', { value: v, selected: String(v) === String(value) }, label)));

export function row({ to, first, name, sub, right }) {
  const inner = [el('span', { class: 'po-row__first oc-value' }, first || ''), el('span', { class: 'po-row__name' }, [el('span', name || '—'), sub ? el('span', { class: 'po-row__sub' }, sub) : null]),
    el('span', { class: 'po-row__right' }, right || '')];
  return el('li', { class: 'po-row' }, Orch.router.link(to, inner, { class: 'po-row__open' }));
}

/** The taken times of an account (anything not dropped or failed), for the next free slot. */
export async function takenOf(accountId, except) {
  const r = await Orch.db.list(T.posts, { filter: { account_id: Number(accountId), status: ['Writing', 'Draft', 'Scheduled', 'Publishing'] }, limit: 500 });
  return (r.rows || []).filter((p) => p._id !== except && p.publish_at).map((p) => p.publish_at);
}
/** A wall-clock 'YYYY-MM-DDTHH:MM' (an input) in the workspace's zone → ISO, and back. */
export const fromInput = (v) => { const m = String(v || '').match(/^(\d{4}-\d{2}-\d{2})T(\d{2}:\d{2})/); return m ? C.isoZ(C.zoned(m[1], m[2], tz())) : null; };
export const toInput = (iso) => { const d = when(iso); if (!d) return ''; const l = C.local(d, tz()); return `${l.ymd}T${l.hm}`; };
