// The router and the bar. Week is home: what goes out in the next days and
// where, what waits for review, and the free times. A post opens on its own
// page, its preview beside the editor. Ideas holds what to write about and
// the feeds; Published is what went out and how it did.
import { render as week } from './screens/week.js';
import { render as post } from './screens/post.js';
import { render as ideas } from './screens/ideas.js';
import { render as done } from './screens/done.js';
import { render as settings } from './screens/settings.js';

const { el, router } = Orch;

router.define({
  '/': week,
  '/week/:from': week,
  '/post/:id': post,
  '/new': (p, path) => post({ fresh: true }, path),
  '/new/:account/:at': (p, path) => post(Object.assign({ fresh: true }, p), path),
  '/write/:idea': (p, path) => post(Object.assign({ fresh: true }, p), path),
  '/ideas': ideas,
  '/published': done,
  '/settings': settings,
}, () => Orch.mount('view', el('div', { class: 'oc-state' }, [
  el('p', 'There is no screen here.'), router.link('/', 'Go to the week'),
]))).start();

Orch.mount('nav', [
  router.link('/', 'Week', { class: 'oc-tab' }),
  router.link('/ideas', 'Ideas', { class: 'oc-tab' }),
  router.link('/published', 'Published', { class: 'oc-tab' }),
  router.link('/settings', 'Settings', { class: 'oc-tab' }),
]);
