// Ideas: what to write about. Yours (and what you told the agent in chat),
// and what the feeds bring (a blog, a newsletter, a changelog: Postiz's
// AutoPost). The weekly proposal takes the oldest first; Write it asks the
// agent now. A feed can also write a draft for each new item on its own.
import { A, C, T, accountSaid, accounts, act, ago, area, field, head, input, pillars, select, settings, sheet, short } from '../data.js';

const { el, router } = Orch;

export function render() {
  Orch.load('view', async () => {
    const s = await settings(true);
    const [ideas, used, feeds, list, allPillars, material] = await Promise.all([
      Orch.db.list(T.ideas, { filter: { status: 'New' }, sort: '_id:desc', limit: 200 }),
      Orch.db.list(T.ideas, { filter: { status: ['Used', 'Dropped'] }, sort: '_id:desc', limit: 50 }),
      Orch.db.list(T.feeds, { sort: '_id:asc', limit: 50 }),
      accounts(),
      pillars(),
      Orch.db.list(T.ideas, { filter: { status: 'Material' }, sort: '_id:desc', limit: 100 }),
    ]);
    const on = list.filter((a) => a.active === 'yes');
    const livePillars = allPillars.filter((p) => p.active !== 'no');
    const pillarOpts = [['', 'No pillar']].concat(livePillars.map((p) => [p._id, p.name]));

    // The composer: one line to write an idea down; the link and its pillar beside the button.
    const text = area('', 2, { maxlength: '2000', placeholder: 'A thought, a customer question, something that happened this week…', 'aria-label': 'An idea' });
    const url = input('', { type: 'url', maxlength: '1000', placeholder: 'A link (optional): the writer reads the page', 'aria-label': 'A link' });
    const pil = select('', [['', livePillars.length ? 'Pillar: the proposal picks' : 'No pillars yet']].concat(livePillars.map((p) => [p._id, p.name])));
    pil.setAttribute('aria-label', 'Pillar');
    const kind = select('story', KIND_OPTS);
    kind.setAttribute('aria-label', 'Kind');
    const why = input('', { maxlength: '1000', placeholder: 'Why it matters to you (optional): what you felt, what you thought, in your words', 'aria-label': 'Why it matters to you' });
    const add = el('button', { type: 'submit', class: 'oc-btn oc-btn--primary' }, 'Add the idea');
    const form = el('form', { class: 'po-compose' }, [text, why, el('div', { class: 'po-compose__row' }, [url, livePillars.length ? pil : null, kind, add])]);
    form.addEventListener('submit', async (e) => {
      e.preventDefault();
      if (!String(text.value).trim()) { text.focus(); return; }
      if (url.value && !/^https?:\/\//i.test(url.value)) { Orch.toast('The link must start with https://', { error: true }); return; }
      add.disabled = true;
      if (await act(A.addIdea, { text: String(text.value).trim(), why: String(why.value).trim() || null, url: String(url.value).trim() || null, pillar_id: pil.value ? Number(pil.value) : null, kind: kind.value }, 'Added.')) render();
      add.disabled = false;
    });

    const fromFeed = (i) => (feeds.rows || []).find((f) => f._id === i.feed_id);
    const waiting = ideas.rows || [];
    const ideaRow = (i) => {
      const sel = livePillars.length ? select(i.pillar_id || '', pillarOpts) : null;
      if (sel) {
        sel.classList.add('po-pillar-pick');
        sel.setAttribute('aria-label', 'Its pillar');
        sel.addEventListener('change', async () => { if (await act(A.setIdeaPillar, { id: i._id, pillar_id: sel.value ? Number(sel.value) : null }, 'Moved.')) render(); });
      }
      return el('li', { class: 'po-idea' }, [
        el('div', { class: 'po-idea__body' }, [
          el('p', { class: 'po-idea__text' }, i.text),
          i.why ? el('p', { class: 'po-idea__why' }, i.why) : null,
          el('p', { class: 'po-idea__meta' }, [i.kind === 'short' ? el('b', 'Short, X only · ') : null,
            i.source === 'feed' ? `From ${(fromFeed(i) || {}).title || 'a feed'}` : i.source === 'agent' ? `Suggested by ${agentName(i.created_by)}${i.origin ? `: ${i.origin}` : ''}` : 'Yours',
            ago(i._created_at) ? ` · ${ago(i._created_at)}` : '',
            i.url ? [' · ', el('a', { href: i.url, target: '_blank', rel: 'noopener' }, short(i.url.replace(/^https?:\/\//, ''), 48))] : null]),
        ]),
        el('div', { class: 'po-idea__tools' }, [
          on.length ? router.link(`/write/${i._id}`, 'Write it', { class: 'oc-btn oc-btn--sm' }) : null,
          el('button', { type: 'button', class: 'oc-btn oc-btn--sm oc-btn--ghost', onClick: () => editIdea(i) }, i.why ? 'Edit' : 'Add why'),
          sel,
          el('button', { type: 'button', class: 'oc-btn oc-btn--sm oc-btn--ghost', onClick: async () => { if (await act(A.dropIdea, { id: i._id }, 'Dropped.')) render(); } }, 'Drop'),
        ]),
      ]);
    };
    const groups = livePillars.map((p) => ({ title: p.name, sub: p.belief, items: waiting.filter((i) => i.pillar_id === p._id) }))
      .concat([{ title: livePillars.length ? 'No pillar yet' : 'Waiting', sub: livePillars.length ? 'The weekly proposal gives each one the pillar its slot needs.' : null, items: waiting.filter((i) => !i.pillar_id || !livePillars.some((p) => p._id === i.pillar_id)) }])
      .filter((g) => g.items.length);

    return el('div', { class: 'po-page po-page--narrow' }, [
      head('Ideas', 'What to write about. The weekly proposal takes them by pillar, oldest first; Write it writes one now.', null),
      suggestBar(s, render),
      form,
      (() => {
        const empty = livePillars.filter((p) => !waiting.some((i) => i.pillar_id === p._id));
        return empty.length ? el('p', { class: 'po-hint' }, [el('b', `${empty.map((p) => p.name).join(', ')}: `), 'no ideas yet, so the proposal writes nothing for them. One real thing that happened, and why it matters to you, makes a post a story.']) : null;
      })(),
      el('div', { class: 'po-ideas' }, groups.length ? groups.map((g) => el('section', { class: 'po-section' }, [
        el('div', { class: 'po-section__head' }, [el('h2', { class: 'po-section__title' }, g.title), el('span', { class: 'po-section__count' }, g.items.length ? `${g.items.length} waiting` : 'none')]),
        g.items.length ? el('ul', { class: 'po-idea-list' }, g.items.map(ideaRow)) : el('p', { class: 'po-muted po-small po-none' }, 'No ideas yet.'),
      ])) : [el('p', { class: 'po-empty' }, 'No ideas waiting. Posts writes from your pillars when there are none.')]),
      materialSection(material.rows || [], fromFeed, livePillars, render),
      feedsSection(s, feeds.rows || [], on),
      (used.rows || []).length ? el('details', { class: 'po-details po-fold' }, [el('summary', `Used and dropped (${used.rows.length})`),
        el('ul', { class: 'po-mini' }, used.rows.map((i) => el('li', { class: 'oc-row' }, [el('span', { class: 'po-grow' }, `${i.status === 'Used' ? 'Used' : 'Dropped'} · ${short(i.text, 110)}`),
          i.status === 'Used' && i.post_id ? router.link(`/post/${i.post_id}`, 'The post', { class: 'oc-small' }) : null,
          i.status === 'Dropped' ? el('button', { type: 'button', class: 'po-linkish', onClick: async () => { if (await act(A.restoreIdea, { id: i._id })) render(); } }, 'Bring back') : null])))]) : null,
    ]);
  });
}

/** An idea in a drawer: its text, why it matters to the person, its link. */
function editIdea(i) {
  const text = area(i.text || '', 4, { maxlength: '2000' });
  const why = area(i.why || '', 3, { maxlength: '1000', placeholder: 'What it meant to you: what you felt, what you thought, what you would tell a friend. Posts builds the post around it.' });
  const url = input(i.url || '', { type: 'url', maxlength: '1000', placeholder: 'https://… (optional)' });
  const kind = select(i.kind === 'short' ? 'short' : 'story', KIND_OPTS);
  const save = el('button', { type: 'submit', class: 'oc-btn oc-btn--primary' }, 'Save the idea');
  let d = null;
  const f = el('form', { class: 'oc-stack po-pillar-form' }, [
    field('The idea', text), field('Why it matters to you', why, 'In your words. Never invented: when it is empty, the post sticks to what happened.'), field('A link', url),
    field('Kind', kind, 'A short is one light X post: a question, a joke, an observation. LinkedIn only takes stories.'),
    el('div', { class: 'oc-row' }, [save, el('button', { type: 'button', class: 'oc-btn oc-btn--ghost', onClick: () => d && d.close() }, 'Cancel')]),
  ]);
  f.addEventListener('submit', async (e) => {
    e.preventDefault();
    if (!String(text.value).trim()) { text.focus(); return; }
    if (url.value && !/^https?:\/\//i.test(url.value)) { Orch.toast('The link must start with https://', { error: true }); return; }
    save.disabled = true;
    const ok = await act(A.updateIdea, { id: i._id, text: String(text.value).trim(), why: String(why.value).trim() || null, url: String(url.value).trim() || null, kind: kind.value }, 'Saved.');
    save.disabled = false;
    if (ok) { d.close(); render(); }
  });
  d = sheet(f, { title: 'The idea', drawer: true });
  setTimeout(() => why.focus(), 50);
}

function feedsSection(s, feeds, on) {
  const url = input('', { type: 'url', maxlength: '1000', placeholder: 'https://yourblog.com/feed.xml' });
  const auto = el('input', { type: 'checkbox' });
  const acct = select(on[0] ? on[0]._id : '', on.map((a) => [a._id, accountSaid(a)]));
  const add = el('button', { type: 'submit', class: 'oc-btn' }, 'Follow the feed');
  const form = el('form', { class: 'oc-stack' }, [
    field('Feed address (RSS or Atom)', url, 'Your blog, a newsletter, your product\'s changelog, a Google Alert. Each new item becomes material the agent picks ideas from each week.'),
    el('label', { class: 'po-check' }, [auto, el('span', 'Also write a draft of each new item, for:')]), acct,
    el('div', { class: 'oc-row' }, add),
  ]);
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    if (!/^https?:\/\//i.test(url.value)) { url.focus(); Orch.toast('A feed address starts with https://', { error: true }); return; }
    add.disabled = true;
    if (await act(A.addFeed, { url: String(url.value).trim(), auto_draft: auto.checked ? 'yes' : 'no', account_id: acct.value ? Number(acct.value) : null, mode: '--feeds' }, 'Following it. Its newest items come in a minute.')) setTimeout(render, 5000);
    add.disabled = false;
  });
  const readNow = el('button', { type: 'button', class: 'oc-btn oc-btn--sm' }, 'Read the feeds now');
  readNow.addEventListener('click', async () => { readNow.disabled = true; if (await act(A.readFeeds, { mode: '--feeds' }, 'Reading them…')) setTimeout(render, 6000); });
  return el('details', { class: 'po-details po-fold' }, [
    el('summary', `Feeds (${feeds.length}): a blog, a newsletter or a changelog that brings material in`),
    el('div', { class: 'oc-row oc-row--between' }, [el('span', { class: 'po-muted po-small' }, feeds.length ? 'Each new item becomes material for the weekly ideas.' : 'None followed yet.'), feeds.length ? readNow : null]),
    feeds.length ? el('ul', { class: 'po-rows' }, feeds.map((f) => el('li', { class: 'po-row po-row--static' }, el('div', { class: 'po-row__open', style: 'cursor:default' }, [
      el('span', { class: 'po-row__first oc-value' }, f.active === 'yes' ? (f.auto_draft === 'yes' ? 'Drafts' : 'Ideas') : 'Off'),
      el('span', { class: 'po-row__name' }, [el('span', f.title || f.url), el('span', { class: 'po-row__sub' }, [f.note ? el('span', { class: 'po-bad' }, f.note) : (f.checked_at ? `Read ${ago(f.checked_at)}` : 'Not read yet'), f.title ? ` · ${short(f.url, 60)}` : ''])]),
      el('span', { class: 'po-row__right' }, el('button', { type: 'button', class: 'oc-btn oc-btn--sm oc-btn--ghost', onClick: async () => { if (await act(A.updateFeed, { id: f._id, active: f.active === 'yes' ? 'no' : 'yes' })) render(); } }, f.active === 'yes' ? 'Stop' : 'Follow again')),
    ])))) : null,
    el('div', { class: 'oc-card po-form' }, form),
  ]);
}

const KIND_OPTS = [['story', 'Story'], ['short', 'Short (X only)']];
const agentName = (id) => (id ? String(id).charAt(0).toUpperCase() + String(id).slice(1) : 'the agent');

/** The agent's weekly ideas: what the last run said, and a button to run it now. */
function suggestBar(s, again) {
  const n = s.suggest_count == null ? 10 : Number(s.suggest_count) || 0;
  const who = agentName(s.agent);
  const btn = el('button', { type: 'button', class: 'oc-btn oc-btn--sm' }, s.ideas_asked_at ? `${who} is looking…` : 'Suggest ideas now');
  if (s.ideas_asked_at) btn.disabled = true;
  btn.addEventListener('click', async () => { btn.disabled = true; if (await act(A.suggestIdeasNow, { id: s._id }, `${who} is looking for ideas. They appear here in a few minutes.`)) setTimeout(again, 4000); });
  const when = n ? `${who} suggests up to ${n} every ${C.DAYS[(Number(s.suggest_day) || 5) - 1]} at ${s.suggest_time || '16:00'}, from your feeds and what happened.` : `${who} suggests none on its own (Settings → Weekly proposal).`;
  return el('div', { class: 'po-hint oc-row oc-row--between' }, [el('span', s.ideas_note || when), btn]);
}

/** What the feeds brought: not ideas yet. The agent picks from it each week; a person can take one. */
function materialSection(rows, fromFeed, livePillars, again) {
  if (!rows.length) return null;
  return el('details', { class: 'po-details po-fold' }, [
    el('summary', `Material from your feeds (${rows.length}): picked from each week, cleared after 14 days`),
    el('ul', { class: 'po-mini' }, rows.map((m) => el('li', { class: 'oc-row' }, [
      el('span', { class: 'po-grow' }, [el('b', `${(fromFeed(m) || {}).title || m.created_by || 'A feed'} · `), short(m.text, 160),
        m.url ? [' · ', el('a', { href: m.url, target: '_blank', rel: 'noopener' }, 'open')] : null]),
      el('button', { type: 'button', class: 'po-linkish', onClick: async () => { if (await act(A.takeMaterial, { id: m._id, text: m.text, pillar_id: null, kind: 'story' }, 'Now an idea.')) again(); } }, 'Make it an idea'),
      el('button', { type: 'button', class: 'po-linkish', onClick: async () => { if (await act(A.dropMaterial, { id: m._id })) again(); } }, 'Drop'),
    ]))),
  ]);
}
