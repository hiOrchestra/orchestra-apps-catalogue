// Home: the next seven days. On top what waits for a person (drafts to
// review, posts that failed), then seven days from today (or from the day in
// the address): each day's posts at their times, and the
// free times of the accounts that are on (a free time opens a new post
// there). Propose the week asks the agent now instead of on Settings' day.
// While the agent writes, the page watches how many are left and redraws
// when that changes (watchFor), not every few seconds.
import { A, C, T, V, act, at, badge, dayName, head, net, netTag, pillarTag, pillars, settings, short, statusOf, tz, unwatch, watchFor } from '../data.js';
import { startCard } from './start.js';

const { el, router } = Orch;

export function render({ from } = {}) {
  Orch.load('view', async () => {
    const s = await settings(true);
    if (!s._id) return el('p', { class: 'oc-state' }, 'Posts is not installed in this project.');
    const today = C.local(new Date(), tz()).ymd;
    const first = /^\d{4}-\d{2}-\d{2}$/.test(from || '') ? from : today;
    const days = Array.from({ length: 7 }, (_, i) => C.addDays(first, i));
    const start = C.isoZ(C.zoned(first, '00:00', tz()));
    const end = C.isoZ(C.zoned(C.addDays(first, 7), '00:00', tz()));
    const [inWeek, review, writing, accts, allPillars] = await Promise.all([
      Orch.db.view(V.posts, { filter: { publish_at: { gte: start, lt: end }, status: ['Writing', 'Draft', 'Scheduled', 'Publishing', 'Published', 'Failed'] }, sort: 'publish_at:asc', limit: 300 }),
      Orch.db.view(V.posts, { filter: { status: ['Draft', 'Failed'] }, sort: 'publish_at:asc', limit: 100 }),
      Orch.db.count(T.posts, { filter: { status: 'Writing' } }),
      Orch.db.list(T.accounts, { filter: { active: 'yes' }, sort: '_id:asc', limit: 50 }),
      pillars(),
    ]);
    const posts = inWeek.rows || [];
    const busy = Number(writing) || 0;
    if (busy) {
      watchFor('week', { was: busy, read: async () => Number(await Orch.db.count(T.posts, { filter: { status: 'Writing' } })) || 0,
        here: () => /^#\/?(week\/[\d-]+)?$/.test(location.hash) || location.hash === '', redraw: () => render({ from }) });
    } else unwatch('week');
    const propose = el('button', { type: 'button', class: 'oc-btn', onClick: async () => {
      if (!(accts.rows || []).length) { Orch.toast('Turn on an account in Settings first.', { error: true }); return; }
      propose.disabled = true; propose.textContent = 'Asking the agent…';
      if (await act(A.proposeNow, { id: s._id, mode: '--propose' })) setTimeout(() => render({ from }), 4000);
    } }, 'Propose the week');
    const nav = el('div', { class: 'po-weeknav' }, [
      router.link(`/week/${C.addDays(first, -7)}`, '← Earlier', { class: 'oc-btn oc-btn--sm oc-btn--ghost' }),
      first !== today ? router.link('/', 'Today', { class: 'oc-btn oc-btn--sm oc-btn--ghost' }) : null,
      router.link(`/week/${C.addDays(first, 7)}`, 'Later →', { class: 'oc-btn oc-btn--sm oc-btn--ghost' }),
    ]);
    const live = posts.filter((p) => p.status !== 'Failed');
    return el('div', { class: 'po-page' }, [
      head(weekTitle(first, today), 'What goes out, where, and the free times. Nothing goes out without your approval.', [propose, router.link('/new', 'New post', { class: 'oc-btn oc-btn--primary' })]),
      s.rehearsal === 'yes' ? el('p', { class: 'po-warn', role: 'note' }, ['Rehearsal: approved posts are checked and marked at their time, but nothing goes to the networks. ', router.link('/settings', 'Turn it off in Settings'), ' when you are ready.']) : null,
      startCard(s, () => render({ from })),
      busy ? el('p', { class: 'po-note-line', role: 'status' }, [el('span', { class: 'po-pulse', 'aria-hidden': 'true' }), `Writing ${busy} post${busy === 1 ? '' : 's'}… they appear here in a minute or two.`]) : null,
      toReview(review.rows || []),
      balance(allPillars, live),
      el('section', { class: 'po-section' }, [
        el('div', { class: 'po-section__head' }, [el('h2', { class: 'po-section__title' }, first === today ? 'The next 7 days' : `From ${dayName(first)}`),
          el('span', { class: 'po-section__count' }, `${live.length} post${live.length === 1 ? '' : 's'}`), nav]),
        el('div', { class: 'po-week' }, days.map((d) => dayColumn(d, today, posts, accts.rows || [])))]),
    ]);
  });
}

function weekTitle(first, today) {
  if (first === today) return 'This week';
  return first < today ? 'Earlier' : 'Later';
}

function toReview(list) {
  if (!list.length) return el('section', { class: 'po-section' }, [el('div', { class: 'po-section__head' }, [el('h2', { class: 'po-section__title' }, 'Needs you'), el('span', { class: 'po-section__count' }, 'nothing')]),
    el('p', { class: 'po-empty' }, 'Nothing waits for your review. New drafts appear here.')]);
  return el('section', { class: 'po-section' }, [
    el('div', { class: 'po-section__head' }, [el('h2', { class: 'po-section__title' }, 'Needs you'), el('span', { class: 'po-section__count' }, `${list.length} to review`)]),
    el('div', { class: 'po-review' }, list.map((p) => {
      const st = statusOf(p);
      const parts = C.partsOf(p.text);
      return router.link(`/post/${p._id}`, [
        el('span', { class: 'po-review__meta' }, [
          el('span', { class: 'oc-value po-review__when' }, p.publish_at ? at(p.publish_at) : 'No time yet'),
          netTag(p.network, p.account_kind), el('span', { class: 'po-review__who' }, p.account_name || 'no account'), badge(st)]),
        el('span', { class: 'po-review__text' }, parts.join('\n\n') || p.brief || '(empty)'),
        el('span', { class: 'po-review__foot' }, [
          pillarTag(p.pillar_name),
          parts.length > 1 ? el('span', { class: 'po-muted' }, `Thread · ${parts.length} posts`) : null,
          p.open_notes ? el('span', { class: 'po-muted' }, `${p.open_notes} note${p.open_notes === 1 ? '' : 's'}`) : null,
          p.status === 'Failed' && p.error ? el('span', { class: 'po-bad' }, short(p.error, 110)) : null,
          el('span', { class: 'po-review__go' }, st === 'Failed' ? 'Open →' : 'Review →'),
        ]),
      ], { class: `po-review__card po-review__card--${st.toLowerCase()}` });
    })),
  ]);
}

/** How this week's posts spread over the pillars, against each pillar's share. */
function balance(allPillars, posts) {
  const on = allPillars.filter((p) => p.active !== 'no' && (Number(p.weight) || 0) > 0);
  if (!on.length) return null;
  const total = on.reduce((a, p) => a + Number(p.weight), 0);
  const n = posts.length;
  const counted = (id) => posts.filter((p) => p.pillar_id === id).length;
  const none = posts.filter((p) => !p.pillar_id).length;
  return el('section', { class: 'po-section' }, [
    el('div', { class: 'po-section__head' }, [el('h2', { class: 'po-section__title' }, 'Pillars this week'), router.link('/pillars', 'Edit pillars', { class: 'po-section__link' })]),
    el('div', { class: 'po-balance' }, [
      ...on.map((p) => {
        const c = counted(p._id);
        const want = Number(p.weight) / total;
        const got = n ? c / n : 0;
        return el('div', { class: 'po-balance__item', title: p.belief || '' }, [
          el('span', { class: 'po-balance__name' }, p.name),
          el('span', { class: 'po-balance__bar', 'aria-hidden': 'true' }, [el('span', { class: 'po-balance__got', style: `width:${Math.round(got * 100)}%` }), el('span', { class: 'po-balance__want', style: `left:${Math.round(want * 100)}%` })]),
          el('span', { class: 'oc-value po-balance__num' }, `${c} of ${n} · aim ${Math.round(want * 100)}%`),
        ]);
      }),
      none ? el('p', { class: 'po-muted po-small' }, `${none} without a pillar.`) : null,
    ]),
  ]);
}

function dayColumn(ymd, today, posts, accts) {
  const mine = posts.filter((p) => C.local(new Date(p.publish_at), tz()).ymd === ymd);
  const items = mine.map((p) => ({ hm: C.local(new Date(p.publish_at), tz()).hm, node: card(p) }));
  // The free times of the accounts that are on, still ahead.
  for (const a of accts) {
    for (const sl of C.slotsOf(a.slots).filter((x) => x.d === C.dowOf(ymd))) {
      const iso = C.isoZ(C.zoned(ymd, sl.t, tz()));
      if (new Date(iso).getTime() < Date.now() + 60000) continue;
      if (mine.some((p) => p.account_id === a._id && C.isoZ(p.publish_at) === iso)) continue;
      items.push({ hm: sl.t, node: router.link(`/new/${a._id}/${encodeURIComponent(iso)}`, [el('span', { class: 'oc-value' }, `+ ${sl.t}`), el('span', ` ${net(a.network)}`)], { class: 'po-free', title: `A free time for ${a.name} on ${net(a.network)}: write a post for it` }) });
    }
  }
  items.sort((x, y) => x.hm.localeCompare(y.hm));
  return el('section', { class: `po-day${ymd === today ? ' po-day--today' : ''}${ymd < today ? ' po-day--past' : ''}`, 'aria-label': dayName(ymd) }, [
    el('h3', { class: 'po-day__name' }, dayName(ymd)),
    items.length ? el('div', { class: 'po-day__items' }, items.map((x) => x.node)) : el('p', { class: 'po-day__none' }, '—'),
  ]);
}

/** A post being written: by the agent, or again after its last try was refused (it tries three times). */
const writingSaid = (p) => (Number(p.tries) > 0 ? `Written again in a few minutes (try ${Number(p.tries) + 1} of 3)…` : 'The agent is writing it…');

const STATE = { Draft: 'To review', Scheduled: 'Approved', Published: 'Out', Rehearsed: 'Rehearsed', Failed: 'Failed', Writing: 'Writing', Publishing: 'Going out' };
function card(p) {
  const st = statusOf(p);
  return router.link(`/post/${p._id}`, [
    el('span', { class: 'po-card__top' }, [el('span', { class: 'oc-value' }, at(p.publish_at, { day: false })), el('span', { class: 'po-card__state' }, STATE[st] || st)]),
    el('span', { class: 'po-card__text' }, short(C.partsOf(p.text).join(' / ') || (p.status === 'Writing' ? writingSaid(p) : p.brief) || '', 90)),
    el('span', { class: 'po-card__pillar' }, [net(p.network), p.account_kind === 'organization' ? ' page' : '', p.pillar_name ? ` · ${p.pillar_name}` : '']),
  ], { class: `po-card po-card--${st.toLowerCase()}`, title: `${p.account_name || ''}${p.pillar_name ? ` · ${p.pillar_name}` : ''}` });
}
