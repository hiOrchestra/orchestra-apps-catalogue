'use strict';
/**
 * Posts · Ideas: next week's ideas, suggested by the project's agent (Friday
 * 16:00 by default, Watch starts it; "Suggest ideas now" too), so the Monday
 * proposal has something real to write from.
 *
 *   pick   gathers what the agent judges from: the pillars, the material the
 *          feeds brought (the last 14 days), the ideas already waiting and
 *          what was said in the last 60 days (not to repeat it), who reads.
 *   save   reads the agent's JSON (PRIOR), keeps each idea that is new, real
 *          (says where it comes from) and on a live pillar, as a waiting idea;
 *          the material it came from is marked taken. Says how many on the
 *          Ideas page (ideas_note).
 *
 * The agent only answers JSON: it never writes to the database.
 *   node ideas.js pick | save
 */
const L = require('./lib');
const C = require('./pocore');

const DAY = 86400000;
const MAX = 20;
const KINDS = ['story', 'short'];
const norm = (t) => String(t || '').toLowerCase().replace(/[^\p{L}\p{N}]+/gu, ' ').trim();

const countOf = (s) => Math.max(0, Math.min(MAX, s.suggest_count == null ? 10 : Number(s.suggest_count) || 0));

function pick() {
  const s = L.settings();
  L.write([{ op: 'update', table: 'po_settings', id: s._id, data: { ideas_asked_at: null } }]);
  const n = countOf(s) || 10; // asked by hand with the weekly ones off: still ten
  const who = s.company_name || 'the person';
  const since14 = L.sqlNow(new Date(L.now().getTime() - 14 * DAY));
  const since60 = L.sqlNow(new Date(L.now().getTime() - 60 * DAY));
  const pillars = L.all("SELECT * FROM po_pillars WHERE _deleted = 0 AND COALESCE(active, 'yes') <> 'no' ORDER BY _id")
    .map((p) => Object.assign({ id: p._id, weight: Number(p.weight) || 1 }, C.pillarSaid(p)));
  const feeds = new Map(L.all('SELECT _id, title, url FROM po_feeds WHERE _deleted = 0').map((f) => [f._id, f.title || f.url]));
  const material = L.all("SELECT * FROM po_ideas WHERE _deleted = 0 AND status = 'Material' AND _created_at >= ? ORDER BY _id DESC LIMIT 60", since14)
    .map((m) => ({ id: m._id, from: feeds.get(m.feed_id) || m.created_by || 'a feed', text: String(m.text || '').slice(0, 600), url: m.url || undefined }));
  const waiting = L.all("SELECT text FROM po_ideas WHERE _deleted = 0 AND status = 'New' ORDER BY _id DESC LIMIT 40").map((x) => String(x.text).slice(0, 200));
  const said = L.all("SELECT text FROM po_ideas WHERE _deleted = 0 AND status IN ('Used', 'Dropped') AND source <> 'feed' AND _updated_at >= ? ORDER BY _id DESC LIMIT 40", since60).map((x) => String(x.text).slice(0, 160))
    .concat(L.all("SELECT agent_note FROM po_posts WHERE _deleted = 0 AND agent_note IS NOT NULL AND status NOT IN ('Dropped', 'Failed') AND _created_at >= ? ORDER BY _id DESC LIMIT 40", since60).map((x) => String(x.agent_note).slice(0, 160)));
  const networks = [...new Set(L.all("SELECT network FROM po_accounts WHERE _deleted = 0 AND active = 'yes'").map((a) => a.network))];
  const instructions = [
    `Suggest up to ${n} ideas for ${who}'s social posts next week. An idea is the raw material of a post, not the post: what happened or the point, in plain facts, one to three sentences, the way ${who} would jot it down. The ideas, pillars and opinions are ${who}'s; you find what is worth saying.`,
    `Every idea comes from something real you can point to: an item of \`material\` (what the feeds ${who} follows brought; give its id), something that happened in this project or that ${who} told you (your memory, your conversations, the project's tasks), or a public page you read (give its url). Never invent an event, a number, a name, a quote or a feeling. Fewer than ${n} is right when the week was thin: a weak idea makes a weak post.`,
    'Material is news and other people\'s work: an idea from it says what is interesting in it for these readers and from where ' + who + ' sees it (their pillars), never just "X released Y". Most material is not worth a post: leave it.',
    'Give each idea the pillar it serves (its id), spread by the pillars\' weight, so the week does not talk about the same thing every day. Never one already in `waiting` or `already_said`, nor the same point in other words.',
    `Each idea has a kind. story: something that happened, a lesson or a take that needs room (a thread on X, a post on LinkedIn). short: X only, one post, light: a question ${who} would really like answered by people building with agents, an ironic or funny observation, a quick take. About a third short${networks.includes('x') ? '' : ' (no X account is on: suggest none)'}.`,
    '`origin`: one line, where it comes from (the material, the conversation, the task, the page), so the person can check it.',
    'You may read what you need (a material link, your memory, the project\'s tasks) but never write to a table or file, never publish, never message anyone: a script saves your answer, and the person can drop any idea before Monday.',
    'Answer ONLY one JSON object: {"ideas":[{"text":"…","pillar":<id>,"kind":"story|short","origin":"…","url":"https://… (optional)","material":<id, optional>}]}',
  ].join('\n');
  return {
    ok: true, instructions, count: n,
    today: C.local(L.now(), s.timezone || 'UTC').ymd,
    who: { name: who, audience: s.audience || undefined, voice: s.voice ? String(s.voice).slice(0, 4000) : undefined, networks },
    pillars, material, waiting, already_said: said,
  };
}

function save() {
  const s = L.settings();
  const picked = L.stepOut('STEP_pick') || {};
  const n = Number(picked.count) || countOf(s) || 10;
  const answer = L.jsonIn(process.env.PRIOR || '') || {};
  const list = Array.isArray(answer.ideas) ? answer.ideas : [];
  const live = new Set(L.all("SELECT _id FROM po_pillars WHERE _deleted = 0 AND COALESCE(active, 'yes') <> 'no'").map((p) => p._id));
  const material = new Map(L.all("SELECT _id, url FROM po_ideas WHERE _deleted = 0 AND status = 'Material'").map((m) => [m._id, m]));
  const seen = new Set(L.all("SELECT text FROM po_ideas WHERE _deleted = 0 AND status IN ('New', 'Used')").map((x) => norm(x.text)));
  const out = { ok: true, saved: 0, refused: [] };
  const ops = [];
  for (const x of list) {
    if (out.saved >= n) break;
    const text = L.clean(x && x.text, 1500);
    const origin = L.clean(x && x.origin, 300);
    if (text.length < 10) { out.refused.push('an idea without text'); continue; }
    if (!origin) { out.refused.push(`"${text.slice(0, 40)}…": does not say where it comes from`); continue; }
    if (seen.has(norm(text))) { out.refused.push(`"${text.slice(0, 40)}…": already an idea`); continue; }
    seen.add(norm(text));
    const m = x.material != null ? material.get(Number(x.material)) : null;
    const url = L.clean(x.url, 1000) || (m && m.url) || null;
    const pid = Number(x.pillar);
    ops.push({ op: 'insert', table: 'po_ideas', data: { text, origin, url: /^https?:\/\//i.test(url || '') ? url : null, pillar_id: live.has(pid) ? pid : null,
      kind: KINDS.includes(x.kind) ? x.kind : 'story', source: 'agent', status: 'New', created_by: s.agent || 'agent' } });
    if (m) { ops.push({ op: 'update', table: 'po_ideas', id: m._id, data: { status: 'Used' } }); material.delete(m._id); }
    out.saved += 1;
  }
  const when = C.local(L.now(), s.timezone || 'UTC');
  const note = out.saved
    ? `${out.saved} idea${out.saved === 1 ? '' : 's'} suggested ${C.DAYS[when.dow - 1] || ''} ${when.hm}: drop any you would not post before the proposal.`
    : `No ideas suggested ${C.DAYS[when.dow - 1] || ''} ${when.hm}${list.length ? `: none could be kept (${out.refused.slice(0, 2).join('; ')})` : ': nothing real worth a post this week'}. Add your own, or follow a feed for material.`;
  ops.push({ op: 'update', table: 'po_settings', id: s._id, data: { ideas_note: note } });
  L.write(ops);
  out.note = note;
  return out;
}

if (require.main === module) {
  const cmd = process.argv[2];
  try { L.done(cmd === 'save' ? save() : pick()); } catch (e) { L.done({ ok: false, error: e.message, ideas: [] }); process.exitCode = 1; }
}
module.exports = { pick, save };
