// The accounts in Settings: each one on or off, its posting times (the days
// and hours its posts go out, in the workspace's zone — Postiz's
// postingTimes) and what to do once a post does well: repost it (LinkedIn),
// or add a first comment / self-reply (Postiz's auto plug).
import { A, C, INTEGRATIONS, PORTAL, X_DOOR, act, ago, area, field, input, net } from '../data.js';

const { el } = Orch;

export function accountsSection(s, list, again) {
  const look = el('button', { type: 'button', class: 'oc-btn' }, list.length ? 'Look for accounts again' : 'Look for accounts');
  look.addEventListener('click', async () => { look.disabled = true; look.textContent = 'Looking…'; if (await act(A.findAccounts, { id: s._id })) setTimeout(again, 8000); });
  return el('section', { class: 'oc-card oc-stack po-form' }, [
    el('div', { class: 'oc-row oc-row--between' }, [el('h2', { class: 'oc-h2' }, 'Accounts'), look]),
    el('p', { class: 'oc-help' }, ['LinkedIn (your profile and the company pages you run) and Facebook pages connect in ', PORTAL(INTEGRATIONS), '; X in ', PORTAL(X_DOOR),
      ', with your own X keys (X charges about US$0.015 a post, US$0.20 with a link). ', s.accounts_at ? `Looked ${ago(s.accounts_at)}.` : '']),
    el('p', { class: 'oc-help' }, 'On LinkedIn your personal profile and each company page you run are separate accounts here: a post goes to exactly one of them, the one you approve it for. Pages come in off; turn on only the ones Posts writes for.'),
    s.accounts_note ? el('p', { class: 'oc-help' }, s.accounts_note) : null,
    list.length ? el('div', { class: 'po-accounts' }, list.map((a) => accountCard(s, a, again))) : el('p', { class: 'po-empty' }, 'No accounts yet: connect a network, then look for accounts.'),
  ]);
}

function accountCard(s, a, again) {
  const slots = C.slotsOf(a.slots);
  const days = new Set(slots.map((x) => x.d));
  const times = [...new Set(slots.map((x) => x.t))].join(', ');
  const ticks = C.DAYS.map((d, i) => {
    const box = el('input', { type: 'checkbox', checked: days.has(i + 1), 'aria-label': d });
    return { box, node: el('label', { class: 'po-day-tick' }, [box, el('span', d)]) };
  });
  const timeIn = input(times, { maxlength: '120', placeholder: '09:00, 13:30', 'aria-label': 'Times' });
  const isLi = a.network === 'linkedin';
  const repost = input(a.repost_at || '', { type: 'number', min: '1', max: '100000', placeholder: 'off', 'aria-label': 'Repost at this many reactions' });
  const replyAt = input(a.reply_at || '', { type: 'number', min: '1', max: '100000', placeholder: 'off', 'aria-label': 'First comment at this many reactions' });
  const replyText = area(a.reply_text || '', 2, { maxlength: '1200', placeholder: a.network === 'x' ? 'A reply under your post: the link, the next step…' : 'A first comment: the link, the sign-up, the next step…' });
  const save = el('button', { type: 'submit', class: 'oc-btn oc-btn--sm oc-btn--primary' }, 'Save');
  const toggle = el('button', { type: 'button', class: `oc-btn oc-btn--sm${a.active === 'yes' ? '' : ' oc-btn--primary'}` }, a.active === 'yes' ? 'Turn off' : 'Turn on');
  toggle.addEventListener('click', async () => { toggle.disabled = true; if (await act(A.updateAccount, { id: a._id, active: a.active === 'yes' ? 'no' : 'yes' }, a.active === 'yes' ? 'Off: nothing more is written or published for it.' : 'On.')) again(); });
  const f = el('form', { class: `po-account${a.active === 'yes' ? '' : ' po-account--off'}` }, [
    el('div', { class: 'po-account__head' }, [
      el('div', { class: 'po-account__name' }, [el('span', a.name), el('span', { class: 'oc-help' }, `${a.kind === 'person' ? 'Personal profile' : a.kind === 'organization' ? 'Company page' : C.netOf(a.network).kinds[a.kind] || a.kind} on ${net(a.network)}${a.handle ? ` · ${a.network === 'x' ? '@' : ''}${a.handle}` : ''}`)]),
      toggle,
    ]),
    a.note ? el('p', { class: 'po-bad' }, a.note) : null,
    field('Posting times', el('div', { class: 'oc-stack' }, [el('div', { class: 'po-days' }, ticks.map((t) => t.node)), timeIn]), `${C.slotsSaid(slots, 'en')} · ${s.timezone || 'UTC'}`),
    el('div', { class: 'po-two' }, [
      isLi ? field('Repost it at', repost, 'reactions; once') : null,
      field(a.network === 'x' ? 'Reply under it at' : 'First comment at', replyAt, a.network === 'x' ? 'likes + reposts; X is read a day and a week after' : 'reactions; once'),
    ]),
    field(a.network === 'x' ? 'The reply' : 'The comment', replyText),
    el('div', { class: 'oc-row' }, save),
  ]);
  f.addEventListener('submit', async (e) => {
    e.preventDefault();
    const picked = ticks.map((t, i) => (t.box.checked ? i + 1 : 0)).filter(Boolean);
    const next = C.slotsFrom(picked, timeIn.value);
    if (!next.length) { timeIn.focus(); Orch.toast('Tick at least one day and write a time like 09:00.', { error: true }); return; }
    if (replyAt.value && !String(replyText.value).trim()) { replyText.focus(); Orch.toast('Write the comment, or leave its number empty.', { error: true }); return; }
    save.disabled = true;
    const num = (x) => (String(x.value).trim() ? Math.max(1, Math.round(Number(x.value))) : null);
    if (await act(A.updateAccount, { id: a._id, slots: JSON.stringify(next), repost_at: isLi ? num(repost) : null, reply_at: num(replyAt), reply_text: String(replyText.value).trim() || null }, 'Saved.')) again();
    save.disabled = false;
  });
  return f;
}
