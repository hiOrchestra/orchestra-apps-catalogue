// A new post: ask the agent (what about, for one account or several — each
// network gets its own version, Postiz's "group"), or write it yourself. A
// free time on the week opens this with its account and time chosen.
import { A, C, T, accountSaid, accounts, act, area, at, field, fromInput, input, select, settings, takenOf, toInput } from '../data.js';
import { preview } from './preview.js';

const { el, router } = Orch;

export function compose({ account, at: when, idea } = {}) {
  Orch.load('view', async () => {
    const s = await settings(true);
    const [list, tpls, ideas] = await Promise.all([accounts(), Orch.db.list(T.templates, { sort: 'name:asc', limit: 100 }), Orch.db.list(T.ideas, { filter: { status: 'New' }, sort: '_id:desc', limit: 50 })]);
    const on = list.filter((a) => a.active === 'yes');
    tpls.rows = (tpls.rows || []).filter((t) => t.dropped !== 'yes');
    if (!on.length) return el('div', { class: 'oc-state' }, [el('p', 'No account is on yet.'), router.link('/settings', 'Turn one on in Settings')]);
    const chosen = new Set([Number(account) || on[0]._id]);
    const fixedAt = when ? decodeURIComponent(when) : null;
    const tplSel = select('', [['', 'No template'], ...(tpls.rows || []).map((t) => [t._id, t.name])]);
    const ideaSel = select(idea || '', [['', 'No idea from the list'], ...(ideas.rows || []).map((i) => [i._id, String(i.text).replace(/\s+/g, ' ').slice(0, 80)])]);

    // Who: one tick per account that is on.
    const ticks = el('div', { class: 'po-ticks' }, on.map((a) => {
      const box = el('input', { type: 'checkbox', checked: chosen.has(a._id), onChange: () => { if (box.checked) chosen.add(a._id); else chosen.delete(a._id); } });
      return el('label', { class: 'po-check' }, [box, el('span', accountSaid(a))]);
    }));

    // Ask the agent.
    const brief = area('', 4, { maxlength: '2000', placeholder: 'What about: the launch of X, a lesson from this week, a customer question… (or pick an idea)' });
    const ask = el('button', { type: 'submit', class: 'oc-btn oc-btn--primary' }, 'Ask the agent');
    const askForm = el('form', { class: 'oc-stack' }, [
      field('Where it goes', ticks, 'Your personal profile and a company page are different places: tick each one it should go to. Each gets its own version.'),
      field('What about', brief), el('div', { class: 'po-two' }, [field('Or an idea', ideaSel), field('Template', tplSel)]),
      el('p', { class: 'oc-help' }, fixedAt ? `It goes in for ${at(fixedAt)}; the others at their next free time.` : 'Each one goes in for its account\'s next free time; you approve it before it goes out.'),
      el('div', { class: 'oc-row' }, ask),
    ]);
    askForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      if (!chosen.size) { Orch.toast('Tick at least one account.', { error: true }); return; }
      if (!String(brief.value).trim() && !ideaSel.value) { brief.focus(); Orch.toast('Say what it is about, or pick an idea.', { error: true }); return; }
      ask.disabled = true;
      const group = chosen.size > 1 ? `g${Date.now().toString(36)}` : null;
      let ok = 0;
      for (const id of chosen) {
        const a = on.find((x) => x._id === id);
        const taken = await takenOf(id);
        const slot = fixedAt && Number(account) === id ? fixedAt : C.freeSlots({ slots: a.slots, taken, tz: s.timezone || 'UTC', from: new Date(), count: 1, days: 60 })[0] || null;
        if (await act(A.writePost, { account_id: id, network: a.network, publish_at: slot, group_key: group, brief: String(brief.value).trim() || null, idea_id: ideaSel.value ? Number(ideaSel.value) : null, template_id: tplSel.value ? Number(tplSel.value) : null, mode: '--auto' })) ok += 1;
      }
      if (ok) { Orch.toast(`The agent is writing ${ok === 1 ? 'it' : `${ok} versions`}. It waits for your review on the week.`); router.go('/'); } else ask.disabled = false;
    });

    // Write it yourself.
    const who = select(Number(account) || on[0]._id, on.map((a) => [a._id, accountSaid(a)]));
    const text = area('', 10, { 'aria-label': 'The post' });
    const time = input(fixedAt ? toInput(fixedAt) : '', { type: 'datetime-local' });
    const tpl2 = select('', [['', 'Start from a template'], ...(tpls.rows || []).map((t) => [t._id, t.name])]);
    const pv = el('div');
    const draw = () => { const a = on.find((x) => x._id === Number(who.value)); pv.replaceChildren(preview({ account: a, network: a && a.network, text: text.value })); };
    text.addEventListener('input', draw);
    who.addEventListener('change', draw);
    tpl2.addEventListener('change', async () => { const t = (tpls.rows || []).find((x) => String(x._id) === tpl2.value); if (t && (!text.value.trim() || await Orch.confirm('Replace the text with the template?', { yes: 'Replace' }))) { text.value = t.body; draw(); } });
    draw();
    const save = el('button', { type: 'submit', class: 'oc-btn oc-btn--primary' }, 'Save as draft');
    const ownForm = el('form', { class: 'po-split' }, [
      el('div', { class: 'oc-stack po-editor' }, [el('div', { class: 'po-two' }, [field('Goes out as', who), field('When', time, 'Empty: the next free time when you approve.')]), tpl2, field('The post', text), el('div', { class: 'oc-row' }, save)]),
      el('div', { class: 'po-side' }, pv),
    ]);
    ownForm.addEventListener('submit', async (e) => {
      e.preventDefault();
      const a = on.find((x) => x._id === Number(who.value));
      if (!String(text.value).trim()) { text.focus(); return; }
      save.disabled = true;
      const r = await act(A.newPost, { account_id: a._id, network: a.network, text: String(text.value).trim(), publish_at: fromInput(time.value), template_id: tpl2.value ? Number(tpl2.value) : null }, 'Saved as a draft.');
      if (r && r._id) router.go(`/post/${r._id}`); else save.disabled = false;
    });

    const tabs = el('div', { class: 'oc-tabs', role: 'tablist' });
    const panes = { agent: askForm, own: ownForm };
    const show = (k) => { for (const [n, p] of Object.entries(panes)) p.hidden = n !== k; for (const b of tabs.children) b.setAttribute('aria-selected', String(b.dataset.k === k)); };
    for (const [k, label] of [['agent', 'Ask the agent'], ['own', 'Write it yourself']]) tabs.append(el('button', { type: 'button', class: 'oc-tab', role: 'tab', 'data-k': k, onClick: () => show(k) }, label));
    show('agent');
    return el('div', { class: 'oc-stack oc-stack--loose' }, [
      el('header', { class: 'po-posthead' }, [router.link('/', '← Week', { class: 'po-back' }), el('h1', { class: 'oc-h1 po-title' }, 'A new post'),
        el('p', { class: 'oc-lede' }, 'Ask the agent to write it in your voice, or write it yourself. Either way it waits for your approval.')]),
      tabs, askForm, ownForm,
    ]);
  });
}
