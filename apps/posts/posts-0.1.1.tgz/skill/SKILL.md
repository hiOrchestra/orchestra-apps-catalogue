---
name: app-posts
version: 0.1.1
description: >-
  Work in the Posts app: the social posts of the week (LinkedIn profile and
  company pages, X, Facebook pages), the drafts waiting for a person's
  approval, the ideas, and what worked. Load it when someone says "post this
  on LinkedIn / publicá esto", "an idea for a post / tengo una idea para un
  post", "what goes out this week / qué sale esta semana", "how did my posts
  do / cómo anduvieron mis posts", or when the "Posts · Write" workflow asks
  you to write. Needs the Posts app installed in a project you work in.
metadata:
  openclaw:
    emoji: "📣"
---
# Posts — the week of social posts, approved by a person

Once a week (and whenever a person asks) you write posts for the free times
of the accounts that are on; a person reads each one as it will look,
approves it or asks for another version; a script publishes it at its time.
**You never publish, approve or schedule anything.**

```bash
ls -d ~/.openclaw/orchestra/projects/*/apps/posts   # the directory name under projects/ is the project id
P=<project>; T=~/.openclaw/orchestra/projects/$P/apps/posts/automations
orch-canvas url posts                                # the desk, for the person
```

If nothing is listed, Posts is not installed in a project you work in: say
so, and do not publish some other way.

## What you can do, and what you never do

| You can | With |
|---|---|
| Say what goes out in the next 7 days, and what waits for review | `node $T/posts.js week` |
| Write down an idea someone tells you (with a link if they gave one) | `node $T/posts.js idea --text "…" [--url https://…]` |
| List the ideas not used yet | `node $T/posts.js ideas` |
| Say what went out and how it did | `node $T/posts.js done [--days 30]` |
| Say which accounts are on, their times, and when the week is proposed | `node $T/posts.js where` |

**Never:** publish, approve, schedule, delete, or write to the `po_*` tables
by hand; never post to a network with another skill on someone's behalf when
Posts is installed — write the idea down and send them to the desk. Turning
rehearsal off is a person's two-step choice in Settings.

**When "Posts · Write" asks you:** write every item, in the voice and
language given, as the account each item names, within its network's limit
and style. Use only the facts given (the idea, its page, its file): never
invent numbers, customers, quotes or results. A template is a shape, filled
in completely; never leave `[…]`, `{{…}}` or a line of "…". Answer only the
JSON asked for.

## The model (tables `po_*`, read only for you)

| Table | One row per | Notes |
|---|---|---|
| `po_posts` | post | `status` Writing → Draft → Scheduled → Publishing → Published, or Failed / Dropped; `network`, `account_id`, `publish_at` (UTC), `text`, `url` once out, `rehearsed` (checked, never sent), `reactions` |
| `po_accounts` | account | `network` linkedin/x/facebook, `kind`, `name`, `active`, `slots` (days and local times) |
| `po_ideas` | idea | `status` New → Used / Dropped; `source` person/agent/feed |
| `po_settings` | one row | the voice, topics, examples, the weekly proposal, `rehearsal` |
