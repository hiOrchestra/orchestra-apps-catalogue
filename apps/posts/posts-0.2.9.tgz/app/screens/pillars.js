// Pillars: the directions every post leans on. Each says what we believe, from
// where we say it, what we push against, and what grounds it (posts,
// articles, our own cases). Ideas run out once written; pillars stay, so the
// weekly proposal keeps them in balance by their weight, and every post takes
// one side instead of describing.
import { A, act, area, field, head, input, pillars, sheet } from '../data.js';

const { el } = Orch;

const WEIGHTS = [[1, 'Now and then'], [2, 'Often'], [3, 'Most of the time']];

function form(p, done) {
  const name = input(p && p.name, { maxlength: '120', placeholder: 'Software is getting free', required: true });
  const belief = area(p && p.belief, 3, { maxlength: '1500', placeholder: 'What we believe, in one or two sentences. The post takes this side.' });
  const angle = area(p && p.angle, 2, { maxlength: '1000', placeholder: 'From where we say it: what we see every day that others do not.' });
  const against = area(p && p.against, 2, { maxlength: '1000', placeholder: 'The view we push against.' });
  const refs = area(p && p.refs, 4, { maxlength: '6000', placeholder: 'Posts, articles, our own cases: a link or a quote per line, with who said it.' });
  const weight = el('select', { class: 'oc-select' }, WEIGHTS.map(([v, l]) => el('option', { value: v, selected: Number(p && p.weight || 2) === v }, l)));
  const save = el('button', { type: 'submit', class: 'oc-btn oc-btn--primary' }, p ? 'Save the pillar' : 'Add the pillar');
  const f = el('form', { class: 'oc-stack po-pillar-form' }, [
    field('Pillar', name),
    field('What we believe', belief, 'The posts take this side, in their own words: it is never quoted.'),
    field('Our angle', angle, 'Where we see it from. It makes the posts ours, not anyone\'s.'),
    field('What we push against', against, 'Optional. A clear other side makes a post worth reading.'),
    field('References', refs, 'Optional. What grounds it: the writer draws on them, and cites one only when it carries the point.'),
    field('How often', weight, 'The weekly proposal keeps the pillars in this balance.'),
    el('div', { class: 'oc-row' }, [save, el('button', { type: 'button', class: 'oc-btn oc-btn--ghost', onClick: () => done(false) }, 'Cancel')]),
  ]);
  f.addEventListener('submit', async (e) => {
    e.preventDefault();
    if (!String(name.value).trim()) { name.focus(); return; }
    save.disabled = true;
    const data = { name: String(name.value).trim(), belief: String(belief.value).trim() || null, angle: String(angle.value).trim() || null, against: String(against.value).trim() || null, refs: String(refs.value).trim() || null, weight: Number(weight.value) };
    const ok = p ? await act(A.updatePillar, Object.assign({ id: p._id }, data), 'Saved.') : await act(A.addPillar, data, 'Added.');
    save.disabled = false;
    if (ok) done(true);
  });
  return f;
}

/** Add or edit a pillar in a dialog, as the rest of the desk edits. */
function openForm(p) {
  let d = null;
  const f = form(p, (changed) => { if (d) d.close(); if (changed) render(); });
  d = sheet(f, { title: p ? `Edit: ${p.name || 'pillar'}` : 'A new pillar', drawer: true });
  setTimeout(() => { const first = f.querySelector('input, textarea'); if (first) first.focus(); }, 50);
}

export function render() {
  Orch.load('view', async () => {
    const since = new Date(Date.now() - 30 * 86400000).toISOString();
    const [list, ideas, posts] = await Promise.all([
      pillars(),
      Orch.db.list('po_ideas', { filter: { status: 'New' }, limit: 500 }),
      Orch.db.list('po_posts', { filter: { publish_at: { gte: since }, status: ['Draft', 'Scheduled', 'Publishing', 'Published'] }, limit: 500 }),
    ]);
    const on = list.filter((p) => p.active !== 'no');
    const total = on.reduce((a, p) => a + (Number(p.weight) || 0), 0) || 1;
    const waiting = (id) => (ideas.rows || []).filter((i) => i.pillar_id === id).length;
    const led = (id) => (posts.rows || []).filter((x) => x.pillar_id === id).length;
    const addBtn = el('button', { type: 'button', class: 'oc-btn oc-btn--primary', onClick: () => openForm(null) }, 'Add a pillar');
    return el('div', { class: 'po-page' }, [
      head('Pillars', 'The directions every post leans on: what we believe, from where we say it, and what we push against. Ideas get used up; pillars stay, and the weekly proposal keeps them in balance.', [addBtn]),
      list.length ? el('div', { class: 'po-pillars' }, list.map((p) => pillarCard(p, {
        share: p.active === 'no' ? null : (Number(p.weight) || 0) / total, waiting: waiting(p._id), led: led(p._id),
        edit: () => openForm(p),
        toggle: async () => { if (await act(A.updatePillar, { id: p._id, active: p.active === 'no' ? 'yes' : 'no' }, p.active === 'no' ? 'On again.' : 'Off: no new posts lean on it.')) render(); },
      }))) : el('div', { class: 'po-empty oc-card' }, [el('p', { style: 'margin:0 0 10px' }, 'No pillars yet. A pillar is a direction your posts lean on: what you believe, from where you say it, and what you push against. Without one, the writer works from the topics in Settings.'),
        el('button', { type: 'button', class: 'oc-btn oc-btn--primary', onClick: () => openForm(null) }, 'Add the first pillar')]),
    ]);
  });
}

function pillarCard(p, { share, waiting, led, edit, toggle }) {
  const off = p.active === 'no';
  const refs = String(p.refs || '').split('\n').filter((x) => x.trim());
  return el('article', { class: `po-pillar${off ? ' po-pillar--off' : ''}` }, [
    el('header', { class: 'po-pillar__head' }, [
      el('h2', { class: 'po-pillar__name' }, p.name || 'Untitled'),
      el('span', { class: 'oc-value po-pillar__share' }, off ? 'Off' : `${Math.round(share * 100)}%`),
    ]),
    off ? null : el('span', { class: 'po-pillar__bar', 'aria-hidden': 'true' }, el('span', { style: `width:${Math.round(share * 100)}%` })),
    p.belief ? el('p', { class: 'po-pillar__belief' }, p.belief) : el('p', { class: 'po-muted' }, 'No belief written yet.'),
    el('dl', { class: 'po-pillar__facts' }, [
      p.angle ? el('div', [el('dt', 'Our angle'), el('dd', p.angle)]) : null,
      p.against ? el('div', [el('dt', 'Against'), el('dd', p.against)]) : null,
      refs.length ? el('div', [el('dt', 'References'), el('dd', el('details', { class: 'po-details' }, [el('summary', `${refs.length} source${refs.length === 1 ? '' : 's'}`), el('pre', { class: 'po-refs' }, refs.join('\n'))]))]) : null,
    ]),
    el('footer', { class: 'po-pillar__foot' }, [
      el('span', { class: 'po-muted po-small' }, `${waiting} idea${waiting === 1 ? '' : 's'} waiting · ${led} post${led === 1 ? '' : 's'} in 30 days`),
      el('span', { class: 'po-pillar__tools' }, [
        el('button', { type: 'button', class: 'oc-btn oc-btn--sm', onClick: edit }, 'Edit'),
        el('button', { type: 'button', class: 'oc-btn oc-btn--sm oc-btn--ghost', onClick: toggle }, off ? 'Turn on' : 'Turn off'),
      ]),
    ]),
  ]);
}
