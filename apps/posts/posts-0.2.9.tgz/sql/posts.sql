SELECT p._id, p.status, p.account_id, COALESCE(a.network, p.network) AS network, a.kind AS account_kind, a.name AS account_name, a.handle AS account_handle,
  p.text, p.publish_at, p.group_key, p.idea_id, p.source, p.created_by, p.agent_note, p.version, p.week, p.url, p.published_at, p.rehearsed, p.error, p.unsure,
  p.cost_usd, p.reactions, p.comments, p.plugs_done, p.brief, p.tries, p._created_at, p._updated_at, p.pillar_id,
  (SELECT pl.name FROM po_pillars pl WHERE pl._id = p.pillar_id AND pl._deleted = 0) AS pillar_name,
  (SELECT COUNT(*) FROM po_notes n WHERE n.post_id = p._id AND n._deleted = 0 AND n.resolved_at IS NULL) AS open_notes
FROM po_posts p LEFT JOIN po_accounts a ON a._id = p.account_id
WHERE p._deleted = 0
