// Pillars: the directions every post leans on. Each says what we believe, from
// where we say it, what we push against, and what grounds it (posts,
// articles, our own cases). Ideas run out once written; pillars stay, so the
// weekly proposal keeps them in balance by their weight, and every post takes
// one side instead of describing.
import { A, act, area, field, head, input, pillars } from '../data.js';

const { el } = Orch;

const WEIGHTS = [[1, 'Now and then'], [2, 'Often'], [3, 'Most of the time']];

function form(p, done) {
  const name = input(p && p.name, { maxlength: '120', placeholder: 'Software is getting free', required: true });
  const belief = area(p && p.belief, 3, { maxlength: '1500', placeholder: 'What we believe, in one or two sentences. The post takes this side.' });
  const angle = area(p && p.angle, 2, { maxlength: '1000', placeholder: 'From where we say it: what we see every day that others do not.' });
  const against = area(p && p.against, 2, { maxlength: '1000', placeholder: 'The view we push against.' });
  const refs = area(p && p.refs, 4, { maxlength: '6000', placeholder: 'Posts, articles, our own cases: a link or a quote per line, with who said it.' });
  const weight = el('select', { class: 'oc-select' }, WEIGHTS.map(([v, l]) => el('option', { value: v, selected: Number(p && p.weight || 2) === v }, l)));
  const save = el('button', { type: 'submit', class: 'oc-btn oc-btn--primary' }, p ? 'Save the pillar' : 'Add the pillar');
  const f = el('form', { class: 'oc-card oc-stack po-form' }, [
    field('Pillar', name),
    field('What we believe', belief, 'The posts take this side, in their own words: it is never quoted.'),
    field('Our angle', angle, 'Where we see it from. It makes the posts ours, not anyone\'s.'),
    field('What we push against', against, 'Optional. A clear other side makes a post worth reading.'),
    field('References', refs, 'Optional. What grounds it: the writer draws on them, and cites one only when it carries the point.'),
    field('How often', weight, 'The weekly proposal keeps the pillars in this balance.'),
    el('div', { class: 'oc-row' }, [save, p ? el('button', { type: 'button', class: 'oc-btn oc-btn--ghost', onClick: () => done(false) }, 'Cancel') : null]),
  ]);
  f.addEventListener('submit', async (e) => {
    e.preventDefault();
    if (!String(name.value).trim()) { name.focus(); return; }
    save.disabled = true;
    const data = { name: String(name.value).trim(), belief: String(belief.value).trim() || null, angle: String(angle.value).trim() || null, against: String(against.value).trim() || null, refs: String(refs.value).trim() || null, weight: Number(weight.value) };
    const ok = p ? await act(A.updatePillar, Object.assign({ id: p._id }, data), 'Saved.') : await act(A.addPillar, data, 'Added.');
    save.disabled = false;
    if (ok) done(true);
  });
  return f;
}

export function render() {
  Orch.load('view', async () => {
    const list = await pillars();
    const on = list.filter((p) => p.active !== 'no');
    const total = on.reduce((a, p) => a + (Number(p.weight) || 0), 0) || 1;
    let editing = null;
    const box = el('div', { class: 'oc-stack' });
    const draw = () => box.replaceChildren(...list.map((p) => (editing === p._id ? form(p, (changed) => { editing = null; if (changed) render(); else draw(); }) : el('article', { class: `oc-card oc-stack po-pillar${p.active === 'no' ? ' po-pillar--off' : ''}` }, [
      el('div', { class: 'oc-row oc-row--between' }, [
        el('h2', { class: 'oc-h2' }, p.name || 'Untitled'),
        el('span', { class: 'oc-small' }, p.active === 'no' ? 'Off' : `${Math.round(((Number(p.weight) || 0) / total) * 100)}% of the posts`),
      ]),
      p.belief ? el('p', p.belief) : null,
      p.angle ? el('p', { class: 'oc-small' }, [el('b', 'Our angle: '), p.angle]) : null,
      p.against ? el('p', { class: 'oc-small' }, [el('b', 'Against: '), p.against]) : null,
      p.refs ? el('details', { class: 'po-details' }, [el('summary', `References (${String(p.refs).split('\n').filter((x) => x.trim()).length})`), el('pre', { class: 'po-refs' }, p.refs)]) : null,
      el('div', { class: 'oc-row' }, [
        el('button', { type: 'button', class: 'oc-btn oc-btn--sm', onClick: () => { editing = p._id; draw(); } }, 'Edit'),
        el('button', { type: 'button', class: 'oc-btn oc-btn--sm oc-btn--ghost', onClick: async () => { if (await act(A.updatePillar, { id: p._id, active: p.active === 'no' ? 'yes' : 'no' }, p.active === 'no' ? 'On again.' : 'Off: no new posts lean on it.')) render(); } }, p.active === 'no' ? 'Turn on' : 'Turn off'),
      ]),
    ]))));
    draw();
    return el('div', { class: 'oc-stack oc-stack--loose' }, [
      head('Pillars', 'The directions every post leans on: what we believe, from where we say it, and what we push against. Ideas get used up; pillars stay.', null),
      list.length ? box : el('p', { class: 'po-empty oc-card' }, 'No pillars yet. Without them the writer works from the topics in Settings.'),
      el('details', { class: 'po-details', open: !list.length }, [el('summary', 'Add a pillar'), form(null, (changed) => { if (changed) render(); })]),
      on.length > 1 ? el('p', { class: 'oc-small' }, 'Each week the proposal gives every post the pillar furthest below its share.') : null,
    ]);
  });
}
