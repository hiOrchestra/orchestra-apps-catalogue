// Settings: the company and language, how you write (the agent's voice),
// the signature, the weekly proposal, the accounts and their times
// (accounts.js), rehearsal, templates and Telegram. One form per section;
// rehearsal has its own two-step control, since turning it off is what lets
// posts reach real people.
import { A, C, accounts, act, area, field, head, input, settings, sheet } from '../data.js';
import { accountsSection } from './accounts.js';

const { el, router } = Orch;
const ZONES = ['Europe/Madrid', 'Europe/London', 'Europe/Lisbon', 'Europe/Paris', 'Europe/Berlin', 'America/New_York', 'America/Chicago', 'America/Los_Angeles',
  'America/Mexico_City', 'America/Bogota', 'America/Lima', 'America/Santiago', 'America/Argentina/Buenos_Aires', 'America/Sao_Paulo', 'UTC'];

export function render() {
  Orch.load('view', async () => {
    const s = await settings(true);
    const [list, tpls] = await Promise.all([accounts(), Orch.db.list('po_templates', { sort: '_id:asc', limit: 100 })]);
    const again = () => render();
    // How Posts writes, the weekly proposal, the signature and Telegram are managed in
    // Orchestra (Apps → Posts → Ajustes): typed, with their defaults, like its connections
    // in Integrations. Here, only what is Posts' own: rehearsal, accounts, templates.
    const f = managed(s);
    const parts = [
      ['publishing', 'Publishing', rehearsal(s, list, again), 'Live or rehearsal: whether approved posts really go out.'],
      ['accounts', 'Accounts', accountsSection(s, list, again), 'Where posts go, and when each account posts.'],
      ['orchestra', 'Writing and schedule', f, 'Your voice, the weekly proposal and its ideas, the signature, Telegram — in Orchestra.'],
      ['templates', 'Templates', templates((tpls.rows || []).filter((t) => t.dropped !== 'yes'), again), 'Shapes a post can follow.'],
    ];
    for (const [key, , node] of parts) if (node) node.setAttribute('data-part', key);
    const KEY = 'posts.settings.part';
    let current = 'publishing';
    try { const v = localStorage.getItem(KEY); if (parts.some((x) => x[0] === v)) current = v; } catch { /* no storage */ }
    const main = el('div', { class: 'po-settings__main' }, parts.map((x) => x[2]));
    const links = parts.map(([key, label, , help]) => el('button', { type: 'button', class: 'po-settings__link', 'data-key': key, onClick: () => show(key) }, [el('span', label), el('span', { class: 'po-settings__help' }, help)]));
    const show = (key) => {
      current = key;
      try { localStorage.setItem(KEY, key); } catch { /* no storage */ }
      for (const node of main.querySelectorAll('[data-part]')) node.hidden = node.getAttribute('data-part') !== key;
      for (const b of links) b.classList.toggle('po-settings__link--on', b.getAttribute('data-key') === key);
    };
    show(current);
    return el('div', { class: 'po-page' }, [
      head('Settings', 'How Posts writes, where posts go and when.', null),
      el('div', { class: 'po-settings' }, [el('nav', { class: 'po-settings__nav', 'aria-label': 'Settings sections' }, links), main]),
    ]);
  });
}

// The settings Orchestra manages: what they are now, and a way there.
function managed(s) {
  const link = el('a', { class: 'oc-btn oc-btn--primary', target: '_blank', rel: 'noopener', hidden: true }, 'Open Posts settings in Orchestra');
  const where = el('p', { class: 'oc-help' }, 'In Orchestra: Apps → Posts → Ajustes.');
  Orch.manageUrl && Orch.manageUrl('settings').then((url) => { if (url) { link.href = url; link.hidden = false; where.hidden = true; } });
  const day = (n, d) => C.DAYS[(Number(n) || d) - 1];
  const facts = [
    ['Proposal', `${day(s.propose_day, 1)} at ${s.propose_time || '08:00'}, up to ${s.propose_count == null ? 3 : s.propose_count} posts`],
    ['Ideas', `${day(s.suggest_day, 5)} at ${s.suggest_time || '16:00'}, up to ${s.suggest_count == null ? 10 : s.suggest_count}`],
    ['Written in', C.langOf(s.language) === 'en' ? 'English' : 'Español'],
    ['Telegram', s.notify_telegram ? 'on' : 'off'],
  ];
  return el('section', { class: 'oc-card oc-stack po-form' }, [
    el('h2', { class: 'oc-h2' }, 'Managed in Orchestra'),
    el('p', { class: 'oc-help' }, 'How you write, the weekly proposal and its ideas, the signature and Telegram are set on Posts\' page in Orchestra, next to its connections and who does its work.'),
    el('ul', { class: 'po-mini' }, facts.map(([k, v]) => el('li', [el('b', `${k}: `), v]))),
    el('div', { class: 'oc-row' }, [link]), where,
  ]);
}

function rehearsal(s, list, again) {
  const on = s.rehearsal === 'yes';
  const live = list.filter((a) => a.active === 'yes');
  const b = el('button', { type: 'button', class: `oc-btn${on ? ' oc-btn--primary' : ''}` }, on ? 'Turn rehearsal off…' : 'Back to rehearsal');
  b.addEventListener('click', async () => {
    if (!on) { if (await act(A.rehearsal, { id: s._id, rehearsal: 'yes' }, 'Rehearsal is on: nothing goes out.')) again(); return; }
    // Two steps: the second names who will start posting for real, and stays off until acknowledged.
    const ack = el('input', { type: 'checkbox' });
    const go = el('button', { type: 'button', class: 'oc-btn oc-btn--primary', disabled: true }, 'Turn it off');
    ack.addEventListener('change', () => { go.disabled = !ack.checked; });
    const body = el('div', { class: 'oc-stack' }, [
      el('p', 'From now on, every approved post goes out at its time, for everyone to see:'),
      live.length ? el('ul', { class: 'po-mini' }, live.map((a) => el('li', `${a.name} · ${C.netOf(a.network).kinds[a.kind] || a.kind} on ${C.netOf(a.network).name}`))) : el('p', { class: 'po-bad' }, 'No account is on yet.'),
      el('label', { class: 'po-check' }, [ack, el('span', 'I understand: approved posts will be published on these accounts.')]),
      el('div', { class: 'oc-row' }, go),
    ]);
    const d = sheet(body, { title: 'Turn rehearsal off?' });
    go.addEventListener('click', async () => { go.disabled = true; const ok = await act(A.rehearsal, { id: s._id, rehearsal: 'no' }, 'Rehearsal is off: approved posts go out at their time.'); d.close(); if (ok) again(); });
  });
  return el('section', { class: `oc-card oc-stack po-form${on ? ' po-rehearsal' : ''}` }, [
    el('div', { class: 'oc-row oc-row--between' }, [el('h2', { class: 'oc-h2' }, on ? 'Rehearsal is on' : 'Live'), b]),
    el('p', { class: 'oc-help' }, on ? 'Approved posts are checked and marked at their time, but nothing goes to any network. Try the whole week this way, then turn it off.'
      : 'Approved posts go out at their time. Back to rehearsal stops that at once; what was already published stays.'),
  ]);
}

function templates(list, again) {
  const name = input('', { maxlength: '80', placeholder: 'Lesson learned' });
  const body = area('', 4, { maxlength: '3000' });
  const add = el('button', { type: 'submit', class: 'oc-btn' }, 'Add the template');
  const f = el('form', { class: 'oc-stack' }, [el('div', { class: 'po-two' }, [field('Name', name), field('The shape', body)]), el('div', { class: 'oc-row' }, add)]);
  f.addEventListener('submit', async (e) => {
    e.preventDefault();
    if (!String(name.value).trim() || !String(body.value).trim()) return;
    add.disabled = true;
    if (await act(A.addTemplate, { name: String(name.value).trim(), body: String(body.value) }, 'Added.')) again();
    add.disabled = false;
  });
  return el('section', { class: 'oc-card oc-stack po-form' }, [
    el('h2', { class: 'oc-h2' }, 'Templates'),
    el('p', { class: 'oc-help' }, 'Shapes a post can follow. Posts fills them in completely; you can start from one when you write yourself.'),
    list.length ? el('div', { class: 'po-accounts' }, list.map((t) => el('details', { class: 'po-account' }, [
      el('summary', { class: 'po-account__sum po-tpl__sum' }, [el('span', { class: 'po-account__title' }, t.name),
        el('span', { class: 'oc-help po-tpl__first' }, String(t.body || '').split('\n')[0].slice(0, 90)),
        el('button', { type: 'button', class: 'oc-btn oc-btn--sm oc-btn--ghost', onClick: async (e) => { e.preventDefault(); e.stopPropagation(); if (await Orch.confirm(`Remove the template "${t.name}"? Posts written with it stay as they are.`, { yes: 'Remove' }) && await act(A.updateTemplate, { id: t._id, dropped: 'yes' }, 'Removed.')) again(); } }, 'Remove')]),
      el('pre', { class: 'po-refs po-tpl__body' }, t.body || ''),
    ]))) : null,
    f,
  ]);
}
