// The accounts in Settings: each one on or off, its posting times (the days
// and hours its posts go out, in the workspace's zone — Postiz's
// postingTimes) and what to do once a post does well: repost it (LinkedIn),
// or add a first comment / self-reply (Postiz's auto plug).
import { A, C, INTEGRATIONS, PORTAL, X_DOOR, act, ago, area, field, input, net } from '../data.js';

const { el } = Orch;

export function accountsSection(s, list, again) {
  const look = el('button', { type: 'button', class: 'oc-btn' }, list.length ? 'Look for accounts again' : 'Look for accounts');
  look.addEventListener('click', async () => { look.disabled = true; look.textContent = 'Looking…'; if (await act(A.findAccounts, { id: s._id })) setTimeout(again, 8000); });
  const on = list.filter((a) => a.active === 'yes').length;
  return el('section', { class: 'oc-card oc-stack po-form po-accounts-card' }, [
    el('div', { class: 'oc-row oc-row--between' }, [el('div', { class: 'po-account__name' }, [el('h2', { class: 'oc-h2' }, 'Accounts'),
      el('span', { class: 'oc-help' }, `${on} of ${list.length} on${s.accounts_at ? ` · looked ${ago(s.accounts_at)}` : ''}`)]), look]),
    el('p', { class: 'oc-help' }, ['Each LinkedIn profile and company page is its own account: a post goes to exactly one. Turn on only the ones Posts writes for. Connect networks in ', PORTAL(INTEGRATIONS), '; X in ', PORTAL(X_DOOR), '.']),
    s.accounts_note ? el('p', { class: 'po-warn' }, s.accounts_note) : null,
    list.length ? el('div', { class: 'po-accounts' }, list.map((a) => accountCard(s, a, again))) : el('p', { class: 'po-empty' }, 'No accounts yet: connect a network, then look for accounts.'),
    el('details', { class: 'po-details' }, [el('summary', 'What X costs'), el('p', { class: 'oc-help' }, 'X posts go out with your own X keys. X charges about US$0.015 a post, US$0.20 with a link, and a small amount for each read of the numbers.')]),
  ]);
}

function accountCard(s, a, again) {
  const slots = C.slotsOf(a.slots);
  const days = new Set(slots.map((x) => x.d));
  const times = [...new Set(slots.map((x) => x.t))].join(', ');
  const ticks = C.DAYS.map((d, i) => {
    const box = el('input', { type: 'checkbox', checked: days.has(i + 1), 'aria-label': d });
    return { box, node: el('label', { class: 'po-day-tick' }, [box, el('span', d)]) };
  });
  const timeIn = input(times, { maxlength: '120', placeholder: '09:00, 13:30', 'aria-label': 'Times' });
  const isLi = a.network === 'linkedin';
  const repost = input(a.repost_at || '', { type: 'number', min: '1', max: '100000', placeholder: 'off', 'aria-label': 'Repost at this many reactions' });
  const replyAt = input(a.reply_at || '', { type: 'number', min: '1', max: '100000', placeholder: 'off', 'aria-label': 'First comment at this many reactions' });
  const replyText = area(a.reply_text || '', 2, { maxlength: '1200', placeholder: a.network === 'x' ? 'A reply under your post: the link, the next step…' : 'A first comment: the link, the sign-up, the next step…' });
  // X Premium lets the account post up to 25,000 characters; without it, each post is 280 (a longer idea becomes a thread).
  const premium = a.network === 'x' ? el('input', { type: 'checkbox', checked: a.premium === 'yes', 'aria-label': 'This account has X Premium' }) : null;
  const save = el('button', { type: 'submit', class: 'oc-btn oc-btn--sm oc-btn--primary' }, 'Save');
  const toggle = el('button', { type: 'button', class: `oc-btn oc-btn--sm${a.active === 'yes' ? '' : ' oc-btn--primary'}` }, a.active === 'yes' ? 'Turn off' : 'Turn on');
  toggle.addEventListener('click', async () => { toggle.disabled = true; if (await act(A.updateAccount, { id: a._id, active: a.active === 'yes' ? 'no' : 'yes' }, a.active === 'yes' ? 'Off: nothing more is written or published for it.' : 'On.')) again(); });
  toggle.addEventListener('click', (e) => e.stopPropagation(), true);
  // Which Integrations connection it goes through: with two LinkedIn connections, the one it uses.
  const kind = `${a.kind === 'person' ? 'Profile' : a.kind === 'organization' ? 'Page' : C.netOf(a.network).kinds[a.kind] || a.kind} on ${net(a.network)}${a.handle ? ` · ${a.network === 'x' ? '@' : ''}${a.handle}` : ''}${a.connection ? ` · through “${a.connection}”` : ''}`;
  const f = el('form', { class: 'po-account__form' }, [
    a.note ? el('p', { class: 'po-bad' }, a.note) : null,
    field('Posting times', el('div', { class: 'oc-stack' }, [el('div', { class: 'po-days' }, ticks.map((t) => t.node)), timeIn]), `${C.slotsSaid(slots, 'en')} · ${s.timezone || 'UTC'}`),
    el('div', { class: 'po-two' }, [
      isLi ? field('Repost it at', repost, 'reactions; once') : null,
      field(a.network === 'x' ? 'Reply under it at' : 'First comment at', replyAt, a.network === 'x' ? 'likes + reposts; X is read a day and a week after' : 'reactions; once'),
    ]),
    field(a.network === 'x' ? 'The reply' : 'The comment', replyText),
    premium ? el('label', { class: 'po-day-tick po-premium' }, [premium, el('span', 'This account has X Premium: long posts, up to 25,000 characters')]) : null,
    premium ? el('p', { class: 'oc-help' }, 'Without it each post is at most 280 characters, and a longer idea goes out as a thread. Either way Posts writes short posts or threads; with it, also a long post when the idea needs room.') : null,
    el('div', { class: 'oc-row' }, save),
  ]);
  const plugs = [a.repost_at ? `repost at ${a.repost_at}` : null, a.reply_at ? `${a.network === 'x' ? 'reply' : 'comment'} at ${a.reply_at}` : null].filter(Boolean).join(' · ');
  const box = el('details', { class: `po-account${a.active === 'yes' ? '' : ' po-account--off'}` }, [
    el('summary', { class: 'po-account__sum' }, [
      el('span', { class: 'po-account__name' }, [el('span', { class: 'po-account__title' }, a.name), el('span', { class: 'oc-help' }, kind)]),
      el('span', { class: 'po-account__when' }, [el('span', slots.length ? C.slotsSaid(slots, 'en') : 'No posting times'), plugs ? el('span', { class: 'oc-help' }, plugs) : null]),
      el('span', { class: `oc-badge${a.active === 'yes' ? ' oc-badge--good' : ''}` }, a.active === 'yes' ? 'On' : 'Off'),
      toggle,
    ]),
    f,
  ]);
  f.addEventListener('submit', async (e) => {
    e.preventDefault();
    const picked = ticks.map((t, i) => (t.box.checked ? i + 1 : 0)).filter(Boolean);
    const next = C.slotsFrom(picked, timeIn.value);
    if (!next.length) { timeIn.focus(); Orch.toast('Tick at least one day and write a time like 09:00.', { error: true }); return; }
    if (replyAt.value && !String(replyText.value).trim()) { replyText.focus(); Orch.toast('Write the comment, or leave its number empty.', { error: true }); return; }
    save.disabled = true;
    const num = (x) => (String(x.value).trim() ? Math.max(1, Math.round(Number(x.value))) : null);
    if (await act(A.updateAccount, { id: a._id, slots: JSON.stringify(next), repost_at: isLi ? num(repost) : null, reply_at: num(replyAt), reply_text: String(replyText.value).trim() || null, ...(premium ? { premium: premium.checked ? 'yes' : 'no' } : {}) }, 'Saved.')) again();
    save.disabled = false;
  });
  return box;
}
