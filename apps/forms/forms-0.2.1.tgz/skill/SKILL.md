---
name: app-forms
version: 0.2.1
description: >-
  Make and run forms people answer one question at a time (a Typeform
  replacement on this workspace): write a form from what the person
  describes, save it as a draft, publish it only when they say so, share its
  link, and read back what people answered. Use when someone asks for a form,
  survey, questionnaire, registration, sign-up, application, feedback or NPS
  form, or asks "what did people answer", "how many signed up", "close the
  form", "import my Typeforms"; in Spanish "haceme un formulario", "armame una
  encuesta", "un formulario de inscripción", "qué respondieron", "cuántos se
  anotaron", "cerrá el formulario", "pasame el link del formulario". Needs the
  Forms app installed in a project you work in.
metadata:
  openclaw:
    emoji: "📝"
---
# Forms — make a form, publish it when told, read what came back

The Forms app keeps every form as a definition (Typeform's form JSON, a
subset) and every answer in the project's database. One tool writes for you:
it checks the definition with the same rules the form page uses and tells you
what is wrong.

## Where it lives

```bash
ls -d ~/.openclaw/orchestra/projects/*/apps/forms     # one line per project with Forms
F=~/.openclaw/orchestra/projects/<project>/apps/forms/automations/forms.js
node "$F" format          # the rules of a definition, and an example — read it before writing one
```

The project is the directory name under `projects/`; the tool works on the
project it is installed in. If nothing is listed, Forms is not installed in a
project you work in: say so, and do not improvise a form some other way.
The app's own screens: `orch-canvas url forms` (the desk) and `orch-canvas url form`
(the public page).

## The model

| Table | One row per |
|---|---|
| `forms_forms` | form: `slug` (its link name), `title`, `status`, `draft` (JSON being edited), `version` (the live one, 0 before the first publish), `responses` (count of Complete), `closes_at`, `max_responses`, `archived` |
| `forms_versions` | publication: `form_id`, `version`, `definition` (what people answer). Never changed after |
| `forms_responses` | person who sent: `answers` (JSON by question ref), `hidden`, `status`, `problem` (why Spam/Rejected), `email` |
| `forms_answers` | one answer (one per option chosen), written only by processing; feeds the totals |
| `forms_settings` | one row: language, notifications, public and desk URLs, Typeform import status |
| `forms_templates` | templates to start from |

Form status: `Draft` (new, nobody can answer) → `Live` (publish; each publish
makes version N+1 in `forms_versions`) → `Closed` (closed by hand, or
automatically at its `max_responses`; a response after `closes_at` is
rejected) → `Live` again (reopen). Saving changes the `draft` only: the live
version stays as it was until the next publish, and every response keeps the
version it answered. Archived forms are hidden from `list` (`--all` shows them).

Response status: `New` (just arrived) → set by processing, seconds later or
within half an hour: `Complete`, `Spam` (bot trap, or answered in under 2 s)
or `Rejected` (form closed, missing or wrong answers, sent twice). In the app
a person can also mark `Spam`, undo it (back to `New`), `Deleted` (hidden,
restorable) and `Erased` (content emptied for good). Totals and `responses`
count only `Complete` by default.

## How you act

Use `forms.js` for everything it does; it validates. Do not write the
`forms_*` tables with `orch-database`. Reading them with `orch-database
--project <p> query "SELECT …"` is fine (filter `_deleted = 0`).

Every command prints one JSON line. `ok: false` comes with `errors`, each
with a `path` and a `message` (or one `error`): fix those and run it again.
`<form>` is the form's id or its link name.

| To | Run |
|---|---|
| Check a definition | `node "$F" validate --file /tmp/form.json` |
| Save a new draft | `node "$F" save --file /tmp/form.json [--slug my-link-name]` (prints id, link name, `link`, `edit`) |
| Save a new draft of a form | `node "$F" save --form <form> --file /tmp/form.json` |
| Publish (only with the person's yes) | `node "$F" publish <form>` |
| Close / reopen | `node "$F" close <form>` · `node "$F" reopen <form>` |
| List the forms | `node "$F" list [--all]` |
| Read one | `node "$F" get <form> [--published]` (the draft, or the live version) |
| What people answered | `node "$F" responses <form> [--since YYYY-MM-DD] [--limit 20] [--status Spam]` |
| The totals per question | `node "$F" summary <form>` |
| The link, with values for hidden fields | `node "$F" link <form> --hidden utm_source=newsletter` |

`--definition '<json>'` or `--b64 <base64>` work instead of `--file`. Hidden
field names must be lower-case letters, digits and `_`; others are dropped.
Only a Live form can be closed, only a Closed one reopened.

Spam, delete, erase, archive, closing date, response limit and notifications
are set by a person in the app (the desk link above).

## Making a form

1. Ask what you need to, not more. Who answers it, what the person needs to
   learn from them, and anything that changes the path ("if they are already
   customers, ask the plan"). The language: the one the people answering speak.
2. Write the definition in a file, following `format`:
   - Short questions, one idea each, in the language of the people answering;
     in Spanish, tú.
   - Mark as required only what is essential.
   - Use jumps only where the request needs a different path.
   - Add a consent question (`legal`) when you ask for personal data.
   - Earlier answers can appear in later questions: `{{field:<ref>}}`.
3. Save it as a draft with `save`. If it answers `ok: false`, fix what each
   error names and save again; never hand the person a form that did not save.
4. Show the person the questions in a few lines and the `edit` link (the
   builder, with a preview). Say it is a draft: nobody can answer it yet.
5. Publish only when they say so, with `publish`. Then give them the `link`.
   A published form is answered by anyone who has the link.

Changing a live form: `save --form <form>` stores a new draft and changes
nothing for the people answering until it is published again; answers already
in keep the questions they answered.

## Reading what came back

- "How is the form doing?" → `summary`: how many answered, and each question's
  answers counted per option, averaged, or quoted, with the NPS.
- "What did they say?" → `responses`, newest first; `--since` for the recent
  ones. Quote people's words; never invent or tidy them.
- "Why is one missing?" → `responses <form> --status Rejected` (or `Spam`,
  `New`): each has a `problem` that says why.
- Still `New` after a while: run the processing now. Its id is `intake` in
  `~/.openclaw/orchestra/projects/<project>/apps/forms/workflows.json`:
  `orch-workflows run <id> --args '{"mode":"--now"}'`.

## Importing from Typeform

Only when the person asks. It needs Typeform connected in the portal
(Integrations). It reads Typeform only and brings forms in as drafts, with
their completed answers. Run the workflow whose id is `typeform` in
`workflows.json`: `orch-workflows run <id> --args '{"mode":"--start"}'`. A big
account takes several runs; a half-hourly check goes on by itself. Progress:
`orch-database --project <p> query "SELECT typeform_status, typeform_note FROM forms_settings WHERE _deleted = 0"`
(`Partial`, `Done`, `Failed`, `Not connected`).

## Other apps

- CRM: when CRM is installed in the same project and "Leads from Forms" is on
  in its Settings (on by default), its workflow "CRM · Leads from Forms"
  (every half hour, or Check Forms now in the CRM) turns each Complete response
  with an email into a contact (status Lead, source Forms) or updates the one
  with that address, and adds a `form` activity with the answers. It only reads
  Forms. Ask for an email question if the form should feed the CRM.
- No other app reads or writes Forms today.

## Never

- Publish, close or reopen without the person asking for it in this conversation.
- Write to the `forms_*` tables directly, or edit an answer.
- Delete or erase responses: the person does that in the app, which asks twice.
- Send the link to people yourself unless the person asked you to and said to whom.
- Put an email, a phone or a name into a link's hidden fields: anyone with the link can read them.
