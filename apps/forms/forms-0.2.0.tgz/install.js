// Forms, installed into one project of this instance: tables and indexes, the
// seed (settings and templates, only into empty tables), the automations
// (scripts, workflows, the half-hourly check), the two Canvas apps (`forms`,
// the desk; `form`, the public page) with their grants, views, actions, brand
// and brief, the public URLs, and the agents' skill when it can be written.
// Converges: run it again after a change and it ends in the same state.
//
// The same file runs both ways a tenant gets an app:
//   as node, by the team over ssh:        gosu node node install.js <bundle> --project default --agent leila
//   as the project's agent, over the MCP: projects.run → node <bundle>/install.js <bundle> --project default --agent leila
// Over the MCP each call has 120 s: run it in parts with --only (in this order):
//   --only files,tables,seed  ·  --only workflows,schedule  ·  --only desk  ·  --only public,settings,skill
// Prints one JSON line per step, and at the end what a person still has to do.
'use strict';
const { execFileSync } = require('child_process');
const fs = require('fs');
const path = require('path');

const B = path.resolve(process.argv[2] || __dirname);
const flag = (name, fallback) => { const i = process.argv.indexOf(`--${name}`); return i > 0 && process.argv[i + 1] ? process.argv[i + 1] : fallback; };
const PROJECT = flag('project', 'default');
const AGENT = flag('agent', '');
const LANG = flag('language', 'es');
const ONLY = new Set((flag('only', 'files,tables,seed,workflows,schedule,desk,public,settings,skill')).split(','));
const STATE = process.env.OPENCLAW_STATE_DIR || '/home/node/.openclaw';
const HOME = path.join(STATE, 'orchestra', 'projects', PROJECT);
const AUTO = path.join(HOME, 'apps', 'forms', 'automations');
const read = (f) => fs.readFileSync(path.join(B, f), 'utf8');
const json = (f) => JSON.parse(read(f));
const todo = [];
const out = (step, data) => console.log(JSON.stringify(Object.assign({ step }, data)));

function cli(bin, args, { soft = false } = {}) {
  let text;
  try {
    text = execFileSync(bin, args, { encoding: 'utf8', timeout: 100000, maxBuffer: 32 << 20 });
  } catch (e) {
    text = String(e.stdout || '') || String(e.stderr || e.message);
    if (!soft) out('warn', { bin, args: args.slice(0, 3), said: text.trim().slice(0, 300) });
  }
  try { return JSON.parse(text); } catch { return { raw: String(text).trim().slice(0, 600) }; }
}
const db = (...a) => cli('orch-database', ['--project', PROJECT, ...a]);
const canvas = (...a) => cli('orch-canvas', a);
const wf = (...a) => cli('orch-workflows', a);
const pick = (o, keys) => Object.fromEntries(keys.filter((k) => o && o[k] !== undefined).map((k) => [k, o[k]]));
const ids = () => { try { return JSON.parse(fs.readFileSync(path.join(AUTO, '..', 'workflows.json'), 'utf8')); } catch { return {}; } };

// ── 1. the automation scripts ────────────────────────────────────────────
if (ONLY.has('files')) {
  fs.mkdirSync(AUTO, { recursive: true });
  for (const f of fs.readdirSync(path.join(B, 'automations'))) fs.copyFileSync(path.join(B, 'automations', f), path.join(AUTO, f));
  out('files', { dir: AUTO, files: fs.readdirSync(AUTO) });
}

// ── 2. tables and indexes ────────────────────────────────────────────────
const schema = json('schema.json');
if (ONLY.has('tables')) {
  for (const [table, cols] of Object.entries(schema.tables)) {
    out('table', Object.assign({ table }, pick(db('ensure-table', table, '--columns', ...cols), ['ok', 'action', 'created', 'added', 'error', 'raw'])));
  }
  for (const sql of schema.indexes) out('index', Object.assign({ sql: sql.slice(0, 80) }, pick(db('sql', sql, '--confirm'), ['ok', 'error', 'raw'])));
}

// ── 3. seed, only into empty tables ──────────────────────────────────────
if (ONLY.has('seed')) {
  const count = (t) => (((db('query', `SELECT COUNT(*) AS n FROM ${t} WHERE _deleted = 0`).rows || [{}])[0]) || {}).n;
  const brand = json('brand.json');
  for (const [table, rows] of Object.entries(json('seed.json'))) {
    if (count(table) > 0) { out('seed', { table, left: 'it has rows' }); continue; }
    const data = rows.map((r) => Object.fromEntries(Object.entries(r).map(([k, v]) => [k, v !== null && typeof v === 'object' ? JSON.stringify(v) : v])));
    if (table === 'forms_settings') Object.assign(data[0], { language: LANG, agent: AGENT, accent: presetAccent(brand.form) });
    out('seed', Object.assign({ table }, pick(db('insert-many', table, '--data', JSON.stringify(data)), ['ok', 'count', 'inserted', 'error', 'raw'])));
  }
}

function presetAccent(spec) {
  if (spec.brand && spec.brand.accent) return spec.brand.accent;
  const presets = cli('orch-canvas', ['brand', 'presets'], { soft: true });
  const p = (presets.presets || []).find((x) => x.name === spec.preset);
  return (p && p.brand && p.brand.accent) || '';
}

// ── 4. workflows (by name: created once, updated after) ─────────────────
if (ONLY.has('workflows')) {
  if (!AGENT) throw new Error('--agent <id> names the agent that drafts forms with AI (a member of the project)');
  const existing = wf('list').workflows || [];
  const WF = {};
  const tmp = fs.mkdtempSync('/tmp/forms-wf-');
  for (const key of ['intake', 'erase', 'save', 'draft', 'typeform']) {
    // runsAs: the scripts run as this agent (orch-as), so it must be a member of the project to reach its database.
    const spec = Object.assign(JSON.parse(read(`workflows/${key}.json`).replace(/__AUTO__/g, AUTO).replace(/__AGENT__/g, AGENT)),
      { project: PROJECT, runsAs: AGENT });
    const file = path.join(tmp, `${key}.json`);
    fs.writeFileSync(file, JSON.stringify(spec));
    const found = existing.find((w) => w.name === spec.name);
    const r = found ? wf('update', found.id, '--file', file) : wf('create', '--file', file);
    WF[key] = found ? found.id : ((r.workflow && r.workflow.id) || r.id || r.workflowId);
    out('workflow', { name: spec.name, id: WF[key], did: found ? 'updated' : 'created', error: r.error || undefined });
  }
  fs.rmSync(tmp, { recursive: true, force: true });
  fs.writeFileSync(path.join(AUTO, '..', 'workflows.json'), JSON.stringify(WF, null, 1));
}

// ── 5. the half-hourly checks, for what a start did not finish ──────────
// The public page starts processing as soon as a response is saved; the first
// check only runs when something is still New, so it costs nothing on a quiet
// day. The second goes on with a Typeform import only while one is under way.
if (ONLY.has('schedule')) {
  const WF = ids();
  for (const [key, cron, name] of [
    ['intake', '*/30 * * * *', 'Forms · Process responses (half-hourly check)'],
    ['typeform', '17,47 * * * *', 'Forms · Import from Typeform (half-hourly, while an import is under way)'],
  ]) {
    if (!WF[key]) { out('schedule', { workflow: key, error: 'not created yet: run --only workflows first' }); continue; }
    for (const s of (wf('schedules', WF[key]).schedules || [])) out('unschedule', pick(wf('unschedule', s.jobId), ['ok', 'error']));
    out('schedule', Object.assign({ workflow: key }, pick(wf('schedule', WF[key], '--cron', cron, '--timezone', 'UTC', '--name', name,
      '--table', 'forms_settings', '--where', read(`workflows/${key}.where`), '--limit', '1'), ['ok', 'jobId', 'schedule', 'error', 'raw'])));
  }
}

// ── 6. the apps ──────────────────────────────────────────────────────────
function app(id, src, brief) {
  let a = (canvas('list').apps || []).find((x) => x.id === id);
  if (!a) {
    out('init', Object.assign({ app: id }, pick(canvas('init', id, '--project', PROJECT, '--pattern', 'list', '--confirmed', ...brief), ['ok', 'dir', 'url', 'error', 'raw'])));
    a = (canvas('list').apps || []).find((x) => x.id === id);
  }
  if (!a) throw new Error(`The app ${id} could not be created`);
  const dir = path.join(STATE, 'orchestra', a.dir);
  const ours = new Set();
  const copy = (from, to) => {
    for (const f of fs.readdirSync(from)) {
      const s = path.join(from, f);
      const d = path.join(to, f);
      if (fs.statSync(s).isDirectory()) { fs.mkdirSync(d, { recursive: true }); copy(s, d); } else { fs.copyFileSync(s, d); ours.add(path.relative(dir, d)); }
    }
  };
  copy(path.join(B, src), dir);
  // What the starter wrote and Forms does not use goes, so the app is exactly the source.
  const sweep = (d) => {
    for (const f of fs.readdirSync(d)) {
      const p = path.join(d, f);
      const rel = path.relative(dir, p);
      if (rel.startsWith('_') || rel.startsWith('.')) continue;
      if (fs.statSync(p).isDirectory()) sweep(p); else if (!ours.has(rel)) { fs.unlinkSync(p); out('removed', { app: id, file: rel }); }
    }
  };
  sweep(dir);
  out('files', { app: id, dir, count: ours.size });
  return a;
}

function actions(id, list) {
  const WF = ids();
  const sub = (v) => (typeof v === 'string' && v.startsWith('$WF_') ? WF[v.slice(4).toLowerCase()] : v);
  for (const a of list) {
    const args = ['action', 'add', id, '--name', a.name, '--type', a.type, '--access', a.access || 'members'];
    if (a.table) args.push('--table', a.table);
    if (a.fields) args.push('--fields', a.fields.join(','));
    if (a.defaults) args.push('--defaults', JSON.stringify(a.defaults));
    if (a.precondition) args.push('--precondition', JSON.stringify(a.precondition));
    if (a.bulk) args.push('--bulk');
    if (a.steps) args.push('--steps', JSON.stringify(a.steps));
    if (a.workflow) args.push('--workflow', sub(a.workflow));
    if (a.args) args.push('--args', JSON.stringify(a.args));
    if (a.trigger) args.push('--trigger-workflow', sub(a.trigger));
    out('action', Object.assign({ app: id, name: a.name }, pick(canvas(...args), ['ok', 'error', 'raw'])));
  }
}

function brand(id, spec) {
  const args = ['brand', 'set', id, '--preset', spec.preset];
  for (const [k, v] of Object.entries(spec.brand || {})) args.push(`--${k}`, v);
  out('brand', Object.assign({ app: id }, pick(canvas(...args), ['ok', 'error', 'raw'])));
}

if (ONLY.has('desk')) {
  app('forms', 'app', ['--name', 'Forms', '--icon', '📝', '--desc', 'Forms people answer one question at a time: make them, publish them, read what came back',
    '--user', 'The team that asks customers, applicants or attendees for information: marketing, sales, operations, people',
    '--frequency', 'When a form is made, then a few times a week to read the answers',
    '--question', 'Which forms do I have, which are open, and how many answers did each bring?',
    '--question', 'What did people answer: each response, and every question counted?',
    '--question', 'What came in since I last looked?',
    '--primary-action', 'Make a form (from a description, a template or blank), publish it and share its link']);
  const grants = Object.keys(schema.tables).map((t) => `${t}:${['forms_answers', 'forms_templates'].includes(t) ? 'read' : 'action'}`);
  // One --grant with every table: the flag is nargs="*", so repeating it keeps only the last.
  const g = canvas('grants', 'set', 'forms', '--grant', ...grants);
  out('grants', Object.assign({ app: 'forms' }, pick(g, ['ok', 'grants', 'pendingApproval', 'error', 'raw'])));
  if ((g.pendingApproval || []).length) todo.push(`Approve the tables Forms asks for: ${g.pendingApproval.map((x) => x.table || x).join(', ')} (Canvas → Forms → who gets in)`);
  for (const f of fs.readdirSync(path.join(B, 'sql'))) {
    const r = canvas('view', 'add', 'forms', '--name', f.replace(/\.sql$/, ''), '--sql-file', path.join(B, 'sql', f), '--description', f.replace(/\.sql$/, '').replace(/_/g, ' '));
    out('view', Object.assign({ app: 'forms', name: f }, pick(r, ['ok', 'reads', 'pending', 'error', 'raw'])));
  }
  actions('forms', json('actions.json'));
  brand('forms', json('brand.json').forms);
  out('brief', pick(canvas('brief', 'set', 'forms', '--density', 'balanced', '--variety', 'focused', '--confirmed'), ['ok', 'error', 'raw']));
}

if (ONLY.has('public')) {
  app('form', 'public', ['--name', 'Form', '--icon', '📝', '--desc', 'The page people answer a Forms form on, one question at a time',
    '--user', 'Anyone with the link to a form: customers, applicants, attendees',
    '--frequency', 'Once, when they answer',
    '--question', 'What am I asked, and how much is left?',
    '--primary-action', 'Answer the questions and send them']);
  const r = canvas('view', 'add', 'form', '--name', 'published_forms', '--access', 'public', '--sql-file', path.join(B, 'public-sql', 'published_forms.sql'),
    '--description', 'The published version of each open or closed form: its link name, its questions and its closing message. Never drafts or answers.');
  out('view', Object.assign({ app: 'form', name: 'published_forms' }, pick(r, ['ok', 'pending', 'status', 'error', 'raw'])));
  actions('form', json('public-actions.json'));
  brand('form', json('brand.json').form);
  todo.push('Approve the public list "published_forms" for the internet (Canvas → Form → the first tab)');
  todo.push('Set Form to Public, and publish both apps (Canvas → Form, Canvas → Forms → Historial)');
}

// ── 7. where the apps live, for the links the scripts and agents give out ──
if (ONLY.has('settings')) {
  const url = (id) => { const u = canvas('url', id).url || ''; return u.endsWith('/') ? u : (u ? `${u}/` : ''); };
  const s = (db('query', 'SELECT _id FROM forms_settings WHERE _deleted = 0 ORDER BY _id LIMIT 1').rows || [])[0];
  if (s) {
    const data = { public_url: url('form'), desk_url: url('forms'), installed_version: read('VERSION').trim() };
    if (AGENT) data.agent = AGENT;
    out('settings', Object.assign(data, pick(db('update', 'forms_settings', '--id', String(s._id), '--data', JSON.stringify(data)), ['ok', 'error'])));
  }
}

// ── 8. the agents' skill: how to make a form from a conversation ────────
if (ONLY.has('skill')) {
  const target = path.join(STATE, 'workspace', 'skills', 'forms');
  try {
    fs.mkdirSync(target, { recursive: true });
    fs.copyFileSync(path.join(B, 'skill', 'SKILL.md'), path.join(target, 'SKILL.md'));
    out('skill', { installed: target });
  } catch (e) {
    out('skill', { installed: false, why: e.code || e.message });
    todo.push('Install the "forms" skill for the agents (Skills → catalogue, or skills.install over the MCP)');
  }
}

out('done', { project: PROJECT, a_person_still_has_to: todo });
