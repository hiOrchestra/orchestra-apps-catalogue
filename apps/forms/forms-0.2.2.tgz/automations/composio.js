'use strict';
/**
 * Every call Forms makes to Composio, and nothing else: the Typeform tool
 * slugs, their arguments, and how each answer is read. When Composio renames
 * a tool or an argument, this is the only file to change. Read only: nothing
 * here writes to Typeform.
 *
 *   listForms(page)               TYPEFORM_LIST_FORMS            one page of the account's forms
 *   getForm(id)                   TYPEFORM_GET_FORM              one form's definition
 *   responsesPage(id, before)     TYPEFORM_GET_FORM_RESPONSES    one page of completed responses, newest first
 *
 * Scripts reach Composio through the instance (POST 127.0.0.1:3001
 * /api/composio/execute {toolSlug, arguments}) as the workflow's agent; the
 * platform key never enters the container.
 *
 * FORMS_FAKE_COMPOSIO=1 answers from FORMS_FAKE_DATA (a JSON file:
 * { typeform: { forms: [{ ...definition, responses: [...] }], fail } }): the
 * tests never reach Typeform. fail: "not-connected" answers the way Composio
 * does for an account with no Typeform; any other text fails every call with it.
 */
const http = require('http');
const fs = require('fs');
const { identityHeaders } = require('./lib');

const FAKE = process.env.FORMS_FAKE_COMPOSIO === '1';
const SLUG = { list: 'TYPEFORM_LIST_FORMS', form: 'TYPEFORM_GET_FORM', responses: 'TYPEFORM_GET_FORM_RESPONSES' };
const LIST_SIZE = 200; // Typeform's most per page of forms
const PAGE_SIZE = Number(process.env.FORMS_TYPEFORM_PAGE) || 200;

/** One Composio tool: its `data`, or an Error with Composio's own sentence. */
function execute(slug, args, { timeoutMs = 90000 } = {}) {
  if (FAKE) return fake(slug, args);
  return new Promise((resolve, reject) => {
    const body = JSON.stringify({ toolSlug: slug, arguments: args });
    const req = http.request({
      hostname: '127.0.0.1', port: Number(process.env.API_SERVER_PORT || 3001), path: '/api/composio/execute', method: 'POST', agent: false,
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body), ...identityHeaders() },
    }, (res) => {
      let b = '';
      res.on('data', (c) => { b += c; });
      res.on('end', () => {
        let j;
        try { j = JSON.parse(b); } catch { return reject(new Error(`Composio answered ${res.statusCode}: ${b.slice(0, 200)}`)); }
        if (j && j.success && j.data && j.data.successful !== false) return resolve(j.data.data !== undefined ? j.data.data : j.data);
        const why = (j && j.data && j.data.error) || (j && j.error && (j.error.message || j.error)) || `HTTP ${res.statusCode}`;
        return reject(new Error(String(why).slice(0, 300)));
      });
    });
    req.on('error', reject);
    req.setTimeout(timeoutMs, () => req.destroy(new Error(`Composio did not answer in ${timeoutMs / 1000}s`)));
    req.end(body);
  });
}

/**
 * Composio's words when the workspace has no Typeform account. Its exact
 * sentence was not seen on a live instance, so this matches the ways it says
 * "no connection" (and Typeform's own 401/403 for a revoked one).
 */
const NOT_CONNECTED = /not connected|no (active )?connect|connected.?account.*(not found|missing|required)|no .*account.*(found|for)|connectedaccountnotfound|auth(entication)? (config )?(required|not found)|\b401\b|unauthori[sz]ed|invalid.*token/i;
const notConnected = (e) => NOT_CONNECTED.test(String((e && e.message) || e));

/** The first array under `key` anywhere in a nested answer (Composio wraps answers differently per tool). */
function arrayAt(obj, key, depth = 0) {
  if (!obj || typeof obj !== 'object' || depth > 4) return null;
  if (Array.isArray(obj[key])) return obj[key];
  for (const v of Object.values(obj)) {
    const found = arrayAt(v, key, depth + 1);
    if (found) return found;
  }
  return null;
}
/** The first object that has `key` as an array, anywhere in a nested answer. */
function objectWith(obj, key, depth = 0) {
  if (!obj || typeof obj !== 'object' || depth > 4) return null;
  if (Array.isArray(obj[key])) return obj;
  for (const v of Object.values(obj)) {
    const found = objectWith(v, key, depth + 1);
    if (found) return found;
  }
  return null;
}
const numberAt = (obj, key) => {
  const o = objectWith(obj, 'items') || obj || {};
  return Number(o[key]) || 0;
};

/** One page of the account's forms: { forms: [{ id, title }], more }. Pages start at 1. */
async function listForms(page = 1) {
  const r = await execute(SLUG.list, { page, page_size: LIST_SIZE });
  const items = arrayAt(r, 'items') || [];
  const pages = numberAt(r, 'page_count');
  return {
    forms: items.map((f) => ({ id: String(f.id || ''), title: String(f.title || '') })).filter((f) => f.id),
    more: pages ? page < pages : items.length === LIST_SIZE,
  };
}

/** One form's definition, as Typeform keeps it. */
async function getForm(id) {
  const r = await execute(SLUG.form, { form_id: id });
  const def = objectWith(r, 'fields') || (r && typeof r === 'object' ? r : null);
  if (!def) throw new Error(`Typeform sent no definition for form ${id}`);
  return def;
}

/**
 * One page of a form's completed responses, newest first: { items, before }.
 * `before` is the token to ask the next (older) page with; null on the last page.
 */
async function responsesPage(id, before) {
  const args = { form_id: id, page_size: PAGE_SIZE, sort: 'submitted_at,desc', response_type: 'completed' };
  if (before) args.before = before;
  const r = await execute(SLUG.responses, args);
  const items = (arrayAt(r, 'items') || []).filter((x) => x && (x.token || x.response_id));
  const last = items[items.length - 1];
  return { items, before: items.length === PAGE_SIZE && last ? String(last.token || last.response_id) : null };
}

// ── the fake, for tests ──────────────────────────────────────────────────
function fakeData() {
  try { return JSON.parse(fs.readFileSync(process.env.FORMS_FAKE_DATA, 'utf8')); } catch { return {}; }
}
function fake(slug, args) {
  const t = fakeData().typeform || {};
  if (process.env.FORMS_FAKE_CALLS) fs.appendFileSync(process.env.FORMS_FAKE_CALLS, `${JSON.stringify({ slug, args })}\n`);
  if (t.fail === 'not-connected') return Promise.reject(new Error('No connected account found for user default and toolkit typeform'));
  if (t.fail) return Promise.reject(new Error(t.fail));
  const forms = t.forms || [];
  if (slug === SLUG.list) {
    const size = Number(args.page_size) || 10;
    const from = (Math.max(1, Number(args.page) || 1) - 1) * size;
    return Promise.resolve({ data: { total_items: forms.length, page_count: Math.max(1, Math.ceil(forms.length / size)),
      items: forms.slice(from, from + size).map((f) => ({ id: f.id, title: f.title })) } });
  }
  const form = forms.find((f) => f.id === args.form_id);
  if (!form) return Promise.reject(new Error(`Typeform: form ${args.form_id} not found (fake)`));
  if (slug === SLUG.form) {
    const def = Object.assign({}, form);
    delete def.responses;
    return Promise.resolve({ response_data: def });
  }
  if (slug === SLUG.responses) {
    const all = (form.responses || []).slice().sort((a, b) => String(b.submitted_at).localeCompare(String(a.submitted_at)));
    const at = args.before ? all.findIndex((x) => x.token === args.before) + 1 : 0;
    const size = Number(args.page_size) || 25;
    return Promise.resolve({ data: { total_items: all.length, page_count: Math.ceil(all.length / size), items: all.slice(at, at + size) } });
  }
  return Promise.reject(new Error(`fake Composio has no ${slug}`));
}

module.exports = { SLUG, PAGE_SIZE, execute, listForms, getForm, responsesPage, notConnected, arrayAt, objectWith };
