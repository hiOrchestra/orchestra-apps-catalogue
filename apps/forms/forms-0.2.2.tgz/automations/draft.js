'use strict';
/**
 * Forms · Draft with AI, its two script steps around the agent's turn:
 *
 *   node draft.js pick <form id>   what the agent needs: the request, the language and the rules
 *   node draft.js save <form id>   the agent's answer ($PRIOR), checked with the form rules and
 *                                  saved as the form's draft; or the reason it was not
 *
 * The agent never writes to the database: it answers JSON, this checks and
 * saves it. Nothing is published; a person reviews the draft first.
 */
const L = require('./lib');
const { RULES, EXAMPLE } = require('./format');

const { F } = L;

function rowOf(id) {
  return /^\d+$/.test(String(id || '')) ? L.one('SELECT * FROM forms_forms WHERE _id = ? AND _deleted = 0', Number(id)) : null;
}

/** The language to write in: the request's own, else the workspace's. */
function languageOf(text, fallback) {
  const t = String(text || '').toLowerCase();
  if (/[áéíóúñ¿¡]/.test(t) || (t.match(/\b(el|la|los|las|de|que|para|una|un|con|por|del|quiero|necesito)\b/g) || []).length >= 2) return 'es';
  if ((t.match(/\b(the|and|for|with|of|to|a|an|we|our|want|need)\b/g) || []).length >= 2) return 'en';
  return F.LANGS.includes(fallback) ? fallback : 'es';
}

function pick(id) {
  const row = rowOf(id);
  if (!row) return { skip: true, why: `No form ${id}` };
  if (row.ai_status !== 'Working') return { skip: true, why: `Form ${id} is not waiting for a draft` };
  const s = L.settings();
  return { form: row._id, request: String(row.ai_request || '').slice(0, 4000), language: languageOf(row.ai_request, s.language),
    format: RULES, example: EXAMPLE };
}

/** The first {...} in what the agent wrote, fences and prose around it ignored. */
function jsonIn(text) {
  const t = String(text || '').replace(/```(?:json)?/gi, '');
  const a = t.indexOf('{');
  const b = t.lastIndexOf('}');
  if (a < 0 || b <= a) return null;
  try { return JSON.parse(t.slice(a, b + 1)); } catch { return null; }
}

function freeSlug(base, own) {
  const b = (F.slug(base).replace(/_/g, '-') || 'form').slice(0, 50);
  for (let i = 1; i < 500; i += 1) {
    const s = i === 1 ? b : `${b}-${i}`;
    const taken = L.one('SELECT _id FROM forms_forms WHERE slug = ?', s);
    if (!taken || taken._id === own) return s;
  }
  return `${b}-${own}`;
}

function save(id) {
  const row = rowOf(id);
  if (!row) return { ok: false, error: `No form ${id}` };
  if (row.ai_status !== 'Working') return { ok: true, skipped: 'This form was not waiting for a draft' };
  const fail = (note) => {
    L.write([{ op: 'update', table: 'forms_forms', id: row._id, when: { ai_status: 'Working' }, data: { ai_status: 'Failed', ai_note: note } }]);
    return { ok: false, form: row._id, failed: note };
  };
  const given = jsonIn(process.env.PRIOR);
  if (!given || !Object.keys(given).length) return fail('The agent did not answer with a form. Try again, or describe it differently.');
  const c = F.check(given);
  if (!c.ok) return fail(`The draft had problems: ${c.errors.slice(0, 3).map((e) => e.message).join('; ')}`);
  const data = { draft: JSON.stringify(c.def), title: c.def.title, ai_status: 'Done', ai_note: c.warnings.length ? c.warnings[0].message : null };
  if (String(row.slug || '').startsWith('draft-')) data.slug = freeSlug(c.def.title, row._id);
  L.write([{ op: 'update', table: 'forms_forms', id: row._id, when: { ai_status: 'Working' }, data }]);
  return { ok: true, form: row._id, title: c.def.title, questions: c.def.fields.length, slug: data.slug || row.slug };
}

if (require.main === module) {
  const [cmd, id] = process.argv.slice(2);
  let out;
  try { out = cmd === 'pick' ? pick(id) : cmd === 'save' ? save(id) : { ok: false, error: 'node draft.js pick|save <form id>' }; } catch (e) { out = { ok: false, error: e.message }; }
  L.done(out);
}

module.exports = { pick, save, jsonIn, languageOf };
