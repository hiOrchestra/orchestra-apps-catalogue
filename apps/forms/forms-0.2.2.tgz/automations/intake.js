'use strict';
/**
 * Forms · Process responses. Every response the public page left as New is
 * checked against the version of the form the person answered:
 *
 *   Complete  every question on their path is fine; its answers become one
 *             row each in forms_answers, for the summaries.
 *   Spam      the bot trap was filled, or it was answered in under 2 seconds
 *             (unless a person said it is not spam).
 *   Rejected  the form is gone, was closed before it arrived, an answer is
 *             missing or wrong, or the same sending arrived twice; `problem`
 *             says which.
 *
 * Nothing is deleted. A form that reaches its limit is closed, and the team
 * hears about what arrived: one line per form, on Telegram and/or by email.
 *
 * When it runs: the public page starts it as soon as a response is saved
 * (the public action `process`), a person can from the desk (Check them now),
 * and a check every half hour picks up whatever a start did not reach. No
 * agent turn: it is this script. One run works at a time; the others leave.
 *   node intake.js [--auto|--now]
 */
const L = require('./lib');

const { F } = L;
const BATCH = 100;
const BUDGET_MS = 90000; // the step has 120 s: stop taking more after this

function run(mode = '--auto') {
  const t0 = Date.now();
  const s = L.settings();
  let held = L.lock('intake');
  if (!held) return L.done({ ok: true, mode, processed: 0, skipped: 'Another run is processing the new responses' });

  const seen = new Set(); // what this run already looked at, whether or not it could save it
  const tally = { processed: 0, complete: 0, spam: 0, rejected: 0, failed: 0 };
  const arrived = new Map(); // form id -> [{ who }]
  const closed = [];
  const forms = new Map();
  const versions = new Map();
  const formOf = (id) => {
    if (!forms.has(id)) forms.set(id, L.one('SELECT * FROM forms_forms WHERE _id = ? AND _deleted = 0', Number(id)) || null);
    return forms.get(id);
  };
  const versionOf = (id, v) => {
    const key = `${id}:${v}`;
    if (!versions.has(key)) {
      const row = L.one('SELECT definition FROM forms_versions WHERE form_id = ? AND version = ? AND _deleted = 0', Number(id), Number(v));
      versions.set(key, row ? F.normalize(L.jsonOf(row.definition, {})) : null);
    }
    return versions.get(key);
  };
  const fresh = (limit) => L.all(`SELECT * FROM forms_responses WHERE _deleted = 0 AND status = 'New'${seen.size ? ` AND _id NOT IN (${[...seen].join(',')})` : ''} ORDER BY _id LIMIT ${limit}`);

  try {
    for (;;) {
      const news = fresh(BATCH);
      for (const r of news) {
        seen.add(r._id);
        processOne(r, formOf(r.form_id), versionOf(r.form_id, r.version), tally, arrived);
      }
      for (const id of new Set(news.map((r) => r.form_id))) {
        const title = settle(formOf(id));
        if (title) { closed.push(title); forms.delete(id); }
      }
      if (news.length === BATCH && Date.now() - t0 < BUDGET_MS) continue;
      // Let go, then look once more: a response saved while this run was
      // finishing was left to it by its own run, which found the lock taken.
      held.release();
      held = null;
      if (Date.now() - t0 >= BUDGET_MS || !fresh(1).length) break;
      held = L.lock('intake');
      if (!held) break; // another run has it, and will see them
    }
  } finally {
    if (held) held.release();
  }

  const notified = tell(s, arrived, formOf);
  return L.done(Object.assign({ ok: true, mode }, tally, { closed, notified }));
}

/** One response: its verdict saved with its answer rows, in one transaction that only applies while it is still New. */
function processOne(r, form, def, tally, arrived) {
  const verdict = judge(r, form, def);
  const ops = [{ op: 'update', table: 'forms_responses', id: r._id, when: { status: 'New' },
    data: { status: verdict.status, problem: verdict.problem || null, email: verdict.email || null,
      ending: verdict.ending || r.ending || null, processed_at: L.sqlNow() } }];
  for (const a of verdict.rows || []) {
    ops.push({ op: 'insert', table: 'forms_answers', data: Object.assign({ response_id: r._id, form_id: r.form_id, version: r.version }, a) });
  }
  try {
    L.write(ops);
  } catch (e) {
    tally.failed += 1;
    // Changed meanwhile (a person marked it, or another run had it): not ours.
    // Anything else would fail again on every run, so it is said once, on the response itself.
    if (!/precondition/.test(e.message)) {
      try {
        L.write([{ op: 'update', table: 'forms_responses', id: r._id, when: { status: 'New' },
          data: { status: 'Rejected', problem: `It could not be saved: ${e.message.slice(0, 200)}`, processed_at: L.sqlNow() } }]);
      } catch (e2) { /* changed meanwhile */ }
    }
    return;
  }
  tally.processed += 1;
  tally[verdict.status.toLowerCase()] += 1;
  if (verdict.status === 'Complete') {
    if (!arrived.has(r.form_id)) arrived.set(r.form_id, []);
    arrived.get(r.form_id).push({ who: verdict.who });
  }
}

/** The form's count and last response, from what is Complete; closed when it reached its limit. Returns its title when it closed it. */
function settle(f) {
  if (!f) return null;
  const c = L.one(`SELECT COUNT(*) AS n, MAX(_created_at) AS last FROM forms_responses WHERE form_id = ? AND _deleted = 0 AND status = 'Complete'`, Number(f._id));
  const data = { responses: c.n, last_response_at: c.last || null };
  const full = f.status === 'Live' && Number(f.max_responses) > 0 && c.n >= Number(f.max_responses);
  if (full) Object.assign(data, { status: 'Closed', closed_at: L.sqlNow(), closed_reason: `Reached its limit of ${f.max_responses} responses` });
  try {
    L.write([{ op: 'update', table: 'forms_forms', id: f._id, data }]);
    return full ? f.title : null;
  } catch (e) {
    return null; // counted again on the next run
  }
}

/** The verdict on one response: its status, why, the rows of its answers and who sent it. */
function judge(r, form, def) {
  if (!form || !def) return { status: 'Rejected', problem: 'The form or the version answered does not exist' };
  const at = L.toDate(r._created_at);
  const closedAt = L.toDate(form.closed_at);
  const closesAt = L.toDate(form.closes_at);
  if (closedAt && at && at > closedAt) return { status: 'Rejected', problem: 'It arrived after the form was closed' };
  if (closesAt && at && at > closesAt) return { status: 'Rejected', problem: 'It arrived after the closing date' };
  // The page sends again when it heard nothing back; when the first one had arrived, this is the same answers twice.
  const twin = r.visit ? L.one(`SELECT _id FROM forms_responses WHERE form_id = ? AND visit = ? AND _id < ? AND _deleted = 0 AND status = 'Complete' LIMIT 1`,
    Number(r.form_id), String(r.visit), Number(r._id)) : null;
  if (twin) return { status: 'Rejected', problem: `Sent twice: the same answers arrived before as #${twin._id}` };
  const meta = L.jsonOf(r.meta, {});
  if (r.review !== 'Not spam') {
    if (String(r.hp || '').trim()) return { status: 'Spam', problem: 'A field only bots see was filled' };
    if (Number.isFinite(Number(meta.ms)) && Number(meta.ms) < 2000) return { status: 'Spam', problem: 'Answered in under 2 seconds' };
  }
  const answers = L.jsonOf(r.answers, null);
  if (!answers || typeof answers !== 'object' || Array.isArray(answers)) return { status: 'Rejected', problem: 'The answers cannot be read' };
  const hidden = L.jsonOf(r.hidden, {});
  const v = F.validateResponse(def, answers, hidden);
  if (!v.ok) {
    const p = v.problems[0];
    const f = F.byRef(def, p.ref);
    return { status: 'Rejected', problem: `${p.message}: "${(f && f.title) || p.ref}"${v.problems.length > 1 ? ` (and ${v.problems.length - 1} more)` : ''}` };
  }
  const email = F.emailOf(def, v.answers);
  const named = def.fields.find((f) => f.type === 'short_text' && /name|nombre/i.test(`${f.ref} ${f.title}`) && v.answers[f.ref]);
  const who = [named ? v.answers[named.ref] : '', email ? `<${email}>` : ''].filter(Boolean).join(' ') || `#${r._id}`;
  return { status: 'Complete', email, ending: v.ending, rows: F.flatten(def, v.answers), who };
}

/**
 * One line per form, on Telegram to the chat in Settings and by email to the
 * addresses there; per form, either can be off. The link opens that form's
 * responses when the message is about one form.
 */
function tell(s, arrived, formOf) {
  if (!arrived.size) return {};
  const lines = [];
  for (const [id, list] of arrived) {
    const f = formOf(id);
    if (!f) continue;
    const n = list.length;
    const names = list.slice(0, 5).map((x) => x.who).join(', ');
    lines.push({ id, form: f, text: `${f.title}: ${n} new ${n === 1 ? 'response' : 'responses'} — ${names}${n > 5 ? `, and ${n - 5} more` : ''}` });
  }
  const link = (list) => (!s.desk_url ? '' : list.length === 1 ? `${s.desk_url}#/forms/${list[0].id}/responses` : s.desk_url);
  const byChannel = (channel) => lines.filter((l) => L.jsonOf(l.form.notify, {})[channel] !== false);
  const out = {};
  const tg = byChannel('telegram');
  if (tg.length && s.notify_telegram) {
    out.telegram = L.telegram(s.notify_telegram, ['Forms', ...tg.map((l) => l.text), link(tg)].filter(Boolean).join('\n'));
  }
  const em = byChannel('email');
  if (em.length && s.notify_emails) {
    const about = em.length === 1 ? em[0].form.title : `${em.length} forms`;
    out.email = L.email(s.notify_emails, `New responses: ${about}`, [...em.map((l) => l.text), '', link(em)].join('\n').trim());
  }
  return out;
}

if (require.main === module) {
  const mode = ['--auto', '--now'].includes(process.argv[2]) ? process.argv[2] : '--auto';
  try { run(mode); } catch (e) { L.done({ ok: false, error: e.message }); process.exitCode = 1; }
}

module.exports = { run, judge };
