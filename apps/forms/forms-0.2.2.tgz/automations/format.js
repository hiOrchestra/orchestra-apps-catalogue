'use strict';
/**
 * The rules of a form definition, for whoever writes one by hand or by model:
 * an agent asked for a form in a conversation (forms.js format), the Draft
 * with AI workflow (draft.js), and another system calling the API. Written for
 * someone who knows Typeform's form JSON: it says what this subset keeps.
 */
const RULES = `A Forms definition is Typeform's form JSON, a subset of it.

{ "title", "language": "es"|"en", "fields": [...], "logic": [...], "hidden": [...],
  "welcome_screens": [one, optional], "thankyou_screens": [at least one], "settings": {...}, "theme": {...} }

fields — the questions, in order. Each: { "ref", "type", "title", "properties": {...}, "validations": {...} }
  ref: letters, digits, _ or -; unique. Everything else points at it, so keep it stable when you edit.
  title: the question. "properties.description": a line under it.
  validations.required: true for the ones that must be answered.
  Types:
    short_text, long_text      validations.max_length
    email, phone_number, website, date (answer YYYY-MM-DD)
    number                     validations.min_value / max_value
    multiple_choice            properties.choices [{ "ref", "label" }], allow_multiple_selection,
                               allow_other_choice, randomize; validations.min_selection / max_selection
    dropdown                   properties.choices [{ "ref", "label" }] (long lists)
    yes_no                     answer true or false
    legal                      a consent; required means it must be accepted
    rating                     properties.steps 3–10 (stars)
    opinion_scale              properties.steps 5–11, start_at_one, labels { left, center, right }
    nps                        0–10, labels { left, right }
    statement                  text with no answer (properties.button_text)
  Not available: file_upload, payment, calendly, matrix, ranking, picture_choice, address, contact_info, group.

logic — jumps. { "type": "field", "ref": <question>, "actions": [
    { "action": "jump", "details": { "to": { "type": "field"|"thankyou", "value": <ref> } },
      "condition": { "op": ..., "vars": [ { "type": "field", "value": <ref> }, { "type": "constant"|"choice", "value": ... } ] } } ] }
  After that question, the first action whose condition holds decides where to go; with none, the next
  question; after the last one, the first ending. A jump only goes forward.
  ops: is, is_not, equal, not_equal, lower_than, lower_equal_than, greater_than, greater_equal_than,
       contains, not_contains, begins_with, ends_with, on, earlier_than, later_than (dates), always.
  Combine with { "op": "and"|"or", "vars": [conditions] }. An option is { "type": "choice", "value": <choice ref> };
  yes_no compares with { "type": "constant", "value": true|false }.

hidden — names (lower-case, digits, _) read from the link: …#/<slug>?utm_source=linkedin. Kept with the response.

Recall — {{field:<ref>}} or {{hidden:<name>}} inside a title or description writes that answer in.
  Only a question answered earlier.

welcome_screens — [{ "ref", "title", "properties": { "description", "button_text" } }]
thankyou_screens — [{ "ref", "title", "properties": { "description", "redirect_url" } }]. Reach a second one with a jump.
settings — show_progress_bar, progress_bar ("proportion"|"percentage"), show_question_number, show_key_hint_on_choices.
theme — { "accent": "#RRGGBB", "logo": "https://…" }.

The whole definition stays under 90 KB.`;

const EXAMPLE = {
  title: 'Webinar registration',
  language: 'en',
  fields: [
    { ref: 'name', type: 'short_text', title: 'What is your name?', validations: { required: true } },
    { ref: 'email', type: 'email', title: 'Thanks, {{field:name}}. Where should we send the link?', validations: { required: true } },
    { ref: 'customer', type: 'yes_no', title: 'Are you already a customer?' },
    { ref: 'plan', type: 'multiple_choice', title: 'Which plan do you have?',
      properties: { choices: [{ ref: 'basic', label: 'Basic' }, { ref: 'pro', label: 'Pro' }] } },
    { ref: 'source', type: 'dropdown', title: 'How did you hear about us?',
      properties: { choices: [{ ref: 'linkedin', label: 'LinkedIn' }, { ref: 'friend', label: 'A friend' }, { ref: 'other', label: 'Other' }] } },
    { ref: 'consent', type: 'legal', title: 'I agree to be emailed about this webinar.', validations: { required: true } },
  ],
  logic: [{ type: 'field', ref: 'customer', actions: [{ action: 'jump', details: { to: { type: 'field', value: 'source' } },
    condition: { op: 'is', vars: [{ type: 'field', value: 'customer' }, { type: 'constant', value: false }] } }] }],
  hidden: ['utm_source'],
  thankyou_screens: [{ ref: 'end', title: "You're in, {{field:name}}!", properties: { description: 'The link is on its way.' } }],
};

module.exports = { RULES, EXAMPLE };
