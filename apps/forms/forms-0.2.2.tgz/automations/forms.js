'use strict';
/**
 * Forms from the command line: what an agent runs when someone asks it for a
 * form in a conversation, and what another system runs through the API
 * (projects.run, or the "Forms · Save a form" workflow). The same rules as the
 * builder (formcore); it saves drafts, and publishes only when told to.
 *
 *   node forms.js format                              the rules of a definition, and an example
 *   node forms.js validate (--file f | --definition '<json>' | --b64 <base64>)
 *   node forms.js save [--form <id|slug>] [--slug <slug>] (--file … | --definition … | --b64 …)
 *   node forms.js publish <form>                      only when the person said so
 *   node forms.js close <form> | reopen <form>
 *   node forms.js list [--all]
 *   node forms.js get <form> [--published]
 *   node forms.js responses <form> [--limit 20] [--since YYYY-MM-DD] [--status Complete]
 *   node forms.js summary <form>
 *   node forms.js link <form> [--hidden name=value …]
 * Every command prints one JSON line.
 */
const fs = require('fs');
const L = require('./lib');
const { RULES, EXAMPLE } = require('./format');

const { F } = L;
const SLUG = /^[a-z0-9][a-z0-9-]{1,59}$/;
const WORDS = { yes: 'Yes', no: 'No' };
const who = () => process.env.ORCHESTRA_AGENT_ID || 'api';

function args(argv) {
  const out = { _: [] };
  for (let i = 0; i < argv.length; i += 1) {
    const a = argv[i];
    if (!a.startsWith('--')) { out._.push(a); continue; }
    const key = a.slice(2);
    const next = argv[i + 1];
    const value = next === undefined || next.startsWith('--') ? true : (i += 1, next);
    if (key === 'hidden') (out.hidden = out.hidden || []).push(value);
    else out[key] = value;
  }
  return out;
}

function source(a) {
  let text = null;
  if (typeof a.file === 'string') text = fs.readFileSync(a.file, 'utf8');
  else if (typeof a.b64 === 'string') text = Buffer.from(a.b64, 'base64').toString('utf8');
  else if (typeof a.definition === 'string') text = a.definition;
  if (text === null) throw new Error('Give the definition with --file, --definition or --b64');
  try { return JSON.parse(text); } catch (e) { throw new Error(`The definition is not JSON: ${e.message}`); }
}

function find(key) {
  if (key === undefined || key === true || key === 'new') return null;
  const row = /^\d+$/.test(String(key))
    ? L.one('SELECT * FROM forms_forms WHERE _id = ? AND _deleted = 0', Number(key))
    : L.one('SELECT * FROM forms_forms WHERE slug = ? AND _deleted = 0', String(key));
  if (!row) throw new Error(`No form "${key}"`);
  return row;
}

function freeSlug(base) {
  const b = (F.slug(base).replace(/_/g, '-') || 'form').slice(0, 50);
  for (let i = 1; i < 500; i += 1) {
    const s = i === 1 ? b : `${b}-${i}`;
    if (!L.one('SELECT 1 AS x FROM forms_forms WHERE slug = ?', s)) return s;
  }
  return `${b}-${Date.now()}`;
}

function links(row) {
  const s = L.settings();
  return {
    link: s.public_url ? `${s.public_url}#/${row.slug}` : null,
    edit: s.desk_url ? `${s.desk_url}#/forms/${row._id}/build` : null,
    live: row.status === 'Live',
  };
}

const brief = (row) => Object.assign({ id: row._id, slug: row.slug, title: row.title, status: row.status, version: row.version,
  responses: row.responses || 0 }, links(row));

function save(a) {
  const c = F.check(source(a));
  if (!c.ok) return { ok: false, errors: c.errors, warnings: c.warnings, hint: 'Fix these and save again; node forms.js format has the rules.' };
  const draft = JSON.stringify(c.def);
  const existing = find(a.form);
  if (existing) {
    L.write([{ op: 'update', table: 'forms_forms', id: existing._id, data: { title: c.def.title, draft } }]);
    return { ok: true, saved: 'draft', form: brief(find(existing._id)), warnings: c.warnings,
      next: existing.version ? 'The live form is unchanged until someone publishes this draft.' : 'Publish it when the person agrees.' };
  }
  let slug = typeof a.slug === 'string' && a.slug !== 'auto' ? a.slug : freeSlug(c.def.title);
  if (!SLUG.test(slug)) return { ok: false, errors: [{ path: 'slug', message: 'A link name is lower-case letters, digits and -' }] };
  if (L.one('SELECT 1 AS x FROM forms_forms WHERE slug = ?', slug)) slug = freeSlug(slug);
  const [r] = L.write([{ op: 'insert', table: 'forms_forms', data: { slug, title: c.def.title, status: 'Draft', draft,
    version: 0, responses: 0, archived: 0, created_by: who() } }]);
  return { ok: true, saved: 'new draft', form: brief(find(r._id)), warnings: c.warnings, next: 'Publish it when the person agrees.' };
}

function publish(row) {
  const c = F.check(L.jsonOf(row.draft, {}));
  if (!c.ok) return { ok: false, errors: c.errors, hint: 'The draft has problems; fix them before publishing.' };
  const top = L.one('SELECT MAX(version) AS v FROM forms_versions WHERE form_id = ?', row._id);
  const version = Number((top && top.v) || 0) + 1;
  const definition = JSON.stringify(c.def);
  L.write([
    { op: 'update', table: 'forms_forms', id: row._id, data: { title: c.def.title, draft: definition, version, status: 'Live',
      published_at: L.sqlNow(), closed_at: null, closed_reason: null } },
    { op: 'insert', table: 'forms_versions', data: { form_id: row._id, version, definition, published_at: L.sqlNow(), published_by: who() } },
  ]);
  return { ok: true, published: version, form: brief(find(row._id)) };
}

function setStatus(row, status) {
  if (status === 'Closed' && row.status !== 'Live') return { ok: false, error: 'Only a live form can be closed' };
  if (status === 'Live' && row.status !== 'Closed') return { ok: false, error: 'Only a closed form can be reopened' };
  const data = status === 'Closed' ? { status, closed_at: L.sqlNow(), closed_reason: 'Closed by an agent' } : { status, closed_at: null, closed_reason: null };
  L.write([{ op: 'update', table: 'forms_forms', id: row._id, when: { status: row.status }, data }]);
  return { ok: true, form: brief(find(row._id)) };
}

function definitionOf(row, version) {
  const v = L.one('SELECT definition FROM forms_versions WHERE form_id = ? AND version = ?', row._id, Number(version));
  return F.normalize(L.jsonOf(v ? v.definition : row.draft, {}));
}

function responses(row, a) {
  const limit = Math.min(Number(a.limit) || 20, 200);
  const status = typeof a.status === 'string' ? a.status : 'Complete';
  const since = typeof a.since === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(a.since) ? a.since : '0000-00-00';
  const rows = L.all(`SELECT * FROM forms_responses WHERE form_id = ? AND _deleted = 0 AND status = ? AND _created_at >= ?
    ORDER BY _id DESC LIMIT ?`, row._id, status, since, limit);
  const defs = {};
  return { ok: true, form: brief(row), count: rows.length, responses: rows.map((r) => {
    const def = defs[r.version] || (defs[r.version] = definitionOf(row, r.version));
    const ans = L.jsonOf(r.answers, {});
    return { id: r._id, at: r._created_at, status: r.status, problem: r.problem || undefined, hidden: L.jsonOf(r.hidden, {}),
      answers: def.fields.filter((f) => F.TYPES[f.type] !== null && !F.empty(ans[f.ref]))
        .map((f) => ({ question: f.title, answer: F.display(f, ans[f.ref], WORDS) })) };
  }) };
}

function summary(row) {
  // The questions people answered are the live version's; the draft may
  // have moved on (questions added or removed) since it was published.
  const def = row.version ? definitionOf(row, row.version) : F.normalize(L.jsonOf(row.draft, {}));
  const total = L.one(`SELECT COUNT(*) AS n FROM forms_responses WHERE form_id = ? AND _deleted = 0 AND status = 'Complete'`, row._id).n;
  const live = `JOIN forms_responses r ON r._id = a.response_id AND r.status = 'Complete' AND r._deleted = 0 WHERE a.form_id = ? AND a._deleted = 0 AND a.question = ?`;
  const questions = def.fields.filter((f) => F.TYPES[f.type] !== null).map((f) => {
    const out = { question: f.title, type: F.TYPE_LABEL[f.type] };
    if (['choice', 'boolean'].includes(F.TYPES[f.type])) {
      out.answers = L.all(`SELECT a.choice, MIN(a.value) AS label, COUNT(*) AS n FROM forms_answers a ${live} GROUP BY a.choice ORDER BY n DESC`, row._id, f.ref)
        .map((x) => ({ option: x.choice === 'other' ? 'Other' : x.label, count: x.n }));
    } else if (F.TYPES[f.type] === 'number') {
      const s = L.one(`SELECT COUNT(*) AS n, AVG(a.number) AS avg, MIN(a.number) AS min, MAX(a.number) AS max FROM forms_answers a ${live}`, row._id, f.ref);
      Object.assign(out, { answered: s.n, average: s.avg === null ? null : Math.round(s.avg * 10) / 10, min: s.min, max: s.max });
      if (f.type === 'nps' && s.n) {
        const c = L.one(`SELECT SUM(a.number >= 9) AS pro, SUM(a.number <= 6) AS det FROM forms_answers a ${live}`, row._id, f.ref);
        out.nps = Math.round(((c.pro - c.det) / s.n) * 100);
      }
    } else {
      out.latest = L.all(`SELECT a.value FROM forms_answers a ${live} ORDER BY a._id DESC LIMIT 5`, row._id, f.ref).map((x) => x.value);
    }
    return out;
  });
  return { ok: true, form: brief(row), responses: total, questions };
}

function main(argv) {
  const a = args(argv);
  const [cmd, key] = a._;
  switch (cmd) {
    case 'format': return { ok: true, rules: RULES, example: EXAMPLE };
    case 'validate': { const c = F.check(source(a)); return { ok: c.ok, errors: c.errors, warnings: c.warnings }; }
    case 'save': return save(a);
    case 'publish': return publish(find(key));
    case 'close': return setStatus(find(key), 'Closed');
    case 'reopen': return setStatus(find(key), 'Live');
    case 'list': return { ok: true, forms: L.all(`SELECT * FROM forms_forms WHERE _deleted = 0 ${a.all ? '' : 'AND COALESCE(archived, 0) = 0'} ORDER BY _id DESC`).map(brief) };
    case 'get': {
      const row = find(key);
      return { ok: true, form: brief(row), definition: a.published && row.version ? definitionOf(row, row.version) : L.jsonOf(row.draft, null) };
    }
    case 'responses': return responses(find(key), a);
    case 'summary': return summary(find(key));
    case 'link': {
      const row = find(key);
      const base = links(row).link;
      const q = (a.hidden || []).filter((h) => /^[a-z0-9_]{1,40}=/.test(h)).map((h) => {
        const i = h.indexOf('=');
        return `${h.slice(0, i)}=${encodeURIComponent(h.slice(i + 1))}`;
      }).join('&');
      return { ok: true, link: base && q ? `${base}?${q}` : base, live: row.status === 'Live' };
    }
    default: return { ok: false, error: `Unknown command "${cmd || ''}". Commands: format, validate, save, publish, close, reopen, list, get, responses, summary, link` };
  }
}

if (require.main === module) {
  let out;
  try { out = main(process.argv.slice(2)); } catch (e) { out = { ok: false, error: e.message }; }
  L.done(out);
  if (!out.ok) process.exitCode = 1;
}

module.exports = { main };
