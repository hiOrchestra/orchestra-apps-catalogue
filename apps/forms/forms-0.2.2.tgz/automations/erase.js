'use strict';
/**
 * Forms · Erase responses: the right to be forgotten. The chosen responses lose
 * their content for good — answers, hidden fields, timings, email — and become
 * Erased, which no list or summary shows; their rows in forms_answers are
 * emptied and deleted. What stays is an empty row that says it was erased.
 *   node erase.js <id,id,…>
 */
const L = require('./lib');

function run(list) {
  const ids = [...new Set(String(list || '').split(',').map((x) => x.trim()).filter((x) => /^\d+$/.test(x)).map(Number))].slice(0, 500);
  if (!ids.length) return { ok: true, erased: 0, why: 'No responses named' };
  const rows = L.all(`SELECT _id, form_id FROM forms_responses WHERE _deleted = 0 AND status <> 'Erased' AND _id IN (${ids.map(() => '?').join(',')})`, ...ids);
  if (!rows.length) return { ok: true, erased: 0 };
  const answers = L.all(`SELECT _id FROM forms_answers WHERE _deleted = 0 AND response_id IN (${rows.map(() => '?').join(',')})`, ...rows.map((r) => r._id));
  L.write([
    ...rows.map((r) => ({ op: 'update', table: 'forms_responses', id: r._id, data: {
      answers: '{}', hidden: '{}', meta: '{}', email: null, problem: null, ending: null, status: 'Erased', review: 'Erased on request' } })),
    ...answers.map((a) => ({ op: 'update', table: 'forms_answers', id: a._id, data: { value: null, number: null, choice: null } })),
  ]);
  L.softDelete('forms_answers', answers.map((a) => a._id));
  for (const id of new Set(rows.map((r) => r.form_id))) {
    const c = L.one(`SELECT COUNT(*) AS n FROM forms_responses WHERE form_id = ? AND _deleted = 0 AND status = 'Complete'`, id);
    L.write([{ op: 'update', table: 'forms_forms', id, data: { responses: c.n } }]);
  }
  return { ok: true, erased: rows.length, answers: answers.length };
}

if (require.main === module) {
  let out;
  try { out = run(process.argv[2]); } catch (e) { out = { ok: false, error: e.message }; }
  L.done(out);
}

module.exports = { run };
