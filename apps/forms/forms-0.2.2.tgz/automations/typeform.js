'use strict';
/**
 * Forms · Import from Typeform. For people moving from Typeform: every form
 * of the Typeform account connected to the workspace comes in as a DRAFT
 * (never published, never public), with its completed responses as answers
 * of that form. Read only on Typeform's side; nothing is sent anywhere.
 *
 *   A form keeps its Typeform id (typeform_id): importing again refreshes the
 *   draft instead of making a second form, unless someone edited or published
 *   it here, in which case it is left as it is.
 *   A response keeps its Typeform token (typeform_token): importing again
 *   only adds the ones not here yet, and one deleted or erased here stays so.
 *
 * Responses come newest first, a page at a time, at most CAP a run. Where it
 * stopped is kept (typeform_cursor), and a half-hourly check continues while
 * the import is Partial, so a big account finishes over several runs. The
 * result is one line in Settings (typeform_note), shown under the Import button.
 *
 *   node typeform.js --start   a person pressed Import (continues one under way)
 *   node typeform.js --auto    continue an import that is Partial
 *
 * mapForm() and mapResponse() are pure: Typeform's JSON in, Forms' out.
 */
const crypto = require('crypto');
const L = require('./lib');
const X = require('./composio');

const { F } = L;
const CAP = Number(process.env.FORMS_TYPEFORM_CAP) || 2000; // responses a run
const BUDGET_MS = Number(process.env.FORMS_TYPEFORM_BUDGET_MS) || 200000; // the step has 300 s
const PACK = 80000; // bytes of ops in one write
const REF = F.REF;

// ── the mapping (pure) ───────────────────────────────────────────────────
// Typeform types Forms has, as they are.
const SAME = new Set(['short_text', 'long_text', 'email', 'phone_number', 'website', 'number', 'date', 'multiple_choice',
  'dropdown', 'yes_no', 'legal', 'rating', 'opinion_scale', 'nps', 'statement']);
// The words for a Typeform type that comes in as text.
const TF_LABEL = { file_upload: 'file upload', payment: 'payment', matrix: 'matrix', ranking: 'ranking', calendly: 'Calendly',
  signature: 'signature', address: 'address', contact_info: 'contact info', multi_format: 'video or audio answer' };
const OPS = new Set(F.OPS);
const VAR_TYPES = new Set(['field', 'constant', 'choice', 'hidden']);
const isObj = (v) => v !== null && typeof v === 'object' && !Array.isArray(v);
const str = (v) => (v === undefined || v === null ? '' : String(v));
const RECALL_ANY = /\{\{\s*[a-z_]+:[^}]*\}\}/gi;

const NOTE = {
  es: (type) => `En Typeform era una pregunta de tipo ${type}; aquí la respuesta es texto.`,
  en: (type) => `In Typeform this was a ${type} question; here the answer is text.`,
};

/**
 * A Typeform form as a Forms definition, and what did not map:
 *   { def, refs: Map(typeform field ref or id -> { ref, as: 'native'|'text', source }),
 *     notes: { text: n fields that became text, logic: n jumps left out, hidden: n hidden fields left out } }
 * Groups (and inline groups) are opened up: their title becomes a statement
 * and their questions follow it. A jump survives only when it is a jump to a
 * question or an ending, forward, on conditions Forms reads the same way.
 */
function mapForm(tf, { language = 'es' } = {}) {
  const src = isObj(tf) ? tf : {};
  const lang = ['es', 'en'].includes(str(src.language || (src.settings && src.settings.language)).slice(0, 2))
    ? str(src.language || src.settings.language).slice(0, 2) : (['es', 'en'].includes(language) ? language : 'es');
  const notes = { text: 0, logic: 0, hidden: 0 };
  const refs = new Map();
  const taken = new Set();
  const refFor = (x, fallback) => {
    let r = [x && x.ref, x && x.id].map(str).find((v) => REF.test(v) && !taken.has(v));
    if (!r) { r = (F.slug(fallback) || 'q').replace(/^_+/, '') || 'q'; for (let i = 2; taken.has(r) || !REF.test(r); i += 1) r = `${(F.slug(fallback) || 'q')}_${i}`; }
    taken.add(r);
    return r;
  };
  const remember = (f, ref, as) => {
    for (const k of [f.ref, f.id]) if (str(k)) refs.set(str(k), { ref, as, source: str(f.type) });
  };
  const fields = [];

  const add = (f) => {
    if (!isObj(f)) return;
    const p = isObj(f.properties) ? f.properties : {};
    const v = isObj(f.validations) ? f.validations : {};
    const title = str(f.title).trim();
    if (Array.isArray(p.fields) && ['group', 'inline_group', 'contact_info', 'address'].includes(f.type)) {
      if (title || str(p.description).trim()) {
        const ref = refFor(f, title || 'group');
        fields.push({ ref, type: 'statement', title, properties: pick(p, ['description', 'button_text']) });
        remember(f, ref, 'native');
      }
      p.fields.forEach(add);
      return;
    }
    const type = str(f.type);
    const ref = refFor(f, title);
    if (SAME.has(type) || type === 'picture_choice') {
      const out = { ref, type: type === 'picture_choice' ? 'multiple_choice' : type, title, properties: {}, validations: {} };
      out.properties = pick(p, ['description', 'button_text', 'allow_multiple_selection', 'allow_other_choice', 'randomize',
        'steps', 'start_at_one', 'labels']);
      if (Array.isArray(p.choices)) {
        const seen = new Set();
        out.properties.choices = p.choices.filter(isObj).map((c) => {
          let cr = [c.ref, c.id].map(str).find((x) => REF.test(x) && !seen.has(x));
          if (!cr) { cr = F.slug(c.label) || 'option'; for (let i = 2; seen.has(cr); i += 1) cr = `${F.slug(c.label) || 'option'}_${i}`; }
          seen.add(cr);
          return { ref: cr, label: str(c.label).trim(), tf: [str(c.ref), str(c.id)] };
        });
      }
      out.validations = pick(v, ['required', 'max_length', 'min_value', 'max_value', 'min_selection', 'max_selection']);
      fields.push(out);
      remember(f, ref, 'native');
      return;
    }
    fields.push(asText({ ref, title: title || `(${type})`, properties: { description: str(p.description).trim() } }, type, lang));
    notes.text += 1;
    remember(f, ref, 'text');
  };
  (Array.isArray(src.fields) ? src.fields : []).forEach(add);
  if (!fields.length) fields.push({ ref: 'empty', type: 'statement', title: lang === 'es' ? 'Este formulario no tenía preguntas en Typeform.' : 'This form had no questions in Typeform.', properties: {} });

  const hidden = [];
  for (const h of Array.isArray(src.hidden) ? src.hidden : []) {
    const name = str(h).trim().toLowerCase();
    if (F.HIDDEN.test(name)) hidden.push(name); else notes.hidden += 1;
  }

  const screen = (s, keys) => ({ ref: str(s.ref || s.id), title: str(s.title).trim(), properties: pick(isObj(s.properties) ? s.properties : {}, keys) });
  const welcome = (Array.isArray(src.welcome_screens) ? src.welcome_screens : []).filter(isObj).slice(0, 1)
    .map((s) => screen(s, ['description', 'button_text']));
  const endings = (Array.isArray(src.thankyou_screens) ? src.thankyou_screens : []).filter(isObj).map((s) => {
    const out = screen(s, ['description', 'redirect_url']);
    if (s.type === 'url_redirect' && s.properties && s.properties.redirect_url) out.properties.redirect_url = str(s.properties.redirect_url);
    if (!out.properties.redirect_url) delete out.properties.redirect_url;
    return out;
  });

  const logic = [];
  for (const l of Array.isArray(src.logic) ? src.logic : []) {
    if (!isObj(l)) continue;
    const actions = Array.isArray(l.actions) ? l.actions.filter(isObj) : [];
    const jumps = actions.filter((a) => a.action === 'jump');
    const usable = l.type === 'field' ? jumps.filter((a) => {
      const to = (a.details && a.details.to) || {};
      return ['field', 'thankyou'].includes(to.type) && cleanCondition(a.condition);
    }).map((a) => ({ action: 'jump', details: { to: { type: a.details.to.type, value: mapRef(refs, a.details.to.value) } },
      condition: renameCondition(a.condition, refs) })) : [];
    notes.logic += jumps.length - usable.length;
    if (usable.length) logic.push({ type: 'field', ref: mapRef(refs, l.ref), actions: usable });
  }

  const def = {
    title: str(src.title).trim().slice(0, 200) || (lang === 'es' ? 'Formulario de Typeform' : 'Typeform form'),
    language: lang, fields, hidden, welcome_screens: welcome, thankyou_screens: endings, logic,
    settings: pick(isObj(src.settings) ? src.settings : {}, ['show_progress_bar', 'progress_bar']),
  };
  settle(def, notes, lang, refs);
  // Where each option came from, for the answers; the saved draft does not keep it.
  const choices = new Map();
  for (const f of def.fields) {
    for (const c of (f.properties.choices || [])) { choices.set(`${f.ref} ${c.ref}`, c.tf || []); delete c.tf; }
  }
  return { def: F.normalize(def), refs, notes, choices };
}

/** A question Forms has no type for, as a short text that says what it was. */
function asText(f, type, lang) {
  const note = NOTE[lang](TF_LABEL[type] || str(type).replace(/_/g, ' '));
  return { ref: f.ref, type: 'short_text', title: f.title,
    properties: { description: [str(f.properties && f.properties.description).trim(), note].filter(Boolean).join(' ') }, validations: {} };
}

function pick(o, keys) {
  const out = {};
  for (const k of keys) if (o[k] !== undefined && o[k] !== null && o[k] !== '') out[k] = o[k];
  return out;
}

const mapRef = (refs, r) => (refs.get(str(r)) || { ref: str(r) }).ref;

function cleanCondition(c) {
  if (!isObj(c)) return false;
  if (c.op === 'and' || c.op === 'or') return Array.isArray(c.vars) && c.vars.length > 0 && c.vars.every(cleanCondition);
  if (!OPS.has(c.op)) return false;
  if (c.op === 'always') return true;
  return Array.isArray(c.vars) && c.vars.length === 2 && c.vars.every((v) => isObj(v) && VAR_TYPES.has(v.type));
}

function renameCondition(c, refs) {
  if (c.op === 'and' || c.op === 'or') return { op: c.op, vars: c.vars.map((x) => renameCondition(x, refs)) };
  return { op: c.op, vars: (c.vars || []).map((v) => (v.type === 'field' ? { type: 'field', value: mapRef(refs, v.value) } : { type: v.type, value: v.value })) };
}

/**
 * Whatever Forms' own checks still refuse is mended, one problem at a time:
 * recall that names nothing is taken out, a question that cannot stand as it
 * is becomes text, a jump that does not hold is left out, a bad redirect or
 * hidden name goes. The draft that is saved always passes F.check.
 */
function settle(def, notes, lang, refs) {
  for (let guard = 0; guard < 1000; guard += 1) {
    const c = F.check(def);
    if (c.ok) return;
    const e = c.errors[0];
    const at = (re) => { const m = e.path.match(re); return m ? Number(m[1]) : -1; };
    let i;
    if ((i = at(/^logic\[(\d+)\]/)) >= 0) {
      const n = def.logic[i] ? def.logic[i].actions.length : 1;
      notes.logic += n;
      def.logic.splice(i, 1);
    } else if ((i = at(/^fields\[(\d+)\]/)) >= 0) {
      const f = def.fields[i];
      if (/\{\{/.test(e.message)) {
        f.title = str(f.title).replace(RECALL_ANY, '…');
        if (f.properties) f.properties.description = str(f.properties.description).replace(RECALL_ANY, '…');
      } else if (f.type !== 'short_text') {
        const was = f.type;
        def.fields[i] = asText(Object.assign({}, f, { title: f.title || `(${was})` }), was, lang);
        notes.text += 1;
        for (const [k, v] of refs) if (v.ref === f.ref) refs.set(k, Object.assign({}, v, { as: 'text' }));
      } else if (!f.title) f.title = '…';
      else if (f.validations && Object.keys(f.validations).length) f.validations = {};
      else { def.fields.splice(i, 1); notes.text += 1; }
    } else if ((i = at(/^thankyou_screens\[(\d+)\]/)) >= 0) {
      delete def.thankyou_screens[i].properties.redirect_url;
    } else if ((i = at(/^hidden\[(\d+)\]/)) >= 0) {
      def.hidden.splice(i, 1);
      notes.hidden += 1;
    } else if (e.path === 'title') {
      def.title = def.title.slice(0, 200) || 'Typeform';
    } else if (e.path === 'fields') {
      if (!def.fields.length) def.fields.push({ ref: 'empty', type: 'statement', title: '…', properties: {} });
      else def.fields.length = 200;
    } else if (/^theme/.test(e.path)) {
      def.theme = {};
    } else if (def.logic.length) {
      notes.logic += def.logic.reduce((n, l) => n + l.actions.length, 0);
      def.logic = [];
    } else {
      // Too large even without jumps: the longest descriptions go.
      const longest = def.fields.reduce((a, f) => (str(f.properties && f.properties.description).length > str(a.properties && a.properties.description).length ? f : a), def.fields[0]);
      if (!str(longest.properties && longest.properties.description)) throw new Error(`It cannot be imported: ${e.message}`);
      longest.properties.description = '';
    }
  }
  throw new Error('It could not be made into a valid form');
}

/**
 * One Typeform response as Forms keeps it: { answers (by question ref),
 * hidden, ending, meta, dropped (answers that did not fit) }. `mapped` is
 * what mapForm() gave for its form: an option is found by Typeform's ref, its
 * id, or its label.
 */
function mapResponse(item, mapped) {
  const { def, refs, choices } = mapped;
  const answers = {};
  let dropped = 0;
  for (const a of Array.isArray(item.answers) ? item.answers : []) {
    if (!isObj(a) || !isObj(a.field)) continue;
    const hit = refs.get(str(a.field.ref)) || refs.get(str(a.field.id));
    const f = hit && F.byRef(def, hit.ref);
    if (!f || F.TYPES[f.type] === null) { dropped += 1; continue; }
    const value = hit.as === 'text' || F.TYPES[f.type] === 'text' ? asString(a) : valueFor(f, a, choices);
    const loose = Object.assign({}, f, { validations: Object.assign({}, f.validations, { required: false, min_selection: 0, max_selection: 0 }) });
    if (F.empty(value) || F.checkAnswer(loose, value)) { dropped += 1; continue; }
    answers[f.ref] = F.clean(f, value);
  }
  const hidden = {};
  for (const [k, v] of Object.entries(isObj(item.hidden) ? item.hidden : {})) {
    if (def.hidden.includes(k.toLowerCase()) && str(v)) hidden[k.toLowerCase()] = str(v).slice(0, 500);
  }
  const at = Date.parse(item.submitted_at);
  const landed = Date.parse(item.landed_at);
  const meta = { source: 'typeform', submitted_at: Number.isFinite(at) ? new Date(at).toISOString() : null };
  if (Number.isFinite(at) && Number.isFinite(landed) && at >= landed) meta.ms = at - landed;
  const ending = F.endingOf(def, str(item.thankyou_screen_ref)) ? str(item.thankyou_screen_ref) : null;
  return { answers, hidden, ending, meta, dropped };
}

/** Any Typeform answer in words: what a question that became text keeps. */
function asString(a) {
  switch (a.type) {
    case 'choice': return str(a.choice && (a.choice.label || a.choice.other));
    case 'choices': return [...(Array.isArray(a.choices && a.choices.labels) ? a.choices.labels : []), str(a.choices && a.choices.other)].filter(Boolean).join(', ');
    case 'boolean': return a.boolean ? 'Yes' : 'No';
    case 'payment': return a.payment ? [a.payment.amount, a.payment.name, a.payment.success === false ? '(not paid)' : ''].filter(Boolean).join(' ') : '';
    case 'file_url': return str(a.file_url);
    case 'url': return str(a.url);
    default: {
      const v = a[a.type];
      if (v === undefined || v === null) return '';
      return isObj(v) || Array.isArray(v) ? JSON.stringify(v).slice(0, 1000) : str(v);
    }
  }
}

/** An answer in the shape Forms keeps for a question of its own type. */
function valueFor(f, a, choices) {
  const kind = F.TYPES[f.type];
  if (kind === 'number') return a.number !== undefined ? Number(a.number) : Number(a[a.type]);
  if (kind === 'date') return str(a.date || a.text).slice(0, 10);
  if (kind === 'boolean') return typeof a.boolean === 'boolean' ? a.boolean : undefined;
  if (kind !== 'choice') return asString(a);
  const find = (ref, id, label) => {
    for (const c of f.properties.choices || []) {
      const was = choices.get(`${f.ref} ${c.ref}`) || [];
      if ((ref && (c.ref === ref || was.includes(ref))) || (id && (c.ref === id || was.includes(id)))) return c.ref;
    }
    const byLabel = (f.properties.choices || []).find((c) => label && c.label.toLowerCase() === str(label).trim().toLowerCase());
    return byLabel ? byLabel.ref : null;
  };
  const picked = [];
  if (a.type === 'choice' && isObj(a.choice)) {
    const r = find(str(a.choice.ref), str(a.choice.id), a.choice.label);
    if (r) picked.push(r); else if (str(a.choice.other || a.choice.label)) picked.push({ other: str(a.choice.other || a.choice.label) });
  } else if (a.type === 'choices' && isObj(a.choices)) {
    const labels = Array.isArray(a.choices.labels) ? a.choices.labels : [];
    const rs = Array.isArray(a.choices.refs) ? a.choices.refs : [];
    const ids = Array.isArray(a.choices.ids) ? a.choices.ids : [];
    const n = Math.max(labels.length, rs.length, ids.length);
    for (let i = 0; i < n; i += 1) {
      const r = find(str(rs[i]), str(ids[i]), labels[i]);
      if (r) picked.push(r); else if (str(labels[i])) picked.push({ other: str(labels[i]) });
    }
    if (str(a.choices.other)) picked.push({ other: str(a.choices.other) });
  } else if (str(a.text)) {
    const r = find('', '', a.text);
    picked.push(r || { other: str(a.text) });
  }
  if (!picked.length) return undefined;
  return f.type === 'multiple_choice' && f.properties.allow_multiple_selection ? picked : picked[0];
}

// ── the run ──────────────────────────────────────────────────────────────
const hash = (text) => crypto.createHash('sha1').update(String(text)).digest('hex').slice(0, 16);
const SLUG = /^[a-z0-9][a-z0-9-]{1,59}$/;

function freeSlug(title) {
  const b = (F.slug(title).replace(/_/g, '-').replace(/^-+|-+$/g, '') || 'typeform').slice(0, 50).padEnd(2, '0');
  for (let i = 1; i < 500; i += 1) {
    const s = i === 1 ? b : `${b}-${i}`;
    if (SLUG.test(s) && !L.one('SELECT 1 AS x FROM forms_forms WHERE slug = ?', s)) return s;
  }
  return `${b}-${Date.now()}`;
}

/** The form here for a Typeform form: made, refreshed while untouched, or left as someone changed it. */
function upsertForm(tfId, mapped) {
  const draft = JSON.stringify(mapped.def);
  const have = L.one('SELECT * FROM forms_forms WHERE typeform_id = ? AND _deleted = 0 ORDER BY _id LIMIT 1', tfId);
  if (!have) {
    const [r] = L.write([{ op: 'insert', table: 'forms_forms', data: { slug: freeSlug(mapped.def.title), title: mapped.def.title, status: 'Draft', draft,
      version: 0, responses: 0, archived: 0, notify: '{}', created_by: 'Typeform', typeform_id: tfId, typeform_hash: hash(draft) } }]);
    return { id: r._id, did: 'new' };
  }
  const untouched = have.status === 'Draft' && !Number(have.version) && hash(have.draft) === have.typeform_hash;
  if (!untouched) return { id: have._id, did: 'kept' };
  if (hash(draft) !== have.typeform_hash) {
    L.write([{ op: 'update', table: 'forms_forms', id: have._id, data: { title: mapped.def.title, draft, typeform_hash: hash(draft) } }]);
  }
  return { id: have._id, did: 'updated' };
}

/** Ops in packs under PACK bytes, each one transaction; the tail goes with the last pack. */
function writePacks(groups, tail) {
  const packs = [];
  let cur = [];
  let size = 0;
  for (const g of groups) {
    const n = JSON.stringify(g).length;
    if (cur.length && size + n > PACK) { packs.push(cur); cur = []; size = 0; }
    cur.push(...g);
    size += n;
  }
  cur.push(...tail);
  packs.push(cur);
  for (const p of packs) if (p.length) L.write(p);
}

function count(formId) {
  const c = L.one(`SELECT COUNT(*) AS n, MAX(_created_at) AS last FROM forms_responses WHERE form_id = ? AND _deleted = 0 AND status = 'Complete'`, Number(formId));
  L.write([{ op: 'update', table: 'forms_forms', id: formId, data: { responses: c.n, last_response_at: c.last || null } }]);
}

const plural = (n, one, many) => `${Number(n || 0).toLocaleString('en')} ${Number(n) === 1 ? one : many}`;

/** The line under the Import button. */
function report(k, finished) {
  const answers = k.known ? plural(k.answers, 'new answer', 'new answers') : plural(k.answers, 'answer', 'answers');
  const head = finished ? `Imported ${plural(k.forms, 'form', 'forms')} and ${answers} from Typeform`
    : `So far ${plural(k.forms, 'form', 'forms')} and ${answers} from Typeform; it goes on by itself within half an hour`;
  const extra = [
    k.text ? `${plural(k.text, 'field', 'fields')} became text` : '',
    k.logic ? `${plural(k.logic, 'jump', 'jumps')} left out` : '',
    k.kept ? `${plural(k.kept, 'form', 'forms')} you changed here kept as ${k.kept === 1 ? 'it is' : 'they are'}` : '',
  ].filter(Boolean);
  return [head, ...extra].join(' · ');
}

async function run(mode = '--auto') {
  const t0 = Date.now();
  const s = L.settings();
  if (mode === '--auto' && s.typeform_status !== 'Partial') return { ok: true, mode, skipped: 'No import is under way' };
  const held = L.lock('typeform');
  if (!held) return { ok: true, mode, skipped: 'Another import run is working' };
  let cur = L.jsonOf(s.typeform_cursor, null);
  // Under way or stopped by an error: go on from where it was. Otherwise from the start.
  if (!(['Partial', 'Failed'].includes(s.typeform_status) && cur && Array.isArray(cur.queue))) cur = null;
  const save = (data) => ({ op: 'update', table: 'forms_settings', id: s._id, data });
  try {
    // Partial from the first moment: a run stopped by its time limit is continued by the half-hourly check.
    L.write([save({ typeform_status: 'Partial', typeform_note: cur ? 'Going on with the import…' : 'Importing from Typeform…' })]);
    if (!cur) {
      // The list of forms first, all of it: a few calls even for a big account.
      const queue = [];
      for (let page = 1; page < 100; page += 1) {
        const r = await X.listForms(page);
        for (const f of r.forms) if (!queue.includes(f.id)) queue.push(f.id);
        if (!r.more || !r.forms.length) break;
      }
      cur = { queue, form: null, counts: { forms: 0, answers: 0, known: 0, text: 0, logic: 0, kept: 0, dropped: 0 } };
    }
    const k = cur.counts;
    let taken = 0;
    while (cur.queue.length && taken < CAP && Date.now() - t0 < BUDGET_MS) {
      const tfId = cur.queue[0];
      const mapped = mapForm(await X.getForm(tfId), { language: s.language });
      const here = upsertForm(tfId, mapped);
      if (!cur.form || cur.form.tf !== tfId) {
        cur.form = { tf: tfId, before: null };
        k.forms += 1;
        k.text += mapped.notes.text;
        k.logic += mapped.notes.logic;
        if (here.did === 'kept') k.kept += 1;
      }
      let more = true;
      while (more && taken < CAP && Date.now() - t0 < BUDGET_MS) {
        const page = await X.responsesPage(tfId, cur.form.before);
        const tokens = page.items.map((x) => str(x.token || x.response_id));
        const knownSet = new Set(tokens.length ? L.all(`SELECT typeform_token AS t FROM forms_responses WHERE typeform_token IN (${tokens.map(() => '?').join(',')})`, ...tokens).map((x) => x.t) : []);
        const groups = [];
        page.items.forEach((item, i) => {
          const token = tokens[i];
          if (knownSet.has(token)) { k.known += 1; return; }
          const r = mapResponse(item, mapped);
          k.dropped += r.dropped;
          const as = `r${i}`;
          const g = [{ op: 'insert', table: 'forms_responses', as, data: { form_id: here.id, version: 0, answers: JSON.stringify(r.answers),
            hidden: JSON.stringify(r.hidden), meta: JSON.stringify(r.meta), visit: `typeform:${token}`, ending: r.ending, hp: '', status: 'Complete',
            email: F.emailOf(mapped.def, r.answers) || null, processed_at: L.sqlNow(), typeform_token: token } }];
          for (const row of F.flatten(mapped.def, r.answers)) {
            g.push({ op: 'insert', table: 'forms_answers', data: Object.assign({ response_id: `$${as}._id`, form_id: here.id, version: 0 }, row) });
          }
          groups.push(g);
          k.answers += 1;
        });
        taken += groups.length; // the cap is on answers brought in; the time budget covers the rest
        // A page with nothing new ends this form: everything older came in before.
        const allKnown = page.items.length > 0 && groups.length === 0;
        more = Boolean(page.before) && !allKnown;
        if (more) cur.form.before = page.before;
        else { cur.queue.shift(); cur.form = null; }
        // The cursor goes in the same transaction as the last answers: a run killed
        // in between fetches the page again and finds part of it already here.
        writePacks(groups, [save({ typeform_cursor: JSON.stringify(cur) })]);
        if (groups.length) count(here.id);
      }
    }
  } catch (e) {
    held.release();
    const off = X.notConnected(e);
    L.write([save(off
      ? { typeform_status: 'Not connected', typeform_cursor: null, typeform_note: 'Typeform is not connected to this workspace. Connect it in Orchestra → Integrations, then press Import again.' }
      : { typeform_status: 'Failed', typeform_cursor: cur ? JSON.stringify(cur) : null,
        typeform_note: `It stopped: ${e.message.slice(0, 200)}. Press Import to go on from there.` })]);
    return { ok: false, mode, notConnected: off || undefined, error: e.message, counts: cur && cur.counts };
  }
  held.release();
  const finished = !cur.queue.length;
  L.write([save(finished
    ? { typeform_status: 'Done', typeform_cursor: null, typeform_at: L.sqlNow(), typeform_note: report(cur.counts, true) }
    : { typeform_status: 'Partial', typeform_cursor: JSON.stringify(cur), typeform_note: report(cur.counts, false) })]);
  return { ok: true, mode, finished, counts: cur.counts, note: report(cur.counts, finished) };
}

if (require.main === module) {
  const mode = process.argv.includes('--start') ? '--start' : '--auto';
  run(mode)
    .then((r) => { L.done(r); if (!r.ok) process.exitCode = 1; })
    .catch((e) => { L.done({ ok: false, error: e.message }); process.exitCode = 1; });
}

module.exports = { run, mapForm, mapResponse, report };
