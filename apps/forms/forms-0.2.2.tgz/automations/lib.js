'use strict';
/**
 * What every Forms script shares: reading the project's database, writing to
 * it, talking to the instance as the workflow's agent, and telling the team.
 *
 * Reads go to the project's SQLite file directly, read-only and
 * parameterised. Every write goes through `orch-database batch`, the
 * platform's own writer: one transaction, and a `when` precondition checked
 * inside the UPDATE, so "this response is mine now" is atomic.
 *
 * The project is the one these scripts were installed into
 * (projects/<p>/apps/forms/automations), so nothing names it by hand.
 *
 * Locally (FORMS_LOCAL=1) the same batch runs against FORMS_DB with the same
 * semantics, and the notices are recorded instead of sent, so every script is
 * tested off the instance.
 */
const { DatabaseSync } = require('node:sqlite');
const { execFileSync } = require('child_process');
const fs = require('fs');
const os = require('os');
const path = require('path');
const F = require('./formcore');

const PROJECT = process.env.FORMS_PROJECT || (__dirname.match(/projects\/([^/]+)\/apps\/forms/) || [])[1] || 'default';
const STATE = process.env.OPENCLAW_STATE_DIR || '/home/node/.openclaw';
const DB_PATH = process.env.FORMS_DB || path.join(STATE, 'orchestra', 'projects', PROJECT, 'data', 'data.db');
const LOCAL = process.env.FORMS_LOCAL === '1';

// ── reading ──────────────────────────────────────────────────────────────
let reader = null;
function db() {
  if (!reader) {
    reader = new DatabaseSync(DB_PATH, { readOnly: true });
    reader.exec('PRAGMA busy_timeout = 5000');
  }
  return reader;
}
const all = (sql, ...params) => db().prepare(sql).all(...params);
const one = (sql, ...params) => db().prepare(sql).get(...params);

function settings() {
  const s = one('SELECT * FROM forms_settings WHERE _deleted = 0 ORDER BY _id LIMIT 1');
  if (!s) throw new Error('Forms has no settings row: it is not installed in this project');
  return s;
}

/** JSON kept in a text column, or the fallback when it is empty or not JSON. */
function jsonOf(text, fallback) {
  if (text === null || text === undefined || text === '') return fallback;
  if (typeof text === 'object') return text;
  try { return JSON.parse(text); } catch { return fallback; }
}

// ── writing ──────────────────────────────────────────────────────────────
/**
 * One transaction per chunk, all or nothing; the inserted ids in order. Big
 * batches are split by size: one argv string over 128 KB is refused by the
 * kernel before the CLI ever runs.
 */
function write(ops) {
  const chunks = [];
  let cur = [];
  let size = 0;
  for (const op of ops) {
    const n = JSON.stringify(op).length;
    if (cur.length && size + n > 90000) { chunks.push(cur); cur = []; size = 0; }
    cur.push(op);
    size += n;
  }
  if (cur.length) chunks.push(cur);
  const results = [];
  for (const chunk of chunks) results.push(...((LOCAL ? localBatch(chunk) : cliBatch(chunk)).results || []));
  return results;
}

function cliBatch(ops) {
  let out;
  try {
    out = execFileSync('orch-database', ['--project', PROJECT, 'batch', '--ops', JSON.stringify(ops)],
      { encoding: 'utf8', timeout: 60000, maxBuffer: 16 << 20 });
  } catch (e) {
    let j = null;
    try { j = JSON.parse(String(e.stdout || '')); } catch { /* not JSON */ }
    throw new Error((j && j.error) || String(e.stderr || e.message).trim().slice(0, 300));
  }
  const j = JSON.parse(out);
  if (!j.ok) throw new Error(j.error || 'the write failed');
  return j;
}

/** orch-database's run_batch, for local tests: same `when`, same all-or-none, same results. */
function localBatch(ops) {
  const w = new DatabaseSync(DB_PATH);
  w.exec('PRAGMA busy_timeout = 5000');
  const now = sqlNow();
  const named = {};
  const deref = (v) => (typeof v === 'string' && v.startsWith('$') && named[v.slice(1).split('.')[0]]
    ? named[v.slice(1).split('.')[0]]._id : v);
  const results = [];
  w.exec('BEGIN IMMEDIATE');
  try {
    ops.forEach((op, i) => {
      const data = {};
      for (const [k, v] of Object.entries(op.data || {})) if (!k.startsWith('_')) data[k] = deref(v);
      if (op.op === 'insert') {
        const cols = [...Object.keys(data), '_created_at', '_updated_at'];
        const r = w.prepare(`INSERT INTO "${op.table}" (${cols.map((c) => `"${c}"`).join(', ')}) VALUES (${cols.map(() => '?').join(', ')})`)
          .run(...Object.values(data), now, now);
        const id = Number(r.lastInsertRowid);
        if (op.as) named[op.as] = { _id: id };
        results.push({ op: 'insert', table: op.table, _id: id });
      } else {
        const when = op.when || {};
        const r = w.prepare(`UPDATE "${op.table}" SET ${Object.keys(data).map((c) => `"${c}" = ?`).join(', ')}, _updated_at = ? `
          + `WHERE _id = ? AND _deleted = 0${Object.keys(when).map((c) => ` AND "${c}" IS ?`).join('')}`)
          .run(...Object.values(data), now, deref(op.id), ...Object.values(when));
        if (!r.changes) throw new Error(`op ${i}: row ${op.id} changed meanwhile (precondition failed)`);
        results.push({ op: 'update', table: op.table, _id: deref(op.id) });
      }
    });
    w.exec('COMMIT');
  } catch (e) {
    w.exec('ROLLBACK');
    w.close();
    throw e;
  }
  w.close();
  return { ok: true, applied: results.length, results };
}

/** Soft-delete rows by id (integers only, so the WHERE is safe to build). */
function softDelete(table, ids) {
  const list = ids.filter((x) => Number.isInteger(x));
  if (!list.length) return 0;
  const where = `_id IN (${list.join(',')})`;
  if (LOCAL) {
    const w = new DatabaseSync(DB_PATH);
    const r = w.prepare(`UPDATE "${table}" SET _deleted = 1, _updated_at = ? WHERE ${where}`).run(sqlNow());
    w.close();
    return r.changes;
  }
  const out = JSON.parse(execFileSync('orch-database', ['--project', PROJECT, 'delete', table, '--where', where], { encoding: 'utf8', timeout: 60000 }));
  if (out.ok === false) throw new Error(out.error || 'the delete failed');
  return out.affected || 0;
}

// ── one run at a time ────────────────────────────────────────────────────
const STALE_MS = 150000; // longer than a step may run (120 s): a file this old was left by a run that was killed

/**
 * A lock file, so a burst of responses has one run doing the work instead of
 * thirty racing for the same rows: each lost race is an orch-database process
 * and a failed transaction. It saves work; it is not what keeps a response
 * from being processed twice (every claim is a `when`). A run that cannot
 * create the file at all goes on without it.
 *   lock('intake') -> { release() }, or null when another run holds it
 */
function lock(name) {
  // Per agent: a file another agent left in /tmp (sticky) is one this one could never remove.
  let who = process.env.ORCHESTRA_AGENT_ID;
  if (!who) { try { who = os.userInfo().username; } catch { who = String(process.getuid ? process.getuid() : 'node'); } }
  const file = path.join(process.env.FORMS_LOCK_DIR || os.tmpdir(), `orchestra-forms-${PROJECT}-${who}-${name}.lock`);
  const held = { file, release() { try { fs.unlinkSync(file); } catch { /* already gone */ } } };
  for (let i = 0; i < 2; i += 1) {
    try {
      fs.writeFileSync(file, String(process.pid), { flag: 'wx' });
      return held;
    } catch (e) {
      if (e.code !== 'EEXIST') return { file: null, release() {} };
      let age;
      try { age = Date.now() - fs.statSync(file).mtimeMs; } catch { continue; } // let go meanwhile: try again
      if (age < STALE_MS) return null;
      try { fs.unlinkSync(file); } catch { /* another run took it over first */ }
    }
  }
  return null;
}

// ── time ─────────────────────────────────────────────────────────────────
/** 'YYYY-MM-DD HH:MM:SS' in UTC: the format orch-database stamps rows with. */
const sqlNow = (d = new Date()) => d.toISOString().slice(0, 19).replace('T', ' ');

/** '2026-10-03 10:00:00' (orch-database, UTC) or '2026-10-03T10:00:00.000Z' ($now) as a Date. */
function toDate(v) {
  if (!v) return null;
  const s = String(v).trim();
  const iso = s.includes('T') ? s : s.replace(' ', 'T');
  const d = new Date(/[zZ]|[+-]\d\d:?\d\d$/.test(iso) ? iso : `${iso}Z`);
  return Number.isNaN(d.getTime()) ? null : d;
}

// ── the instance, as this workflow's agent ───────────────────────────────
/**
 * Scripts run as the workflow's agent (runsAs, through orch-as): its id and
 * token are in the environment. HOOKS_TOKEN is only there when a person runs a
 * script by hand as `node`.
 */
function identityHeaders() {
  const id = process.env.ORCHESTRA_AGENT_ID;
  const token = process.env.ORCHESTRA_AGENT_TOKEN;
  if (id && token) return { 'x-orchestra-agent': id, 'x-orchestra-agent-token': token };
  const secret = process.env.HOOKS_TOKEN || process.env.OPENCLAW_GATEWAY_TOKEN || '';
  return secret ? { 'x-orchestra-secret': secret } : {};
}

/**
 * POST to the instance's api-server. Headers go to curl on stdin (-K -),
 * never argv, so the token is not in the process list. Never throws.
 */
function post(route, body) {
  const q = (v) => `"${String(v).replace(/[\\"]/g, '\\$&')}"`;
  const config = [
    `url = ${q(`http://127.0.0.1:${Number(process.env.API_SERVER_PORT || 3001)}${route}`)}`,
    'request = "POST"',
    'header = "Content-Type: application/json"',
    ...Object.entries(identityHeaders()).map(([k, v]) => `header = ${q(`${k}: ${v}`)}`),
    `data = ${q(JSON.stringify(body))}`,
  ].join('\n');
  try {
    const out = execFileSync('curl', ['-sS', '-m', '30', '-K', '-'], { input: config, timeout: 35000, stdio: ['pipe', 'pipe', 'pipe'] }).toString();
    let j = null;
    try { j = JSON.parse(out); } catch { /* reported below */ }
    if (j && j.success) return { ok: true, data: j.data };
    return { ok: false, why: String((j && j.error && (j.error.message || j.error)) || out).trim().slice(0, 200) };
  } catch (e) {
    return { ok: false, why: String((e.stderr && e.stderr.toString()) || e.message).trim().slice(0, 200) };
  }
}

// ── telling the team ─────────────────────────────────────────────────────
const TG_CHAT = /^(-?\d{5,20}|@[A-Za-z0-9_]{5,32})$/;
const sent = []; // what a local run would have sent

/** One message from the instance's Telegram bot, to a chat it is set up for. */
function telegram(to, text) {
  const chat = String(to || '').trim();
  if (!chat) return { sent: false, why: 'No Telegram chat in Settings' };
  if (!TG_CHAT.test(chat)) return { sent: false, why: 'The Telegram chat in Settings is not a chat id or @username' };
  const message = String(text || '').slice(0, 3800);
  if (LOCAL || process.env.FORMS_FAKE_NOTIFY === '1') { sent.push({ telegram: chat, message }); return { sent: true, to: chat, fake: true, message }; }
  const r = post('/api/channels/telegram/notify', { to: chat, message });
  return r.ok ? { sent: true, to: chat } : { sent: false, to: chat, why: r.why };
}

/** An email from the workspace's own address. The backend only lets it reach the workspace's members. */
function email(to, subject, text) {
  const list = String(to || '').split(/[,\s;]+/).map((x) => x.trim()).filter(Boolean).slice(0, 5);
  if (!list.length) return { sent: false, why: 'No email in Settings' };
  if (LOCAL || process.env.FORMS_FAKE_NOTIFY === '1') { sent.push({ email: list, subject, text }); return { sent: true, to: list, fake: true }; }
  const r = post('/api/email/send', { to: list.join(', '), subject: String(subject).slice(0, 200), text: String(text).slice(0, 20000) });
  return r.ok ? { sent: true, to: list } : { sent: false, to: list, why: r.why };
}

/** The one JSON line a workflow step leaves as its output. */
function done(result) {
  process.stdout.write(`${JSON.stringify(result)}\n`);
  return result;
}

module.exports = {
  F, PROJECT, DB_PATH, LOCAL, all, one, settings, jsonOf, write, softDelete, lock, sqlNow, toDate,
  identityHeaders, post, telegram, email, sent, done,
};
