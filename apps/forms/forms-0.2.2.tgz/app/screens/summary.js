// What the answers add up to: how many came, how many this week, how long it
// takes to answer, per day, and each question's answers counted. Read from the
// views, never by downloading the answers.
import { F, T, V, formRow, formHead, versionDef, parse, plural } from '../data.js';

const { el, router, fmt } = Orch;

export function render({ id }) {
  Orch.load('view', async () => {
    const [list, row] = await Promise.all([formRow(id), Orch.db.get(T.forms, id)]);
    if (!list || !row) return el('p', { class: 'oc-state' }, 'This form does not exist.');
    const def = (await versionDef(row._id, row.version)) || F.normalize(parse(row.draft, {}));
    const by = { filter: { form_id: row._id }, limit: 500 };
    const [ins, choices, numbers, daily] = await Promise.all([
      Orch.db.view(V.insights, { filter: { form_id: row._id }, limit: 1 }), Orch.db.view(V.choices, by), Orch.db.view(V.numbers, by),
      Orch.db.view(V.daily, Object.assign({ sort: 'day:asc' }, by)),
    ]);
    const k = (ins.rows || [])[0] || {};
    const kpi = (value, label, note) => el('div', { class: 'oc-kpi' }, [el('span', { class: 'oc-kpi__value oc-num' }, value), el('span', { class: 'oc-kpi__label' }, label), note ? el('span', { class: 'oc-small oc-muted' }, note) : null]);
    if (!k.completed) {
      return el('div', { class: 'oc-stack oc-stack--loose' }, [formHead(list, 'summary'), el('div', { class: 'oc-state' }, [
        el('p', 'Nobody has answered yet.'),
        router.link(`/forms/${row._id}/share`, 'Share its link'),
      ])]);
    }
    const asked = def.fields.filter((f) => F.TYPES[f.type] !== null);
    return el('div', { class: 'oc-stack oc-stack--loose' }, [
      formHead(list, 'summary'),
      el('div', { class: 'oc-grid fm-kpis' }, [
        kpi(fmt.number(k.completed), 'Responses'),
        kpi(fmt.number(k.this_week || 0), 'In the last 7 days'),
        kpi(k.avg_ms ? duration(k.avg_ms) : '—', 'Time to answer', 'on average'),
      ]),
      daily.rows.length > 1 ? el('section', { class: 'oc-card' }, [el('h2', { class: 'oc-h3' }, 'Responses per day'),
        Orch.chart({ rows: daily.rows.slice(-60), x: 'day', kind: 'bar', series: [{ key: 'n', label: 'Responses' }] })]) : null,
      ...asked.map((f, i) => question(f, i, row, choices.rows || [], numbers.rows || [], k.completed)),
    ]);
  });
}

const duration = (ms) => (ms < 60000 ? `${Math.round(ms / 1000)} s` : `${Math.floor(ms / 60000)} min ${Math.round((ms % 60000) / 1000)} s`);

function bars(items, total) {
  const top = Math.max(1, ...items.map((x) => x.n));
  return el('ul', { class: 'fm-bars' }, items.map((x) => el('li', { class: 'fm-bar' }, [
    el('span', { class: 'fm-bar__label' }, x.label),
    el('span', { class: 'fm-bar__track', 'aria-hidden': 'true' }, el('span', { class: 'fm-bar__fill', style: { width: `${Math.round((x.n / top) * 100)}%` } })),
    el('span', { class: 'fm-bar__n oc-num' }, `${fmt.number(x.n)} · ${total ? Math.round((x.n / total) * 100) : 0}%`),
  ])));
}

function question(f, i, row, choices, numbers, total) {
  const kind = F.TYPES[f.type];
  const mine = (list) => list.filter((x) => x.question === f.ref);
  let body;
  if (kind === 'choice' || kind === 'boolean') {
    const counted = mine(choices);
    const answered = counted.reduce((n, x) => n + x.n, 0);
    const known = kind === 'boolean'
      ? [['yes', f.type === 'legal' ? 'Accepted' : 'Yes'], ['no', f.type === 'legal' ? 'Not accepted' : 'No']]
      : f.properties.choices.map((c) => [c.ref, c.label]).concat(f.properties.allow_other_choice ? [['other', 'Other']] : []);
    body = bars(known.map(([ref, label]) => ({ label, n: (counted.find((x) => x.choice === ref) || {}).n || 0 })), f.properties.allow_multiple_selection ? total : answered);
  } else if (kind === 'number') {
    const dist = mine(numbers).sort((a, b) => a.value - b.value);
    const n = dist.reduce((s, x) => s + x.n, 0);
    const avg = n ? dist.reduce((s, x) => s + x.value * x.n, 0) / n : 0;
    const head = [el('p', { class: 'fm-avg' }, [el('strong', { class: 'oc-num' }, fmt.number(Math.round(avg * 10) / 10)), el('span', { class: 'oc-muted' }, ` average of ${plural(n, 'answer', 'answers')}`)])];
    if (f.type === 'nps' && n) {
      const pro = dist.filter((x) => x.value >= 9).reduce((s, x) => s + x.n, 0);
      const det = dist.filter((x) => x.value <= 6).reduce((s, x) => s + x.n, 0);
      head.unshift(el('p', { class: 'fm-avg' }, [el('strong', { class: 'oc-num' }, String(Math.round(((pro - det) / n) * 100))),
        el('span', { class: 'oc-muted' }, ` Net Promoter Score · ${fmt.number(pro)} promoters, ${fmt.number(n - pro - det)} passives, ${fmt.number(det)} detractors`)]));
    }
    const [lo, hi] = f.type === 'number' ? [null, null] : F.scale(f);
    const steps = lo === null ? dist.map((x) => x.value) : Array.from({ length: hi - lo + 1 }, (_, j) => lo + j);
    body = el('div', {}, [...head, steps.length <= 12 ? bars(steps.map((v) => ({ label: String(v), n: (dist.find((x) => x.value === v) || {}).n || 0 })), n) : null]);
  } else {
    body = el('div', { class: 'fm-texts', 'data-q': f.ref }, el('p', { class: 'oc-muted' }, 'Loading…'));
    Orch.db.view(V.texts, { filter: { form_id: row._id, question: f.ref }, sort: '_id:desc', limit: 5, count: true }).then((r) => {
      Orch.mount(body, r.rows.length ? [el('ul', { class: 'fm-quotes' }, r.rows.map((x) => el('li', x.value))),
        r.total > 5 ? router.link(`/forms/${row._id}/responses`, `All ${fmt.number(r.total)} answers`) : null]
        : el('p', { class: 'oc-muted' }, 'No answers to this one yet.'));
    }).catch(() => Orch.mount(body, el('p', { class: 'oc-muted' }, 'Could not read these answers.')));
  }
  return el('section', { class: 'oc-card fm-q' }, [
    el('p', { class: 'oc-small oc-muted' }, `${i + 1} · ${F.TYPE_LABEL[f.type]}`),
    el('h2', { class: 'oc-h3' }, f.title.replace(/\{\{\s*(field|hidden):[^}]+\}\}/g, '…') || f.ref),
    body,
  ]);
}
