// The builder: the map of the form on the left, the part being edited in the
// middle, and on the right the form as people will answer it. Every change
// is saved a moment later as the draft; what people answer changes only when
// someone presses Publish (a new version, the old answers keep theirs).
// A form an agent is drafting shows that, and opens when the draft is in.
import { F, T, A, act, formRow, formHead, versionDef, parse, settings, freeSlug, publicLink, copy, sheet } from '../data.js';
import { outline } from './build-outline.js';
import { questionEditor } from './build-question.js';
import { formEditor, welcomeEditor, endingEditor } from './build-misc.js';
import { play } from '../render/player.js';
import { handOver } from './preview.js';

const { el, router } = Orch;

// The builder on screen: a change still waiting to be saved is saved when the
// screen changes, and the page asks before closing over it.
let onScreen = null;
window.addEventListener('hashchange', () => { if (onScreen) { const b = onScreen; onScreen = null; b.leave(); } });
window.addEventListener('beforeunload', (e) => { if (onScreen && onScreen.timer) { e.preventDefault(); e.returnValue = ''; } });

export function render({ id }) {
  Orch.load('view', async () => {
    const [row, list, s] = await Promise.all([Orch.db.get(T.forms, id), formRow(id), settings()]);
    if (!row || !list) return el('div', { class: 'oc-state' }, [el('p', 'This form does not exist.'), router.link('/', 'All forms')]);
    if (row.ai_status === 'Working') return drafting(row, list);
    const def = F.normalize(parse(row.draft, null) || await versionDef(row._id, row.version) || { title: row.title, fields: [] });
    return builder(row, list, def, s);
  });
}

/** An agent is writing the draft: say so, and open the builder when it is in. */
function drafting(row, list) {
  const started = Date.now();
  const note = el('p', { class: 'oc-muted' }, 'An agent is writing the questions. It takes a minute or two; this page opens them when they are ready.');
  const poll = async () => {
    if (!note.isConnected) return;
    const now = await Orch.db.get(T.forms, row._id).catch(() => null);
    if (now && now.ai_status !== 'Working') { render({ id: row._id }); return; }
    if (Date.now() - started > 5 * 60000) { note.textContent = 'It is taking longer than usual. You can leave: the draft appears in Forms when it is in.'; return; }
    setTimeout(poll, 3000);
  };
  setTimeout(poll, 3000);
  return el('div', { class: 'oc-stack oc-stack--loose' }, [
    formHead(list, 'build'),
    el('section', { class: 'oc-card fm-drafting' }, [
      el('div', { class: 'oc-row' }, [Orch.spinner('Drafting…')]),
      note,
      el('blockquote', { class: 'fm-request' }, row.ai_request || ''),
    ]),
  ]);
}

function builder(row, list, def, s) {
  const B = { id: row._id, row, list, def, settings: s, sel: def.fields.length ? { kind: 'field', ref: def.fields[0].ref } : { kind: 'form' }, timer: null };
  const said = el('span', { class: 'fm-saved oc-small oc-muted', role: 'status' }, 'All changes saved');
  const olHost = el('nav', { class: 'fm-ol', 'aria-label': 'Parts of the form' });
  const edHost = el('section', { class: 'fm-edhost', 'aria-label': 'Editing' });
  const pvHost = el('div', { class: 'fm-pv__screen' });
  let player = null;
  let pvTimer = null;

  const drawOutline = () => Orch.mount(olHost, outline(B));
  function drawEditor() {
    const k = B.sel;
    const f = k.kind === 'field' && B.def.fields.find((x) => x.ref === k.ref);
    const e = k.kind === 'ending' && B.def.thankyou_screens.find((x) => x.ref === k.ref);
    Orch.mount(edHost, f ? questionEditor(B, f) : e ? endingEditor(B, e) : k.kind === 'welcome' && B.def.welcome_screens.length ? welcomeEditor(B) : formEditor(B));
  }
  function drawPreview() {
    clearTimeout(pvTimer);
    pvTimer = setTimeout(() => {
      if (player) player.destroy();
      const live = F.normalize(B.def);
      if (!live.theme.accent && B.settings.accent) live.theme.accent = B.settings.accent;
      player = play(pvHost, live, { preview: true, scopeKeys: true });
      if (B.sel.kind === 'field') player.peek(B.sel.ref);
    }, 250);
  }
  B.select = (sel) => { B.sel = sel; drawOutline(); drawEditor(); drawPreview(); };
  B.change = (opts = {}) => {
    handOver(B.id, B.def);
    said.textContent = 'Saving…';
    clearTimeout(B.timer);
    B.timer = setTimeout(save, 900);
    drawOutline();
    drawPreview();
    if (opts.editor) drawEditor();
  };

  async function save() {
    B.timer = null;
    const clean = F.normalize(B.def);
    const r = await act(A.saveDraft, { id: B.id, title: clean.title || 'Untitled form', draft: JSON.stringify(clean) });
    said.textContent = r ? 'All changes saved' : 'Not saved: it will try again with the next change';
  }
  async function flush() { if (B.timer) { clearTimeout(B.timer); await save(); } }

  async function publish() {
    await flush();
    const c = F.check(B.def);
    if (!c.ok) { problems(B, c.errors); return; }
    const live = Number(B.row.version) > 0;
    const sure = await Orch.confirm(live
      ? 'Publish these changes? Whoever opens the link from now on answers this version; answers already in keep the questions they answered.'
      : 'Publish this form? Anyone with its link can answer it.', { yes: 'Publish' });
    if (!sure) return;
    const top = (await Orch.db.list(T.versions, { filter: { form_id: B.id }, sort: 'version:desc', limit: 1 })).rows[0];
    const version = Number((top && top.version) || 0) + 1;
    if (!live && /^(draft-|untitled-form|formulario-sin-titulo)/.test(B.row.slug)) {
      const slug = await freeSlug(c.def.title, B.id);
      if (slug !== B.row.slug && await act(A.setSlug, { id: B.id, slug })) B.row.slug = slug;
    }
    const r = await act(A.publish, { id: B.id, form_id: B.id, version, title: c.def.title, definition: JSON.stringify(c.def) });
    if (!r) return;
    B.row.version = version;
    const link = publicLink(B.row.slug);
    sheet(el('div', { class: 'oc-stack' }, [
      el('p', live ? 'The new version is live.' : 'It is live. Anyone with this link can answer it:'),
      el('p', { class: 'fm-link' }, link),
      el('div', { class: 'oc-row' }, [
        el('button', { type: 'button', class: 'oc-btn oc-btn--primary', onClick: () => copy(link, 'Link copied.') }, 'Copy link'),
        el('a', { class: 'oc-btn', href: link, target: '_blank', rel: 'noopener' }, 'Open it'),
        router.link(`/forms/${B.id}/share`, 'More ways to share', { class: 'oc-btn oc-btn--ghost' }),
      ]),
    ]), { title: 'Published' });
    render({ id: B.id });
  }

  // Its own tab, opened inside the click (a popup blocker trusts nothing later),
  // with what is on screen handed over first: it plays that, not the last save.
  function fullPreview() {
    handOver(B.id, B.def);
    window.open(`${location.pathname}${location.search}#/forms/${B.id}/preview`, `fm-preview-${B.id}`);
  }

  const tools = [
    said,
    el('button', { type: 'button', class: 'oc-btn', onClick: fullPreview }, 'Preview'),
    el('button', { type: 'button', class: 'oc-btn oc-btn--primary', onClick: publish }, Number(row.version) > 0 ? 'Publish changes' : 'Publish'),
  ];
  B.leave = () => { if (B.timer) save(); if (player) player.destroy(); };
  onScreen = B;
  setTimeout(() => { drawOutline(); drawEditor(); drawPreview(); }, 0);
  return el('div', { class: 'fm-build-page' }, [
    formHead(list, 'build', tools),
    row.ai_status === 'Failed' ? failedDraft(row) : null,
    el('div', { class: 'fm-build' }, [olHost, edHost, el('aside', { class: 'fm-pv', 'aria-label': 'Preview' }, [
      el('p', { class: 'oc-small oc-muted' }, 'How people see it'),
      pvHost,
    ])]),
  ]);
}

/** What stops a form from being published, each with a way to it. */
function problems(B, errors) {
  const where = (path) => {
    const m = /^(fields|logic|thankyou_screens|welcome_screens)\[(\d+)\]/.exec(path);
    if (!m) return { kind: 'form' };
    const i = Number(m[2]);
    if (m[1] === 'fields') return { kind: 'field', ref: (B.def.fields[i] || {}).ref };
    if (m[1] === 'logic') return { kind: 'field', ref: (B.def.logic[i] || {}).ref };
    if (m[1] === 'thankyou_screens') return { kind: 'ending', ref: (B.def.thankyou_screens[i] || {}).ref };
    return { kind: 'welcome' };
  };
  const d = sheet(el('div', { class: 'oc-stack' }, [
    el('p', 'Fix these first; then publish again.'),
    el('ul', { class: 'fm-problems' }, errors.slice(0, 12).map((e) => el('li', {}, [
      el('span', e.message),
      el('button', { type: 'button', class: 'oc-btn oc-btn--sm oc-btn--ghost', onClick: () => { d.close(); B.select(where(e.path)); } }, 'Go there'),
    ]))),
  ]), { title: 'Not ready to publish' });
}

function failedDraft(row) {
  return el('div', { class: 'fm-banner', role: 'alert' }, [
    el('p', [el('strong', 'The agent could not draft this form. '), row.ai_note || '']),
    el('div', { class: 'oc-row' }, [
      el('button', { type: 'button', class: 'oc-btn oc-btn--sm', onClick: async () => {
        if (await act(A.retryDraft, { id: row._id, ai_request: row.ai_request })) render({ id: row._id });
      } }, 'Try again'),
      el('span', { class: 'oc-small oc-muted' }, 'Or write the questions here yourself.'),
    ]),
  ]);
}
