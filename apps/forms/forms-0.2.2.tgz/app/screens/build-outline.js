// The builder's map of the form: its settings, the welcome screen, every
// question in order and the endings. Picking one opens it in the editor and
// shows it in the preview; "Add a question" asks the type first.
import { F } from '../data.js';
import { TYPE_GROUPS, shortTitle } from './build-kit.js';
import { addField } from './build-question.js';
import { addWelcome, addEnding } from './build-misc.js';

const { el } = Orch;

export function outline(B) {
  const is = (kind, ref) => B.sel.kind === kind && (ref === undefined || B.sel.ref === ref);
  const item = (kind, ref, parts, label) => el('button', { type: 'button', class: 'fm-ol__item', 'aria-current': is(kind, ref) ? 'true' : null,
    'aria-label': label || null, onClick: () => B.select({ kind, ref }) }, parts);
  let n = 0;
  const menu = el('div', { class: 'fm-ol__menu', hidden: true, role: 'menu' }, TYPE_GROUPS.map(([g, types]) => el('div', { class: 'fm-ol__group' }, [
    el('p', { class: 'oc-small oc-muted' }, g),
    ...types.map((t) => el('button', { type: 'button', role: 'menuitem', class: 'fm-ol__type', onClick: () => { menu.hidden = true; addField(B, t); } }, F.TYPE_LABEL[t])),
  ])));
  const adder = el('button', { type: 'button', class: 'oc-btn oc-btn--sm fm-ol__add', 'aria-expanded': 'false',
    onClick: () => { menu.hidden = !menu.hidden; adder.setAttribute('aria-expanded', String(!menu.hidden)); } }, 'Add a question');
  return el('div', { class: 'fm-ol__inner' }, [
    item('form', undefined, [el('span', { class: 'fm-ol__num' }, '·'), el('span', { class: 'fm-ol__text' }, 'The form: language, look, link')]),
    B.def.welcome_screens.length
      ? item('welcome', undefined, [el('span', { class: 'fm-ol__num' }, '·'), el('span', { class: 'fm-ol__text' }, 'Welcome screen')])
      : el('button', { type: 'button', class: 'fm-ol__ghost', onClick: () => addWelcome(B) }, '+ Welcome screen'),
    el('p', { class: 'fm-ol__head' }, `Questions · ${B.def.fields.length}`),
    el('ol', { class: 'fm-ol__list' }, B.def.fields.map((f) => {
      const asks = f.type !== 'statement';
      if (asks) n += 1;
      const jumps = B.def.logic.some((l) => l.ref === f.ref && l.actions.length);
      return el('li', {}, item('field', f.ref, [
        el('span', { class: 'fm-ol__num' }, asks ? String(n) : '—'),
        el('span', { class: 'fm-ol__text' }, [
          el('span', { class: shortTitle(f.title) ? '' : 'oc-muted' }, shortTitle(f.title) || 'No text yet'),
          el('span', { class: 'oc-small oc-muted' }, `${F.TYPE_LABEL[f.type] || f.type}${f.validations.required ? ' · required' : ''}${jumps ? ' · jumps' : ''}`),
        ]),
      ], `Question ${asks ? n : ''}: ${shortTitle(f.title) || 'no text yet'}`));
    })),
    el('div', { class: 'fm-ol__adder' }, [adder, menu]),
    el('p', { class: 'fm-ol__head' }, 'Endings'),
    ...B.def.thankyou_screens.map((e, k) => item('ending', e.ref, [
      el('span', { class: 'fm-ol__num' }, String.fromCharCode(97 + (k % 26))),
      el('span', { class: 'fm-ol__text' }, shortTitle(e.title, 40) || (B.def.language === 'es' ? '¡Gracias!' : 'Thank you!')),
    ])),
    el('button', { type: 'button', class: 'fm-ol__ghost', onClick: () => addEnding(B) }, '+ Another ending'),
  ]);
}
