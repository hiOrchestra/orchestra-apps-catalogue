// The builder's small parts: a labelled field, inputs bound to a property of
// the draft, new refs. Every edit mutates the draft in memory and calls
// B.change(), which saves it a moment later and redraws the preview.
import { F } from '../data.js';

const { el } = Orch;

export const TYPE_GROUPS = [
  ['Text', ['short_text', 'long_text', 'email', 'phone_number', 'website', 'number', 'date']],
  ['Choice', ['multiple_choice', 'dropdown', 'yes_no', 'legal']],
  ['Rating', ['rating', 'opinion_scale', 'nps']],
  ['No answer', ['statement']],
];

export function field(label, control, help) {
  return el('label', { class: 'oc-field' }, [el('span', { class: 'oc-label' }, label), control, help ? el('span', { class: 'oc-help' }, help) : null]);
}

/** A text input or textarea bound to obj[key]. */
export function text(B, obj, key, opts = {}) {
  const c = el(opts.area ? 'textarea' : 'input', { class: opts.area ? 'oc-textarea' : 'oc-input', type: opts.area ? null : (opts.type || 'text'),
    rows: opts.area ? String(opts.rows || 2) : null, placeholder: opts.placeholder || null, 'aria-label': opts.label || null });
  c.value = obj[key] === undefined || obj[key] === null ? '' : String(obj[key]);
  c.addEventListener('input', () => {
    if (c.value === '' && opts.dropEmpty) delete obj[key]; else obj[key] = c.value;
    B.change();
  });
  return c;
}

/** A number input bound to obj[key]; empty removes the key. */
export function number(B, obj, key, opts = {}) {
  const c = el('input', { class: 'oc-input fm-num', type: 'number', min: opts.min, max: opts.max, step: opts.step || '1',
    placeholder: opts.placeholder || null, 'aria-label': opts.label || null });
  c.value = obj[key] === undefined || obj[key] === null ? '' : String(obj[key]);
  c.addEventListener('input', () => {
    if (c.value === '' || !Number.isFinite(Number(c.value))) delete obj[key]; else obj[key] = Number(c.value);
    B.change();
  });
  return c;
}

/** A checkbox bound to obj[key] (absent when off). */
export function check(B, obj, key, label, after, onValue = true) {
  const c = el('input', { type: 'checkbox' });
  c.checked = onValue === true ? !!obj[key] : obj[key] !== false;
  c.addEventListener('change', () => {
    if (onValue === true) { if (c.checked) obj[key] = true; else delete obj[key]; } else if (c.checked) delete obj[key]; else obj[key] = false;
    B.change();
    if (after) after(c.checked);
  });
  return el('label', { class: 'fm-check' }, [c, el('span', label)]);
}

/** A select over [value, label] pairs; onPick(value). */
export function select(options, value, onPick, label) {
  const s = el('select', { class: 'oc-select', 'aria-label': label || null }, options.map(([v, l]) => {
    const o = el('option', { value: String(v) }, l);
    if (String(v) === String(value)) o.selected = true;
    return o;
  }));
  s.addEventListener('change', () => onPick(s.value));
  return s;
}

export function typeSelect(value, onPick) {
  const s = el('select', { class: 'oc-select', 'aria-label': 'Question type' }, TYPE_GROUPS.map(([g, types]) => el('optgroup', { label: g },
    types.map((t) => { const o = el('option', { value: t }, F.TYPE_LABEL[t]); if (t === value) o.selected = true; return o; }))));
  s.addEventListener('change', () => onPick(s.value));
  return s;
}

/** A ref not used yet in `list`: prefix_1, prefix_2… */
export function freshRef(list, prefix) {
  const taken = new Set(list.map((x) => x.ref));
  for (let i = list.length + 1; ; i += 1) if (!taken.has(`${prefix}_${i}`)) return `${prefix}_${i}`;
}

export const letter = (i) => (i < 26 ? String.fromCharCode(65 + i) : String(i + 1));
export const shortTitle = (t, n = 60) => { const s = String(t || '').replace(/\{\{\s*(field|hidden):[^}]+\}\}/g, '…').trim(); return s.length > n ? `${s.slice(0, n - 1)}…` : s; };

/** "Insert an answer": puts {{field:ref}} (or a hidden field) at the cursor of a title. */
export function recallPicker(B, before, target, obj, key) {
  const earlier = B.def.fields.slice(0, Math.max(0, before)).filter((f) => F.TYPES[f.type] !== null);
  if (!earlier.length && !B.def.hidden.length) return null;
  const s = select([['', 'Insert an earlier answer…'],
    ...earlier.map((f) => [`field:${f.ref}`, `Answer: ${shortTitle(f.title, 40) || f.ref}`]),
    ...B.def.hidden.map((h) => [`hidden:${h}`, `From the link: ${h}`])], '', (v) => {
    if (!v) return;
    const at = target.selectionStart ?? target.value.length;
    const token = `{{${v}}}`;
    target.value = `${target.value.slice(0, at)}${token}${target.value.slice(target.selectionEnd ?? at)}`;
    obj[key] = target.value;
    s.value = '';
    target.focus();
    target.setSelectionRange(at + token.length, at + token.length);
    B.change();
  }, 'Insert an earlier answer');
  s.classList.add('fm-recall');
  return s;
}
