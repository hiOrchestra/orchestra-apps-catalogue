// One form's settings: its link name, when it stops taking answers, who hears
// about new ones, and closing, reopening or putting it away.
import { T, A, act, formRow, formHead, settings, parse, publicLink, freeSlug } from '../data.js';

const { el, router } = Orch;

export function render({ id }) {
  Orch.load('view', async () => {
    const [list, row, s] = await Promise.all([formRow(id), Orch.db.get(T.forms, id), settings()]);
    if (!list || !row) return el('p', { class: 'oc-state' }, 'This form does not exist.');
    const again = () => render({ id });
    const notify = Object.assign({ telegram: true, email: true }, parse(row.notify, {}));
    const slug = el('input', { class: 'oc-input', type: 'text', value: row.slug, pattern: '[a-z0-9][a-z0-9-]{1,59}' });
    const preview = el('p', { class: 'oc-help' }, publicLink(row.slug));
    slug.addEventListener('input', () => { preview.textContent = publicLink(slug.value.trim() || '…'); });
    const closes = el('input', { class: 'oc-input', type: 'datetime-local' });
    if (row.closes_at) { const d = new Date(row.closes_at); if (!Number.isNaN(d.getTime())) closes.value = new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 16); }
    const max = el('input', { class: 'oc-input fm-num', type: 'number', min: '1', placeholder: 'No limit' });
    if (row.max_responses) max.value = String(row.max_responses);
    const message = el('textarea', { class: 'oc-textarea', rows: '2', placeholder: 'This form is closed. It no longer takes answers.' });
    message.value = row.closed_message || '';
    const tg = el('input', { type: 'checkbox' }); tg.checked = notify.telegram !== false;
    const em = el('input', { type: 'checkbox' }); em.checked = notify.email !== false;

    const saveLink = async () => {
      const v = slug.value.trim().toLowerCase();
      if (!/^[a-z0-9][a-z0-9-]{1,59}$/.test(v)) { Orch.toast('Use lower-case letters, digits and hyphens.', { error: true }); return; }
      if (v === row.slug) return;
      if ((await freeSlug(v, row._id)) !== v) { Orch.toast('Another form already uses that name.', { error: true }); return; }
      if (row.status === 'Live' && !(await Orch.confirm('Change the link of a live form? The old link stops working.', { yes: 'Change it' }))) return;
      if (await act(A.setSlug, { id: row._id, slug: v }, 'Link changed.')) again();
    };
    const saveRules = async () => {
      const at = closes.value ? new Date(closes.value) : null;
      await act(A.formSettings, { id: row._id, closes_at: at ? at.toISOString() : '', max_responses: max.value ? Number(max.value) : '',
        closed_message: message.value.trim(), notify: JSON.stringify({ telegram: tg.checked, email: em.checked }) }, 'Saved.');
    };
    const lifecycle = [];
    if (row.status === 'Live') lifecycle.push(button('Close it now', async () => { if (await act(A.close, { id: row._id }, 'Closed.')) again(); }));
    if (row.status === 'Closed') lifecycle.push(button('Reopen it', async () => { if (await act(A.reopen, { id: row._id }, 'Reopened.')) again(); }, true));
    lifecycle.push(Number(row.archived) === 1
      ? button('Bring it back from the archive', async () => { if (await act(A.unarchive, { id: row._id }, 'Back in Forms.')) again(); })
      : button('Archive it', async () => {
        if (!(await Orch.confirm('Archive this form? It leaves the list; its answers are kept and it can come back.', { yes: 'Archive' }))) return;
        if (row.status === 'Live') await act(A.close, { id: row._id });
        if (await act(A.archive, { id: row._id }, 'Archived.')) router.go('/');
      }));

    return el('div', { class: 'oc-stack oc-stack--loose fm-narrow' }, [
      formHead(list, 'settings'),
      card('Link', [
        el('label', { class: 'oc-field' }, [el('span', { class: 'oc-label' }, 'Link name'), slug, preview]),
        el('div', { class: 'oc-row' }, [button('Save the link', saveLink)]),
      ]),
      card('When it closes', [
        el('p', { class: 'oc-muted' }, 'It closes by itself on a date, or when enough people answered. Answers already on their way still count.'),
        el('div', { class: 'oc-row fm-row-fields' }, [
          el('label', { class: 'oc-field' }, [el('span', { class: 'oc-label' }, 'Close on'), closes]),
          el('label', { class: 'oc-field' }, [el('span', { class: 'oc-label' }, 'Most responses'), max]),
        ]),
        el('label', { class: 'oc-field' }, [el('span', { class: 'oc-label' }, 'What it says when closed'), message]),
        el('div', { class: 'oc-row' }, [button('Save', saveRules, true)]),
      ]),
      card('Who hears about new answers', [
        el('p', { class: 'oc-muted' }, ['New answers are announced where ', router.link('/settings', 'Settings'), ' says. For this form:']),
        el('label', { class: 'fm-check' }, [tg, el('span', `On Telegram${s.notify_telegram ? '' : ' (no chat set in Settings yet)'}`)]),
        el('label', { class: 'fm-check' }, [em, el('span', `By email${s.notify_emails ? '' : ' (no address set in Settings yet)'}`)]),
        el('div', { class: 'oc-row' }, [button('Save', saveRules)]),
      ]),
      card('Open, closed, archived', [el('div', { class: 'oc-row' }, lifecycle)]),
    ]);
  });
}

const card = (title, body) => el('section', { class: 'oc-card oc-stack' }, [el('h2', { class: 'oc-h3' }, title), ...body]);
const button = (label, run, primary) => el('button', { type: 'button', class: `oc-btn${primary ? ' oc-btn--primary' : ''}`, onClick: run }, label);
