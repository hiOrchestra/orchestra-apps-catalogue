// One question, edited: its type, its words, whether it is required, what
// its type needs (options, a scale, limits) and where people go after it.
import { F } from '../data.js';
import { field, text, number, check, select, typeSelect, freshRef, letter, recallPicker } from './build-kit.js';
import { logicEditor, forget } from './build-logic.js';

const { el } = Orch;

export function questionEditor(B, f) {
  const i = B.def.fields.indexOf(f);
  const statement = f.type === 'statement';
  const title = text(B, f, 'title', { area: true, rows: 2, label: 'Question', placeholder: statement ? 'What people read before going on' : 'Type the question' });
  const move = (by) => {
    const j = i + by;
    if (j < 0 || j >= B.def.fields.length) return;
    B.def.fields.splice(i, 1);
    B.def.fields.splice(j, 0, f);
    B.change({ editor: true });
  };
  const head = el('div', { class: 'fm-ed__head' }, [
    el('p', { class: 'oc-small oc-muted' }, `Question ${i + 1} of ${B.def.fields.length}`),
    el('div', { class: 'oc-row' }, [
      el('button', { type: 'button', class: 'oc-btn oc-btn--ghost oc-btn--sm', disabled: i === 0, onClick: () => move(-1) }, 'Move up'),
      el('button', { type: 'button', class: 'oc-btn oc-btn--ghost oc-btn--sm', disabled: i === B.def.fields.length - 1, onClick: () => move(1) }, 'Move down'),
      el('button', { type: 'button', class: 'oc-btn oc-btn--ghost oc-btn--sm', onClick: () => duplicate(B, f) }, 'Duplicate'),
      el('button', { type: 'button', class: 'oc-btn oc-btn--ghost oc-btn--sm', onClick: () => remove(B, f) }, 'Delete'),
    ]),
  ]);
  return el('div', { class: 'fm-ed oc-stack' }, [
    head,
    field('Type', typeSelect(f.type, (t) => { retype(B, f, t); B.change({ editor: true }); })),
    el('div', { class: 'oc-field' }, [el('span', { class: 'oc-label' }, statement ? 'Text' : 'Question'), title, recallPicker(B, i, title, f, 'title')]),
    field('Description', text(B, f.properties, 'description', { area: true, rows: 2, placeholder: 'Optional: a line under the question' })),
    statement ? field('Button', text(B, f.properties, 'button_text', { placeholder: B.def.language === 'es' ? 'Continuar' : 'Continue', dropEmpty: true }))
      : check(B, f.validations, 'required', 'Required: people cannot go on without answering'),
    ...specifics(B, f),
    logicEditor(B, f),
  ]);
}

/** What only this type needs. */
function specifics(B, f) {
  const p = f.properties;
  const v = f.validations;
  const kind = F.TYPES[f.type];
  if (f.type === 'multiple_choice' || f.type === 'dropdown') {
    const out = [choicesEditor(B, f)];
    if (f.type === 'multiple_choice') {
      out.push(el('div', { class: 'fm-checks' }, [
        check(B, p, 'allow_multiple_selection', 'People can choose several', () => B.change({ editor: true })),
        check(B, p, 'allow_other_choice', 'Add "Other", where people type their own'),
        check(B, p, 'randomize', 'Shuffle the options for each person'),
      ]));
      if (p.allow_multiple_selection) {
        out.push(el('div', { class: 'oc-row' }, [field('At least', number(B, v, 'min_selection', { min: 1, placeholder: 'Any' })),
          field('At most', number(B, v, 'max_selection', { min: 1, placeholder: 'Any' }))]));
      }
    }
    return out;
  }
  if (f.type === 'rating') {
    return [field('Stars', select([3, 4, 5, 6, 7, 8, 9, 10].map((n) => [n, String(n)]), p.steps || 5, (s) => { p.steps = Number(s); B.change(); }))];
  }
  if (f.type === 'opinion_scale' || f.type === 'nps') {
    const out = [];
    if (f.type === 'opinion_scale') {
      out.push(el('div', { class: 'oc-row' }, [
        field('Steps', select([5, 6, 7, 8, 9, 10, 11].map((n) => [n, String(n)]), p.steps || 11, (s) => { p.steps = Number(s); B.change(); })),
        check(B, p, 'start_at_one', 'Start at 1 instead of 0'),
      ]));
    }
    p.labels = p.labels || {};
    out.push(el('div', { class: 'fm-trio' }, [
      field('Left label', text(B, p.labels, 'left', { placeholder: f.type === 'nps' ? 'Not likely' : 'Optional', dropEmpty: true })),
      f.type === 'nps' ? null : field('Middle label', text(B, p.labels, 'center', { placeholder: 'Optional', dropEmpty: true })),
      field('Right label', text(B, p.labels, 'right', { placeholder: f.type === 'nps' ? 'Very likely' : 'Optional', dropEmpty: true })),
    ]));
    return out;
  }
  if (f.type === 'number') {
    return [el('div', { class: 'oc-row' }, [field('Lowest', number(B, v, 'min_value', { placeholder: 'Any', step: 'any' })),
      field('Highest', number(B, v, 'max_value', { placeholder: 'Any', step: 'any' }))])];
  }
  if (f.type === 'short_text' || f.type === 'long_text') {
    return [field('Longest answer', number(B, v, 'max_length', { min: 1, placeholder: f.type === 'long_text' ? '10000' : '1000' }), 'Characters.')];
  }
  if (f.type === 'legal') return [el('p', { class: 'oc-help' }, 'People answer "I accept" or "I don\'t accept". Required means they must accept to send.')];
  if (kind === 'text' || kind === 'date') return [el('p', { class: 'oc-help' }, `The answer is checked as ${F.TYPE_LABEL[f.type].toLowerCase()} before people can go on.`)];
  return [];
}

function choicesEditor(B, f) {
  const list = el('ol', { class: 'fm-options' });
  const choices = f.properties.choices;
  const draw = (focus) => {
    Orch.mount(list, choices.map((c, k) => {
      const input = el('input', { class: 'oc-input', type: 'text', 'aria-label': `Option ${k + 1}`, placeholder: `Option ${k + 1}` });
      input.value = c.label;
      input.addEventListener('input', () => { c.label = input.value; B.change(); });
      input.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); add(k + 1); } });
      if (focus === k) setTimeout(() => input.focus(), 0);
      const shift = (by) => { const j = k + by; if (j < 0 || j >= choices.length) return; choices.splice(k, 1); choices.splice(j, 0, c); B.change(); draw(j); };
      return el('li', { class: 'fm-option' }, [
        el('span', { class: 'fm-option__key', 'aria-hidden': 'true' }, letter(k)),
        input,
        el('button', { type: 'button', class: 'oc-btn oc-btn--ghost oc-btn--icon oc-btn--sm', 'aria-label': 'Move up', disabled: k === 0, onClick: () => shift(-1) }, '↑'),
        el('button', { type: 'button', class: 'oc-btn oc-btn--ghost oc-btn--icon oc-btn--sm', 'aria-label': 'Move down', disabled: k === choices.length - 1, onClick: () => shift(1) }, '↓'),
        el('button', { type: 'button', class: 'oc-btn oc-btn--ghost oc-btn--icon oc-btn--sm', 'aria-label': `Remove option ${k + 1}`, disabled: choices.length < 2,
          onClick: () => { choices.splice(k, 1); B.change(); draw(Math.max(0, k - 1)); } }, '×'),
      ]);
    }));
  };
  function add(at) {
    choices.splice(at, 0, { ref: freshRef(choices, 'option'), label: '' });
    B.change();
    draw(at);
  }
  draw();
  return el('div', { class: 'oc-field' }, [
    el('span', { class: 'oc-label' }, 'Options'),
    list,
    el('div', {}, el('button', { type: 'button', class: 'oc-btn oc-btn--sm', onClick: () => add(choices.length) }, 'Add an option')),
  ]);
}

/** A new type keeps the words and "required"; what belonged to the old type goes, and so do its rules. */
export function retype(B, f, type) {
  if (type === f.type) return;
  const es = B.def.language === 'es';
  f.type = type;
  f.properties = { description: f.properties.description || '' };
  f.validations = type === 'statement' ? {} : { required: !!f.validations.required };
  if (type === 'multiple_choice' || type === 'dropdown') {
    f.properties.choices = [1, 2].map((n) => ({ ref: `option_${n}`, label: es ? `Opción ${n}` : `Option ${n}` }));
  }
  if (type === 'rating') f.properties.steps = 5;
  if (type === 'opinion_scale') f.properties.steps = 11;
  B.def.logic = B.def.logic.filter((l) => l.ref !== f.ref);
}

export function addField(B, type) {
  const at = B.sel.kind === 'field' ? B.def.fields.findIndex((x) => x.ref === B.sel.ref) + 1 : B.def.fields.length;
  const f = { ref: freshRef(B.def.fields, 'q'), type: 'short_text', title: '', properties: { description: '' }, validations: {} };
  retype(B, Object.assign(f, { type: 'short_text' }), type);
  B.def.fields.splice(at < 1 ? B.def.fields.length : at, 0, f);
  B.select({ kind: 'field', ref: f.ref });
  B.change();
}

function duplicate(B, f) {
  const copy = JSON.parse(JSON.stringify(f));
  copy.ref = freshRef(B.def.fields, 'q');
  B.def.fields.splice(B.def.fields.indexOf(f) + 1, 0, copy);
  B.select({ kind: 'field', ref: copy.ref });
  B.change();
}

async function remove(B, f) {
  if (B.def.fields.length < 2) { Orch.toast('A form needs at least one question.', { error: true }); return; }
  const used = B.def.logic.some((l) => l.ref === f.ref || JSON.stringify(l).includes(`"${f.ref}"`));
  if (!(await Orch.confirm(used ? 'Delete this question and the jumps that use it?' : 'Delete this question?', { yes: 'Delete' }))) return;
  const i = B.def.fields.indexOf(f);
  B.def.fields.splice(i, 1);
  forget(B.def, f.ref);
  const next = B.def.fields[Math.min(i, B.def.fields.length - 1)];
  B.select({ kind: 'field', ref: next.ref });
  B.change();
}
