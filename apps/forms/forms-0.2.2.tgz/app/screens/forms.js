// Home: every form, how it is doing and its link. A draft opens on its
// builder; a form people answer opens on its responses.
import { V, badge, ago, copy, publicLink, settings } from '../data.js';

const { el, router, fmt } = Orch;

export async function render(_params, path) {
  await settings();
  const archived = path.startsWith('/archived');
  const base = archived ? '/archived' : '/';
  Orch.mount('view', el('div', { class: 'oc-stack oc-stack--loose' }, [
    el('div', { class: 'fm-pagehead' }, [
      el('div', {}, [
        el('h1', { class: 'oc-h1 oc-h1--collection' }, archived ? 'Archived forms' : 'Forms'),
        el('p', { class: 'oc-muted' }, archived ? 'Forms put away. Their answers are kept.' : 'Each form has a link people answer one question at a time.'),
      ]),
      el('div', { class: 'oc-row' }, [
        router.link(archived ? '/' : '/archived', archived ? 'Back to forms' : 'Archived', { class: 'oc-btn oc-btn--ghost' }),
        router.link('/new', 'New form', { class: 'oc-btn oc-btn--primary' }),
      ]),
    ]),
    el('div', { id: 'fm-list' }),
  ]));
  Orch.table({
    into: 'fm-list', path: base, query: path, view: V.list, filter: { archived: archived ? 'yes' : 'no' },
    search: 'title', searchPlaceholder: 'Find a form', pageSize: 25, sort: '_id:desc',
    columns: [
      { key: 'title', label: 'Form', render: (r) => el('div', { class: 'fm-name' }, [
        router.link(`/forms/${r._id}/${r.status === 'Draft' ? 'build' : 'responses'}`, r.title || 'Untitled form', { class: 'fm-name__link' }),
        r.ai_status === 'Working' ? el('span', { class: 'oc-small oc-muted' }, 'Being drafted…')
          : r.unpublished === 'yes' ? el('span', { class: 'oc-small oc-muted' }, 'Has unpublished changes') : null,
      ]) },
      { key: 'status', label: 'Status', render: (r) => badge(r.status) },
      { key: 'responses', label: 'Responses', numeric: true, render: (r) => fmt.number(r.responses || 0) },
      { key: 'this_week', label: 'Last 7 days', numeric: true, sortable: false, render: (r) => (r.this_week ? `+${fmt.number(r.this_week)}` : '—') },
      { key: 'last_response_at', label: 'Last answer', render: (r) => ago(r.last_response_at) },
      { key: 'slug', label: 'Link', sortable: false, render: (r) => (r.status === 'Live'
        ? el('button', { type: 'button', class: 'oc-btn oc-btn--sm oc-btn--ghost', onClick: () => copy(publicLink(r.slug), 'Link copied.') }, 'Copy link')
        : el('span', { class: 'oc-muted' }, r.status === 'Draft' ? 'Not published' : 'Closed')) },
    ],
    filters: [{ key: 'status', label: 'Status', options: ['Draft', 'Live', 'Closed'] }],
    empty: archived ? 'Nothing archived.' : 'No forms here yet. Start one with New form.',
  });
}
