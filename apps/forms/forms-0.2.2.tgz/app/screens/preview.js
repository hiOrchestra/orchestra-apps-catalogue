// The form as people will answer it, on a page of its own: the whole window,
// no rail, a thin bar to start over or go back to editing. The builder's
// Preview opens it in a new tab. Nothing is sent. It plays the draft, and
// follows the builder: each change made there (in this browser) restarts it.
import { F, T, formRow, versionDef, parse, settings } from '../data.js';
import { play } from '../render/player.js';

const { el, router } = Orch;
const KEY = (id) => `fm-preview:${id}`;

let current = null;
window.addEventListener('hashchange', () => {
  if (current && !/\/preview$/.test(location.hash)) { current.leave(); current = null; }
});

/** What the builder has on screen right now, for the preview tab (this browser only). */
export function handOver(id, def) {
  try { localStorage.setItem(KEY(id), JSON.stringify({ at: Date.now(), def })); } catch { /* storage off: the saved draft is used */ }
}

/** The builder's copy, unless the saved draft is newer (an agent, another browser). */
function handed(id, savedAt) {
  try {
    const v = JSON.parse(localStorage.getItem(KEY(id)) || 'null');
    const saved = Date.parse(String(savedAt || '').replace(' ', 'T') + (/Z|[+-]\d\d:?\d\d$/.test(savedAt || '') ? '' : 'Z'));
    return v && v.def && !(saved > v.at) ? v.def : null;
  } catch { return null; }
}

export function render({ id }) {
  if (current) { current.leave(); current = null; }
  document.body.classList.add('fm-previewing');
  Orch.load('view', async () => {
    const [row, list, s] = await Promise.all([Orch.db.get(T.forms, id), formRow(id), settings()]);
    if (!row || !list) return el('div', { class: 'oc-state' }, [el('p', 'This form does not exist.'), router.link('/', 'All forms')]);
    const saved = parse(row.draft, null) || await versionDef(row._id, row.version) || { title: row.title, fields: [] };
    return page(row, s, handed(row._id, row._updated_at) || saved);
  });
}

function page(row, s, first) {
  const host = el('div', { class: 'fm-preview__form' });
  let player = null;
  const start = (def) => {
    if (player) player.destroy();
    const live = F.normalize(def);
    if (!live.theme.accent && s.accent) live.theme.accent = s.accent;
    player = play(host, live, { preview: true });
  };
  const onStorage = (e) => {
    if (e.key !== KEY(row._id) || !e.newValue) return;
    try { start(JSON.parse(e.newValue).def); } catch { /* a bad hand-over: keep what is playing */ }
  };
  window.addEventListener('storage', onStorage);
  current = {
    leave() {
      window.removeEventListener('storage', onStorage);
      if (player) player.destroy();
      document.body.classList.remove('fm-previewing');
    },
  };
  setTimeout(() => start(first), 0);
  return el('div', { class: 'fm-preview' }, [
    el('header', { class: 'fm-preview__bar' }, [
      el('span', { class: 'fm-preview__what' }, [el('strong', row.title || 'Untitled form'), ' · Preview']),
      el('span', { class: 'oc-row' }, [
        el('button', { type: 'button', class: 'oc-btn oc-btn--ghost oc-btn--sm', onClick: () => player && player.restart() }, 'Start over'),
        router.link(`/forms/${row._id}/build`, 'Back to editing', { class: 'oc-btn oc-btn--sm' }),
      ]),
    ]),
    host,
  ]);
}
