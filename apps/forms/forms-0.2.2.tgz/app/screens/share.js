// How a form reaches people: its link (what it says when shared), a link that
// carries hidden fields, and what to tell someone sending it for you.
import { F, T, formRow, formHead, settings, versionDef, parse, publicLink, copy } from '../data.js';

const { el, router } = Orch;

export function render({ id }) {
  Orch.load('view', async () => {
    const [list, row] = await Promise.all([formRow(id), Orch.db.get(T.forms, id), settings()]);
    if (!list || !row) return el('p', { class: 'oc-state' }, 'This form does not exist.');
    const def = (await versionDef(row._id, row.version)) || F.normalize(parse(row.draft, {}));
    const link = publicLink(row.slug);
    const live = row.status === 'Live';
    const out = el('p', { class: 'fm-link' }, link);
    const values = {};
    const tagged = () => {
      const q = Object.entries(values).filter(([, v]) => v).map(([k, v]) => `${k}=${encodeURIComponent(v)}`).join('&');
      out.textContent = publicLink(row.slug, q);
    };
    return el('div', { class: 'oc-stack oc-stack--loose' }, [
      formHead(list, 'share'),
      live ? null : el('div', { class: 'fm-banner' }, row.status === 'Closed'
        ? [el('strong', 'This form is closed. '), 'The link shows its closing message until you reopen it in Settings.']
        : [el('strong', 'Not published yet. '), 'The link works once you publish the form from Build.']),
      el('section', { class: 'oc-card oc-stack' }, [
        el('h2', { class: 'oc-h2' }, 'Its link'),
        el('p', { class: 'oc-muted' }, 'Anyone with the link can answer, without signing in. It opens on a phone as well as a computer.'),
        out,
        el('div', { class: 'oc-row' }, [
          el('button', { type: 'button', class: 'oc-btn oc-btn--primary', onClick: () => copy(out.textContent, 'Link copied.') }, 'Copy link'),
          el('a', { class: 'oc-btn', href: link, target: '_blank', rel: 'noopener' }, 'Open it'),
        ]),
      ]),
      def.hidden.length ? el('section', { class: 'oc-card oc-stack' }, [
        el('h2', { class: 'oc-h2' }, 'A link that says where people came from'),
        el('p', { class: 'oc-muted' }, 'This form keeps these values with each answer, unseen by the person answering. Fill them in and the link above carries them.'),
        el('div', { class: 'fm-trio' }, def.hidden.map((h) => {
          const input = el('input', { class: 'oc-input', type: 'text', placeholder: h === 'utm_source' ? 'newsletter' : '' });
          input.addEventListener('input', () => { values[h] = input.value.trim(); tagged(); });
          return el('label', { class: 'oc-field' }, [el('span', { class: 'oc-label' }, h), input]);
        })),
      ]) : el('p', { class: 'oc-muted' }, ['To know where people come from (a newsletter, a post), add hidden fields in ',
        router.link(`/forms/${row._id}/build`, 'Build'), ' → The form.']),
      el('section', { class: 'oc-card oc-stack' }, [
        el('h2', { class: 'oc-h2' }, 'Sending it for you'),
        el('p', { class: 'oc-muted' }, 'An agent can share the link where you ask, and tell you who answered: ask it in a conversation, naming the form.'),
      ]),
    ]);
  });
}
