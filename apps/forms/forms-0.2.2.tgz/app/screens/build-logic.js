// "After this question": where people go, by what they answered. Each rule is
// a Typeform jump (if the answer is…, go to a later question or an ending);
// the first rule that holds wins, "everyone else" is a rule that always holds,
// and with none people go to the next question. Conditions written elsewhere
// (by an agent, over other answers) are shown and can be removed, not edited.
import { F } from '../data.js';
import { select, shortTitle } from './build-kit.js';

const { el } = Orch;

const OPS = {
  choice: [['is', 'is'], ['is_not', 'is not']],
  boolean: [['is', 'is']],
  number: [['equal', 'is'], ['not_equal', 'is not'], ['greater_than', 'is more than'], ['lower_than', 'is less than'],
    ['greater_equal_than', 'is at least'], ['lower_equal_than', 'is at most']],
  text: [['is', 'is'], ['is_not', 'is not'], ['contains', 'contains'], ['not_contains', 'does not contain'], ['begins_with', 'starts with'], ['ends_with', 'ends with']],
  date: [['on', 'is on'], ['earlier_than', 'is before'], ['later_than', 'is after']],
};

const kindOf = (f) => F.TYPES[f.type];

/** A rule this screen can edit: one comparison on this question's own answer, or "always". */
function simple(a, f) {
  const c = a.condition || {};
  if (c.op === 'always') return true;
  const v = c.vars || [];
  return (OPS[kindOf(f)] || []).some(([op]) => op === c.op) && v.length === 2 && v[0] && v[0].type === 'field' && v[0].value === f.ref
    && v[1] && ['constant', 'choice'].includes(v[1].type);
}

export function logicEditor(B, f) {
  const i = B.def.fields.indexOf(f);
  const kind = kindOf(f);
  if (kind === null && i === B.def.fields.length - 1) return null;
  const targets = [
    ...B.def.fields.slice(i + 1).map((x) => [`field:${x.ref}`, `${B.def.fields.indexOf(x) + 1}. ${shortTitle(x.title, 50) || F.TYPE_LABEL[x.type]}`]),
    ...B.def.thankyou_screens.map((s, k) => [`thankyou:${s.ref}`, `Ending ${k + 1}: ${shortTitle(s.title, 40) || 'Thank you'}`]),
  ];
  const entry = () => B.def.logic.find((l) => l.ref === f.ref);
  const rules = () => (entry() ? entry().actions : []);
  const tidy = () => { const e = entry(); if (e && !e.actions.length) B.def.logic.splice(B.def.logic.indexOf(e), 1); };
  const ensure = () => { let e = entry(); if (!e) { e = { type: 'field', ref: f.ref, actions: [] }; B.def.logic.push(e); } return e; };
  const host = el('div', { class: 'fm-logic__rules' });

  function targetPicker(a) {
    const to = (a.details && a.details.to) || {};
    const now = `${to.type}:${to.value}`;
    const opts = targets.some(([v]) => v === now) ? targets : [[now, 'An earlier question: choose another'], ...targets];
    return select(opts, now, (v) => {
      const [type, ...rest] = v.split(':');
      a.details = { to: { type, value: rest.join(':') } };
      B.change();
    }, 'Go to');
  }

  function valuePicker(a) {
    const vars = a.condition.vars;
    const cur = vars[1] || {};
    const set = (v) => { vars[1] = v; B.change(); };
    if (kind === 'choice') {
      const choices = f.properties.choices;
      return select(choices.map((c) => [c.ref, c.label || '(no text yet)']), cur.value, (v) => set({ type: 'choice', value: v }), 'Option');
    }
    if (kind === 'boolean') {
      return select([['true', f.type === 'legal' ? 'Accepted' : 'Yes'], ['false', f.type === 'legal' ? 'Not accepted' : 'No']], String(cur.value),
        (v) => set({ type: 'constant', value: v === 'true' }), 'Answer');
    }
    const input = el('input', { class: 'oc-input fm-logic__value', type: kind === 'number' ? 'number' : kind === 'date' ? 'date' : 'text', 'aria-label': 'Value' });
    input.value = cur.value === undefined ? '' : String(cur.value);
    input.addEventListener('input', () => set({ type: 'constant', value: kind === 'number' && input.value !== '' ? Number(input.value) : input.value }));
    return input;
  }

  function draw() {
    const list = rules();
    Orch.mount(host, list.map((a, k) => {
      const remove = el('button', { type: 'button', class: 'oc-btn oc-btn--ghost oc-btn--sm', 'aria-label': 'Remove this rule',
        onClick: () => { list.splice(k, 1); tidy(); B.change(); draw(); } }, 'Remove');
      if (a.action !== 'jump') return el('div', { class: 'fm-logic__rule fm-logic__rule--other' }, [el('span', { class: 'oc-muted' }, `A "${a.action}" rule (not supported, ignored)`), remove]);
      if (!simple(a, f)) return el('div', { class: 'fm-logic__rule fm-logic__rule--other' }, [el('span', { class: 'oc-muted' }, 'A rule over other answers, written outside the builder: go to'), targetPicker(a), remove]);
      if (a.condition.op === 'always') return el('div', { class: 'fm-logic__rule' }, [el('span', 'Everyone else goes to'), targetPicker(a), remove]);
      const op = select(OPS[kind], a.condition.op, (v) => { a.condition.op = v; B.change(); }, 'Comparison');
      return el('div', { class: 'fm-logic__rule' }, [el('span', 'If the answer'), op, valuePicker(a), el('span', 'go to'), targetPicker(a), remove]);
    }));
    const last = list.length && list[list.length - 1].condition && list[list.length - 1].condition.op === 'always';
    host.appendChild(el('p', { class: 'oc-help' }, last ? 'The rules are checked in order; the first that holds decides.'
      : `Anyone no rule catches goes to ${i + 1 < B.def.fields.length ? 'the next question' : 'the first ending'}.`));
  }

  function add(always) {
    if (!targets.length) return;
    const e = ensure();
    const [type, ...rest] = targets[0][0].split(':');
    const go = { type, value: rest.join(':') };
    const first = kind === 'choice' ? { type: 'choice', value: (f.properties.choices[0] || {}).ref }
      : kind === 'boolean' ? { type: 'constant', value: true } : { type: 'constant', value: kind === 'number' ? 0 : '' };
    const rule = always ? { action: 'jump', details: { to: go }, condition: { op: 'always', vars: [] } }
      : { action: 'jump', details: { to: go }, condition: { op: OPS[kind][0][0], vars: [{ type: 'field', value: f.ref }, first] } };
    const at = e.actions.findIndex((x) => x.condition && x.condition.op === 'always');
    if (always || at < 0) e.actions.push(rule); else e.actions.splice(at, 0, rule);
    B.change();
    draw();
  }

  draw();
  const hasAlways = () => rules().some((a) => a.condition && a.condition.op === 'always');
  return el('section', { class: 'fm-logic' }, [
    el('h3', { class: 'oc-h3' }, 'After this question'),
    host,
    el('div', { class: 'oc-row' }, [
      kind === null ? null : el('button', { type: 'button', class: 'oc-btn oc-btn--sm', onClick: () => add(false) }, 'Add a rule'),
      el('button', { type: 'button', class: 'oc-btn oc-btn--sm oc-btn--ghost', onClick: () => { if (!hasAlways()) add(true); } }, 'Send everyone else to…'),
    ]),
  ]);
}

/** A question is gone: so are the rules on it, the jumps to it and the conditions that read it. */
export function forget(def, ref) {
  def.logic = def.logic.filter((l) => l.ref !== ref).map((l) => Object.assign(l, { actions: l.actions.filter((a) => {
    const to = (a.details && a.details.to) || {};
    if (to.type === 'field' && to.value === ref) return false;
    return !reads(a.condition, ref);
  }) })).filter((l) => l.actions.length);
}

/** Does a condition (or any part of an and/or) read the answer to `ref`? */
function reads(c, ref) {
  return !!c && (c.vars || []).some((v) => !!v && ((v.type === 'field' && v.value === ref) || (!!v.op && reads(v, ref))));
}
