// The parts of a form that are not questions: the form itself (language,
// look, what the link may carry), its welcome screen and its endings.
import { field, text, check, select, recallPicker, freshRef } from './build-kit.js';

const { el } = Orch;

export function formEditor(B) {
  const d = B.def;
  const s = d.settings;
  const accent = el('input', { type: 'color', class: 'fm-color', 'aria-label': 'Accent colour' });
  // Without its own colour a form wears the public page's brand, which Settings keeps as `accent`.
  accent.value = [d.theme.accent, B.settings.accent].find((c) => /^#[0-9a-fA-F]{6}$/.test(c || '')) || '#000000';
  const accentNote = el('span', { class: 'oc-help' }, d.theme.accent ? `This form's own colour (${d.theme.accent}).` : "The app's colour. Pick one to give this form its own.");
  accent.addEventListener('input', () => { d.theme.accent = accent.value.toUpperCase(); accentNote.textContent = `This form's own colour (${d.theme.accent}).`; B.change(); });
  const hidden = el('input', { class: 'oc-input', type: 'text', placeholder: 'utm_source, ref', 'aria-label': 'Hidden fields' });
  hidden.value = d.hidden.join(', ');
  hidden.addEventListener('input', () => {
    d.hidden = [...new Set(hidden.value.split(/[,\s]+/).map((h) => h.trim().toLowerCase()).filter(Boolean))];
    B.change();
  });
  const progress = s.show_progress_bar === false ? 'off' : (s.progress_bar === 'percentage' ? 'percentage' : 'proportion');
  return el('div', { class: 'fm-ed oc-stack' }, [
    el('h2', { class: 'oc-h2' }, 'The form'),
    field('Title', text(B, d, 'title', { placeholder: 'What the form is called' }), 'People see it in the browser tab and as the welcome title.'),
    field('Language of the page', select([['es', 'Español'], ['en', 'English']], d.language, (v) => { d.language = v; B.change(); }),
      'The words around your questions: OK, Submit, "Please fill this in".'),
    el('h3', { class: 'oc-h3' }, 'How it looks'),
    el('div', { class: 'oc-row fm-accent' }, [accent, accentNote, d.theme.accent ? el('button', { type: 'button', class: 'oc-btn oc-btn--ghost oc-btn--sm',
      onClick: () => { d.theme.accent = ''; B.change({ editor: true }); } }, "Use the app's colour") : null]),
    field('Logo', text(B, d.theme, 'logo', { type: 'url', placeholder: 'https://… (optional)' }), 'An https address of an image, shown top left.'),
    field('Progress', select([['proportion', 'Answered, as "3 of 7"'], ['percentage', 'As a percentage'], ['off', 'Hidden']], progress, (v) => {
      if (v === 'off') s.show_progress_bar = false; else { s.show_progress_bar = true; s.progress_bar = v; }
      B.change();
    })),
    el('div', { class: 'fm-checks' }, [
      check(B, s, 'show_question_number', 'Number the questions', null, false),
      check(B, s, 'show_key_hint_on_choices', 'Show the letter to press on each option', null, false),
      check(B, s, 'show_time_to_complete', 'Say on the welcome screen how long it takes', null, false),
    ]),
    el('h3', { class: 'oc-h3' }, 'Hidden fields'),
    field('Names', hidden, 'Values that come in the link and are kept with each answer, unseen: …#/link-name?utm_source=newsletter. Separate with commas.'),
  ]);
}

export function welcomeEditor(B) {
  const w = B.def.welcome_screens[0];
  const p = w.properties;
  return el('div', { class: 'fm-ed oc-stack' }, [
    el('div', { class: 'fm-ed__head' }, [el('h2', { class: 'oc-h2' }, 'Welcome screen'),
      el('button', { type: 'button', class: 'oc-btn oc-btn--ghost oc-btn--sm', onClick: () => {
        B.def.welcome_screens = [];
        B.select({ kind: 'form' });
        B.change();
      } }, 'Remove it')]),
    el('p', { class: 'oc-help' }, 'What people see before the first question.'),
    field('Title', text(B, w, 'title', { placeholder: B.def.title })),
    field('Text', text(B, p, 'description', { area: true, rows: 3, placeholder: 'Optional: why it matters, how long it takes' })),
    field('Button', text(B, p, 'button_text', { placeholder: B.def.language === 'es' ? 'Empezar' : 'Start', dropEmpty: true })),
  ]);
}

export function endingEditor(B, e) {
  const k = B.def.thankyou_screens.indexOf(e);
  const p = e.properties;
  const title = text(B, e, 'title', { area: true, rows: 2, placeholder: B.def.language === 'es' ? '¡Gracias!' : 'Thank you!' });
  const jumps = B.def.logic.some((l) => l.actions.some((a) => a.details && a.details.to && a.details.to.type === 'thankyou' && a.details.to.value === e.ref));
  return el('div', { class: 'fm-ed oc-stack' }, [
    el('div', { class: 'fm-ed__head' }, [el('h2', { class: 'oc-h2' }, `Ending ${k + 1}`),
      B.def.thankyou_screens.length > 1 ? el('button', { type: 'button', class: 'oc-btn oc-btn--ghost oc-btn--sm', onClick: () => {
        if (jumps) { Orch.toast('A jump leads here: change it first.', { error: true }); return; }
        B.def.thankyou_screens.splice(k, 1);
        B.select({ kind: 'ending', ref: B.def.thankyou_screens[0].ref });
        B.change();
      } }, 'Delete') : null]),
    el('p', { class: 'oc-help' }, k === 0 ? 'Where people land when no jump sends them elsewhere.' : 'People land here only when a jump sends them.'),
    el('div', { class: 'oc-field' }, [el('span', { class: 'oc-label' }, 'Title'), title, recallPicker(B, B.def.fields.length, title, e, 'title')]),
    field('Text', text(B, p, 'description', { area: true, rows: 3, placeholder: 'Optional: what happens next' })),
    field('Then send people to', text(B, p, 'redirect_url', { type: 'url', placeholder: 'https://… (optional)', dropEmpty: true }),
      'A web page that opens a few seconds after the ending. It may carry answers: https://example.com/?name={{field:name}}'),
  ]);
}

export function addWelcome(B) {
  B.def.welcome_screens = [{ ref: 'welcome', title: B.def.title, properties: { description: '' } }];
  B.select({ kind: 'welcome' });
  B.change();
}

export function addEnding(B) {
  const e = { ref: freshRef(B.def.thankyou_screens, 'ending'), title: '', properties: {} };
  B.def.thankyou_screens.push(e);
  B.select({ kind: 'ending', ref: e.ref });
  B.change();
}

