// Settings for every form: where new answers are announced, and the language
// a new form starts in.
import { A, act, settings } from '../data.js';

const { el } = Orch;

export function render() {
  Orch.load('view', async () => {
    const s = await settings(true);
    const lang = el('select', { class: 'oc-select' }, [['es', 'Español'], ['en', 'English']].map(([v, l]) => {
      const o = el('option', { value: v }, l); if (v === (s.language || 'es')) o.selected = true; return o;
    }));
    const tg = el('input', { class: 'oc-input', type: 'text', placeholder: '@your_chat or 123456789' });
    tg.value = s.notify_telegram || '';
    const em = el('input', { class: 'oc-input', type: 'text', placeholder: 'you@company.com, partner@company.com' });
    em.value = s.notify_emails || '';
    const save = el('button', { type: 'button', class: 'oc-btn oc-btn--primary' }, 'Save');
    save.addEventListener('click', async () => {
      const chat = tg.value.trim();
      if (chat && !/^(-?\d{5,20}|@[A-Za-z0-9_]{5,32})$/.test(chat)) { Orch.toast('A Telegram chat is its number or @name.', { error: true }); return; }
      if (await act(A.settings, { id: s._id, language: lang.value, notify_telegram: chat, notify_emails: em.value.trim() }, 'Saved.')) await settings(true);
    });
    return el('div', { class: 'oc-stack oc-stack--loose fm-narrow' }, [
      el('div', {}, [el('h1', { class: 'oc-h1 oc-h1--collection' }, 'Settings'), el('p', { class: 'oc-muted' }, 'For every form. Each form can turn its announcements off in its own Settings.')]),
      el('section', { class: 'oc-card oc-stack' }, [
        el('h2', { class: 'oc-h3' }, 'Where new answers are announced'),
        el('p', { class: 'oc-muted' }, 'Seconds after an answer arrives, a message says which form it is for and who sent it.'),
        el('label', { class: 'oc-field' }, [el('span', { class: 'oc-label' }, 'Telegram chat'), tg,
          el('span', { class: 'oc-help' }, "A chat this workspace's Telegram bot is already in.")]),
        el('label', { class: 'oc-field' }, [el('span', { class: 'oc-label' }, 'Email'), em,
          el('span', { class: 'oc-help' }, "Up to five addresses of people in this workspace; the workspace's own address sends it.")]),
      ]),
      el('section', { class: 'oc-card oc-stack' }, [
        el('h2', { class: 'oc-h3' }, 'New forms'),
        el('label', { class: 'oc-field' }, [el('span', { class: 'oc-label' }, 'Language they start in'), lang,
          el('span', { class: 'oc-help' }, 'The words around the questions (OK, Submit, "Please fill this in") follow each form\'s own language.')]),
      ]),
      el('div', { class: 'oc-row' }, [save]),
    ]);
  });
}
