// What the form says around the questions, in the form's language. The
// questions themselves are the author's; these are the page's own words.
// Spanish uses tú: the people answering are the tenant's customers.
const WORDS = {
  es: {
    start: 'Empezar', ok: 'OK', submit: 'Enviar', continue: 'Continuar', pressEnter: 'pulsa Enter ↵',
    shiftEnter: 'Shift ⇧ + Enter ↵ para un salto de línea', typeHere: 'Escribe tu respuesta aquí…',
    chooseMany: 'Elige todas las que quieras', chooseUpTo: 'Elige hasta {n}', chooseAtLeast: 'Elige al menos {n}',
    other: 'Otra', otherPlaceholder: 'Escribe tu respuesta', search: 'Escribe o elige una opción', noMatch: 'Ninguna opción coincide',
    yes: 'Sí', no: 'No', accept: 'Acepto', decline: 'No acepto', required: 'Obligatoria',
    progress: '{n} de {total} respondidas', percent: '{n}% completado', back: 'Pregunta anterior', next: 'Pregunta siguiente', nav: 'Avance',
    sending: 'Enviando…', retrying: 'No se pudo enviar todavía: lo intentamos de nuevo en {s} s', sendFailed: 'No se pudo enviar. Tus respuestas siguen aquí.',
    tryAgain: 'Intentar de nuevo', thanks: '¡Gracias!', thanksText: 'Recibimos tus respuestas.', redirecting: 'Te llevamos a la página siguiente…',
    goNow: 'Ir ahora', takes: 'Lleva {n} min', resumed: 'Seguimos donde lo dejaste.', startOver: 'Empezar de nuevo',
    closed: 'Este formulario está cerrado', closedText: 'Ya no recibe respuestas.', missing: 'No encontramos este formulario',
    missingText: 'Revisa el enlace que recibiste: puede estar incompleto o el formulario ya no existe.',
    notYet: 'Este formulario todavía no está abierto', notYetText: 'Vuelve a probar en un rato.',
    busy: 'Hay mucha gente respondiendo', busyText: 'Espera un minuto y vuelve a cargar la página.',
    broken: 'No se pudo abrir el formulario', brokenText: 'Vuelve a cargar la página en un momento.',
    preview: 'Vista previa: no se envía nada', previewDone: 'Así termina el formulario. En la vista previa no se guarda nada.',
    err: {
      required: 'Completa este campo', email: 'Ese email no parece válido', url: 'Esa dirección web no parece válida',
      phone: 'Ese teléfono no parece válido', number: 'Escribe un número', min: 'El número tiene que ser {n} o más',
      max: 'El número tiene que ser {n} o menos', max_length: 'Es demasiado largo: hasta {n} caracteres', date: 'Elige una fecha válida',
      choice: 'Elige una opción', min_selection: 'Elige al menos {n}', max_selection: 'Elige hasta {n}', accept: 'Necesitamos que aceptes para seguir',
      range: 'Elige un valor de la escala',
    },
  },
  en: {
    start: 'Start', ok: 'OK', submit: 'Submit', continue: 'Continue', pressEnter: 'press Enter ↵',
    shiftEnter: 'Shift ⇧ + Enter ↵ to make a line break', typeHere: 'Type your answer here…',
    chooseMany: 'Choose as many as you like', chooseUpTo: 'Choose up to {n}', chooseAtLeast: 'Choose at least {n}',
    other: 'Other', otherPlaceholder: 'Type your answer', search: 'Type or select an option', noMatch: 'No option matches',
    yes: 'Yes', no: 'No', accept: 'I accept', decline: "I don't accept", required: 'Required',
    progress: '{n} of {total} answered', percent: '{n}% completed', back: 'Previous question', next: 'Next question', nav: 'Progress',
    sending: 'Sending…', retrying: 'Not sent yet: trying again in {s} s', sendFailed: 'It could not be sent. Your answers are still here.',
    tryAgain: 'Try again', thanks: 'Thank you!', thanksText: 'Your answers are in.', redirecting: 'Taking you to the next page…',
    goNow: 'Go now', takes: 'Takes {n} min', resumed: 'Picking up where you left off.', startOver: 'Start over',
    closed: 'This form is closed', closedText: 'It no longer takes answers.', missing: 'We could not find this form',
    missingText: 'Check the link you received: it may be incomplete, or the form no longer exists.',
    notYet: 'This form is not open yet', notYetText: 'Try again in a little while.',
    busy: 'Many people are answering right now', busyText: 'Wait a minute and reload the page.',
    broken: 'The form could not be opened', brokenText: 'Reload the page in a moment.',
    preview: 'Preview: nothing is sent', previewDone: 'This is how the form ends. Nothing is saved in the preview.',
    err: {
      required: 'Please fill this in', email: "That email doesn't look right", url: "That web address doesn't look right",
      phone: "That phone number doesn't look right", number: 'Type a number', min: 'The number must be {n} or more',
      max: 'The number must be {n} or less', max_length: 'Too long: up to {n} characters', date: 'Choose a valid date',
      choice: 'Choose an option', min_selection: 'Choose at least {n}', max_selection: 'Choose up to {n}', accept: 'You need to accept to continue',
      range: 'Choose a value on the scale',
    },
  },
};

/** The page's words in `lang` (Spanish when unknown), with {name} filled in. */
export function words(lang) {
  const w = WORDS[lang] || WORDS.es;
  const say = (key, vars) => {
    const text = key.startsWith('err.') ? w.err[key.slice(4)] : w[key];
    return String(text === undefined ? key : text).replace(/\{(\w+)\}/g, (m, k) => (vars && vars[k] !== undefined ? vars[k] : m));
  };
  say.yes = w.yes;
  say.no = w.no;
  return say;
}

/** The message for an answer FormCore refused, with the limit it broke. */
export function problem(say, code, field) {
  const v = (field && field.validations) || {};
  const cap = v.max_length || (field && field.type === 'long_text' ? 10000 : 1000);
  const n = { min: v.min_value, max: v.max_value, max_length: cap, min_selection: v.min_selection, max_selection: v.max_selection }[code];
  return say(`err.${code}`, { n });
}
