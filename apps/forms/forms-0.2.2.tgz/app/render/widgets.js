// One input per question type, each the shape Typeform taught people: a line
// to type on, options with a letter to press, stars, a numbered scale. Every
// widget returns { el, value(), focus(), key(event) }; `env.pick(value)` says
// "this is the answer, move on", `env.changed()` that it changed.
const { el } = Orch;
const F = self.FormCore;

const STAR = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 2.6l2.85 5.95 6.55.8-4.8 4.55 1.22 6.5L12 17.25 6.18 20.4l1.22-6.5-4.8-4.55 6.55-.8z"/></svg>';
const CHECK = '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8.5l3 3 7-7" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>';
const keyOf = (i) => (i < 26 ? String.fromCharCode(65 + i) : '');
const fold = (s) => String(s || '').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase();

export function widgetFor(field, value, env) {
  const kind = F.TYPES[field.type];
  if (kind === null) return { el: null, value: () => undefined, focus() {}, key: () => false };
  if (field.type === 'dropdown') return dropdown(field, value, env);
  if (kind === 'choice' || kind === 'boolean') return choices(field, value, env);
  if (field.type === 'rating') return stars(field, value, env);
  if (field.type === 'opinion_scale' || field.type === 'nps') return scale(field, value, env);
  if (field.type === 'long_text') return longText(field, value, env);
  return line(field, value, env);
}

function line(field, value, env) {
  const type = { email: 'email', phone_number: 'tel', website: 'url', date: 'date' }[field.type] || 'text';
  const auto = { email: 'email', phone_number: 'tel', website: 'url' }[field.type]
    || (/^(name|nombre|first_name)$/.test(field.ref) ? 'name' : 'off');
  const input = el('input', { class: `fx-input${type === 'date' ? ' fx-input--date' : ''}`, type, autocomplete: auto,
    placeholder: type === 'date' ? null : env.say('typeHere'), 'aria-label': field.title,
    inputmode: field.type === 'number' ? 'decimal' : null, enterkeyhint: 'next' });
  input.value = value === undefined || value === null ? '' : String(value);
  input.addEventListener('input', env.changed);
  const read = () => {
    const s = input.value.trim();
    if (!s) return undefined;
    return field.type === 'number' ? (Number.isFinite(Number(s.replace(',', '.'))) ? Number(s.replace(',', '.')) : s) : input.value;
  };
  return { el: input, value: read, focus: () => input.focus(), key: () => false };
}

function longText(field, value, env) {
  const area = el('textarea', { class: 'fx-input fx-input--long', rows: '1', placeholder: env.say('typeHere'), 'aria-label': field.title });
  area.value = value || '';
  const grow = () => { area.style.height = 'auto'; area.style.height = `${Math.min(area.scrollHeight, 320)}px`; };
  area.addEventListener('input', () => { grow(); env.changed(); });
  setTimeout(grow, 0);
  const box = el('div', {}, [area, el('p', { class: 'fx-hint fx-hint--below' }, env.say('shiftEnter'))]);
  return { el: box, value: () => (area.value.trim() ? area.value : undefined), focus: () => area.focus(), key: () => false };
}

/** Options to pick: multiple choice, yes/no and consent. One is picked and moves on; several wait for OK. */
function choices(field, value, env) {
  const p = field.properties || {};
  const many = field.type === 'multiple_choice' && !!p.allow_multiple_selection;
  let opts;
  if (field.type === 'yes_no') opts = [{ v: true, label: env.say.yes }, { v: false, label: env.say.no }];
  else if (field.type === 'legal') opts = [{ v: true, label: env.say('accept') }, { v: false, label: env.say('decline') }];
  else {
    opts = p.choices.map((c) => ({ v: c.ref, label: c.label }));
    if (p.randomize) opts = env.once(`order:${field.ref}`, () => opts.map((o) => [Math.random(), o]).sort((a, b) => a[0] - b[0]).map((x) => x[1]));
    if (p.allow_other_choice) opts = opts.concat([{ v: '__other', label: env.say('other') }]);
  }
  // Yes/no answers with its own initials, as Typeform does (Y/N, S/N); everything else with A, B, C…
  opts.forEach((o, i) => { o.key = field.type === 'yes_no' ? o.label.charAt(0).toUpperCase() : keyOf(i); });
  const given = many ? (Array.isArray(value) ? value : []) : (value === undefined ? [] : [value]);
  const picked = new Set(given.filter((x) => typeof x !== 'object'));
  const otherGiven = given.find((x) => x && typeof x === 'object');
  const other = el('input', { class: 'fx-input fx-input--other', type: 'text', placeholder: env.say('otherPlaceholder'), 'aria-label': env.say('other') });
  other.value = otherGiven ? otherGiven.other : '';
  if (otherGiven) picked.add('__other');
  const buttons = opts.map((o) => {
    const b = el('button', { type: 'button', class: 'fx-choice', role: many ? 'checkbox' : 'radio', 'data-key': o.key,
      onClick: () => choose(o) }, [
      env.keyHints && o.key ? el('span', { class: 'fx-key', 'aria-hidden': 'true' }, o.key) : null,
      el('span', { class: 'fx-choice__label' }, o.label),
      el('span', { class: 'fx-choice__check', html: CHECK }),
    ]);
    return { o, b };
  });
  const paint = () => {
    for (const { o, b } of buttons) b.setAttribute('aria-checked', String(picked.has(o.v)));
    other.hidden = !picked.has('__other');
  };
  function choose(o) {
    if (o.v === '__other') {
      if (many && picked.has('__other')) picked.delete('__other'); else { if (!many) picked.clear(); picked.add('__other'); }
      paint();
      if (picked.has('__other')) other.focus();
      env.changed();
      return;
    }
    if (many) { if (picked.has(o.v)) picked.delete(o.v); else picked.add(o.v); paint(); env.changed(); return; }
    picked.clear();
    picked.add(o.v);
    paint();
    env.pick(o.v);
  }
  other.addEventListener('input', env.changed);
  paint();
  const v = field.validations || {};
  const note = many ? (v.max_selection ? env.say('chooseUpTo', { n: v.max_selection })
    : v.min_selection ? env.say('chooseAtLeast', { n: v.min_selection }) : env.say('chooseMany')) : null;
  const list = el('div', { class: 'fx-choices', role: many ? 'group' : 'radiogroup', 'aria-label': field.title }, buttons.map((x) => x.b));
  const read = () => {
    const out = [...picked].filter((x) => x !== '__other');
    if (picked.has('__other') && other.value.trim()) out.push({ other: other.value });
    else if (picked.has('__other') && !many) return { other: '' };
    return many ? (out.length ? out : undefined) : out[0];
  };
  return {
    el: el('div', {}, [note ? el('p', { class: 'fx-hint fx-hint--above' }, note) : null, list, other]),
    value: read,
    focus: () => (buttons[0] && buttons[0].b.focus()),
    key: (e) => {
      const hit = buttons.find((x) => x.o.key && x.o.key === e.key.toUpperCase());
      if (!hit) return false;
      choose(hit.o);
      return true;
    },
  };
}

/** A long list: type to narrow it, arrows to move, Enter to pick. */
function dropdown(field, value, env) {
  const all = field.properties.choices;
  const input = el('input', { class: 'fx-input', type: 'text', role: 'combobox', 'aria-expanded': 'true', 'aria-autocomplete': 'list',
    placeholder: env.say('search'), 'aria-label': field.title, autocomplete: 'off' });
  const list = el('ul', { class: 'fx-dd', role: 'listbox' });
  let chosen = value;
  let shown = [];
  let at = -1;
  const current = all.find((c) => c.ref === value);
  if (current) input.value = current.label;
  const draw = () => {
    const q = fold(input.value);
    shown = current && input.value === current.label ? all : all.filter((c) => fold(c.label).includes(q));
    at = Math.min(Math.max(at, shown.length ? 0 : -1), shown.length - 1);
    Orch.mount(list, shown.length ? shown.map((c, i) => el('li', { role: 'option', class: 'fx-dd__item', 'aria-selected': String(c.ref === chosen),
      'data-active': String(i === at), onMousedown: (e) => { e.preventDefault(); pick(c); } }, c.label))
      : el('li', { class: 'fx-dd__none' }, env.say('noMatch')));
  };
  const pick = (c) => { chosen = c.ref; input.value = c.label; draw(); env.pick(c.ref); };
  input.addEventListener('input', () => { chosen = undefined; at = 0; draw(); env.changed(); });
  input.addEventListener('keydown', (e) => {
    if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
      e.preventDefault();
      at = Math.max(0, Math.min(shown.length - 1, at + (e.key === 'ArrowDown' ? 1 : -1)));
      draw();
    } else if (e.key === 'Enter' && shown[at] && chosen !== shown[at].ref) { e.preventDefault(); e.stopPropagation(); pick(shown[at]); }
  });
  draw();
  return { el: el('div', { class: 'fx-dd-wrap' }, [input, list]), value: () => chosen, focus: () => input.focus(), key: () => false };
}

function stars(field, value, env) {
  const [, hi] = F.scale(field);
  const buttons = [];
  const paint = (upTo) => buttons.forEach((b, i) => {
    b.setAttribute('aria-checked', String(i + 1 === value));
    b.classList.toggle('is-on', i + 1 <= upTo);
  });
  for (let n = 1; n <= hi; n += 1) {
    const b = el('button', { type: 'button', class: 'fx-star', role: 'radio', 'aria-label': String(n), html: STAR,
      onClick: () => { value = n; paint(n); env.pick(n); } });
    b.addEventListener('mouseenter', () => paint(n));
    b.addEventListener('mouseleave', () => paint(value || 0));
    buttons.push(b);
  }
  paint(value || 0);
  return { el: el('div', { class: 'fx-stars', role: 'radiogroup', 'aria-label': field.title }, buttons), value: () => value,
    focus: () => buttons[0].focus(), key: digits(1, hi, (n) => buttons[n - 1].click()) };
}

/** Opinion scale and NPS: numbered boxes, with the words for each end under them. */
function scale(field, value, env) {
  const [lo, hi] = F.scale(field);
  const labels = field.properties.labels || {};
  const buttons = [];
  for (let n = lo; n <= hi; n += 1) {
    buttons.push(el('button', { type: 'button', class: 'fx-scale__n', role: 'radio', 'aria-checked': String(n === value),
      onClick: () => { buttons.forEach((b) => b.setAttribute('aria-checked', 'false')); buttons[n - lo].setAttribute('aria-checked', 'true'); env.pick(n); } }, String(n)));
  }
  const row = el('div', { class: 'fx-scale', role: 'radiogroup', 'aria-label': field.title }, buttons);
  row.style.setProperty('--n', String(hi - lo + 1));
  const ends = labels.left || labels.right || labels.center
    ? el('div', { class: 'fx-scale__ends', 'aria-hidden': 'true' }, [el('span', labels.left || ''), el('span', labels.center || ''), el('span', labels.right || '')]) : null;
  return { el: el('div', {}, [row, ends]), value: () => value, focus: () => buttons[0].focus(),
    key: digits(lo, hi, (n) => buttons[n - lo].click()) };
}

/** Number keys pick a value; "1" then "0" quickly makes 10. */
function digits(lo, hi, press) {
  let buffer = '';
  let timer = null;
  return (e) => {
    if (!/^[0-9]$/.test(e.key)) return false;
    buffer += e.key;
    clearTimeout(timer);
    const n = Number(buffer);
    const longer = buffer !== '0' && Number(`${buffer}0`) <= hi;
    if (!longer || buffer.length >= 2) { buffer = ''; if (n >= lo && n <= hi) press(n); return true; }
    timer = setTimeout(() => { const m = Number(buffer); buffer = ''; if (m >= lo && m <= hi) press(m); }, 500);
    return true;
  };
}
