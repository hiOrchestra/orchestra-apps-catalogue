// A form, played the way Typeform plays it: a welcome, one question at a
// time, Enter or OK to go on, letters and numbers to pick, a jump when an
// answer says so, earlier answers written into later questions, and an
// ending. The rules (what a valid answer is, where a jump goes) are
// FormCore's, so the server later checks exactly what this page asked for.
//
//   const p = play(host, def, { hidden, start, preview, scopeKeys, onProgress, onStep, onDone });
//   p.peek(ref)  show one question (the builder's preview)    p.destroy()
//
// onDone({ answers, ending, ms, hidden }, status) sends the response; it may
// call status(text) while it retries, and throws when it gives up.
import { words, problem } from './i18n.js';
import { widgetFor } from './widgets.js';

const { el } = Orch;
const F = self.FormCore;
const UP = '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M4 10l4-4 4 4" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>';
const DOWN = '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M4 6l4 4 4-4" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>';
const ARROW = '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8h9M9 4.5L12.5 8 9 11.5" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round"/></svg>';
const TICK = '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8.5l3 3 7-7" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg>';
const TYPED = ['short_text', 'long_text', 'email', 'phone_number', 'website', 'number', 'date', 'dropdown'];
const calm = () => !!(window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches);

export function play(host, def, opts = {}) {
  const say = words(def.language);
  const hidden = opts.hidden || {};
  const cache = {};
  const st = {
    answers: Object.assign({}, opts.start && opts.start.answers),
    history: ((opts.start && opts.start.history) || []).filter((r) => F.byRef(def, r)),
    startedAt: (opts.start && opts.start.startedAt) || 0,
    at: null, field: null, widget: null, err: null, actions: null, busy: false, done: false, timer: null,
  };

  const root = el('div', { class: 'fx', lang: def.language });
  if (/^#[0-9a-fA-F]{6}$/.test((def.theme && def.theme.accent) || '')) {
    root.style.setProperty('--f-accent', def.theme.accent);
    root.style.setProperty('--f-accent-ink', F.inkFor(def.theme.accent));
  }
  const fill = el('span');
  const bar = el('div', { class: 'fx-bar', 'aria-hidden': 'true' }, fill);
  const stage = el('div', { class: 'fx-stage' });
  const told = el('span', { class: 'fx-nav__progress' });
  const upBtn = el('button', { type: 'button', class: 'fx-nav__btn', 'aria-label': say('back'), html: UP, onClick: () => back() });
  const downBtn = el('button', { type: 'button', class: 'fx-nav__btn', 'aria-label': say('next'), html: DOWN, onClick: () => ok() });
  const nav = el('nav', { class: 'fx-nav', 'aria-label': say('nav') }, [told, el('div', { class: 'fx-nav__btns' }, [upBtn, downBtn])]);
  Orch.append(root, [
    bar,
    def.theme && /^https:\/\//.test(def.theme.logo || '') ? el('img', { class: 'fx-logo', src: def.theme.logo, alt: '' }) : null,
    opts.preview ? el('p', { class: 'fx-preview' }, say('preview')) : null,
    stage, nav,
    // Where the platform puts "Powered by Orchestra" on a public page (empty on the desk's preview).
    el('div', { class: 'fx-credit', 'data-oc-credit': '' }),
  ]);
  Orch.mount(host, root);
  document.addEventListener('keydown', onKey);

  // ── what is on screen ──────────────────────────────────────────────────
  function swap(node, dir) {
    if (!calm()) node.classList.add(dir === 'down' ? 'fx-in-down' : 'fx-in-up');
    Orch.mount(stage, node);
  }

  function show(step, dir) {
    clearTimeout(st.timer);
    st.at = step;
    if (step.type === 'welcome') return welcome();
    if (step.type === 'thankyou') return ending(step.ref, st.answers);
    return question(F.byRef(def, step.ref), dir);
  }

  function welcome() {
    const w = def.welcome_screens[0];
    const p = w.properties || {};
    const asked = def.fields.filter((f) => F.TYPES[f.type] !== null).length;
    nav.hidden = true;
    bar.hidden = true;
    swap(el('section', { class: 'fx-screen' }, [
      el('h1', { class: 'fx-screen__title', tabindex: '-1' }, w.title || def.title),
      p.description ? el('p', { class: 'fx-desc' }, p.description) : null,
      el('div', { class: 'fx-actions' }, [
        el('button', { type: 'button', class: 'fx-ok', onClick: () => ok() }, p.button_text || say('start')),
        el('span', { class: 'fx-hint fx-hint--enter' }, say('pressEnter')),
      ]),
      def.settings.show_time_to_complete === false ? null
        : el('p', { class: 'fx-hint' }, say('takes', { n: Math.max(1, Math.round((asked * 12) / 60)) })),
    ]), 'up');
  }

  function question(f, dir) {
    st.field = f;
    const i = def.fields.indexOf(f);
    const statement = f.type === 'statement';
    const number = def.fields.slice(0, i + 1).filter((x) => x.type !== 'statement').length;
    const env = { say, keyHints: def.settings.show_key_hint_on_choices !== false, changed: clearError,
      pick: (v) => { clearError(); clearTimeout(st.timer); st.timer = setTimeout(() => ok(v), calm() ? 0 : 320); },
      once: (k, fn) => (k in cache ? cache[k] : (cache[k] = fn())) };
    st.widget = widgetFor(f, st.answers[f.ref], env);
    const last = i === def.fields.length - 1 && !def.logic.some((l) => l.ref === f.ref);
    st.err = el('p', { class: 'fx-error', role: 'alert', hidden: true });
    st.actions = el('div', { class: 'fx-actions' }, [
      el('button', { type: 'button', class: 'fx-ok', onClick: () => ok() },
        statement ? (f.properties.button_text || say('continue')) : last ? say('submit') : [say('ok'), el('span', { class: 'fx-ok__tick', html: TICK })]),
      el('span', { class: 'fx-hint fx-hint--enter' }, say('pressEnter')),
    ]);
    const title = el('h1', { class: 'fx-title', id: `q-${f.ref}`, tabindex: '-1' }, [
      F.recall(f.title, def, st.answers, hidden, say),
      f.validations.required ? el('span', { class: 'fx-req', 'aria-label': say('required') }, ' *') : null,
    ]);
    swap(el('section', { class: `fx-step${statement ? ' fx-step--statement' : ''}`, 'aria-labelledby': `q-${f.ref}` }, [
      def.settings.show_question_number === false || statement ? null : el('p', { class: 'fx-num' }, [String(number), el('span', { html: ARROW })]),
      title,
      f.properties.description ? el('p', { class: 'fx-desc' }, F.recall(f.properties.description, def, st.answers, hidden, say)) : null,
      st.widget.el ? el('div', { class: 'fx-answer' }, st.widget.el) : null,
      st.err,
      st.actions,
    ]), dir);
    progress();
    setTimeout(() => { if (!root.isConnected) return; if (TYPED.includes(f.type)) st.widget.focus(); else title.focus({ preventScroll: true }); }, calm() ? 0 : 240);
  }

  function ending(ref, answers, previewed) {
    const e = F.endingOf(def, ref) || def.thankyou_screens[0];
    const p = e.properties || {};
    const go = /^https?:\/\//i.test(p.redirect_url || '') ? link(p.redirect_url) : '';
    nav.hidden = true;
    fill.style.width = '100%';
    swap(el('section', { class: 'fx-screen fx-screen--end' }, [
      el('h1', { class: 'fx-screen__title', tabindex: '-1' }, F.recall(e.title, def, answers, hidden, say) || say('thanks')),
      p.description ? el('p', { class: 'fx-desc' }, F.recall(p.description, def, answers, hidden, say)) : (e.title ? null : el('p', { class: 'fx-desc' }, say('thanksText'))),
      previewed ? el('p', { class: 'fx-hint' }, say('previewDone')) : null,
      go && !previewed ? el('p', { class: 'fx-hint' }, [say('redirecting'), ' ', el('a', { href: go }, say('goNow'))]) : null,
    ]), 'up');
    if (go && !previewed) setTimeout(() => location.assign(go), 2500);
  }

  /** The redirect, with earlier answers written in (encoded). */
  function link(url) {
    return url.replace(/\{\{\s*(field|hidden):([A-Za-z0-9_-]+)\s*\}\}/g, (_m, kind, key) => encodeURIComponent(kind === 'hidden'
      ? (hidden[key] || '') : F.display(F.byRef(def, key), st.answers[key], say)));
  }

  function progress() {
    const asks = (r) => { const f = F.byRef(def, r); return f && F.TYPES[f.type] !== null; };
    const answered = st.history.filter(asks).length;
    const i = st.field ? def.fields.indexOf(st.field) : 0;
    const ahead = def.fields.slice(i).filter((f) => F.TYPES[f.type] !== null).length;
    const total = answered + ahead;
    const share = total ? answered / total : 0;
    const show = def.settings.show_progress_bar !== false;
    bar.hidden = !show;
    nav.hidden = false;
    fill.style.width = `${Math.round(share * 100)}%`;
    told.textContent = !show ? '' : def.settings.progress_bar === 'percentage'
      ? say('percent', { n: Math.round(share * 100) }) : say('progress', { n: answered, total });
    upBtn.disabled = !st.history.length;
    if (opts.onStep) opts.onStep({ ref: st.field && st.field.ref, answered });
  }

  function clearError() { if (st.err) st.err.hidden = true; }
  function showError(text) {
    st.err.textContent = text;
    st.err.hidden = false;
    if (!calm()) { st.err.classList.remove('fx-shake'); void st.err.offsetWidth; st.err.classList.add('fx-shake'); }
  }

  // ── moving ─────────────────────────────────────────────────────────────
  function ok(given) {
    if (st.busy || st.done || !st.at) return;
    if (st.at.type === 'welcome') { st.startedAt = st.startedAt || Date.now(); show(F.firstStep(def), 'up'); save(); return; }
    if (st.at.type !== 'field') return;
    const f = st.field;
    const value = given !== undefined ? given : st.widget.value();
    const why = F.checkAnswer(f, value);
    if (why) { showError(problem(say, why, f)); return; }
    if (F.TYPES[f.type] !== null) { if (F.empty(value)) delete st.answers[f.ref]; else st.answers[f.ref] = F.clean(f, value); }
    st.startedAt = st.startedAt || Date.now();
    const next = F.nextStep(def, f.ref, st.answers, hidden);
    st.history.push(f.ref);
    if (next.type === 'thankyou') { finish(); return; }
    show(next, 'up');
    save();
  }

  function back() {
    if (st.busy || st.done || !st.history.length) return;
    show({ type: 'field', ref: st.history.pop() }, 'down');
    save();
  }

  function save() {
    if (opts.onProgress && !opts.preview) {
      opts.onProgress({ answers: st.answers, history: st.history, current: st.at && st.at.ref, startedAt: st.startedAt });
    }
  }

  async function finish() {
    const v = F.validateResponse(def, st.answers, hidden);
    if (!v.ok) {
      const p = v.problems[0];
      const k = st.history.indexOf(p.ref);
      st.history = k >= 0 ? st.history.slice(0, k) : st.history.slice(0, -1);
      show({ type: 'field', ref: p.ref }, 'down');
      showError(problem(say, p.code, F.byRef(def, p.ref)));
      return;
    }
    if (opts.preview || !opts.onDone) { st.done = true; ending(v.ending, v.answers, true); return; }
    st.busy = true;
    const line = el('p', { class: 'fx-hint', role: 'status' }, say('sending'));
    Orch.mount(st.actions, line);
    try {
      await opts.onDone({ answers: v.answers, ending: v.ending, ms: st.startedAt ? Date.now() - st.startedAt : 0, hidden },
        (text) => { line.textContent = text; });
      st.done = true;
      st.busy = false;
      ending(v.ending, v.answers);
    } catch (e) {
      st.busy = false;
      st.history.pop();
      Orch.mount(st.actions, [
        el('button', { type: 'button', class: 'fx-ok', onClick: () => ok() }, say('tryAgain')),
        el('span', { class: 'fx-hint' }, say('sendFailed')),
      ]);
    }
  }

  function onKey(e) {
    if (!root.isConnected) { document.removeEventListener('keydown', onKey); return; }
    if (e.defaultPrevented || e.altKey || e.ctrlKey || e.metaKey || st.done) return;
    // A preview inside a builder listens only to keys pressed in it (or in its dialog).
    if (opts.scopeKeys && !(root.closest('dialog') || root).contains(e.target)) return;
    const t = e.target;
    const typing = t && (t.tagName === 'TEXTAREA' || (t.tagName === 'INPUT' && t.type !== 'button'));
    if (e.key === 'Enter') {
      if ((t && t.tagName === 'TEXTAREA' && e.shiftKey) || (t && (t.tagName === 'BUTTON' || t.tagName === 'A'))) return;
      e.preventDefault();
      ok();
      return;
    }
    if (!typing && st.at && st.at.type === 'field' && st.widget && st.widget.key(e)) e.preventDefault();
  }

  // ── start ──────────────────────────────────────────────────────────────
  const resume = opts.start && opts.start.current && F.byRef(def, opts.start.current);
  if (resume) show({ type: 'field', ref: opts.start.current }, 'up');
  else if (def.welcome_screens.length) show({ type: 'welcome' }, 'up');
  else show(F.firstStep(def), 'up');

  return {
    peek(ref) { if (F.byRef(def, ref)) { st.done = false; st.busy = false; st.history = []; show({ type: 'field', ref }, 'up'); } },
    restart() { st.answers = {}; st.history = []; st.done = false; st.busy = false; st.startedAt = 0;
      show(def.welcome_screens.length ? { type: 'welcome' } : F.firstStep(def), 'up'); },
    destroy() { clearTimeout(st.timer); document.removeEventListener('keydown', onKey); },
  };
}
