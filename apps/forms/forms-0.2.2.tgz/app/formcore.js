/**
 * The rules of a form, in one place: what a definition may say, how it moves
 * from question to question, what counts as an answer, and how answers become
 * rows. Pure functions, no database, no DOM. The page that people answer, the
 * builder's preview and the automations all load THIS file (build-bundle.sh
 * copies it; a test fails if a copy differs), so the server checks exactly what
 * the page asked for.
 *
 * A definition is a subset of Typeform's form JSON (fields, logic, hidden,
 * welcome_screens, thankyou_screens, settings) so an agent that knows Typeform
 * writes a valid one, and a Typeform form can be copied in. What we add:
 * `language`, `theme`, and `validations.min_selection` / `max_selection`.
 */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.FormCore = api;
}(typeof self !== 'undefined' ? self : this, () => {
  'use strict';

  // What travels: the definition as a JSON string inside an action's body,
  // escaped, in UTF-8. The platform refuses a body over 100 KB (express.json),
  // and the rest of the body needs a little room.
  const MAX_BYTES = 90000;
  const sizeOf = (def) => new TextEncoder().encode(JSON.stringify(JSON.stringify(def))).length;
  const TEXT_MAX = { short_text: 1000, long_text: 10000 };
  const LANGS = ['es', 'en'];
  // What each type's answer is. `null`: nothing to answer (a statement).
  const TYPES = {
    short_text: 'text', long_text: 'text', email: 'text', phone_number: 'text', website: 'text',
    number: 'number', date: 'date', multiple_choice: 'choice', dropdown: 'choice',
    yes_no: 'boolean', legal: 'boolean', rating: 'number', opinion_scale: 'number', nps: 'number',
    statement: null,
  };
  const TYPE_LABEL = {
    short_text: 'Short text', long_text: 'Long text', email: 'Email', phone_number: 'Phone', website: 'Website',
    number: 'Number', date: 'Date', multiple_choice: 'Multiple choice', dropdown: 'Dropdown', yes_no: 'Yes / No',
    legal: 'Consent', rating: 'Rating', opinion_scale: 'Opinion scale', nps: 'Net Promoter Score', statement: 'Statement',
  };
  const OPS = ['is', 'is_not', 'equal', 'not_equal', 'lower_than', 'lower_equal_than', 'greater_than', 'greater_equal_than',
    'contains', 'not_contains', 'begins_with', 'ends_with', 'always', 'on', 'not_on', 'earlier_than', 'earlier_than_or_on',
    'later_than', 'later_than_or_on'];
  const REF = /^[A-Za-z0-9][A-Za-z0-9_-]{0,63}$/;
  const HIDDEN = /^[a-z0-9_]{1,40}$/;
  const HEX = /^#[0-9a-fA-F]{6}$/;
  const URL_RE = /^https?:\/\/[^\s]+\.[^\s]+$/i;
  const EMAIL = /^[^\s@<>(),;:"]+@[^\s@<>(),;:"]+\.[a-z]{2,}$/i;
  const DATE = /^\d{4}-\d{2}-\d{2}$/;
  const RECALL = /\{\{\s*(field|hidden):([A-Za-z0-9_-]+)\s*\}\}/g;
  // The desk's words for what went wrong with an answer (the page has its own, per language).
  const PROBLEM = {
    required: 'A required question has no answer', email: 'The email is not valid', url: 'The web address is not valid',
    phone: 'The phone number is not valid', number: 'Not a number', min: 'The number is below the minimum',
    max: 'The number is above the maximum', max_length: 'The answer is too long', date: 'Not a date',
    choice: 'Not one of the options', min_selection: 'Too few options chosen', max_selection: 'Too many options chosen',
    accept: 'Consent was not given', range: 'Outside the scale',
  };

  const isObj = (v) => v !== null && typeof v === 'object' && !Array.isArray(v);
  const str = (v) => (v === undefined || v === null ? '' : String(v));
  const empty = (v) => v === undefined || v === null || v === '' || (Array.isArray(v) && !v.length)
    || (isObj(v) && !str(v.other).trim());
  const slug = (s) => str(s).normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase()
    .replace(/[^a-z0-9]+/g, '_').replace(/^_+|_+$/g, '').slice(0, 40);
  const unique = (base, taken) => {
    let r = base || 'q';
    for (let i = 2; taken.has(r); i += 1) r = `${base}_${i}`;
    taken.add(r);
    return r;
  };

  // ── the definition ───────────────────────────────────────────────────────
  /**
   * A clean copy: every field, choice and screen with a ref, the defaults
   * filled in, unknown keys dropped. Never throws; validate() says what is wrong.
   */
  function normalize(input) {
    const d = isObj(input) ? JSON.parse(JSON.stringify(input)) : {};
    const out = {
      title: str(d.title).trim(),
      language: LANGS.includes(d.language) ? d.language : 'es',
      settings: Object.assign({ show_progress_bar: true, progress_bar: 'proportion', show_key_hint_on_choices: true,
        show_question_number: true }, isObj(d.settings) ? d.settings : {}),
      fields: [], hidden: [], welcome_screens: [], thankyou_screens: [], logic: [],
      theme: isObj(d.theme) ? { accent: str(d.theme.accent), logo: str(d.theme.logo) } : { accent: '', logo: '' },
    };
    const taken = new Set();
    for (const f of Array.isArray(d.fields) ? d.fields : []) {
      if (!isObj(f)) continue;
      const p = isObj(f.properties) ? f.properties : {};
      const field = {
        ref: REF.test(str(f.ref)) && !taken.has(f.ref) ? (taken.add(f.ref), f.ref) : unique(slug(f.title) || 'q', taken),
        type: str(f.type), title: str(f.title).trim(),
        properties: Object.assign({}, p, { description: str(p.description).trim() }),
        validations: isObj(f.validations) ? Object.assign({}, f.validations) : {},
      };
      if (field.type === 'rating' && !(Number(p.steps) >= 3 && Number(p.steps) <= 10)) field.properties.steps = 5;
      if (field.type === 'opinion_scale' && !(Number(p.steps) >= 5 && Number(p.steps) <= 11)) field.properties.steps = 11;
      if (TYPES[field.type] === 'choice') {
        const seen = new Set();
        field.properties.choices = (Array.isArray(p.choices) ? p.choices : []).filter(isObj).map((c) => ({
          ref: REF.test(str(c.ref)) && !seen.has(c.ref) ? (seen.add(c.ref), c.ref) : unique(slug(c.label) || 'option', seen),
          label: str(c.label).trim(),
        }));
      } else delete field.properties.choices;
      out.fields.push(field);
    }
    out.hidden = [...new Set((Array.isArray(d.hidden) ? d.hidden : []).map((h) => str(h).trim().toLowerCase()))];
    const screens = (list, kind) => {
      const seen = new Set();
      return (Array.isArray(list) ? list : []).filter(isObj).map((s) => ({
        ref: REF.test(str(s.ref)) && !seen.has(s.ref) ? (seen.add(s.ref), s.ref) : unique(kind, seen),
        title: str(s.title).trim(),
        properties: Object.assign({}, isObj(s.properties) ? s.properties : {}),
      }));
    };
    out.welcome_screens = screens(d.welcome_screens, 'welcome').slice(0, 1);
    out.thankyou_screens = screens(d.thankyou_screens, 'ending');
    if (!out.thankyou_screens.length) out.thankyou_screens.push({ ref: 'ending', title: '', properties: {} });
    out.logic = (Array.isArray(d.logic) ? d.logic : []).filter(isObj).map((l) => ({
      type: 'field', ref: str(l.ref), actions: (Array.isArray(l.actions) ? l.actions : []).filter(isObj),
    }));
    return out;
  }

  const byRef = (def, ref) => (def.fields || []).find((f) => f.ref === ref) || null;
  const choiceOf = (field, ref) => ((field && field.properties.choices) || []).find((c) => c.ref === ref) || null;
  const endingOf = (def, ref) => (def.thankyou_screens || []).find((s) => s.ref === ref) || null;

  /** Everything wrong with a normalized definition, each with where it is: { ok, errors, warnings }. */
  function validate(def) {
    const errors = [];
    const warnings = [];
    const err = (path, message) => errors.push({ path, message });
    if (!def.title) err('title', 'The form needs a title');
    if (def.title.length > 200) err('title', 'The title is longer than 200 characters');
    if (!def.fields.length) err('fields', 'The form has no questions');
    if (def.fields.length > 200) err('fields', 'A form holds at most 200 questions');
    def.fields.forEach((f, i) => {
      const at = `fields[${i}]`;
      if (!(f.type in TYPES)) { err(`${at}.type`, `"${f.type}" is not a question type this form supports`); return; }
      if (!f.title && f.type !== 'statement') err(`${at}.title`, 'The question has no text');
      if (f.title.length > 1000) err(`${at}.title`, 'The question is longer than 1,000 characters');
      const p = f.properties;
      const v = f.validations;
      if (TYPES[f.type] === 'choice') {
        if (!p.choices.length) err(`${at}.properties.choices`, 'A choice question needs options');
        if (p.choices.length > (f.type === 'dropdown' ? 500 : 50)) err(`${at}.properties.choices`, 'Too many options');
        p.choices.forEach((c, j) => { if (!c.label) err(`${at}.properties.choices[${j}]`, 'An option has no text'); });
        const labels = p.choices.map((c) => c.label.toLowerCase());
        if (new Set(labels).size !== labels.length) err(`${at}.properties.choices`, 'Two options have the same text');
        const lo = Number(v.min_selection || 0);
        const hi = Number(v.max_selection || 0);
        if (lo && hi && lo > hi) err(`${at}.validations`, 'The minimum to choose is above the maximum');
      }
      if (f.type === 'number' && v.min_value != null && v.max_value != null && Number(v.min_value) > Number(v.max_value)) {
        err(`${at}.validations`, 'The minimum is above the maximum');
      }
      if (TYPES[f.type] === 'text' && v.max_length != null && !(Number(v.max_length) >= 1)) err(`${at}.validations`, 'max_length must be at least 1');
      for (const m of `${f.title} ${p.description}`.matchAll(RECALL)) {
        if (m[1] === 'hidden' && !def.hidden.includes(m[2])) err(`${at}.title`, `{{hidden:${m[2]}}} is not a hidden field of this form`);
        if (m[1] === 'field') {
          const k = def.fields.findIndex((x) => x.ref === m[2]);
          if (k < 0) err(`${at}.title`, `{{field:${m[2]}}} names no question`);
          else if (k >= i) err(`${at}.title`, `{{field:${m[2]}}} is not answered yet at this point`);
        }
      }
    });
    def.hidden.forEach((h, i) => { if (!HIDDEN.test(h)) err(`hidden[${i}]`, `"${h}": a hidden field is lower-case letters, digits and _`); });
    def.thankyou_screens.forEach((s, i) => {
      const u = str(s.properties.redirect_url);
      if (u && !URL_RE.test(u)) err(`thankyou_screens[${i}].properties.redirect_url`, 'The redirect is not a web address');
    });
    if (def.theme.accent && !HEX.test(def.theme.accent)) err('theme.accent', 'The colour must look like #1A2B3C');
    if (def.theme.logo && !/^https:\/\//i.test(def.theme.logo)) err('theme.logo', 'The logo must be an https:// address');
    const order = new Map(def.fields.map((f, i) => [f.ref, i]));
    def.logic.forEach((l, i) => {
      const at = `logic[${i}]`;
      if (!order.has(l.ref)) { err(`${at}.ref`, `"${l.ref}" names no question`); return; }
      l.actions.forEach((a, j) => {
        const where = `${at}.actions[${j}]`;
        if (a.action !== 'jump') { warnings.push({ path: where, message: `"${a.action}" is not supported yet and is ignored` }); return; }
        const to = (a.details && a.details.to) || {};
        if (to.type === 'field') {
          if (!order.has(to.value)) err(where, `It jumps to "${to.value}", which is no question`);
          else if (order.get(to.value) <= order.get(l.ref)) err(where, 'A jump can only go forward');
        } else if (to.type === 'thankyou') {
          if (!endingOf(def, to.value)) err(where, `It jumps to "${to.value}", which is no ending`);
        } else err(where, 'A jump goes to a question or an ending');
        conditionErrors(def, a.condition, `${where}.condition`, err);
      });
    });
    if (sizeOf(def) > MAX_BYTES) err('', 'The form is too large (over 90 KB): split it, or shorten its longest texts');
    return { ok: !errors.length, errors, warnings };
  }

  function conditionErrors(def, c, at, err) {
    if (!isObj(c)) { err(at, 'A jump needs a condition (use "always" for every case)'); return; }
    if (c.op === 'and' || c.op === 'or') {
      if (!Array.isArray(c.vars) || !c.vars.length) err(at, `"${c.op}" needs conditions`);
      else c.vars.forEach((x, i) => conditionErrors(def, x, `${at}.vars[${i}]`, err));
      return;
    }
    if (!OPS.includes(c.op)) { err(at, `"${c.op}" is not a condition this form supports`); return; }
    if (c.op === 'always') return;
    if (!Array.isArray(c.vars) || c.vars.length !== 2) { err(at, 'A condition compares two things'); return; }
    const [a, b] = c.vars;
    if (a && a.type === 'field' && !byRef(def, a.value)) err(at, `"${a.value}" names no question`);
    if (a && a.type === 'hidden' && !def.hidden.includes(a.value)) err(at, `"${a.value}" is not a hidden field`);
    if (b && b.type === 'choice' && a && a.type === 'field' && !choiceOf(byRef(def, a.value), b.value)) {
      err(at, `"${b.value}" is not an option of "${a.value}"`);
    }
  }

  /** normalize + validate in one call: { def, ok, errors, warnings }. */
  function check(input) {
    const def = normalize(input);
    return Object.assign({ def }, validate(def));
  }

  // ── moving through the form ──────────────────────────────────────────────
  /** What a variable in a condition stands for, given the answers so far. */
  function term(def, v, answers, hidden) {
    if (!isObj(v)) return { value: undefined };
    if (v.type === 'hidden') return { value: str(hidden && hidden[v.value]) };
    if (v.type === 'choice') return { value: str(v.value), choice: true };
    if (v.type !== 'field') return { value: v.value };
    const f = byRef(def, v.value);
    const a = answers ? answers[v.value] : undefined;
    if (!f || TYPES[f.type] !== 'choice') return { value: a };
    const picked = (Array.isArray(a) ? a : [a]).filter((x) => x !== undefined && x !== null);
    const keys = [];
    for (const x of picked) {
      if (isObj(x)) keys.push('other', str(x.other).toLowerCase());
      else { const c = choiceOf(f, x); keys.push(str(x).toLowerCase()); if (c) keys.push(c.label.toLowerCase()); }
    }
    return { set: keys, value: a };
  }

  const num = (v) => (v === '' || v === null || v === undefined || typeof v === 'boolean' ? NaN : Number(v));
  const bool = (v) => (v === true || v === 'true' || v === 1 ? true : v === false || v === 'false' || v === 0 ? false : undefined);

  /** Typeform's condition semantics. An unanswered question matches nothing but "is not". */
  function test(def, c, answers, hidden) {
    if (!isObj(c)) return false;
    if (c.op === 'always') return true;
    if (c.op === 'and') return (c.vars || []).every((x) => test(def, x, answers, hidden));
    if (c.op === 'or') return (c.vars || []).some((x) => test(def, x, answers, hidden));
    const [l, r] = (c.vars || []).map((v) => term(def, v, answers, hidden));
    if (!l || !r) return false;
    const negate = ['is_not', 'not_equal', 'not_contains', 'not_on'].includes(c.op);
    const op = { is_not: 'is', not_equal: 'is', not_contains: 'contains', not_on: 'on', equal: 'is' }[c.op] || c.op;
    if (l.set ? !l.set.length : empty(l.value)) return negate;
    let yes = false;
    const rv = r.value;
    if (op === 'is' && l.set) yes = l.set.includes(str(rv).toLowerCase());
    else if (op === 'is' && typeof l.value === 'boolean') yes = l.value === bool(rv);
    else if (op === 'is' && Number.isFinite(num(l.value)) && Number.isFinite(num(rv))) yes = num(l.value) === num(rv);
    else if (op === 'is') yes = str(l.value).trim().toLowerCase() === str(rv).trim().toLowerCase();
    else if (['lower_than', 'lower_equal_than', 'greater_than', 'greater_equal_than'].includes(op)) {
      const a = num(l.value);
      const b = num(rv);
      if (Number.isFinite(a) && Number.isFinite(b)) {
        yes = { lower_than: a < b, lower_equal_than: a <= b, greater_than: a > b, greater_equal_than: a >= b }[op];
      }
    } else if (['contains', 'begins_with', 'ends_with'].includes(op)) {
      const a = (l.set ? l.set.join(' ') : str(l.value)).toLowerCase();
      const b = str(rv).toLowerCase();
      yes = op === 'contains' ? a.includes(b) : op === 'begins_with' ? a.startsWith(b) : a.endsWith(b);
    } else if (['on', 'earlier_than', 'earlier_than_or_on', 'later_than', 'later_than_or_on'].includes(op)) {
      const a = str(l.value);
      const b = str(rv);
      if (DATE.test(a) && DATE.test(b)) {
        yes = { on: a === b, earlier_than: a < b, earlier_than_or_on: a <= b, later_than: a > b, later_than_or_on: a >= b }[op];
      }
    }
    return negate ? !yes : yes;
  }

  const firstStep = (def) => (def.fields.length ? { type: 'field', ref: def.fields[0].ref }
    : { type: 'thankyou', ref: def.thankyou_screens[0].ref });

  /** Where a person goes after `ref`: the first jump whose condition holds, else the next question, else the first ending. */
  function nextStep(def, ref, answers, hidden) {
    for (const l of def.logic) {
      if (l.ref !== ref) continue;
      for (const a of l.actions) {
        if (a.action !== 'jump' || !test(def, a.condition, answers, hidden)) continue;
        const to = (a.details && a.details.to) || {};
        if (to.type === 'thankyou' && endingOf(def, to.value)) return { type: 'thankyou', ref: to.value };
        if (to.type === 'field' && byRef(def, to.value)) return { type: 'field', ref: to.value };
      }
    }
    const i = def.fields.findIndex((f) => f.ref === ref);
    if (i >= 0 && i + 1 < def.fields.length) return { type: 'field', ref: def.fields[i + 1].ref };
    return { type: 'thankyou', ref: def.thankyou_screens[0].ref };
  }

  // ── answers ──────────────────────────────────────────────────────────────
  /** Why an answer is not acceptable (a PROBLEM key), or null. */
  function checkAnswer(f, value) {
    const kind = TYPES[f.type];
    const v = f.validations || {};
    const p = f.properties || {};
    if (kind === null) return null;
    if (empty(value) || (f.type === 'legal' && value === false && v.required)) {
      if (!v.required) return null;
      return f.type === 'legal' && value === false ? 'accept' : 'required';
    }
    if (kind === 'text') {
      if (typeof value !== 'string') return 'required';
      const s = value.trim();
      const cap = Number(v.max_length) || TEXT_MAX[f.type] || 1000;
      if (s.length > cap) return 'max_length';
      if (f.type === 'email' && !EMAIL.test(s)) return 'email';
      if (f.type === 'website' && !/^(https?:\/\/)?[^\s/.]+(\.[^\s/.]+)+(\/\S*)?$/i.test(s)) return 'url';
      if (f.type === 'phone_number' && !/^\+?[\d\s().-]{6,24}$/.test(s)) return 'phone';
      return null;
    }
    if (kind === 'number') {
      const n = num(value);
      if (!Number.isFinite(n)) return 'number';
      if (f.type === 'number') {
        if (v.min_value != null && n < Number(v.min_value)) return 'min';
        if (v.max_value != null && n > Number(v.max_value)) return 'max';
        return null;
      }
      const [lo, hi] = scale(f);
      return Number.isInteger(n) && n >= lo && n <= hi ? null : 'range';
    }
    if (kind === 'date') return realDate(value) ? null : 'date';
    if (kind === 'boolean') return typeof value === 'boolean' ? null : 'choice';
    const many = f.type === 'multiple_choice' && p.allow_multiple_selection;
    const list = many ? (Array.isArray(value) ? value : [value]) : [value];
    if (!many && (Array.isArray(value) || list.length !== 1)) return 'choice';
    for (const x of list) {
      if (isObj(x)) { if (!p.allow_other_choice || !str(x.other).trim()) return 'choice'; } else if (!choiceOf(f, x)) return 'choice';
    }
    if (many && v.min_selection && list.length < Number(v.min_selection)) return 'min_selection';
    if (many && v.max_selection && list.length > Number(v.max_selection)) return 'max_selection';
    return null;
  }

  /** YYYY-MM-DD that names a real day: Date.parse rolls 2026-02-30 over to March. */
  function realDate(v) {
    if (!DATE.test(str(v))) return false;
    const d = new Date(`${v}T00:00:00Z`);
    return !Number.isNaN(d.getTime()) && d.toISOString().slice(0, 10) === v;
  }

  /** The lowest and highest value of a rating, scale or NPS. */
  function scale(f) {
    if (f.type === 'nps') return [0, 10];
    const steps = Number(f.properties.steps) || (f.type === 'rating' ? 5 : 11);
    if (f.type === 'rating') return [1, steps];
    const lo = f.properties.start_at_one ? 1 : 0;
    return [lo, lo + steps - 1];
  }

  /** An answer as the form keeps it: strings trimmed, numbers as numbers. */
  function clean(f, value) {
    const kind = TYPES[f.type];
    if (kind === 'text' || kind === 'date') return str(value).trim();
    if (kind === 'number') return num(value);
    if (isObj(value)) return { other: str(value.other).trim() };
    if (Array.isArray(value)) return value.map((x) => (isObj(x) ? { other: str(x.other).trim() } : x));
    return value;
  }

  /**
   * A whole response, walked the way the person walked it: which questions
   * they were shown, what is wrong, and which ending they reached. Answers to
   * questions off their path are dropped, as Typeform does.
   */
  function validateResponse(def, answers, hidden) {
    const given = isObj(answers) ? answers : {};
    const kept = {};
    const visited = [];
    const problems = [];
    let step = firstStep(def);
    for (let guard = 0; step.type === 'field' && guard <= def.fields.length; guard += 1) {
      const f = byRef(def, step.ref);
      visited.push(f.ref);
      const why = checkAnswer(f, given[f.ref]);
      if (why) problems.push({ ref: f.ref, code: why, message: PROBLEM[why] });
      else if (TYPES[f.type] !== null && !empty(given[f.ref])) kept[f.ref] = clean(f, given[f.ref]);
      step = nextStep(def, f.ref, kept, hidden || {});
    }
    return { ok: !problems.length, problems, visited, ending: step.ref, answers: kept };
  }

  /** An answer in words: option labels, yes/no, the number. `words` gives yes/no in the page's language. */
  function display(f, value, words) {
    if (!f || empty(value)) return '';
    const w = words || { yes: 'Yes', no: 'No' };
    if (TYPES[f.type] === 'boolean') return value ? w.yes : w.no;
    if (TYPES[f.type] === 'choice') {
      return (Array.isArray(value) ? value : [value]).map((x) => (isObj(x) ? str(x.other) : (choiceOf(f, x) || { label: str(x) }).label)).join(', ');
    }
    return str(value);
  }

  /** {{field:ref}} and {{hidden:name}} replaced by what the person gave. */
  function recall(text, def, answers, hidden, words) {
    return str(text).replace(RECALL, (_m, kind, key) => (kind === 'hidden'
      ? str(hidden && hidden[key]) : display(byRef(def, key), answers && answers[key], words)));
  }

  /** One row per answer (one per option chosen), for summaries: { question, type, value, choice, number }. */
  function flatten(def, answers) {
    const rows = [];
    for (const f of def.fields) {
      const a = answers[f.ref];
      if (TYPES[f.type] === null || empty(a)) continue;
      const base = { question: f.ref, type: f.type };
      if (TYPES[f.type] === 'choice') {
        for (const x of Array.isArray(a) ? a : [a]) {
          rows.push(Object.assign({}, base, isObj(x) ? { choice: 'other', value: str(x.other) }
            : { choice: x, value: (choiceOf(f, x) || { label: x }).label }, { number: null }));
        }
      } else if (TYPES[f.type] === 'boolean') {
        rows.push(Object.assign({}, base, { choice: a ? 'yes' : 'no', value: a ? 'Yes' : 'No', number: a ? 1 : 0 }));
      } else if (TYPES[f.type] === 'number') {
        rows.push(Object.assign({}, base, { choice: null, value: str(a), number: num(a) }));
      } else rows.push(Object.assign({}, base, { choice: null, value: str(a), number: null }));
    }
    return rows;
  }

  /** The first email someone gave, to find their response later. */
  function emailOf(def, answers) {
    const f = def.fields.find((x) => x.type === 'email' && !empty(answers[x.ref]));
    return f ? str(answers[f.ref]).trim().toLowerCase() : '';
  }

  /** Text on the accent: white, or near-black when the accent is light. */
  function inkFor(hex) {
    if (!HEX.test(str(hex))) return '#FFFFFF';
    const [r, g, b] = [1, 3, 5].map((i) => parseInt(hex.slice(i, i + 2), 16) / 255)
      .map((c) => (c <= 0.03928 ? c / 12.92 : ((c + 0.055) / 1.055) ** 2.4));
    return 0.2126 * r + 0.7152 * g + 0.0722 * b > 0.4 ? '#16181D' : '#FFFFFF';
  }

  return {
    MAX_BYTES, TYPES, TYPE_LABEL, OPS, LANGS, PROBLEM, REF, HIDDEN,
    normalize, validate, check, byRef, choiceOf, endingOf, test, firstStep, nextStep,
    checkAnswer, scale, clean, validateResponse, display, recall, flatten, emailOf, inkFor, empty, slug,
  };
}));
