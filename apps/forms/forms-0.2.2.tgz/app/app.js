// The router and the rail. Forms is home: every form with how it is doing.
// A form opens on its builder while it is a draft, on its responses once
// people answer it; its tabs are Build, Share, Responses, Summary, Settings.
// Preview is a page of its own, opened in a new tab from the builder.
import { render as forms } from './screens/forms.js';
import { render as create } from './screens/new.js';
import { render as build } from './screens/build.js';
import { render as preview } from './screens/preview.js';
import { render as share } from './screens/share.js';
import { render as responses } from './screens/responses.js';
import { render as summary } from './screens/summary.js';
import { render as formSettings } from './screens/form-settings.js';
import { render as settings } from './screens/settings.js';

const { el, router } = Orch;

router.define({
  '/': forms,
  '/archived': forms,
  '/new': create,
  '/forms/:id': (p) => router.go(`/forms/${p.id}/build`, { replace: true }),
  '/forms/:id/build': build,
  '/forms/:id/preview': preview,
  '/forms/:id/share': share,
  '/forms/:id/responses': responses,
  '/forms/:id/responses/:state': responses,
  '/forms/:id/summary': summary,
  '/forms/:id/settings': formSettings,
  '/settings': settings,
}, () => Orch.mount('view', el('div', { class: 'oc-state' }, [
  el('p', 'There is no screen here.'), router.link('/', 'Go to your forms'),
]))).start();

Orch.mount('nav', [
  router.link('/', 'Forms', { class: 'oc-tab' }),
  router.link('/new', 'New form', { class: 'oc-tab' }),
  router.link('/settings', 'Settings', { class: 'oc-tab' }),
]);
