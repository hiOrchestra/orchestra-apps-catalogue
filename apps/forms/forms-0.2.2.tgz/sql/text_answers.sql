SELECT a._id, a.form_id, a.question, a.value, a.response_id, r._created_at AS submitted_at
FROM forms_answers a
JOIN forms_responses r ON r._id = a.response_id
WHERE r.status = 'Complete' AND a.number IS NULL AND (a.choice IS NULL OR a.choice = 'other')
