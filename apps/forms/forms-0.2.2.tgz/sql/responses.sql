SELECT r._id, r.form_id, r.version, r.answers, r.hidden, r.meta, r.ending, r.status, r.problem, r.email, r.review,
       r._created_at AS submitted_at, r.processed_at
FROM forms_responses r
WHERE r.status <> 'Erased'
