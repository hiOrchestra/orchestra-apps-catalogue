SELECT form_id, date(_created_at) AS day, COUNT(*) AS n
FROM forms_responses
WHERE status = 'Complete'
GROUP BY form_id, date(_created_at)
