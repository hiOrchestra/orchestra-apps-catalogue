SELECT f._id AS form_id,
       (SELECT COUNT(*) FROM forms_responses r WHERE r.form_id = f._id AND r.status = 'Complete') AS completed,
       (SELECT COUNT(*) FROM forms_responses r
         WHERE r.form_id = f._id AND r.status = 'Complete' AND r._created_at >= datetime('now', '-7 days')) AS this_week,
       (SELECT CAST(AVG(json_extract(r.meta, '$.ms')) AS INTEGER) FROM forms_responses r
         WHERE r.form_id = f._id AND r.status = 'Complete') AS avg_ms
FROM forms_forms f
