SELECT f._id, f.slug, f.title, f.status, f.version, f.published_at, f.closes_at, f.closed_at, f.closed_reason,
       f.max_responses, COALESCE(f.responses, 0) AS responses, f.last_response_at, CASE WHEN COALESCE(f.archived, 0) = 1 THEN 'yes' ELSE 'no' END AS archived,
       f.ai_status, f.ai_note, f._created_at AS created_at, f._updated_at AS updated_at,
       (SELECT COUNT(*) FROM forms_responses r
         WHERE r.form_id = f._id AND r.status = 'Complete' AND r._created_at >= datetime('now', '-7 days')) AS this_week,
       CASE WHEN COALESCE(f.version, 0) = 0 THEN 'never'
            WHEN f.draft IS NOT NULL AND f.draft <> COALESCE((SELECT x.definition FROM forms_versions x
              WHERE x.form_id = f._id AND x.version = f.version), '') THEN 'yes'
            ELSE 'no' END AS unpublished
FROM forms_forms f
