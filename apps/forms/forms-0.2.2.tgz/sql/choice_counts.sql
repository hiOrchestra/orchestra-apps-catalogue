SELECT a.form_id, a.question, a.choice, MIN(a.value) AS label, COUNT(*) AS n
FROM forms_answers a
JOIN forms_responses r ON r._id = a.response_id
WHERE r.status = 'Complete' AND a.choice IS NOT NULL
GROUP BY a.form_id, a.question, a.choice
