SELECT a.form_id, a.question, a.type, a.number AS value, COUNT(*) AS n
FROM forms_answers a
JOIN forms_responses r ON r._id = a.response_id
WHERE r.status = 'Complete' AND a.number IS NOT NULL AND a.type IN ('rating', 'opinion_scale', 'nps', 'number')
GROUP BY a.form_id, a.question, a.type, a.number
