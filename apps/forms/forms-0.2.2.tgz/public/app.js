// The public page of Forms. The link names the form (#/<link name>, with
// hidden fields after it: #/<link name>?utm_source=x); its published version
// comes from the approved public list, and the player does the rest. Answers
// are kept in this browser until they are sent, so a reload or a lost
// connection costs nothing; sending retries on its own when the platform is
// busy. Once a response is saved, the page asks for it to be processed: the
// team hears about it in seconds, not at the next half-hourly check.
import './formcore.js';
import { play } from './render/player.js';
import { words } from './render/i18n.js';

const { el } = Orch;
const F = self.FormCore;
const HOST = 'form';
const WAITS = [3, 6, 12, 20, 30, 30, 30]; // seconds between tries: about two minutes
let player = null;

// The app's own base, as the runtime computes it: a beacon needs it absolute.
const BASE = (() => {
  const p = location.pathname;
  const i = p.indexOf('/canvas/a/');
  return i < 0 ? '.' : `${p.slice(0, i)}/canvas/a/${p.slice(i + 10).split('/')[0]}`;
})();

const store = {
  get(k) { try { return JSON.parse(localStorage.getItem(k) || 'null'); } catch { return null; } },
  set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch { /* private window: no resume */ } },
  drop(k) { try { localStorage.removeItem(k); } catch { /* nothing kept */ } },
};
const newId = () => (self.crypto && crypto.randomUUID ? crypto.randomUUID() : `${Date.now().toString(36)}${Math.random().toString(36).slice(2)}`);
const sleep = (ms) => new Promise((r) => { setTimeout(r, ms); });
const guess = () => (/^es/i.test(navigator.language || '') ? 'es' : 'en');

/** A page with no form on it: closed, missing, not open yet, busy or broken. */
function screen(kind, lang, message) {
  if (player) { player.destroy(); player = null; }
  const say = words(lang || guess());
  Orch.mount(HOST, el('div', { class: 'fx' }, el('div', { class: 'fx-stage' }, el('section', { class: 'fx-screen' }, [
    el('h1', { class: 'fx-screen__title' }, say(kind)),
    el('p', { class: 'fx-desc' }, message || say(`${kind}Text`)),
  ]))));
}

async function open({ slug }, path) {
  if (player) { player.destroy(); player = null; }
  let row;
  try {
    const r = await Orch.db.view('published_forms', { filter: { slug }, limit: 1 });
    row = (r.rows || [])[0];
  } catch (e) {
    screen(e.reason === 'public-view-pending' ? 'notYet' : e.status === 429 ? 'busy' : 'broken');
    return;
  }
  if (!row) { screen('missing'); return; }
  let def;
  try { def = F.normalize(JSON.parse(row.definition)); } catch { screen('broken'); return; }
  document.documentElement.lang = def.language;
  document.title = def.title;
  const closes = row.closes_at ? new Date(row.closes_at) : null;
  if (row.status === 'Closed' || (closes && !Number.isNaN(closes.getTime()) && closes < new Date())) {
    screen('closed', def.language, row.closed_message);
    return;
  }

  // Hidden fields come in the link's own query (#/slug?utm_source=x). Ad
  // platforms add theirs before the # (?gclid=…#/slug), so that query counts
  // too. `check` flags location.search as a mistake in a hash router; here it
  // is on purpose, and the router's query wins when both have a value.
  const query = new URLSearchParams(path.split('?')[1] || '');
  const outer = new URLSearchParams(location.search);
  const hidden = {};
  for (const h of def.hidden) {
    const v = query.has(h) ? query.get(h) : outer.get(h);
    if (v !== null) hidden[h] = String(v).slice(0, 500);
  }

  // `visit` names this attempt: sent again after no answer came back, it lets
  // the server see the same answers twice. A new one after a response is sent.
  const key = `forms:${slug}:${row.version}`;
  const saved = store.get(key);
  const visit = (saved && saved.visit) || newId();
  const trap = el('input', { class: 'fx-trap', type: 'text', name: 'website_url', tabindex: '-1', autocomplete: 'off', 'aria-hidden': 'true' });

  player = play(HOST, def, {
    hidden,
    start: saved,
    onProgress: (p) => store.set(key, Object.assign({ visit }, p)),
    onDone: async (p, status) => {
      await submit(row, p, { visit, hp: trap.value }, status, words(def.language));
      store.drop(key);
      processNow();
    },
  });
  document.body.appendChild(trap);
  if (saved && saved.current) {
    Orch.toast(words(def.language)('resumed'), { action: { label: words(def.language)('startOver'), run: () => { store.drop(key); player.restart(); } } });
  }
}

/** The answers, sent; on a busy platform or a lost connection, again after a wait. */
async function submit(row, p, extra, status, say) {
  const params = {
    form_id: row.form_id, version: row.version, ending: p.ending, visit: extra.visit, hp: extra.hp || '',
    answers: JSON.stringify(p.answers), hidden: JSON.stringify(p.hidden || {}),
    meta: JSON.stringify({ ms: p.ms, lang: navigator.language || '', mobile: matchMedia('(max-width: 600px)').matches }),
  };
  for (let i = 0; ; i += 1) {
    try {
      return await Orch.action('submit', params);
    } catch (e) {
      const passing = !e.status || e.status === 429 || e.status >= 500;
      if (!passing || i >= WAITS.length) throw e;
      for (let s = WAITS[i]; s > 0; s -= 1) { status(say('retrying', { s })); await sleep(1000); }
      status(say('sending'));
    }
  }
}

/**
 * Asks for what was just saved to be processed. It carries nothing: the run
 * looks for every new response itself. A beacon, so closing the tab on the
 * thank-you screen does not cancel it; when it is refused (busy), the
 * half-hourly check, or the next response, processes this one.
 */
function processNow() {
  const body = new Blob([JSON.stringify({ params: {} })], { type: 'application/json' });
  try {
    if (navigator.sendBeacon && navigator.sendBeacon(`${BASE}/api/actions/process`, body)) return;
  } catch { /* no beacon here: the plain call below */ }
  Orch.action('process', {}).catch(() => { /* picked up by the half-hourly check */ });
}

Orch.router.define({ '/:slug': open }, () => screen('missing')).start();
