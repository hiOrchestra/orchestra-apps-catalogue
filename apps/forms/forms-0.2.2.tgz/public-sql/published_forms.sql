SELECT f._id AS form_id, f.slug, f.status, f.version, f.closes_at, f.closed_message, v.definition
FROM forms_forms f
JOIN forms_versions v ON v.form_id = f._id AND v.version = f.version
WHERE f.status IN ('Live', 'Closed') AND COALESCE(f.archived, 0) = 0
