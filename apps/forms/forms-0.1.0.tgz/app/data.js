// What Forms reads, the only things it writes, and the pieces every screen
// shares. Tables give rows, views do the joins and the counts, and every write
// is a declared action (A). Checking a response, splitting it for the
// summaries and telling the team run as a workflow on the instance; drafting
// with AI too. The form rules are formcore.js, the same file the page people
// answer and the automations load.
import './formcore.js';

export const F = self.FormCore;
const { el, router, fmt } = Orch;

export const T = {
  forms: 'forms_forms', versions: 'forms_versions', responses: 'forms_responses', answers: 'forms_answers',
  settings: 'forms_settings', templates: 'forms_templates',
};
export const V = {
  list: 'forms_list', responses: 'responses', choices: 'choice_counts', numbers: 'number_counts', texts: 'text_answers',
  daily: 'daily', insights: 'insights',
};
export const A = {
  create: 'create_form', saveDraft: 'save_draft', setSlug: 'set_slug', publish: 'publish_form', close: 'close_form', reopen: 'reopen_form',
  archive: 'archive_form', unarchive: 'unarchive_form', formSettings: 'update_form_settings', spam: 'mark_spam', notSpam: 'not_spam',
  remove: 'delete_responses', restore: 'restore_responses', erase: 'erase_responses', processNow: 'process_now',
  draftAi: 'draft_with_ai', retryDraft: 'retry_draft', settings: 'update_settings',
};

/** Run a declared action, say how it went, and hand back its result (null on failure). */
export async function act(name, params, done) {
  try {
    const r = await Orch.action(name, params);
    if (done) Orch.toast(done);
    return r || {};
  } catch (e) {
    Orch.toast(e.status === 409 ? 'It changed in the meantime: look again.' : (e.message || 'That did not work.'), { error: true });
    return null;
  }
}

let kept = null;
/** The one settings row. */
export async function settings(fresh) {
  if (!kept || fresh) kept = (await Orch.db.list(T.settings, { sort: '_id:asc', limit: 1 })).rows[0] || {};
  return kept;
}

/** A form as the list sees it: counts, whether the draft differs from what is live. */
export async function formRow(id) {
  const r = await Orch.db.view(V.list, { filter: { _id: id }, limit: 1 });
  return (r.rows || [])[0] || null;
}

/** A published version's questions, or null. */
export async function versionDef(formId, version) {
  if (!version) return null;
  const r = await Orch.db.list(T.versions, { filter: { form_id: formId, version }, limit: 1 });
  const row = (r.rows || [])[0];
  return row ? F.normalize(parse(row.definition, {})) : null;
}

export function parse(text, fallback) {
  if (!text) return fallback;
  try { return JSON.parse(text); } catch { return fallback; }
}

/** The public page of this instance's form app; Settings may name another. */
export function publicLink(slug, query) {
  const own = `${location.origin}${location.pathname.replace(/\/canvas\/a\/[^/]+\/?.*$/, '/canvas/a/form/')}`;
  const base = (kept && kept.public_url) || own;
  return `${base}#/${slug}${query ? `?${query}` : ''}`;
}

const TONE = { Live: 'good', Closed: 'warn', Complete: 'good', Spam: 'bad', Rejected: 'warn', New: 'accent', Deleted: '' };
export const badge = (text) => el('span', { class: `oc-badge${TONE[text] ? ` oc-badge--${TONE[text]}` : ''}` }, text || '—');
export const plural = (n, one, many) => `${fmt.number(n || 0)} ${Number(n) === 1 ? one : many}`;

/** '2026-10-03 10:00:00' (UTC, as rows are stamped) or ISO, as a Date. */
export function when(v) {
  if (!v) return null;
  const s = String(v).trim();
  const d = new Date(/[zZ]|[+-]\d\d:?\d\d$/.test(s) ? s : `${s.replace(' ', 'T')}Z`);
  return Number.isNaN(d.getTime()) ? null : d;
}
/** "3 h ago", "yesterday", "12 Sep": in the reader's own time. */
export function ago(v) {
  const d = when(v);
  if (!d) return '—';
  const s = (Date.now() - d.getTime()) / 1000;
  if (s < 60) return 'just now';
  if (s < 3600) return `${Math.floor(s / 60)} min ago`;
  if (s < 86400) return `${Math.floor(s / 3600)} h ago`;
  if (s < 172800) return 'yesterday';
  return d.toLocaleDateString(undefined, { day: 'numeric', month: 'short', year: d.getFullYear() === new Date().getFullYear() ? undefined : 'numeric' });
}
export const stamp = (v) => { const d = when(v); return d ? d.toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' }) : '—'; };

export async function copy(text, said) {
  try { await navigator.clipboard.writeText(text); Orch.toast(said || 'Copied.'); } catch { Orch.toast('Select the link and copy it.', { error: true }); }
}

/** The top of every screen of one form: its name, its state and its tabs. */
export function formHead(f, tab, extra) {
  const tabs = [['build', 'Build'], ['share', 'Share'], ['responses', 'Responses'], ['summary', 'Summary'], ['settings', 'Settings']];
  const note = f.status === 'Live' && f.unpublished === 'yes' ? 'The draft has changes people do not see yet'
    : f.status === 'Closed' ? (f.closed_reason || 'Closed') : f.status === 'Draft' ? 'Not published yet' : '';
  return el('header', { class: 'fm-head' }, [
    router.link('/', '← All forms', { class: 'fm-head__back' }),
    el('div', { class: 'fm-head__row' }, [
      el('div', { class: 'fm-head__name' }, [
        el('h1', { class: 'oc-h1' }, f.title || 'Untitled form'),
        badge(f.status),
        note ? el('span', { class: 'oc-small oc-muted' }, note) : null,
      ]),
      extra ? el('div', { class: 'fm-head__tools' }, extra) : null,
    ]),
    el('nav', { class: 'oc-tabs fm-tabs', 'aria-label': 'This form' }, tabs.map(([k, label]) => router.link(`/forms/${f._id}/${k}`,
      [label, k === 'responses' && Number(f.responses) ? el('span', { class: 'oc-count' }, fmt.number(f.responses)) : null],
      { class: 'oc-tab', 'aria-current': k === tab ? 'page' : null }))),
  ]);
}

/** A dialog that closes when the screen changes: a link inside it must not leave it over the next screen. */
export function sheet(content, opts) {
  const d = Orch.dialog(content, opts);
  window.addEventListener('hashchange', () => { try { d.close(); } catch { /* already closed */ } }, { once: true });
  return d;
}

/** A free link name from a title: the form's address after #/. */
export async function freeSlug(title, own) {
  const base = (F.slug(title).replace(/_/g, '-') || 'form').slice(0, 50);
  for (let i = 1; i < 50; i += 1) {
    const s = i === 1 ? base : `${base}-${i}`;
    const hit = await Orch.db.find(T.forms, { slug: s });
    if (!hit || hit._id === own) return s;
  }
  return `${base}-${Date.now().toString(36)}`;
}
