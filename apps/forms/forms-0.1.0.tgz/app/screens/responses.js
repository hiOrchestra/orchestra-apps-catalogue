// What people answered. Complete answers first; spam, rejected (with the
// reason), deleted and those still arriving each have their own tab. A
// response opens in a panel with every answer in words; from there it can be
// marked, deleted, restored or erased for good. Export downloads a CSV.
import { F, T, V, A, act, formRow, formHead, versionDef, parse, badge, stamp, plural } from '../data.js';

const { el, router, fmt } = Orch;
const STATES = [['', 'Complete', 'Complete'], ['spam', 'Spam', 'Spam'], ['rejected', 'Rejected', 'Rejected'], ['deleted', 'Deleted', 'Deleted'], ['new', 'Arriving', 'New']];

export function render({ id, state = '' }, path) {
  Orch.load('view', async () => {
    const [list, row] = await Promise.all([formRow(id), Orch.db.get(T.forms, id)]);
    if (!list || !row) return el('p', { class: 'oc-state' }, 'This form does not exist.');
    const tab = STATES.find((s) => s[0] === state) || STATES[0];
    const counts = await Orch.db.count(T.responses, { filter: { form_id: row._id }, group: 'status' });
    const n = (status) => ((counts.groups || []).find((g) => g.value === status) || {}).count || 0;
    const defs = {};
    const def = (v) => defs[v] || (defs[v] = versionDef(row._id, v));
    const latest = (await def(row.version)) || F.normalize(parse(row.draft, {}));
    const asked = latest.fields.filter((f) => F.TYPES[f.type] !== null);
    const base = `/forms/${row._id}/responses${tab[0] ? `/${tab[0]}` : ''}`;
    const host = el('div', { id: 'fm-responses' });
    const screen = el('div', { class: 'oc-stack oc-stack--loose' }, [
      formHead(list, 'responses', [
        tab[2] === 'Complete' && n('Complete') ? el('button', { type: 'button', class: 'oc-btn', onClick: () => exportCsv(row, latest) }, 'Export CSV') : null,
      ]),
      el('nav', { class: 'fm-states', 'aria-label': 'Which responses' }, STATES.filter((s) => !s[0] || n(s[2])).map((s) => router.link(
        `/forms/${row._id}/responses${s[0] ? `/${s[0]}` : ''}`, [s[1], el('span', { class: 'oc-count' }, fmt.number(n(s[2])))],
        { class: 'fm-state', 'aria-current': s === tab ? 'page' : null }))),
      tab[2] === 'New' && n('New') ? el('div', { class: 'fm-banner' }, [
        'These were sent and are waiting to be checked: usually seconds after they arrive, at the latest within half an hour. ',
        el('button', { type: 'button', class: 'oc-btn oc-btn--sm', onClick: async () => { if (await act(A.processNow, {}, 'Checking them now.')) setTimeout(() => render({ id, state }, path), 4000); } }, 'Check them now'),
      ]) : null,
      host,
    ]);
    const answerCols = asked.slice(0, 4).map((f) => ({ key: `q_${f.ref}`, label: f.title.length > 28 ? `${f.title.slice(0, 27)}…` : f.title, sortable: false,
      render: (r) => el('span', { class: 'fm-cell' }, F.display(f, parse(r.answers, {})[f.ref]) || '—') }));
    setTimeout(() => Orch.table({
      into: host, path: base, query: path, view: V.responses, filter: { form_id: row._id, status: tab[2] }, pageSize: 25, sort: '_id:desc',
      search: 'email', searchPlaceholder: 'Find by email',
      columns: [
        { key: 'submitted_at', label: 'Sent', format: (v) => stamp(v) },
        ...answerCols,
        tab[2] === 'Complete' ? null : { key: 'problem', label: 'Why', clamp: true, sortable: false, render: (r) => r.problem || r.review || '—' },
      ].filter(Boolean),
      detail: { table: T.responses, title: 'Response', render: (r) => panel(r, def, latest, () => render({ id, state }, path)) },
      bulk: tab[2] === 'Complete' ? [
        { label: 'Mark as spam', action: A.spam, done: '{n} marked as spam.' },
        { label: 'Delete', action: A.remove, danger: true, confirm: 'Delete {n} responses? They leave the summaries; you can restore them from Deleted.', done: '{n} deleted.' },
      ] : tab[2] === 'Spam' ? [{ label: 'Not spam', action: A.notSpam, done: '{n} will be checked again.' }]
        : tab[2] === 'Deleted' ? [{ label: 'Restore', action: A.restore, done: '{n} restored.' }] : [],
      empty: tab[2] === 'Complete' ? 'No answers yet. Share the link from Share.' : 'Nothing here.',
    }), 0);
    return screen;
  });
}

/** One response: every answer in words, what came in the link, and what can be done with it. */
async function panel(r, def, latest, again) {
  const d = (await def(r.version)) || latest;
  const answers = parse(r.answers, {});
  const hidden = parse(r.hidden, {});
  const meta = parse(r.meta, {});
  const act2 = (name, done, ask) => el('button', { type: 'button', class: `oc-btn oc-btn--sm${name === A.erase ? ' oc-btn--danger' : ''}`, onClick: async () => {
    if (ask && !(await Orch.confirm(ask, { yes: done.split(' ')[0] }))) return;
    if (await act(name, name === A.erase ? { ids: String(r._id) } : { ids: [r._id] }, done)) again();
  } }, done.replace(/\.$/, ''));
  const rows = d.fields.filter((f) => F.TYPES[f.type] !== null && !F.empty(answers[f.ref]))
    .map((f) => el('div', { class: 'fm-qa' }, [el('dt', f.title), el('dd', F.display(f, answers[f.ref]))]));
  return el('div', { class: 'oc-stack' }, [
    el('div', { class: 'oc-row' }, [badge(r.status), el('span', { class: 'oc-muted oc-small' }, `${stamp(r._created_at)}${meta.ms ? ` · ${Math.max(1, Math.round(meta.ms / 1000))} s to answer` : ''}`)]),
    r.problem ? el('p', { class: 'fm-banner' }, r.problem) : null,
    rows.length ? el('dl', { class: 'fm-qas' }, rows) : el('p', { class: 'oc-muted' }, r.status === 'Erased' ? 'Its answers were erased.' : 'No answers in it.'),
    Object.keys(hidden).length ? el('p', { class: 'oc-small oc-muted' }, `From the link: ${Object.entries(hidden).map(([k, v]) => `${k} = ${v}`).join(' · ')}`) : null,
    el('div', { class: 'oc-row' }, [
      r.status === 'Complete' ? act2(A.spam, 'Mark as spam.') : null,
      r.status === 'Spam' ? act2(A.notSpam, 'Not spam.') : null,
      r.status === 'Deleted' ? act2(A.restore, 'Restore.') : act2(A.remove, 'Delete.', 'Delete this response? It leaves the summaries; you can restore it.'),
      act2(A.erase, 'Erase for good.', 'Erase this response for good? Its answers cannot be recovered. Do this when someone asks for their data to be removed.'),
    ]),
  ]);
}

/** Every complete answer, one column per question of the live version, read 500 at a time. */
async function exportCsv(row, def) {
  Orch.toast('Preparing the file…');
  const asked = def.fields.filter((f) => F.TYPES[f.type] !== null);
  const rows = [];
  for (let offset = 0; offset < 20000; offset += 500) {
    const page = await Orch.db.view(V.responses, { filter: { form_id: row._id, status: 'Complete' }, sort: '_id:asc', limit: 500, offset });
    rows.push(...(page.rows || []));
    if (!page.hasMore) break;
  }
  const cell = (v) => { const s = v === null || v === undefined ? '' : String(v); return /[",\n\r;]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s; };
  const head = ['Sent', ...asked.map((f) => f.title), ...def.hidden, 'Ending'];
  const body = rows.map((r) => {
    const a = parse(r.answers, {});
    const h = parse(r.hidden, {});
    return [stamp(r.submitted_at), ...asked.map((f) => F.display(f, a[f.ref])), ...def.hidden.map((k) => h[k] || ''), r.ending || ''];
  });
  const csv = `﻿${[head, ...body].map((line) => line.map(cell).join(',')).join('\r\n')}`;
  const url = URL.createObjectURL(new Blob([csv], { type: 'text/csv;charset=utf-8' }));
  const a = el('a', { href: url, download: `${row.slug}.csv` });
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 5000);
  Orch.toast(`${plural(rows.length, 'response', 'responses')} exported.`);
}
