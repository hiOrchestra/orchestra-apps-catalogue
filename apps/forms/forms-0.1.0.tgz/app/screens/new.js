// A new form, three ways: describe it and an agent drafts it, start from a
// template, or start blank. All three land on the builder as a draft;
// nothing is published until someone presses Publish.
import { F, T, A, act, settings, freeSlug, parse } from '../data.js';

const { el, router } = Orch;

export async function render(_params, path) {
  Orch.load('view', async () => {
    const s = await settings();
    const lang = new URLSearchParams(path.split('?')[1] || '').get('lang') || s.language || 'es';
    const tpl = await Orch.db.list(T.templates, { filter: { archived: 0, language: lang }, sort: 'position:asc', limit: 50 });
    const request = el('textarea', { class: 'oc-textarea fm-describe', rows: '4',
      placeholder: 'For example: a sign-up for Thursday\'s webinar — name, email, company and role, and how they heard about us. If they are already customers, ask which plan they have.' });
    const go = el('button', { type: 'button', class: 'oc-btn oc-btn--primary' }, 'Draft it');
    go.addEventListener('click', async () => {
      const text = request.value.trim();
      if (text.length < 15) { Orch.toast('Say a little more about what the form should ask.', { error: true }); request.focus(); return; }
      go.disabled = true;
      const r = await act(A.draftAi, { slug: `draft-${Date.now().toString(36)}`, title: 'Drafting…', ai_request: text });
      go.disabled = false;
      if (r && r._id) router.go(`/forms/${r._id}/build`);
    });
    return el('div', { class: 'oc-stack oc-stack--loose fm-new' }, [
      el('div', {}, [el('h1', { class: 'oc-h1 oc-h1--collection' }, 'New form'), el('p', { class: 'oc-muted' }, 'Every way starts a draft you can change before anyone sees it.')]),
      el('section', { class: 'oc-card fm-new__ai' }, [
        el('h2', { class: 'oc-h2' }, 'Describe it'),
        el('p', { class: 'oc-muted' }, 'Say who answers it and what you need to know. An agent writes the questions in a minute or two; you review them.'),
        el('label', { class: 'oc-field' }, [el('span', { class: 'oc-label' }, 'What the form is for'), request]),
        el('div', { class: 'oc-row' }, [go]),
      ]),
      el('section', { class: 'oc-stack' }, [
        el('div', { class: 'oc-row oc-row--between' }, [
          el('h2', { class: 'oc-h2' }, 'Start from a template'),
          el('div', { class: 'oc-row' }, ['es', 'en'].map((l) => router.link(`/new?lang=${l}`, l === 'es' ? 'Español' : 'English',
            { class: `oc-btn oc-btn--sm${l === lang ? '' : ' oc-btn--ghost'}`, 'aria-current': l === lang ? 'true' : null }))),
        ]),
        tpl.rows.length ? el('div', { class: 'fm-templates' }, tpl.rows.map((t) => template(t))) : el('p', { class: 'oc-muted' }, 'No templates in this language.'),
      ]),
      el('section', { class: 'oc-row' }, [
        el('button', { type: 'button', class: 'oc-btn', onClick: () => create({ title: lang === 'es' ? 'Formulario sin título' : 'Untitled form', language: lang,
          fields: [{ ref: 'q1', type: 'short_text', title: '' }], thankyou_screens: [{ ref: 'ending', title: '' }] }) }, 'Start blank'),
      ]),
    ]);
  });
}

function template(t) {
  const def = F.normalize(parse(t.definition, {}));
  const asks = def.fields.filter((f) => F.TYPES[f.type] !== null).length;
  return el('button', { type: 'button', class: 'fm-template', onClick: () => create(def) }, [
    el('strong', t.name),
    el('span', { class: 'oc-muted' }, t.description || ''),
    el('span', { class: 'oc-small oc-muted' }, `${asks} questions${def.logic.length ? ' · with jumps' : ''}`),
  ]);
}

async function create(def) {
  const clean = F.normalize(def);
  const r = await act(A.create, { slug: await freeSlug(clean.title), title: clean.title, draft: JSON.stringify(clean), notify: '{}' });
  if (r && r._id) router.go(`/forms/${r._id}/build`);
}
