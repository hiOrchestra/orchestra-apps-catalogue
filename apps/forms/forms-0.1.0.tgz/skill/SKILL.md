---
name: forms
version: 0.1.0
description: >-
  Make and run forms people answer one question at a time (a Typeform
  replacement on this workspace): write a form from what the person
  describes, save it as a draft, publish it only when they say so, share its
  link, and read back what people answered. Use when someone asks for a form,
  survey, questionnaire, registration, sign-up, application, feedback or NPS
  form, or asks "what did people answer", "how many signed up", "close the
  form". Needs the Forms app installed in the project.
metadata:
  openclaw:
    emoji: "📝"
---
# Forms — make a form, publish it when told, read what came back

The Forms app keeps every form as a definition (Typeform's form JSON, a
subset) and every answer in the project's database. You never write to its
tables yourself: one tool does it, checks the definition with the same rules
the form page uses, and tells you what is wrong.

## The tool

```bash
F=$(ls ~/.openclaw/orchestra/projects/*/apps/forms/automations/forms.js 2>/dev/null | head -1)
node "$F" format          # the rules of a definition, and an example — read it before writing one
```

If `$F` is empty, Forms is not installed in a project you work in: say so,
and do not improvise a form some other way.

Every command prints one JSON line. `ok: false` comes with `errors`, each
with a `path` and a `message`: fix those and run it again.

| To | Run |
|---|---|
| Check a definition | `node "$F" validate --file /tmp/form.json` |
| Save a new draft | `node "$F" save --file /tmp/form.json` (prints its id, link name and links) |
| Save a new draft of a form | `node "$F" save --form <id or link name> --file /tmp/form.json` |
| Publish (only with the person's yes) | `node "$F" publish <form>` |
| Close / reopen | `node "$F" close <form>` · `node "$F" reopen <form>` |
| List the forms | `node "$F" list` |
| Read one | `node "$F" get <form> [--published]` |
| What people answered | `node "$F" responses <form> [--since YYYY-MM-DD] [--limit 20]` |
| The totals per question | `node "$F" summary <form>` |
| The link, with values for hidden fields | `node "$F" link <form> --hidden utm_source=newsletter` |

## Making a form

1. **Ask what you need to, not more.** Who answers it, what the person needs to
   learn from them, and anything that changes the path ("if they are already
   customers, ask the plan"). The language: the one the people answering speak.
2. **Write the definition** in a file, following `format`:
   - Short questions, one idea each, in the language of the people answering;
     in Spanish, tú.
   - Mark as required only what is essential.
   - Use jumps only where the request needs a different path.
   - Add a consent question (`legal`) when you ask for personal data.
   - Earlier answers can appear in later questions: `{{field:<ref>}}`.
3. **Save it as a draft** with `save`. If it answers `ok: false`, fix what each
   error names and save again; never hand the person a form that did not save.
4. **Show the person** the questions in a few lines and the `edit` link (the
   builder, with a preview). Say it is a draft: nobody can answer it yet.
5. **Publish only when they say so**, with `publish`. Then give them the `link`.
   A published form is answered by anyone who has the link.

Changing a live form: `save --form <form>` stores a new draft and changes
nothing for the people answering until it is published again; answers already
in keep the questions they answered.

## Reading what came back

- "How is the form doing?" → `summary`: how many answered, and each question's
  answers counted per option, averaged, or quoted, with the NPS.
- "What did they say?" → `responses`, newest first; `--since` for the recent
  ones. Quote people's words; never invent or tidy them.
- Answers are checked seconds after they arrive (at the latest within half an
  hour): a response marked Spam or Rejected has a `problem` that says why.

## Never

- Publish, close or reopen without the person asking for it in this conversation.
- Write to the `forms_*` tables directly, or edit an answer.
- Send the link to people yourself unless the person asked you to and said to whom.
- Put an email, a phone or a name into a link's hidden fields: anyone with the link can read them.
