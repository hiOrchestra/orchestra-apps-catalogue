// Settings for every form — where new answers are announced, the language a new
// form starts in — are managed in Orchestra (Apps → Formularios → Ajustes):
// typed, next to its connections and who does its work. Here, what they are now
// and a way there. Each form still turns its own announcements off in its own Settings.
import { settings } from '../data.js';

const { el } = Orch;

export function render() {
  Orch.load('view', async () => {
    const s = await settings(true);
    const link = el('a', { class: 'oc-btn oc-btn--primary', target: '_blank', rel: 'noopener', hidden: true }, 'Open the settings in Orchestra');
    const where = el('p', { class: 'oc-muted' }, 'In Orchestra: Apps → Formularios → Ajustes.');
    if (Orch.manageUrl) Orch.manageUrl('settings').then((url) => { if (url) { link.href = url; link.hidden = false; where.hidden = true; } });
    const facts = [
      ['Telegram', s.notify_telegram ? 'on' : 'off'],
      ['Email', s.notify_emails ? s.notify_emails : 'off'],
      ['New forms start in', (s.language || 'es') === 'en' ? 'English' : 'Español'],
    ];
    return el('div', { class: 'oc-stack oc-stack--loose fm-narrow' }, [
      el('div', {}, [el('h1', { class: 'oc-h1 oc-h1--collection' }, 'Settings'), el('p', { class: 'oc-muted' }, 'Managed in Orchestra. Each form can turn its announcements off in its own Settings.')]),
      el('section', { class: 'oc-card oc-stack' }, [
        el('h2', { class: 'oc-h3' }, 'Where new answers are announced, and new forms'),
        el('ul', { class: 'oc-stack' }, facts.map(([k, v]) => el('li', [el('b', `${k}: `), v]))),
        el('div', { class: 'oc-row' }, [link]), where,
      ]),
    ]);
  });
}
