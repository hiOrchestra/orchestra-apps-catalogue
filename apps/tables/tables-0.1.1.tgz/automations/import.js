'use strict';
/**
 * Tables · Import guests: the parts of a CSV the desk sent (a TheFork,
 * CoverManager or Quandoo export, read and mapped in the browser by
 * tablecore.guestsFrom, ~80 KB a part), checked again here and merged into
 * tb_guests by email, else by phone: an existing guest keeps what it has and
 * gains what was missing (phone, email, allergies), notes are added, and the
 * visits count is the larger of the two. Nothing is ever sent to a guest.
 *   node import.js [--auto|--now] [--dry-run]
 */
const L = require('./lib');
const C = require('./tablecore');

function clean(g) {
  const email = C.normEmail(g.email);
  const phone = C.normPhone(g.phone);
  return {
    name: String(g.name || '').trim().slice(0, 120), email: C.isEmail(email) ? email : '', phone: phone.slice(0, 25), phone_key: C.phoneKey(phone),
    notes: String(g.notes || '').trim().slice(0, 1000), allergies: String(g.allergies || '').trim().slice(0, 300),
    visits: Math.max(0, Math.min(9999, parseInt(g.visits, 10) || 0)), vip: g.vip === 'yes' ? 'yes' : 'no',
  };
}

/** Where the list came from: a marketplace (TheFork, Quandoo, or one named in Settings) counts as a marketplace guest. */
function originOf(part, s) {
  const name = C.srcOf(part.origin) || 'Import';
  const markets = ['thefork', 'quandoo', 'opentable', ...String(s.marketplaces || '').split(',').map((x) => x.trim().toLowerCase()).filter(Boolean)];
  return markets.includes(name.toLowerCase()) ? { first_source: 'market', first_src: name } : { first_source: 'import', first_src: name };
}

function merge(part, dry) {
  const origin = originOf(part, L.settings());
  const rows = (C.jsonOf(part.rows, []) || []).map(clean).filter((g) => g.email || g.phone_key);
  const res = { added: 0, updated: 0, skipped: (C.jsonOf(part.rows, []) || []).length - rows.length };
  const ops = [];
  const seen = new Map(); // inside one part, the same person twice is one guest
  for (const g of rows) {
    const key = g.email || `p:${g.phone_key}`;
    if (seen.has(key)) { res.skipped += 1; continue; }
    seen.set(key, true);
    let have = g.email ? L.one('SELECT * FROM tb_guests WHERE _deleted = 0 AND lower(email) = ? ORDER BY _id LIMIT 1', g.email) : null;
    if (!have && g.phone_key) have = L.one('SELECT * FROM tb_guests WHERE _deleted = 0 AND phone_key = ? ORDER BY _id LIMIT 1', g.phone_key);
    if (have) {
      const data = {};
      if (!have.name && g.name) data.name = g.name;
      if (!have.email && g.email) data.email = g.email;
      if (!have.phone && g.phone) Object.assign(data, { phone: g.phone, phone_key: g.phone_key });
      if (!have.allergies && g.allergies) data.allergies = g.allergies;
      if (g.notes && !String(have.notes || '').includes(g.notes)) data.notes = [have.notes, g.notes].filter(Boolean).join('\n').slice(0, 2000);
      if (g.visits > (Number(have.imported_visits) || 0)) data.imported_visits = g.visits;
      if (g.vip === 'yes' && have.vip !== 'yes') data.vip = 'yes';
      if (!have.first_source) Object.assign(data, origin);
      if (Object.keys(data).length) { ops.push({ op: 'update', table: 'tb_guests', id: have._id, data }); res.updated += 1; } else res.skipped += 1;
    } else {
      ops.push({ op: 'insert', table: 'tb_guests', data: { name: g.name, email: g.email, phone: g.phone, phone_key: g.phone_key, notes: g.notes, allergies: g.allergies,
        vip: g.vip, imported_visits: g.visits, lang: '', source: 'import', import_batch: String(part.batch || '').slice(0, 40), ...origin } });
      res.added += 1;
    }
  }
  ops.push({ op: 'update', table: 'tb_imports', id: part._id, when: { status: 'New' }, data: { status: 'Done', result: JSON.stringify(res), rows: '' } });
  if (!dry) L.write(ops);
  return res;
}

function run(mode = '--auto', { dry = false } = {}) {
  const held = dry ? { release() {} } : L.lock('import');
  if (!held) return { ok: true, mode, skipped: 'Another import is running' };
  try {
    const out = { ok: true, mode, parts: 0, added: 0, updated: 0, skipped: 0, failed: [] };
    for (const part of L.all("SELECT * FROM tb_imports WHERE _deleted = 0 AND status = 'New' ORDER BY batch, part LIMIT 50")) {
      try {
        const r = merge(part, dry);
        out.parts += 1;
        for (const k of ['added', 'updated', 'skipped']) out[k] += r[k];
      } catch (e) {
        out.failed.push({ part: part._id, error: e.message.slice(0, 200) });
        if (!dry) { try { L.write([{ op: 'update', table: 'tb_imports', id: part._id, when: { status: 'New' }, data: { status: 'Failed', result: JSON.stringify({ error: e.message.slice(0, 300) }) } }]); } catch { /* moved */ } }
      }
    }
    return out;
  } finally {
    held.release();
  }
}

if (require.main === module) {
  const argv = process.argv.slice(2);
  L.main(() => run(argv.includes('--now') ? '--now' : '--auto', { dry: argv.includes('--dry-run') }));
}

module.exports = { run, clean, originOf };
