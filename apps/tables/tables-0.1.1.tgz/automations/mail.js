'use strict';
/**
 * Tables · Booking emails (optional, off by default: Settings → "Read booking
 * emails"). The two script steps around one agent turn:
 *
 *   node mail.js pick   reads the business's Gmail inbox since the last look
 *                       (Composio, read only), keeps the messages about
 *                       bookings (a reply in a thread we wrote, or words like
 *                       reserva / mesa / booking / table), each ONCE (a unique
 *                       index on the Gmail id), claims up to five (New →
 *                       Working) and prints what the agent needs: the message
 *                       and the booking it is about. Under 18 000 characters.
 *   node mail.js save   checks the agent's answer ($PRIOR, JSON only) and acts
 *                       through the same door as the public page (seat.js):
 *                       a new booking inside the rules is confirmed and the
 *                       confirmation goes as a reply in the guest's thread; a
 *                       change or a cancellation inside the rules is applied
 *                       and the guest is told. Anything else — full, outside
 *                       the rules, a question — becomes a draft the host
 *                       approves (Requests → Emails). The agent never writes
 *                       to the database and never sends.
 *
 * An answer that does not pass the checks marks nothing: the message goes
 * back to New, and after three tries it waits on the desk as Failed.
 */
const L = require('./lib');
const C = require('./tablecore');
const S = require('./seat');
const X = require('./composio');

const TAKE = 5;
const BODY = 2000;
const STUCK_MS = 30 * 60000;
const ABOUT = /\b(reserv\w*|mesa|mesas|comensales|personas|cena|cenar|comida|comer|almuerzo|booking|book|table|reservation|dinner|lunch|guests|people|cancel\w*|anul\w*)\b/i;
const INTENTS = ['new', 'change', 'cancel', 'late', 'question', 'ignore'];

/** The guest's own words: the quoted history under "On … wrote:" is cut. */
function ownWords(text) {
  const lines = String(text || '').replace(/\r\n/g, '\n').split('\n');
  const cut = lines.findIndex((l, i) => i > 0 && (/^\s*(On|El|Le|Am) .{4,200}(wrote|escribió|a écrit|schrieb):\s*$/i.test(l) || /^-{2,}\s*(Original Message|Mensaje original)/i.test(l) || /^>/.test(l)));
  return (cut > 0 ? lines.slice(0, cut) : lines).join('\n').trim().slice(0, BODY);
}
const addressOf = (from) => C.normEmail((String(from).match(/<([^>]+)>/) || [])[1] || from);
const nameOf = (from) => String(from).replace(/<[^>]*>/, '').replace(/"/g, '').trim().slice(0, 120);
const brief = (b) => b && { id: b._id, status: b.status, name: b.name, party: b.party, day: b.day, time: b.start_at && C.localTime(new Date(b.start_at), L.settings().timezone || 'UTC'), note: b.note || '' };

function look(s) {
  const now = L.now();
  const since = Math.floor((L.toDate(s.mail_cursor) || new Date(now.getTime() - 2 * 86400000)).getTime() / 1000) - 600;
  const r = X.fetch(s, { query: `in:inbox -from:me after:${since}`, max: 25 });
  if (!r.ok) {
    L.write([{ op: 'update', table: 'tb_settings', id: s._id, data: { mail_at: L.sqlNow(), mail_note: `Gmail could not be read: ${String(r.why).slice(0, 200)}`, ...(r.notConnected ? { gmail_status: 'not_connected' } : {}) } }]);
    return { error: r.why };
  }
  let kept = 0;
  const ops = [];
  for (const m of r.messages) {
    if (L.one('SELECT 1 AS x FROM tb_mail WHERE gmail_id = ? AND _deleted = 0', m.id)) continue;
    const ours = m.threadId && L.one("SELECT 1 AS x FROM tb_emails WHERE thread_id = ? AND _deleted = 0 UNION SELECT 1 FROM tb_bookings WHERE mail_thread_id = ? AND _deleted = 0", m.threadId, m.threadId);
    if (!ours && !ABOUT.test(`${m.subject}\n${m.text}`)) continue;
    ops.push({ op: 'insert', table: 'tb_mail', data: { gmail_id: m.id, thread_id: m.threadId, from_email: addressOf(m.from), from_name: nameOf(m.from),
      subject: m.subject.slice(0, 200), body: ownWords(m.text), received_at: m.at ? L.isoZ(m.at) : L.isoZ(now), status: 'New', attempts: 0 } });
    kept += 1;
  }
  const newest = r.messages.map((m) => m.at).filter(Boolean).sort((a, b) => b - a)[0];
  ops.push({ op: 'update', table: 'tb_settings', id: s._id, data: { mail_at: L.sqlNow(), mail_note: `${kept} booking ${kept === 1 ? 'email' : 'emails'} in the last look`, ...(newest ? { mail_cursor: L.isoZ(newest) } : {}) } });
  L.write(ops);
  return { kept };
}

function pick() {
  const s = L.settings();
  if (s.mail_on !== 'yes') return { skip: true, why: 'Reading booking emails is off' };
  const cut = L.sqlNow(new Date(L.now().getTime() - STUCK_MS));
  for (const m of L.all("SELECT _id, attempts FROM tb_mail WHERE _deleted = 0 AND status = 'Working' AND picked_at < ?", cut)) {
    try { L.write([{ op: 'update', table: 'tb_mail', id: m._id, when: { status: 'Working' }, data: { status: (m.attempts || 0) >= 3 ? 'Failed' : 'New', result: 'The agent did not answer in time' } }]); } catch { /* moved */ }
  }
  const seen = look(s);
  const rows = L.all("SELECT * FROM tb_mail WHERE _deleted = 0 AND status = 'New' ORDER BY received_at LIMIT ?", TAKE);
  if (!rows.length) return { skip: true, why: 'No booking email waits', seen };
  const picked = [];
  for (const m of rows) {
    try { L.write([{ op: 'update', table: 'tb_mail', id: m._id, when: { status: 'New' }, data: { status: 'Working', picked_at: L.sqlNow(), attempts: (m.attempts || 0) + 1 } }]); picked.push(m); } catch { /* another run */ }
  }
  const tz = C.validZone(s.timezone || 'UTC');
  const ctx = S.context();
  const today = C.localDay(L.now(), tz);
  const hours = [0, 1, 2, 3, 4, 5, 6].map((i) => C.addDays(today, i)).map((d) => `${d} (${C.weekday(d)}): ${C.servicesOn(d, ctx.services, ctx.exceptions).map((x) => `${x.name} ${x.first}–${x.last}`).join(', ') || 'closed'}`);
  return {
    restaurant: { name: s.business_name, timezone: tz, today, max_online_party: Number(s.max_online_party) || 8, next_days: hours },
    emails: picked.map((m) => {
      const thread = m.thread_id && L.one('SELECT b.* FROM tb_bookings b WHERE b._deleted = 0 AND (b.mail_thread_id = ? OR b._id IN (SELECT booking_id FROM tb_emails WHERE thread_id = ? AND _deleted = 0)) ORDER BY b._id DESC LIMIT 1', m.thread_id, m.thread_id);
      const theirs = L.all("SELECT * FROM tb_bookings WHERE _deleted = 0 AND lower(email) = ? AND status IN ('Confirmed', 'Requested') AND start_at > ? ORDER BY start_at LIMIT 3", m.from_email, L.isoZ(L.now()));
      return { mail: m._id, from: m.from_email, name: m.from_name, subject: m.subject, received: m.received_at, text: m.body, thread_booking: brief(thread), their_bookings: theirs.map(brief) };
    }),
  };
}

function jsonIn(text) {
  const grab = (t) => { const x = String(t || '').replace(/```(?:json)?/gi, ''); const a = x.indexOf('{'); const b = x.lastIndexOf('}'); if (a < 0 || b <= a) return null; try { return JSON.parse(x.slice(a, b + 1)); } catch { return null; } };
  const j = grab(text);
  if (j && typeof j.content === 'string') { const inner = grab(j.content); if (inner) return inner; }
  return j;
}

/** One item of the agent's answer, checked; { error } when it cannot be used. */
function checkItem(it, ids) {
  if (!it || typeof it !== 'object' || !ids.has(Number(it.mail))) return { error: 'It names no email that was picked' };
  if (!INTENTS.includes(it.intent)) return { error: `Unknown intent "${it.intent}"` };
  const reply = typeof it.reply === 'string' ? it.reply.trim() : '';
  if (reply.length > 1500) return { error: 'The reply is too long' };
  if (/https?:\/\/|www\.|\{\{|\[[A-Z_ ]+\]|<[a-z]/i.test(reply)) return { error: 'The reply has a link or a placeholder' };
  const out = { mail: Number(it.mail), intent: it.intent, reply, lang: it.lang === 'en' ? 'en' : 'es', booking: Number(it.booking) || null,
    name: String(it.name || '').trim().slice(0, 120), phone: C.normPhone(it.phone), note: String(it.note || '').trim().slice(0, 500),
    allergies: String(it.allergies || '').trim().slice(0, 300), special: it.special === true || it.special === 'yes' ? 'yes' : 'no' };
  if (['new', 'change'].includes(it.intent)) {
    if (it.date && !C.realDay(it.date)) return { error: 'The date is not a real day' };
    if (it.time && C.toMin(it.time) === null) return { error: 'The time is not HH:MM' };
    if (it.party !== undefined && it.party !== null && (!Number.isInteger(Number(it.party)) || Number(it.party) < 1 || Number(it.party) > C.MAX_PARTY)) return { error: 'The party size is not valid' };
    if (it.intent === 'new' && !(it.date && it.time && it.party)) return { error: 'A new booking needs a date, a time and a party size' };
    Object.assign(out, { date: it.date || '', time: it.time || '', party: it.party ? Number(it.party) : null });
  }
  return out;
}

function draft(m, b, reply, why, s) {
  return { op: 'insert', table: 'tb_emails', data: { booking_id: b ? b._id : null, mail_id: m._id, kind: 'reply', to_email: m.from_email,
    subject: /^re:/i.test(m.subject) ? m.subject : `Re: ${m.subject || s.business_name || ''}`.trim(), body: reply || '', thread_id: m.thread_id || '',
    status: 'Review', drafted_by: 'agent', error: why ? `Why it waits: ${why}` : '' } };
}

/** Which booking an email is about: the agent's pick (if it is the sender's or the thread's), the thread's, or the sender's only upcoming one. */
function bookingOf(m, it) {
  const ok = (b) => b && (C.normEmail(b.email) === m.from_email || (m.thread_id && b.mail_thread_id === m.thread_id)
    || (m.thread_id && L.one('SELECT 1 AS x FROM tb_emails WHERE booking_id = ? AND thread_id = ? AND _deleted = 0', b._id, m.thread_id)));
  if (it.booking) { const b = L.one('SELECT * FROM tb_bookings WHERE _id = ? AND _deleted = 0', it.booking); if (ok(b)) return b; }
  const t = m.thread_id && L.one('SELECT * FROM tb_bookings WHERE _deleted = 0 AND (mail_thread_id = ? OR _id IN (SELECT booking_id FROM tb_emails WHERE thread_id = ? AND _deleted = 0)) ORDER BY _id DESC LIMIT 1', m.thread_id, m.thread_id);
  if (t) return t;
  const mine = L.all("SELECT * FROM tb_bookings WHERE _deleted = 0 AND lower(email) = ? AND status IN ('Confirmed', 'Requested') AND start_at > ? ORDER BY start_at", m.from_email, L.isoZ(L.now()));
  return mine.length === 1 ? mine[0] : null;
}

function act(m, it, s) {
  const done = (result, extra = [], booking = null) => L.write([...extra, { op: 'update', table: 'tb_mail', id: m._id, when: { status: 'Working' }, data: { status: extra.some((o) => o.data && o.data.status === 'Review') ? 'Review' : 'Done', intent: it.intent, result, booking_id: booking } }]);
  if (it.intent === 'ignore') return L.write([{ op: 'update', table: 'tb_mail', id: m._id, when: { status: 'Working' }, data: { status: 'Ignored', intent: 'ignore', result: 'Not about a booking' } }]);
  if (it.intent === 'new') {
    const tz = C.validZone(s.timezone || 'UTC');
    const start = L.isoZ(C.localToUtc(it.date, it.time, tz));
    const [ins] = L.write([{ op: 'insert', table: 'tb_bookings', data: { name: it.name || m.from_name, email: m.from_email, phone: it.phone, party: it.party, start_at: start,
      note: it.note, allergies: it.allergies, special: it.special, lang: it.lang, status: 'New', source: 'email', mail_thread_id: m.thread_id || '', token: C.newToken(), created_by: 'agent' } }]);
    const r = S.settle(ins._id, (b, ctx) => (b.status === 'New' ? S.judgeNew(b, ctx) : null)) || {};
    const b = L.one('SELECT * FROM tb_bookings WHERE _id = ?', ins._id);
    if (r.status === 'Confirmed') return done('Booked and confirmed', [], b._id);
    if (r.status === 'Requested') return done(`Waits for your OK: ${b.reason}`, it.reply ? [draft(m, b, it.reply, 'the booking waits for your OK', s)] : [], b._id);
    const tpl = C.email('full', b, s, { page: s.public_url, others: C.jsonOf(b.offer, []) }).body;
    return done(`Not booked: ${b.reason}`, [draft(m, b, it.reply || tpl, b.reason, s)], b._id);
  }
  const b = bookingOf(m, it);
  if (!b) return done('No booking found for it', [draft(m, null, it.reply, 'no booking was found for this email', s)]);
  if (it.intent === 'cancel' && ['Confirmed', 'Requested'].includes(b.status)) {
    const r = S.settle(b._id, (x, ctx) => (['Confirmed', 'Requested'].includes(x.status) ? { ops: [{ op: 'update', table: 'tb_bookings', id: x._id, when: { status: x.status },
      data: { status: 'Cancelled', cancelled_by: 'guest', decided_at: L.sqlNow() } }, S.emailOp('cancelled', x, ctx.s)].filter(Boolean) } : null));
    return done(r && !r.error ? 'Cancelled' : 'Could not cancel', [], b._id);
  }
  if (it.intent === 'change') {
    const tz = C.validZone(s.timezone || 'UTC');
    const cur = { date: b.day, time: C.localTime(new Date(b.start_at), tz) };
    const start = (it.date || it.time) ? L.isoZ(C.localToUtc(it.date || cur.date, it.time || cur.time, tz)) : null;
    const r = S.settle(b._id, (x, ctx) => {
      const p = S.judgeChange(x, { party: it.party, start_at: start }, ctx, { guest: true, when: { status: x.status, start_at: x.start_at, party: x.party } });
      if (p.status !== 'Done') return p;
      const mail = S.emailOp('changed', Object.assign({}, x, p.data), ctx.s);
      if (p.data.notice) delete p.data.notice;
      return Object.assign(p, { ops: [...p.ops, mail].filter(Boolean) });
    }) || {};
    if (r.status === 'Done' && !r.error) return done('Changed', [], b._id);
    return done(`Not changed: ${r.why || r.error || ''}`, [draft(m, b, it.reply || r.why, r.why, s)], b._id);
  }
  const extra = [];
  if (it.intent === 'late' && it.note) extra.push({ op: 'update', table: 'tb_bookings', id: b._id, data: { note: [b.note, `Email: ${it.note}`].filter(Boolean).join(' · ').slice(0, 500) } });
  if (it.reply) extra.push(draft(m, b, it.reply, it.intent === 'late' ? 'the guest wrote they are running late' : 'the guest asked something', s));
  return done(it.intent === 'late' ? 'Noted on the booking' : 'A reply waits for your OK', extra, b._id);
}

function save() {
  let picked = {};
  try { picked = JSON.parse(String(process.env.STEP_pick || '').trim().split('\n').pop() || '{}'); } catch { picked = {}; }
  if (picked.skip || !Array.isArray(picked.emails)) return { ok: true, skipped: 'Nothing was picked' };
  const s = L.settings();
  const ids = new Set(picked.emails.map((e) => Number(e.mail)));
  const answer = jsonIn(process.env.PRIOR);
  const items = answer && Array.isArray(answer.items) ? answer.items : null;
  const out = { ok: true, done: [], back: [] };
  const used = new Set();
  for (const raw of items || []) {
    const it = checkItem(raw, ids);
    const m = it.error ? null : L.one("SELECT * FROM tb_mail WHERE _id = ? AND status = 'Working' AND _deleted = 0", it.mail);
    if (it.error || !m || used.has(it.mail)) { if (!it.error) continue; out.back.push({ mail: raw && raw.mail, why: it.error }); continue; }
    used.add(it.mail);
    try { act(m, it, s); out.done.push({ mail: m._id, intent: it.intent }); } catch (e) { out.back.push({ mail: m._id, why: e.message.slice(0, 160) }); }
  }
  // Whatever was not used goes back to New (or Failed after three tries): nothing is marked on a bad answer.
  for (const id of ids) {
    if (used.has(id) && out.done.some((d) => d.mail === id)) continue;
    const m = L.one("SELECT _id, attempts FROM tb_mail WHERE _id = ? AND status = 'Working'", id);
    if (!m) continue;
    const why = (out.back.find((x) => Number(x.mail) === id) || {}).why || (items ? 'The agent left it out' : 'The agent did not answer with JSON');
    try { L.write([{ op: 'update', table: 'tb_mail', id, when: { status: 'Working' }, data: { status: (m.attempts || 0) >= 3 ? 'Failed' : 'New', result: why } }]); } catch { /* moved */ }
  }
  if (L.one("SELECT COUNT(*) AS n FROM tb_emails WHERE _deleted = 0 AND status = 'Approved'").n) out.send = L.kick('send');
  return out;
}

if (require.main === module) {
  const cmd = process.argv[2];
  L.main(() => (cmd === 'pick' ? pick() : cmd === 'save' ? save() : { ok: false, error: 'node mail.js pick|save' }));
}

module.exports = { pick, save, checkItem, jsonIn, ownWords, ABOUT };
