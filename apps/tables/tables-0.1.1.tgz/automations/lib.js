'use strict';
/**
 * What every Tables script shares (Booking's lib.js, the SDK the platform
 * does not have yet, adapted): reading the project's database, writing to it,
 * one run at a time, talking to the instance as the workflow's agent,
 * Composio, starting another workflow, and telling the owner.
 *
 * Reads go to the project's SQLite file directly, read-only and
 * parameterised. Every write goes through `orch-database batch`, the
 * platform's own writer: one transaction, and a `when` precondition checked
 * inside the UPDATE, so "this booking is mine now" is atomic.
 *
 * Locally (TABLES_LOCAL=1) the same batch runs against TABLES_DB with the
 * same semantics and notices are recorded, not sent. TABLES_FAKE_COMPOSIO=1
 * answers Gmail from a JSON file (composio.js), so nothing reaches Google in a
 * test; starting a workflow and Telegram are recorded. TABLES_NOW pins the clock.
 */
const { DatabaseSync } = require('node:sqlite');
const C = require('./tablecore');
const { execFileSync } = require('child_process');
const fs = require('fs');
const os = require('os');
const path = require('path');

const PROJECT = process.env.TABLES_PROJECT || (__dirname.match(/projects\/([^/]+)\/apps\/tables/) || [])[1] || 'default';
const STATE = process.env.OPENCLAW_STATE_DIR || '/home/node/.openclaw';
const DB_PATH = process.env.TABLES_DB || path.join(STATE, 'orchestra', 'projects', PROJECT, 'data', 'data.db');
const LOCAL = process.env.TABLES_LOCAL === '1';

// ── reading ──────────────────────────────────────────────────────────────
let reader = null;
function db() {
  if (!reader) {
    reader = new DatabaseSync(DB_PATH, { readOnly: true });
    reader.exec('PRAGMA busy_timeout = 5000');
  }
  return reader;
}
/** A fresh reader: after a write in this process, the old one may hold an older snapshot. */
function reread() { if (reader) { try { reader.close(); } catch { /* closed */ } } reader = null; }
const all = (sql, ...params) => db().prepare(sql).all(...params);
const one = (sql, ...params) => db().prepare(sql).get(...params);

function settings() {
  const s = one('SELECT * FROM tb_settings WHERE _deleted = 0 ORDER BY _id LIMIT 1');
  if (!s) throw new Error('Tables has no settings row: it is not installed in this project');
  return s;
}

/** JSON kept in a text column, or the fallback when it is empty or not JSON. */
function jsonOf(text, fallback) {
  if (text === null || text === undefined || text === '') return fallback;
  if (typeof text === 'object') return text;
  try { return JSON.parse(text); } catch { return fallback; }
}

// ── writing ──────────────────────────────────────────────────────────────
/** One transaction per chunk (an argv string over 128 KB is refused), all or nothing; the inserted ids in order. */
function write(ops) {
  const chunks = [];
  let cur = [];
  let size = 0;
  for (const op of ops) {
    const n = JSON.stringify(op).length;
    if (cur.length && size + n > 90000) { chunks.push(cur); cur = []; size = 0; }
    cur.push(op);
    size += n;
  }
  if (cur.length) chunks.push(cur);
  const results = [];
  for (const chunk of chunks) results.push(...((LOCAL ? localBatch(chunk) : cliBatch(chunk)).results || []));
  reread();
  return results;
}

function cliBatch(ops) {
  let out;
  try {
    out = execFileSync('orch-database', ['--project', PROJECT, 'batch', '--ops', JSON.stringify(ops)],
      { encoding: 'utf8', timeout: 60000, maxBuffer: 16 << 20 });
  } catch (e) {
    let j = null;
    try { j = JSON.parse(String(e.stdout || '')); } catch { /* not JSON */ }
    throw new Error((j && j.error) || String(e.stderr || e.message).trim().slice(0, 300));
  }
  const j = JSON.parse(out);
  if (!j.ok) throw new Error(j.error || 'the write failed');
  return j;
}

/** orch-database's run_batch, for local tests: same `when`, same all-or-none, same `as` / `$name._id` references, same results. */
function localBatch(ops) {
  const w = new DatabaseSync(DB_PATH);
  w.exec('PRAGMA busy_timeout = 5000');
  const now = sqlNow();
  const named = {};
  const deref = (v) => {
    if (typeof v !== 'string' || !v.startsWith('$')) return v;
    const key = v.slice(1).split('.')[0];
    if (!named[key]) throw new Error(`reference ${v} names a step that has not run`);
    return named[key]._id;
  };
  const results = [];
  w.exec('BEGIN IMMEDIATE');
  try {
    ops.forEach((op, i) => {
      const data = {};
      for (const [k, v] of Object.entries(op.data || {})) if (!k.startsWith('_')) data[k] = deref(v);
      if (op.op === 'insert') {
        const cols = [...Object.keys(data), '_created_at', '_updated_at'];
        const r = w.prepare(`INSERT INTO "${op.table}" (${cols.map((c) => `"${c}"`).join(', ')}) VALUES (${cols.map(() => '?').join(', ')})`)
          .run(...Object.values(data), now, now);
        const id = Number(r.lastInsertRowid);
        if (op.as) named[op.as] = { _id: id };
        results.push({ op: 'insert', table: op.table, _id: id });
      } else {
        const when = op.when || {};
        const id = deref(op.id);
        const r = w.prepare(`UPDATE "${op.table}" SET ${Object.keys(data).map((c) => `"${c}" = ?`).join(', ')}, _updated_at = ? `
          + `WHERE _id = ? AND _deleted = 0${Object.keys(when).map((c) => ` AND "${c}" IS ?`).join('')}`)
          .run(...Object.values(data), now, id, ...Object.values(when));
        if (!r.changes) throw new Error(`op ${i}: row ${id} changed meanwhile (precondition failed)`);
        results.push({ op: 'update', table: op.table, _id: id });
      }
    });
    w.exec('COMMIT');
  } catch (e) {
    w.exec('ROLLBACK');
    w.close();
    throw e;
  }
  w.close();
  return { ok: true, applied: results.length, results };
}

/** Soft-delete rows by id (integers only, so the WHERE is safe to build). */
function softDelete(table, ids) {
  const list = ids.filter((x) => Number.isInteger(x));
  if (!list.length) return 0;
  const where = `_id IN (${list.join(',')})`;
  if (LOCAL) {
    const w = new DatabaseSync(DB_PATH);
    const r = w.prepare(`UPDATE "${table}" SET _deleted = 1, _updated_at = ? WHERE ${where}`).run(sqlNow());
    w.close();
    reread();
    return r.changes;
  }
  const out = JSON.parse(execFileSync('orch-database', ['--project', PROJECT, 'delete', table, '--where', where], { encoding: 'utf8', timeout: 60000 }));
  if (out.ok === false) throw new Error(out.error || 'the delete failed');
  reread();
  return out.affected || 0;
}

// ── one run at a time ────────────────────────────────────────────────────
const STALE_MS = 150000; // longer than a step may run (120 s): a file this old was left by a killed run

/**
 * A lock file per job, so a burst of requests has one run doing the work. It
 * saves work; what keeps a booking from being taken twice is every `when`.
 *   lock('intake') -> { release() }, or null when another run holds it
 */
function lock(name) {
  let who = process.env.ORCHESTRA_AGENT_ID;
  if (!who) { try { who = os.userInfo().username; } catch { who = 'node'; } }
  const file = path.join(process.env.TABLES_LOCK_DIR || os.tmpdir(), `orchestra-tables-${PROJECT}-${who}-${name}.lock`);
  const held = { file, release() { try { fs.unlinkSync(file); } catch { /* already gone */ } } };
  for (let i = 0; i < 2; i += 1) {
    try {
      fs.writeFileSync(file, String(process.pid), { flag: 'wx' });
      return held;
    } catch (e) {
      if (e.code !== 'EEXIST') return { file: null, release() {} };
      let age;
      try { age = Date.now() - fs.statSync(file).mtimeMs; } catch { continue; }
      if (age < STALE_MS) return null;
      try { fs.unlinkSync(file); } catch { /* another run took it over first */ }
    }
  }
  return null;
}

// ── time ─────────────────────────────────────────────────────────────────
/** Now, or TABLES_NOW in tests. */
const now = () => (process.env.TABLES_NOW ? new Date(process.env.TABLES_NOW) : new Date());
/** 'YYYY-MM-DD HH:MM:SS' in UTC: the format orch-database stamps rows with. */
const sqlNow = (d = now()) => d.toISOString().slice(0, 19).replace('T', ' ');
/** 'YYYY-MM-DDTHH:MM:SSZ': the one format slot and booking times are kept in, so strings compare. */
const isoZ = (d) => `${d.toISOString().slice(0, 19)}Z`;

/** '2026-10-03 10:00:00' (orch-database, UTC) or ISO as a Date; null when not a time. */
function toDate(v) {
  if (!v) return null;
  const s = String(v).trim();
  const iso = s.includes('T') ? s : s.replace(' ', 'T');
  const d = new Date(/[zZ]|[+-]\d\d:?\d\d$/.test(iso) ? iso : `${iso}Z`);
  return Number.isNaN(d.getTime()) ? null : d;
}

// ── the instance, as this workflow's agent ───────────────────────────────
function identityHeaders() {
  const id = process.env.ORCHESTRA_AGENT_ID;
  const token = process.env.ORCHESTRA_AGENT_TOKEN;
  if (id && token) return { 'x-orchestra-agent': id, 'x-orchestra-agent-token': token };
  const secret = process.env.HOOKS_TOKEN || process.env.OPENCLAW_GATEWAY_TOKEN || '';
  return secret ? { 'x-orchestra-secret': secret } : {};
}

/**
 * POST to the instance's api-server. Headers go to curl on stdin (-K -),
 * never argv, so the token is not in the process list. Never throws; a
 * timeout says so (`timedOut`), because then the other side may have acted.
 */
function post(route, body, seconds = 30) {
  const q = (v) => `"${String(v).replace(/[\\"]/g, '\\$&')}"`;
  const config = [
    `url = ${q(`http://127.0.0.1:${Number(process.env.API_SERVER_PORT || 3001)}${route}`)}`,
    'request = "POST"',
    'header = "Content-Type: application/json"',
    ...Object.entries(identityHeaders()).map(([k, v]) => `header = ${q(`${k}: ${v}`)}`),
    `data = ${q(JSON.stringify(body))}`,
  ].join('\n');
  try {
    const out = execFileSync('curl', ['-sS', '-m', String(seconds), '-K', '-'], { input: config, timeout: (seconds + 5) * 1000, stdio: ['pipe', 'pipe', 'pipe'] }).toString();
    let j = null;
    try { j = JSON.parse(out); } catch { /* reported below */ }
    if (j && j.success) return { ok: true, data: j.data };
    return { ok: false, why: String((j && j.error && (j.error.message || j.error)) || out).trim().slice(0, 300) };
  } catch (e) {
    const why = String((e.stderr && e.stderr.toString()) || e.message).trim().slice(0, 300);
    return { ok: false, why, timedOut: /timed out|Operation timed out|ETIMEDOUT|\(28\)/i.test(why) };
  }
}

/**
 * One Composio action for this tenant's connected account, the way
 * `orch-composio execute` does it. { ok, data } or { ok: false, why, timedOut }.
 */
function composio(slug, args, seconds = 60) {
  if (process.env.TABLES_FAKE_COMPOSIO === '1') return require('./composio').fake(slug, args);
  const r = post('/api/composio/execute', { toolSlug: slug, arguments: args }, seconds);
  if (!r.ok) return r;
  const d = r.data || {};
  if (d.successful === false || d.error) return { ok: false, why: String(d.error || 'Composio said it did not work').slice(0, 300) };
  return { ok: true, data: d.data !== undefined ? d.data : d };
}

// ── telling the owner ────────────────────────────────────────────────────
const TG_CHAT = /^(-?\d{5,20}|@[A-Za-z0-9_]{5,32})$/;
const sent = [];

/** One message from the instance's Telegram bot, to a chat it is set up for. */
function telegram(to, text) {
  const chat = String(to || '').trim();
  if (!chat) return { sent: false, why: 'No Telegram chat in Settings' };
  if (!TG_CHAT.test(chat)) return { sent: false, why: 'The Telegram chat in Settings is not a chat id or @username' };
  const message = String(text || '').slice(0, 3800);
  if (LOCAL || process.env.TABLES_FAKE_NOTIFY === '1') { sent.push({ telegram: chat, message }); return { sent: true, to: chat, fake: true, message }; }
  const r = post('/api/channels/telegram/notify', { to: chat, message });
  return r.ok ? { sent: true, to: chat } : { sent: false, to: chat, why: r.why };
}

/** "Tue 7 Oct, 21:00" in the restaurant's zone, for a notice. */
function said(iso, tz) {
  const d = toDate(iso);
  if (!d) return String(iso || '');
  return new Intl.DateTimeFormat('en-GB', { timeZone: C.validZone(tz), weekday: 'short', day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit', hourCycle: 'h23' }).format(d);
}

// ── starting another workflow ────────────────────────────────────────────
function workflowIds() {
  try { return JSON.parse(fs.readFileSync(path.join(__dirname, '..', 'workflows.json'), 'utf8')); } catch { return {}; }
}
const kicked = [];
/** Start one of Tables' workflows now (the ids install.js wrote). Locally it is recorded, not started. */
function kick(key, args = {}) {
  if (LOCAL || process.env.TABLES_FAKE_KICK === '1') { kicked.push({ workflow: key, args }); return { started: true, fake: true }; }
  const id = workflowIds()[key];
  if (!id) return { started: false, why: `No ${key} workflow recorded (install Tables again)` };
  const r = post(`/api/platform/workflows/${encodeURIComponent(id)}/run`, { execute: true, argsJson: JSON.stringify(args) });
  return r.ok ? { started: true } : { started: false, why: r.why };
}

/** Run an async main and print its one line; an exception is a failed step with its reason. */
function main(fn) {
  Promise.resolve().then(fn).then((out) => done(out)).catch((e) => { done({ ok: false, error: String(e && e.message || e).slice(0, 400) }); process.exitCode = 1; });
}

/** The one JSON line a workflow step leaves as its output. */
function done(result) {
  process.stdout.write(`${JSON.stringify(result)}\n`);
  return result;
}

module.exports = {
  PROJECT, DB_PATH, LOCAL, all, one, reread, settings, jsonOf, write, softDelete, lock,
  now, sqlNow, isoZ, toDate, identityHeaders, post, composio, telegram, sent, said, done,
  workflowIds, kick, kicked, main,
};
