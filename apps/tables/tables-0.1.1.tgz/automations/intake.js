'use strict';
/**
 * Tables · Take bookings. Everything that waits on a booking, judged through
 * the one door (seat.js), no agent:
 *
 *   New         from the public page, the desk (phone, walk-in) or an email:
 *               Discarded (bots, repeats), Failed (outside the rules, or full:
 *               with other times), Requested (a person approves) or Confirmed
 *               with its table. The guest's email is queued (it was asked for).
 *   Approving   the host pressed Approve: Confirmed, or back to Requested.
 *   pending     the host moved or edited a booking from the desk.
 *   tb_changes  what a guest did on their link: confirm, cancel, change.
 *   notice      a change the guest has to hear about (host cancelled,
 *               declined, moved): the email, queued.
 *   links       each booking's sealed page, rewritten when what the guest
 *               sees changed.
 *
 * Then the owner hears on Telegram about requests that wait, and Send starts
 * when an email is queued. One run at a time (a lock); the `when` on every
 * write (and the day's revision) is what keeps a table from going twice.
 *   node intake.js [--auto|--now] [--only <booking id>] [--dry-run]
 */
const crypto = require('crypto');
const L = require('./lib');
const C = require('./tablecore');
const S = require('./seat');

const BATCH = 100;

async function run(mode = '--auto', { only = null, dry = false } = {}) {
  const held = dry || only ? { release() {} } : L.lock('intake');
  if (!held) return { ok: true, mode, skipped: 'Another run is taking bookings' };
  const out = { ok: true, mode, judged: {}, approved: 0, moved: 0, changes: {}, notices: 0, links: 0, errors: [] };
  const tally = (o, k) => { o[k] = (o[k] || 0) + 1; };
  const requested = [];
  try {
    // ── New ──
    const fresh = only ? L.all("SELECT _id FROM tb_bookings WHERE _id = ? AND status = 'New' AND _deleted = 0", only)
      : L.all(`SELECT _id FROM tb_bookings WHERE _deleted = 0 AND status = 'New' ORDER BY _id LIMIT ${BATCH}`);
    for (const { _id } of fresh) {
      const r = S.settle(_id, (b, ctx) => (b.status === 'New' ? S.judgeNew(b, ctx) : null), { dry });
      if (!r) continue;
      if (r.error) { out.errors.push(`#${_id}: ${r.error}`); continue; }
      tally(out.judged, r.status);
      if (r.status === 'Requested') requested.push(_id);
    }
    if (only) return out;
    // ── Approve ──
    for (const { _id } of L.all("SELECT _id FROM tb_bookings WHERE _deleted = 0 AND status = 'Approving' ORDER BY _id")) {
      const r = S.settle(_id, (b, ctx) => (b.status === 'Approving' ? S.judgeApprove(b, ctx) : null), { dry });
      if (r && r.status === 'Confirmed' && !r.error) out.approved += 1;
    }
    // ── the host's moves and edits ──
    for (const { _id } of L.all("SELECT _id FROM tb_bookings WHERE _deleted = 0 AND COALESCE(pending, '') <> '' AND status <> 'New'")) {
      const r = S.settle(_id, (b, ctx) => {
        if (!b.pending) return null;
        const p = S.judgeChange(b, C.jsonOf(b.pending, {}), ctx, { when: { pending: b.pending } });
        if (p.status === 'Done') { p.ops[p.ops.length - 1].data = Object.assign(p.data, { pending: '', pending_note: '' }); return p; }
        return Object.assign(p, { ops: [{ op: 'update', table: 'tb_bookings', id: b._id, when: { pending: b.pending }, data: { pending: '', pending_note: p.why } }] });
      }, { dry });
      if (r && r.status === 'Done') out.moved += 1;
    }
    // ── the guests' links ──
    for (const ch of L.all("SELECT * FROM tb_changes WHERE _deleted = 0 AND status = 'New' ORDER BY _id LIMIT 100")) tally(out.changes, guestChange(ch, dry));
    // ── what the guest has to hear ──
    for (const { _id } of L.all("SELECT _id FROM tb_bookings WHERE _deleted = 0 AND COALESCE(notice, '') <> ''")) {
      const r = S.settle(_id, (b, ctx) => {
        if (!b.notice) return null;
        const kind = ['changed', 'cancelled', 'declined', 'confirmed'].includes(b.notice) ? b.notice : null;
        return { ops: [{ op: 'update', table: 'tb_bookings', id: b._id, when: { notice: b.notice }, data: { notice: '' } }, kind ? S.emailOp(kind, b, ctx.s) : null].filter(Boolean) };
      }, { dry });
      if (r && !r.error) out.notices += 1;
    }
    if (!dry) out.links = await links();
  } finally {
    held.release();
  }
  const s = L.settings();
  if (requested.length && s.notify_telegram && !dry) {
    const rows = L.all(`SELECT name, party, start_at, reason FROM tb_bookings WHERE _id IN (${requested.join(',')})`);
    out.telegram = L.telegram(s.notify_telegram, [`Tables: ${rows.length === 1 ? 'a booking waits' : `${rows.length} bookings wait`} for your OK`,
      ...rows.map((r) => `· ${r.name}, ${r.party} people, ${L.said(r.start_at, s.timezone)}: ${String(r.reason).replace(/^Needs your OK: /, '')}`),
      s.desk_url ? `Requests: ${s.desk_url}#/requests` : ''].filter(Boolean).join('\n'));
  }
  if (!dry && L.one("SELECT COUNT(*) AS n FROM tb_emails WHERE _deleted = 0 AND status = 'Approved'").n) out.send = L.kick('send');
  if (!out.errors.length) delete out.errors;
  return out;
}

/** One thing a guest did on their link. Returns Done, Rejected or Skipped. */
function guestChange(ch, dry) {
  let bookingId = null;
  const finish = (status, reason, offer) => {
    if (dry) return status;
    try {
      L.write([{ op: 'update', table: 'tb_changes', id: ch._id, when: { status: 'New' },
        data: { status, reason: reason || '', offer: offer && offer.length ? JSON.stringify(offer) : '', booking_id: bookingId, processed_at: L.sqlNow() } }]);
    } catch { return 'Skipped'; }
    return status;
  };
  if (String(ch.hp || '').trim() || (Number.isFinite(Number(ch.ms)) && Number(ch.ms) < 1000)) return finish('Rejected', 'Not sent by a person');
  if (!C.TOKEN.test(String(ch.token || ''))) return finish('Rejected', 'The link is not valid');
  const ref = L.one('SELECT _id FROM tb_bookings WHERE token = ? AND _deleted = 0', String(ch.token));
  if (!ref) return finish('Rejected', 'There is no booking with this link');
  bookingId = ref._id;
  const now = L.now().getTime();
  const r = S.settle(ref._id, (b, ctx) => {
    const done = { op: 'update', table: 'tb_changes', id: ch._id, when: { status: 'New' }, data: { status: 'Done', booking_id: b._id, processed_at: L.sqlNow() } };
    const live = ['Confirmed', 'Requested'].includes(b.status) && Date.parse(b.start_at) > now;
    if (ch.kind === 'confirm') {
      if (!live) return { status: 'Rejected', why: 'This booking is no longer open', ops: [] };
      return { status: 'Done', ops: [{ op: 'update', table: 'tb_bookings', id: b._id, when: { status: b.status }, data: { guest_confirmed_at: L.sqlNow() } }, done] };
    }
    if (ch.kind === 'cancel') {
      if (!live) return { status: 'Rejected', why: 'This booking is no longer open', ops: [] };
      return { status: 'Done', ops: [{ op: 'update', table: 'tb_bookings', id: b._id, when: { status: b.status },
        data: { status: 'Cancelled', cancelled_by: 'guest', decided_at: L.sqlNow(), notice: 'cancelled' } }, done] };
    }
    if (ch.kind === 'change') {
      const p = S.judgeChange(b, { party: ch.party, start_at: ch.start_at }, ctx, { guest: true, when: { status: b.status, start_at: b.start_at, party: b.party } });
      if (p.status !== 'Done') return p;
      if (ch.note) p.data.note = String(ch.note).slice(0, 500);
      if (p.data.notice !== 'changed' && b.status === 'Confirmed' && ch.note) p.data.notice = 'changed';
      return Object.assign(p, { ops: [...p.ops, done] });
    }
    return { status: 'Rejected', why: 'Unknown request', ops: [] };
  }, { dry });
  if (!r) return finish('Rejected', 'There is no booking with this link');
  if (r.error) return 'Skipped';
  if (r.status === 'Rejected') return finish('Rejected', r.why, r.offer);
  return 'Done';
}

const hashOf = (o) => crypto.createHash('sha256').update(JSON.stringify(o)).digest('hex').slice(0, 32);

/** Each booking's sealed page: written when it is missing or what the guest sees changed. */
async function links() {
  const s = L.settings();
  const rows = L.all(`SELECT b.*, l._id AS link_id, l.hash AS link_hash FROM tb_bookings b
    LEFT JOIN tb_links l ON l.booking_id = b._id AND l._deleted = 0
    WHERE b._deleted = 0 AND COALESCE(b.token, '') <> '' AND b.status <> 'New'
      AND (l._id IS NULL OR l.built_at <= b._updated_at
        OR EXISTS (SELECT 1 FROM tb_changes c WHERE c.booking_id = b._id AND c._deleted = 0 AND c._updated_at >= l.built_at))
    ORDER BY b._id LIMIT 300`);
  let n = 0;
  for (const b of rows) {
    const ch = L.one('SELECT kind, status, reason, offer, _id FROM tb_changes WHERE booking_id = ? AND _deleted = 0 ORDER BY _id DESC LIMIT 1', b._id);
    const snap = C.snapshot(b, s, {
      offer: C.jsonOf(b.offer, []),
      change: ch ? { id: ch._id, kind: ch.kind, status: ch.status, reason: ch.reason || '', offer: C.jsonOf(ch.offer, []) } : null,
    });
    const hash = hashOf(snap);
    if (hash === b.link_hash) {
      L.write([{ op: 'update', table: 'tb_links', id: b.link_id, data: { built_at: L.sqlNow() } }]);
      continue;
    }
    const data = { booking_id: b._id, k: await C.linkKey(b.token), box: await C.seal(b.token, snap), hash, built_at: L.sqlNow() };
    try {
      L.write([b.link_id ? { op: 'update', table: 'tb_links', id: b.link_id, data } : { op: 'insert', table: 'tb_links', data }]);
      n += 1;
    } catch { /* another run wrote it first */ }
  }
  return n;
}

if (require.main === module) {
  const argv = process.argv.slice(2);
  const i = argv.indexOf('--only');
  L.main(() => run(argv.includes('--now') ? '--now' : '--auto', { only: i >= 0 ? Number(argv[i + 1]) : null, dry: argv.includes('--dry-run') }));
}

module.exports = { run, links, guestChange };
