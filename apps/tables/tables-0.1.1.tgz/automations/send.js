'use strict';
/**
 * Tables · Send emails, from the business's Gmail (Composio), in plain text.
 *
 *   reminders  a Confirmed booking with an email, starting within Settings'
 *              reminder hours (24 by default) and more than two hours away,
 *              gets one reminder with its confirm / cancel link. Queued
 *              Approved: the guest asked for the booking.
 *   send       only Approved emails go: the ones the rules wrote (the guest
 *              booked, changed, cancelled; the reminder) and the ones a
 *              person approved (the agent's drafts wait in Review). Each is
 *              CLAIMED first (Approved → Sending, atomic), so none leaves
 *              twice; an answer in the guest's own thread goes as a reply.
 *              One left Sending (a run that died, Gmail silent) becomes
 *              Failed saying it may have gone out: never retried blind.
 *   --check    asks Gmail who is connected (Getting started), and notes it.
 *
 * Nothing is queued while emails are off (Settings), and bookings work the
 * same without them.
 *   node send.js [--auto|--now|--check] [--dry-run]
 */
const L = require('./lib');
const C = require('./tablecore');
const X = require('./composio');
const S = require('./seat');

const STALE_MIN = 15;

function readable(r) {
  if (r.notConnected) return `Gmail is not connected for this workspace: nothing went out. Connect it in Orchestra → Integrations, then send it again. (${String(r.why).slice(0, 160)})`;
  if (r.timedOut) return `Gmail did not answer in time, so it may or may not have gone out. Look in Gmail's Sent folder before sending again. (${String(r.why).slice(0, 160)})`;
  if (/invalid to|recipient|address/i.test(r.why || '')) return `The address was refused: nothing went out. Check it and send again. (${String(r.why).slice(0, 160)})`;
  return `Gmail did not take it: nothing went out. (${String(r.why || '').slice(0, 200)})`;
}

function check(s) {
  const r = X.profile(s);
  const data = { gmail_checked_at: L.sqlNow() };
  if (r.ok) Object.assign(data, { gmail_status: 'ok', gmail_account: r.address || s.gmail_account || '', gmail_note: '' });
  else Object.assign(data, { gmail_status: r.notConnected ? 'not_connected' : 'error', gmail_note: String(r.why || '').slice(0, 300) });
  L.write([{ op: 'update', table: 'tb_settings', id: s._id, data }]);
  return { ok: true, gmail: data.gmail_status, address: data.gmail_account || undefined, note: data.gmail_note || undefined };
}

/** One reminder per booking that starts within the reminder hours (and not within two). */
function reminders(s, dry) {
  if (s.emails_on !== 'yes') return 0;
  const now = L.now().getTime();
  const rows = L.all(`SELECT * FROM tb_bookings WHERE _deleted = 0 AND status = 'Confirmed' AND COALESCE(reminder_at, '') = ''
    AND COALESCE(email, '') <> '' AND start_at > ? AND start_at <= ? ORDER BY start_at LIMIT 100`,
  L.isoZ(new Date(now + 2 * 3600000)), L.isoZ(new Date(now + (Number(s.reminder_hours) || 24) * 3600000)));
  let n = 0;
  for (const b of rows) {
    const op = S.emailOp('reminder', b, s);
    if (!op || dry) { n += op ? 1 : 0; continue; }
    try { L.write([{ op: 'update', table: 'tb_bookings', id: b._id, when: { reminder_at: b.reminder_at }, data: { reminder_at: L.sqlNow() } }, op]); n += 1; } catch { /* taken meanwhile */ }
  }
  return n;
}

function run(mode = '--auto', { dry = false } = {}) {
  const s = L.settings();
  if (mode === '--check') return check(s);
  const held = dry ? { release() {} } : L.lock('send');
  if (!held) return { ok: true, mode, skipped: 'Another run is sending' };
  try {
    const out = { ok: true, mode, reminders: reminders(s, dry), sent: [], failed: [] };
    const stale = L.all(`SELECT _id FROM tb_emails WHERE _deleted = 0 AND status = 'Sending' AND datetime(lock_at) <= datetime(?, '-${STALE_MIN} minutes')`, L.sqlNow());
    if (stale.length && !dry) {
      L.write(stale.map((r) => ({ op: 'update', table: 'tb_emails', id: r._id, when: { status: 'Sending' },
        data: { status: 'Failed', error: 'The send did not finish, so it may or may not have gone out. Look in Gmail\'s Sent folder before sending again.' } })));
    }
    const queue = L.all("SELECT * FROM tb_emails WHERE _deleted = 0 AND status = 'Approved' ORDER BY _id LIMIT 30");
    if (dry) return Object.assign(out, { dry: true, wouldSend: queue.map((m) => ({ id: m._id, to: m.to_email, subject: m.subject })) });
    let disconnected = false;
    for (const m of queue) {
      const to = C.normEmail(m.to_email);
      const fail = (error, from) => { try { L.write([{ op: 'update', table: 'tb_emails', id: m._id, when: { status: from }, data: { status: 'Failed', error: error.slice(0, 500) } }]); } catch { /* moved on */ } out.failed.push({ id: m._id, error: error.slice(0, 120) }); };
      if (!C.isEmail(to) || !String(m.subject || '').trim() || !String(m.body || '').trim()) { fail('It has no valid address, subject or message: nothing went out. Fix it and send it again.', 'Approved'); continue; }
      if (disconnected) { fail(readable({ notConnected: true, why: 'not connected' }), 'Approved'); continue; }
      try { L.write([{ op: 'update', table: 'tb_emails', id: m._id, when: { status: 'Approved' }, data: { status: 'Sending', lock_at: L.sqlNow(), error: '' } }]); } catch { continue; }
      const r = m.thread_id ? X.reply(s, { threadId: m.thread_id, to, body: m.body }) : X.send(s, { to, subject: m.subject, body: m.body });
      if (!r.ok) {
        if (r.notConnected) disconnected = true;
        fail(readable(r), 'Sending');
        continue;
      }
      L.write([{ op: 'update', table: 'tb_emails', id: m._id, data: { status: 'Sent', sent_at: L.sqlNow(), gmail_id: r.id || '', thread_id: m.thread_id || r.threadId || '', error: '' } }]);
      out.sent.push({ id: m._id, kind: m.kind });
    }
    if (disconnected) L.write([{ op: 'update', table: 'tb_settings', id: s._id, data: { gmail_status: 'not_connected', gmail_checked_at: L.sqlNow() } }]);
    return out;
  } finally {
    held.release();
  }
}

if (require.main === module) {
  const argv = process.argv.slice(2);
  const mode = ['--now', '--check'].find((m) => argv.includes(m)) || '--auto';
  L.main(() => run(mode, { dry: argv.includes('--dry-run') }));
}

module.exports = { run, readable, reminders };
