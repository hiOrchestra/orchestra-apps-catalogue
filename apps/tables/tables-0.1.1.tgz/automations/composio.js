'use strict';
/**
 * Every call Tables makes to Composio, and nothing else: the Gmail of the
 * business (the account connected in Orchestra → Integrations). When Composio
 * renames an argument, this is the only file to change.
 *
 *   profile()                         GMAIL_GET_PROFILE       the connected address (the Getting started check)
 *   fetch({ query, max })             GMAIL_FETCH_EMAILS      messages, read only, with their text
 *   send({ to, subject, body })       GMAIL_SEND_EMAIL        one plain-text email
 *   reply({ threadId, to, body })     GMAIL_REPLY_TO_THREAD   an answer inside the guest's own thread
 *
 * Each returns { ok, data } or { ok: false, why, timedOut, notConnected }.
 * TABLES_FAKE_COMPOSIO=1 answers from TABLES_FAKE_DATA (a JSON file: {address,
 * messages: [...], fail: {SLUG: "why"}, timeout: {SLUG: true}}) and appends
 * every email "sent" to TABLES_FAKE_OUTBOX, one JSON a line.
 */
const fs = require('fs');
const L = require('./lib');

const SLUG = { profile: 'GMAIL_GET_PROFILE', fetch: 'GMAIL_FETCH_EMAILS', send: 'GMAIL_SEND_EMAIL', reply: 'GMAIL_REPLY_TO_THREAD' };
const NOT_CONNECTED = /no connected account|not connected|connection.*(not found|expired|revoked)|no active connection|ConnectedAccountNotFound/i;

const mark = (r) => (r.ok ? r : Object.assign(r, { notConnected: NOT_CONNECTED.test(String(r.why || '')) }));

/** The first value under `key` anywhere in a nested answer (Composio wraps answers differently per tool). */
function valueAt(obj, key, depth = 0) {
  if (!obj || typeof obj !== 'object' || depth > 5) return undefined;
  if (obj[key] !== undefined && obj[key] !== null && typeof obj[key] !== 'object') return obj[key];
  for (const v of Object.values(obj)) { const f = valueAt(v, key, depth + 1); if (f !== undefined) return f; }
  return undefined;
}
function arrayAt(obj, key, depth = 0) {
  if (!obj || typeof obj !== 'object' || depth > 4) return null;
  if (Array.isArray(obj[key])) return obj[key];
  for (const v of Object.values(obj)) { const f = arrayAt(v, key, depth + 1); if (f) return f; }
  return null;
}
const timeOf = (v) => {
  if (v === null || v === undefined || v === '') return null;
  const n = Number(v);
  const d = Number.isFinite(n) && String(v).trim() !== '' ? new Date(n < 1e12 ? n * 1000 : n) : new Date(String(v));
  return Number.isNaN(d.getTime()) ? null : d;
};

function profile(s) {
  const r = mark(L.composio(SLUG.profile, { user_id: 'me' }, 30));
  return r.ok ? { ok: true, address: String(valueAt(r.data, 'emailAddress') || valueAt(r.data, 'email_address') || '').toLowerCase() } : r;
}

/** Messages matching a Gmail query, newest first: [{ id, threadId, at, from, subject, text, labels }]. */
function fetch(s, { query, max = 25 }) {
  const r = mark(L.composio(SLUG.fetch, { user_id: 'me', query, max_results: max, include_payload: true, verbose: true }, 60));
  if (!r.ok) return r;
  const list = arrayAt(r.data, 'messages') || [];
  return {
    ok: true,
    messages: list.map((m) => ({
      id: String(m.messageId || m.id || ''), threadId: String(m.threadId || m.thread_id || ''),
      at: timeOf(m.messageTimestamp || m.internalDate || m.date),
      from: String(m.sender || m.from || ''), subject: String(m.subject || (m.preview && m.preview.subject) || ''),
      text: String(m.messageText || (m.preview && m.preview.body) || m.snippet || ''),
      labels: Array.isArray(m.labelIds) ? m.labelIds : [],
    })).filter((m) => m.id),
  };
}

function send(s, { to, subject, body }) {
  const r = mark(L.composio(SLUG.send, { user_id: 'me', recipient_email: to, subject, body, is_html: false }, 45));
  return r.ok ? { ok: true, id: String(valueAt(r.data, 'id') || ''), threadId: String(valueAt(r.data, 'threadId') || '') } : r;
}

function reply(s, { threadId, to, body }) {
  const r = mark(L.composio(SLUG.reply, { user_id: 'me', thread_id: threadId, recipient_email: to, message_body: body, is_html: false }, 45));
  return r.ok ? { ok: true, id: String(valueAt(r.data, 'id') || ''), threadId: String(valueAt(r.data, 'threadId') || threadId) } : r;
}

// ── the fake, for tests and the local harness ────────────────────────────
function fake(slug, args) {
  let d = {};
  try { d = JSON.parse(fs.readFileSync(process.env.TABLES_FAKE_DATA, 'utf8')); } catch { /* none */ }
  if (d.timeout && d.timeout[slug]) return { ok: false, why: 'Operation timed out after 45000 milliseconds (28)', timedOut: true };
  if (d.fail && d.fail[slug]) return { ok: false, why: d.fail[slug] };
  if (slug === SLUG.profile) return { ok: true, data: { response_data: { emailAddress: d.address || 'reservas@restaurant.example' } } };
  if (slug === SLUG.fetch) {
    const after = Number((String(args.query).match(/after:(\d+)/) || [])[1] || 0) * 1000;
    const all = (d.messages || []).filter((m) => Number(m.messageTimestamp) >= after).sort((a, b) => Number(b.messageTimestamp) - Number(a.messageTimestamp));
    return { ok: true, data: { messages: all.slice(0, Number(args.max_results) || 25) } };
  }
  if (slug === SLUG.send || slug === SLUG.reply) {
    const to = String(args.recipient_email || '');
    if (/^fail@/.test(to)) return { ok: false, why: 'Invalid To header (fake)' };
    if (/^timeout@/.test(to)) return { ok: false, why: 'Operation timed out (28)', timedOut: true };
    const id = `fake-${Math.random().toString(36).slice(2, 10)}`;
    if (process.env.TABLES_FAKE_OUTBOX) fs.appendFileSync(process.env.TABLES_FAKE_OUTBOX, `${JSON.stringify({ slug, ...args, id })}\n`);
    return { ok: true, data: { response_data: { id, threadId: args.thread_id || `th-${id}` } } };
  }
  return { ok: false, why: `fake Composio has no ${slug}` };
}

module.exports = { SLUG, NOT_CONNECTED, profile, fetch, send, reply, fake, valueAt, timeOf };
