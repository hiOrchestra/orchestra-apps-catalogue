'use strict';
/**
 * Tables · Offer times. Works out, for every start time of the coming days
 * (the services of each day, every interval, in Settings' zone, DST
 * included), which party sizes can still be seated: a table (or combo) free
 * for the whole stay, walk-in-only tables kept free, the service's cover cap,
 * the minimum notice. The public page reads only this (the view book_times):
 * a day, a time, and the sizes, never who booked.
 *
 * It rewrites tb_times by difference: rows still right stay, rows no longer
 * right are reused for times now needed, leftovers are deleted. Runs after
 * every booking (the second step of Take bookings), when settings, hours or
 * tables are saved, and every 30 minutes. It also sets when the next
 * pre-service brief is due (brief_next_at), so that check runs only then.
 *   node times.js [--auto|--now|--after-intake] [--dry-run]
 */
const L = require('./lib');
const C = require('./tablecore');
const S = require('./seat');

function wanted(ctx) {
  const { s, tz, now } = ctx;
  const today = C.localDay(now, tz);
  const days = Math.max(1, Math.min(180, Number(s.window_days) || 60));
  const soonest = now.getTime() + (Number(s.min_notice_min) || 0) * 60000;
  const books = L.all(`SELECT _id, party, start_at, end_at, table_ids, status, day, service FROM tb_bookings WHERE _deleted = 0
    AND status IN (${C.HOLDING.map((x) => `'${x}'`).join(',')}) AND end_at > ?`, L.isoZ(now));
  const taken = C.takenFrom(books);
  const out = new Map();
  for (let i = 0; i <= days; i += 1) {
    const day = C.addDays(today, i);
    for (const slot of C.startsOn(day, s, ctx.services, ctx.exceptions)) {
      const t = Date.parse(slot.start_at);
      if (t < soonest || t > now.getTime() + days * 86400000) continue;
      out.set(slot.start_at, { day, start_at: slot.start_at, time: slot.time, service: slot.service, sizes: C.sizesText(C.sizesAt(slot, s, ctx.tables, taken, books)) });
    }
  }
  return out;
}

/** When the next brief is due: today's brief time if it has not passed and today has none, else tomorrow's. */
function briefNext(ctx) {
  const { s, tz, now } = ctx;
  if (s.brief_on !== 'yes' || C.toMin(s.brief_time) === null) return '';
  const today = C.localDay(now, tz);
  for (const day of [today, C.addDays(today, 1)]) {
    const at = C.localToUtc(day, s.brief_time, tz);
    if (L.one('SELECT 1 AS x FROM tb_briefs WHERE day = ? AND _deleted = 0', day)) continue;
    if (day === today && at.getTime() + 6 * 3600000 < now.getTime()) continue; // a brief half a day late is no use
    return L.isoZ(at);
  }
  return '';
}

function run(mode = '--auto', { dry = false } = {}) {
  const held = dry ? { release() {} } : L.lock('times');
  if (!held) return { ok: true, mode, skipped: 'Another run is working out the times' };
  try {
    const ctx = S.context();
    const want = wanted(ctx);
    const open = [...want.values()].filter((x) => x.sizes).length;
    const have = L.all('SELECT _id, start_at, day, time, service, sizes FROM tb_times WHERE _deleted = 0 ORDER BY start_at');
    const at = L.sqlNow();
    const ops = [];
    const spare = [];
    for (const r of have) {
      const w = want.get(r.start_at);
      if (!w) { spare.push(r._id); continue; }
      if (w.sizes !== r.sizes || w.service !== r.service || w.day !== r.day || w.time !== r.time) ops.push({ op: 'update', table: 'tb_times', id: r._id, data: { ...w, built_at: at } });
      want.delete(r.start_at);
    }
    // Reuse a row that went stale for a time now needed; the unique start_at is freed first by moving it.
    for (const w of want.values()) {
      const id = spare.shift();
      ops.push(id ? { op: 'update', table: 'tb_times', id, data: { ...w, built_at: at } } : { op: 'insert', table: 'tb_times', data: { ...w, built_at: at } });
    }
    const note = !ctx.tables.length ? 'No tables yet: add them in Tables'
      : !ctx.services.length ? 'No service hours yet: add them in Settings'
        : `${open} start times with a free table`;
    const next = briefNext(ctx);
    const settings = { times_built_at: at, times_note: note };
    if (next !== (ctx.s.brief_next_at || '')) settings.brief_next_at = next;
    if (dry) return { ok: true, mode, dry: true, would: { update_or_insert: ops.length, remove: spare.length }, note };
    if (ops.length) L.write(ops);
    if (spare.length) L.softDelete('tb_times', spare); // only the rows no time needed
    L.write([{ op: 'update', table: 'tb_settings', id: ctx.s._id, data: settings }]);
    return { ok: true, mode, written: ops.length, removed: spare.length, open, note, brief_next_at: next || undefined };
  } finally {
    held.release();
  }
}

if (require.main === module) {
  const argv = process.argv.slice(2);
  const mode = ['--now', '--after-intake'].find((m) => argv.includes(m)) || '--auto';
  L.main(() => run(mode, { dry: argv.includes('--dry-run') }));
}

module.exports = { run, wanted, briefNext };
