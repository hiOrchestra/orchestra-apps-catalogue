'use strict';
/**
 * Tables · Service brief (optional: Settings → "Brief before service"). Once a
 * day at Settings' hour (brief_next_at, worked out by times.js), the facts of
 * the day — covers per service, large groups, allergies, VIPs, first visits,
 * guests who did not come before — and a few lines from the agent on what to
 * watch. The facts are the script's; the agent only writes words, as JSON.
 *
 *   node brief.js pick   claims the day (a tb_briefs row, unique per day) and
 *                        prints the facts
 *   node brief.js save   checks the agent's answer ($PRIOR) and saves it; if it
 *                        does not pass, the facts stay and the note says why
 */
const L = require('./lib');
const C = require('./tablecore');

const GROUP = 6;

function facts(day, s) {
  const tz = C.validZone(s.timezone || 'UTC');
  const rows = L.all(`SELECT b.*, g.vip AS g_vip, g.allergies AS g_allergies, g.notes AS g_notes,
      (SELECT COUNT(*) FROM tb_bookings x WHERE x.guest_id = b.guest_id AND x._deleted = 0 AND x.status = 'Arrived') + COALESCE(g.imported_visits, 0) AS visits,
      (SELECT COUNT(*) FROM tb_bookings x WHERE x.guest_id = b.guest_id AND x._deleted = 0 AND x.status = 'NoShow') AS no_shows
    FROM tb_bookings b LEFT JOIN tb_guests g ON g._id = b.guest_id
    WHERE b._deleted = 0 AND b.day = ? AND b.status IN ('Confirmed', 'Requested', 'Arrived') ORDER BY b.start_at`, day);
  const who = (b) => `${b.name} (${b.party}, ${C.localTime(new Date(b.start_at), tz)}${b.table_label ? `, ${b.table_label}` : ''})`;
  const services = {};
  for (const b of rows) { const k = b.service || 'Other'; services[k] = services[k] || { bookings: 0, covers: 0 }; services[k].bookings += 1; services[k].covers += Number(b.party) || 0; }
  return {
    day, services,
    groups: rows.filter((b) => b.party >= GROUP).map(who),
    allergies: rows.filter((b) => b.allergies || b.g_allergies).map((b) => `${who(b)}: ${[b.allergies, b.g_allergies].filter(Boolean).join('; ')}`),
    vips: rows.filter((b) => b.g_vip === 'yes').map(who),
    first_visits: rows.filter((b) => !Number(b.visits)).length,
    no_show_history: rows.filter((b) => Number(b.no_shows) > 0).map((b) => `${who(b)}: ${b.no_shows} no-show${b.no_shows > 1 ? 's' : ''} before`),
    notes: rows.filter((b) => b.note || b.g_notes).map((b) => `${who(b)}: ${[b.note, b.g_notes].filter(Boolean).join(' · ').slice(0, 200)}`),
    waiting_ok: rows.filter((b) => b.status === 'Requested').map(who),
  };
}

function pick() {
  const s = L.settings();
  const now = L.now();
  if (s.brief_on !== 'yes') return { skip: true, why: 'The service brief is off' };
  const due = L.toDate(s.brief_next_at);
  if (!due || due > now) return { skip: true, why: 'Not due yet' };
  const day = C.localDay(due, C.validZone(s.timezone || 'UTC'));
  const f = facts(day, s);
  try {
    L.write([{ op: 'insert', table: 'tb_briefs', data: { day, facts: JSON.stringify(f), status: 'Working', summary: '', watch: '[]' } },
      { op: 'update', table: 'tb_settings', id: s._id, data: { brief_next_at: '' } }]);
  } catch { return { skip: true, why: `The brief of ${day} is already made` }; }
  return { day, restaurant: s.business_name, facts: f };
}

function save() {
  let picked = {};
  try { picked = JSON.parse(String(process.env.STEP_pick || '').trim().split('\n').pop() || '{}'); } catch { picked = {}; }
  if (picked.skip || !picked.day) return { ok: true, skipped: 'Nothing was picked' };
  const row = L.one("SELECT * FROM tb_briefs WHERE day = ? AND _deleted = 0 AND status = 'Working'", picked.day);
  if (!row) return { ok: true, skipped: `The brief of ${picked.day} is not waiting` };
  const j = require('./mail').jsonIn(process.env.PRIOR);
  const summary = j && typeof j.summary === 'string' ? j.summary.trim().slice(0, 800) : '';
  const watch = j && Array.isArray(j.watch) ? j.watch.filter((x) => typeof x === 'string' && x.trim()).map((x) => x.trim().slice(0, 200)).slice(0, 6) : [];
  const ok = summary && !/https?:\/\//.test(summary);
  L.write([{ op: 'update', table: 'tb_briefs', id: row._id, when: { status: 'Working' },
    data: ok ? { summary, watch: JSON.stringify(watch), status: 'Done', note: '' } : { status: 'Done', note: 'The agent\'s words did not pass the checks: the facts are below' } }]);
  const s = L.settings();
  let telegram;
  if (s.notify_telegram) {
    const f = C.jsonOf(row.facts, {});
    const covers = Object.entries(f.services || {}).map(([k, v]) => `${k} ${v.covers}`).join(' · ');
    telegram = L.telegram(s.notify_telegram, [`Tables · ${picked.day}: ${covers || 'no bookings'}`, ok ? summary : '', ...watch.map((w) => `· ${w}`)].filter(Boolean).join('\n'));
  }
  return { ok: true, day: picked.day, saved: ok ? 'summary' : 'facts only', telegram };
}

if (require.main === module) {
  const cmd = process.argv[2];
  L.main(() => (cmd === 'pick' ? pick() : cmd === 'save' ? save() : { ok: false, error: 'node brief.js pick|save' }));
}

module.exports = { pick, save, facts };
