'use strict';
/**
 * Tables · the one door every booking goes through: the public page, a phone
 * booking or a walk-in from the desk, a booking the agent read in an email,
 * a guest's change from their link, and the host's Approve or Move. Each is
 * judged by the same rules (tablecore.check), seated by the same assigner
 * (tablecore.assign) and written in one transaction.
 *
 * Two guests asking for the last table at once: every write that gives a
 * table also moves its day's revision (tb_days.rev, a `when` on the number
 * read BEFORE the bookings were read). The second write fails as a whole,
 * the bookings are read again, and the second guest is judged against a
 * table that is now taken. The lock in intake.js only saves work.
 */
const L = require('./lib');
const C = require('./tablecore');

const ATTEMPTS = 4;

function context() {
  const s = L.settings();
  const tz = C.validZone(s.timezone || 'UTC');
  const today = C.localDay(L.now(), tz);
  return {
    s, tz, now: L.now(),
    services: L.all("SELECT * FROM tb_services WHERE _deleted = 0 AND COALESCE(active, 'yes') <> 'no' ORDER BY position, _id"),
    exceptions: L.all("SELECT * FROM tb_exceptions WHERE _deleted = 0 AND COALESCE(active, 'yes') <> 'no' AND day >= ?", C.addDays(today, -1)),
    tables: L.all("SELECT * FROM tb_tables WHERE _deleted = 0 AND COALESCE(active, 'yes') <> 'no'"),
  };
}

/** Bookings that hold a table around a time (±14 h), for seating and the cover cap. */
const around = (iso) => {
  const t = Date.parse(iso);
  return L.all(`SELECT _id, party, start_at, end_at, table_ids, status, day, service FROM tb_bookings WHERE _deleted = 0
    AND status IN (${C.HOLDING.map((x) => `'${x}'`).join(',')}) AND end_at > ? AND start_at < ?`, L.isoZ(new Date(t - 14 * 3600000)), L.isoZ(new Date(t + 14 * 3600000)));
};

/** The revision of each day, read first: the `when` that makes the last table go to one guest only. */
function revOps(days) {
  return [...new Set(days.filter(Boolean))].map((day) => {
    const r = L.one('SELECT _id, rev FROM tb_days WHERE day = ? AND _deleted = 0', day);
    return r ? { op: 'update', table: 'tb_days', id: r._id, when: { rev: r.rev }, data: { rev: (Number(r.rev) || 0) + 1 } }
      : { op: 'insert', table: 'tb_days', data: { day, rev: 1 } };
  });
}
const daysOf = (ctx, ...isos) => isos.filter(Boolean).map((x) => C.localDay(new Date(x), ctx.tz));

/** The guest this booking belongs to (by email, else phone), or a new one. */
function guestOps(b) {
  if (b.guest_id) return { id: b.guest_id, ops: [] };
  const email = C.normEmail(b.email);
  const pk = C.phoneKey(b.phone);
  let g = email ? L.one('SELECT * FROM tb_guests WHERE _deleted = 0 AND lower(email) = ? ORDER BY _id LIMIT 1', email) : null;
  if (!g && pk) g = L.one('SELECT * FROM tb_guests WHERE _deleted = 0 AND phone_key = ? ORDER BY _id LIMIT 1', pk);
  if (g) {
    const fill = {};
    if (!g.name && b.name) fill.name = b.name;
    if (!g.email && email) fill.email = email;
    if (!g.phone && b.phone) Object.assign(fill, { phone: b.phone, phone_key: pk });
    if (!g.allergies && b.allergies) fill.allergies = b.allergies;
    if (!g.first_source) Object.assign(fill, { first_source: b.source || 'web', first_src: b.src || '' });
    return { id: g._id, ops: Object.keys(fill).length ? [{ op: 'update', table: 'tb_guests', id: g._id, data: fill }] : [] };
  }
  if (!email && !pk && !b.name) return { id: null, ops: [] };
  return { id: '$g._id', ops: [{ op: 'insert', table: 'tb_guests', as: 'g', data: { name: b.name || '', email, phone: b.phone || '', phone_key: pk,
    allergies: b.allergies || '', notes: '', vip: 'no', lang: b.lang || '', imported_visits: 0, source: 'booking',
    first_source: b.source || 'web', first_src: b.src || '' } }] };
}

const linkFor = (s, token) => (s.public_url && token ? `${s.public_url}#/b/${token}` : '');
/** An email the guest asked for (they booked, changed, cancelled), from the rules' words: it goes out without review. */
function emailOp(kind, b, s, others) {
  if (s.emails_on !== 'yes' || !C.isEmail(b.email)) return null;
  const m = C.email(kind, b, s, { link: linkFor(s, b.token), page: s.public_url || '', others });
  return { op: 'insert', table: 'tb_emails', data: { booking_id: b._id, kind, to_email: C.normEmail(b.email), subject: m.subject, body: m.body,
    thread_id: b.mail_thread_id || '', status: 'Approved', drafted_by: 'rules', approved_by: 'rules', approved_at: L.sqlNow() } };
}

/** Other times the same day that seat this party, nearest first (for "full" and "taken just now"). */
function offerFor(ctx, day, party, wanted, except) {
  const opts = C.startsOn(day, ctx.s, ctx.services, ctx.exceptions).filter((o) => Date.parse(o.start_at) >= ctx.now.getTime() + (Number(ctx.s.min_notice_min) || 0) * 60000);
  if (!opts.length) return [];
  const books = around(opts[0].start_at).concat(around(opts[opts.length - 1].start_at)).filter((x) => Number(x._id) !== Number(except));
  const taken = C.takenFrom(books, except);
  const s = Object.assign({}, ctx.s, { max_online_party: Math.max(Number(ctx.s.max_online_party) || 8, Number(party) || 1) });
  return C.nearby(opts.map((o) => ({ ...o, sizes: C.sizesAt(o, s, ctx.tables, taken, books) })), wanted, party);
}

/** The service a host's booking falls in, by the local time: the one whose hours it is inside. */
function serviceAt(ctx, day, iso) {
  const t = C.toMin(C.localTime(new Date(iso), ctx.tz));
  const hit = C.servicesOn(day, ctx.services, ctx.exceptions).find((x) => t >= C.toMin(x.first) - 60 && t <= C.toMin(x.last) + 60);
  return hit ? hit.name : '';
}

/** Which unit to give: the host's pick, else the one already held (if still free), else the assigner's. */
function seatFor(ctx, b, { party, start, end, pick, keep, walkIn }) {
  const books = around(L.isoZ(new Date(start)));
  const taken = C.takenFrom(books, b._id);
  const opts = { walkIn: walkIn || b.source === 'walkin' };
  if (pick && pick !== 'auto') return { unit: C.candidates(ctx.tables, taken, party, start, end, { walkIn: true, only: pick })[0] || null, books, picked: true };
  if (keep) {
    const ids = String(keep).split(',').map(Number).filter(Boolean).sort((x, y) => x - y).join(',');
    const same = C.candidates(ctx.tables, taken, party, start, end, { walkIn: true }).find((u) => u.ids.join(',') === ids);
    if (same) return { unit: same, books };
  }
  return { unit: C.assign(ctx.tables, taken, party, start, end, opts), books };
}
const seatData = (u) => (u ? { table_ids: u.ids.join(','), table_label: u.label, area: u.area || '' } : { table_ids: '', table_label: '', area: '' });

const FLAG = {
  large: (b, s) => `A party of ${b.party} (online bookings go up to ${s.max_online_party || 8})`,
  special: () => 'The guest marked it as a special request', review: () => 'Settings ask you to approve every booking',
};

/**
 * A New booking, judged. Returns { ops, status, why } or null when it is not
 * New any more. Bots and repeats are Discarded; outside the rules it is
 * Failed (with other times) or Requested (a person approves); otherwise
 * Confirmed with its table.
 */
function judgeNew(b, ctx) {
  const { s } = ctx;
  const web = !b.source || b.source === 'web';
  const host = C.HOST_SOURCES.includes(b.source);
  const at = L.sqlNow();
  // The guest's insert goes first: the booking names it ($g._id).
  const end = (data, extra = []) => ({ ops: [...extra.filter((o) => o.table === 'tb_guests'), { op: 'update', table: 'tb_bookings', id: b._id, when: { status: 'New' }, data: Object.assign({ processed_at: at }, data) },
    ...extra.filter((o) => o.table !== 'tb_guests')], status: data.status, why: data.reason || '' });
  if (web) {
    if (String(b.hp || '').trim()) return end({ status: 'Discarded', reason: 'A field only bots see was filled' });
    if (Number.isFinite(Number(b.ms)) && Number(b.ms) < 3000) return end({ status: 'Discarded', reason: 'Sent in under 3 seconds' });
    if (b.visit && L.one("SELECT _id FROM tb_bookings WHERE visit = ? AND _id <> ? AND _deleted = 0 AND status NOT IN ('New', 'Discarded') LIMIT 1", String(b.visit), b._id)) return end({ status: 'Discarded', reason: 'Sent twice from the same page' });
    const hour = L.isoZ(new Date(ctx.now.getTime() - 3600000)).replace('T', ' ').slice(0, 19);
    if (C.normEmail(b.email) && L.one("SELECT COUNT(*) AS n FROM tb_bookings WHERE _deleted = 0 AND lower(email) = ? AND _id < ? AND COALESCE(source, 'web') = 'web' AND status NOT IN ('Discarded') AND _created_at >= ?", C.normEmail(b.email), b._id, hour).n >= 3) {
      return end({ status: 'Discarded', reason: 'More than three bookings from one address in an hour' });
    }
    if (!C.TOKEN.test(String(b.token || ''))) return end({ status: 'Discarded', reason: 'The page sent no link token' });
  }
  const name = String(b.name || '').trim().slice(0, 120);
  const email = C.normEmail(b.email);
  if (!name && !host) return end({ status: 'Failed', reason: 'There is no name' });
  if (web && !C.isEmail(email)) return end({ status: 'Failed', reason: 'The email address is not valid' });
  if (web && s.paused === 'yes') return end({ status: 'Failed', reason: 'Bookings are paused' });
  const d = new Date(b.start_at || ctx.now);
  if (Number.isNaN(d.getTime())) return end({ status: 'Failed', reason: 'There is no time' });
  const startIso = L.isoZ(new Date(Math.floor(d.getTime() / 60000) * 60000));
  const party = Number(b.party);
  const c = C.check({ start_at: startIso, party, special: b.special, source: b.source }, ctx);
  const day = c.slot ? c.slot.day : C.localDay(new Date(startIso), ctx.tz);
  const stay = C.stayFor(s, party);
  const start = Date.parse(startIso);
  const endIso = L.isoZ(new Date(start + stay * 60000));
  const token = b.token || C.newToken();
  const base = { name, email, phone: C.normPhone(b.phone), party, start_at: startIso, end_at: endIso, day, token, source: b.source || 'web', src: b.source === 'market' ? C.srcOf(b.src) : C.srcOf(b.src).toLowerCase(),
    service: c.slot ? c.slot.service : serviceAt(ctx, day, startIso), lang: b.lang === 'en' ? 'en' : (b.lang === 'es' ? 'es' : (s.default_lang || 'es')) };
  if (!c.ok) {
    const offer = c.problems.some((p) => ['time', 'notice'].includes(p)) && Number.isInteger(party) ? offerFor(ctx, day, party, startIso) : [];
    return end(Object.assign(base, { status: 'Failed', reason: C.problemText(c.problems), offer: JSON.stringify(offer) }));
  }
  const revs = revOps(daysOf(ctx, startIso, endIso));
  const seat = seatFor(ctx, b, { party, start, end: start + stay * 60000, pick: b.pending && C.jsonOf(b.pending, {}).table });
  let unit = seat.unit;
  if (unit && web && c.slot && c.slot.max_covers && C.coversIn(seat.books, day, c.slot.service) + party > c.slot.max_covers) unit = null;
  const row = Object.assign({}, b, base);
  const g = guestOps(row);
  if (c.flags.length) {
    const why = `Needs your OK: ${c.flags.map((f) => FLAG[f](row, s)).join('; ')}`;
    const data = Object.assign(base, seatData(unit), { status: 'Requested', reason: why, flags: c.flags.join(','), guest_id: g.id, pending: '' });
    return end(data, [...(unit ? revs : []), ...g.ops, emailOp('requested', Object.assign(row, data), s)].filter(Boolean));
  }
  if (!unit) {
    if (seat.picked) return end(Object.assign(base, { status: 'Failed', reason: 'That table is taken at that time: pick another', pending: '' }));
    const offer = web || b.source === 'email' ? offerFor(ctx, day, party, startIso) : [];
    return end(Object.assign(base, { status: 'Failed', reason: `No table free for ${party} at that time`, offer: JSON.stringify(offer) }));
  }
  const data = Object.assign(base, seatData(unit), { status: 'Confirmed', reason: '', guest_id: g.id, pending: '' });
  const mail = b.source === 'walkin' ? null : emailOp('confirmed', Object.assign(row, data), s);
  return end(data, [...revs, ...g.ops, mail].filter(Boolean));
}

/** The host pressed Approve: the tentative table if it is still free, else the assigner's; none, and it waits again. */
function judgeApprove(b, ctx) {
  const start = Date.parse(b.start_at);
  const seat = seatFor(ctx, b, { party: Number(b.party), start, end: Date.parse(b.end_at), keep: b.table_ids });
  if (!seat.unit) {
    return { status: 'Requested', why: 'No table free', ops: [{ op: 'update', table: 'tb_bookings', id: b._id, when: { status: 'Approving' },
      data: { status: 'Requested', reason: 'No table is free at that time: move it to a table first, then approve' } }] };
  }
  const data = Object.assign(seatData(seat.unit), { status: 'Confirmed', reason: '', flags: '', decided_at: L.sqlNow() });
  return { status: 'Confirmed', ops: [...revOps(daysOf(ctx, b.start_at, b.end_at)),
    { op: 'update', table: 'tb_bookings', id: b._id, when: { status: 'Approving' }, data }, emailOp('confirmed', Object.assign({}, b, data), ctx.s)].filter(Boolean) };
}

/**
 * A change to a booking that has a table: the host's (Move, Edit: no limits
 * but a free table) or the guest's from their link (inside the rules, before
 * Settings' hours of notice, up to the online party size).
 *   change = { party?, start_at?, table? ('auto' or a unit key) }
 * Returns { ops, status: 'Done' | 'Rejected', why, data }.
 */
function judgeChange(b, change, ctx, { guest = false, when }) {
  const party = change.party ? Number(change.party) : Number(b.party);
  const startIso = change.start_at ? L.isoZ(new Date(change.start_at)) : b.start_at;
  const reject = (why, offer = []) => ({ status: 'Rejected', why, offer, ops: [] });
  if (!['Confirmed', 'Requested'].includes(b.status) && !(b.status === 'Arrived' && !guest)) return reject('This booking can no longer be changed');
  if (Number.isNaN(Date.parse(startIso))) return reject('That is not a time');
  if (guest && ctx.now.getTime() > C.changeUntil(b, ctx.s)) return reject(`It is too close to the time to change it online: call us${ctx.s.phone ? ` on ${ctx.s.phone}` : ''}`);
  const c = C.check({ start_at: startIso, party, source: guest ? 'web' : 'desk' }, ctx);
  const day = c.slot ? c.slot.day : C.localDay(new Date(startIso), ctx.tz);
  if (!c.ok) return reject(C.problemText(c.problems), c.problems.includes('time') ? offerFor(ctx, day, party, startIso, b._id) : []);
  if (guest && c.flags.includes('large')) return reject(`For more than ${ctx.s.max_online_party || 8} people, call us${ctx.s.phone ? ` on ${ctx.s.phone}` : ''}`);
  const start = Date.parse(startIso);
  const end = start + C.stayFor(ctx.s, party) * 60000;
  const seat = seatFor(ctx, b, { party, start, end, pick: change.table, keep: b.table_ids });
  if (!seat.unit) return reject(change.table && change.table !== 'auto' ? 'That table is taken at that time' : `No table free for ${party} at that time`, offerFor(ctx, day, party, startIso, b._id));
  const data = Object.assign(seatData(seat.unit), { party, start_at: startIso, end_at: L.isoZ(new Date(end)), day,
    service: c.slot ? c.slot.service : serviceAt(ctx, day, startIso) });
  const moved = data.start_at !== b.start_at || Number(data.party) !== Number(b.party);
  if (moved && b.status === 'Confirmed') data.notice = 'changed';
  if (moved) data.reminder_at = '';
  return { status: 'Done', data, ops: [...revOps(daysOf(ctx, b.start_at, startIso, data.end_at)),
    { op: 'update', table: 'tb_bookings', id: b._id, when, data }] };
}

const pause = () => { const ms = Number(process.env.TABLES_TEST_PAUSE_MS) || 0; if (ms) Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, ms); };

/**
 * Plan, write, and on a lost race read everything again and plan again. `plan`
 * gets the booking as it is now and returns { ops, … } or null (nothing to do).
 */
function settle(id, plan, { dry = false } = {}) {
  for (let i = 0; i < ATTEMPTS; i += 1) {
    L.reread();
    const b = L.one('SELECT * FROM tb_bookings WHERE _id = ? AND _deleted = 0', id);
    if (!b) return null;
    const p = plan(b, context());
    if (!p) return null;
    if (dry) return Object.assign(p, { dry: true });
    pause();
    try {
      L.write(p.ops);
      return p;
    } catch (e) {
      if (!/precondition|changed meanwhile|UNIQUE|constraint/i.test(e.message) || i === ATTEMPTS - 1) return Object.assign({}, p, { error: e.message.slice(0, 300) });
    }
  }
  return null;
}

module.exports = { context, around, revOps, guestOps, emailOp, offerFor, seatFor, seatData, judgeNew, judgeApprove, judgeChange, settle, linkFor };
