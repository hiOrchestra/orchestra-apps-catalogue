SELECT substr(b.day, 1, 7) AS month,
       COALESCE(NULLIF(b.source, ''), 'web') AS source,
       COALESCE(b.src, '') AS src,
       COUNT(*) AS bookings,
       SUM(b.party) AS covers
FROM tb_bookings b
WHERE b.status IN ('Confirmed', 'Arrived')
GROUP BY substr(b.day, 1, 7), COALESCE(NULLIF(b.source, ''), 'web'), COALESCE(b.src, '')
