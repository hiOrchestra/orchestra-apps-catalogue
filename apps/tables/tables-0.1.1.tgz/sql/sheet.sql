SELECT b._id, b.day, b.start_at, b.end_at, b.service, b.name, b.email, b.phone, b.party, b.table_ids, b.table_label, b.area,
       b.status, b.source, b.src, b.note, b.allergies, b.special, b.reason, b.flags, b.pending, b.pending_note, b.lang, b.guest_id,
       b.guest_confirmed_at, b.arrived_at, b.cancelled_by, b._created_at,
       COALESCE(g.vip, 'no') AS vip, COALESCE(g.allergies, '') AS guest_allergies, COALESCE(g.notes, '') AS guest_notes,
       g.first_source, g.first_src,
       COALESCE(g.imported_visits, 0) + (SELECT COUNT(*) FROM tb_bookings x WHERE x.guest_id = b.guest_id AND x.status = 'Arrived') AS visits,
       (SELECT COUNT(*) FROM tb_bookings x WHERE x.guest_id = b.guest_id AND x.status = 'NoShow') AS no_shows
FROM tb_bookings b
LEFT JOIN tb_guests g ON g._id = b.guest_id
