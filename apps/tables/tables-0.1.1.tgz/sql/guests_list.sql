SELECT g._id, g.name, g.email, g.phone, COALESCE(g.vip, 'no') AS vip, g.allergies, g.notes, g.first_source, g.first_src, g._created_at,
       COALESCE(g.imported_visits, 0) + (SELECT COUNT(*) FROM tb_bookings b WHERE b.guest_id = g._id AND b.status = 'Arrived') AS visits,
       (SELECT COUNT(*) FROM tb_bookings b WHERE b.guest_id = g._id AND b.status = 'NoShow') AS no_shows,
       (SELECT MAX(b.day) FROM tb_bookings b WHERE b.guest_id = g._id AND b.status = 'Arrived') AS last_visit,
       (SELECT MIN(b.day) FROM tb_bookings b WHERE b.guest_id = g._id AND b.status IN ('Confirmed', 'Requested')
          AND b.start_at > strftime('%Y-%m-%dT%H:%M:%SZ', 'now')) AS next_visit,
       CASE WHEN g.first_source = 'market' AND EXISTS (SELECT 1 FROM tb_bookings b WHERE b.guest_id = g._id
          AND COALESCE(b.source, 'web') <> 'market' AND b.status IN ('Confirmed', 'Arrived')) THEN 'yes' ELSE 'no' END AS recovered
FROM tb_guests g
