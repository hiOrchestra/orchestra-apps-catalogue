SELECT b.day,
       COUNT(*) AS bookings,
       SUM(b.party) AS covers,
       SUM(CASE WHEN b.status = 'Requested' THEN 1 ELSE 0 END) AS waiting,
       SUM(CASE WHEN b.party >= 6 THEN 1 ELSE 0 END) AS groups,
       SUM(CASE WHEN COALESCE(b.allergies, '') <> '' THEN 1 ELSE 0 END) AS allergies
FROM tb_bookings b
WHERE b.status IN ('Requested', 'Approving', 'Confirmed', 'Arrived')
GROUP BY b.day
