// One booking, in a side panel: who, when, how many, the table, where it came
// from, the guest's history, notes and allergies; and what the host can do:
// Arrived / No-show, approve or decline a request, move it (another table, time
// or party size: the instance checks the table is free), edit the notes, and
// cancel (two steps, naming what else happens).
import { A, C, T, V, act, badge, code, dayName, field, hm, input, plural, publicLink, select, settings, sheet, sourceLabel, statusWord, twoStep, tz, waitFor } from '../data.js';

const { el, fmt } = Orch;

export async function openBooking(id, again) {
  const [s, list, changes, tables] = await Promise.all([
    settings(), Orch.db.view(V.sheet, { filter: { _id: id }, limit: 1 }), Orch.db.list(T.changes, { filter: { booking_id: id }, sort: '_id:desc', limit: 5 }),
    Orch.db.list(T.tables, { filter: { active: 'yes' }, sort: 'position:asc', limit: 200 }),
  ]);
  const b = (list.rows || [])[0];
  if (!b) { Orch.toast('That booking is not there any more.', { error: true }); return; }
  const raw = await Orch.db.get(T.bookings, id);
  const body = el('div', { class: 'oc-stack tb-panel' });
  const d = sheet(body, { title: b.name || 'Walk-in', drawer: true });
  const done = () => { d.close(); again(); };
  const facts = [
    ['When', `${dayName(b.day)}, ${hm(b.start_at)} – ${hm(b.end_at)}`],
    ['People', String(b.party)],
    ['Table', b.table_label ? `${b.table_label}${b.area ? ` · ${b.area}` : ''}` : 'None yet'],
    ['Status', [badge(b.status), b.reason ? el('span', { class: 'tb-sub tb-panel__why' }, ` ${b.reason}`) : null]],
    ['Came from', sourceLabel(b)],
    ['Contact', [b.phone ? el('a', { href: `tel:${b.phone}` }, b.phone) : null, b.phone && b.email ? ' · ' : '', b.email ? el('a', { href: `mailto:${b.email}` }, b.email) : null]],
    ['Guest', [Number(b.visits) ? plural(b.visits, 'visit', 'visits') : 'First visit', Number(b.no_shows) ? ` · ${plural(b.no_shows, 'no-show', 'no-shows')}` : '',
      b.vip === 'yes' ? ' · VIP' : '', b.first_source ? ` · first came via ${C.sourceLabel(b.first_source, b.first_src)}` : '']],
    b.note || b.guest_notes ? ['Notes', [b.note, b.guest_notes].filter(Boolean).join(' · ')] : null,
    b.allergies || b.guest_allergies ? ['Allergies', el('span', { class: 'tb-row__allergy' }, [b.allergies, b.guest_allergies].filter(Boolean).join('; '))] : null,
    b.guest_confirmed_at ? ['Guest confirmed', fmt.ago(b.guest_confirmed_at)] : null,
  ].filter(Boolean);
  body.append(...[
    el('dl', { class: 'oc-dl' }, facts.map(([k, v]) => el('div', { class: 'oc-dl__row' }, [el('dt', k), el('dd', v)]))),
    b.pending_note ? el('div', { class: 'tb-notice tb-notice--bad' }, `The last move did not happen: ${b.pending_note}`) : null,
    ...changes.rows.map((c) => el('p', { class: 'oc-help' }, `The guest asked to ${c.kind} from their link ${fmt.ago(c._created_at)}: ${statusWord(c.status) === 'Done' ? 'done' : `${String(c.status).toLowerCase()}${c.reason ? ` (${c.reason})` : ''}`}.`)),
    el('div', { class: 'oc-row tb-panel__acts' }, actions(b, s, done)),
  ].filter(Boolean));
  if (['Confirmed', 'Requested', 'Arrived'].includes(b.status)) body.append(moveForm(b, s, tables.rows || [], done));
  body.append(editForm(b, done));
  if (raw && raw.token && !['Discarded'].includes(b.status)) body.append(el('div', { class: 'oc-stack oc-stack--tight' }, [el('span', { class: 'oc-label' }, 'The guest\'s page (confirm, change, cancel)'), code(`${publicLink(s)}#/b/${raw.token}`)]));
  if (b.status === 'Confirmed') {
    const mail = s.emails_on === 'yes' && b.email;
    body.append(el('div', { class: 'tb-panel__danger' }, twoStep({
      label: 'Cancel booking', yes: 'Cancel the booking', what: `Cancel the booking${b.name ? ` of ${b.name}` : ''} for ${b.party}, ${dayName(b.day, true)} at ${hm(b.start_at)}?`,
      collateral: [`${b.table_label || 'The table'} is free again for that time.`, mail ? `${b.name} gets an email saying it is cancelled (${b.email}).` : 'Nobody is told: there is no email to write to, or emails are off. Call them if needed.',
        'Their page shows it as cancelled.'],
      run: async () => { if (await act(A.cancel, { id: b._id, reason: 'Cancelled by the restaurant' }, 'Cancelled.')) done(); },
    })));
  }
}

function actions(b, s, done) {
  const btn = (label, name, said, cls = '') => el('button', { type: 'button', class: `oc-btn ${cls}`, onClick: async () => { if (await act(name, { id: b._id }, said)) done(); } }, label);
  if (b.status === 'Confirmed') return [btn('Arrived', A.arrive, 'Arrived.', 'oc-btn--primary'), btn('No-show', A.noShow, 'Marked as no-show.', 'oc-btn--ghost')];
  if (b.status === 'Arrived') return [btn('Undo arrived', A.undoArrive, 'Back to booked.', 'oc-btn--ghost')];
  if (b.status === 'NoShow') return [btn('Undo no-show', A.undoNoShow, 'Back to booked.', 'oc-btn--ghost')];
  if (b.status === 'Requested') return requestActions(b, s, done);
  return [];
}

/** Approve (it gets a table and the guest is told) or Decline (two steps: the guest is told). */
export function requestActions(b, s, done) {
  const mail = s.emails_on === 'yes' && b.email;
  const approve = el('button', { type: 'button', class: 'oc-btn oc-btn--primary' }, 'Approve');
  approve.addEventListener('click', async () => {
    approve.disabled = true;
    if (!(await act(A.approve, { id: b._id }))) { approve.disabled = false; return; }
    const x = await waitFor(b._id, (r) => r.status !== 'Approving');
    if (x && x.status === 'Confirmed') Orch.toast(`Confirmed at ${x.table_label}${mail ? `; ${b.name} gets the confirmation` : ''}.`);
    else Orch.toast(x && x.reason ? x.reason : 'It is still being approved.', { error: x && x.status === 'Requested' });
    done();
  });
  return [approve, twoStep({
    label: 'Decline', yes: 'Decline it', what: `Decline ${b.name}'s request for ${b.party}?`,
    collateral: [mail ? `${b.name} gets an email saying you cannot take it, with your page to book another time.` : 'Nobody is told: call them if needed.', b.table_label ? `${b.table_label} is free again.` : null],
    run: async () => { if (await act(A.decline, { id: b._id, reason: 'Declined by the restaurant' }, 'Declined.')) done(); },
  })];
}

/** Another table, time or party size. The instance checks the table is free; the guest is told when the time or the size changed. */
function moveForm(b, s, tables, done) {
  const party = input({ type: 'number', min: '1', max: String(C.MAX_PARTY), value: String(b.party), class: 'oc-input tb-num' });
  const time = input({ type: 'time', value: hm(b.start_at) });
  const units = C.units(tables);
  const table = select([['auto', 'Keep it, or the best free one'], ...units.map((u) => [u.key, `${u.label}${u.area ? ` · ${u.area}` : ''} · ${u.min}–${u.max}`])], 'auto');
  const out = el('p', { class: 'tb-result', role: 'status' });
  const save = el('button', { type: 'submit', class: 'oc-btn' }, 'Move');
  const f = el('form', { class: 'oc-stack tb-move' }, [
    el('span', { class: 'oc-label' }, 'Move or change'),
    el('div', { class: 'tb-movegrid' }, [field('People', party), field('Time', time), field('Table', table)]),
    out, el('div', { class: 'oc-row' }, save),
  ]);
  f.addEventListener('submit', async (e) => {
    e.preventDefault();
    const change = { table: table.value };
    if (Number(party.value) !== Number(b.party)) change.party = Number(party.value);
    if (time.value && time.value !== hm(b.start_at)) change.start_at = C.isoZ(C.localToUtc(b.day, time.value, tz()));
    save.disabled = true;
    out.textContent = 'Checking the table…';
    if (!(await act(A.move, { id: b._id, pending: JSON.stringify(change) }))) { save.disabled = false; out.textContent = ''; return; }
    const x = await waitFor(b._id, (r) => !r.pending);
    save.disabled = false;
    if (x && x.pending_note) { out.className = 'tb-result tb-result--bad'; out.textContent = `Not moved: ${x.pending_note}`; return; }
    Orch.toast(x ? `Now at ${x.table_label}, ${hm(x.start_at)}, ${x.party} people.` : 'Moving…');
    done();
  });
  return f;
}

function editForm(b, done) {
  const note = el('textarea', { class: 'oc-textarea', rows: '2', maxlength: '500' }, b.note || '');
  const allergies = input({ value: b.allergies || '', maxlength: '300' });
  const phone = input({ type: 'tel', value: b.phone || '', maxlength: '30' });
  const save = el('button', { type: 'submit', class: 'oc-btn oc-btn--ghost' }, 'Save notes');
  const f = el('form', { class: 'oc-stack tb-move' }, [field('Note for the floor', note), el('div', { class: 'tb-two-col' }, [field('Allergies', allergies), field('Phone', phone)]), el('div', { class: 'oc-row' }, save)]);
  f.addEventListener('submit', async (e) => {
    e.preventDefault();
    if (await act(A.edit, { id: b._id, note: note.value.trim(), allergies: allergies.value.trim(), phone: phone.value.trim() }, 'Saved.')) done();
  });
  return f;
}
