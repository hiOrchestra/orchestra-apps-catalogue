// A walk-in and a phone booking: one button, one short form, one Save. The
// instance seats them through the same door as the page (the smallest free
// table that fits; walk-ins may take walk-in-only tables), and the form waits
// for the answer: the table it got, or why not, with the form still filled.
import { A, C, T, act, dayName, field, input, nowIso, select, sheet, tz, waitFor } from '../data.js';

const { el } = Orch;

/** 1 … 8 as buttons, and a box for more. */
function partyPicker(initial = 2) {
  let value = initial;
  const box = input({ type: 'number', min: '1', max: String(C.MAX_PARTY), value: String(initial), class: 'oc-input tb-num', 'aria-label': 'People' });
  const chips = [1, 2, 3, 4, 5, 6, 7, 8].map((n) => el('button', { type: 'button', class: 'tb-chip', 'aria-pressed': String(n === initial), onClick: () => set(n) }, String(n)));
  const listeners = [];
  function set(n) {
    value = n;
    box.value = String(n);
    chips.forEach((c, i) => c.setAttribute('aria-pressed', String(i + 1 === n)));
    listeners.forEach((f) => f(n));
  }
  box.addEventListener('input', () => { const n = Number(box.value); if (n >= 1) { value = n; chips.forEach((c, i) => c.setAttribute('aria-pressed', String(i + 1 === n))); listeners.forEach((f) => f(n)); } });
  return { node: el('div', { class: 'tb-chips', role: 'group', 'aria-label': 'People' }, [...chips, box]), get: () => value, on: (f) => listeners.push(f) };
}

/** Free tables for a party now (walk-ins), from today's bookings: the best first. */
async function freeNow(party, s) {
  const [tables, books] = await Promise.all([
    Orch.db.list(T.tables, { filter: { active: 'yes' }, limit: 200 }),
    Orch.db.list(T.bookings, { filter: { status: C.HOLDING, end_at: { gt: nowIso() } }, limit: 500 }),
  ]);
  const start = Date.now();
  return C.candidates(tables.rows || [], C.takenFrom(books.rows || []), party, start, start + C.stayFor(s, party) * 60000, { walkIn: true });
}

const result = () => el('p', { class: 'tb-result', role: 'status', 'aria-live': 'polite' });

async function send(params, out, save, okWord) {
  save.disabled = true;
  out.className = 'tb-result';
  out.textContent = 'Finding a table…';
  const r = await act(A.add, params);
  if (!r || !r._id) { save.disabled = false; out.textContent = ''; return null; }
  const b = await waitFor(r._id, (x) => x.status !== 'New');
  save.disabled = false;
  if (!b || b.status === 'New') { out.textContent = 'Still being seated: it appears on the sheet in a moment.'; return b; }
  if (['Confirmed', 'Requested'].includes(b.status)) {
    out.className = 'tb-result tb-result--good';
    out.textContent = okWord(b);
    return b;
  }
  out.className = 'tb-result tb-result--bad';
  out.textContent = `Not booked: ${b.reason || 'no table free'}. Change the time or the table and save again.`;
  return null;
}

export function walkIn(s, again) {
  const party = partyPicker(2);
  const name = input({ maxlength: '120', placeholder: 'Optional' });
  const table = select([['auto', 'The best free table']], 'auto');
  const fill = async () => {
    const list = await freeNow(party.get(), s);
    table.replaceChildren(el('option', { value: 'auto' }, list.length ? 'The best free table' : 'No table free for that many'), ...list.map((u) => el('option', { value: u.key }, `${u.label} · ${u.area || ''} · up to ${u.max}`)));
  };
  party.on(fill);
  fill();
  const out = result();
  const save = el('button', { type: 'submit', class: 'oc-btn oc-btn--primary' }, 'Seat them');
  const f = el('form', { class: 'oc-stack tb-add' }, [field('People', party.node), field('Name', name), field('Table', table), out, el('div', { class: 'oc-row oc-row--end' }, save)]);
  const d = sheet(f, { title: 'Walk-in' });
  f.addEventListener('submit', async (e) => {
    e.preventDefault();
    const b = await send({ name: name.value.trim(), party: party.get(), start_at: nowIso(), source: 'walkin', pending: table.value === 'auto' ? '' : JSON.stringify({ table: table.value }) },
      out, save, (x) => `Seated at ${x.table_label}.`);
    if (b) setTimeout(() => { d.close(); again(); }, 900);
  });
}

export async function phoneBooking(s, day, again) {
  const markets = String(s.marketplaces || '').split(',').map((x) => x.trim()).filter(Boolean);
  const party = partyPicker(2);
  const date = input({ type: 'date', value: day, required: true });
  const time = select([], '');
  const other = input({ type: 'time', 'aria-label': 'Another time' });
  const name = input({ maxlength: '120', required: true, autocomplete: 'off' });
  const phone = input({ type: 'tel', maxlength: '30' });
  const email = input({ type: 'email', maxlength: '200', placeholder: 'For the confirmation email' });
  const note = input({ maxlength: '500', placeholder: 'Birthday, high chair, terrace…' });
  const allergies = input({ maxlength: '300' });
  const source = select([['phone', 'Phone'], ...markets.map((m) => [`market:${m}`, m]), ['market:Other', 'Other marketplace']], 'phone');
  const times = async () => {
    const r = await Orch.db.list(T.times, { filter: { day: date.value }, sort: 'start_at:asc', limit: 200 });
    const p = party.get();
    const rows = r.rows || [];
    time.replaceChildren(...(rows.length ? rows.map((x) => el('option', { value: x.time }, `${x.time}${C.sizesOf(x).includes(p) ? '' : ' · full for that many'}`))
      : [el('option', { value: '' }, 'No times that day: write one')]));
    const first = rows.find((x) => C.sizesOf(x).includes(p));
    if (first) time.value = first.time;
  };
  date.addEventListener('change', times);
  party.on(times);
  await times();
  const out = result();
  const save = el('button', { type: 'submit', class: 'oc-btn oc-btn--primary' }, 'Book it');
  const f = el('form', { class: 'oc-stack tb-add' }, [
    field('People', party.node),
    el('div', { class: 'tb-two-col' }, [field('Day', date), field('Time', el('div', { class: 'oc-row tb-time' }, [time, other]), 'Or write another time.')]),
    el('div', { class: 'tb-two-col' }, [field('Name', name), field('Phone', phone)]),
    el('div', { class: 'tb-two-col' }, [field('Email', email), field('Booked through', source)]),
    el('div', { class: 'tb-two-col' }, [field('Note', note), field('Allergies', allergies)]),
    out, el('div', { class: 'oc-row oc-row--end' }, save),
  ]);
  const d = sheet(f, { title: 'Phone booking' });
  f.addEventListener('submit', async (e) => {
    e.preventDefault();
    const at = other.value || time.value;
    if (!C.realDay(date.value) || C.toMin(at) === null) { out.textContent = 'Pick a day and a time.'; return; }
    const [src, market] = source.value.split(':');
    const b = await send({ name: name.value.trim(), phone: phone.value.trim(), email: email.value.trim(), party: party.get(), note: note.value.trim(), allergies: allergies.value.trim(),
      start_at: C.isoZ(C.localToUtc(date.value, at, tz())), source: src, src: market || '', lang: s.default_lang || 'es' },
    out, save, (x) => (x.status === 'Confirmed' ? `Booked: ${dayName(x.day, true)}, ${at}, ${x.party} people at ${x.table_label}.` : `Saved, but it waits for your OK: ${x.reason}`));
    if (b) setTimeout(() => { d.close(); again(); }, 1200);
  });
}
