// The tables, by area: a simple list, no floor plan. Each has a name, an area,
// the fewest and most people it seats, whether it joins others (tables with
// the same "joins with" name are pushed together for big groups), whether it
// is kept for walk-ins, and a priority (higher is offered first at the same
// size). Every change works out the free times again.
import { A, T, act, field, head, input, select, twoStep } from '../data.js';

const { el } = Orch;

export function render() {
  Orch.load('view', async () => {
    const r = await Orch.db.list(T.tables, { filter: { active: 'yes' }, sort: 'position:asc', limit: 300 });
    const rows = r.rows || [];
    const areas = [...new Set(rows.map((t) => t.area || 'No area'))];
    const host = el('div', { class: 'oc-stack' });
    const add = el('button', { type: 'button', class: 'oc-btn oc-btn--primary' }, 'Add a table');
    add.addEventListener('click', () => { host.prepend(form(null, rows.length + 1, areas, () => render())); add.disabled = true; });
    const seats = rows.reduce((n, t) => n + (Number(t.max_seats) || 0), 0);
    host.append(...areas.map((a) => el('section', { class: 'oc-card oc-card--pad0' }, [
      el('h2', { class: 'oc-eyebrow tb-group' }, [a, el('span', { class: 'tb-group__n' }, `${rows.filter((t) => (t.area || 'No area') === a).reduce((n, t) => n + (Number(t.max_seats) || 0), 0)} seats`)]),
      el('ul', { class: 'tb-rows' }, rows.filter((t) => (t.area || 'No area') === a).map((t) => row(t, areas))),
    ])));
    return el('div', { class: 'oc-stack oc-stack--loose' }, [
      head('Tables', rows.length ? `${rows.length} tables, ${seats} seats. Each booking gets the smallest free table that fits.` : 'Add your tables: each booking gets the smallest free table that fits.', [add]),
      rows.length ? null : el('div', { class: 'oc-card oc-state' }, [el('p', { class: 'oc-state__title' }, 'No tables yet.'), el('p', { class: 'oc-help' }, 'Nothing can be booked until there is at least one. Add them here, or with the quick form in Getting started (Today).')]),
      host,
    ]);
  });
}

function row(t, areas) {
  const li = el('li', { class: 'tb-row' });
  const facts = [t.combine ? `joins with ${t.combine}` : '', t.walk_in_only === 'yes' ? 'walk-ins only' : '', Number(t.priority) ? `priority ${t.priority}` : ''].filter(Boolean).join(' · ');
  const open = el('button', { type: 'button', class: 'tb-row__open tb-row__open--table', 'aria-expanded': 'false' }, [
    el('span', { class: 'oc-value tb-row__time' }, t.name),
    el('span', { class: 'tb-row__who' }, [el('span', { class: 'tb-row__name' }, `${t.min_seats === t.max_seats ? t.max_seats : `${t.min_seats}–${t.max_seats}`} people`), facts ? el('span', { class: 'tb-sub' }, facts) : null]),
    el('span', { class: 'oc-muted' }, 'Edit'),
  ]);
  open.addEventListener('click', () => {
    const shown = li.querySelector('form');
    if (shown) { shown.remove(); open.setAttribute('aria-expanded', 'false'); return; }
    open.setAttribute('aria-expanded', 'true');
    li.append(form(t, t.position, areas, () => render()));
  });
  li.append(open);
  return li;
}

function form(t, position, areas, done) {
  const v = t || { name: '', area: areas[0] === 'No area' ? '' : areas[0] || '', min_seats: 1, max_seats: 4, combine: '', walk_in_only: 'no', priority: 0 };
  const c = {
    name: input({ value: v.name, maxlength: '20', required: true }),
    area: input({ value: v.area || '', maxlength: '30', list: 'tb-areas' }),
    min_seats: input({ type: 'number', min: '1', max: '60', value: v.min_seats, class: 'oc-input tb-num' }),
    max_seats: input({ type: 'number', min: '1', max: '60', value: v.max_seats, class: 'oc-input tb-num' }),
    combine: input({ value: v.combine || '', maxlength: '20', placeholder: 'Empty: on its own' }),
    walk_in_only: select([['no', 'No'], ['yes', 'Yes: never online']], v.walk_in_only),
    priority: input({ type: 'number', min: '0', max: '9', value: v.priority || 0, class: 'oc-input tb-num' }),
  };
  const f = el('form', { class: 'oc-stack tb-tableform' }, [
    el('datalist', { id: 'tb-areas' }, areas.filter((a) => a !== 'No area').map((a) => el('option', { value: a }))),
    el('div', { class: 'tb-four' }, [field('Name', c.name), field('Area', c.area), field('Fewest', c.min_seats), field('Most', c.max_seats)]),
    el('div', { class: 'tb-three' }, [field('Joins with', c.combine, 'Tables with the same name here are pushed together for big groups.'),
      field('Walk-ins only', c.walk_in_only, 'Kept free for people who come without booking.'), field('Priority', c.priority, '0–9: higher is offered first at the same size.')]),
    el('div', { class: 'oc-row' }, [el('button', { type: 'submit', class: 'oc-btn oc-btn--primary' }, t ? 'Save' : 'Add'),
      el('button', { type: 'button', class: 'oc-btn oc-btn--ghost', onClick: done }, 'Close'),
      t ? twoStep({ label: 'Remove table', yes: 'Remove it', what: `Remove ${t.name}?`, collateral: ['Bookings already at this table keep it.', 'New bookings will not be given it, and the free times are worked out again.'],
        run: async () => { if (await act(A.retireTable, { id: t._id }, `${t.name} removed.`)) done(); } }) : null]),
  ]);
  f.addEventListener('submit', async (e) => {
    e.preventDefault();
    const p = { name: c.name.value.trim(), area: c.area.value.trim(), min_seats: Number(c.min_seats.value), max_seats: Number(c.max_seats.value), combine: c.combine.value.trim(),
      walk_in_only: c.walk_in_only.value, priority: Number(c.priority.value) || 0, position: Number(position) || 0 };
    if (!p.name) { Orch.toast('Give the table a name.', { error: true }); return; }
    if (!(p.min_seats >= 1 && p.max_seats >= p.min_seats)) { Orch.toast('The most people must be at least the fewest.', { error: true }); return; }
    if (await act(t ? A.updateTable : A.createTable, t ? { id: t._id, ...p } : p, t ? 'Saved.' : `${p.name} added.`)) done();
  });
  return f;
}
