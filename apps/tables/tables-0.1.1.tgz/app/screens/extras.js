// Emails to guests, and the optional extras. Emails go from the restaurant's
// own Gmail (connected in Orchestra → Integrations): the confirmation, the
// reminder before the visit (with confirm / cancel), and a note when
// something changes. Bookings work the same without them. The extras are off
// until turned on: the agent reading booking emails in that inbox (inside the
// rules it books; anything else waits as a draft for you), and a brief
// before each service.
import { A, INTEGRATIONS, act, field, input, select, settings } from '../data.js';

const { el, fmt } = Orch;

export function extrasCard(s, again) {
  const gmail = { ok: `Connected: ${s.gmail_account || 'Gmail answers'}.`, not_connected: 'Not connected: this workspace has no Gmail in Orchestra yet.', error: `Gmail answered with an error. ${s.gmail_note || ''}` }[s.gmail_status] || 'Not checked yet.';
  const check = el('button', { type: 'button', class: 'oc-btn oc-btn--sm' }, 'Check Gmail');
  check.addEventListener('click', async () => {
    check.disabled = true;
    const before = s.gmail_checked_at || '';
    if (!(await act(A.checkGmail, {}, 'Asking Gmail…'))) { check.disabled = false; return; }
    for (let i = 0; i < 20; i += 1) { await new Promise((r) => { setTimeout(r, 2000); }); if (((await settings()).gmail_checked_at || '') !== before) break; }
    again();
  });
  const c = {
    emails_on: select([['no', 'Off: no emails to guests'], ['yes', 'On: confirmation, reminder and changes']], s.emails_on || 'no'),
    mail_on: select([['no', 'Off'], ['yes', 'On: the agent reads booking emails']], s.mail_on || 'no'),
    brief_on: select([['no', 'Off'], ['yes', 'On: a brief before each day\'s service']], s.brief_on || 'no'),
    brief_time: input({ type: 'time', value: s.brief_time || '11:00' }),
    agent: input({ value: s.agent || '', maxlength: '60', placeholder: 'The project\'s agent' }),
  };
  const save = el('button', { type: 'submit', class: 'oc-btn oc-btn--primary' }, 'Save');
  const f = el('form', { class: 'oc-stack tb-form' }, [
    el('div', { class: 'tb-gmail' }, [el('p', { class: `tb-gmail__state${s.gmail_status && s.gmail_status !== 'ok' ? ' tb-gmail__state--bad' : ''}` },
      [gmail, s.gmail_checked_at ? ` Checked ${fmt.ago(s.gmail_checked_at)}.` : '']), el('div', { class: 'oc-row' }, [s.gmail_status === 'ok' ? null : el('a', { class: 'oc-btn oc-btn--sm', href: INTEGRATIONS, target: '_top' }, 'Connect Gmail'), check])]),
    field('Emails to guests', c.emails_on, 'They go because the guest booked: the confirmation with their link, a reminder about a day before with confirm or cancel, and a note when you change or cancel it.'),
    el('h3', { class: 'oc-h3' }, 'Optional extras'),
    field('Booking emails', c.mail_on, 'The agent reads new emails about bookings in that inbox. Inside your rules it books, changes or cancels, and the guest gets the usual email. Anything else becomes a draft reply in Requests that waits for you. Needs emails to guests on.'),
    el('div', { class: 'tb-two-col' }, [field('Brief before service', c.brief_on, 'Groups, allergies, VIPs and a few lines from the agent, on Today and on Telegram.'), field('At', c.brief_time)]),
    field('Agent', c.agent, 'Who reads the emails and writes the brief. It contacts nobody and writes nothing itself.'),
    el('div', { class: 'oc-row' }, save),
  ]);
  f.addEventListener('submit', async (e) => {
    e.preventDefault();
    const p = { id: s._id };
    for (const [k, n] of Object.entries(c)) p[k] = String(n.value).trim();
    if (p.emails_on === 'yes' && s.gmail_status !== 'ok') { Orch.toast('Connect Gmail and check it first: emails go from it.', { error: true }); return; }
    if (p.mail_on === 'yes' && p.emails_on !== 'yes') { Orch.toast('Booking emails need emails to guests on: the agent answers in the guest\'s thread.', { error: true }); return; }
    if ((p.mail_on === 'yes' || p.brief_on === 'yes') && !p.agent) { Orch.toast('Name the agent that does it.', { error: true }); return; }
    if (p.emails_on === 'yes' && s.emails_on !== 'yes' && !(await Orch.confirm('Turn on emails to guests? From now on every booking with an email gets its confirmation, and a reminder the day before, from your Gmail.', { yes: 'Turn them on' }))) return;
    save.disabled = true;
    if (await act(A.extras, p, 'Saved.')) again();
    save.disabled = false;
  });
  const tg = input({ value: s.notify_telegram || '', maxlength: '40', placeholder: '@channel or chat id' });
  const tgf = el('form', { class: 'oc-row tb-tg' }, [field('Telegram', tg, 'Where you hear about bookings that wait for your OK, and the brief.'), el('button', { type: 'submit', class: 'oc-btn oc-btn--sm' }, 'Save')]);
  tgf.addEventListener('submit', async (e) => { e.preventDefault(); if (await act(A.settings, { id: s._id, notify_telegram: tg.value.trim() }, 'Saved.')) again(); });
  return el('section', { class: 'oc-card oc-stack' }, [el('h2', { class: 'oc-h2' }, 'Emails and extras'), f, tgf]);
}
