// Settings, one card per thing: the booking page (its link, one link per
// channel, pause), the restaurant, the hours (hours.js), the booking rules,
// emails and the optional extras (extras.js), and sources. Each card saves on
// its own; saving works out the free times again.
import { A, C, act, code, field, head, input, publicLink, select, settings, zoneSelect } from '../data.js';
import { hoursCard } from './hours.js';
import { extrasCard } from './extras.js';

const { el, fmt } = Orch;

export function render() {
  Orch.load('view', async () => {
    const s = await settings();
    if (!s._id) return el('p', { class: 'oc-state' }, 'Tables is not installed in this project.');
    return el('div', { class: 'oc-stack oc-stack--loose tb-settings' }, [
      head('Settings', 'How bookings work for your restaurant.'),
      page(s), restaurant(s), await hoursCard(s, render), rules(s), extrasCard(s, render), sources(s),
    ]);
  });
}

function card(title, help, kids) {
  return el('section', { class: 'oc-card oc-stack' }, [el('h2', { class: 'oc-h2' }, title), help ? el('p', { class: 'oc-help tb-legible' }, help) : null, ...kids]);
}

/** A form that saves the listed controls with one action. */
function saver(s, action, controls, said, check) {
  const save = el('button', { type: 'submit', class: 'oc-btn oc-btn--primary' }, 'Save');
  const f = el('form', { class: 'oc-stack tb-form' });
  f.addEventListener('submit', async (e) => {
    e.preventDefault();
    const params = { id: s._id };
    for (const [k, node] of Object.entries(controls)) params[k] = node.type === 'number' || k === 'interval_min' ? Number(node.value) : (node.value === undefined ? node.get() : String(node.value).trim());
    if (check) { const why = check(params); if (why) { Orch.toast(why, { error: true }); return; } }
    save.disabled = true;
    if (await act(action, params, said || 'Saved.')) render();
    save.disabled = false;
  });
  return { f, save };
}

function page(s) {
  const paused = s.paused === 'yes';
  const b = el('button', { type: 'button', class: `oc-btn${paused ? ' oc-btn--primary' : ''}`, onClick: async () => {
    if (!paused && !(await Orch.confirm('Pause online bookings? Your page stops offering times at once. Bookings already made are not touched, and you can still add phone bookings.', { yes: 'Pause' }))) return;
    if (await act(paused ? A.resume : A.pause, { id: s._id }, paused ? 'Resumed: the times are back on your page in a moment.' : 'Paused: the page offers no times.')) render();
  } }, paused ? 'Resume online bookings' : 'Pause online bookings');
  const channels = String(s.channels || '').split(',').map((x) => C.srcOf(x).toLowerCase()).filter(Boolean);
  return card('Your booking page', 'Put it on Instagram, Google Maps and your website. Guests pick a day, how many they are and a time; inside your rules the table is theirs at once.', [
    el('div', { class: 'oc-row oc-row--between' }, [el('span', { class: 'oc-label' }, 'The link'), el('span', { class: `oc-badge${paused ? ' oc-badge--warn' : ' oc-badge--good'}` }, paused ? 'Paused' : 'Taking bookings')]),
    code(publicLink(s)),
    channels.length ? el('div', { class: 'oc-stack oc-stack--tight' }, [
      el('span', { class: 'oc-label' }, 'One link per channel'),
      el('p', { class: 'oc-help' }, 'The same page; each booking remembers which link it came from, so Sources can tell you which channel brings guests.'),
      ...channels.map((c) => el('div', { class: 'tb-channel' }, [el('span', { class: 'oc-value tb-channel__name' }, c), code(publicLink(s, c))])),
    ]) : null,
    s.times_note ? el('p', { class: 'oc-help' }, `${s.times_note}${s.times_built_at ? ` · worked out ${fmt.ago(s.times_built_at)}` : ''}.`) : null,
    el('div', { class: 'oc-row' }, b),
  ]);
}

function restaurant(s) {
  const c = {
    business_name: input({ value: s.business_name || '', maxlength: '80' }), phone: input({ type: 'tel', value: s.phone || '', maxlength: '30' }),
    address: input({ value: s.address || '', maxlength: '160' }), intro: el('textarea', { class: 'oc-textarea', rows: '2', maxlength: '400' }, s.intro || ''),
    timezone: zoneSelect(s.timezone || 'Europe/Madrid'), languages: select([['es,en', 'Spanish and English'], ['es', 'Spanish'], ['en', 'English']], s.languages || 'es,en'),
    default_lang: select([['es', 'Spanish'], ['en', 'English']], s.default_lang || 'es'),
  };
  const { f, save } = saver(s, A.settings, c);
  f.append(el('div', { class: 'tb-two-col' }, [field('Name', c.business_name, 'On the page and in every email.'), field('Phone', c.phone, 'Guests who need to call see it.')]),
    field('Address', c.address, 'In the confirmation, so guests know where to go.'), field('A line on the page', c.intro, 'Optional: the dress code, a terrace note, how long tables are kept.'),
    el('div', { class: 'tb-three' }, [field('Time zone', c.timezone), field('Page languages', c.languages), field('Language by default', c.default_lang, 'For guests whose language is not known.')]), el('div', { class: 'oc-row' }, save));
  return card('The restaurant', null, [f]);
}

function rules(s) {
  const stay = C.jsonOf(s.stay_rules, []).map((r) => ({ min: Number(r.min), minutes: Number(r.minutes) }));
  const stays = [0, 1, 2].map((i) => ({ min: input({ type: 'number', min: '1', max: '60', value: stay[i] ? stay[i].min : '', class: 'oc-input tb-num', 'aria-label': 'From people' }),
    minutes: input({ type: 'number', min: '30', max: '480', step: '15', value: stay[i] ? stay[i].minutes : '', class: 'oc-input tb-num', 'aria-label': 'Minutes' }) }));
  const stayValue = { get: () => JSON.stringify(stays.map((x) => ({ min: Number(x.min.value), minutes: Number(x.minutes.value) })).filter((x) => x.min > 0 && x.minutes > 0)) };
  const c = {
    interval_min: select([['15', 'Every 15 minutes'], ['30', 'Every 30 minutes'], ['60', 'Every hour']], String(s.interval_min || 15)),
    default_stay_min: input({ type: 'number', min: '30', max: '480', step: '15', value: s.default_stay_min || 90, class: 'oc-input tb-num' }),
    stay_rules: stayValue,
    max_online_party: input({ type: 'number', min: '1', max: '60', value: s.max_online_party || 8, class: 'oc-input tb-num' }),
    min_notice_min: input({ type: 'number', min: '0', max: '10080', step: '15', value: s.min_notice_min ?? 60, class: 'oc-input tb-num' }),
    window_days: input({ type: 'number', min: '1', max: '180', value: s.window_days || 60, class: 'oc-input tb-num' }),
    change_notice_hours: input({ type: 'number', min: '0', max: '72', value: s.change_notice_hours ?? 2, class: 'oc-input tb-num' }),
    policy: select([['auto', 'On their own, inside the rules'], ['review', 'Only with my OK']], s.policy || 'auto'),
  };
  const { f, save } = saver(s, A.settings, c, 'Saved. The free times are being worked out again.', (p) => (p.max_online_party < 1 ? 'Online bookings need at least 1 person.' : null));
  f.append(
    el('div', { class: 'tb-three' }, [field('Start times', c.interval_min), field('Most people online', c.max_online_party, 'Larger groups can still ask: it waits for your OK.'), field('Bookings confirm', c.policy)]),
    el('div', { class: 'oc-stack oc-stack--tight' }, [el('span', { class: 'oc-label' }, 'How long a table is kept (minutes)'),
      el('div', { class: 'tb-stays' }, [el('span', 'Usually'), c.default_stay_min, ...stays.flatMap((x) => [el('span', 'from'), x.min, el('span', 'people:'), x.minutes])]),
      el('p', { class: 'oc-help' }, 'Bigger parties stay longer: from that many people, the table is kept that long.')]),
    el('div', { class: 'tb-three' }, [field('Minimum notice (minutes)', c.min_notice_min, 'How soon before the time a guest can still book online.'), field('Days ahead', c.window_days, 'How far ahead the page offers times.'),
      field('Changes up to (hours before)', c.change_notice_hours, 'Until then guests can change or cancel from their link; after, they call.')]),
    el('div', { class: 'oc-row' }, save));
  return card('Booking rules', 'Inside these a booking is confirmed at once; outside them it is refused (too soon, closed) or waits for your OK (a large group).', [f]);
}

function sources(s) {
  const c = {
    channels: input({ value: s.channels || '', maxlength: '200', placeholder: 'instagram, google, web' }), marketplaces: input({ value: s.marketplaces || '', maxlength: '200', placeholder: 'TheFork' }),
    market_fee: input({ type: 'number', min: '0', max: '50', step: '0.05', value: s.market_fee ?? 2.5, class: 'oc-input tb-num' }), currency: select([['EUR', 'EUR'], ['USD', 'USD'], ['GBP', 'GBP'], ['MXN', 'MXN'], ['COP', 'COP'], ['ARS', 'ARS'], ['CLP', 'CLP']], s.currency || 'EUR'),
  };
  const { f, save } = saver(s, A.settings, c);
  f.append(field('Channels', c.channels, 'Separated by commas. Each gets its own link above.'), field('Marketplaces you also use', c.marketplaces, 'Separated by commas. A phone booking can be marked as coming from one of them.'),
    el('div', { class: 'tb-two-col' }, [field('Your marketplace\'s fee per cover', c.market_fee, 'What a marketplace charges you per guest; Sources uses it to estimate what booking direct saves.'), field('Currency', c.currency)]),
    el('div', { class: 'oc-row' }, save));
  return card('Sources', null, [f]);
}
