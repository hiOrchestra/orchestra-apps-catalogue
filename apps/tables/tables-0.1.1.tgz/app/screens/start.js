// Getting started, on top of Today until done and hidden: 1. the restaurant
// and its hours, 2. the tables (a quick set), 3. emails to guests (optional).
// Each step is checked from the data every time it draws, never ticked by hand.
import { A, INTEGRATIONS, T, act, browserZone, code, field, input, publicLink, settings, zoneSelect } from '../data.js';

const { el, router, fmt } = Orch;
const DAYS = [['mon', 'Mon'], ['tue', 'Tue'], ['wed', 'Wed'], ['thu', 'Thu'], ['fri', 'Fri'], ['sat', 'Sat'], ['sun', 'Sun']];

export async function startData() {
  const [services, tables] = await Promise.all([
    Orch.db.list(T.services, { filter: { active: 'yes' }, sort: 'position:asc', limit: 50 }),
    Orch.db.count(T.tables, { filter: { active: 'yes' } }),
  ]);
  return { services: services.rows || [], tables: Number(tables) || 0 };
}

export function steps(s, d) {
  return [
    { id: 'hours', title: 'Your restaurant and its hours', done: Boolean(String(s.business_name || '').trim()) && d.services.length > 0 },
    { id: 'tables', title: 'Your tables', done: d.tables > 0 },
    { id: 'emails', title: 'Emails to guests', done: s.emails_on === 'yes' && s.gmail_status === 'ok', optional: true },
  ];
}

export function startPanel(s, d, again) {
  if (!d || s.onboarding_dismissed_at) return null;
  const list = steps(s, d);
  const needed = list.filter((x) => !x.optional);
  if (needed.every((x) => x.done)) {
    return el('section', { class: 'oc-card tb-start tb-start--done', 'aria-label': 'Getting started' }, [
      el('div', { class: 'tb-start__line' }, [
        el('span', { class: 'oc-eyebrow' }, 'Getting started · done'),
        el('p', { class: 'tb-start__said' }, list[2].done ? 'Your booking page is live, and guests get their emails.' : 'Your booking page is live. Emails to guests are optional: turn them on in Settings when Gmail is connected.'),
        code(publicLink(s)),
        el('button', { type: 'button', class: 'oc-btn oc-btn--sm oc-btn--ghost', onClick: async () => { if (await act(A.dismissStart, { id: s._id })) again(); } }, 'Hide this'),
      ]),
    ]);
  }
  let open = (list.find((x) => !x.done) || list[0]).id;
  const host = el('ol', { class: 'tb-steps' });
  const draw = () => host.replaceChildren(...list.map((x, i) => step(x, i, x.id === open, () => { open = open === x.id ? '' : x.id; draw(); }, s, d, again)));
  draw();
  return el('section', { class: 'oc-card oc-card--pad0 tb-start', 'aria-label': 'Getting started' }, [
    el('header', { class: 'tb-start__head' }, [el('h2', { class: 'oc-h2' }, 'Getting started'), el('span', { class: 'oc-eyebrow' }, `${needed.filter((x) => x.done).length} of ${needed.length} done`)]),
    el('p', { class: 'oc-help tb-start__lede' }, 'Two steps before guests can book a table on your page, and one more if you want them to get emails. Each ticks itself when it is done.'),
    host,
  ]);
}

const WHY = {
  hours: 'Guests can only pick times inside your services. Exceptions (a holiday, a closed day) go in Settings later.',
  tables: 'Each booking gets the smallest free table that fits. You can name them, set their area and which ones join for big groups in Tables.',
  emails: 'Guests get a confirmation, a reminder the day before with a link to confirm or cancel, and a note when something changes, from your own Gmail. Bookings work without it.',
};

function step(x, i, isOpen, toggle, s, d, again) {
  return el('li', { class: `tb-step${x.done ? ' tb-step--done' : ''}` }, [
    el('button', { type: 'button', class: 'tb-step__head', 'aria-expanded': String(isOpen), onClick: toggle }, [
      el('span', { class: 'oc-value tb-step__n' }, String(i + 1).padStart(2, '0')),
      el('span', { class: 'tb-step__title' }, x.title),
      el('span', { class: `oc-badge${x.done ? ' oc-badge--good' : ''}` }, x.done ? 'Done' : x.optional ? 'Optional' : 'To do'),
    ]),
    isOpen ? el('div', { class: 'tb-step__body oc-stack' }, [el('p', { class: 'tb-step__why' }, WHY[x.id]), BODY[x.id](s, d, again, x)]) : null,
  ]);
}

function serviceRow(name, first, last, days) {
  const on = el('input', { type: 'checkbox', checked: true });
  const nameIn = input({ value: name, maxlength: '40', 'aria-label': 'Service name' });
  const a = input({ type: 'time', value: first, 'aria-label': `${name}: first booking` });
  const b = input({ type: 'time', value: last, 'aria-label': `${name}: last booking` });
  const boxes = DAYS.map(([k, label]) => { const c = el('input', { type: 'checkbox', value: k, checked: days.includes(k) }); return { k, c, node: el('label', { class: 'tb-check' }, [c, label]) }; });
  return {
    node: el('div', { class: 'tb-svc' }, [el('label', { class: 'tb-check' }, [on, '']), nameIn, a, el('span', { class: 'oc-muted' }, 'to'), b, el('div', { class: 'tb-days' }, boxes.map((x) => x.node))]),
    value: () => (on.checked ? { name: nameIn.value.trim() || name, first_time: a.value, last_time: b.value, days: boxes.filter((x) => x.c.checked).map((x) => x.k).join(',') } : null),
  };
}

const BODY = {
  hours(s, d, again) {
    const name = input({ value: s.business_name || '', maxlength: '80', placeholder: 'Casa Lola' });
    const phone = input({ value: s.phone || '', maxlength: '30', type: 'tel', placeholder: '+34 …' });
    const zone = zoneSelect(s.business_name ? s.timezone : browserZone());
    const rows = d.services.length ? [] : [serviceRow('Lunch', '13:00', '15:30', ['tue', 'wed', 'thu', 'fri', 'sat', 'sun']), serviceRow('Dinner', '20:00', '22:30', ['tue', 'wed', 'thu', 'fri', 'sat'])];
    const save = el('button', { type: 'submit', class: 'oc-btn oc-btn--primary' }, 'Save');
    const f = el('form', { class: 'oc-stack tb-start__form' }, [
      el('div', { class: 'tb-three' }, [field('Restaurant name', name, 'Guests see it on the page and in emails.'), field('Phone', phone, 'For guests who need to call.'), field('Time zone', zone)]),
      rows.length ? el('div', { class: 'oc-stack oc-stack--tight' }, [el('span', { class: 'oc-label' }, 'Services: the first and the last time a table can be booked'), ...rows.map((r) => r.node)])
        : el('p', { class: 'oc-help' }, [`${d.services.length} ${d.services.length === 1 ? 'service' : 'services'} set. `, router.link('/settings', 'Change hours in Settings')]),
      el('div', { class: 'oc-row' }, save),
    ]);
    f.addEventListener('submit', async (e) => {
      e.preventDefault();
      if (!name.value.trim()) { Orch.toast('Write the restaurant\'s name.', { error: true }); name.focus(); return; }
      const svc = rows.map((r) => r.value()).filter((x) => x && x.days && x.first_time && x.last_time);
      if (rows.length && !svc.length) { Orch.toast('Keep at least one service, with its days and times.', { error: true }); return; }
      save.disabled = true;
      let ok = await act(A.settings, { id: s._id, business_name: name.value.trim(), phone: phone.value.trim(), timezone: zone.value });
      for (const [i, x] of svc.entries()) ok = ok && await act(A.createService, { ...x, max_covers: 0, position: i + 1 });
      save.disabled = false;
      if (ok) { Orch.toast('Saved.'); again(); }
    });
    return f;
  },

  tables(s, d, again) {
    const n = (v) => input({ type: 'number', min: '0', max: '40', value: v, class: 'oc-input tb-num' });
    const twos = n(4); const fours = n(6); const sixes = n(2);
    const area = input({ value: 'Sala', maxlength: '30' });
    const save = el('button', { type: 'submit', class: 'oc-btn oc-btn--primary' }, 'Add these tables');
    const f = el('form', { class: 'oc-stack tb-start__form' }, [
      el('div', { class: 'tb-four' }, [field('Tables for 2', twos), field('Tables for 4', fours), field('Tables for 6', sixes), field('Area', area)]),
      el('p', { class: 'oc-help' }, ['A quick start: you can rename them, change seats and mark tables that join together in ', router.link('/tables', 'Tables'), '.']),
      el('div', { class: 'oc-row' }, save),
    ]);
    f.addEventListener('submit', async (e) => {
      e.preventDefault();
      const plan = [[2, 1, Number(twos.value) || 0], [4, 2, Number(fours.value) || 0], [6, 4, Number(sixes.value) || 0]];
      if (!plan.some((p) => p[2] > 0)) { Orch.toast('Add at least one table.', { error: true }); return; }
      save.disabled = true;
      let k = 0;
      for (const [max, min, count] of plan) {
        for (let i = 0; i < count; i += 1) {
          k += 1;
          if (!(await act(A.createTable, { name: `${(area.value.trim() || 'T')[0].toUpperCase()}${k}`, area: area.value.trim(), min_seats: min, max_seats: max, combine: '', walk_in_only: 'no', priority: 0, position: k }))) { save.disabled = false; return; }
        }
      }
      Orch.toast(`${k} tables added.`);
      again();
    });
    return f;
  },

  emails(s, _d, again, x) {
    const said = { ok: `Connected: ${s.gmail_account || 'Gmail answered'}.`, not_connected: 'Not connected yet: this workspace has no Gmail in Orchestra.', error: `Gmail answered with an error: ${s.gmail_note || ''}` }[s.gmail_status] || 'Not checked yet.';
    const check = el('button', { type: 'button', class: 'oc-btn' }, 'Check Gmail');
    check.addEventListener('click', async () => {
      check.disabled = true;
      const before = s.gmail_checked_at || '';
      if (!(await act(A.checkGmail, {}, 'Asking Gmail…'))) { check.disabled = false; return; }
      check.textContent = 'Checking…';
      for (let i = 0; i < 20; i += 1) { await new Promise((r) => { setTimeout(r, 2000); }); if (((await settings()).gmail_checked_at || '') !== before) break; }
      again();
    });
    const on = el('button', { type: 'button', class: 'oc-btn oc-btn--primary', disabled: s.gmail_status !== 'ok' }, 'Turn on emails to guests');
    on.addEventListener('click', async () => { if (await act(A.extras, { id: s._id, emails_on: 'yes' }, 'Emails to guests are on.')) again(); });
    const checked = s.gmail_checked_at ? ` Checked ${fmt.ago(s.gmail_checked_at)}.` : '';
    return el('div', { class: 'oc-stack' }, [
      el('p', { class: `tb-step__state${s.gmail_status && s.gmail_status !== 'ok' ? ' tb-step__state--bad' : ''}` }, `${said}${checked}`),
      el('div', { class: 'oc-row' }, [
        s.gmail_status === 'ok' ? null : el('a', { class: 'oc-btn', href: INTEGRATIONS, target: '_top' }, 'Connect Gmail in Orchestra → Integrations'),
        check, x.done ? null : on,
      ]),
      el('p', { class: 'oc-help' }, 'Also in Settings, with an optional extra: the agent reading booking emails.'),
    ]);
  },
};
