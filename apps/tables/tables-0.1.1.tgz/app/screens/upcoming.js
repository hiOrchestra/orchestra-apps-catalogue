// The coming days, one thin row each: bookings, covers, what waits for an OK,
// large groups and allergies. A day opens its service sheet (/day/<day>).
import { C, V, dayName, head, plural, settings, today } from '../data.js';

const { el, router } = Orch;

export function render() {
  Orch.load('view', async () => {
    await settings();
    const from = today();
    const r = await Orch.db.view(V.days, { filter: { day: { gte: from, lte: C.addDays(from, 60) } }, sort: 'day:asc', limit: 70 });
    const rows = r.rows || [];
    return el('div', { class: 'oc-stack oc-stack--loose' }, [
      head('Upcoming', 'The next days at a glance. Open a day for its service sheet.'),
      rows.length ? el('ul', { class: 'tb-rows tb-rows--card' }, rows.map((d) => el('li', { class: 'tb-row' }, router.link(`/day/${d.day}`, [
        el('span', { class: 'oc-value tb-row__time tb-row__time--day' }, d.day === from ? 'Today' : d.day === C.addDays(from, 1) ? 'Tomorrow' : dayName(d.day, true)),
        el('span', { class: 'tb-row__who' }, [
          el('span', { class: 'tb-row__name' }, `${plural(d.covers || 0, 'cover', 'covers')}`),
          el('span', { class: 'tb-sub' }, [plural(d.bookings, 'booking', 'bookings'), Number(d.groups) ? ` · ${plural(d.groups, 'group of 6+', 'groups of 6+')}` : '',
            Number(d.allergies) ? ` · ${plural(d.allergies, 'allergy', 'allergies')}` : '']),
        ]),
        Number(d.waiting) ? el('span', { class: 'oc-badge oc-badge--warn' }, `${d.waiting} to approve`) : el('span'),
        el('span', { class: 'oc-muted' }, '→'),
      ], { class: 'tb-row__open tb-row__open--day' }))))
        : el('div', { class: 'oc-card oc-state' }, [el('p', { class: 'oc-state__title' }, 'Nothing booked in the coming days yet.'), el('p', { class: 'oc-help' }, 'Share your booking page (Settings) and bookings appear here day by day.')]),
    ]);
  });
}
