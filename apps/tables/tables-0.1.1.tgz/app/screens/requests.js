// What waits for a person: bookings outside the rules (a large party, a
// special request, or every booking when Settings ask for it), replies the
// agent drafted from booking emails (read, edit, send or drop), and emails
// that could not go out, each with its way out.
import { A, T, act, dayName, field, head, hm, input, plural, settings, sourceLabel } from '../data.js';
import { openBooking, requestActions } from './booking.js';

const { el, router, fmt } = Orch;

export function render(p) {
  const tab = (p && p.tab) || 'bookings';
  const again = () => render(p);
  Orch.load('view', async () => {
    const s = await settings();
    const [books, drafts, failed, mail] = await Promise.all([
      Orch.db.list(T.bookings, { filter: { status: ['Requested', 'Approving'] }, sort: 'start_at:asc', limit: 200 }),
      Orch.db.list(T.emails, { filter: { status: 'Review' }, sort: '_id:asc', limit: 100 }),
      Orch.db.list(T.emails, { filter: { status: 'Failed' }, sort: '_id:desc', limit: 100 }),
      Orch.db.list(T.mail, { filter: { status: 'Failed' }, sort: '_id:desc', limit: 50 }),
    ]);
    const n = { bookings: books.rows.length, replies: drafts.rows.length, problems: failed.rows.length + mail.rows.length };
    const tabs = el('nav', { class: 'oc-tabs', 'aria-label': 'What waits' }, [['bookings', 'Bookings'], ['replies', 'Replies'], ['problems', 'Problems']].map(([k, label]) => router.link(k === 'bookings' ? '/requests' : `/requests/${k}`,
      [label, n[k] ? el('span', { class: 'oc-count' }, String(n[k])) : null], { class: `oc-tab${k === tab ? ' oc-tab--active' : ''}`, 'aria-current': k === tab ? 'page' : null })));
    const body = tab === 'replies' ? replies(drafts.rows, again) : tab === 'problems' ? problems(failed.rows, mail.rows, again) : bookings(books.rows, s, again);
    return el('div', { class: 'oc-stack oc-stack--loose' }, [head('Requests', 'What waits for your OK before a guest hears back.'), tabs, body]);
  });
}

function bookings(rows, s, again) {
  if (!rows.length) return empty('No booking waits for your OK.', 'Bookings outside your rules (a large party, a special request) wait here. Everything else is confirmed on its own.');
  return el('ul', { class: 'tb-queue' }, rows.map((b) => el('li', { class: 'tb-queue__item' }, [
    el('button', { type: 'button', class: 'tb-queue__open', onClick: () => openBooking(b._id, again) }, [
      el('span', { class: 'tb-queue__name' }, `${b.name} · ${plural(b.party, 'person', 'people')}`),
      el('span', { class: 'oc-value' }, `${dayName(b.day, true)}, ${hm(b.start_at)}${b.table_label ? ` · held: ${b.table_label}` : ''}`),
      el('span', { class: 'tb-queue__why' }, String(b.reason || '').replace(/^Needs your OK: /, '')),
      el('span', { class: 'tb-sub' }, [sourceLabel(b), b.note ? ` · "${b.note}"` : '', b.allergies ? ` · allergies: ${b.allergies}` : '']),
    ]),
    el('div', { class: 'oc-row tb-queue__actions' }, b.status === 'Approving' ? [el('span', { class: 'oc-badge oc-badge--warn' }, 'Approving…')] : requestActions(b, s, again)),
  ])));
}

function replies(rows, again) {
  if (!rows.length) return empty('No reply waits.', 'When the agent reads a booking email it cannot settle on its own (a question, a full night, a large group), its draft waits here for you.');
  return el('div', { class: 'oc-stack' }, rows.map((m) => {
    const subject = input({ value: m.subject || '', maxlength: '200' });
    const body = el('textarea', { class: 'oc-textarea', rows: '7', maxlength: '4000' }, m.body || '');
    const send = el('button', { type: 'button', class: 'oc-btn oc-btn--primary' }, 'Send');
    send.addEventListener('click', async () => {
      if (!body.value.trim()) { Orch.toast('Write the reply first, or drop it.', { error: true }); return; }
      send.disabled = true;
      if (await act(A.approveEmail, { id: m._id, subject: subject.value.trim(), body: body.value.trim() }, `Sending to ${m.to_email}.`)) again(); else send.disabled = false;
    });
    const card = el('section', { class: 'oc-card oc-stack tb-reply' }, [
      el('div', { class: 'oc-row oc-row--between' }, [el('span', { class: 'oc-value' }, `To ${m.to_email}`), el('span', { class: 'oc-eyebrow' }, m.drafted_by === 'agent' ? 'Drafted by the agent' : 'Draft')]),
      m.error ? el('p', { class: 'tb-queue__why' }, m.error.replace(/^Why it waits: /, 'Waits because ')) : null,
      el('div', { class: 'tb-original', 'data-mail': String(m.mail_id || '') }),
      field('Subject', subject), field('Reply', body),
      el('div', { class: 'oc-row' }, [send, el('button', { type: 'button', class: 'oc-btn oc-btn--ghost', onClick: async () => { if (await act(A.dropEmail, { id: m._id }, 'Dropped: nothing was sent.')) again(); } }, 'Drop')]),
    ]);
    if (m.mail_id) Orch.db.get(T.mail, m.mail_id).then((x) => { if (x) card.querySelector('.tb-original').append(el('p', { class: 'tb-sub' }, `${x.from_name || x.from_email} wrote ${fmt.ago(x.received_at)}:`), el('blockquote', { class: 'tb-quote' }, x.body || '')); }).catch(() => {});
    return card;
  }));
}

function problems(emails, mail, again) {
  if (!emails.length && !mail.length) return empty('Nothing went wrong.', 'An email Gmail did not take, or a booking email the agent could not read, would wait here with what to do.');
  const rowOf = (title, sub, why, acts) => el('li', { class: 'tb-queue__item' }, [el('div', { class: 'tb-queue__open' }, [el('span', { class: 'tb-queue__name' }, title), el('span', { class: 'tb-sub' }, sub), el('span', { class: 'tb-queue__why' }, why)]), el('div', { class: 'oc-row' }, acts)]);
  const b = (label, name, id, said, cls = 'oc-btn--ghost') => el('button', { type: 'button', class: `oc-btn oc-btn--sm ${cls}`, onClick: async () => { if (await act(name, { id }, said)) again(); } }, label);
  return el('ul', { class: 'tb-queue' }, [
    ...emails.map((m) => rowOf(`Email to ${m.to_email}`, `${m.subject} · ${KIND[m.kind] || m.kind}`, m.error || 'It could not be sent.',
      [b('Try again', A.retryEmail, m._id, 'Sending again.', 'oc-btn--primary'), b('Drop', A.dropFailed, m._id, 'Dropped.')])),
    ...mail.map((x) => rowOf(`Email from ${x.from_name || x.from_email}`, x.subject, `The agent could not read it: ${x.result || 'no usable answer'}. Read it in Gmail, or let the agent try again.`,
      [b('Try again', A.retryMail, x._id, 'The agent reads it on its next look.', 'oc-btn--primary'), b('Ignore', A.ignoreMail, x._id, 'Ignored.')])),
  ]);
}

const KIND = { confirmed: 'confirmation', requested: 'request received', changed: 'change', cancelled: 'cancellation', declined: 'declined', reminder: 'reminder', reply: 'reply' };
const empty = (title, help) => el('div', { class: 'oc-card oc-state' }, [el('p', { class: 'oc-state__title' }, title), el('p', { class: 'oc-help' }, help)]);
