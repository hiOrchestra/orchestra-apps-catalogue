// Guests: built by the bookings themselves (by email, else phone), plus the
// ones imported from TheFork, CoverManager or Quandoo. Visits, no-shows, when
// they last came and the next booking; VIP, allergies and the host's notes.
// "Recovered" are guests who first came through a marketplace and now book
// with you directly.
import { A, C, T, V, act, dayName, field, head, hm, input, plural, select, sourceLabel, statusWord } from '../data.js';
import { importGuests } from './import.js';

const { el } = Orch;
const VIEWS = [['', 'All', null], ['vip', 'VIP', { vip: 'yes' }], ['recovered', 'Recovered', { recovered: 'yes' }]];

export function render(p, path) {
  const view = VIEWS.find((v) => v[0] === ((p && p.state) || '')) || VIEWS[0];
  const again = () => render(p, path);
  Orch.load('view', async () => {
    const counts = await Promise.all(VIEWS.map((v) => Orch.db.view(V.guests, { filter: v[2] || {}, limit: 1, count: true }).then((r) => r.total || 0).catch(() => 0)));
    const host = el('div');
    setTimeout(() => Orch.table({
      into: host, path: view[0] ? `/guests/${view[0]}` : '/guests', query: path, view: V.guests, filter: view[2] || undefined, pageSize: 25,
      sort: 'name:asc', search: 'name', searchPlaceholder: 'Find by name',
      columns: [
        { key: 'name', label: 'Name', format: (v, r) => v || r.email || r.phone || 'No name' },
        { key: 'visits', label: 'Visits', numeric: true, format: (v) => String(v || 0) },
        { key: 'no_shows', label: 'No-shows', numeric: true, format: (v) => (Number(v) ? String(v) : '—') },
        { key: 'last_visit', label: 'Last visit', format: (v) => (v ? dayName(v, true) : '—') },
        { key: 'next_visit', label: 'Next', format: (v) => (v ? dayName(v, true) : '—') },
        { key: 'first_source', label: 'First came via', sortable: false, format: (v, r) => (v ? C.sourceLabel(v, r.first_src) : '—') },
        { key: 'allergies', label: 'Allergies', clamp: true, sortable: false, format: (v) => v || '—' },
        { key: 'vip', label: 'VIP', format: (v) => (v === 'yes' ? 'VIP' : '') },
      ],
      detail: { table: T.guests, title: 'Guest', render: (row) => panel(row, again) },
      empty: view[0] === 'recovered' ? 'No recovered guests yet: a guest who first came through a marketplace and then books on your page shows up here.'
        : 'No guests yet. They appear with the first bookings, or import your list from TheFork, CoverManager or Quandoo.',
    }), 0);
    return el('div', { class: 'oc-stack oc-stack--loose' }, [
      head('Guests', 'Everyone who booked, with their visits, no-shows, notes and allergies.', [
        el('button', { type: 'button', class: 'oc-btn', onClick: () => importGuests(again) }, 'Import a guest list'),
      ]),
      el('nav', { class: 'oc-tabs', 'aria-label': 'Which guests' }, VIEWS.map((v, i) => Orch.router.link(v[0] ? `/guests/${v[0]}` : '/guests',
        [v[1], el('span', { class: 'oc-count' }, String(counts[i]))], { class: `oc-tab${v === view ? ' oc-tab--active' : ''}`, 'aria-current': v === view ? 'page' : null }))),
      host,
    ]);
  });
}

async function panel(row, again) {
  const [stats, books] = await Promise.all([
    Orch.db.view(V.guests, { filter: { _id: row._id }, limit: 1 }).then((r) => (r.rows || [])[0] || {}),
    Orch.db.list(T.bookings, { filter: { guest_id: row._id }, sort: 'start_at:desc', limit: 30 }),
  ]);
  const name = input({ value: row.name || '', maxlength: '120' });
  const email = input({ type: 'email', value: row.email || '', maxlength: '200' });
  const phone = input({ type: 'tel', value: row.phone || '', maxlength: '30' });
  const vip = select([['no', 'No'], ['yes', 'Yes: VIP']], row.vip === 'yes' ? 'yes' : 'no');
  const allergies = input({ value: row.allergies || '', maxlength: '300' });
  const notes = el('textarea', { class: 'oc-textarea', rows: '3', maxlength: '2000' }, row.notes || '');
  const f = el('form', { class: 'oc-stack' }, [
    el('div', { class: 'tb-two-col' }, [field('Name', name), field('VIP', vip)]),
    el('div', { class: 'tb-two-col' }, [field('Email', email), field('Phone', phone)]),
    field('Allergies', allergies, 'Shown on every booking of theirs, on the sheet and in the brief.'),
    field('Notes for the team', notes, 'Their table, their wine, how they like to be treated. Never sent to the guest.'),
    el('div', { class: 'oc-row' }, el('button', { type: 'submit', class: 'oc-btn oc-btn--primary' }, 'Save')),
  ]);
  f.addEventListener('submit', async (e) => {
    e.preventDefault();
    if (await act(A.guest, { id: row._id, name: name.value.trim(), email: email.value.trim().toLowerCase(), phone: phone.value.trim(), vip: vip.value, allergies: allergies.value.trim(), notes: notes.value.trim() }, 'Saved.')) again();
  });
  return el('div', { class: 'oc-stack tb-panel' }, [
    el('dl', { class: 'oc-facts' }, [['Visits', String(stats.visits || 0)], ['No-shows', String(stats.no_shows || 0)], ['Last visit', stats.last_visit ? dayName(stats.last_visit, true) : '—'],
      ['First came via', row.first_source ? C.sourceLabel(row.first_source, row.first_src) : '—']].map(([k, v]) => el('div', { class: 'oc-facts__item' }, [el('dt', k), el('dd', v)]))),
    stats.recovered === 'yes' ? el('p', { class: 'tb-notice tb-notice--good' }, `Recovered: first came through ${row.first_src || 'a marketplace'}, now books with you directly.`) : null,
    f,
    (books.rows || []).length ? el('section', { class: 'oc-stack oc-stack--tight' }, [el('span', { class: 'oc-label' }, 'Bookings'),
      el('ul', { class: 'tb-mini' }, books.rows.map((b) => el('li', [el('span', { class: 'oc-value' }, `${dayName(b.day, true)} ${hm(b.start_at)}`), ` ${plural(b.party, 'person', 'people')} · ${sourceLabel(b)} · ${statusWord(b.status)}`])))]) : null,
  ]);
}
