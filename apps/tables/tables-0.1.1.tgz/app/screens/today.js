// The service sheet of a day (today by default, /day/<YYYY-MM-DD> for another):
// one thin row per booking, by service and time — the time, who (VIP, how
// many visits, where the booking came from), how many, which table, notes and
// allergies — with Arrived and No-show on the row. A walk-in and a phone
// booking are one button and one form each. Until Tables is set up, Getting
// started (start.js) sits on top.
import { A, C, T, V, act, badge, dayName, head, hm, plural, settings, sourceLabel, today, tz } from '../data.js';
import { openBooking } from './booking.js';
import { phoneBooking, walkIn } from './add.js';
import { startData, startPanel } from './start.js';

const { el, router } = Orch;
const SHOWN = ['New', 'Requested', 'Approving', 'Confirmed', 'Arrived', 'NoShow'];

export function render(p) {
  const again = () => render(p);
  Orch.load('view', async () => {
    const s = await settings();
    const day = p && p.day && C.realDay(p.day) ? p.day : today();
    const isToday = day === today();
    const [list, brief, waiting, setup] = await Promise.all([
      Orch.db.view(V.sheet, { filter: { day }, sort: 'start_at:asc', limit: 500 }),
      Orch.db.find(T.briefs, { day }),
      Orch.db.count(T.bookings, { filter: { status: 'Requested' } }),
      isToday ? startData() : null,
    ]);
    const rows = list.rows || [];
    const live = rows.filter((b) => SHOWN.includes(b.status));
    const gone = rows.filter((b) => ['Cancelled', 'Declined'].includes(b.status));
    const services = C.servicesOn(day, (setup && setup.services) || (await Orch.db.list(T.services, { filter: { active: 'yes' }, limit: 50 })).rows,
      (await Orch.db.list(T.exceptions, { filter: { day, active: 'yes' }, limit: 5 })).rows);
    const covers = (list2) => list2.filter((b) => b.status !== 'NoShow').reduce((n, b) => n + (Number(b.party) || 0), 0);
    const tools = [
      el('div', { class: 'tb-daynav' }, [
        router.link(`/day/${C.addDays(day, -1)}`, '←', { class: 'oc-btn oc-btn--ghost oc-btn--sm', 'aria-label': 'Day before' }),
        isToday ? null : router.link('/', 'Today', { class: 'oc-btn oc-btn--ghost oc-btn--sm' }),
        router.link(`/day/${C.addDays(day, 1)}`, '→', { class: 'oc-btn oc-btn--ghost oc-btn--sm', 'aria-label': 'Next day' }),
      ]),
      isToday ? el('button', { type: 'button', class: 'oc-btn', onClick: () => walkIn(s, again) }, 'Walk-in') : null,
      el('button', { type: 'button', class: 'oc-btn oc-btn--primary', onClick: () => phoneBooking(s, day, again) }, 'Phone booking'),
    ];
    return el('div', { class: 'oc-stack oc-stack--loose' }, [
      head(isToday ? `Today · ${dayName(day)}` : dayName(day), isToday ? 'Who comes, when, and at which table.' : 'The service sheet of that day.', tools),
      isToday ? startPanel(s, setup, again) : null,
      s.paused === 'yes' ? el('div', { class: 'tb-notice tb-notice--warn' }, ['Online bookings are paused: the page offers no times. ', router.link('/settings', 'Resume them in Settings')]) : null,
      waiting ? el('div', { class: 'tb-notice tb-notice--warn' }, [`${waiting === 1 ? 'A booking waits' : `${waiting} bookings wait`} for your OK. `, router.link('/requests', 'See requests')]) : null,
      live.length || gone.length ? el('div', { class: 'oc-metrics' }, [
        metric('Covers', covers(live), plural(live.length, 'booking', 'bookings')),
        ...services.slice(0, 3).map((x) => metric(x.name, covers(live.filter((b) => b.service === x.name)), `${x.first}–${x.last}`)),
        metric('Arrived', covers(live.filter((b) => b.status === 'Arrived')), plural(live.filter((b) => b.status === 'NoShow').length, 'no-show', 'no-shows')),
      ]) : null,
      briefCard(brief),
      ...sections(live, services, again),
      live.length ? null : empty(services, isToday),
      gone.length ? cancelled(gone, again) : null,
    ]);
  });
}

function metric(label, value, sub) {
  return el('div', { class: 'oc-metric' }, [el('span', { class: 'oc-kpi__label' }, label), el('span', { class: 'oc-kpi__value tb-metric' }, String(value)), el('span', { class: 'tb-sub' }, sub)]);
}

function briefCard(b) {
  if (!b || b.status !== 'Done' || !(b.summary || b.note)) return null;
  const watch = C.jsonOf(b.watch, []);
  return el('section', { class: 'oc-card oc-stack tb-brief', 'aria-label': 'Service brief' }, [
    el('p', { class: 'oc-eyebrow' }, 'Before service'),
    b.summary ? el('p', { class: 'tb-brief__text' }, b.summary) : el('p', { class: 'oc-help' }, b.note),
    watch.length ? el('ul', { class: 'tb-list' }, watch.map((w) => el('li', w))) : null,
  ]);
}

/** One card per service (and one for bookings outside every service), rows by time. */
function sections(live, services, again) {
  const names = services.map((x) => x.name);
  const groups = services.map((x) => ({ title: `${x.name} · ${x.first}–${x.last}`, rows: live.filter((b) => b.service === x.name) }));
  const other = live.filter((b) => !names.includes(b.service));
  if (other.length) groups.push({ title: services.length ? 'Outside the service hours' : 'Bookings', rows: other });
  return groups.filter((g) => g.rows.length).map((g) => el('section', { class: 'oc-card oc-card--pad0' }, [
    el('h2', { class: 'oc-eyebrow tb-group' }, [g.title, el('span', { class: 'tb-group__n' }, `${g.rows.filter((b) => b.status !== 'NoShow').reduce((n, b) => n + (Number(b.party) || 0), 0)} covers`)]),
    el('ul', { class: 'tb-rows' }, g.rows.map((b) => row(b, again))),
  ]));
}

function visits(b) {
  const n = Number(b.visits) || 0;
  return n ? `${n} ${n === 1 ? 'visit' : 'visits'}` : 'First visit';
}

export function row(b, again) {
  const warn = [...new Set([b.allergies, b.guest_allergies].map((x) => String(x || '').trim()).filter(Boolean))].join('; ');
  const open = el('button', { type: 'button', class: 'tb-row__open', onClick: () => openBooking(b._id, again) }, [
    el('span', { class: 'oc-value tb-row__time' }, hm(b.start_at)),
    el('span', { class: 'tb-row__who' }, [
      el('span', { class: 'tb-row__name' }, [b.name || 'Walk-in', b.vip === 'yes' ? el('span', { class: 'oc-badge oc-badge--accent tb-vip' }, 'VIP') : null]),
      el('span', { class: 'tb-sub' }, [visits(b), ' · ', sourceLabel(b), Number(b.no_shows) ? ` · ${plural(b.no_shows, 'no-show', 'no-shows')} before` : '']),
      b.note || b.guest_notes ? el('span', { class: 'tb-sub tb-row__note' }, [...new Set([b.note, b.guest_notes].filter(Boolean))].join(' · ')) : null,
      warn ? el('span', { class: 'tb-row__allergy' }, `Allergies: ${warn}`) : null,
    ]),
    el('span', { class: 'oc-value tb-row__party' }, `${b.party}p`),
    el('span', { class: 'oc-value tb-row__table' }, b.table_label || '—'),
  ]);
  return el('li', { class: `tb-row tb-row--${String(b.status).toLowerCase()}` }, [open, el('div', { class: 'tb-row__act' }, actions(b, again))]);
}

/** On the row: Arrived and No-show while it is booked, Undo after, the state otherwise. */
function actions(b, again) {
  const btn = (label, name, done, cls = '') => el('button', { type: 'button', class: `oc-btn oc-btn--sm ${cls}`, onClick: async (e) => {
    e.currentTarget.disabled = true;
    if (await act(name, { id: b._id }, done)) again(); else e.currentTarget.disabled = false;
  } }, label);
  if (b.status === 'Confirmed') {
    const started = Date.parse(b.start_at) <= Date.now() + 15 * 60000;
    return [btn('Arrived', A.arrive, `${b.name || 'Walk-in'}: arrived.`, 'oc-btn--primary'), started ? btn('No-show', A.noShow, `${b.name}: marked as no-show.`, 'oc-btn--ghost') : null];
  }
  if (b.status === 'Arrived') return [badge('Arrived'), btn('Undo', A.undoArrive, 'Back to booked.', 'oc-btn--ghost')];
  if (b.status === 'NoShow') return [badge('NoShow'), btn('Undo', A.undoNoShow, 'Back to booked.', 'oc-btn--ghost')];
  return [badge(b.status)];
}

function cancelled(rows, again) {
  const list = el('ul', { class: 'tb-rows', hidden: true }, rows.map((b) => row(b, again)));
  const t = el('button', { type: 'button', class: 'oc-btn oc-btn--ghost oc-btn--sm', 'aria-expanded': 'false' }, `Show cancelled (${rows.length})`);
  t.addEventListener('click', () => { list.hidden = !list.hidden; t.setAttribute('aria-expanded', String(!list.hidden)); t.textContent = `${list.hidden ? 'Show' : 'Hide'} cancelled (${rows.length})`; });
  return el('section', { class: 'oc-stack' }, [el('div', { class: 'oc-row' }, t), el('div', { class: 'oc-card oc-card--pad0' }, list)]);
}

function empty(services, isToday) {
  if (!services.length) {
    return el('div', { class: 'oc-card oc-state' }, [el('p', { class: 'oc-state__title' }, 'Closed: no service that day.'),
      el('p', { class: 'oc-help' }, ['The page offers no times on a closed day. ', router.link('/settings', 'Change the hours in Settings')])]);
  }
  return el('div', { class: 'oc-card oc-state' }, [el('p', { class: 'oc-state__title' }, isToday ? 'No bookings yet today.' : 'No bookings yet that day.'),
    el('p', { class: 'oc-help' }, 'Bookings from your page, the phone and walk-ins appear here as they come in.')]);
}

export { tz };
