// The hours: services (lunch, dinner…) with their days, the first and the
// last time a table can be booked, and an optional cap of covers; and the
// exceptions by date (closed, or other hours that day), which replace the
// weekly services of that day.
import { A, C, T, act, dayName, input, select, today, twoStep } from '../data.js';

const { el } = Orch;
const DAYS = [['mon', 'Mon'], ['tue', 'Tue'], ['wed', 'Wed'], ['thu', 'Thu'], ['fri', 'Fri'], ['sat', 'Sat'], ['sun', 'Sun']];

export async function hoursCard(s, again) {
  const [svc, ex] = await Promise.all([
    Orch.db.list(T.services, { filter: { active: 'yes' }, sort: 'position:asc', limit: 30 }),
    Orch.db.list(T.exceptions, { filter: { active: 'yes', day: { gte: today() } }, sort: 'day:asc', limit: 100 }),
  ]);
  const services = svc.rows || [];
  const list = el('div', { class: 'oc-stack' }, services.map((x) => service(x, again)));
  const add = el('button', { type: 'button', class: 'oc-btn oc-btn--sm' }, 'Add a service');
  add.addEventListener('click', () => { list.append(service(null, again, services.length + 1)); add.disabled = true; });
  return el('section', { class: 'oc-card oc-stack' }, [
    el('h2', { class: 'oc-h2' }, 'Hours'),
    el('p', { class: 'oc-help tb-legible' }, 'Guests can book from the first to the last time of each service, every few minutes (Booking rules). A table is then kept for the stay, even past the last time.'),
    services.length ? null : el('p', { class: 'tb-notice tb-notice--warn' }, 'No service yet: the page offers no times until there is one.'),
    list, el('div', { class: 'oc-row' }, add),
    el('h3', { class: 'oc-h3' }, 'Exceptions'),
    el('p', { class: 'oc-help' }, 'A holiday, a closed day, a private event, or other hours on one date. It replaces the weekly hours of that day.'),
    (ex.rows || []).length ? el('ul', { class: 'tb-mini' }, ex.rows.map((e) => exceptionRow(e, again))) : el('p', { class: 'oc-muted' }, 'None coming up.'),
    exceptionForm(again),
  ]);
}

function service(x, again, position) {
  const v = x || { name: '', days: 'mon,tue,wed,thu,fri,sat,sun', first_time: '20:00', last_time: '22:30', max_covers: 0 };
  const on = C.daysOf(v.days);
  const name = input({ value: v.name, maxlength: '40', placeholder: 'Dinner', required: true, 'aria-label': 'Service name' });
  const first = input({ type: 'time', value: v.first_time, required: true, 'aria-label': 'First booking' });
  const last = input({ type: 'time', value: v.last_time, required: true, 'aria-label': 'Last booking' });
  const cap = input({ type: 'number', min: '0', max: '2000', value: v.max_covers || 0, class: 'oc-input tb-num', 'aria-label': 'Most covers' });
  const boxes = DAYS.map(([k, label]) => { const c = el('input', { type: 'checkbox', value: k, checked: on.includes(k) }); return { k, c, node: el('label', { class: 'tb-check' }, [c, label]) }; });
  const f = el('form', { class: 'tb-svcform' }, [
    el('div', { class: 'tb-svc' }, [name, first, el('span', { class: 'oc-muted' }, 'to'), last, el('label', { class: 'tb-check tb-cap' }, ['Most covers', cap])]),
    el('div', { class: 'tb-days' }, boxes.map((b) => b.node)),
    el('div', { class: 'oc-row' }, [el('button', { type: 'submit', class: 'oc-btn oc-btn--sm oc-btn--primary' }, x ? 'Save' : 'Add'),
      x ? twoStep({ label: 'Remove', yes: 'Remove the service', what: `Remove ${x.name}?`, collateral: [`The page stops offering ${x.name} times.`, 'Bookings already made for it stay as they are.'],
        run: async () => { if (await act(A.removeService, { id: x._id }, `${x.name} removed.`)) again(); } }) : null]),
  ]);
  f.addEventListener('submit', async (e) => {
    e.preventDefault();
    const days = boxes.filter((b) => b.c.checked).map((b) => b.k).join(',');
    if (!days) { Orch.toast('Tick at least one day.', { error: true }); return; }
    const p = { name: name.value.trim() || 'Service', days, first_time: first.value, last_time: last.value, max_covers: Number(cap.value) || 0, position: x ? x.position : position };
    if (await act(x ? A.updateService : A.createService, x ? { id: x._id, ...p } : p, 'Saved. The free times are being worked out again.')) again();
  });
  return f;
}

function exceptionRow(e, again) {
  const hours = C.jsonOf(e.services, []).map((x) => `${x.name || 'Open'} ${x.first}–${x.last}`).join(', ');
  return el('li', { class: 'tb-exc' }, [
    el('span', { class: 'oc-value' }, dayName(e.day, true)),
    el('span', e.kind === 'closed' ? 'Closed' : hours),
    e.note ? el('span', { class: 'oc-muted' }, e.note) : null,
    el('button', { type: 'button', class: 'oc-btn oc-btn--sm oc-btn--ghost', onClick: async () => { if (await act(A.removeException, { id: e._id }, 'Removed: the weekly hours apply that day.')) again(); } }, 'Remove'),
  ]);
}

function exceptionForm(again) {
  const day = input({ type: 'date', min: today(), required: true, 'aria-label': 'Date' });
  const kind = select([['closed', 'Closed'], ['hours', 'Other hours']], 'closed');
  const first = input({ type: 'time', value: '20:00', 'aria-label': 'First booking' });
  const last = input({ type: 'time', value: '22:30', 'aria-label': 'Last booking' });
  const note = input({ maxlength: '80', placeholder: 'Christmas, private event…', 'aria-label': 'Note' });
  const times = el('span', { class: 'oc-row tb-exc__times', hidden: true }, [first, el('span', { class: 'oc-muted' }, 'to'), last]);
  kind.addEventListener('change', () => { times.hidden = kind.value !== 'hours'; });
  const f = el('form', { class: 'tb-excform' }, [day, kind, times, note, el('button', { type: 'submit', class: 'oc-btn oc-btn--sm' }, 'Add exception')]);
  f.addEventListener('submit', async (e) => {
    e.preventDefault();
    if (!C.realDay(day.value)) { Orch.toast('Pick a date.', { error: true }); return; }
    const services = kind.value === 'hours' ? JSON.stringify([{ name: note.value.trim() || 'Open', first: first.value, last: last.value }]) : '';
    if (await act(A.createException, { day: day.value, kind: kind.value, services, note: note.value.trim() }, 'Added.')) again();
  });
  return el('div', { class: 'oc-field' }, [el('span', { class: 'oc-label' }, 'Add an exception'), f]);
}
