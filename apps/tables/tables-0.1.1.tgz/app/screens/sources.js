// Where bookings come from, this month or last: the booking page (and each
// channel link: Instagram, Google, the website…), email, phone, walk-ins and
// marketplaces. "Commission avoided" is an estimate, said as one: the covers
// booked straight with you online (the page, email) times the per-cover fee
// the owner set for their marketplace. Recovered guests first came through a
// marketplace and now book directly.
import { C, V, head, plural, settings, today } from '../data.js';

const { el, router, fmt } = Orch;

export function render(p, path) {
  const which = String(path || '').includes('month=last') ? 'last' : 'this';
  Orch.load('view', async () => {
    const s = await settings();
    const now = today().slice(0, 7);
    const [y, m] = now.split('-').map(Number);
    const last = new Date(Date.UTC(y, m - 2, 1)).toISOString().slice(0, 7);
    const month = which === 'last' ? last : now;
    const [r, rec] = await Promise.all([
      Orch.db.view(V.sources, { filter: { month }, sort: 'covers:desc', limit: 200 }),
      Orch.db.view(V.guests, { filter: { recovered: 'yes' }, limit: 1, count: true }),
    ]);
    const rows = (r.rows || []).map((x) => ({ ...x, bookings: Number(x.bookings) || 0, covers: Number(x.covers) || 0 }));
    const sum = (f) => rows.filter(f).reduce((a, x) => ({ b: a.b + x.bookings, c: a.c + x.covers }), { b: 0, c: 0 });
    const all = sum(() => true);
    const direct = sum((x) => C.DIRECT.includes(x.source));
    const market = sum((x) => x.source === 'market');
    const fee = Number(s.market_fee) || 0;
    const label = new Intl.DateTimeFormat('en-GB', { month: 'long', year: 'numeric', timeZone: 'UTC' }).format(new Date(`${month}-15T12:00:00Z`));
    return el('div', { class: 'oc-stack oc-stack--loose' }, [
      head('Sources', 'Where your bookings come from, and what booking direct saves you.', [
        el('div', { class: 'oc-segmented', role: 'group', 'aria-label': 'Month' }, [
          router.link('/sources', 'This month', { class: 'oc-segmented__item', 'aria-current': String(which === 'this') }),
          router.link('/sources?month=last', 'Last month', { class: 'oc-segmented__item', 'aria-current': String(which === 'last') }),
        ]),
      ]),
      el('div', { class: 'oc-metrics' }, [
        metric(`Covers · ${label}`, fmt.number(all.c), plural(all.b, 'booking', 'bookings')),
        metric('Booked direct online', fmt.number(direct.c), 'covers from your page and by email'),
        metric('Through marketplaces', fmt.number(market.c), 'covers you entered as TheFork or similar'),
        metric('Commission avoided', fee ? fmt.money(Math.round(direct.c * fee * 100) / 100, s.currency || 'EUR') : '—', fee ? `estimate at ${fmt.money(fee, s.currency || 'EUR')} a cover` : 'set the fee in Settings'),
        metric('Recovered guests', fmt.number(rec.total || 0), 'first came via a marketplace, now book direct', '/guests/recovered'),
      ]),
      el('p', { class: 'oc-help tb-legible' }, `An estimate, not an invoice: the covers booked on your page or by email, times the fee per cover you set for your marketplace (${fee ? fmt.money(fee, s.currency || 'EUR') : 'not set'}). It assumes those guests would otherwise have booked there. Phone bookings and walk-ins are not counted.`),
      rows.length ? el('section', { class: 'oc-card oc-card--pad0' }, [
        el('h2', { class: 'oc-eyebrow tb-group' }, ['By source', el('span', { class: 'tb-group__n' }, 'bookings · covers')]),
        el('ul', { class: 'tb-rows' }, rows.map((x) => el('li', { class: 'tb-row tb-row--static' }, [
          el('span', { class: 'tb-row__who' }, [el('span', { class: 'tb-row__name' }, C.sourceLabel(x.source, x.src)), el('span', { class: 'tb-sub' }, C.DIRECT.includes(x.source) ? 'direct' : x.source === 'market' ? 'marketplace' : 'in person or by phone')]),
          el('span', { class: 'oc-value' }, `${x.bookings} · ${x.covers}`),
          el('span', { class: 'tb-bar', 'aria-hidden': 'true' }, el('span', { style: `width:${all.c ? Math.round((x.covers / all.c) * 100) : 0}%` })),
        ]))),
      ]) : el('div', { class: 'oc-card oc-state' }, [el('p', { class: 'oc-state__title' }, `No bookings in ${label} yet.`), el('p', { class: 'oc-help' }, 'Confirmed and seated bookings are counted here by where they came from.')]),
      el('p', { class: 'oc-help tb-legible' }, ['To see which channel brings guests, share one link per channel (Instagram, Google, your website…): ', router.link('/settings', 'the links are in Settings'), '.']),
    ]);
  });
}

function metric(label, value, sub, to) {
  const kids = [el('span', { class: 'oc-kpi__label' }, label), el('span', { class: 'oc-kpi__value tb-metric' }, value), el('span', { class: 'tb-sub' }, sub)];
  return to ? router.link(to, kids, { class: 'oc-metric tb-metric-link' }) : el('div', { class: 'oc-metric' }, kids);
}
