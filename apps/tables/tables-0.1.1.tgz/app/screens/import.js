// Import a guest list: the CSV a marketplace or an old booking system exports
// (TheFork, CoverManager, Quandoo, any similar file). It is read here, the
// columns are recognised (and can be corrected), and the guests go to the
// instance in parts of about 80 KB; Import guests merges them by email, else
// phone. Nobody is contacted.
import { A, C, T, act, field, select, sheet } from '../data.js';

const { el } = Orch;
const KEYS = [['name', 'Full name'], ['first', 'First name'], ['last', 'Last name'], ['email', 'Email'], ['phone', 'Phone'], ['notes', 'Notes'], ['allergies', 'Allergies'], ['visits', 'Visits'], ['vip', 'VIP']];
const PART = 80000;

export function importGuests(again) {
  const file = el('input', { type: 'file', accept: '.csv,.txt,text/csv', class: 'oc-input' });
  const origin = select([['TheFork', 'TheFork'], ['Quandoo', 'Quandoo'], ['CoverManager', 'CoverManager'], ['Other', 'Another system']], 'TheFork');
  const map = el('div', { class: 'tb-map' });
  const said = el('p', { class: 'tb-result', role: 'status', 'aria-live': 'polite' });
  const go = el('button', { type: 'submit', class: 'oc-btn oc-btn--primary', disabled: true }, 'Import');
  let rows = [];
  let header = [];
  let cols = {};
  const preview = () => {
    const guests = C.guestsFrom(rows, cols);
    said.className = 'tb-result';
    said.textContent = `${guests.length} ${guests.length === 1 ? 'guest' : 'guests'} to import${rows.length - guests.length ? `; ${rows.length - guests.length} rows without email or phone are left out` : ''}.`;
    go.disabled = !guests.length;
    return guests;
  };
  file.addEventListener('change', async () => {
    const f = file.files && file.files[0];
    if (!f) return;
    if (f.size > 8 * 1024 * 1024) { said.textContent = 'That file is over 8 MB: export fewer columns, or split it.'; return; }
    const all = C.parseCsv(await f.text());
    header = all[0] || [];
    rows = all.slice(1);
    cols = C.mapColumns(header);
    map.replaceChildren(...KEYS.map(([k, label]) => {
      const s = select([['', '—'], ...header.map((h, i) => [String(i), h || `Column ${i + 1}`])], cols[k] === undefined ? '' : String(cols[k]));
      s.addEventListener('change', () => { if (s.value === '') delete cols[k]; else cols[k] = Number(s.value); preview(); });
      return field(label, s);
    }));
    preview();
  });
  const f = el('form', { class: 'oc-stack tb-add' }, [
    el('p', { class: 'oc-help' }, 'Export your guests from TheFork Manager, CoverManager or Quandoo as CSV and pick the file. Guests already here are matched by email or phone and keep what they have; visits and notes are added. Nobody gets an email.'),
    el('div', { class: 'tb-two-col' }, [field('The file', file), field('Where is it from?', origin, 'Guests from a marketplace count as "first came via" it, for Sources.')]),
    map, said, el('div', { class: 'oc-row oc-row--end' }, go),
  ]);
  const d = sheet(f, { title: 'Import a guest list' });
  f.addEventListener('submit', async (e) => {
    e.preventDefault();
    const guests = preview();
    if (!guests.length) return;
    go.disabled = true;
    const batch = `imp-${Date.now().toString(36)}`;
    const parts = [];
    let cur = [];
    for (const g of guests) {
      cur.push(g);
      if (JSON.stringify(cur).length > PART) { parts.push(cur.slice(0, -1)); cur = [g]; }
    }
    if (cur.length) parts.push(cur);
    for (const [i, p] of parts.entries()) {
      said.textContent = `Sending part ${i + 1} of ${parts.length}…`;
      if (!(await act(A.importPart, { batch, part: i + 1, origin: origin.value, rows: JSON.stringify(p) }))) { go.disabled = false; said.textContent = 'It stopped: nothing was lost, try again.'; return; }
    }
    await act(A.runImport, {});
    said.textContent = 'Merging them…';
    for (let t = 0; t < 40; t += 1) {
      await new Promise((r) => { setTimeout(r, 1500); });
      const r = await Orch.db.list(T.imports, { filter: { batch }, limit: 200 });
      const rs = r.rows || [];
      if (rs.length && rs.every((x) => x.status !== 'New')) {
        const sum = rs.reduce((a, x) => { const j = C.jsonOf(x.result, {}); for (const k of ['added', 'updated', 'skipped']) a[k] += Number(j[k]) || 0; return a; }, { added: 0, updated: 0, skipped: 0 });
        said.className = 'tb-result tb-result--good';
        said.textContent = `Done: ${sum.added} new guests, ${sum.updated} updated, ${sum.skipped} already known or left out.`;
        setTimeout(() => { d.close(); again(); }, 1800);
        return;
      }
    }
    said.textContent = 'Still merging: the guests appear in the list in a moment.';
  });
}
