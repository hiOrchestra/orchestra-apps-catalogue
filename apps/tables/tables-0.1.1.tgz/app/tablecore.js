/**
 * The rules of Tables that the desk, the scripts and the public page must
 * agree on, in one file: the service hours of a day (weekly services, a date
 * exception replaces them), the start times they offer (DST included), how
 * long a party keeps its table, what is inside the rules and what becomes a
 * request, which table a party gets, the sealed guest link, the guest's
 * snapshot, the emails' words, and reading a guest CSV.
 * Pure functions, no database, no DOM. test/sync.js copies this file to app/,
 * public/ and automations/, and a test fails if a copy is stale.
 *
 * Ported, with their MIT notices (see THIRD_PARTY_LICENSES):
 *   - the table assignment and the stay by party size: karanshukla/openresto
 *     (TableAutoAssigner.cs, BookingDuration.cs), Copyright (c) 2026 Karan
 *     Shukla, MIT. Its tests are our edge-case list (test/core.test.js).
 *   - merging and overlap of busy times, and reading a time of day from the
 *     instant: recal-dev/scheduling-sdk (merge.ts, generator.ts), Copyright (c)
 *     2025 Torben Köhler, MIT.
 *   - the idea that a date override replaces that day's weekly hours, and that
 *     a day's ranges are built in the zone so DST days come out right:
 *     calcom/cal.diy (packages/features/schedules/lib/date-ranges.ts),
 *     Copyright (c) 2020-present Cal.com, Inc., MIT.
 *   - areas, tables with min/max and priority, combos, and the settings names
 *     (interval, stay time, lead time, max guests): tastyigniter/
 *     ti-ext-reservation, Copyright (c) Samuel Adepoyigi, MIT (model only).
 */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.TableCore = api;
}(typeof self !== 'undefined' ? self : this, () => {
  'use strict';

  const DAYS = ['sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat'];
  /** Statuses whose table is taken for its time. */
  const HOLDING = ['Requested', 'Approving', 'Confirmed', 'Arrived'];
  const HOST_SOURCES = ['phone', 'walkin', 'desk', 'market'];
  const MAX_PARTY = 60;

  const jsonOf = (t, fallback) => {
    if (t === null || t === undefined || t === '') return fallback;
    if (typeof t === 'object') return t;
    try { return JSON.parse(t); } catch { return fallback; }
  };

  // ── time ───────────────────────────────────────────────────────────────
  function validZone(tz) { try { new Intl.DateTimeFormat('en-CA', { timeZone: tz }); return tz; } catch { return 'UTC'; } }
  const fmts = {};
  function parts(date, tz) {
    const f = fmts[tz] || (fmts[tz] = new Intl.DateTimeFormat('en-CA', {
      timeZone: tz, year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', hourCycle: 'h23',
    }));
    const o = {};
    for (const p of f.formatToParts(date)) o[p.type] = p.value;
    if (o.hour === '24') o.hour = '00'; // some ICU builds (scheduling-sdk, generator.ts)
    return o;
  }
  const localDay = (d, tz) => { const p = parts(d, tz); return `${p.year}-${p.month}-${p.day}`; };
  const localTime = (d, tz) => { const p = parts(d, tz); return `${p.hour}:${p.minute}`; };
  const isoZ = (d) => `${new Date(d).toISOString().slice(0, 19)}Z`;
  const toMin = (hhmm) => { const m = /^(\d{1,2}):(\d{2})$/.exec(String(hhmm || '').trim()); return m && +m[1] < 25 && +m[2] < 60 ? +m[1] * 60 + +m[2] : null; };
  const hhmm = (min) => `${String(Math.floor(min / 60) % 24).padStart(2, '0')}:${String(min % 60).padStart(2, '0')}`;
  function addDays(day, n) { const [y, m, d] = day.split('-').map(Number); return new Date(Date.UTC(y, m - 1, d + n)).toISOString().slice(0, 10); }
  const weekday = (day) => DAYS[new Date(`${day}T12:00:00Z`).getUTCDay()];
  /** A calendar day that exists ('2026-02-30' does not). */
  const realDay = (s) => /^\d{4}-\d\d-\d\d$/.test(String(s)) && new Date(`${s}T00:00:00Z`).toISOString().slice(0, 10) === s;

  /**
   * The instant a wall-clock time in `tz` is, corrected twice for the DST
   * edge. A time skipped in spring lands an hour later (the caller checks it
   * with localTime and drops it); one repeated in autumn is the second.
   */
  function localToUtc(day, time, tz) {
    const [y, m, d] = day.split('-').map(Number);
    const min = toMin(time);
    const want = Date.UTC(y, m - 1, d, Math.floor(min / 60), min % 60);
    let t = want;
    for (let i = 0; i < 2; i += 1) {
      const p = parts(new Date(t), tz);
      t -= Date.UTC(+p.year, +p.month - 1, +p.day, +p.hour, +p.minute) - want;
    }
    return new Date(t);
  }

  // ── hours ──────────────────────────────────────────────────────────────
  const daysOf = (v) => String(v || '').toLowerCase().split(/[\s,]+/).filter((d) => DAYS.includes(d));
  const svc = (x) => ({ name: String(x.name || 'Service').slice(0, 40), first: x.first || x.first_time, last: x.last || x.last_time, max_covers: Number(x.max_covers) || 0 });
  /**
   * The services open on a local day. A date exception REPLACES the weekly
   * services of that day (cal.diy's date override): closed, or its own hours.
   */
  function servicesOn(day, services, exceptions) {
    const ex = (exceptions || []).find((e) => e.day === day && e.active !== 'no');
    if (ex) return ex.kind === 'closed' ? [] : (jsonOf(ex.services, []) || []).map(svc).filter((x) => toMin(x.first) !== null && toMin(x.last) !== null);
    const wd = weekday(day);
    return (services || []).filter((x) => x.active !== 'no' && daysOf(x.days).includes(wd)).map(svc)
      .filter((x) => toMin(x.first) !== null && toMin(x.last) !== null)
      .sort((a, b) => toMin(a.first) - toMin(b.first));
  }

  /**
   * The start times a local day offers, every `interval_min` from each
   * service's first to its last booking time, counted on the wall clock of
   * Settings' zone. A service whose last time is before its first runs past
   * midnight. A time the spring change skips is not offered.
   */
  function startsOn(day, s, services, exceptions) {
    const tz = validZone(s.timezone || 'UTC');
    const step = Math.max(5, Number(s.interval_min) || 15);
    const out = [];
    for (const x of servicesOn(day, services, exceptions)) {
      const a = toMin(x.first);
      let b = toMin(x.last);
      if (b < a) b += 1440;
      for (let m = a; m <= b; m += step) {
        const d = m >= 1440 ? addDays(day, 1) : day;
        const t = localToUtc(d, hhmm(m % 1440), tz);
        if (localTime(t, tz) !== hhmm(m % 1440)) continue; // the hour skipped in spring
        out.push({ day, start_at: isoZ(t), time: hhmm(m % 1440), service: x.name, max_covers: x.max_covers });
      }
    }
    return out;
  }

  /** How long a party keeps its table (openresto BookingDuration.For): the rule with the largest `min` at or below the party, else the default. */
  function stayFor(s, party) {
    const rules = (jsonOf(s.stay_rules, []) || []).map((r) => ({ min: Number(r.min), minutes: Number(r.minutes) }))
      .filter((r) => r.min > 0 && r.minutes > 0).sort((a, b) => a.min - b.min);
    let hit = null;
    for (const r of rules) if (r.min <= party) hit = r;
    return hit ? hit.minutes : (Number(s.default_stay_min) || 90);
  }

  // ── the rules ──────────────────────────────────────────────────────────
  const WORD = {
    party: 'The number of people is not valid', closed: 'Closed that day', time: 'Not a time we take bookings',
    past: 'That time has passed', notice: 'Too soon: bookings need more notice', window: 'Too far ahead: bookings open later',
  };
  /**
   * What the rules say about a booking. `problems` mean it cannot be booked as
   * asked; `flags` mean a person approves it (a large party, a special
   * request, or Settings asks to approve every booking). A booking the host
   * makes (phone, walk-in) only needs a valid party: it is their room.
   *   check({start_at, party, special, source}, {s, services, exceptions, now})
   */
  function check(b, { s, services, exceptions, now }) {
    const problems = [];
    const flags = [];
    const party = Number(b.party);
    if (!Number.isInteger(party) || party < 1 || party > MAX_PARTY) problems.push('party');
    const start = new Date(b.start_at);
    if (Number.isNaN(start.getTime())) return { ok: false, problems: [...problems, 'time'], flags, slot: null };
    if (HOST_SOURCES.includes(b.source)) return { ok: !problems.length, problems, flags, slot: null };
    const tz = validZone(s.timezone || 'UTC');
    const t = (now || new Date()).getTime();
    let slot = null;
    for (const d of [localDay(start, tz), addDays(localDay(start, tz), -1)]) {
      slot = startsOn(d, s, services, exceptions).find((x) => x.start_at === isoZ(start));
      if (slot) break;
    }
    if (!slot) problems.push(servicesOn(localDay(start, tz), services, exceptions).length ? 'time' : 'closed');
    if (start.getTime() <= t) problems.push('past');
    else if (start.getTime() - t < (Number(s.min_notice_min) || 0) * 60000) problems.push('notice');
    if (start.getTime() - t > (Number(s.window_days) || 60) * 86400000) problems.push('window');
    if (party > (Number(s.max_online_party) || 8)) flags.push('large');
    if (b.special === 'yes' || b.special === true) flags.push('special');
    if (s.policy === 'review') flags.push('review');
    return { ok: !problems.length, problems, flags, slot };
  }
  const problemText = (codes) => codes.map((c) => WORD[c] || c).join('; ');

  // ── seating (openresto's TableAutoAssigner, ported) ─────────────────────
  /** Merge overlapping busy times into one each (scheduling-sdk mergeBusyTimes). */
  function mergeBusy(list) {
    const sorted = list.slice().sort((a, b) => a.start - b.start);
    const out = [];
    for (const x of sorted) {
      const last = out[out.length - 1];
      if (!last || x.start > last.end) out.push({ start: x.start, end: x.end });
      else if (x.end > last.end) last.end = x.end;
    }
    return out;
  }
  const overlaps = (a, b) => a.start < b.end && b.start < a.end; // scheduling-sdk isOverlapping

  /** Tables, and the combos their `combine` names make (two or more tables sharing a name), as bookable units. */
  function units(tables) {
    const live = (tables || []).filter((t) => t.active !== 'no').map((t) => ({
      id: Number(t._id), name: String(t.name || t._id), min: Math.max(1, Number(t.min_seats) || 1), max: Number(t.max_seats) || 0,
      combine: String(t.combine || '').trim(), walkIn: t.walk_in_only === 'yes', priority: Number(t.priority) || 0, area: t.area || '',
    })).filter((t) => t.max >= t.min);
    const out = live.map((t) => ({ key: `t${t.id}`, ids: [t.id], label: t.name, area: t.area, min: t.min, max: t.max,
      tier: t.combine ? 1 : 0, priority: t.priority, walkIn: t.walkIn, group: false }));
    const groups = {};
    for (const t of live) if (t.combine) (groups[t.combine] = groups[t.combine] || []).push(t);
    for (const [name, members] of Object.entries(groups)) {
      if (members.length < 2) continue;
      const m = members.slice().sort((a, b) => a.id - b.id);
      out.push({ key: `g:${name}`, ids: m.map((t) => t.id), label: m.map((t) => t.name).join('+'), area: m[0].area,
        min: m.reduce((n, t) => n + t.min, 0), max: m.reduce((n, t) => n + t.max, 0), tier: 2,
        priority: Math.max(...m.map((t) => t.priority)), walkIn: m.some((t) => t.walkIn), group: true, name });
    }
    return out;
  }

  /** Busy time per table id from bookings that hold a table: { id: [{start, end}] } (merged). `except` leaves one booking out (its own move). */
  function takenFrom(bookings, except) {
    const by = {};
    for (const b of bookings || []) {
      if (!HOLDING.includes(b.status) || Number(b._id) === Number(except)) continue;
      const start = Date.parse(b.start_at);
      const end = Date.parse(b.end_at);
      if (!(end > start)) continue;
      for (const id of String(b.table_ids || '').split(',').map(Number).filter(Boolean)) (by[id] = by[id] || []).push({ start, end });
    }
    for (const id of Object.keys(by)) by[id] = mergeBusy(by[id]);
    return by;
  }

  /**
   * The units that can seat `party` from `start` to `end` (ms), free on every
   * table they use, ordered as openresto does: the smallest that fits first;
   * at the same size a table that combines with nothing, then one that
   * combines, then a combo (so combinable tables stay free for the big
   * parties that need them pushed together); then priority (higher first),
   * then the lowest id. Walk-in-only tables are left out unless `walkIn`.
   * `only` (a unit key) is the host's own pick: any size, only if it is free.
   */
  function candidates(tables, taken, party, start, end, { walkIn = false, only = null } = {}) {
    if (!(party > 0)) return [];
    const span = { start, end };
    return units(tables)
      .filter((u) => (only ? only === u.key : (walkIn || !u.walkIn) && party >= u.min && party <= u.max))
      .filter((u) => u.ids.every((id) => !(taken[id] || []).some((x) => overlaps(x, span))))
      .sort((a, b) => a.max - b.max || a.tier - b.tier || b.priority - a.priority || a.ids[0] - b.ids[0]);
  }
  const assign = (...a) => candidates(...a)[0] || null;

  /** Covers that start in a service of a day, for its cap. */
  function coversIn(bookings, day, service, except) {
    return (bookings || []).filter((b) => HOLDING.includes(b.status) && b.day === day && b.service === service && Number(b._id) !== Number(except))
      .reduce((n, b) => n + (Number(b.party) || 0), 0);
  }

  /**
   * The party sizes (1 … max online) a start can still seat: a unit free for
   * the whole stay, and the service's cover cap not passed.
   */
  function sizesAt(slot, s, tables, taken, bookings) {
    const max = Number(s.max_online_party) || 8;
    const start = Date.parse(slot.start_at);
    const used = slot.max_covers ? coversIn(bookings, slot.day, slot.service) : 0;
    const out = [];
    for (let p = 1; p <= max; p += 1) {
      if (slot.max_covers && used + p > slot.max_covers) break;
      if (assign(tables, taken, p, start, start + stayFor(s, p) * 60000)) out.push(p);
    }
    return out;
  }

  /** Up to `n` other times the same day that seat `party`, nearest first, then in order. */
  function nearby(options, wantedIso, party, n = 3) {
    const w = Date.parse(wantedIso);
    return (options || []).filter((o) => o.start_at !== wantedIso && sizesOf(o).includes(Number(party)))
      .sort((a, b) => Math.abs(Date.parse(a.start_at) - w) - Math.abs(Date.parse(b.start_at) - w)).slice(0, n)
      .sort((a, b) => Date.parse(a.start_at) - Date.parse(b.start_at)).map((o) => ({ start_at: o.start_at, time: o.time }));
  }
  /** '|1|2|4|' (how tb_times keeps them) or an array, as numbers. */
  const sizesOf = (o) => (Array.isArray(o.sizes) ? o.sizes : String(o.sizes || '').split('|').filter(Boolean).map(Number));
  const sizesText = (list) => (list.length ? `|${list.join('|')}|` : '');

  // ── the guest's link ───────────────────────────────────────────────────
  // A public view cannot require a filter, so what it holds means nothing
  // without the link (Invoices' pattern): k = SHA-256("tb-k:"+token) finds the
  // row, the row is AES-GCM sealed with SHA-256("tb-e:"+token). The token
  // lives after the link's '#', never sent to a server. WebCrypto, so the same
  // code runs in Node (scripts, tests) and in the browser.
  const subtle = () => (globalThis.crypto && globalThis.crypto.subtle) || null;
  const enc = (x) => new TextEncoder().encode(x);
  const b64u = (bytes) => btoa(String.fromCharCode(...new Uint8Array(bytes))).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  const unb64u = (x) => Uint8Array.from(atob(String(x).replace(/-/g, '+').replace(/_/g, '/') + '==='.slice((String(x).length + 3) % 4)), (c) => c.charCodeAt(0));
  const hex = (bytes) => [...new Uint8Array(bytes)].map((b) => b.toString(16).padStart(2, '0')).join('');
  const TOKEN = /^[A-Za-z0-9_-]{22,64}$/;
  function newToken() { const b = new Uint8Array(16); globalThis.crypto.getRandomValues(b); return b64u(b); }
  async function linkKey(token) { return hex(await subtle().digest('SHA-256', enc(`tb-k:${token}`))); }
  async function boxKey(token, use) { return subtle().importKey('raw', await subtle().digest('SHA-256', enc(`tb-e:${token}`)), { name: 'AES-GCM' }, false, [use]); }
  async function seal(token, obj) {
    const iv = new Uint8Array(12);
    globalThis.crypto.getRandomValues(iv);
    const ct = await subtle().encrypt({ name: 'AES-GCM', iv }, await boxKey(token, 'encrypt'), enc(JSON.stringify(obj)));
    const out = new Uint8Array(12 + ct.byteLength);
    out.set(iv, 0);
    out.set(new Uint8Array(ct), 12);
    return b64u(out);
  }
  async function open(token, box) {
    try {
      const all = unb64u(box);
      const pt = await subtle().decrypt({ name: 'AES-GCM', iv: all.slice(0, 12) }, await boxKey(token, 'decrypt'), all.slice(12));
      return JSON.parse(new TextDecoder().decode(pt));
    } catch { return null; }
  }

  /** Until when a guest may change or cancel from the link (Settings' hours before). */
  const changeUntil = (b, s) => Date.parse(b.start_at) - (Number(s.change_notice_hours ?? 2) || 0) * 3600000;
  /** What the guest's page shows: nothing the guest did not give, plus the place. */
  function snapshot(b, s, extra) {
    const tz = validZone(s.timezone || 'UTC');
    const d = new Date(b.start_at);
    return {
      v: 1, id: Number(b._id), status: b.status, name: b.name || '', party: Number(b.party) || 0,
      start_at: b.start_at, day: b.day || localDay(d, tz), time: localTime(d, tz), tz, service: b.service || '',
      note: b.note || '', allergies: b.allergies || '', lang: b.lang === 'en' ? 'en' : 'es', reason: b.reason || '',
      guest_confirmed: Boolean(b.guest_confirmed_at), change_until: isoZ(changeUntil(b, s)),
      biz: { name: s.business_name || '', address: s.address || '', phone: s.phone || '' },
      ...(extra || {}),
    };
  }

  // ── emails (the guest's language; Spanish uses tú) ─────────────────────
  const dayLong = (iso, tz, lang) => new Intl.DateTimeFormat(lang === 'en' ? 'en-GB' : 'es-ES', { timeZone: tz, weekday: 'long', day: 'numeric', month: 'long' }).format(new Date(iso));
  const WORDS = {
    es: {
      people: (n) => `${n} ${n === 1 ? 'persona' : 'personas'}`, hi: (n) => `Hola${n ? ` ${n}` : ''},`,
      manage: 'Para confirmar, cambiar o cancelar', call: (p) => `Si necesitas algo, responde a este correo${p ? ` o llámanos al ${p}` : ''}.`,
      confirmed: ['Reserva confirmada', 'Tu mesa está reservada:'], requested: ['Hemos recibido tu solicitud', 'Hemos recibido tu solicitud de reserva. Te escribimos en cuanto la confirmemos:'],
      changed: ['Reserva cambiada', 'Hemos cambiado tu reserva. Ahora es:'], cancelled: ['Reserva cancelada', 'Tu reserva está cancelada:'],
      declined: ['No podemos confirmar tu reserva', 'Lo sentimos: no podemos confirmar esta reserva:'], reminder: ['Te esperamos', '¿Sigues viniendo? Te esperamos:'],
      full: ['No tenemos mesa a esa hora', 'Lo sentimos: a esa hora no tenemos mesa para'], others: 'Tenemos sitio a estas horas:', again: 'Para reservar otra hora',
      tap: 'Confirma o cancela aquí',
    },
    en: {
      people: (n) => `${n} ${n === 1 ? 'person' : 'people'}`, hi: (n) => `Hello${n ? ` ${n}` : ''},`,
      manage: 'To confirm, change or cancel', call: (p) => `If you need anything, reply to this email${p ? ` or call us on ${p}` : ''}.`,
      confirmed: ['Booking confirmed', 'Your table is booked:'], requested: ['We have your request', 'We have your booking request. We will write as soon as it is confirmed:'],
      changed: ['Booking changed', 'We changed your booking. It is now:'], cancelled: ['Booking cancelled', 'Your booking is cancelled:'],
      declined: ['We cannot confirm your booking', 'We are sorry: we cannot confirm this booking:'], reminder: ['See you soon', 'Are you still coming? We are expecting you:'],
      full: ['No table at that time', 'We are sorry: at that time we have no table for'], others: 'We have room at these times:', again: 'To book another time',
      tap: 'Confirm or cancel here',
    },
  };
  /**
   * One email to the guest, in plain text: confirmed, requested, changed,
   * cancelled, declined, reminder, or full (with other times). `link` is the
   * guest's own page; `page` the booking page.
   */
  function email(kind, b, s, { link = '', page = '', others = [] } = {}) {
    const lang = b.lang === 'en' ? 'en' : 'es';
    const w = WORDS[lang];
    const tz = validZone(s.timezone || 'UTC');
    const biz = s.business_name || '';
    const when = `${dayLong(b.start_at, tz, lang)}, ${localTime(new Date(b.start_at), tz)}`;
    const facts = [when, w.people(Number(b.party) || 0), [biz, s.address].filter(Boolean).join(', ')].filter(Boolean).join('\n');
    const first = String(b.name || '').trim().split(/\s+/)[0] || '';
    const [title, lead] = w[kind];
    const lines = [w.hi(first), ''];
    if (kind === 'full') {
      lines.push(`${lead} ${w.people(Number(b.party) || 0)} (${when}).`);
      if (others.length) lines.push('', w.others, ...others.map((o) => `· ${o.time}`));
      if (page) lines.push('', `${w.again}: ${page}`);
    } else {
      lines.push(lead, '', facts);
      if (b.note && kind !== 'cancelled') lines.push(lang === 'en' ? `Note: ${b.note}` : `Nota: ${b.note}`);
      if (link && kind === 'reminder') lines.push('', `${w.tap}: ${link}`);
      else if (link && !['cancelled', 'declined'].includes(kind)) lines.push('', `${w.manage}: ${link}`);
      if (page && ['cancelled', 'declined'].includes(kind)) lines.push('', `${w.again}: ${page}`);
    }
    lines.push('', w.call(s.phone), '', biz);
    return { subject: `${title}${biz ? ` · ${biz}` : ''}${kind === 'full' ? '' : ` · ${when}`}`, body: lines.join('\n') };
  }

  // ── where bookings come from ───────────────────────────────────────────
  /** A channel tag from the page's ?src= (or a marketplace's name from the desk): letters, digits, - and _, 40 at most. */
  const srcOf = (v) => String(v || '').trim().replace(/[^\p{L}\p{N} _-]/gu, '').slice(0, 40);
  /** Booked straight with the restaurant online (the page) or by email: what would otherwise likely come through a marketplace. */
  const DIRECT = ['web', 'email'];
  const SOURCES = { web: 'Booking page', email: 'Email', phone: 'Phone', walkin: 'Walk-in', market: 'Marketplace', desk: 'Desk', import: 'Imported' };
  /** "Instagram" for web+instagram, "TheFork" for market+TheFork, "Phone" … */
  const sourceLabel = (source, src) => (source === 'market' && src ? src : source === 'web' && src ? `Booking page · ${src}` : SOURCES[source || 'web'] || source);

  // ── guests ─────────────────────────────────────────────────────────────
  const normEmail = (e) => String(e || '').trim().toLowerCase();
  const isEmail = (e) => /^[^\s@<>(),;:"]+@[^\s@<>(),;:"]+\.[a-z]{2,}$/i.test(String(e || '').trim()) && String(e).length <= 200;
  /** Digits and a leading +, so '+34 600 11 22 33' and '600112233' can be told the same person (last 9 digits). */
  const normPhone = (p) => { const s = String(p || '').replace(/[^\d+]/g, ''); return s.length >= 6 ? s : ''; };
  const phoneKey = (p) => normPhone(p).replace(/\D/g, '').slice(-9);

  /** A CSV (comma, semicolon or tab; quotes) as rows of cells. */
  function parseCsv(text) {
    const t = String(text || '').replace(/^﻿/, '');
    const head = t.split(/\r?\n/)[0] || '';
    const sep = [';', '\t', ','].reduce((best, c) => (head.split(c).length > head.split(best).length ? c : best), ',');
    const rows = [];
    let row = [];
    let cell = '';
    let q = false;
    for (let i = 0; i < t.length; i += 1) {
      const c = t[i];
      if (q) {
        if (c === '"' && t[i + 1] === '"') { cell += '"'; i += 1; } else if (c === '"') q = false; else cell += c;
      } else if (c === '"') q = true;
      else if (c === sep) { row.push(cell); cell = ''; }
      else if (c === '\n' || c === '\r') {
        if (c === '\r' && t[i + 1] === '\n') i += 1;
        row.push(cell); cell = '';
        if (row.some((x) => x.trim())) rows.push(row);
        row = [];
      } else cell += c;
    }
    row.push(cell);
    if (row.some((x) => x.trim())) rows.push(row);
    return rows;
  }
  /** Which column is which, from the header of a TheFork, CoverManager or Quandoo export (or any similar one). */
  const COLUMNS = {
    first: /^(first ?name|nombre|pr[eé]nom|vorname|given name)$/i, last: /^(last ?name|surname|apellidos?|nom|nachname|family name)$/i,
    name: /^(name|full ?name|guest( name)?|customer( name)?|cliente|nombre (y|completo).*|nombre del cliente)$/i,
    email: /e-?mail|correo/i, phone: /phone|tel[eé]fono|m[oó]vil|mobile|^tel/i, notes: /^(notes?|notas?|comments?|comentarios?|observaciones|remarks|guest notes?|customer notes?)$/i,
    allergies: /aller|alerg|intoler/i, visits: /visits?|visitas|^(number of )?(reservations?|bookings?)$|^reservas|n[ºo°]? ?(de )?reservas|total reservations/i, vip: /^vip|vip$/i,
  };
  function mapColumns(header) {
    const map = {};
    (header || []).forEach((h, i) => {
      const x = String(h || '').trim();
      for (const [k, re] of Object.entries(COLUMNS)) if (map[k] === undefined && re.test(x)) { map[k] = i; break; }
    });
    return map;
  }
  /** Rows → guests {name, email, phone, notes, allergies, visits, vip}; rows with neither email nor phone are left out. */
  function guestsFrom(rows, map) {
    const at = (r, k) => (map[k] === undefined ? '' : String(r[map[k]] || '').trim());
    return rows.map((r) => {
      const name = at(r, 'name') || [at(r, 'first'), at(r, 'last')].filter(Boolean).join(' ');
      const email = normEmail(at(r, 'email'));
      return {
        name: name.slice(0, 120), email: isEmail(email) ? email : '', phone: normPhone(at(r, 'phone')).slice(0, 25),
        notes: at(r, 'notes').slice(0, 1000), allergies: at(r, 'allergies').slice(0, 300),
        visits: Math.max(0, Math.min(9999, parseInt(at(r, 'visits'), 10) || 0)), vip: /^(1|yes|s[ií]|true|x|vip)$/i.test(at(r, 'vip')) ? 'yes' : 'no',
      };
    }).filter((g) => g.email || g.phone);
  }

  return {
    DAYS, HOLDING, HOST_SOURCES, MAX_PARTY, TOKEN, WORDS,
    jsonOf, validZone, parts, localDay, localTime, isoZ, toMin, hhmm, addDays, weekday, realDay, localToUtc,
    daysOf, servicesOn, startsOn, stayFor, check, problemText,
    mergeBusy, overlaps, units, takenFrom, candidates, assign, coversIn, sizesAt, nearby, sizesOf, sizesText,
    newToken, linkKey, seal, open, changeUntil, snapshot, dayLong, email,
    normEmail, isEmail, normPhone, phoneKey, parseCsv, mapColumns, guestsFrom, srcOf, DIRECT, SOURCES, sourceLabel,
  };
}));
