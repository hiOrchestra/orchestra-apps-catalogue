// The router and the bar. Today is home: the service sheet. A day of the
// coming days opens the same sheet (/day/<YYYY-MM-DD>). Requests is what waits
// for an OK (bookings and the replies to approve); Guests, Tables, Sources and
// Settings are the rest.
import { render as today } from './screens/today.js';
import { render as upcoming } from './screens/upcoming.js';
import { render as requests } from './screens/requests.js';
import { render as guests } from './screens/guests.js';
import { render as tables } from './screens/tables.js';
import { render as sources } from './screens/sources.js';
import { render as settings } from './screens/settings.js';
import { T } from './data.js';

const { el, router } = Orch;

router.define({
  '/': today,
  '/day/:day': today,
  '/upcoming': upcoming,
  '/requests': requests,
  '/requests/:tab': requests,
  '/guests': guests,
  '/guests/:state': guests,
  '/tables': tables,
  '/sources': sources,
  '/settings': settings,
}, () => Orch.mount('view', el('div', { class: 'oc-state' }, [
  el('p', 'There is no screen here.'), router.link('/', 'Go to today'),
]))).start();

const waiting = el('span', { class: 'oc-count', hidden: true });
Orch.mount('nav', [
  router.link('/', 'Today', { class: 'oc-tab' }),
  router.link('/upcoming', 'Upcoming', { class: 'oc-tab' }),
  router.link('/requests', ['Requests', waiting], { class: 'oc-tab' }),
  router.link('/guests', 'Guests', { class: 'oc-tab' }),
  router.link('/tables', 'Tables', { class: 'oc-tab' }),
  router.link('/sources', 'Sources', { class: 'oc-tab' }),
  router.link('/settings', 'Settings', { class: 'oc-tab' }),
]);

/** How many things wait for an OK, on the Requests tab; again when a screen changes. */
async function count() {
  try {
    const [b, e] = await Promise.all([
      Orch.db.count(T.bookings, { filter: { status: 'Requested' } }),
      Orch.db.count(T.emails, { filter: { status: ['Review', 'Failed'] } }),
    ]);
    const n = Number(b || 0) + Number(e || 0);
    waiting.textContent = String(n);
    waiting.hidden = !n;
  } catch { /* the tab still works */ }
}
count();
window.addEventListener('hashchange', () => setTimeout(count, 400));
window.addEventListener('tables:changed', () => setTimeout(count, 400));
