SELECT k, box FROM tb_links
