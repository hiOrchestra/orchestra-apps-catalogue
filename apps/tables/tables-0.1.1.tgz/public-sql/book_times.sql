SELECT t.day, t.time, t.start_at, t.service, t.sizes
FROM tb_times t
WHERE t.start_at > strftime('%Y-%m-%dT%H:%M:%SZ', 'now')
  AND COALESCE((SELECT paused FROM tb_settings ORDER BY _id LIMIT 1), 'no') <> 'yes'
