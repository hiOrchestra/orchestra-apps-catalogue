SELECT business_name, address, phone, intro, timezone, languages, default_lang, interval_min,
       max_online_party, min_notice_min, window_days, change_notice_hours, COALESCE(paused, 'no') AS paused
FROM tb_settings ORDER BY _id LIMIT 1
