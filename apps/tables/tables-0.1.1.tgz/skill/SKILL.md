---
name: app-tables
version: 0.1.1
description: >-
  Work with the Tables app (restaurant bookings on this workspace): who comes
  today and at which table, whether there is a table for N at a time, booking
  a table for a guest, marking arrived or no-show, moving or cancelling a
  booking, the guests (visits, no-shows, allergies, VIPs), the tables and the
  hours, and where bookings come from. Use when someone says "who's coming
  tonight / quién viene hoy", "do we have a table for 4 on Friday at 9 /
  ¿tenemos mesa para 4 el viernes a las 21?", "book 4 for Saturday / reservá
  para 4 el sábado", "mark Ana as no-show / marcá no-show a Ana", "Ana has
  arrived / llegó Ana", "move the Pérez booking to 21:30 / cambiá la reserva de
  Pérez a las 21:30", "cancel the booking for 6 / cancelá la de 6", "any
  allergies tonight? / ¿alergias hoy?", "where do our bookings come from? /
  ¿de dónde vienen las reservas?", "how much did we save on commissions? /
  ¿cuánto ahorré en comisiones?", "close on the 24th / cerramos el 24". Needs
  the Tables app installed in a project you work in.
metadata:
  openclaw:
    emoji: "🍽️"
---
# Tables — restaurant bookings, the service sheet, the guests

Guests book on a public page (Canvas app `tables-book`); the host runs the
service from the desk (`tables`): Today's sheet, walk-ins, phone bookings,
requests to approve, guests, tables, sources and settings. Every booking —
the page, the desk, an email, you — goes through ONE door: a row in
`tb_bookings` with status `New`, judged by the **Take bookings** workflow
(`intake.js` → `seat.js`), which applies the rules and picks the table. You
never pick a table or confirm a booking by writing it yourself.

## Is it installed

```bash
ls -d ~/.openclaw/orchestra/projects/*/apps/tables      # the project id is the directory under projects/
P=<project id>
cat ~/.openclaw/orchestra/projects/$P/apps/tables/workflows.json   # {"intake":…, "times":…, "send":…, "import":…, "mail":…, "brief":…}
orch-database --project $P tables                        # tb_settings, tb_bookings, tb_tables, tb_guests, tb_times…
```

If nothing is there, Tables is not installed where you work: say so, and do
not take bookings some other way.

## The model

| Table | One row per |
|---|---|
| `tb_settings` | one row: `business_name`, `address`, `phone`, `timezone` (IANA), `interval_min`, `default_stay_min`, `stay_rules` (JSON `[{"min":5,"minutes":120}]`: from that many people, that long), `max_online_party`, `min_notice_min`, `window_days`, `change_notice_hours`, `policy` (`auto` / `review`), `paused`, `emails_on`, `gmail_status`, `reminder_hours`, `mail_on`, `brief_on`, `brief_time`, `agent`, `marketplaces`, `channels`, `market_fee`, `currency`, `public_url`, `desk_url` |
| `tb_services` | a service: `name` (Lunch, Dinner), `days` (`mon,tue,…`), `first_time` / `last_time` (`HH:MM`, the first and last time a table can be booked; last before first runs past midnight), `max_covers` (0 = no cap), `active` |
| `tb_exceptions` | a date: `day`, `kind` (`closed` or `hours`), `services` (JSON `[{"name","first","last"}]` for `hours`), `note`, `active`. It REPLACES that day's weekly services |
| `tb_tables` | a table: `name`, `area`, `min_seats`, `max_seats`, `combine` (tables with the same name are pushed together for big groups), `walk_in_only` (`yes`: never given online), `priority` (higher first at the same size), `active` |
| `tb_bookings` | a booking: `name`, `email`, `phone`, `party`, `start_at` / `end_at` (UTC `YYYY-MM-DDTHH:MM:SSZ`), `day` (local service day), `service`, `table_ids`, `table_label`, `status`, `reason`, `source` (`web`, `email`, `phone`, `walkin`, `market`), `src` (the page's channel: instagram…; or the marketplace's name), `note`, `allergies`, `special`, `token` (the guest's link), `pending` (a move the desk asked for), `notice` (an email the guest is owed) |
| `tb_guests` | a guest: `name`, `email`, `phone`, `notes`, `allergies`, `vip`, `imported_visits`, `first_source` / `first_src` (how they first came) |
| `tb_times` | a start time: `day`, `time`, `start_at`, `service`, `sizes` (`|1|2|4|`: the party sizes still seatable). Written only by Offer times |
| `tb_emails` | an email to a guest: `kind`, `to_email`, `subject`, `body`, `status` (Review → Approved → Sending → Sent; Failed; Dropped) |
| `tb_mail` | a booking email read from Gmail (optional): `from_email`, `subject`, `body`, `status`, `intent`, `result` |

Times: say them in `tb_settings.timezone`. Read with read-only SQL
(`orch-database --project $P query "SELECT …"`); the desk's views `sources` and
`guests_list` are in the app's `sql/` folder, and their SQL works as a query.

Statuses: **New** (just arrived; judged in seconds) → **Confirmed** (has its
table) → **Arrived** or **NoShow**. Outside the rules: **Requested** (waits for
the host's OK: a large party, a special request, or `policy = review`; may hold
a table) → Approving → Confirmed, or **Declined**. **Failed**: could not be
booked (`reason`: full, closed, too soon…; `offer` has other times).
**Cancelled** (`cancelled_by` guest or host). **Discarded**: not a person.

## How you act

Run a workflow with `orch-workflows run <id> --args '{"mode":"--now"}'` (ids
in `workflows.json`). Write with `orch-database --project $P batch --ops '[…]'`,
always with a `when` on the status, copying exactly what the desk's action
writes:

| To | Write | Then run |
|---|---|---|
| Book a table (phone, someone asks you) | insert `tb_bookings` `{name, phone, email, party, start_at, note, allergies, source: "phone", status: "New"}` (`source: "market", src: "TheFork"` when it came from a marketplace) | Take bookings; read the row back: Confirmed with its `table_label`, or Failed with `reason` and `offer` |
| A walk-in | the same with `source: "walkin"`, `start_at` now | Take bookings |
| Arrived / No-show | update `status` Confirmed → `Arrived` (`arrived_at`) or `NoShow` (`when: {"status":"Confirmed"}`) | — |
| Move (time, people or table) | update `pending` = JSON `{"start_at":…, "party":…, "table":"auto" or "t<id>"}` | Take bookings; `pending` empties; `pending_note` says why when it could not |
| Approve a request | update Requested → `Approving` | Take bookings |
| Decline a request | update Requested → `Declined`, `notice: "declined"`, `table_ids: ""` | Take bookings (it emails the guest) |
| Cancel | update Confirmed → `Cancelled`, `cancelled_by: "host"`, `notice: "cancelled"` | Take bookings (it emails the guest) |
| Hours, tables, rules | update `tb_services` / `tb_exceptions` / `tb_tables` / `tb_settings` | Offer times |

Rules:
- **Ask before anything the guest hears**: cancelling, declining, a move that
  changes the time or the size (the guest gets an email when emails are on),
  turning emails on, turning booking emails on. Say what will be sent.
- Never write `table_ids`, `status = 'Confirmed'` or `tb_times` yourself: the
  door decides, so two people never get the same table.
- Never send email yourself, and never write in `tb_emails` as Approved. A
  reply you draft for a guest goes in as `status: "Review"`: the host sends it.
- Pausing online bookings (`paused = 'yes'`) takes every time off the page at
  once: ask first.

## Recipes

- **"¿Tenemos mesa para 4 el viernes a las 21?"** — the day's rows in
  `tb_times` (`day = '<date>'`): the one at `time = '21:00'` seats 4 if `sizes`
  contains `|4|`. If not, offer the nearest times that do. Over
  `max_online_party` it is a request the host approves.
- **"Quién viene hoy"** — `SELECT * FROM tb_bookings WHERE day = '<today>' AND status IN ('Confirmed','Arrived','Requested') ORDER BY start_at`:
  time, name, party, table, notes and allergies; say covers per service, the
  groups of 6+, allergies and VIPs (join `tb_guests`).
- **"Reservá para 4 el sábado a las 21:30 a nombre de Luis, 600…"** — the
  booking insert above, run Take bookings, then say the table it got or why
  not, with the other times in `offer`.
- **"Marcá no-show a Ana"** — find today's Confirmed booking by name (ask if
  two match), update to NoShow.
- **"¿De dónde vienen las reservas?"** — the view `sources` for this month
  (`month = 'YYYY-MM'`): bookings and covers per `source`/`src`.
- **"¿Cuánto ahorré en comisiones?"** — covers from `source IN ('web','email')`
  this month × `tb_settings.market_fee`. Say it is an estimate (what those
  covers would have cost on a marketplace), in `currency`, and that phone and
  walk-ins are not counted. Recovered guests: `guests_list` with `recovered = 'yes'`.
- **"Cerramos el 24"** — insert `tb_exceptions {day, kind: "closed", active: "yes"}`, run Offer times.
  Bookings already on that day stay: list them so the host can call.

## Optional, off by default

- **Booking emails** (`mail_on`): the agent reads booking emails in the
  restaurant's Gmail (workflow Booking emails, JSON only); a script books,
  changes or cancels inside the rules and drafts everything else for review.
- **Service brief** (`brief_on`, `brief_time`): facts of the day plus a few
  lines from the agent, on Today and Telegram.

If someone asks you to answer a booking email, put your draft in Review
(above); do not send it.
