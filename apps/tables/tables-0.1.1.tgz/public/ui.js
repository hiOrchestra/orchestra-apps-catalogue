// The pieces of the booking page: the header, a state, the day, the number of
// people, the times, the guest's details. Times are the restaurant's own (a
// table is booked in the restaurant's clock), said as such when the guest's
// browser is elsewhere.
import { WORDS } from './words.js';

const { el } = Orch;
const C = window.TableCore;

export const ctx = { lang: 'es', tz: 'Europe/Madrid', page: {} };
export const w = () => WORDS[ctx.lang] || WORDS.es;
const locale = () => (ctx.lang === 'en' ? 'en-GB' : 'es-ES');
const fmt = (o) => new Intl.DateTimeFormat(locale(), Object.assign({ timeZone: 'UTC' }, o));
export const dayLong = (day) => fmt({ weekday: 'long', day: 'numeric', month: 'long' }).format(new Date(`${day}T12:00:00Z`));
const dayShort = (day) => fmt({ weekday: 'short', day: 'numeric' }).format(new Date(`${day}T12:00:00Z`));
export const timeOf = (iso) => C.localTime(new Date(iso), ctx.tz);
const cap = (s) => s.charAt(0).toUpperCase() + s.slice(1);

export function state(title, text, extra) {
  return el('section', { class: 'tp-card tp-state', 'aria-live': 'polite' }, [el('h1', { class: 'tp-title', tabindex: '-1' }, title), text ? el('p', { class: 'tp-text' }, text) : null, ...[].concat(extra || [])]);
}

/** The restaurant's name, its address, its line, and the language switch. */
export function top(onLang) {
  const p = ctx.page;
  const langs = String(p.languages || 'es,en').split(',').map((x) => x.trim()).filter((x) => WORDS[x]);
  return el('header', { class: 'tp-top' }, [
    el('div', { class: 'tp-top__line' }, [
      el('p', { class: 'tp-name' }, p.business_name || ''),
      langs.length > 1 ? el('div', { class: 'tp-langs', role: 'group', 'aria-label': 'Language' }, langs.map((l) => el('button', { type: 'button', class: 'tp-lang', 'aria-pressed': String(l === ctx.lang), lang: l, onClick: () => onLang(l) }, l.toUpperCase()))) : null,
    ]),
    p.address ? el('p', { class: 'tp-addr' }, p.address) : null,
    p.intro ? el('p', { class: 'tp-text' }, p.intro) : null,
  ]);
}

export const back = (label, go) => el('button', { type: 'button', class: 'tp-back', onClick: go }, `← ${label}`);

/** What was chosen so far, each part with its own way back. */
export function chosen(parts) {
  return el('div', { class: 'tp-chosen' }, parts.filter(Boolean).map(([value, go]) => el('button', { type: 'button', class: 'tp-chosen__part', onClick: go, 'aria-label': `${w().change}: ${value}` }, [el('span', value), el('span', { class: 'tp-chosen__edit' }, w().change)])));
}

/** The next two weeks as buttons, and a date box for further. */
export function dayPicker(days, current, onPick) {
  const today = days[0];
  const tomorrow = C.addDays(today, 1);
  const other = el('input', { type: 'date', class: 'oc-input tp-date', min: today, max: days.max, value: current && !days.includes(current) ? current : '', 'aria-label': w().other });
  other.addEventListener('change', () => { if (C.realDay(other.value)) onPick(other.value); });
  return el('div', { class: 'tp-pick' }, [
    el('div', { class: 'tp-days', role: 'group', 'aria-label': w().when }, days.map((d) => el('button', { type: 'button', class: 'tp-day', 'aria-pressed': String(d === current), onClick: () => onPick(d) }, [
      el('span', { class: 'tp-day__top' }, d === today ? w().today : d === tomorrow ? w().tomorrow : cap(dayShort(d).split(' ')[0].replace('.', ''))),
      el('span', { class: 'tp-day__n' }, String(Number(d.slice(8)))),
    ]))),
    el('label', { class: 'tp-other' }, [el('span', w().other), other]),
  ]);
}

export function partyPicker(max, current, onPick) {
  const n = Math.max(1, Math.min(12, max));
  const big = el('input', { type: 'number', class: 'oc-input tp-num', min: String(n + 1), max: '60', placeholder: String(n + 1), 'aria-label': w().howMany });
  big.addEventListener('change', () => { const v = Number(big.value); if (v > n) onPick(v); });
  return el('div', { class: 'tp-pick' }, [
    el('div', { class: 'tp-people', role: 'group', 'aria-label': w().people }, Array.from({ length: n }, (_, i) => i + 1).map((k) => el('button', { type: 'button', class: 'tp-person', 'aria-pressed': String(k === current), onClick: () => onPick(k) }, String(k)))),
    el('label', { class: 'tp-other' }, [el('span', w().more(n)), big]),
  ]);
}

/** The day's times by service: the ones that seat this party as buttons, the rest marked full. A large party sees every time (it is a request). */
export function timeGrid(rows, party, large, onPick) {
  const services = [];
  for (const r of rows) {
    if (!services.length || services[services.length - 1].name !== r.service) services.push({ name: r.service, rows: [] });
    services[services.length - 1].rows.push(r);
  }
  return el('div', { class: 'tp-times' }, services.map((sv) => el('section', { class: 'tp-service' }, [
    el('h2', { class: 'tp-h2' }, sv.name),
    el('div', { class: 'tp-grid' }, sv.rows.map((r) => {
      const ok = large || C.sizesOf(r).includes(party);
      return el('button', { type: 'button', class: 'tp-time', disabled: !ok, onClick: () => onPick(r) }, ok ? r.time : [r.time, el('span', { class: 'tp-time__full' }, w().full)]);
    })),
  ])));
}

/** Name, email, phone, a note, allergies, the special-request box; a trap only bots fill in. */
export function details(saved, large) {
  const t = w();
  const field = (label, control, help) => el('label', { class: 'oc-field tp-field' }, [el('span', { class: 'oc-label' }, label), control, help ? el('span', { class: 'oc-help' }, help) : null]);
  const inp = (attrs) => el('input', Object.assign({ class: 'oc-input' }, attrs));
  const name = inp({ name: 'name', autocomplete: 'name', required: true, maxlength: '120', value: saved.name || '' });
  const email = inp({ name: 'email', type: 'email', autocomplete: 'email', required: true, maxlength: '200', value: saved.email || '' });
  const phone = inp({ name: 'phone', type: 'tel', autocomplete: 'tel', maxlength: '30', value: saved.phone || '' });
  const note = el('textarea', { class: 'oc-textarea', name: 'note', rows: '2', maxlength: '500', placeholder: t.notePh });
  const allergies = inp({ name: 'allergies', maxlength: '300', value: saved.allergies || '' });
  const special = el('input', { type: 'checkbox', name: 'special', checked: Boolean(large) });
  const trap = el('input', { class: 'tp-trap', type: 'text', name: 'website_url', tabindex: '-1', autocomplete: 'off', 'aria-hidden': 'true' });
  return {
    nodes: [field(t.name, name), field(t.email, email, t.emailHelp), field(t.phone, phone, t.phoneHelp), field(t.note, note), field(t.allergies, allergies),
      large ? null : el('label', { class: 'tp-special' }, [special, el('span', t.special)]), trap],
    read: () => ({ name: name.value.trim(), email: email.value.trim(), phone: phone.value.trim(), note: note.value.trim(), allergies: allergies.value.trim(), special: special.checked ? 'yes' : 'no', hp: trap.value }),
  };
}

/** Other times the same day, as buttons. */
export function offer(list, onPick) {
  if (!list || !list.length) return null;
  return el('div', { class: 'tp-stack' }, [el('p', { class: 'tp-text' }, w().others), el('div', { class: 'tp-grid' }, list.map((o) => el('button', { type: 'button', class: 'tp-time', onClick: () => onPick(o) }, o.time)))]);
}
