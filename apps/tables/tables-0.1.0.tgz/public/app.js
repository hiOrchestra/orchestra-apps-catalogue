// The booking page: the day, how many, the time, who you are; inside the
// rules the table is yours at once. It reads three approved public views
// (book_page, book_times: a day, a time and the party sizes it can still
// seat, never who booked; book_links: sealed pages) and writes one public
// action (request), then asks for it to be judged (process, which carries
// nothing). The page makes the guest's link token itself, so it can open the
// answer the moment it is sealed. #/b/<token> is the guest's own page
// (guest.js). A ?src= on the link (instagram, google…) travels with the
// booking, so Sources can say which channel brings guests.
import { WORDS, reasonOf } from './words.js';
import { chosen, ctx, dayLong, dayPicker, details, offer, partyPicker, state, timeGrid, top, w } from './ui.js';
import { guestPage, waitBox } from './guest.js';

const { el, router } = Orch;
const C = window.TableCore;
const HOST = 'page';
const T0 = Date.now();
const WAITS = [3, 6, 12, 20, 30, 30];
const sleep = (ms) => new Promise((r) => { setTimeout(r, ms); });
const store = { get(k) { try { return JSON.parse(localStorage.getItem(k) || 'null') || {}; } catch { return {}; } }, set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch { /* private window */ } } };
const BASE = (() => { const p = location.pathname; const i = p.indexOf('/canvas/a/'); return i < 0 ? '.' : `${p.slice(0, i)}/canvas/a/${p.slice(i + 10).split('/')[0]}`; })();
// The channel this page was opened from (?src=instagram): read on purpose from location.search.
const SRC = (() => { try { return C.srcOf(new URLSearchParams(location.search).get('src')).toLowerCase(); } catch { return ''; } })();
const pick = { day: null, party: null, slot: null };

function show(...nodes) {
  Orch.mount(HOST, [top(setLang), ...nodes]);
  const h = document.querySelector('#page h1');
  if (h) h.focus({ preventScroll: true });
  window.scrollTo(0, 0);
}
function setLang(l) {
  ctx.lang = l;
  document.documentElement.lang = l;
  store.set('tables:lang', { l });
  router.go(location.hash.slice(1) || '/', { replace: true });
}
function trouble(e) {
  if (e.reason === 'public-view-pending' || e.status === 403) return show(state(w().notOpen, w().notOpenText));
  return show(state(w().loadFail, '', el('button', { type: 'button', class: 'oc-btn', onClick: () => location.reload() }, w().retry)));
}

let loaded = false;
async function loadPage() {
  if (loaded) return ctx.page;
  const r = await Orch.db.view('book_page', { limit: 1 });
  ctx.page = (r.rows || [])[0] || {};
  ctx.tz = C.validZone(ctx.page.timezone || 'Europe/Madrid');
  const langs = String(ctx.page.languages || 'es,en').split(',').map((x) => x.trim()).filter((x) => WORDS[x]);
  const asked = new URLSearchParams(location.search).get('lang') || store.get('tables:lang').l || (navigator.language || '').slice(0, 2);
  ctx.lang = langs.includes(asked) ? asked : (langs.includes(ctx.page.default_lang) ? ctx.page.default_lang : langs[0] || 'es');
  document.documentElement.lang = ctx.lang;
  loaded = true;
  return ctx.page;
}
const timesOf = async (filter) => (await Orch.db.view('book_times', { filter, sort: 'start_at:asc', limit: 500 })).rows || [];

async function home() {
  try { await loadPage(); } catch (e) { trouble(e); return; }
  const p = ctx.page;
  if (p.paused === 'yes') { show(state(w().closedPage, w().call(p.phone))); return; }
  const max = Number(p.max_online_party) || 8;
  const today = C.localDay(new Date(), ctx.tz);
  const days = Array.from({ length: 14 }, (_, i) => C.addDays(today, i));
  days.max = C.addDays(today, Number(p.window_days) || 60);
  if (!pick.day) {
    show(el('section', { class: 'tp-card' }, [el('h1', { class: 'tp-title', tabindex: '-1' }, w().when), dayPicker(days, null, (d) => { pick.day = d; home(); })]));
    return;
  }
  const says = chosen([[cap(dayLong(pick.day)), () => { pick.day = null; pick.party = null; home(); }], pick.party ? [w().p(pick.party), () => { pick.party = null; home(); }] : null]);
  if (!pick.party) {
    show(el('section', { class: 'tp-card' }, [says, el('h1', { class: 'tp-title', tabindex: '-1' }, w().people), partyPicker(max, null, (n) => { pick.party = n; home(); })]));
    return;
  }
  const large = pick.party > max;
  show(el('section', { class: 'tp-card' }, [says, el('h1', { class: 'tp-title', tabindex: '-1' }, w().time), el('p', { class: 'tp-text tp-muted' }, '…')]));
  let rows;
  try { rows = await timesOf({ day: pick.day }); } catch (e) { trouble(e); return; }
  const fits = rows.filter((r) => C.sizesOf(r).includes(pick.party));
  const body = [says, el('h1', { class: 'tp-title', tabindex: '-1' }, w().time)];
  if (large) body.push(el('p', { class: 'tp-note' }, w().large(max)));
  if (!rows.length) body.push(el('p', { class: 'tp-text' }, w().closed));
  else if (!fits.length && !large) body.push(el('p', { class: 'tp-text' }, w().noTimes(pick.party)));
  if (rows.length) body.push(timeGrid(rows, pick.party, large, (r) => { pick.slot = r; form(); }));
  if (!fits.length && !large) {
    const later = await timesOf({ day: { gt: pick.day, lte: C.addDays(pick.day, 14) } }).catch(() => []);
    const next = [...new Set(later.filter((r) => C.sizesOf(r).includes(pick.party)).map((r) => r.day))].slice(0, 4);
    if (next.length) body.push(el('p', { class: 'tp-text' }, w().tryDays), el('div', { class: 'tp-grid' }, next.map((d) => el('button', { type: 'button', class: 'tp-time tp-time--day', onClick: () => { pick.day = d; home(); } }, cap(dayLong(d))))));
  }
  if (ctx.tz !== Intl.DateTimeFormat().resolvedOptions().timeZone) body.push(el('p', { class: 'tp-note' }, w().localTime(ctx.tz.split('/').pop().replace(/_/g, ' '))));
  show(el('section', { class: 'tp-card' }, body));
}
const cap = (s) => s.charAt(0).toUpperCase() + s.slice(1);

function form() {
  const max = Number(ctx.page.max_online_party) || 8;
  const large = pick.party > max;
  const saved = store.get('tables:me');
  const d = details(saved, large);
  const visit = (self.crypto && crypto.randomUUID) ? crypto.randomUUID() : `${Date.now()}${Math.random()}`;
  const status = el('p', { class: 'tp-status', role: 'status', 'aria-live': 'polite' });
  const send = el('button', { type: 'submit', class: 'oc-btn oc-btn--primary tp-send' }, large ? w().request : w().book);
  const f = el('form', { class: 'tp-form' }, [
    chosen([[cap(dayLong(pick.day)), () => { pick.day = null; pick.slot = null; home(); }], [w().p(pick.party), () => { pick.party = null; pick.slot = null; home(); }], [pick.slot.time, () => { pick.slot = null; home(); }]]),
    el('h1', { class: 'tp-title', tabindex: '-1' }, w().you), ...d.nodes, send, status, el('p', { class: 'tp-note' }, w().privacy),
  ]);
  f.addEventListener('input', () => { const v = d.read(); store.set('tables:me', { name: v.name, email: v.email, phone: v.phone, allergies: v.allergies }); });
  f.addEventListener('submit', async (e) => {
    e.preventDefault();
    if (!f.reportValidity()) return;
    send.disabled = true;
    const v = d.read();
    const token = C.newToken();
    try {
      await request({ name: v.name, email: v.email, phone: v.phone, note: v.note, allergies: v.allergies, special: v.special, party: pick.party, start_at: pick.slot.start_at,
        lang: ctx.lang, token, src: SRC, hp: v.hp || '', ms: Date.now() - T0, visit }, status);
    } catch {
      send.disabled = false;
      status.textContent = w().failed;
      return;
    }
    processNow();
    try { localStorage.setItem('tables:last', token); } catch { /* private window */ }
    await result(token);
  });
  show(el('section', { class: 'tp-card' }, f));
}

async function request(params, status) {
  status.textContent = w().sending;
  for (let i = 0; ; i += 1) {
    try { return await Orch.action('request', params); } catch (e) {
      if (!(!e.status || e.status === 429 || e.status >= 500) || i >= WAITS.length) throw e;
      for (let s = WAITS[i]; s > 0; s -= 1) { status.textContent = w().busy(s); await sleep(1000); }
    }
  }
}
function processNow() {
  const body = new Blob([JSON.stringify({ params: {} })], { type: 'application/json' });
  try { if (navigator.sendBeacon && navigator.sendBeacon(`${BASE}/api/actions/process`, body)) return; } catch { /* below */ }
  Orch.action('process', {}).catch(() => { /* the half-hourly check takes it */ });
}

/** Wait for the sealed answer, then say it: booked, a request, or other times. */
async function result(token) {
  show(state(w().sending, w().waiting));
  const box = await waitBox(token, (b) => b && b.status !== 'New', 45000);
  if (!box) { show(state(w().requested, w().slow, linkLine(token))); return; }
  if (box.status === 'Failed') {
    const why = reasonOf(ctx.lang, box.reason) || w().taken;
    show(el('section', { class: 'tp-card tp-state' }, [el('h1', { class: 'tp-title', tabindex: '-1' }, w().notBooked), el('p', { class: 'tp-text' }, why),
      offer(box.offer, (o) => { pick.slot = { ...o, day: pick.day }; form(); }),
      el('button', { type: 'button', class: 'oc-btn', onClick: () => { pick.slot = null; home(); } }, w().pickOther)]));
    return;
  }
  router.go(`/b/${token}`, { replace: true });
}
const linkLine = (token) => el('p', { class: 'tp-note' }, [w().keep, ' ', el('a', { href: `#/b/${token}` }, w().yourLink)]);

router.define({
  '/': () => home(),
  '/b/:token': async ({ token }) => { try { await loadPage(); } catch (e) { trouble(e); return; } guestPage(token, { show, processNow, home: () => { pick.day = null; pick.party = null; pick.slot = null; router.go('/'); } }); },
}, () => home()).start();

