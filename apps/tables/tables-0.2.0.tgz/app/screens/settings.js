// Settings, one card per thing: the booking page (its link, one link per
// channel, pause), what is managed in Orchestra (the restaurant, the booking
// rules, sources, notices and the extras — Apps → Tables → Ajustes), the hours
// (hours.js), how long a table is kept, and emails to guests (emails.js).
// Each card saves only its own fields, so no card's rule can stop another's
// save; saving works out the free times again. Opening it looks at which of
// Gmail and Resend is connected when the last look is old.
import { A, C, act, code, head, input, lookIfStale, publicLink, settings } from '../data.js';
import { hoursCard } from './hours.js';
import { emailsCard } from './emails.js';

const { el, fmt } = Orch;

export function render() {
  Orch.load('view', async () => {
    const s = await settings();
    if (!s._id) return el('p', { class: 'oc-state' }, 'Tables is not installed in this project.');
    lookIfStale(s, render);
    return el('div', { class: 'oc-stack oc-stack--loose tb-settings' }, [
      head('Settings', 'How bookings work for your restaurant.'),
      page(s), managed(s), await hoursCard(s, render), stays(s), emailsCard(s, render),
    ]);
  });
}

function card(title, help, kids) {
  return el('section', { class: 'oc-card oc-stack' }, [el('h2', { class: 'oc-h2' }, title), help ? el('p', { class: 'oc-help tb-legible' }, help) : null, ...kids]);
}

/** A form that saves the listed controls with one action. */
function saver(s, action, controls, said, check) {
  const save = el('button', { type: 'submit', class: 'oc-btn oc-btn--primary' }, 'Save');
  const f = el('form', { class: 'oc-stack tb-form' });
  f.addEventListener('submit', async (e) => {
    e.preventDefault();
    const params = { id: s._id };
    for (const [k, node] of Object.entries(controls)) params[k] = node.type === 'number' || k === 'interval_min' ? Number(node.value) : (node.value === undefined ? node.get() : String(node.value).trim());
    if (check) { const why = check(params); if (why) { Orch.toast(why, { error: true }); return; } }
    save.disabled = true;
    if (await act(action, params, said || 'Saved.')) render();
    save.disabled = false;
  });
  return { f, save };
}

function page(s) {
  const paused = s.paused === 'yes';
  const b = el('button', { type: 'button', class: `oc-btn${paused ? ' oc-btn--primary' : ''}`, onClick: async () => {
    if (!paused && !(await Orch.confirm('Pause online bookings? Your page stops offering times at once. Bookings already made are not touched, and you can still add phone bookings.', { yes: 'Pause' }))) return;
    if (await act(paused ? A.resume : A.pause, { id: s._id }, paused ? 'Resumed: the times are back on your page in a moment.' : 'Paused: the page offers no times.')) render();
  } }, paused ? 'Resume online bookings' : 'Pause online bookings');
  const channels = C.listOf(s.channels).map((x) => C.srcOf(x).toLowerCase()).filter(Boolean);
  return card('Your booking page', 'Put it on Instagram, Google Maps and your website. Guests pick a day, how many they are and a time; inside your rules the table is theirs at once.', [
    el('div', { class: 'oc-row oc-row--between' }, [el('span', { class: 'oc-label' }, 'The link'), el('span', { class: `oc-badge${paused ? ' oc-badge--warn' : ' oc-badge--good'}` }, paused ? 'Paused' : 'Taking bookings')]),
    code(publicLink(s)),
    channels.length ? el('div', { class: 'oc-stack oc-stack--tight' }, [
      el('span', { class: 'oc-label' }, 'One link per channel'),
      el('p', { class: 'oc-help' }, 'The same page; each booking remembers which link it came from, so Sources can tell you which channel brings guests.'),
      ...channels.map((c) => el('div', { class: 'tb-channel' }, [el('span', { class: 'oc-value tb-channel__name' }, c), code(publicLink(s, c))])),
    ]) : null,
    s.times_note ? el('p', { class: 'oc-help' }, `${s.times_note}${s.times_built_at ? ` · worked out ${fmt.ago(s.times_built_at)}` : ''}.`) : null,
    el('div', { class: 'oc-row' }, b),
  ]);
}

// The restaurant, the booking rules, sources, where you hear about bookings and
// the optional extras are managed in Orchestra (Apps → Tables → Ajustes): typed,
// next to the agent that reads booking emails and writes the brief. Here, what
// they are now and a way there. Saving there works out the free times again.
function managed(s) {
  const link = el('a', { class: 'oc-btn oc-btn--primary', target: '_blank', rel: 'noopener', hidden: true }, 'Open the settings in Orchestra');
  const where = el('p', { class: 'oc-help' }, 'In Orchestra: Apps → Tables → Ajustes.');
  if (Orch.manageUrl) Orch.manageUrl('settings').then((url) => { if (url) { link.href = url; link.hidden = false; where.hidden = true; } });
  const minutes = (n) => (Number(n) % 60 === 0 && Number(n) >= 60 ? `${Number(n) / 60} h` : `${Number(n) || 0} min`);
  const facts = [
    ['Restaurant', s.business_name || 'not named yet'],
    ['Time zone', s.timezone || 'Europe/Madrid'],
    ['Start times', `every ${minutes(s.interval_min || 15)}`],
    ['Most people online', String(s.max_online_party || 8)],
    ['Bookings confirm', (s.policy || 'auto') === 'review' ? 'only with your OK' : 'on their own, inside the rules'],
    ['Notice, days ahead, changes', `${minutes(s.min_notice_min ?? 60)} · ${s.window_days || 60} days · up to ${s.change_notice_hours ?? 2} h before`],
    ['Channels', C.listOf(s.channels).join(', ') || '—'],
    ['Telegram', s.notify_telegram ? 'on' : 'off'],
    ['Booking emails, brief', `${s.mail_on === 'yes' ? 'on' : 'off'} · ${s.brief_on === 'yes' ? `on at ${s.brief_time || '11:00'}` : 'off'}`],
  ];
  return card('The restaurant and its rules', 'Its name and address, the booking rules, sources, Telegram and the optional extras are managed in Orchestra.', [
    el('ul', { class: 'oc-stack oc-stack--tight' }, facts.map(([k, v]) => el('li', [el('b', `${k}: `), v]))),
    el('div', { class: 'oc-row' }, link), where,
  ]);
}

// How long a table is kept: a usual time and, for bigger parties, longer — rules
// with a shape Orchestra's Ajustes does not edit, so they stay here.
function stays(s) {
  const stay = C.jsonOf(s.stay_rules, []).map((r) => ({ min: Number(r.min), minutes: Number(r.minutes) }));
  const rows = [0, 1, 2].map((i) => ({ min: input({ type: 'number', min: '1', max: '60', value: stay[i] ? stay[i].min : '', class: 'oc-input tb-num', 'aria-label': 'From people' }),
    minutes: input({ type: 'number', min: '30', max: '480', step: '15', value: stay[i] ? stay[i].minutes : '', class: 'oc-input tb-num', 'aria-label': 'Minutes' }) }));
  const c = {
    default_stay_min: input({ type: 'number', min: '30', max: '480', step: '15', value: s.default_stay_min || 90, class: 'oc-input tb-num' }),
    stay_rules: { get: () => JSON.stringify(rows.map((x) => ({ min: Number(x.min.value), minutes: Number(x.minutes.value) })).filter((x) => x.min > 0 && x.minutes > 0)) },
  };
  const { f, save } = saver(s, A.settings, c, 'Saved. The free times are being worked out again.');
  f.append(
    el('div', { class: 'tb-stays' }, [el('span', 'Usually'), c.default_stay_min, ...rows.flatMap((x) => [el('span', 'from'), x.min, el('span', 'people:'), x.minutes])]),
    el('p', { class: 'oc-help' }, 'Bigger parties stay longer: from that many people, the table is kept that long.'),
    el('div', { class: 'oc-row' }, save));
  return card('How long a table is kept (minutes)', null, [f]);
}
