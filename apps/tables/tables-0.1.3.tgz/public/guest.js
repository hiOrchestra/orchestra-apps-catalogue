// The guest's own page (#/b/<token>): the booking as the restaurant has it,
// and what the guest can do without an account: confirm they are coming,
// change the time or the number of people (inside the rules, until Settings'
// hours before), or cancel. The token never leaves this browser: the page
// hashes it to find its sealed row in book_links and opens it here. Each
// action is a public insert (change) that the instance judges; the page waits
// for the sealed answer.
import { reasonOf } from './words.js';
import { chosen, ctx, dayLong, dayPicker, offer, partyPicker, state, timeGrid, w } from './ui.js';

const { el } = Orch;
const C = window.TableCore;
const T0 = Date.now();
const sleep = (ms) => new Promise((r) => { setTimeout(r, ms); });
const cap = (s) => s.charAt(0).toUpperCase() + s.slice(1);

/** The sealed booking for a token once `test` passes (or the last one seen when time runs out with `last`). */
export async function waitBox(token, test, ms = 30000, { last = false } = {}) {
  const k = await C.linkKey(token);
  const until = Date.now() + ms;
  let seen = null;
  for (;;) {
    try {
      const r = await Orch.db.view('book_links', { filter: { k }, limit: 1 });
      const row = (r.rows || [])[0];
      if (row) seen = await C.open(token, row.box);
      if (seen && test(seen)) return seen;
    } catch (e) { if (e.status === 403) throw e; }
    if (Date.now() > until) return last ? seen : null;
    await sleep(1500);
  }
}

export async function guestPage(token, app) {
  if (!C.TOKEN.test(token)) { app.show(state(w().noLink, '')); return; }
  app.show(state(w().yourLink, '…'));
  let box;
  try { box = await waitBox(token, () => true, 6000); } catch { app.show(state(w().notOpen, w().notOpenText)); return; }
  if (!box) { app.show(state(w().noLink, w().call(ctx.page.phone))); return; }
  draw(token, box, app);
}

function facts(b) {
  return el('dl', { class: 'tp-facts' }, [
    [cap(dayLong(b.day)), `${b.time} · ${w().p(b.party)}`],
    [b.biz.name, [b.biz.address, b.biz.phone].filter(Boolean).join(' · ')],
    b.note ? ['', `${ctx.lang === 'en' ? 'Note' : 'Nota'}: ${b.note}`] : null, b.allergies ? ['', `${ctx.lang === 'en' ? 'Allergies' : 'Alergias'}: ${b.allergies}`] : null,
  ].filter(Boolean).map(([k, v]) => el('div', { class: 'tp-facts__row' }, [el('dt', k), el('dd', v)])));
}

function draw(token, b, app, said) {
  const t = w();
  const live = ['Confirmed', 'Requested'].includes(b.status) && Date.parse(b.start_at) > Date.now();
  const canChange = live && Date.now() < Date.parse(b.change_until);
  const kids = [el('h1', { class: 'tp-title', tabindex: '-1' }, b.status === 'Confirmed' ? t.confirmed : (t.statusTitle[b.status] || t.yourLink)), facts(b)];
  if (said) kids.push(said);
  if (b.status === 'Requested') kids.push(el('p', { class: 'tp-text' }, ctx.page && ctx.page.mails === 'yes' ? t.requestedText : t.requestedTextLink));
  if (['Failed', 'Declined', 'Discarded'].includes(b.status) && b.reason) kids.push(el('p', { class: 'tp-text' }, reasonOf(ctx.lang, b.reason) || t.discarded));
  if (b.status === 'Confirmed' && live) {
    kids.push(b.guest_confirmed ? el('p', { class: 'tp-ok' }, t.attending)
      : el('button', { type: 'button', class: 'oc-btn oc-btn--primary tp-send', onClick: (e) => act(token, { kind: 'confirm' }, b, app, e.currentTarget) }, t.confirmAttend));
  }
  if (canChange) {
    kids.push(el('button', { type: 'button', class: 'oc-btn tp-send', onClick: () => changeForm(token, b, app) }, t.changeIt));
    const host = el('div', { class: 'tp-stack' });
    const start = el('button', { type: 'button', class: 'tp-link tp-link--danger', onClick: () => host.replaceChildren(el('div', { class: 'tp-confirm', role: 'alert' }, [
      el('p', { class: 'tp-text' }, t.cancelSure),
      el('div', { class: 'tp-row' }, [el('button', { type: 'button', class: 'oc-btn', onClick: () => host.replaceChildren(start) }, t.keepIt),
        el('button', { type: 'button', class: 'oc-btn oc-btn--danger', onClick: (e) => act(token, { kind: 'cancel' }, b, app, e.currentTarget) }, t.cancelYes)]),
    ])) }, t.cancelIt);
    host.append(start);
    kids.push(host);
  } else if (live) kids.push(el('p', { class: 'tp-note' }, t.tooLate(b.biz.phone)));
  if (!live) kids.push(el('button', { type: 'button', class: 'oc-btn', onClick: app.home }, t.bookAnother));
  else kids.push(el('p', { class: 'tp-note' }, t.keep));
  app.show(el('section', { class: 'tp-card tp-guest' }, kids));
}

/** Send a change and wait for the sealed answer about it. */
async function act(token, change, b, app, button) {
  if (button) button.disabled = true;
  const before = b.change ? b.change.id : 0;
  // An error from the platform can come for a change that went through (seen
  // on staging under a burst): then only a short look decides what to say.
  let unsure = false;
  try {
    await Orch.action('change', Object.assign({ token, hp: '', ms: Date.now() - T0, visit: `${token.slice(0, 8)}-${Date.now()}` }, change));
  } catch {
    unsure = true;
  }
  app.processNow();
  const box = await waitBox(token, (x) => x.change && x.change.id !== before, unsure ? 20000 : 40000, { last: !unsure });
  if (!box) {
    if (button) button.disabled = false;
    if (unsure) Orch.toast(w().failed, { error: true });
    return;
  }
  const c = box.change;
  const said = c && c.id !== before && c.status === 'Rejected'
    ? el('div', { class: 'tp-problem', role: 'alert' }, [el('p', { class: 'tp-text' }, `${w().rejected} ${reasonOf(ctx.lang, c.reason) || c.reason}`),
      offer(c.offer, (o) => act(token, { kind: 'change', party: change.party || box.party, start_at: o.start_at }, box, app))])
    : c && c.id !== before && change.kind === 'change' ? el('p', { class: 'tp-ok' }, w().changed) : null;
  draw(token, box, app, said);
}

/** Change the day, the time or the number of people: the same pickers as the page. */
function changeForm(token, b, app) {
  const max = Number(ctx.page.max_online_party) || 8;
  const today = C.localDay(new Date(), ctx.tz);
  const days = Array.from({ length: 14 }, (_, i) => C.addDays(today, i));
  days.max = C.addDays(today, Number(ctx.page.window_days) || 60);
  const want = { day: b.day, party: b.party };
  const step = async () => {
    const head = [chosen([[cap(dayLong(want.day)), () => { want.pickDay = true; step(); }], [w().p(want.party), () => { want.pickParty = true; step(); }]]),
      el('h1', { class: 'tp-title', tabindex: '-1' }, w().changeIt)];
    if (want.pickDay) { app.show(el('section', { class: 'tp-card' }, [...head, dayPicker(days, want.day, (d) => { want.day = d; want.pickDay = false; step(); })])); return; }
    if (want.pickParty) { app.show(el('section', { class: 'tp-card' }, [...head, partyPicker(max, want.party, (n) => { want.party = Math.min(n, max); want.pickParty = false; step(); })])); return; }
    const rows = ((await Orch.db.view('book_times', { filter: { day: want.day }, sort: 'start_at:asc', limit: 500 }).catch(() => ({ rows: [] }))).rows) || [];
    // Its own table is still counted as taken in the times: the instance leaves it out when it judges the change.
    app.show(el('section', { class: 'tp-card' }, [...head, el('p', { class: 'tp-text' }, w().time),
      rows.length ? timeGrid(rows, want.party, true, (r) => act(token, { kind: 'change', party: want.party, start_at: r.start_at }, b, app)) : el('p', { class: 'tp-text' }, w().closed),
      el('button', { type: 'button', class: 'tp-link', onClick: () => draw(token, b, app) }, `← ${w().back}`)]));
  };
  step();
}
