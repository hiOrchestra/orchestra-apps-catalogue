// The words of the booking page and the guest's page, in Spanish (tú) and
// English. The guest's language: ?lang=, else the browser's when the
// restaurant offers it, else the restaurant's default.
export const WORDS = {
  es: {
    lang: 'Español', when: '¿Qué día?', today: 'Hoy', tomorrow: 'Mañana', other: 'Otra fecha', people: '¿Cuántos sois?', more: (n) => `Más de ${n}`,
    time: '¿A qué hora?', full: 'completo', noTimes: (n) => `No nos queda mesa para ${n} ese día.`, tryDays: 'Prueba otro día:', closed: 'Ese día no abrimos.',
    large: (n) => `Para más de ${n} personas te confirmamos nosotros: elige una hora y te escribimos.`, howMany: 'Número de personas',
    you: 'Tus datos', name: 'Nombre', email: 'Email', emailHelp: 'Te enviamos aquí la confirmación.', emailHelpLink: 'Por si tenemos que escribirte.', phone: 'Teléfono', phoneHelp: 'Por si tenemos que avisarte.',
    note: 'Algo que debamos saber (opcional)', notePh: 'Cumpleaños, trona, terraza…', allergies: 'Alergias o intolerancias (opcional)',
    special: 'Es una ocasión especial o necesito algo fuera de lo normal: preferimos confirmarlo nosotros.', book: 'Reservar', request: 'Enviar solicitud',
    privacy: 'Usamos tus datos solo para gestionar esta reserva.', change: 'Cambiar', back: 'Atrás', sending: 'Reservando…',
    busy: (s) => `Hay mucha gente reservando. Lo intentamos de nuevo en ${s} s…`, failed: 'No se pudo enviar. Tus datos siguen aquí: inténtalo de nuevo.',
    confirmed: '¡Mesa reservada!', requested: 'Solicitud recibida', requestedText: 'Te confirmamos lo antes posible por email.', requestedTextLink: 'Te confirmamos lo antes posible: vuelve a este enlace para verlo.',
    notBooked: 'No hemos podido reservar', taken: 'Esa hora se acaba de llenar.', others: 'Tenemos sitio a estas horas:', pickOther: 'Elegir otra hora',
    discarded: 'No hemos podido tomar esta reserva. Llámanos y lo vemos.', waiting: 'Recibida. En unos segundos la ves confirmada aquí.', slow: 'La recibimos. Te confirmamos por email; también puedes volver a este enlace.', slowLink: 'La recibimos. Vuelve a este enlace para ver la confirmación.',
    keep: 'Guarda este enlace: desde aquí confirmas, cambias o cancelas.', yourLink: 'Tu reserva',
    p: (n) => `${n} ${n === 1 ? 'persona' : 'personas'}`, at: 'a las', localTime: (tz) => `Horas de ${tz}.`,
    statusTitle: { Confirmed: 'Tu reserva', Requested: 'Solicitud pendiente', Cancelled: 'Reserva cancelada', Declined: 'No podemos confirmar esta reserva', Failed: 'No se pudo reservar', Arrived: '¡Gracias por venir!', NoShow: 'Te echamos de menos', Discarded: 'Reserva no válida', New: 'Un momento…', Approving: 'Un momento…' },
    confirmAttend: 'Confirmo que vamos', attending: 'Has confirmado que venís. ¡Te esperamos!', changeIt: 'Cambiar hora o personas', cancelIt: 'Cancelar la reserva',
    cancelSure: '¿Seguro que quieres cancelar? La mesa queda libre para otra persona.', cancelYes: 'Sí, cancelar', keepIt: 'No, mantener',
    tooLate: (p) => `Para cambios a estas horas, llámanos${p ? ` al ${p}` : ''}.`, saveChange: 'Guardar el cambio', changed: 'Hecho: tu reserva está actualizada.',
    rejected: 'No se pudo cambiar:', noLink: 'Este enlace no es válido o la reserva ya no existe.', closedPage: 'Ahora mismo no aceptamos reservas online.',
    notOpen: 'Las reservas aún no están abiertas', notOpenText: 'Vuelve a intentarlo un poco más tarde.', loadFail: 'No se pudo cargar la página', retry: 'Reintentar',
    call: (p) => (p ? `Llámanos al ${p}.` : ''), bookAgain: 'Hacer otra reserva', bookAnother: 'Reservar otra fecha',
  },
  en: {
    lang: 'English', when: 'Which day?', today: 'Today', tomorrow: 'Tomorrow', other: 'Another date', people: 'How many of you?', more: (n) => `More than ${n}`,
    time: 'What time?', full: 'full', noTimes: (n) => `We have no table left for ${n} that day.`, tryDays: 'Try another day:', closed: 'We are closed that day.',
    large: (n) => `For more than ${n} people we confirm it ourselves: pick a time and we will write to you.`, howMany: 'Number of people',
    you: 'Your details', name: 'Name', email: 'Email', emailHelp: 'We send the confirmation here.', emailHelpLink: 'In case we need to write to you.', phone: 'Phone', phoneHelp: 'In case we need to reach you.',
    note: 'Anything we should know (optional)', notePh: 'Birthday, high chair, terrace…', allergies: 'Allergies or intolerances (optional)',
    special: 'It is a special occasion, or I need something unusual: we would rather confirm it ourselves.', book: 'Book', request: 'Send request',
    privacy: 'We use your details only to handle this booking.', change: 'Change', back: 'Back', sending: 'Booking…',
    busy: (s) => `Many people are booking right now. Trying again in ${s} s…`, failed: 'It could not be sent. Your details are still here: try again.',
    confirmed: 'Your table is booked!', requested: 'Request received', requestedText: 'We will confirm it by email as soon as we can.', requestedTextLink: 'We will confirm it as soon as we can: come back to this link to see it.',
    notBooked: 'We could not book it', taken: 'That time just filled up.', others: 'We have room at these times:', pickOther: 'Pick another time',
    discarded: 'We could not take this booking. Call us and we will sort it out.', waiting: 'Received. In a few seconds you see it confirmed here.', slow: 'We have it. We will confirm by email; you can also come back to this link.', slowLink: 'We have it. Come back to this link to see the confirmation.',
    keep: 'Keep this link: here you confirm, change or cancel.', yourLink: 'Your booking',
    p: (n) => `${n} ${n === 1 ? 'person' : 'people'}`, at: 'at', localTime: (tz) => `Times in ${tz}.`,
    statusTitle: { Confirmed: 'Your booking', Requested: 'Request pending', Cancelled: 'Booking cancelled', Declined: 'We cannot confirm this booking', Failed: 'It could not be booked', Arrived: 'Thank you for coming!', NoShow: 'We missed you', Discarded: 'Booking not valid', New: 'One moment…', Approving: 'One moment…' },
    confirmAttend: 'I confirm we are coming', attending: 'You confirmed you are coming. See you soon!', changeIt: 'Change the time or people', cancelIt: 'Cancel the booking',
    cancelSure: 'Cancel it? The table goes to someone else.', cancelYes: 'Yes, cancel', keepIt: 'No, keep it',
    tooLate: (p) => `For changes this close to the time, call us${p ? ` on ${p}` : ''}.`, saveChange: 'Save the change', changed: 'Done: your booking is updated.',
    rejected: 'It could not be changed:', noLink: 'This link is not valid, or the booking no longer exists.', closedPage: 'We are not taking online bookings right now.',
    notOpen: 'Bookings are not open yet', notOpenText: 'Please try again a little later.', loadFail: 'This page could not load', retry: 'Try again',
    call: (p) => (p ? `Call us on ${p}.` : ''), bookAgain: 'Make another booking', bookAnother: 'Book another date',
  },
};

/** The reasons the instance gives, said to a guest. */
export const REASON = {
  es: [[/No table free/i, 'No nos queda mesa a esa hora.'], [/Too soon/i, 'Es demasiado pronto para reservar esa hora online.'], [/Too far/i, 'Esa fecha aún no está abierta.'],
    [/Closed/i, 'Ese día no abrimos.'], [/Not a time/i, 'No reservamos a esa hora.'], [/paused/i, 'Ahora mismo no aceptamos reservas online.'], [/passed/i, 'Esa hora ya pasó.'],
    [/too close/i, 'Queda muy poco para la hora: llámanos.'], [/call us/i, 'Para eso, llámanos.'], [/no longer/i, 'Esta reserva ya no se puede cambiar.']],
  en: [[/No table free/i, 'We have no table left at that time.'], [/Too soon/i, 'It is too soon to book that time online.'], [/Too far/i, 'That date is not open yet.'],
    [/Closed/i, 'We are closed that day.'], [/Not a time/i, 'We do not take bookings at that time.'], [/paused/i, 'We are not taking online bookings right now.'], [/passed/i, 'That time has passed.'],
    [/too close/i, 'It is very close to the time: please call us.'], [/call us/i, 'For that, please call us.'], [/no longer/i, 'This booking can no longer be changed.']],
};
export const reasonOf = (lang, text) => ((REASON[lang] || REASON.en).find(([re]) => re.test(String(text || ''))) || [null, ''])[1];
