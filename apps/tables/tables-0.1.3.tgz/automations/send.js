'use strict';
/**
 * Tables · Send emails, in plain text, through the sender Settings chose:
 * the business's Gmail or its Resend (both Composio integrations, connected
 * in Orchestra → Integrations).
 *
 *   reminders  a Confirmed booking with an email, starting within Settings'
 *              reminder hours (24 by default) and more than two hours away,
 *              gets one reminder with its confirm / cancel link. Queued
 *              Approved: the guest asked for the booking.
 *   send       only Approved emails go: the ones the rules wrote (the guest
 *              booked, changed, cancelled; the reminder) and the ones a
 *              person approved (the agent's drafts wait in Review). Each is
 *              CLAIMED first (Approved → Sending, atomic), so none leaves
 *              twice; with Gmail an answer in the guest's own thread goes as a
 *              reply (Resend has no threads: it goes as a new email). One
 *              left Sending (a run that died, the sender silent) becomes
 *              Failed saying it may have gone out: never retried blind.
 *   --check    looks at which of Gmail and Resend this workspace has connected
 *              (the instance's connections list, else one cheap call to each),
 *              Gmail's address, Resend's verified domains and whether the From
 *              address is on one, and notes it all in Settings. With no sender
 *              chosen yet it picks the connected one (Gmail if both). --auto
 *              does it too when the last look is over six hours old, or the
 *              From address changed since.
 *
 * Nothing is queued while emails are off (Settings), and bookings work the
 * same without them.
 *   node send.js [--auto|--now|--check] [--dry-run]
 */
const L = require('./lib');
const C = require('./tablecore');
const X = require('./composio');
const S = require('./seat');

const STALE_MIN = 15;
const LOOK_EVERY_H = 6;
const NAME = { gmail: 'Gmail', resend: 'Resend' };
const WHERE_SENT = { gmail: 'Gmail\'s Sent folder', resend: 'Resend\'s Emails list' };

function readable(r, via = 'gmail') {
  const who = NAME[via];
  const why = String(r.why || '');
  if (r.noFrom) return 'Resend has no From address in Settings: nothing went out. Write one (Settings → Emails to guests), then send it again.';
  if (r.notConnected) return `${who} is not connected for this workspace: nothing went out. Connect it in Orchestra → Integrations (or choose the other sender in Settings), then send it again. (${why.slice(0, 160)})`;
  if (r.timedOut) return `${who} did not answer in time, so it may or may not have gone out. Look in ${WHERE_SENT[via]} before sending again. (${why.slice(0, 160)})`;
  if (via === 'resend' && /not verified|verify your domain/i.test(why)) return `Resend refused the From address: its domain is not verified in your Resend account. Verify it in Resend → Domains, or change the From address in Settings, then send it again. (${why.slice(0, 160)})`;
  if (/invalid to|invalid `to`|recipient|address/i.test(why)) return `The address was refused: nothing went out. Check it and send again. (${why.slice(0, 160)})`;
  return `${who} did not take it: nothing went out. (${why.slice(0, 200)})`;
}

/** Which senders are connected, and what each says; noted in Settings. */
function check(s) {
  const now = L.sqlNow();
  const conn = X.connections();
  const data = { gmail_checked_at: now, resend_checked_at: now };
  // Gmail: its address (the cheap call); not asked when the list says it is not connected.
  if (conn.ok && !conn.has('gmail')) Object.assign(data, { gmail_status: 'not_connected', gmail_note: '' });
  else {
    const r = X.profile(s);
    if (r.ok) Object.assign(data, { gmail_status: 'ok', gmail_account: r.address || s.gmail_account || '', gmail_note: '' });
    else Object.assign(data, { gmail_status: r.notConnected ? 'not_connected' : 'error', gmail_note: String(r.why || '').slice(0, 300) });
  }
  // Resend: its domains (which also says it answers); when they cannot be read, one read of its emails.
  const from = C.normEmail(s.resend_from);
  if (conn.ok && !conn.has('resend')) Object.assign(data, { resend_status: 'not_connected', resend_note: '', resend_domains: '' });
  else {
    const d = X.resendDomains();
    if (d.ok) Object.assign(data, { resend_status: 'ok', resend_note: '', resend_domains: JSON.stringify(d.verified) });
    else if (d.notConnected) Object.assign(data, { resend_status: 'not_connected', resend_note: '', resend_domains: '' });
    else {
      const p = X.resendPing();
      if (p.ok) Object.assign(data, { resend_status: 'ok', resend_note: '', resend_domains: '' });
      else Object.assign(data, { resend_status: p.notConnected ? 'not_connected' : 'error', resend_note: String(p.why || '').slice(0, 300), resend_domains: '' });
    }
  }
  const verified = data.resend_domains ? JSON.parse(data.resend_domains) : null;
  Object.assign(data, { resend_checked_from: from,
    resend_from_status: !C.isEmail(from) || data.resend_status !== 'ok' ? '' : !verified ? 'unknown' : verified.includes(C.domainOf(from)) ? 'verified' : 'unverified' });
  if (!s.sender) {
    const pick = data.gmail_status === 'ok' ? 'gmail' : data.resend_status === 'ok' ? 'resend' : '';
    if (pick) data.sender = pick;
  }
  L.write([{ op: 'update', table: 'tb_settings', id: s._id, data }]);
  const after = Object.assign({}, s, data);
  const st = C.senders(after);
  return { ok: true, sender: st.sender, ready: st.ready, gmail: data.gmail_status, address: data.gmail_status === 'ok' ? data.gmail_account || undefined : undefined,
    resend: data.resend_status, from: from || undefined, from_status: data.resend_from_status || undefined, via: conn.ok ? 'connections' : 'calls', say: st.say };
}

/** Time for a look: never looked, over six hours ago (while emails are on), or the From address changed since. */
function lookDue(s) {
  const last = L.toDate(s.resend_checked_at);
  if (!last) return true;
  if (C.senderOf(s) === 'resend' && C.normEmail(s.resend_from) !== (s.resend_checked_from || '')) return true;
  return s.emails_on === 'yes' && L.now().getTime() - last.getTime() > LOOK_EVERY_H * 3600000;
}

/** One reminder per booking that starts within the reminder hours (and not within two). */
function reminders(s, dry) {
  if (s.emails_on !== 'yes') return 0;
  const now = L.now().getTime();
  const rows = L.all(`SELECT * FROM tb_bookings WHERE _deleted = 0 AND status = 'Confirmed' AND COALESCE(reminder_at, '') = ''
    AND COALESCE(email, '') <> '' AND start_at > ? AND start_at <= ? ORDER BY start_at LIMIT 100`,
  L.isoZ(new Date(now + 2 * 3600000)), L.isoZ(new Date(now + (Number(s.reminder_hours) || 24) * 3600000)));
  let n = 0;
  for (const b of rows) {
    const op = S.emailOp('reminder', b, s);
    if (!op || dry) { n += op ? 1 : 0; continue; }
    try { L.write([{ op: 'update', table: 'tb_bookings', id: b._id, when: { reminder_at: b.reminder_at }, data: { reminder_at: L.sqlNow() } }, op]); n += 1; } catch { /* taken meanwhile */ }
  }
  return n;
}

function run(mode = '--auto', { dry = false } = {}) {
  let s = L.settings();
  if (mode === '--check') return check(s);
  let looked;
  if (!dry && lookDue(s)) { looked = check(s); s = L.settings(); }
  const held = dry ? { release() {} } : L.lock('send');
  if (!held) return { ok: true, mode, skipped: 'Another run is sending' };
  try {
    const via = C.senderOf(s);
    const out = { ok: true, mode, via, reminders: reminders(s, dry), sent: [], failed: [] };
    if (looked) out.looked = { gmail: looked.gmail, resend: looked.resend, ready: looked.ready };
    const stale = L.all(`SELECT _id FROM tb_emails WHERE _deleted = 0 AND status = 'Sending' AND datetime(lock_at) <= datetime(?, '-${STALE_MIN} minutes')`, L.sqlNow());
    if (stale.length && !dry) {
      L.write(stale.map((r) => ({ op: 'update', table: 'tb_emails', id: r._id, when: { status: 'Sending' },
        data: { status: 'Failed', error: `The send did not finish, so it may or may not have gone out. Look in ${WHERE_SENT[via]} before sending again.` } })));
    }
    const queue = L.all("SELECT * FROM tb_emails WHERE _deleted = 0 AND status = 'Approved' ORDER BY _id LIMIT 30");
    if (dry) return Object.assign(out, { dry: true, wouldSend: queue.map((m) => ({ id: m._id, to: m.to_email, subject: m.subject })) });
    let disconnected = false;
    for (const m of queue) {
      const to = C.normEmail(m.to_email);
      const fail = (error, from) => { try { L.write([{ op: 'update', table: 'tb_emails', id: m._id, when: { status: from }, data: { status: 'Failed', error: error.slice(0, 500) } }]); } catch { /* moved on */ } out.failed.push({ id: m._id, error: error.slice(0, 120) }); };
      if (!C.isEmail(to) || !String(m.subject || '').trim() || !String(m.body || '').trim()) { fail('It has no valid address, subject or message: nothing went out. Fix it and send it again.', 'Approved'); continue; }
      if (disconnected) { fail(readable(disconnected, via), 'Approved'); continue; }
      try { L.write([{ op: 'update', table: 'tb_emails', id: m._id, when: { status: 'Approved' }, data: { status: 'Sending', lock_at: L.sqlNow(), error: '' } }]); } catch { continue; }
      const r = X.deliver(s, Object.assign({}, m, { to_email: to }));
      if (!r.ok) {
        if (r.notConnected || r.noFrom) disconnected = r;
        fail(readable(r, via), 'Sending');
        continue;
      }
      L.write([{ op: 'update', table: 'tb_emails', id: m._id, data: { status: 'Sent', sent_at: L.sqlNow(), sent_via: via, gmail_id: via === 'gmail' ? r.id || '' : '',
        resend_id: via === 'resend' ? r.id || '' : '', thread_id: m.thread_id || r.threadId || '', error: '' } }]);
      out.sent.push({ id: m._id, kind: m.kind });
    }
    if (disconnected && disconnected.notConnected) {
      L.write([{ op: 'update', table: 'tb_settings', id: s._id, data: via === 'resend' ? { resend_status: 'not_connected', resend_checked_at: L.sqlNow() } : { gmail_status: 'not_connected', gmail_checked_at: L.sqlNow() } }]);
    }
    return out;
  } finally {
    held.release();
  }
}

if (require.main === module) {
  const argv = process.argv.slice(2);
  const mode = ['--now', '--check'].find((m) => argv.includes(m)) || '--auto';
  L.main(() => run(mode, { dry: argv.includes('--dry-run') }));
}

module.exports = { run, readable, reminders, check, lookDue };
