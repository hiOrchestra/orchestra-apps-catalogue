'use strict';
/**
 * Every call Tables makes to Composio, and nothing else: the Gmail or the
 * Resend of the business (connected in Orchestra → Integrations; Settings
 * chooses which one sends). When Composio renames an argument, this is the
 * only file to change.
 *
 *   connections()                     GET /api/composio/connections   which toolkits are connected (ACTIVE)
 *   profile()                         GMAIL_GET_PROFILE       the connected address
 *   fetch({ query, max })             GMAIL_FETCH_EMAILS      messages, read only, with their text
 *   send({ to, subject, body })       GMAIL_SEND_EMAIL        one plain-text email
 *   reply({ threadId, to, body })     GMAIL_REPLY_TO_THREAD   an answer inside the guest's own thread
 *   resendPing()                      RESEND_LIST_EMAILS      limit 1: does Resend answer (nothing is sent)
 *   resendDomains()                   RESEND_LIST_DOMAINS     the domains and which are verified
 *   resendSend({ to, subject, body }) RESEND_SEND_EMAIL       one plain-text email, from Settings' From
 *   deliver(m)                        one queued email through the chosen sender (a thread reply only with Gmail)
 *
 * Each returns { ok, data } or { ok: false, why, timedOut, notConnected }.
 * TABLES_FAKE_COMPOSIO=1 answers from TABLES_FAKE_DATA (a JSON file: {address,
 * messages: [...], connected: ["gmail", "resend"] (both when absent; null: the
 * connections list is refused), domains: [{name, status}], fail: {SLUG: "why"},
 * timeout: {SLUG: true}}) and appends every email "sent" to TABLES_FAKE_OUTBOX,
 * one JSON a line.
 */
const fs = require('fs');
const L = require('./lib');

const C = require('./tablecore');

const SLUG = { profile: 'GMAIL_GET_PROFILE', fetch: 'GMAIL_FETCH_EMAILS', send: 'GMAIL_SEND_EMAIL', reply: 'GMAIL_REPLY_TO_THREAD',
  resendSend: 'RESEND_SEND_EMAIL', resendList: 'RESEND_LIST_EMAILS', resendDomains: 'RESEND_LIST_DOMAINS' };
const NOT_CONNECTED = /no connected account|not connected|connection.*(not found|expired|revoked)|no active connection|ConnectedAccountNotFound/i;

const mark = (r) => (r.ok ? r : Object.assign(r, { notConnected: NOT_CONNECTED.test(String(r.why || '')) }));

/** The first value under `key` anywhere in a nested answer (Composio wraps answers differently per tool). */
function valueAt(obj, key, depth = 0) {
  if (!obj || typeof obj !== 'object' || depth > 5) return undefined;
  if (obj[key] !== undefined && obj[key] !== null && typeof obj[key] !== 'object') return obj[key];
  for (const v of Object.values(obj)) { const f = valueAt(v, key, depth + 1); if (f !== undefined) return f; }
  return undefined;
}
function arrayAt(obj, key, depth = 0) {
  if (!obj || typeof obj !== 'object' || depth > 4) return null;
  if (Array.isArray(obj[key])) return obj[key];
  for (const v of Object.values(obj)) { const f = arrayAt(v, key, depth + 1); if (f) return f; }
  return null;
}
const timeOf = (v) => {
  if (v === null || v === undefined || v === '') return null;
  const n = Number(v);
  const d = Number.isFinite(n) && String(v).trim() !== '' ? new Date(n < 1e12 ? n * 1000 : n) : new Date(String(v));
  return Number.isNaN(d.getTime()) ? null : d;
};

function profile(s) {
  const r = mark(L.composio(SLUG.profile, { user_id: 'me' }, 30));
  return r.ok ? { ok: true, address: String(valueAt(r.data, 'emailAddress') || valueAt(r.data, 'email_address') || '').toLowerCase() } : r;
}

/** Messages matching a Gmail query, newest first: [{ id, threadId, at, from, subject, text, labels }]. */
function fetch(s, { query, max = 25 }) {
  const r = mark(L.composio(SLUG.fetch, { user_id: 'me', query, max_results: max, include_payload: true, verbose: true }, 60));
  if (!r.ok) return r;
  const list = arrayAt(r.data, 'messages') || [];
  return {
    ok: true,
    messages: list.map((m) => ({
      id: String(m.messageId || m.id || ''), threadId: String(m.threadId || m.thread_id || ''),
      at: timeOf(m.messageTimestamp || m.internalDate || m.date),
      from: String(m.sender || m.from || ''), subject: String(m.subject || (m.preview && m.preview.subject) || ''),
      text: String(m.messageText || (m.preview && m.preview.body) || m.snippet || ''),
      labels: Array.isArray(m.labelIds) ? m.labelIds : [],
    })).filter((m) => m.id),
  };
}

function send(s, { to, subject, body }) {
  const r = mark(L.composio(SLUG.send, { user_id: 'me', recipient_email: to, subject, body, is_html: false }, 45));
  return r.ok ? { ok: true, id: String(valueAt(r.data, 'id') || ''), threadId: String(valueAt(r.data, 'threadId') || '') } : r;
}

function reply(s, { threadId, to, body }) {
  const r = mark(L.composio(SLUG.reply, { user_id: 'me', thread_id: threadId, recipient_email: to, message_body: body, is_html: false }, 45));
  return r.ok ? { ok: true, id: String(valueAt(r.data, 'id') || ''), threadId: String(valueAt(r.data, 'threadId') || threadId) } : r;
}

/**
 * The toolkits this workspace has connected (status ACTIVE), from the
 * instance's own list: { ok, has(slug) }, or { ok: false } when it cannot be
 * read (then the cheap calls tell).
 */
function connections() {
  const r = process.env.TABLES_FAKE_COMPOSIO === '1' ? fakeConnections() : L.get('/api/composio/connections?view=brief', 20);
  if (!r.ok) return { ok: false, why: r.why };
  const d = r.data || {};
  const slug = (x) => String((x && typeof x === 'object' ? (x.slug || x.name) : x) || '').toLowerCase();
  const active = Array.isArray(d.connections)
    ? d.connections.filter((c) => !c.status || /^active$/i.test(String(c.status))).map((c) => slug(c.toolkit))
    : (Array.isArray(d.toolkits) ? d.toolkits.map(slug) : null);
  if (!active) return { ok: false, why: 'The connections list had no toolkits' };
  const set = new Set(active);
  return { ok: true, has: (k) => set.has(k), list: [...set] };
}

/** Does Resend answer? One read of its latest email; nothing is sent. */
function resendPing() {
  return mark(L.composio(SLUG.resendList, { limit: 1 }, 30));
}

/** Resend's domains: { ok, verified: ['example.com'], all: [{ name, status }] }. */
function resendDomains() {
  const r = mark(L.composio(SLUG.resendDomains, {}, 30));
  if (!r.ok) return r;
  const list = (arrayAt(r.data, 'data') || arrayAt(r.data, 'domains') || []).filter((d) => d && typeof d === 'object' && d.name);
  const all = list.map((d) => ({ name: String(d.name).toLowerCase(), status: String(d.status || '').toLowerCase() }));
  return { ok: true, all, verified: all.filter((d) => d.status === 'verified').map((d) => d.name) };
}

/** One plain-text email through Resend, "Name <from>" and the reply-to from Settings. */
function resendSend(s, { to, subject, body }) {
  const from = C.normEmail(s.resend_from);
  if (!C.isEmail(from)) return { ok: false, why: 'No From address for Resend in Settings', noFrom: true };
  const args = { from: C.fromLine(s.resend_from_name || s.business_name, from), to, subject, text: body };
  if (C.isEmail(s.resend_reply_to)) args.reply_to = C.normEmail(s.resend_reply_to);
  const r = mark(L.composio(SLUG.resendSend, args, 45));
  return r.ok ? { ok: true, id: String(valueAt(r.data, 'id') || ''), threadId: '' } : r;
}

/** A queued email through the sender Settings chose: Gmail answers inside the guest's thread; Resend has no threads. */
function deliver(s, m) {
  const to = C.normEmail(m.to_email);
  if (C.senderOf(s) === 'resend') return Object.assign(resendSend(s, { to, subject: m.subject, body: m.body }), { via: 'resend' });
  const r = m.thread_id ? reply(s, { threadId: m.thread_id, to, body: m.body }) : send(s, { to, subject: m.subject, body: m.body });
  return Object.assign(r, { via: 'gmail' });
}

// ── the fake, for tests and the local harness ────────────────────────────
function fakeData() {
  try { return JSON.parse(fs.readFileSync(process.env.TABLES_FAKE_DATA, 'utf8')); } catch { return {}; }
}
function fakeConnections() {
  const d = fakeData();
  if (d.connected === null) return { ok: false, why: 'Instance discovery requires a workspace admin. (fake)' };
  const on = d.connected || ['gmail', 'resend'];
  return { ok: true, data: { toolkits: on, connections: on.map((k) => ({ id: `ca_${k}`, toolkit: k, status: 'ACTIVE' })) } };
}
function fake(slug, args) {
  const d = fakeData();
  if (d.timeout && d.timeout[slug]) return { ok: false, why: 'Operation timed out after 45000 milliseconds (28)', timedOut: true };
  if (d.fail && d.fail[slug]) return { ok: false, why: d.fail[slug] };
  const toolkit = slug.startsWith('RESEND_') ? 'resend' : 'gmail';
  if (Array.isArray(d.connected) && !d.connected.includes(toolkit)) return { ok: false, why: `No connected account found for toolkit ${toolkit} (fake)` };
  if (slug === SLUG.resendList) return { ok: true, data: { object: 'list', has_more: false, data: [] } };
  if (slug === SLUG.resendDomains) {
    if (d.domains === null) return { ok: false, why: 'The tool returned no domain list (fake)' };
    return { ok: true, data: { data: { object: 'list', data: (d.domains || [{ name: 'casalola.example', status: 'verified' }]).map((x, i) => Object.assign({ id: `dom-${i}`, region: 'eu-west-1' }, x)) } } };
  }
  if (slug === SLUG.resendSend) {
    const to = String(args.to || '');
    if (/^fail@/.test(to)) return { ok: false, why: 'Invalid `to` field (fake)' };
    if (/^timeout@/.test(to)) return { ok: false, why: 'Operation timed out (28)', timedOut: true };
    const domain = C.domainOf((String(args.from).match(/<([^>]+)>/) || [])[1] || args.from);
    const verified = (d.domains || [{ name: 'casalola.example', status: 'verified' }]).filter((x) => x.status === 'verified').map((x) => x.name);
    if (!verified.includes(domain)) return { ok: false, why: `The ${domain} domain is not verified. Please, add and verify your domain on https://resend.com/domains (fake)` };
    const id = `re-${Math.random().toString(36).slice(2, 10)}`;
    if (process.env.TABLES_FAKE_OUTBOX) fs.appendFileSync(process.env.TABLES_FAKE_OUTBOX, `${JSON.stringify({ slug, ...args, id })}\n`);
    return { ok: true, data: { data: { id } } };
  }
  if (slug === SLUG.profile) return { ok: true, data: { response_data: { emailAddress: d.address || 'reservas@restaurant.example' } } };
  if (slug === SLUG.fetch) {
    const after = Number((String(args.query).match(/after:(\d+)/) || [])[1] || 0) * 1000;
    const all = (d.messages || []).filter((m) => Number(m.messageTimestamp) >= after).sort((a, b) => Number(b.messageTimestamp) - Number(a.messageTimestamp));
    return { ok: true, data: { messages: all.slice(0, Number(args.max_results) || 25) } };
  }
  if (slug === SLUG.send || slug === SLUG.reply) {
    const to = String(args.recipient_email || '');
    if (/^fail@/.test(to)) return { ok: false, why: 'Invalid To header (fake)' };
    if (/^timeout@/.test(to)) return { ok: false, why: 'Operation timed out (28)', timedOut: true };
    const id = `fake-${Math.random().toString(36).slice(2, 10)}`;
    if (process.env.TABLES_FAKE_OUTBOX) fs.appendFileSync(process.env.TABLES_FAKE_OUTBOX, `${JSON.stringify({ slug, ...args, id })}\n`);
    return { ok: true, data: { response_data: { id, threadId: args.thread_id || `th-${id}` } } };
  }
  return { ok: false, why: `fake Composio has no ${slug}` };
}

module.exports = { SLUG, NOT_CONNECTED, connections, profile, fetch, send, reply, resendPing, resendDomains, resendSend, deliver, fake, valueAt, timeOf };
