SELECT business_name, address, phone, intro, timezone, languages, default_lang, interval_min,
       max_online_party, min_notice_min, window_days, change_notice_hours, COALESCE(paused, 'no') AS paused,
       CASE WHEN COALESCE(emails_on, '') <> 'yes' THEN 'no'
            WHEN sender = 'resend' THEN CASE WHEN resend_status = 'ok' AND COALESCE(resend_from, '') <> '' AND resend_checked_from = lower(trim(resend_from))
                                             AND COALESCE(resend_from_status, '') <> 'unverified' THEN 'yes' ELSE 'no' END
            WHEN gmail_status = 'ok' THEN 'yes' ELSE 'no' END AS mails
FROM tb_settings ORDER BY _id LIMIT 1
