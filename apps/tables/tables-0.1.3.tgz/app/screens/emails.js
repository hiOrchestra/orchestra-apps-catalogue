// Emails to guests: the confirmation, a reminder the day before and a note
// when something changes, through Gmail or Resend. Both are connected in
// Orchestra → Integrations; this card only chooses one and says what the
// last look found (the Send workflow's --check: on its own when Settings
// opens, every six hours while emails are on, and with "Look again"). It
// saves only its own fields, and turning emails on is the one thing here
// that needs a working sender: when it is not ready, it says why in plain
// words and keeps emails off, never an error.
import { A, C, INTEGRATIONS, act, field, input, lookAgain, select } from '../data.js';

const { el, fmt } = Orch;

export function emailsCard(s, again) {
  const st = C.senders(s, 'guests');
  const domains = C.verifiedDomains(s);
  let sender = st.sender;
  const c = {
    resend_from_name: input({ value: s.resend_from_name || '', maxlength: '80', placeholder: s.business_name || 'Casa Lola' }),
    resend_from: input({ type: 'email', value: s.resend_from || '', maxlength: '120', placeholder: domains && domains[0] ? `reservas@${domains[0]}` : 'reservas@yourrestaurant.com' }),
    resend_reply_to: input({ type: 'email', value: s.resend_reply_to || '', maxlength: '120', placeholder: 'Optional' }),
    emails_on: select([['no', 'Off: no emails to guests'], ['yes', 'On: confirmation, reminder and changes']], s.emails_on || 'no'),
  };
  const option = (value, label, sub) => {
    const r = el('input', { type: 'radio', name: 'tb-sender', value, checked: sender === value });
    r.addEventListener('change', () => { sender = value; draw(); });
    return el('label', { class: 'tb-choice' }, [r, el('span', { class: 'tb-choice__text' }, [el('span', { class: 'tb-choice__name' }, label), el('span', { class: 'oc-help' }, sub)])]);
  };
  const gmailSub = st.connected.gmail ? `Connected: ${s.gmail_account || 'it answers'}. Emails go from that address, and replies land in it.` : 'Not connected to this workspace.';
  const resendSub = st.connected.resend
    ? `Connected${domains && domains.length ? `; verified domains: ${domains.join(', ')}` : ''}. Emails go from an address on your own domain.`
    : 'Not connected to this workspace.';
  const resendBox = el('div', { class: 'oc-stack tb-resend' }, [
    el('div', { class: 'tb-two-col' }, [field('From name', c.resend_from_name, 'What guests see as the sender. Empty: the restaurant\'s name.'),
      field('From address', c.resend_from, 'On a domain verified in your Resend account.')]),
    field('Reply-to (optional)', c.resend_reply_to, 'Where guests\' replies go. Empty: to the From address.'),
  ]);
  const said = el('p', { class: 'tb-legible tb-sender__said' });
  const agentNote = el('p', { class: 'tb-legible tb-sender__said' });
  function draw() {
    resendBox.hidden = sender !== 'resend';
    const problem = C.senderProblem(s, { sender, resend_from: c.resend_from.value });
    said.textContent = sender === st.sender && !problem ? [st.say, st.note].filter(Boolean).join(' ') : (problem || (sender === 'resend' ? 'Save, and Resend is asked about this address.' : ''));
    said.hidden = !said.textContent;
    agentNote.textContent = sender === 'resend' && s.mail_on === 'yes'
      ? 'Booking emails (Optional extras) need Gmail: the agent reads that inbox and answers in the guest\'s thread. While Resend sends, it does not read it.' : '';
    agentNote.hidden = !agentNote.textContent;
  }
  draw();

  const save = el('button', { type: 'submit', class: 'oc-btn oc-btn--primary' }, 'Save');
  const f = el('form', { class: 'oc-stack tb-form' }, [
    el('fieldset', { class: 'tb-fieldset' }, [el('legend', { class: 'oc-label' }, 'Send through'), el('div', { class: 'tb-choices' }, [
      option('gmail', 'Gmail', gmailSub), option('resend', 'Resend', resendSub)])]),
    resendBox, said, agentNote,
    field('Emails to guests', c.emails_on, 'They go because the guest booked: the confirmation with their link, a reminder about a day before with confirm or cancel, and a note when you change or cancel it.'),
    el('div', { class: 'oc-row' }, save),
  ]);
  f.addEventListener('submit', async (e) => {
    e.preventDefault();
    const p = { id: s._id, sender, emails_on: c.emails_on.value, resend_from_name: c.resend_from_name.value.trim(),
      resend_from: C.normEmail(c.resend_from.value), resend_reply_to: C.normEmail(c.resend_reply_to.value) };
    if (p.resend_from && !C.isEmail(p.resend_from)) { Orch.toast('The From address does not look like an email address.'); c.resend_from.focus(); return; }
    if (p.resend_reply_to && !C.isEmail(p.resend_reply_to)) { Orch.toast('The reply-to does not look like an email address.'); c.resend_reply_to.focus(); return; }
    const turningOn = p.emails_on === 'yes' && s.emails_on !== 'yes';
    const problem = C.senderProblem(s, p);
    let done = 'Saved.';
    if (turningOn && problem) { p.emails_on = 'no'; done = `Saved. Emails stay off for now: ${problem}`; } else if (turningOn && !(await Orch.confirm(`Turn on emails to guests? From now on every booking with an email gets its confirmation, and a reminder the day before, through ${sender === 'resend' ? 'Resend' : 'Gmail'}.`, { yes: 'Turn them on' }))) return;
    const changed = p.sender !== st.sender || p.resend_from !== C.normEmail(s.resend_from);
    save.disabled = true;
    if (await act(A.emails, p, done)) { if (changed) await lookAgain(again, { quiet: true }); else again(); }
    save.disabled = false;
  });

  const nothing = !st.connected.gmail && !st.connected.resend && (s.gmail_status || s.resend_status);
  const look = el('button', { type: 'button', class: 'oc-btn oc-btn--sm oc-btn--ghost' }, 'Look again');
  look.addEventListener('click', async () => { look.disabled = true; look.textContent = 'Looking…'; await lookAgain(again); });
  return el('section', { class: 'oc-card oc-stack tb-emails' }, [
    el('div', { class: 'oc-row oc-row--between' }, [el('h2', { class: 'oc-h2' }, 'Emails to guests'),
      el('span', { class: `oc-badge${s.emails_on === 'yes' && st.ready ? ' oc-badge--good' : ''}` }, s.emails_on === 'yes' ? (st.ready ? 'On' : 'On, not sending') : 'Off')]),
    nothing ? el('p', { class: 'tb-legible' }, ['Connect Gmail or Resend in ', el('a', { href: INTEGRATIONS, target: '_top' }, 'Integrations'), ' to email guests. Bookings work the same without emails.']) : null,
    f,
    el('div', { class: 'oc-row tb-look' }, [el('span', { class: 'oc-help' }, s.resend_checked_at ? `Looked at Gmail and Resend ${fmt.ago(s.resend_checked_at)}.` : 'Not looked yet.'), look]),
  ]);
}
