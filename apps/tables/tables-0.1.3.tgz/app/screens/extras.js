// The optional extras, off until turned on: the agent reading booking emails
// in the Gmail inbox (inside the rules it books; anything else waits as a
// draft for you), and a brief before each service; and where the owner hears
// about bookings (Telegram). Emails to guests, and who sends them, are their
// own card (emails.js). Each form saves only its own fields; a rule here is
// checked only when its switch is being turned on, and says why in plain
// words.
import { A, C, act, field, input, select } from '../data.js';

const { el } = Orch;

export function extrasCard(s, again) {
  const c = {
    mail_on: select([['no', 'Off'], ['yes', 'On: the agent reads booking emails']], s.mail_on || 'no'),
    brief_on: select([['no', 'Off'], ['yes', 'On: a brief before each day\'s service']], s.brief_on || 'no'),
    brief_time: input({ type: 'time', value: s.brief_time || '11:00' }),
    agent: input({ value: s.agent || '', maxlength: '60', placeholder: 'The project\'s agent' }),
  };
  const save = el('button', { type: 'submit', class: 'oc-btn oc-btn--primary' }, 'Save');
  const f = el('form', { class: 'oc-stack tb-form' }, [
    field('Booking emails', c.mail_on, 'The agent reads new emails about bookings in your Gmail inbox. Inside your rules it books, changes or cancels, and the guest gets the usual email. Anything else becomes a draft reply in Requests that waits for you. Needs emails to guests on, sent through Gmail.'),
    el('div', { class: 'tb-two-col' }, [field('Brief before service', c.brief_on, 'Groups, allergies, VIPs and a few lines from the agent, on Today and on Telegram.'), field('At', c.brief_time)]),
    field('Agent', c.agent, 'Who reads the emails and writes the brief. It contacts nobody and writes nothing itself.'),
    el('div', { class: 'oc-row' }, save),
  ]);
  f.addEventListener('submit', async (e) => {
    e.preventDefault();
    const p = { id: s._id };
    for (const [k, n] of Object.entries(c)) p[k] = String(n.value).trim();
    if (p.mail_on === 'yes' && s.mail_on !== 'yes') {
      if (s.emails_on !== 'yes') { Orch.toast('Booking emails need emails to guests on first (the card above): the agent answers in the guest\'s thread.'); return; }
      if (C.senderOf(s) !== 'gmail') { Orch.toast('Booking emails need Gmail as the sender: the agent reads that inbox and answers in the guest\'s thread. Choose Gmail under Emails to guests first.'); return; }
    }
    if (((p.mail_on === 'yes' && s.mail_on !== 'yes') || (p.brief_on === 'yes' && s.brief_on !== 'yes')) && !p.agent) { Orch.toast('Name the agent that does it.'); c.agent.focus(); return; }
    save.disabled = true;
    if (await act(A.extras, p, 'Saved.')) again();
    save.disabled = false;
  });
  const tg = input({ value: s.notify_telegram || '', maxlength: '40', placeholder: '@channel or chat id' });
  const tgf = el('form', { class: 'oc-row tb-tg' }, [field('Telegram', tg, 'Where you hear about bookings that wait for your OK, and the brief.'), el('button', { type: 'submit', class: 'oc-btn oc-btn--sm' }, 'Save')]);
  tgf.addEventListener('submit', async (e) => { e.preventDefault(); if (await act(A.settings, { id: s._id, notify_telegram: tg.value.trim() }, 'Saved.')) again(); });
  return el('section', { class: 'oc-card oc-stack' }, [el('h2', { class: 'oc-h2' }, 'Optional extras'), el('p', { class: 'oc-help tb-legible' }, 'Off until you turn them on.'), f, tgf]);
}
