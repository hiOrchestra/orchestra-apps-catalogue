// What the desk reads, the only things it writes, and what the screens share.
// Seating, the rules and the emails run on the instance (automations/,
// through one door: seat.js); the desk asks with declared actions (A) and
// waits for the answer on the row. Times are shown in the restaurant's own
// zone (Settings), wherever the host's browser is.
import './tablecore.js';

export const C = window.TableCore;
const { el, router } = Orch;

export const T = {
  settings: 'tb_settings', services: 'tb_services', exceptions: 'tb_exceptions', tables: 'tb_tables', guests: 'tb_guests', bookings: 'tb_bookings',
  emails: 'tb_emails', mail: 'tb_mail', briefs: 'tb_briefs', times: 'tb_times', imports: 'tb_imports', changes: 'tb_changes',
};
export const V = { sheet: 'sheet', guests: 'guests_list', days: 'upcoming_days', sources: 'sources' };
export const A = {
  add: 'add_booking', arrive: 'arrive', undoArrive: 'undo_arrive', noShow: 'no_show', undoNoShow: 'undo_no_show', cancel: 'cancel_booking',
  approve: 'approve_booking', decline: 'decline_booking', move: 'move_booking', edit: 'edit_booking',
  approveEmail: 'approve_email', dropEmail: 'drop_email', retryEmail: 'retry_email', dropFailed: 'drop_failed_email', retryMail: 'retry_mail', ignoreMail: 'ignore_mail',
  guest: 'update_guest', importPart: 'import_part', runImport: 'run_import',
  createTable: 'create_table', updateTable: 'update_table', retireTable: 'retire_table',
  createService: 'create_service', updateService: 'update_service', removeService: 'remove_service', createException: 'create_exception', removeException: 'remove_exception',
  settings: 'update_settings', emails: 'update_emails', extras: 'update_extras', pause: 'pause_bookings', resume: 'resume_bookings', dismissStart: 'dismiss_onboarding',
  checkSenders: 'check_senders', rebuild: 'rebuild_times', processNow: 'process_now',
};

let S = {};
/** The one settings row (kept for the time zone the screens draw in). */
export async function settings() {
  S = (await Orch.db.list(T.settings, { sort: '_id:asc', limit: 1 })).rows[0] || {};
  return S;
}
export const tz = () => C.validZone(S.timezone || 'Europe/Madrid');
export const today = () => C.localDay(new Date(), tz());
/** "21:00" in the restaurant's zone. */
export const hm = (iso) => (iso ? C.localTime(new Date(iso), tz()) : '—');
/** "Friday 9 October" for a YYYY-MM-DD. */
export const dayName = (day, short) => new Intl.DateTimeFormat('en-GB', { timeZone: 'UTC', weekday: short ? 'short' : 'long', day: 'numeric', month: short ? 'short' : 'long' }).format(new Date(`${day}T12:00:00Z`));
export const nowIso = () => `${new Date().toISOString().slice(0, 19)}Z`;

/** Run a declared action, say how it went, and hand back its result (null on failure). */
export async function act(name, params, done) {
  try {
    const r = await Orch.action(name, params);
    if (done) Orch.toast(done);
    window.dispatchEvent(new Event('tables:changed'));
    return r || {};
  } catch (e) {
    Orch.toast(e.status === 409 ? 'It changed in the meantime: look again.' : (e.message || 'That did not work.'), { error: true });
    return null;
  }
}

/** Wait (up to `ms`) until a booking passes `test`: the instance judges it in a few seconds. */
export async function waitFor(id, test, ms = 20000) {
  const until = Date.now() + ms;
  let row = null;
  while (Date.now() < until) {
    await new Promise((r) => { setTimeout(r, 900); });
    try { row = await Orch.db.get(T.bookings, id); } catch { row = null; }
    if (row && test(row)) return row;
  }
  return row;
}

/** A dialog that closes when the screen changes: a link inside it must not leave it over the next screen. */
export function sheet(content, opts) {
  const d = Orch.dialog(content, opts);
  window.addEventListener('hashchange', () => { try { d.close(); } catch { /* closed */ } }, { once: true });
  return d;
}

/** A screen's head: its title, a sentence, and tools on the right. */
export const head = (title, lede, tools) => el('header', { class: 'tb-head' }, [
  el('div', { class: 'tb-head__title' }, [el('h1', { class: 'oc-h1 oc-h1--collection' }, title), lede ? el('p', { class: 'oc-lede' }, lede) : null]),
  tools ? el('div', { class: 'tb-head__tools' }, tools) : null,
]);
export const field = (label, control, help) => el('label', { class: 'oc-field' }, [el('span', { class: 'oc-label' }, label), control, help ? el('span', { class: 'oc-help' }, help) : null]);
export const input = (attrs) => el('input', Object.assign({ class: 'oc-input' }, attrs));
export const select = (options, value, attrs) => el('select', Object.assign({ class: 'oc-select' }, attrs || {}),
  options.map(([v, label]) => el('option', { value: v, selected: String(v) === String(value) }, label)));

const WORD = { New: 'Arriving', Requested: 'Needs your OK', Approving: 'Approving…', Confirmed: 'Booked', Arrived: 'Arrived', NoShow: 'No-show',
  Cancelled: 'Cancelled', Declined: 'Declined', Failed: 'Not booked', Discarded: 'Discarded', Review: 'To review', Approved: 'Sending', Sending: 'Sending', Sent: 'Sent', Dropped: 'Dropped' };
const TONE = { Requested: 'warn', Approving: 'warn', Arrived: 'good', NoShow: 'bad', Failed: 'bad', Review: 'warn', Sent: 'good' };
export const badge = (status) => el('span', { class: `oc-badge${TONE[status] ? ` oc-badge--${TONE[status]}` : ''}` }, WORD[status] || status || '—');
export const statusWord = (s) => WORD[s] || s;

/** The public booking page of this instance; with a channel, its ?src= link. */
export function publicLink(s, src) {
  const own = `${location.origin}${location.pathname.replace(/\/canvas\/a\/[^/]+\/?.*$/, '/canvas/a/tables-book/')}`;
  const base = (s && s.public_url) || own;
  return src ? `${base}?src=${encodeURIComponent(C.srcOf(src).toLowerCase())}` : base;
}
export async function copy(text, said) {
  try { await navigator.clipboard.writeText(text); Orch.toast(said || 'Copied.'); } catch { Orch.toast('Select the link and copy it.', { error: true }); }
}
export const code = (text) => el('div', { class: 'tb-code' }, [el('code', text), el('button', { type: 'button', class: 'oc-btn oc-btn--sm', onClick: () => copy(text, 'Link copied.') }, 'Copy')]);

/**
 * A destructive step in two: the first click opens a line that names what
 * else happens; its button stays inert until "I understand" is ticked.
 *   twoStep({ label, what, collateral: [..], yes, run })
 */
export function twoStep({ label, what, collateral, yes, run }) {
  const host = el('div', { class: 'tb-two' });
  const start = el('button', { type: 'button', class: 'oc-btn oc-btn--danger oc-btn--sm' }, label);
  start.addEventListener('click', () => {
    const ack = el('input', { type: 'checkbox' });
    const go = el('button', { type: 'button', class: 'oc-btn oc-btn--danger', disabled: true }, yes);
    ack.addEventListener('change', () => { go.disabled = !ack.checked; });
    go.addEventListener('click', async () => { go.disabled = true; await run(); });
    host.replaceChildren(el('div', { class: 'tb-two__box', role: 'alert' }, [
      el('p', { class: 'tb-two__what' }, what),
      el('ul', { class: 'tb-two__list' }, collateral.filter(Boolean).map((c) => el('li', c))),
      el('label', { class: 'tb-check' }, [ack, 'I understand']),
      el('div', { class: 'oc-row' }, [el('button', { type: 'button', class: 'oc-btn oc-btn--ghost', onClick: () => host.replaceChildren(start) }, 'Keep it'), go]),
    ]));
  });
  host.append(start);
  return host;
}

export const plural = (n, one, many) => `${n} ${Number(n) === 1 ? one : many}`;
export const sourceLabel = (b) => C.sourceLabel(b.source, b.src);
export const go = (path) => router.go(path);

/**
 * Look again which of Gmail and Resend is connected (the Send workflow's
 * --check), then call `after` once the settings row says so (up to ~40 s).
 * One look at a time.
 */
let looking = null;
export function lookAgain(after, { quiet = false } = {}) {
  if (!looking) {
    looking = (async () => {
      const before = S.resend_checked_at || '';
      if (await act(A.checkSenders, {}, quiet ? null : 'Looking at Gmail and Resend…')) {
        for (let i = 0; i < 20; i += 1) { await new Promise((r) => { setTimeout(r, 2000); }); if (((await settings()).resend_checked_at || '') !== before) break; }
      }
    })().finally(() => { looking = null; });
  }
  return looking.then(() => after && after());
}
/** Whether the last look is older than ten minutes (or there was none): Settings and Getting started then look on their own, once per visit. */
let lookedHere = false;
export function lookIfStale(s, after) {
  if (lookedHere) return;
  const at = s.resend_checked_at ? Date.parse(`${String(s.resend_checked_at).replace(' ', 'T')}Z`) : 0;
  if (at && Date.now() - at < 10 * 60000) return;
  lookedHere = true;
  // Redrawn with what it found only if nobody has started typing meanwhile: a look never wipes an edit.
  let touched = false;
  const mark = () => { touched = true; };
  document.addEventListener('input', mark, { capture: true, once: true });
  document.addEventListener('change', mark, { capture: true, once: true });
  lookAgain(() => { if (!touched && after) after(); }, { quiet: true });
}

/** Where Gmail and Resend are connected: the portal's Integrations, in the top window (the app is served from the instance, not the portal). */
const PORTAL_ORIGIN = (() => {
  try {
    const o = document.referrer ? new URL(document.referrer).origin : '';
    if (/^https:\/\/([a-z0-9-]+\.)*(hiorchestra\.com|orchestra-portal[a-z0-9-]*\.up\.railway\.app)$/.test(o)) return o;
  } catch { /* no referrer */ }
  return 'https://hiorchestra.com';
})();
export const INTEGRATIONS = `${PORTAL_ORIGIN}/portal/integrations`;
export const browserZone = () => { try { return Intl.DateTimeFormat().resolvedOptions().timeZone || 'UTC'; } catch { return 'UTC'; } };
export const ZONES = ['Europe/Madrid', 'Europe/Lisbon', 'Europe/London', 'Europe/Paris', 'Europe/Rome', 'Europe/Berlin', 'Atlantic/Canary', 'America/New_York', 'America/Chicago',
  'America/Los_Angeles', 'America/Mexico_City', 'America/Bogota', 'America/Lima', 'America/Santiago', 'America/Argentina/Buenos_Aires', 'America/Sao_Paulo', 'UTC'];
export const zoneSelect = (chosen) => select([...new Set([chosen || browserZone(), ...ZONES])].map((z) => [z, z.replace(/_/g, ' ')]), chosen || browserZone());
