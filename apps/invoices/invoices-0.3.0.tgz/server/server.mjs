var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// shared/invcore.js
var require_invcore = __commonJS({
  "shared/invcore.js"(exports, module) {
    (function(root, factory) {
      const api = factory();
      if (root) root.InvCore = api;
      if (typeof module === "object" && module && module.exports) module.exports = api;
    })(typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : exports, () => {
      "use strict";
      const CURRENCIES = ["EUR", "USD", "GBP", "CHF", "MXN", "COP", "ARS", "CLP", "PEN", "BRL", "CAD", "AUD", "SEK", "NOK", "DKK", "PLN", "JPY", "KWD"];
      const MAX_LINES = 60;
      function decimals(currency) {
        try {
          return new Intl.NumberFormat("en", { style: "currency", currency: String(currency || "EUR").toUpperCase() }).resolvedOptions().maximumFractionDigits;
        } catch {
          return 2;
        }
      }
      const scale = (currency) => 10 ** decimals(currency);
      function round(x) {
        const n = Number(x);
        if (!Number.isFinite(n)) return 0;
        const a = Math.floor(Math.abs(n) + 0.5 + 1e-9);
        return n < 0 ? -a : a;
      }
      function parseAmount(text) {
        if (typeof text === "number") return Number.isFinite(text) ? text : null;
        let s = String(text == null ? "" : text).replace(/[\s '€$£¥]/g, "").trim();
        if (!s) return null;
        const neg = /^-/.test(s);
        s = s.replace(/^[-+]/, "");
        const dot = s.lastIndexOf(".");
        const comma = s.lastIndexOf(",");
        if (dot >= 0 && comma >= 0) {
          const dec = dot > comma ? "." : ",";
          s = s.split(dec === "." ? "," : ".").join("").replace(dec, ".");
        } else if (comma >= 0) {
          s = /^\d{1,3}(,\d{3})+$/.test(s) && !/,\d{1,2}$/.test(s) ? s.replace(/,/g, "") : s.replace(",", ".");
        } else if (dot >= 0 && /^\d{1,3}(\.\d{3})+$/.test(s)) {
          s = s.replace(/\./g, "");
        }
        if (!/^\d+(\.\d+)?$/.test(s)) return null;
        const n = Number(s);
        return neg ? -n : n;
      }
      function toMinor(text, currency) {
        const n = parseAmount(text);
        return n === null ? null : round(n * scale(currency));
      }
      const fromMinor = (n, currency) => Number(n || 0) / scale(currency);
      function money2(n, currency, locale) {
        const cur = String(currency || "EUR").toUpperCase();
        try {
          return new Intl.NumberFormat(locale || void 0, { style: "currency", currency: cur }).format(fromMinor(n, cur));
        } catch {
          return `${fromMinor(n, cur).toFixed(decimals(cur))} ${cur}`;
        }
      }
      const plain = (n, currency) => fromMinor(n, currency).toFixed(decimals(currency));
      const pct = (v) => {
        const n = parseAmount(v);
        return n === null ? 0 : Math.max(0, Math.min(100, Math.round(n * 100) / 100));
      };
      const qtyOf = (v) => {
        const n = parseAmount(v);
        return n === null ? 0 : Math.round(n * 1e3) / 1e3;
      };
      function lineOf(raw2) {
        const r = raw2 && typeof raw2 === "object" ? raw2 : {};
        return {
          description: String(r.description == null ? "" : r.description).replace(/\r\n/g, "\n").slice(0, 600),
          qty: qtyOf(r.qty),
          price: Number.isFinite(Number(r.price)) ? Math.trunc(Number(r.price)) : 0,
          tax: pct(r.tax),
          disc: pct(r.disc)
        };
      }
      function linesOf(text) {
        let v = text;
        if (typeof v === "string") {
          try {
            v = JSON.parse(v || "[]");
          } catch {
            v = [];
          }
        }
        return (Array.isArray(v) ? v : []).slice(0, MAX_LINES).map(lineOf);
      }
      function totals(doc) {
        const lines = linesOf(doc && doc.lines).map((l) => {
          const net = round(l.qty * l.price * (100 - l.disc) / 100);
          return Object.assign({}, l, { net, taxAmount: round(net * l.tax / 100) });
        });
        const byRate = /* @__PURE__ */ new Map();
        for (const l of lines) {
          const g = byRate.get(l.tax) || { rate: l.tax, base: 0, tax: 0 };
          g.base += l.net;
          g.tax += l.taxAmount;
          byRate.set(l.tax, g);
        }
        const subtotal = lines.reduce((s, l) => s + l.net, 0);
        const taxes = [...byRate.values()].sort((a, b) => b.rate - a.rate);
        const taxTotal = taxes.reduce((s, g) => s + g.tax, 0);
        const withholdingRate = pct(doc && doc.withholding_rate);
        const withholding = round(subtotal * withholdingRate / 100);
        return { lines, subtotal, taxes, taxTotal, withholdingRate, withholding, total: subtotal + taxTotal - withholding };
      }
      const KINDS2 = ["quote", "invoice"];
      function numberOf(prefix, year, n, digits) {
        const d = Math.max(1, Math.min(6, Math.trunc(Number(digits)) || 4));
        return `${String(prefix || "").trim()}${year}-${String(n).padStart(d, "0")}`;
      }
      function seqOf(number, prefix, year) {
        const m = String(number || "").trim().match(/^(.*?)(\d{4})-(\d{1,6})$/);
        if (!m || m[1] !== String(prefix || "").trim() || Number(m[2]) !== Number(year)) return null;
        return Number(m[3]);
      }
      const prefixOf = (kind, s) => kind === "quote" ? s && s.quote_prefix != null ? s.quote_prefix : "Q-" : s && s.invoice_prefix != null ? s.invoice_prefix : "";
      const DAY = /^\d{4}-\d{2}-\d{2}$/;
      function realDay(v) {
        const s = String(v || "").slice(0, 10);
        if (!DAY.test(s)) return "";
        const d = /* @__PURE__ */ new Date(`${s}T00:00:00Z`);
        return !Number.isNaN(d.getTime()) && d.toISOString().slice(0, 10) === s ? s : "";
      }
      function addDays(day, n) {
        const d = /* @__PURE__ */ new Date(`${realDay(day) || "1970-01-01"}T00:00:00Z`);
        d.setUTCDate(d.getUTCDate() + Number(n || 0));
        return d.toISOString().slice(0, 10);
      }
      function today(tz, now) {
        const at = now ? new Date(now) : /* @__PURE__ */ new Date();
        try {
          return new Intl.DateTimeFormat("en-CA", { timeZone: tz || "UTC", year: "numeric", month: "2-digit", day: "2-digit" }).format(at);
        } catch {
          return at.toISOString().slice(0, 10);
        }
      }
      function offsetAt(tz, ms) {
        const p = {};
        for (const x of new Intl.DateTimeFormat("en-US", { timeZone: tz, hourCycle: "h23", year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", second: "2-digit" }).formatToParts(new Date(ms))) p[x.type] = x.value;
        const local = Date.UTC(Number(p.year), Number(p.month) - 1, Number(p.day), Number(p.hour) % 24, Number(p.minute), Number(p.second));
        return Math.round((local - Math.floor(ms / 1e3) * 1e3) / 6e4);
      }
      function tzWindow(tz, now) {
        const t0 = now ? new Date(now).getTime() : Date.now();
        let zone = tz || "UTC";
        try {
          offsetAt(zone, t0);
        } catch {
          zone = "UTC";
        }
        const offset = offsetAt(zone, t0);
        let lo = t0;
        let hi = null;
        for (let t = t0 + 864e5; t <= t0 + 400 * 864e5; t += 864e5) {
          if (offsetAt(zone, t) !== offset) {
            hi = t;
            break;
          }
          lo = t;
        }
        if (hi === null) return { tz_offset: offset, tz_change_at: "9999-12-31 00:00:00", tz_next_offset: offset };
        while (hi - lo > 1e3) {
          const mid = lo + Math.floor((hi - lo) / 2);
          if (offsetAt(zone, mid) === offset) lo = mid;
          else hi = mid;
        }
        const at = new Date(Math.floor(hi / 1e3) * 1e3).toISOString().slice(0, 19).replace("T", " ");
        return { tz_offset: offset, tz_change_at: at, tz_next_offset: offsetAt(zone, hi) };
      }
      const daysBetween = (a, b) => Math.round((Date.parse(`${b}T00:00:00Z`) - Date.parse(`${a}T00:00:00Z`)) / 864e5);
      const isEmail = (v) => /^[^\s@<>()"',;]+@[^\s@<>()"',;]+\.[a-z]{2,}$/i.test(String(v || "").trim());
      const normEmail = (v) => String(v || "").trim().toLowerCase();
      function issueProblems(doc, client) {
        const out = [];
        if (!client || !String(client.name || "").trim()) out.push("It has no client.");
        const t = totals(doc);
        if (!t.lines.length) out.push("It has no lines.");
        if (t.lines.some((l) => !l.description.trim())) out.push("A line has no description.");
        if (t.lines.some((l) => l.qty === 0)) out.push("A line has a quantity of zero.");
        if (t.total <= 0) out.push("Its total is not above zero.");
        if (!CURRENCIES.includes(String(doc && doc.currency || "").toUpperCase())) out.push("Its currency is not one Invoices knows.");
        if (doc && doc.due_date && !realDay(doc.due_date)) out.push("Its due date is not a real day.");
        return out;
      }
      function stateOf2(doc, day) {
        const st = doc && doc.status;
        if (st === "Issued" && doc.due_date && doc.due_date < day) return "Overdue";
        if (st === "Sent" && doc.due_date && doc.due_date < day) return "Expired";
        return st || "Draft";
      }
      const pick = (o, keys) => Object.fromEntries(keys.map((k) => [k, String(o && o[k] || "")]));
      function snapshot(doc, s, extra) {
        const t = totals(doc);
        let client = doc.client_snapshot;
        if (typeof client === "string") {
          try {
            client = JSON.parse(client);
          } catch {
            client = {};
          }
        }
        return {
          v: 1,
          lang: s && s.language === "es" ? "es" : "en",
          kind: doc.kind,
          status: doc.status,
          number: doc.number || "",
          title: String(doc.title || ""),
          issue_date: doc.issue_date || "",
          due_date: doc.due_date || "",
          currency: String(doc.currency || "EUR").toUpperCase(),
          company: pick(s, ["company_name", "tax_id", "address", "country", "email", "phone", "logo_url"]),
          client: pick(client || {}, ["name", "tax_id", "email", "address", "country"]),
          lines: t.lines.map((l) => ({ d: l.description, q: l.qty, p: l.price, t: l.tax, x: l.disc, n: l.net })),
          totals: { subtotal: t.subtotal, taxes: t.taxes, withholding_rate: t.withholdingRate, withholding: t.withholding, total: t.total },
          notes: String(doc.notes || ""),
          pay: doc.kind === "invoice" ? { bank: String(s && s.bank_details || ""), note: String(s && s.payment_note || ""), url: doc.status === "Issued" ? /^https:\/\//.test(String(doc.pay_url || "")) ? String(doc.pay_url) : doc.stripe_link_url && doc.stripe_link_active === "yes" ? doc.stripe_link_url : "" : "" } : null,
          paid_at: doc.paid_at || "",
          accepted: doc.accepted_at ? { name: doc.accepted_name || "", at: doc.accepted_at } : null,
          declined_at: doc.declined_at || "",
          void_at: doc.void_at || "",
          ...extra || {}
        };
      }
      const subtle = () => globalThis.crypto && globalThis.crypto.subtle || null;
      const enc = (s) => new TextEncoder().encode(s);
      const b64u = (bytes) => btoa(String.fromCharCode(...new Uint8Array(bytes))).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
      const unb64u = (s) => Uint8Array.from(atob(String(s).replace(/-/g, "+").replace(/_/g, "/") + "===".slice((String(s).length + 3) % 4)), (c) => c.charCodeAt(0));
      const hex = (bytes) => [...new Uint8Array(bytes)].map((b) => b.toString(16).padStart(2, "0")).join("");
      const TOKEN = /^[A-Za-z0-9_-]{22,64}$/;
      function newToken() {
        const b = new Uint8Array(16);
        globalThis.crypto.getRandomValues(b);
        return b64u(b);
      }
      async function linkKey(token) {
        return hex(await subtle().digest("SHA-256", enc(`inv-k:${token}`)));
      }
      async function boxKey(token, use) {
        const raw2 = await subtle().digest("SHA-256", enc(`inv-e:${token}`));
        return subtle().importKey("raw", raw2, { name: "AES-GCM" }, false, [use]);
      }
      async function seal(token, obj) {
        const iv = new Uint8Array(12);
        globalThis.crypto.getRandomValues(iv);
        const ct = await subtle().encrypt({ name: "AES-GCM", iv }, await boxKey(token, "encrypt"), enc(JSON.stringify(obj)));
        const out = new Uint8Array(12 + ct.byteLength);
        out.set(iv, 0);
        out.set(new Uint8Array(ct), 12);
        return b64u(out);
      }
      async function open(token, box) {
        try {
          const all = unb64u(box);
          const pt = await subtle().decrypt({ name: "AES-GCM", iv: all.slice(0, 12) }, await boxKey(token, "decrypt"), all.slice(12));
          return JSON.parse(new TextDecoder().decode(pt));
        } catch {
          return null;
        }
      }
      const WORDS = {
        en: {
          invoice: "invoice",
          quote: "quote",
          sendSubject: (d) => `${d.kind === "quote" ? "Quote" : "Invoice"} ${d.number} from ${d.company}`,
          sendBody: (d) => [
            `Hello${d.contact ? ` ${d.contact}` : ""},`,
            "",
            d.kind === "quote" ? `Here is our quote ${d.number}${d.title ? ` for ${d.title}` : ""}, for ${d.total}. It is valid until ${d.due}. You can read it, accept it or decline it here:` : `Here is invoice ${d.number}${d.title ? ` for ${d.title}` : ""}, for ${d.total}, due on ${d.due}. You can read it, save it as a PDF and pay it here:`,
            d.link,
            "",
            "Thank you,",
            d.company
          ].join("\n"),
          remindSubject: (d) => `Reminder: invoice ${d.number} is overdue`,
          remindBody: (d) => [
            `Hello${d.contact ? ` ${d.contact}` : ""},`,
            "",
            `Invoice ${d.number} for ${d.total} was due on ${d.due} and we have not received the payment yet. If it is already on its way, please ignore this message.`,
            "",
            "Thank you,",
            d.company
          ].join("\n"),
          view: "Read and pay it here"
        },
        es: {
          invoice: "factura",
          quote: "presupuesto",
          sendSubject: (d) => `${d.kind === "quote" ? "Presupuesto" : "Factura"} ${d.number} de ${d.company}`,
          sendBody: (d) => [
            `Hola${d.contact ? ` ${d.contact}` : ""}:`,
            "",
            d.kind === "quote" ? `Te enviamos nuestro presupuesto ${d.number}${d.title ? ` para ${d.title}` : ""}, por ${d.total}. Es v\xE1lido hasta el ${d.due}. Puedes verlo, aceptarlo o rechazarlo aqu\xED:` : `Te enviamos la factura ${d.number}${d.title ? ` por ${d.title}` : ""}, de ${d.total}, con vencimiento el ${d.due}. Puedes verla, guardarla en PDF y pagarla aqu\xED:`,
            d.link,
            "",
            "Gracias,",
            d.company
          ].join("\n"),
          remindSubject: (d) => `Recordatorio: la factura ${d.number} est\xE1 vencida`,
          remindBody: (d) => [
            `Hola${d.contact ? ` ${d.contact}` : ""}:`,
            "",
            `La factura ${d.number} de ${d.total} venc\xEDa el ${d.due} y todav\xEDa no hemos recibido el pago. Si ya est\xE1 en camino, ignora este mensaje.`,
            "",
            "Gracias,",
            d.company
          ].join("\n"),
          view: "Puedes verla y pagarla aqu\xED"
        }
      };
      const localeOf = (lang) => lang === "es" ? "es-ES" : "en-GB";
      function longDay(day, lang) {
        const d = realDay(day);
        if (!d) return "";
        return new Intl.DateTimeFormat(localeOf(lang), { day: "numeric", month: "long", year: "numeric", timeZone: "UTC" }).format(/* @__PURE__ */ new Date(`${d}T00:00:00Z`));
      }
      function mailFacts(doc, s, link) {
        const lang = s && s.language === "es" ? "es" : "en";
        let client = doc.client_snapshot;
        if (typeof client === "string") {
          try {
            client = JSON.parse(client);
          } catch {
            client = {};
          }
        }
        return {
          lang,
          kind: doc.kind,
          number: doc.number || "",
          title: String(doc.title || "").trim(),
          total: money2(Number.isFinite(Number(doc.total)) && doc.total !== null && doc.total !== "" ? Number(doc.total) : totals(doc).total, doc.currency, localeOf(lang)),
          due: longDay(doc.due_date, lang),
          link: link || "",
          company: String(s && s.company_name || "").trim(),
          contact: "",
          client: String(client && client.name || "")
        };
      }
      function sendEmail(doc, s, link) {
        const f = mailFacts(doc, s, link);
        const w = WORDS[f.lang];
        return { subject: w.sendSubject(f), body: w.sendBody(f) };
      }
      function reminderEmail(doc, s, link) {
        const f = mailFacts(doc, s, link);
        const w = WORDS[f.lang];
        return { subject: w.remindSubject(f), body: `${w.remindBody(f)}

${w.view}: ${link}` };
      }
      return {
        CURRENCIES,
        KINDS: KINDS2,
        MAX_LINES,
        TOKEN,
        WORDS,
        decimals,
        round,
        parseAmount,
        toMinor,
        fromMinor,
        money: money2,
        plain,
        pct,
        qtyOf,
        lineOf,
        linesOf,
        totals,
        numberOf,
        seqOf,
        prefixOf,
        realDay,
        addDays,
        today,
        tzWindow,
        daysBetween,
        isEmail,
        normEmail,
        issueProblems,
        stateOf: stateOf2,
        snapshot,
        newToken,
        linkKey,
        seal,
        open,
        b64u,
        localeOf,
        longDay,
        mailFacts,
        sendEmail,
        reminderEmail
      };
    });
  }
});

// .stack/node_modules/@hono/node-server/dist/index.mjs
import { createServer as createServerHTTP } from "http";
import { Http2ServerRequest as Http2ServerRequest2 } from "http2";
import { Http2ServerRequest } from "http2";
import { Readable } from "stream";
import crypto from "crypto";
var RequestError = class extends Error {
  constructor(message, options) {
    super(message, options);
    this.name = "RequestError";
  }
};
var toRequestError = (e) => {
  if (e instanceof RequestError) {
    return e;
  }
  return new RequestError(e.message, { cause: e });
};
var GlobalRequest = global.Request;
var Request2 = class extends GlobalRequest {
  constructor(input, options) {
    if (typeof input === "object" && getRequestCache in input) {
      input = input[getRequestCache]();
    }
    if (typeof options?.body?.getReader !== "undefined") {
      ;
      options.duplex ??= "half";
    }
    super(input, options);
  }
};
var wrapBodyStream = Symbol("wrapBodyStream");
var newRequestFromIncoming = (method, url, incoming, abortController) => {
  const headerRecord = [];
  const rawHeaders = incoming.rawHeaders;
  for (let i = 0; i < rawHeaders.length; i += 2) {
    const { [i]: key, [i + 1]: value } = rawHeaders;
    if (key.charCodeAt(0) !== /*:*/
    58) {
      headerRecord.push([key, value]);
    }
  }
  const init = {
    method,
    headers: headerRecord,
    signal: abortController.signal
  };
  if (method === "TRACE") {
    init.method = "GET";
    const req = new Request2(url, init);
    Object.defineProperty(req, "method", {
      get() {
        return "TRACE";
      }
    });
    return req;
  }
  if (!(method === "GET" || method === "HEAD")) {
    if ("rawBody" in incoming && incoming.rawBody instanceof Buffer) {
      init.body = new ReadableStream({
        start(controller) {
          controller.enqueue(incoming.rawBody);
          controller.close();
        }
      });
    } else if (incoming[wrapBodyStream]) {
      let reader;
      init.body = new ReadableStream({
        async pull(controller) {
          try {
            reader ||= Readable.toWeb(incoming).getReader();
            const { done, value } = await reader.read();
            if (done) {
              controller.close();
            } else {
              controller.enqueue(value);
            }
          } catch (error) {
            controller.error(error);
          }
        }
      });
    } else {
      init.body = Readable.toWeb(incoming);
    }
  }
  return new Request2(url, init);
};
var getRequestCache = Symbol("getRequestCache");
var requestCache = Symbol("requestCache");
var incomingKey = Symbol("incomingKey");
var urlKey = Symbol("urlKey");
var abortControllerKey = Symbol("abortControllerKey");
var getAbortController = Symbol("getAbortController");
var requestPrototype = {
  get method() {
    return this[incomingKey].method || "GET";
  },
  get url() {
    return this[urlKey];
  },
  [getAbortController]() {
    this[getRequestCache]();
    return this[abortControllerKey];
  },
  [getRequestCache]() {
    this[abortControllerKey] ||= new AbortController();
    return this[requestCache] ||= newRequestFromIncoming(
      this.method,
      this[urlKey],
      this[incomingKey],
      this[abortControllerKey]
    );
  }
};
[
  "body",
  "bodyUsed",
  "cache",
  "credentials",
  "destination",
  "headers",
  "integrity",
  "mode",
  "redirect",
  "referrer",
  "referrerPolicy",
  "signal",
  "keepalive"
].forEach((k) => {
  Object.defineProperty(requestPrototype, k, {
    get() {
      return this[getRequestCache]()[k];
    }
  });
});
["arrayBuffer", "blob", "clone", "formData", "json", "text"].forEach((k) => {
  Object.defineProperty(requestPrototype, k, {
    value: function() {
      return this[getRequestCache]()[k]();
    }
  });
});
Object.setPrototypeOf(requestPrototype, Request2.prototype);
var newRequest = (incoming, defaultHostname) => {
  const req = Object.create(requestPrototype);
  req[incomingKey] = incoming;
  const incomingUrl = incoming.url || "";
  if (incomingUrl[0] !== "/" && // short-circuit for performance. most requests are relative URL.
  (incomingUrl.startsWith("http://") || incomingUrl.startsWith("https://"))) {
    if (incoming instanceof Http2ServerRequest) {
      throw new RequestError("Absolute URL for :path is not allowed in HTTP/2");
    }
    try {
      const url2 = new URL(incomingUrl);
      req[urlKey] = url2.href;
    } catch (e) {
      throw new RequestError("Invalid absolute URL", { cause: e });
    }
    return req;
  }
  const host = (incoming instanceof Http2ServerRequest ? incoming.authority : incoming.headers.host) || defaultHostname;
  if (!host) {
    throw new RequestError("Missing host header");
  }
  let scheme;
  if (incoming instanceof Http2ServerRequest) {
    scheme = incoming.scheme;
    if (!(scheme === "http" || scheme === "https")) {
      throw new RequestError("Unsupported scheme");
    }
  } else {
    scheme = incoming.socket && incoming.socket.encrypted ? "https" : "http";
  }
  const url = new URL(`${scheme}://${host}${incomingUrl}`);
  if (url.hostname.length !== host.length && url.hostname !== host.replace(/:\d+$/, "")) {
    throw new RequestError("Invalid host header");
  }
  req[urlKey] = url.href;
  return req;
};
var responseCache = Symbol("responseCache");
var getResponseCache = Symbol("getResponseCache");
var cacheKey = Symbol("cache");
var GlobalResponse = global.Response;
var Response2 = class _Response {
  #body;
  #init;
  [getResponseCache]() {
    delete this[cacheKey];
    return this[responseCache] ||= new GlobalResponse(this.#body, this.#init);
  }
  constructor(body, init) {
    let headers;
    this.#body = body;
    if (init instanceof _Response) {
      const cachedGlobalResponse = init[responseCache];
      if (cachedGlobalResponse) {
        this.#init = cachedGlobalResponse;
        this[getResponseCache]();
        return;
      } else {
        this.#init = init.#init;
        headers = new Headers(init.#init.headers);
      }
    } else {
      this.#init = init;
    }
    if (typeof body === "string" || typeof body?.getReader !== "undefined" || body instanceof Blob || body instanceof Uint8Array) {
      headers ||= init?.headers || { "content-type": "text/plain; charset=UTF-8" };
      this[cacheKey] = [init?.status || 200, body, headers];
    }
  }
  get headers() {
    const cache = this[cacheKey];
    if (cache) {
      if (!(cache[2] instanceof Headers)) {
        cache[2] = new Headers(cache[2]);
      }
      return cache[2];
    }
    return this[getResponseCache]().headers;
  }
  get status() {
    return this[cacheKey]?.[0] ?? this[getResponseCache]().status;
  }
  get ok() {
    const status = this.status;
    return status >= 200 && status < 300;
  }
};
["body", "bodyUsed", "redirected", "statusText", "trailers", "type", "url"].forEach((k) => {
  Object.defineProperty(Response2.prototype, k, {
    get() {
      return this[getResponseCache]()[k];
    }
  });
});
["arrayBuffer", "blob", "clone", "formData", "json", "text"].forEach((k) => {
  Object.defineProperty(Response2.prototype, k, {
    value: function() {
      return this[getResponseCache]()[k]();
    }
  });
});
Object.setPrototypeOf(Response2, GlobalResponse);
Object.setPrototypeOf(Response2.prototype, GlobalResponse.prototype);
async function readWithoutBlocking(readPromise) {
  return Promise.race([readPromise, Promise.resolve().then(() => Promise.resolve(void 0))]);
}
function writeFromReadableStreamDefaultReader(reader, writable, currentReadPromise) {
  const handleError = () => {
  };
  writable.on("error", handleError);
  (currentReadPromise ?? reader.read()).then(flow, handleStreamError);
  return reader.closed.finally(() => {
    writable.off("error", handleError);
  });
  function handleStreamError(error) {
    if (error) {
      writable.destroy(error);
    }
  }
  function onDrain() {
    reader.read().then(flow, handleStreamError);
  }
  function flow({ done, value }) {
    try {
      if (done) {
        writable.end();
      } else if (!writable.write(value)) {
        writable.once("drain", onDrain);
      } else {
        return reader.read().then(flow, handleStreamError);
      }
    } catch (e) {
      handleStreamError(e);
    }
  }
}
function writeFromReadableStream(stream, writable) {
  if (stream.locked) {
    throw new TypeError("ReadableStream is locked.");
  } else if (writable.destroyed) {
    return;
  }
  return writeFromReadableStreamDefaultReader(stream.getReader(), writable);
}
var buildOutgoingHttpHeaders = (headers) => {
  const res = {};
  if (!(headers instanceof Headers)) {
    headers = new Headers(headers ?? void 0);
  }
  const cookies = [];
  for (const [k, v] of headers) {
    if (k === "set-cookie") {
      cookies.push(v);
    } else {
      res[k] = v;
    }
  }
  if (cookies.length > 0) {
    res["set-cookie"] = cookies;
  }
  res["content-type"] ??= "text/plain; charset=UTF-8";
  return res;
};
var X_ALREADY_SENT = "x-hono-already-sent";
var webFetch = global.fetch;
if (typeof global.crypto === "undefined") {
  global.crypto = crypto;
}
global.fetch = (info, init) => {
  init = {
    // Disable compression handling so people can return the result of a fetch
    // directly in the loader without messing with the Content-Encoding header.
    compress: false,
    ...init
  };
  return webFetch(info, init);
};
var outgoingEnded = Symbol("outgoingEnded");
var handleRequestError = () => new Response(null, {
  status: 400
});
var handleFetchError = (e) => new Response(null, {
  status: e instanceof Error && (e.name === "TimeoutError" || e.constructor.name === "TimeoutError") ? 504 : 500
});
var handleResponseError = (e, outgoing) => {
  const err = e instanceof Error ? e : new Error("unknown error", { cause: e });
  if (err.code === "ERR_STREAM_PREMATURE_CLOSE") {
    console.info("The user aborted a request.");
  } else {
    console.error(e);
    if (!outgoing.headersSent) {
      outgoing.writeHead(500, { "Content-Type": "text/plain" });
    }
    outgoing.end(`Error: ${err.message}`);
    outgoing.destroy(err);
  }
};
var flushHeaders = (outgoing) => {
  if ("flushHeaders" in outgoing && outgoing.writable) {
    outgoing.flushHeaders();
  }
};
var responseViaCache = async (res, outgoing) => {
  let [status, body, header] = res[cacheKey];
  if (header instanceof Headers) {
    header = buildOutgoingHttpHeaders(header);
  }
  if (typeof body === "string") {
    header["Content-Length"] = Buffer.byteLength(body);
  } else if (body instanceof Uint8Array) {
    header["Content-Length"] = body.byteLength;
  } else if (body instanceof Blob) {
    header["Content-Length"] = body.size;
  }
  outgoing.writeHead(status, header);
  if (typeof body === "string" || body instanceof Uint8Array) {
    outgoing.end(body);
  } else if (body instanceof Blob) {
    outgoing.end(new Uint8Array(await body.arrayBuffer()));
  } else {
    flushHeaders(outgoing);
    await writeFromReadableStream(body, outgoing)?.catch(
      (e) => handleResponseError(e, outgoing)
    );
  }
  ;
  outgoing[outgoingEnded]?.();
};
var responseViaResponseObject = async (res, outgoing, options = {}) => {
  if (res instanceof Promise) {
    if (options.errorHandler) {
      try {
        res = await res;
      } catch (err) {
        const errRes = await options.errorHandler(err);
        if (!errRes) {
          return;
        }
        res = errRes;
      }
    } else {
      res = await res.catch(handleFetchError);
    }
  }
  if (cacheKey in res) {
    return responseViaCache(res, outgoing);
  }
  const resHeaderRecord = buildOutgoingHttpHeaders(res.headers);
  if (res.body) {
    const reader = res.body.getReader();
    const values = [];
    let done = false;
    let currentReadPromise = void 0;
    if (resHeaderRecord["transfer-encoding"] !== "chunked") {
      let maxReadCount = 2;
      for (let i = 0; i < maxReadCount; i++) {
        currentReadPromise ||= reader.read();
        const chunk = await readWithoutBlocking(currentReadPromise).catch((e) => {
          console.error(e);
          done = true;
        });
        if (!chunk) {
          if (i === 1) {
            await new Promise((resolve) => setTimeout(resolve));
            maxReadCount = 3;
            continue;
          }
          break;
        }
        currentReadPromise = void 0;
        if (chunk.value) {
          values.push(chunk.value);
        }
        if (chunk.done) {
          done = true;
          break;
        }
      }
      if (done && !("content-length" in resHeaderRecord)) {
        resHeaderRecord["content-length"] = values.reduce((acc, value) => acc + value.length, 0);
      }
    }
    outgoing.writeHead(res.status, resHeaderRecord);
    values.forEach((value) => {
      ;
      outgoing.write(value);
    });
    if (done) {
      outgoing.end();
    } else {
      if (values.length === 0) {
        flushHeaders(outgoing);
      }
      await writeFromReadableStreamDefaultReader(reader, outgoing, currentReadPromise);
    }
  } else if (resHeaderRecord[X_ALREADY_SENT]) {
  } else {
    outgoing.writeHead(res.status, resHeaderRecord);
    outgoing.end();
  }
  ;
  outgoing[outgoingEnded]?.();
};
var getRequestListener = (fetchCallback, options = {}) => {
  const autoCleanupIncoming = options.autoCleanupIncoming ?? true;
  if (options.overrideGlobalObjects !== false && global.Request !== Request2) {
    Object.defineProperty(global, "Request", {
      value: Request2
    });
    Object.defineProperty(global, "Response", {
      value: Response2
    });
  }
  return async (incoming, outgoing) => {
    let res, req;
    try {
      req = newRequest(incoming, options.hostname);
      let incomingEnded = !autoCleanupIncoming || incoming.method === "GET" || incoming.method === "HEAD";
      if (!incomingEnded) {
        ;
        incoming[wrapBodyStream] = true;
        incoming.on("end", () => {
          incomingEnded = true;
        });
        if (incoming instanceof Http2ServerRequest2) {
          ;
          outgoing[outgoingEnded] = () => {
            if (!incomingEnded) {
              setTimeout(() => {
                if (!incomingEnded) {
                  setTimeout(() => {
                    incoming.destroy();
                    outgoing.destroy();
                  });
                }
              });
            }
          };
        }
      }
      outgoing.on("close", () => {
        const abortController = req[abortControllerKey];
        if (abortController) {
          if (incoming.errored) {
            req[abortControllerKey].abort(incoming.errored.toString());
          } else if (!outgoing.writableFinished) {
            req[abortControllerKey].abort("Client connection prematurely closed.");
          }
        }
        if (!incomingEnded) {
          setTimeout(() => {
            if (!incomingEnded) {
              setTimeout(() => {
                incoming.destroy();
              });
            }
          });
        }
      });
      res = fetchCallback(req, { incoming, outgoing });
      if (cacheKey in res) {
        return responseViaCache(res, outgoing);
      }
    } catch (e) {
      if (!res) {
        if (options.errorHandler) {
          res = await options.errorHandler(req ? e : toRequestError(e));
          if (!res) {
            return;
          }
        } else if (!req) {
          res = handleRequestError();
        } else {
          res = handleFetchError(e);
        }
      } else {
        return handleResponseError(e, outgoing);
      }
    }
    try {
      return await responseViaResponseObject(res, outgoing, options);
    } catch (e) {
      return handleResponseError(e, outgoing);
    }
  };
};
var createAdaptorServer = (options) => {
  const fetchCallback = options.fetch;
  const requestListener = getRequestListener(fetchCallback, {
    hostname: options.hostname,
    overrideGlobalObjects: options.overrideGlobalObjects,
    autoCleanupIncoming: options.autoCleanupIncoming
  });
  const createServer = options.createServer || createServerHTTP;
  const server = createServer(options.serverOptions || {}, requestListener);
  return server;
};
var serve = (options, listeningListener) => {
  const server = createAdaptorServer(options);
  server.listen(options?.port ?? 3e3, options.hostname, () => {
    const serverInfo = server.address();
    listeningListener && listeningListener(serverInfo);
  });
  return server;
};

// .stack/node_modules/hono/dist/compose.js
var compose = (middleware, onError, onNotFound) => {
  return (context, next) => {
    let index = -1;
    return dispatch(0);
    async function dispatch(i) {
      if (i <= index) {
        throw new Error("next() called multiple times");
      }
      index = i;
      let res;
      let isError = false;
      let handler;
      if (middleware[i]) {
        handler = middleware[i][0][0];
        context.req.routeIndex = i;
      } else {
        handler = i === middleware.length && next || void 0;
      }
      if (handler) {
        try {
          res = await handler(context, () => dispatch(i + 1));
        } catch (err) {
          if (err instanceof Error && onError) {
            context.error = err;
            res = await onError(err, context);
            isError = true;
          } else {
            throw err;
          }
        }
      } else {
        if (context.finalized === false && onNotFound) {
          res = await onNotFound(context);
        }
      }
      if (res && (context.finalized === false || isError)) {
        context.res = res;
      }
      return context;
    }
  };
};

// .stack/node_modules/hono/dist/request/constants.js
var GET_MATCH_RESULT = /* @__PURE__ */ Symbol();

// .stack/node_modules/hono/dist/utils/body.js
var parseBody = async (request, options = /* @__PURE__ */ Object.create(null)) => {
  const { all = false, dot = false } = options;
  const headers = request instanceof HonoRequest ? request.raw.headers : request.headers;
  const contentType = headers.get("Content-Type");
  if (contentType?.startsWith("multipart/form-data") || contentType?.startsWith("application/x-www-form-urlencoded")) {
    return parseFormData(request, { all, dot });
  }
  return {};
};
async function parseFormData(request, options) {
  const formData = await request.formData();
  if (formData) {
    return convertFormDataToBodyData(formData, options);
  }
  return {};
}
function convertFormDataToBodyData(formData, options) {
  const form = /* @__PURE__ */ Object.create(null);
  formData.forEach((value, key) => {
    const shouldParseAllValues = options.all || key.endsWith("[]");
    if (!shouldParseAllValues) {
      form[key] = value;
    } else {
      handleParsingAllValues(form, key, value);
    }
  });
  if (options.dot) {
    Object.entries(form).forEach(([key, value]) => {
      const shouldParseDotValues = key.includes(".");
      if (shouldParseDotValues) {
        handleParsingNestedValues(form, key, value);
        delete form[key];
      }
    });
  }
  return form;
}
var handleParsingAllValues = (form, key, value) => {
  if (form[key] !== void 0) {
    if (Array.isArray(form[key])) {
      ;
      form[key].push(value);
    } else {
      form[key] = [form[key], value];
    }
  } else {
    if (!key.endsWith("[]")) {
      form[key] = value;
    } else {
      form[key] = [value];
    }
  }
};
var handleParsingNestedValues = (form, key, value) => {
  let nestedForm = form;
  const keys = key.split(".");
  keys.forEach((key2, index) => {
    if (index === keys.length - 1) {
      nestedForm[key2] = value;
    } else {
      if (!nestedForm[key2] || typeof nestedForm[key2] !== "object" || Array.isArray(nestedForm[key2]) || nestedForm[key2] instanceof File) {
        nestedForm[key2] = /* @__PURE__ */ Object.create(null);
      }
      nestedForm = nestedForm[key2];
    }
  });
};

// .stack/node_modules/hono/dist/utils/url.js
var splitPath = (path) => {
  const paths = path.split("/");
  if (paths[0] === "") {
    paths.shift();
  }
  return paths;
};
var splitRoutingPath = (routePath) => {
  const { groups, path } = extractGroupsFromPath(routePath);
  const paths = splitPath(path);
  return replaceGroupMarks(paths, groups);
};
var extractGroupsFromPath = (path) => {
  const groups = [];
  path = path.replace(/\{[^}]+\}/g, (match2, index) => {
    const mark = `@${index}`;
    groups.push([mark, match2]);
    return mark;
  });
  return { groups, path };
};
var replaceGroupMarks = (paths, groups) => {
  for (let i = groups.length - 1; i >= 0; i--) {
    const [mark] = groups[i];
    for (let j = paths.length - 1; j >= 0; j--) {
      if (paths[j].includes(mark)) {
        paths[j] = paths[j].replace(mark, groups[i][1]);
        break;
      }
    }
  }
  return paths;
};
var patternCache = {};
var getPattern = (label, next) => {
  if (label === "*") {
    return "*";
  }
  const match2 = label.match(/^\:([^\{\}]+)(?:\{(.+)\})?$/);
  if (match2) {
    const cacheKey2 = `${label}#${next}`;
    if (!patternCache[cacheKey2]) {
      if (match2[2]) {
        patternCache[cacheKey2] = next && next[0] !== ":" && next[0] !== "*" ? [cacheKey2, match2[1], new RegExp(`^${match2[2]}(?=/${next})`)] : [label, match2[1], new RegExp(`^${match2[2]}$`)];
      } else {
        patternCache[cacheKey2] = [label, match2[1], true];
      }
    }
    return patternCache[cacheKey2];
  }
  return null;
};
var tryDecode = (str, decoder) => {
  try {
    return decoder(str);
  } catch {
    return str.replace(/(?:%[0-9A-Fa-f]{2})+/g, (match2) => {
      try {
        return decoder(match2);
      } catch {
        return match2;
      }
    });
  }
};
var tryDecodeURI = (str) => tryDecode(str, decodeURI);
var getPath = (request) => {
  const url = request.url;
  const start = url.indexOf("/", url.indexOf(":") + 4);
  let i = start;
  for (; i < url.length; i++) {
    const charCode = url.charCodeAt(i);
    if (charCode === 37) {
      const queryIndex = url.indexOf("?", i);
      const hashIndex = url.indexOf("#", i);
      const end = queryIndex === -1 ? hashIndex === -1 ? void 0 : hashIndex : hashIndex === -1 ? queryIndex : Math.min(queryIndex, hashIndex);
      const path = url.slice(start, end);
      return tryDecodeURI(path.includes("%25") ? path.replace(/%25/g, "%2525") : path);
    } else if (charCode === 63 || charCode === 35) {
      break;
    }
  }
  return url.slice(start, i);
};
var getPathNoStrict = (request) => {
  const result = getPath(request);
  return result.length > 1 && result.at(-1) === "/" ? result.slice(0, -1) : result;
};
var mergePath = (base, sub, ...rest) => {
  if (rest.length) {
    sub = mergePath(sub, ...rest);
  }
  return `${base?.[0] === "/" ? "" : "/"}${base}${sub === "/" ? "" : `${base?.at(-1) === "/" ? "" : "/"}${sub?.[0] === "/" ? sub.slice(1) : sub}`}`;
};
var checkOptionalParameter = (path) => {
  if (path.charCodeAt(path.length - 1) !== 63 || !path.includes(":")) {
    return null;
  }
  const segments = path.split("/");
  const results = [];
  let basePath = "";
  segments.forEach((segment) => {
    if (segment !== "" && !/\:/.test(segment)) {
      basePath += "/" + segment;
    } else if (/\:/.test(segment)) {
      if (/\?/.test(segment)) {
        if (results.length === 0 && basePath === "") {
          results.push("/");
        } else {
          results.push(basePath);
        }
        const optionalSegment = segment.replace("?", "");
        basePath += "/" + optionalSegment;
        results.push(basePath);
      } else {
        basePath += "/" + segment;
      }
    }
  });
  return results.filter((v, i, a) => a.indexOf(v) === i);
};
var _decodeURI = (value) => {
  if (!/[%+]/.test(value)) {
    return value;
  }
  if (value.indexOf("+") !== -1) {
    value = value.replace(/\+/g, " ");
  }
  return value.indexOf("%") !== -1 ? tryDecode(value, decodeURIComponent_) : value;
};
var _getQueryParam = (url, key, multiple) => {
  let encoded;
  if (!multiple && key && !/[%+]/.test(key)) {
    let keyIndex2 = url.indexOf("?", 8);
    if (keyIndex2 === -1) {
      return void 0;
    }
    if (!url.startsWith(key, keyIndex2 + 1)) {
      keyIndex2 = url.indexOf(`&${key}`, keyIndex2 + 1);
    }
    while (keyIndex2 !== -1) {
      const trailingKeyCode = url.charCodeAt(keyIndex2 + key.length + 1);
      if (trailingKeyCode === 61) {
        const valueIndex = keyIndex2 + key.length + 2;
        const endIndex = url.indexOf("&", valueIndex);
        return _decodeURI(url.slice(valueIndex, endIndex === -1 ? void 0 : endIndex));
      } else if (trailingKeyCode == 38 || isNaN(trailingKeyCode)) {
        return "";
      }
      keyIndex2 = url.indexOf(`&${key}`, keyIndex2 + 1);
    }
    encoded = /[%+]/.test(url);
    if (!encoded) {
      return void 0;
    }
  }
  const results = {};
  encoded ??= /[%+]/.test(url);
  let keyIndex = url.indexOf("?", 8);
  while (keyIndex !== -1) {
    const nextKeyIndex = url.indexOf("&", keyIndex + 1);
    let valueIndex = url.indexOf("=", keyIndex);
    if (valueIndex > nextKeyIndex && nextKeyIndex !== -1) {
      valueIndex = -1;
    }
    let name = url.slice(
      keyIndex + 1,
      valueIndex === -1 ? nextKeyIndex === -1 ? void 0 : nextKeyIndex : valueIndex
    );
    if (encoded) {
      name = _decodeURI(name);
    }
    keyIndex = nextKeyIndex;
    if (name === "") {
      continue;
    }
    let value;
    if (valueIndex === -1) {
      value = "";
    } else {
      value = url.slice(valueIndex + 1, nextKeyIndex === -1 ? void 0 : nextKeyIndex);
      if (encoded) {
        value = _decodeURI(value);
      }
    }
    if (multiple) {
      if (!(results[name] && Array.isArray(results[name]))) {
        results[name] = [];
      }
      ;
      results[name].push(value);
    } else {
      results[name] ??= value;
    }
  }
  return key ? results[key] : results;
};
var getQueryParam = _getQueryParam;
var getQueryParams = (url, key) => {
  return _getQueryParam(url, key, true);
};
var decodeURIComponent_ = decodeURIComponent;

// .stack/node_modules/hono/dist/request.js
var tryDecodeURIComponent = (str) => tryDecode(str, decodeURIComponent_);
var HonoRequest = class {
  /**
   * `.raw` can get the raw Request object.
   *
   * @see {@link https://hono.dev/docs/api/request#raw}
   *
   * @example
   * ```ts
   * // For Cloudflare Workers
   * app.post('/', async (c) => {
   *   const metadata = c.req.raw.cf?.hostMetadata?
   *   ...
   * })
   * ```
   */
  raw;
  #validatedData;
  // Short name of validatedData
  #matchResult;
  routeIndex = 0;
  /**
   * `.path` can get the pathname of the request.
   *
   * @see {@link https://hono.dev/docs/api/request#path}
   *
   * @example
   * ```ts
   * app.get('/about/me', (c) => {
   *   const pathname = c.req.path // `/about/me`
   * })
   * ```
   */
  path;
  bodyCache = {};
  constructor(request, path = "/", matchResult = [[]]) {
    this.raw = request;
    this.path = path;
    this.#matchResult = matchResult;
    this.#validatedData = {};
  }
  param(key) {
    return key ? this.#getDecodedParam(key) : this.#getAllDecodedParams();
  }
  #getDecodedParam(key) {
    const paramKey = this.#matchResult[0][this.routeIndex][1][key];
    const param = this.#getParamValue(paramKey);
    return param && /\%/.test(param) ? tryDecodeURIComponent(param) : param;
  }
  #getAllDecodedParams() {
    const decoded = {};
    const keys = Object.keys(this.#matchResult[0][this.routeIndex][1]);
    for (const key of keys) {
      const value = this.#getParamValue(this.#matchResult[0][this.routeIndex][1][key]);
      if (value !== void 0) {
        decoded[key] = /\%/.test(value) ? tryDecodeURIComponent(value) : value;
      }
    }
    return decoded;
  }
  #getParamValue(paramKey) {
    return this.#matchResult[1] ? this.#matchResult[1][paramKey] : paramKey;
  }
  query(key) {
    return getQueryParam(this.url, key);
  }
  queries(key) {
    return getQueryParams(this.url, key);
  }
  header(name) {
    if (name) {
      return this.raw.headers.get(name) ?? void 0;
    }
    const headerData = {};
    this.raw.headers.forEach((value, key) => {
      headerData[key] = value;
    });
    return headerData;
  }
  async parseBody(options) {
    return this.bodyCache.parsedBody ??= await parseBody(this, options);
  }
  #cachedBody = (key) => {
    const { bodyCache, raw: raw2 } = this;
    const cachedBody = bodyCache[key];
    if (cachedBody) {
      return cachedBody;
    }
    const anyCachedKey = Object.keys(bodyCache)[0];
    if (anyCachedKey) {
      return bodyCache[anyCachedKey].then((body) => {
        if (anyCachedKey === "json") {
          body = JSON.stringify(body);
        }
        return new Response(body)[key]();
      });
    }
    return bodyCache[key] = raw2[key]();
  };
  /**
   * `.json()` can parse Request body of type `application/json`
   *
   * @see {@link https://hono.dev/docs/api/request#json}
   *
   * @example
   * ```ts
   * app.post('/entry', async (c) => {
   *   const body = await c.req.json()
   * })
   * ```
   */
  json() {
    return this.#cachedBody("text").then((text) => JSON.parse(text));
  }
  /**
   * `.text()` can parse Request body of type `text/plain`
   *
   * @see {@link https://hono.dev/docs/api/request#text}
   *
   * @example
   * ```ts
   * app.post('/entry', async (c) => {
   *   const body = await c.req.text()
   * })
   * ```
   */
  text() {
    return this.#cachedBody("text");
  }
  /**
   * `.arrayBuffer()` parse Request body as an `ArrayBuffer`
   *
   * @see {@link https://hono.dev/docs/api/request#arraybuffer}
   *
   * @example
   * ```ts
   * app.post('/entry', async (c) => {
   *   const body = await c.req.arrayBuffer()
   * })
   * ```
   */
  arrayBuffer() {
    return this.#cachedBody("arrayBuffer");
  }
  /**
   * Parses the request body as a `Blob`.
   * @example
   * ```ts
   * app.post('/entry', async (c) => {
   *   const body = await c.req.blob();
   * });
   * ```
   * @see https://hono.dev/docs/api/request#blob
   */
  blob() {
    return this.#cachedBody("blob");
  }
  /**
   * Parses the request body as `FormData`.
   * @example
   * ```ts
   * app.post('/entry', async (c) => {
   *   const body = await c.req.formData();
   * });
   * ```
   * @see https://hono.dev/docs/api/request#formdata
   */
  formData() {
    return this.#cachedBody("formData");
  }
  /**
   * Adds validated data to the request.
   *
   * @param target - The target of the validation.
   * @param data - The validated data to add.
   */
  addValidatedData(target, data) {
    this.#validatedData[target] = data;
  }
  valid(target) {
    return this.#validatedData[target];
  }
  /**
   * `.url()` can get the request url strings.
   *
   * @see {@link https://hono.dev/docs/api/request#url}
   *
   * @example
   * ```ts
   * app.get('/about/me', (c) => {
   *   const url = c.req.url // `http://localhost:8787/about/me`
   *   ...
   * })
   * ```
   */
  get url() {
    return this.raw.url;
  }
  /**
   * `.method()` can get the method name of the request.
   *
   * @see {@link https://hono.dev/docs/api/request#method}
   *
   * @example
   * ```ts
   * app.get('/about/me', (c) => {
   *   const method = c.req.method // `GET`
   * })
   * ```
   */
  get method() {
    return this.raw.method;
  }
  get [GET_MATCH_RESULT]() {
    return this.#matchResult;
  }
  /**
   * `.matchedRoutes()` can return a matched route in the handler
   *
   * @deprecated
   *
   * Use matchedRoutes helper defined in "hono/route" instead.
   *
   * @see {@link https://hono.dev/docs/api/request#matchedroutes}
   *
   * @example
   * ```ts
   * app.use('*', async function logger(c, next) {
   *   await next()
   *   c.req.matchedRoutes.forEach(({ handler, method, path }, i) => {
   *     const name = handler.name || (handler.length < 2 ? '[handler]' : '[middleware]')
   *     console.log(
   *       method,
   *       ' ',
   *       path,
   *       ' '.repeat(Math.max(10 - path.length, 0)),
   *       name,
   *       i === c.req.routeIndex ? '<- respond from here' : ''
   *     )
   *   })
   * })
   * ```
   */
  get matchedRoutes() {
    return this.#matchResult[0].map(([[, route]]) => route);
  }
  /**
   * `routePath()` can retrieve the path registered within the handler
   *
   * @deprecated
   *
   * Use routePath helper defined in "hono/route" instead.
   *
   * @see {@link https://hono.dev/docs/api/request#routepath}
   *
   * @example
   * ```ts
   * app.get('/posts/:id', (c) => {
   *   return c.json({ path: c.req.routePath })
   * })
   * ```
   */
  get routePath() {
    return this.#matchResult[0].map(([[, route]]) => route)[this.routeIndex].path;
  }
};

// .stack/node_modules/hono/dist/utils/html.js
var HtmlEscapedCallbackPhase = {
  Stringify: 1,
  BeforeStream: 2,
  Stream: 3
};
var raw = (value, callbacks) => {
  const escapedString = new String(value);
  escapedString.isEscaped = true;
  escapedString.callbacks = callbacks;
  return escapedString;
};
var resolveCallback = async (str, phase, preserveCallbacks, context, buffer) => {
  if (typeof str === "object" && !(str instanceof String)) {
    if (!(str instanceof Promise)) {
      str = str.toString();
    }
    if (str instanceof Promise) {
      str = await str;
    }
  }
  const callbacks = str.callbacks;
  if (!callbacks?.length) {
    return Promise.resolve(str);
  }
  if (buffer) {
    buffer[0] += str;
  } else {
    buffer = [str];
  }
  const resStr = Promise.all(callbacks.map((c) => c({ phase, buffer, context }))).then(
    (res) => Promise.all(
      res.filter(Boolean).map((str2) => resolveCallback(str2, phase, false, context, buffer))
    ).then(() => buffer[0])
  );
  if (preserveCallbacks) {
    return raw(await resStr, callbacks);
  } else {
    return resStr;
  }
};

// .stack/node_modules/hono/dist/context.js
var TEXT_PLAIN = "text/plain; charset=UTF-8";
var setDefaultContentType = (contentType, headers) => {
  return {
    "Content-Type": contentType,
    ...headers
  };
};
var createResponseInstance = (body, init) => new Response(body, init);
var Context = class {
  #rawRequest;
  #req;
  /**
   * `.env` can get bindings (environment variables, secrets, KV namespaces, D1 database, R2 bucket etc.) in Cloudflare Workers.
   *
   * @see {@link https://hono.dev/docs/api/context#env}
   *
   * @example
   * ```ts
   * // Environment object for Cloudflare Workers
   * app.get('*', async c => {
   *   const counter = c.env.COUNTER
   * })
   * ```
   */
  env = {};
  #var;
  finalized = false;
  /**
   * `.error` can get the error object from the middleware if the Handler throws an error.
   *
   * @see {@link https://hono.dev/docs/api/context#error}
   *
   * @example
   * ```ts
   * app.use('*', async (c, next) => {
   *   await next()
   *   if (c.error) {
   *     // do something...
   *   }
   * })
   * ```
   */
  error;
  #status;
  #executionCtx;
  #res;
  #layout;
  #renderer;
  #notFoundHandler;
  #preparedHeaders;
  #matchResult;
  #path;
  /**
   * Creates an instance of the Context class.
   *
   * @param req - The Request object.
   * @param options - Optional configuration options for the context.
   */
  constructor(req, options) {
    this.#rawRequest = req;
    if (options) {
      this.#executionCtx = options.executionCtx;
      this.env = options.env;
      this.#notFoundHandler = options.notFoundHandler;
      this.#path = options.path;
      this.#matchResult = options.matchResult;
    }
  }
  /**
   * `.req` is the instance of {@link HonoRequest}.
   */
  get req() {
    this.#req ??= new HonoRequest(this.#rawRequest, this.#path, this.#matchResult);
    return this.#req;
  }
  /**
   * @see {@link https://hono.dev/docs/api/context#event}
   * The FetchEvent associated with the current request.
   *
   * @throws Will throw an error if the context does not have a FetchEvent.
   */
  get event() {
    if (this.#executionCtx && "respondWith" in this.#executionCtx) {
      return this.#executionCtx;
    } else {
      throw Error("This context has no FetchEvent");
    }
  }
  /**
   * @see {@link https://hono.dev/docs/api/context#executionctx}
   * The ExecutionContext associated with the current request.
   *
   * @throws Will throw an error if the context does not have an ExecutionContext.
   */
  get executionCtx() {
    if (this.#executionCtx) {
      return this.#executionCtx;
    } else {
      throw Error("This context has no ExecutionContext");
    }
  }
  /**
   * @see {@link https://hono.dev/docs/api/context#res}
   * The Response object for the current request.
   */
  get res() {
    return this.#res ||= createResponseInstance(null, {
      headers: this.#preparedHeaders ??= new Headers()
    });
  }
  /**
   * Sets the Response object for the current request.
   *
   * @param _res - The Response object to set.
   */
  set res(_res) {
    if (this.#res && _res) {
      _res = createResponseInstance(_res.body, _res);
      for (const [k, v] of this.#res.headers.entries()) {
        if (k === "content-type") {
          continue;
        }
        if (k === "set-cookie") {
          const cookies = this.#res.headers.getSetCookie();
          _res.headers.delete("set-cookie");
          for (const cookie of cookies) {
            _res.headers.append("set-cookie", cookie);
          }
        } else {
          _res.headers.set(k, v);
        }
      }
    }
    this.#res = _res;
    this.finalized = true;
  }
  /**
   * `.render()` can create a response within a layout.
   *
   * @see {@link https://hono.dev/docs/api/context#render-setrenderer}
   *
   * @example
   * ```ts
   * app.get('/', (c) => {
   *   return c.render('Hello!')
   * })
   * ```
   */
  render = (...args) => {
    this.#renderer ??= (content) => this.html(content);
    return this.#renderer(...args);
  };
  /**
   * Sets the layout for the response.
   *
   * @param layout - The layout to set.
   * @returns The layout function.
   */
  setLayout = (layout) => this.#layout = layout;
  /**
   * Gets the current layout for the response.
   *
   * @returns The current layout function.
   */
  getLayout = () => this.#layout;
  /**
   * `.setRenderer()` can set the layout in the custom middleware.
   *
   * @see {@link https://hono.dev/docs/api/context#render-setrenderer}
   *
   * @example
   * ```tsx
   * app.use('*', async (c, next) => {
   *   c.setRenderer((content) => {
   *     return c.html(
   *       <html>
   *         <body>
   *           <p>{content}</p>
   *         </body>
   *       </html>
   *     )
   *   })
   *   await next()
   * })
   * ```
   */
  setRenderer = (renderer) => {
    this.#renderer = renderer;
  };
  /**
   * `.header()` can set headers.
   *
   * @see {@link https://hono.dev/docs/api/context#header}
   *
   * @example
   * ```ts
   * app.get('/welcome', (c) => {
   *   // Set headers
   *   c.header('X-Message', 'Hello!')
   *   c.header('Content-Type', 'text/plain')
   *
   *   return c.body('Thank you for coming')
   * })
   * ```
   */
  header = (name, value, options) => {
    if (this.finalized) {
      this.#res = createResponseInstance(this.#res.body, this.#res);
    }
    const headers = this.#res ? this.#res.headers : this.#preparedHeaders ??= new Headers();
    if (value === void 0) {
      headers.delete(name);
    } else if (options?.append) {
      headers.append(name, value);
    } else {
      headers.set(name, value);
    }
  };
  status = (status) => {
    this.#status = status;
  };
  /**
   * `.set()` can set the value specified by the key.
   *
   * @see {@link https://hono.dev/docs/api/context#set-get}
   *
   * @example
   * ```ts
   * app.use('*', async (c, next) => {
   *   c.set('message', 'Hono is hot!!')
   *   await next()
   * })
   * ```
   */
  set = (key, value) => {
    this.#var ??= /* @__PURE__ */ new Map();
    this.#var.set(key, value);
  };
  /**
   * `.get()` can use the value specified by the key.
   *
   * @see {@link https://hono.dev/docs/api/context#set-get}
   *
   * @example
   * ```ts
   * app.get('/', (c) => {
   *   const message = c.get('message')
   *   return c.text(`The message is "${message}"`)
   * })
   * ```
   */
  get = (key) => {
    return this.#var ? this.#var.get(key) : void 0;
  };
  /**
   * `.var` can access the value of a variable.
   *
   * @see {@link https://hono.dev/docs/api/context#var}
   *
   * @example
   * ```ts
   * const result = c.var.client.oneMethod()
   * ```
   */
  // c.var.propName is a read-only
  get var() {
    if (!this.#var) {
      return {};
    }
    return Object.fromEntries(this.#var);
  }
  #newResponse(data, arg, headers) {
    const responseHeaders = this.#res ? new Headers(this.#res.headers) : this.#preparedHeaders ?? new Headers();
    if (typeof arg === "object" && "headers" in arg) {
      const argHeaders = arg.headers instanceof Headers ? arg.headers : new Headers(arg.headers);
      for (const [key, value] of argHeaders) {
        if (key.toLowerCase() === "set-cookie") {
          responseHeaders.append(key, value);
        } else {
          responseHeaders.set(key, value);
        }
      }
    }
    if (headers) {
      for (const [k, v] of Object.entries(headers)) {
        if (typeof v === "string") {
          responseHeaders.set(k, v);
        } else {
          responseHeaders.delete(k);
          for (const v2 of v) {
            responseHeaders.append(k, v2);
          }
        }
      }
    }
    const status = typeof arg === "number" ? arg : arg?.status ?? this.#status;
    return createResponseInstance(data, { status, headers: responseHeaders });
  }
  newResponse = (...args) => this.#newResponse(...args);
  /**
   * `.body()` can return the HTTP response.
   * You can set headers with `.header()` and set HTTP status code with `.status`.
   * This can also be set in `.text()`, `.json()` and so on.
   *
   * @see {@link https://hono.dev/docs/api/context#body}
   *
   * @example
   * ```ts
   * app.get('/welcome', (c) => {
   *   // Set headers
   *   c.header('X-Message', 'Hello!')
   *   c.header('Content-Type', 'text/plain')
   *   // Set HTTP status code
   *   c.status(201)
   *
   *   // Return the response body
   *   return c.body('Thank you for coming')
   * })
   * ```
   */
  body = (data, arg, headers) => this.#newResponse(data, arg, headers);
  #useFastPath() {
    return !this.#preparedHeaders && !this.#status && !this.finalized;
  }
  /**
   * `.text()` can render text as `Content-Type:text/plain`.
   *
   * @see {@link https://hono.dev/docs/api/context#text}
   *
   * @example
   * ```ts
   * app.get('/say', (c) => {
   *   return c.text('Hello!')
   * })
   * ```
   */
  text = (text, arg, headers) => {
    return this.#useFastPath() && !arg && !headers ? createResponseInstance(text) : this.#newResponse(
      text,
      arg,
      setDefaultContentType(TEXT_PLAIN, headers)
    );
  };
  /**
   * `.json()` can render JSON as `Content-Type:application/json`.
   *
   * @see {@link https://hono.dev/docs/api/context#json}
   *
   * @example
   * ```ts
   * app.get('/api', (c) => {
   *   return c.json({ message: 'Hello!' })
   * })
   * ```
   */
  json = (object, arg, headers) => {
    return this.#useFastPath() && !arg && !headers ? Response.json(object) : this.#newResponse(
      JSON.stringify(object),
      arg,
      setDefaultContentType("application/json", headers)
    );
  };
  html = (html, arg, headers) => {
    const res = (html2) => this.#newResponse(html2, arg, setDefaultContentType("text/html; charset=UTF-8", headers));
    return typeof html === "object" ? resolveCallback(html, HtmlEscapedCallbackPhase.Stringify, false, {}).then(res) : res(html);
  };
  /**
   * `.redirect()` can Redirect, default status code is 302.
   *
   * @see {@link https://hono.dev/docs/api/context#redirect}
   *
   * @example
   * ```ts
   * app.get('/redirect', (c) => {
   *   return c.redirect('/')
   * })
   * app.get('/redirect-permanently', (c) => {
   *   return c.redirect('/', 301)
   * })
   * ```
   */
  redirect = (location, status) => {
    const locationString = String(location);
    this.header(
      "Location",
      // Multibyes should be encoded
      // eslint-disable-next-line no-control-regex
      !/[^\x00-\xFF]/.test(locationString) ? locationString : encodeURI(locationString)
    );
    return this.newResponse(null, status ?? 302);
  };
  /**
   * `.notFound()` can return the Not Found Response.
   *
   * @see {@link https://hono.dev/docs/api/context#notfound}
   *
   * @example
   * ```ts
   * app.get('/notfound', (c) => {
   *   return c.notFound()
   * })
   * ```
   */
  notFound = () => {
    this.#notFoundHandler ??= () => createResponseInstance();
    return this.#notFoundHandler(this);
  };
};

// .stack/node_modules/hono/dist/router.js
var METHOD_NAME_ALL = "ALL";
var METHOD_NAME_ALL_LOWERCASE = "all";
var METHODS = ["get", "post", "put", "delete", "options", "patch"];
var MESSAGE_MATCHER_IS_ALREADY_BUILT = "Can not add a route since the matcher is already built.";
var UnsupportedPathError = class extends Error {
};

// .stack/node_modules/hono/dist/utils/constants.js
var COMPOSED_HANDLER = "__COMPOSED_HANDLER";

// .stack/node_modules/hono/dist/hono-base.js
var notFoundHandler = (c) => {
  return c.text("404 Not Found", 404);
};
var errorHandler = (err, c) => {
  if ("getResponse" in err) {
    const res = err.getResponse();
    return c.newResponse(res.body, res);
  }
  console.error(err);
  return c.text("Internal Server Error", 500);
};
var Hono = class _Hono {
  get;
  post;
  put;
  delete;
  options;
  patch;
  all;
  on;
  use;
  /*
    This class is like an abstract class and does not have a router.
    To use it, inherit the class and implement router in the constructor.
  */
  router;
  getPath;
  // Cannot use `#` because it requires visibility at JavaScript runtime.
  _basePath = "/";
  #path = "/";
  routes = [];
  constructor(options = {}) {
    const allMethods = [...METHODS, METHOD_NAME_ALL_LOWERCASE];
    allMethods.forEach((method) => {
      this[method] = (args1, ...args) => {
        if (typeof args1 === "string") {
          this.#path = args1;
        } else {
          this.#addRoute(method, this.#path, args1);
        }
        args.forEach((handler) => {
          this.#addRoute(method, this.#path, handler);
        });
        return this;
      };
    });
    this.on = (method, path, ...handlers) => {
      for (const p of [path].flat()) {
        this.#path = p;
        for (const m of [method].flat()) {
          handlers.map((handler) => {
            this.#addRoute(m.toUpperCase(), this.#path, handler);
          });
        }
      }
      return this;
    };
    this.use = (arg1, ...handlers) => {
      if (typeof arg1 === "string") {
        this.#path = arg1;
      } else {
        this.#path = "*";
        handlers.unshift(arg1);
      }
      handlers.forEach((handler) => {
        this.#addRoute(METHOD_NAME_ALL, this.#path, handler);
      });
      return this;
    };
    const { strict, ...optionsWithoutStrict } = options;
    Object.assign(this, optionsWithoutStrict);
    this.getPath = strict ?? true ? options.getPath ?? getPath : getPathNoStrict;
  }
  #clone() {
    const clone = new _Hono({
      router: this.router,
      getPath: this.getPath
    });
    clone.errorHandler = this.errorHandler;
    clone.#notFoundHandler = this.#notFoundHandler;
    clone.routes = this.routes;
    return clone;
  }
  #notFoundHandler = notFoundHandler;
  // Cannot use `#` because it requires visibility at JavaScript runtime.
  errorHandler = errorHandler;
  /**
   * `.route()` allows grouping other Hono instance in routes.
   *
   * @see {@link https://hono.dev/docs/api/routing#grouping}
   *
   * @param {string} path - base Path
   * @param {Hono} app - other Hono instance
   * @returns {Hono} routed Hono instance
   *
   * @example
   * ```ts
   * const app = new Hono()
   * const app2 = new Hono()
   *
   * app2.get("/user", (c) => c.text("user"))
   * app.route("/api", app2) // GET /api/user
   * ```
   */
  route(path, app) {
    const subApp = this.basePath(path);
    app.routes.map((r) => {
      let handler;
      if (app.errorHandler === errorHandler) {
        handler = r.handler;
      } else {
        handler = async (c, next) => (await compose([], app.errorHandler)(c, () => r.handler(c, next))).res;
        handler[COMPOSED_HANDLER] = r.handler;
      }
      subApp.#addRoute(r.method, r.path, handler);
    });
    return this;
  }
  /**
   * `.basePath()` allows base paths to be specified.
   *
   * @see {@link https://hono.dev/docs/api/routing#base-path}
   *
   * @param {string} path - base Path
   * @returns {Hono} changed Hono instance
   *
   * @example
   * ```ts
   * const api = new Hono().basePath('/api')
   * ```
   */
  basePath(path) {
    const subApp = this.#clone();
    subApp._basePath = mergePath(this._basePath, path);
    return subApp;
  }
  /**
   * `.onError()` handles an error and returns a customized Response.
   *
   * @see {@link https://hono.dev/docs/api/hono#error-handling}
   *
   * @param {ErrorHandler} handler - request Handler for error
   * @returns {Hono} changed Hono instance
   *
   * @example
   * ```ts
   * app.onError((err, c) => {
   *   console.error(`${err}`)
   *   return c.text('Custom Error Message', 500)
   * })
   * ```
   */
  onError = (handler) => {
    this.errorHandler = handler;
    return this;
  };
  /**
   * `.notFound()` allows you to customize a Not Found Response.
   *
   * @see {@link https://hono.dev/docs/api/hono#not-found}
   *
   * @param {NotFoundHandler} handler - request handler for not-found
   * @returns {Hono} changed Hono instance
   *
   * @example
   * ```ts
   * app.notFound((c) => {
   *   return c.text('Custom 404 Message', 404)
   * })
   * ```
   */
  notFound = (handler) => {
    this.#notFoundHandler = handler;
    return this;
  };
  /**
   * `.mount()` allows you to mount applications built with other frameworks into your Hono application.
   *
   * @see {@link https://hono.dev/docs/api/hono#mount}
   *
   * @param {string} path - base Path
   * @param {Function} applicationHandler - other Request Handler
   * @param {MountOptions} [options] - options of `.mount()`
   * @returns {Hono} mounted Hono instance
   *
   * @example
   * ```ts
   * import { Router as IttyRouter } from 'itty-router'
   * import { Hono } from 'hono'
   * // Create itty-router application
   * const ittyRouter = IttyRouter()
   * // GET /itty-router/hello
   * ittyRouter.get('/hello', () => new Response('Hello from itty-router'))
   *
   * const app = new Hono()
   * app.mount('/itty-router', ittyRouter.handle)
   * ```
   *
   * @example
   * ```ts
   * const app = new Hono()
   * // Send the request to another application without modification.
   * app.mount('/app', anotherApp, {
   *   replaceRequest: (req) => req,
   * })
   * ```
   */
  mount(path, applicationHandler, options) {
    let replaceRequest;
    let optionHandler;
    if (options) {
      if (typeof options === "function") {
        optionHandler = options;
      } else {
        optionHandler = options.optionHandler;
        if (options.replaceRequest === false) {
          replaceRequest = (request) => request;
        } else {
          replaceRequest = options.replaceRequest;
        }
      }
    }
    const getOptions = optionHandler ? (c) => {
      const options2 = optionHandler(c);
      return Array.isArray(options2) ? options2 : [options2];
    } : (c) => {
      let executionContext = void 0;
      try {
        executionContext = c.executionCtx;
      } catch {
      }
      return [c.env, executionContext];
    };
    replaceRequest ||= (() => {
      const mergedPath = mergePath(this._basePath, path);
      const pathPrefixLength = mergedPath === "/" ? 0 : mergedPath.length;
      return (request) => {
        const url = new URL(request.url);
        url.pathname = url.pathname.slice(pathPrefixLength) || "/";
        return new Request(url, request);
      };
    })();
    const handler = async (c, next) => {
      const res = await applicationHandler(replaceRequest(c.req.raw), ...getOptions(c));
      if (res) {
        return res;
      }
      await next();
    };
    this.#addRoute(METHOD_NAME_ALL, mergePath(path, "*"), handler);
    return this;
  }
  #addRoute(method, path, handler) {
    method = method.toUpperCase();
    path = mergePath(this._basePath, path);
    const r = { basePath: this._basePath, path, method, handler };
    this.router.add(method, path, [handler, r]);
    this.routes.push(r);
  }
  #handleError(err, c) {
    if (err instanceof Error) {
      return this.errorHandler(err, c);
    }
    throw err;
  }
  #dispatch(request, executionCtx, env, method) {
    if (method === "HEAD") {
      return (async () => new Response(null, await this.#dispatch(request, executionCtx, env, "GET")))();
    }
    const path = this.getPath(request, { env });
    const matchResult = this.router.match(method, path);
    const c = new Context(request, {
      path,
      matchResult,
      env,
      executionCtx,
      notFoundHandler: this.#notFoundHandler
    });
    if (matchResult[0].length === 1) {
      let res;
      try {
        res = matchResult[0][0][0][0](c, async () => {
          c.res = await this.#notFoundHandler(c);
        });
      } catch (err) {
        return this.#handleError(err, c);
      }
      return res instanceof Promise ? res.then(
        (resolved) => resolved || (c.finalized ? c.res : this.#notFoundHandler(c))
      ).catch((err) => this.#handleError(err, c)) : res ?? this.#notFoundHandler(c);
    }
    const composed = compose(matchResult[0], this.errorHandler, this.#notFoundHandler);
    return (async () => {
      try {
        const context = await composed(c);
        if (!context.finalized) {
          throw new Error(
            "Context is not finalized. Did you forget to return a Response object or `await next()`?"
          );
        }
        return context.res;
      } catch (err) {
        return this.#handleError(err, c);
      }
    })();
  }
  /**
   * `.fetch()` will be entry point of your app.
   *
   * @see {@link https://hono.dev/docs/api/hono#fetch}
   *
   * @param {Request} request - request Object of request
   * @param {Env} Env - env Object
   * @param {ExecutionContext} - context of execution
   * @returns {Response | Promise<Response>} response of request
   *
   */
  fetch = (request, ...rest) => {
    return this.#dispatch(request, rest[1], rest[0], request.method);
  };
  /**
   * `.request()` is a useful method for testing.
   * You can pass a URL or pathname to send a GET request.
   * app will return a Response object.
   * ```ts
   * test('GET /hello is ok', async () => {
   *   const res = await app.request('/hello')
   *   expect(res.status).toBe(200)
   * })
   * ```
   * @see https://hono.dev/docs/api/hono#request
   */
  request = (input, requestInit, Env, executionCtx) => {
    if (input instanceof Request) {
      return this.fetch(requestInit ? new Request(input, requestInit) : input, Env, executionCtx);
    }
    input = input.toString();
    return this.fetch(
      new Request(
        /^https?:\/\//.test(input) ? input : `http://localhost${mergePath("/", input)}`,
        requestInit
      ),
      Env,
      executionCtx
    );
  };
  /**
   * `.fire()` automatically adds a global fetch event listener.
   * This can be useful for environments that adhere to the Service Worker API, such as non-ES module Cloudflare Workers.
   * @deprecated
   * Use `fire` from `hono/service-worker` instead.
   * ```ts
   * import { Hono } from 'hono'
   * import { fire } from 'hono/service-worker'
   *
   * const app = new Hono()
   * // ...
   * fire(app)
   * ```
   * @see https://hono.dev/docs/api/hono#fire
   * @see https://developer.mozilla.org/en-US/docs/Web/API/Service_Worker_API
   * @see https://developers.cloudflare.com/workers/reference/migrate-to-module-workers/
   */
  fire = () => {
    addEventListener("fetch", (event) => {
      event.respondWith(this.#dispatch(event.request, event, void 0, event.request.method));
    });
  };
};

// .stack/node_modules/hono/dist/router/reg-exp-router/matcher.js
var emptyParam = [];
function match(method, path) {
  const matchers = this.buildAllMatchers();
  const match2 = ((method2, path2) => {
    const matcher = matchers[method2] || matchers[METHOD_NAME_ALL];
    const staticMatch = matcher[2][path2];
    if (staticMatch) {
      return staticMatch;
    }
    const match3 = path2.match(matcher[0]);
    if (!match3) {
      return [[], emptyParam];
    }
    const index = match3.indexOf("", 1);
    return [matcher[1][index], match3];
  });
  this.match = match2;
  return match2(method, path);
}

// .stack/node_modules/hono/dist/router/reg-exp-router/node.js
var LABEL_REG_EXP_STR = "[^/]+";
var ONLY_WILDCARD_REG_EXP_STR = ".*";
var TAIL_WILDCARD_REG_EXP_STR = "(?:|/.*)";
var PATH_ERROR = /* @__PURE__ */ Symbol();
var regExpMetaChars = new Set(".\\+*[^]$()");
function compareKey(a, b) {
  if (a.length === 1) {
    return b.length === 1 ? a < b ? -1 : 1 : -1;
  }
  if (b.length === 1) {
    return 1;
  }
  if (a === ONLY_WILDCARD_REG_EXP_STR || a === TAIL_WILDCARD_REG_EXP_STR) {
    return 1;
  } else if (b === ONLY_WILDCARD_REG_EXP_STR || b === TAIL_WILDCARD_REG_EXP_STR) {
    return -1;
  }
  if (a === LABEL_REG_EXP_STR) {
    return 1;
  } else if (b === LABEL_REG_EXP_STR) {
    return -1;
  }
  return a.length === b.length ? a < b ? -1 : 1 : b.length - a.length;
}
var Node = class _Node {
  #index;
  #varIndex;
  #children = /* @__PURE__ */ Object.create(null);
  insert(tokens, index, paramMap, context, pathErrorCheckOnly) {
    if (tokens.length === 0) {
      if (this.#index !== void 0) {
        throw PATH_ERROR;
      }
      if (pathErrorCheckOnly) {
        return;
      }
      this.#index = index;
      return;
    }
    const [token, ...restTokens] = tokens;
    const pattern = token === "*" ? restTokens.length === 0 ? ["", "", ONLY_WILDCARD_REG_EXP_STR] : ["", "", LABEL_REG_EXP_STR] : token === "/*" ? ["", "", TAIL_WILDCARD_REG_EXP_STR] : token.match(/^\:([^\{\}]+)(?:\{(.+)\})?$/);
    let node;
    if (pattern) {
      const name = pattern[1];
      let regexpStr = pattern[2] || LABEL_REG_EXP_STR;
      if (name && pattern[2]) {
        if (regexpStr === ".*") {
          throw PATH_ERROR;
        }
        regexpStr = regexpStr.replace(/^\((?!\?:)(?=[^)]+\)$)/, "(?:");
        if (/\((?!\?:)/.test(regexpStr)) {
          throw PATH_ERROR;
        }
      }
      node = this.#children[regexpStr];
      if (!node) {
        if (Object.keys(this.#children).some(
          (k) => k !== ONLY_WILDCARD_REG_EXP_STR && k !== TAIL_WILDCARD_REG_EXP_STR
        )) {
          throw PATH_ERROR;
        }
        if (pathErrorCheckOnly) {
          return;
        }
        node = this.#children[regexpStr] = new _Node();
        if (name !== "") {
          node.#varIndex = context.varIndex++;
        }
      }
      if (!pathErrorCheckOnly && name !== "") {
        paramMap.push([name, node.#varIndex]);
      }
    } else {
      node = this.#children[token];
      if (!node) {
        if (Object.keys(this.#children).some(
          (k) => k.length > 1 && k !== ONLY_WILDCARD_REG_EXP_STR && k !== TAIL_WILDCARD_REG_EXP_STR
        )) {
          throw PATH_ERROR;
        }
        if (pathErrorCheckOnly) {
          return;
        }
        node = this.#children[token] = new _Node();
      }
    }
    node.insert(restTokens, index, paramMap, context, pathErrorCheckOnly);
  }
  buildRegExpStr() {
    const childKeys = Object.keys(this.#children).sort(compareKey);
    const strList = childKeys.map((k) => {
      const c = this.#children[k];
      return (typeof c.#varIndex === "number" ? `(${k})@${c.#varIndex}` : regExpMetaChars.has(k) ? `\\${k}` : k) + c.buildRegExpStr();
    });
    if (typeof this.#index === "number") {
      strList.unshift(`#${this.#index}`);
    }
    if (strList.length === 0) {
      return "";
    }
    if (strList.length === 1) {
      return strList[0];
    }
    return "(?:" + strList.join("|") + ")";
  }
};

// .stack/node_modules/hono/dist/router/reg-exp-router/trie.js
var Trie = class {
  #context = { varIndex: 0 };
  #root = new Node();
  insert(path, index, pathErrorCheckOnly) {
    const paramAssoc = [];
    const groups = [];
    for (let i = 0; ; ) {
      let replaced = false;
      path = path.replace(/\{[^}]+\}/g, (m) => {
        const mark = `@\\${i}`;
        groups[i] = [mark, m];
        i++;
        replaced = true;
        return mark;
      });
      if (!replaced) {
        break;
      }
    }
    const tokens = path.match(/(?::[^\/]+)|(?:\/\*$)|./g) || [];
    for (let i = groups.length - 1; i >= 0; i--) {
      const [mark] = groups[i];
      for (let j = tokens.length - 1; j >= 0; j--) {
        if (tokens[j].indexOf(mark) !== -1) {
          tokens[j] = tokens[j].replace(mark, groups[i][1]);
          break;
        }
      }
    }
    this.#root.insert(tokens, index, paramAssoc, this.#context, pathErrorCheckOnly);
    return paramAssoc;
  }
  buildRegExp() {
    let regexp = this.#root.buildRegExpStr();
    if (regexp === "") {
      return [/^$/, [], []];
    }
    let captureIndex = 0;
    const indexReplacementMap = [];
    const paramReplacementMap = [];
    regexp = regexp.replace(/#(\d+)|@(\d+)|\.\*\$/g, (_, handlerIndex, paramIndex) => {
      if (handlerIndex !== void 0) {
        indexReplacementMap[++captureIndex] = Number(handlerIndex);
        return "$()";
      }
      if (paramIndex !== void 0) {
        paramReplacementMap[Number(paramIndex)] = ++captureIndex;
        return "";
      }
      return "";
    });
    return [new RegExp(`^${regexp}`), indexReplacementMap, paramReplacementMap];
  }
};

// .stack/node_modules/hono/dist/router/reg-exp-router/router.js
var nullMatcher = [/^$/, [], /* @__PURE__ */ Object.create(null)];
var wildcardRegExpCache = /* @__PURE__ */ Object.create(null);
function buildWildcardRegExp(path) {
  return wildcardRegExpCache[path] ??= new RegExp(
    path === "*" ? "" : `^${path.replace(
      /\/\*$|([.\\+*[^\]$()])/g,
      (_, metaChar) => metaChar ? `\\${metaChar}` : "(?:|/.*)"
    )}$`
  );
}
function clearWildcardRegExpCache() {
  wildcardRegExpCache = /* @__PURE__ */ Object.create(null);
}
function buildMatcherFromPreprocessedRoutes(routes) {
  const trie = new Trie();
  const handlerData = [];
  if (routes.length === 0) {
    return nullMatcher;
  }
  const routesWithStaticPathFlag = routes.map(
    (route) => [!/\*|\/:/.test(route[0]), ...route]
  ).sort(
    ([isStaticA, pathA], [isStaticB, pathB]) => isStaticA ? 1 : isStaticB ? -1 : pathA.length - pathB.length
  );
  const staticMap = /* @__PURE__ */ Object.create(null);
  for (let i = 0, j = -1, len = routesWithStaticPathFlag.length; i < len; i++) {
    const [pathErrorCheckOnly, path, handlers] = routesWithStaticPathFlag[i];
    if (pathErrorCheckOnly) {
      staticMap[path] = [handlers.map(([h]) => [h, /* @__PURE__ */ Object.create(null)]), emptyParam];
    } else {
      j++;
    }
    let paramAssoc;
    try {
      paramAssoc = trie.insert(path, j, pathErrorCheckOnly);
    } catch (e) {
      throw e === PATH_ERROR ? new UnsupportedPathError(path) : e;
    }
    if (pathErrorCheckOnly) {
      continue;
    }
    handlerData[j] = handlers.map(([h, paramCount]) => {
      const paramIndexMap = /* @__PURE__ */ Object.create(null);
      paramCount -= 1;
      for (; paramCount >= 0; paramCount--) {
        const [key, value] = paramAssoc[paramCount];
        paramIndexMap[key] = value;
      }
      return [h, paramIndexMap];
    });
  }
  const [regexp, indexReplacementMap, paramReplacementMap] = trie.buildRegExp();
  for (let i = 0, len = handlerData.length; i < len; i++) {
    for (let j = 0, len2 = handlerData[i].length; j < len2; j++) {
      const map = handlerData[i][j]?.[1];
      if (!map) {
        continue;
      }
      const keys = Object.keys(map);
      for (let k = 0, len3 = keys.length; k < len3; k++) {
        map[keys[k]] = paramReplacementMap[map[keys[k]]];
      }
    }
  }
  const handlerMap = [];
  for (const i in indexReplacementMap) {
    handlerMap[i] = handlerData[indexReplacementMap[i]];
  }
  return [regexp, handlerMap, staticMap];
}
function findMiddleware(middleware, path) {
  if (!middleware) {
    return void 0;
  }
  for (const k of Object.keys(middleware).sort((a, b) => b.length - a.length)) {
    if (buildWildcardRegExp(k).test(path)) {
      return [...middleware[k]];
    }
  }
  return void 0;
}
var RegExpRouter = class {
  name = "RegExpRouter";
  #middleware;
  #routes;
  constructor() {
    this.#middleware = { [METHOD_NAME_ALL]: /* @__PURE__ */ Object.create(null) };
    this.#routes = { [METHOD_NAME_ALL]: /* @__PURE__ */ Object.create(null) };
  }
  add(method, path, handler) {
    const middleware = this.#middleware;
    const routes = this.#routes;
    if (!middleware || !routes) {
      throw new Error(MESSAGE_MATCHER_IS_ALREADY_BUILT);
    }
    if (!middleware[method]) {
      ;
      [middleware, routes].forEach((handlerMap) => {
        handlerMap[method] = /* @__PURE__ */ Object.create(null);
        Object.keys(handlerMap[METHOD_NAME_ALL]).forEach((p) => {
          handlerMap[method][p] = [...handlerMap[METHOD_NAME_ALL][p]];
        });
      });
    }
    if (path === "/*") {
      path = "*";
    }
    const paramCount = (path.match(/\/:/g) || []).length;
    if (/\*$/.test(path)) {
      const re = buildWildcardRegExp(path);
      if (method === METHOD_NAME_ALL) {
        Object.keys(middleware).forEach((m) => {
          middleware[m][path] ||= findMiddleware(middleware[m], path) || findMiddleware(middleware[METHOD_NAME_ALL], path) || [];
        });
      } else {
        middleware[method][path] ||= findMiddleware(middleware[method], path) || findMiddleware(middleware[METHOD_NAME_ALL], path) || [];
      }
      Object.keys(middleware).forEach((m) => {
        if (method === METHOD_NAME_ALL || method === m) {
          Object.keys(middleware[m]).forEach((p) => {
            re.test(p) && middleware[m][p].push([handler, paramCount]);
          });
        }
      });
      Object.keys(routes).forEach((m) => {
        if (method === METHOD_NAME_ALL || method === m) {
          Object.keys(routes[m]).forEach(
            (p) => re.test(p) && routes[m][p].push([handler, paramCount])
          );
        }
      });
      return;
    }
    const paths = checkOptionalParameter(path) || [path];
    for (let i = 0, len = paths.length; i < len; i++) {
      const path2 = paths[i];
      Object.keys(routes).forEach((m) => {
        if (method === METHOD_NAME_ALL || method === m) {
          routes[m][path2] ||= [
            ...findMiddleware(middleware[m], path2) || findMiddleware(middleware[METHOD_NAME_ALL], path2) || []
          ];
          routes[m][path2].push([handler, paramCount - len + i + 1]);
        }
      });
    }
  }
  match = match;
  buildAllMatchers() {
    const matchers = /* @__PURE__ */ Object.create(null);
    Object.keys(this.#routes).concat(Object.keys(this.#middleware)).forEach((method) => {
      matchers[method] ||= this.#buildMatcher(method);
    });
    this.#middleware = this.#routes = void 0;
    clearWildcardRegExpCache();
    return matchers;
  }
  #buildMatcher(method) {
    const routes = [];
    let hasOwnRoute = method === METHOD_NAME_ALL;
    [this.#middleware, this.#routes].forEach((r) => {
      const ownRoute = r[method] ? Object.keys(r[method]).map((path) => [path, r[method][path]]) : [];
      if (ownRoute.length !== 0) {
        hasOwnRoute ||= true;
        routes.push(...ownRoute);
      } else if (method !== METHOD_NAME_ALL) {
        routes.push(
          ...Object.keys(r[METHOD_NAME_ALL]).map((path) => [path, r[METHOD_NAME_ALL][path]])
        );
      }
    });
    if (!hasOwnRoute) {
      return null;
    } else {
      return buildMatcherFromPreprocessedRoutes(routes);
    }
  }
};

// .stack/node_modules/hono/dist/router/smart-router/router.js
var SmartRouter = class {
  name = "SmartRouter";
  #routers = [];
  #routes = [];
  constructor(init) {
    this.#routers = init.routers;
  }
  add(method, path, handler) {
    if (!this.#routes) {
      throw new Error(MESSAGE_MATCHER_IS_ALREADY_BUILT);
    }
    this.#routes.push([method, path, handler]);
  }
  match(method, path) {
    if (!this.#routes) {
      throw new Error("Fatal error");
    }
    const routers = this.#routers;
    const routes = this.#routes;
    const len = routers.length;
    let i = 0;
    let res;
    for (; i < len; i++) {
      const router = routers[i];
      try {
        for (let i2 = 0, len2 = routes.length; i2 < len2; i2++) {
          router.add(...routes[i2]);
        }
        res = router.match(method, path);
      } catch (e) {
        if (e instanceof UnsupportedPathError) {
          continue;
        }
        throw e;
      }
      this.match = router.match.bind(router);
      this.#routers = [router];
      this.#routes = void 0;
      break;
    }
    if (i === len) {
      throw new Error("Fatal error");
    }
    this.name = `SmartRouter + ${this.activeRouter.name}`;
    return res;
  }
  get activeRouter() {
    if (this.#routes || this.#routers.length !== 1) {
      throw new Error("No active router has been determined yet.");
    }
    return this.#routers[0];
  }
};

// .stack/node_modules/hono/dist/router/trie-router/node.js
var emptyParams = /* @__PURE__ */ Object.create(null);
var hasChildren = (children) => {
  for (const _ in children) {
    return true;
  }
  return false;
};
var Node2 = class _Node2 {
  #methods;
  #children;
  #patterns;
  #order = 0;
  #params = emptyParams;
  constructor(method, handler, children) {
    this.#children = children || /* @__PURE__ */ Object.create(null);
    this.#methods = [];
    if (method && handler) {
      const m = /* @__PURE__ */ Object.create(null);
      m[method] = { handler, possibleKeys: [], score: 0 };
      this.#methods = [m];
    }
    this.#patterns = [];
  }
  insert(method, path, handler) {
    this.#order = ++this.#order;
    let curNode = this;
    const parts = splitRoutingPath(path);
    const possibleKeys = [];
    for (let i = 0, len = parts.length; i < len; i++) {
      const p = parts[i];
      const nextP = parts[i + 1];
      const pattern = getPattern(p, nextP);
      const key = Array.isArray(pattern) ? pattern[0] : p;
      if (key in curNode.#children) {
        curNode = curNode.#children[key];
        if (pattern) {
          possibleKeys.push(pattern[1]);
        }
        continue;
      }
      curNode.#children[key] = new _Node2();
      if (pattern) {
        curNode.#patterns.push(pattern);
        possibleKeys.push(pattern[1]);
      }
      curNode = curNode.#children[key];
    }
    curNode.#methods.push({
      [method]: {
        handler,
        possibleKeys: possibleKeys.filter((v, i, a) => a.indexOf(v) === i),
        score: this.#order
      }
    });
    return curNode;
  }
  #pushHandlerSets(handlerSets, node, method, nodeParams, params) {
    for (let i = 0, len = node.#methods.length; i < len; i++) {
      const m = node.#methods[i];
      const handlerSet = m[method] || m[METHOD_NAME_ALL];
      const processedSet = {};
      if (handlerSet !== void 0) {
        handlerSet.params = /* @__PURE__ */ Object.create(null);
        handlerSets.push(handlerSet);
        if (nodeParams !== emptyParams || params && params !== emptyParams) {
          for (let i2 = 0, len2 = handlerSet.possibleKeys.length; i2 < len2; i2++) {
            const key = handlerSet.possibleKeys[i2];
            const processed = processedSet[handlerSet.score];
            handlerSet.params[key] = params?.[key] && !processed ? params[key] : nodeParams[key] ?? params?.[key];
            processedSet[handlerSet.score] = true;
          }
        }
      }
    }
  }
  search(method, path) {
    const handlerSets = [];
    this.#params = emptyParams;
    const curNode = this;
    let curNodes = [curNode];
    const parts = splitPath(path);
    const curNodesQueue = [];
    const len = parts.length;
    let partOffsets = null;
    for (let i = 0; i < len; i++) {
      const part = parts[i];
      const isLast = i === len - 1;
      const tempNodes = [];
      for (let j = 0, len2 = curNodes.length; j < len2; j++) {
        const node = curNodes[j];
        const nextNode = node.#children[part];
        if (nextNode) {
          nextNode.#params = node.#params;
          if (isLast) {
            if (nextNode.#children["*"]) {
              this.#pushHandlerSets(handlerSets, nextNode.#children["*"], method, node.#params);
            }
            this.#pushHandlerSets(handlerSets, nextNode, method, node.#params);
          } else {
            tempNodes.push(nextNode);
          }
        }
        for (let k = 0, len3 = node.#patterns.length; k < len3; k++) {
          const pattern = node.#patterns[k];
          const params = node.#params === emptyParams ? {} : { ...node.#params };
          if (pattern === "*") {
            const astNode = node.#children["*"];
            if (astNode) {
              this.#pushHandlerSets(handlerSets, astNode, method, node.#params);
              astNode.#params = params;
              tempNodes.push(astNode);
            }
            continue;
          }
          const [key, name, matcher] = pattern;
          if (!part && !(matcher instanceof RegExp)) {
            continue;
          }
          const child = node.#children[key];
          if (matcher instanceof RegExp) {
            if (partOffsets === null) {
              partOffsets = new Array(len);
              let offset = path[0] === "/" ? 1 : 0;
              for (let p = 0; p < len; p++) {
                partOffsets[p] = offset;
                offset += parts[p].length + 1;
              }
            }
            const restPathString = path.substring(partOffsets[i]);
            const m = matcher.exec(restPathString);
            if (m) {
              params[name] = m[0];
              this.#pushHandlerSets(handlerSets, child, method, node.#params, params);
              if (hasChildren(child.#children)) {
                child.#params = params;
                const componentCount = m[0].match(/\//)?.length ?? 0;
                const targetCurNodes = curNodesQueue[componentCount] ||= [];
                targetCurNodes.push(child);
              }
              continue;
            }
          }
          if (matcher === true || matcher.test(part)) {
            params[name] = part;
            if (isLast) {
              this.#pushHandlerSets(handlerSets, child, method, params, node.#params);
              if (child.#children["*"]) {
                this.#pushHandlerSets(
                  handlerSets,
                  child.#children["*"],
                  method,
                  params,
                  node.#params
                );
              }
            } else {
              child.#params = params;
              tempNodes.push(child);
            }
          }
        }
      }
      const shifted = curNodesQueue.shift();
      curNodes = shifted ? tempNodes.concat(shifted) : tempNodes;
    }
    if (handlerSets.length > 1) {
      handlerSets.sort((a, b) => {
        return a.score - b.score;
      });
    }
    return [handlerSets.map(({ handler, params }) => [handler, params])];
  }
};

// .stack/node_modules/hono/dist/router/trie-router/router.js
var TrieRouter = class {
  name = "TrieRouter";
  #node;
  constructor() {
    this.#node = new Node2();
  }
  add(method, path, handler) {
    const results = checkOptionalParameter(path);
    if (results) {
      for (let i = 0, len = results.length; i < len; i++) {
        this.#node.insert(method, results[i], handler);
      }
      return;
    }
    this.#node.insert(method, path, handler);
  }
  match(method, path) {
    return this.#node.search(method, path);
  }
};

// .stack/node_modules/hono/dist/hono.js
var Hono2 = class extends Hono {
  /**
   * Creates an instance of the Hono class.
   *
   * @param options - Optional configuration options for the Hono instance.
   */
  constructor(options = {}) {
    super(options);
    this.router = options.router ?? new SmartRouter({
      routers: [new RegExpRouter(), new TrieRouter()]
    });
  }
};

// server/command.mjs
var BY_STATUS = { 400: "BAD_INPUT", 403: "NOT_ALLOWED", 404: "NOT_FOUND", 424: "MISSING_KEYS", 502: "SITE_FAILED", 504: "SITE_TIMEOUT" };
var Refused = class extends Error {
  constructor(message, status = 409, extra = {}) {
    super(message);
    this.status = status;
    this.code = extra.code ?? (/^Only a person/.test(message) ? "PERSON_ONLY" : BY_STATUS[status] ?? "REFUSED");
    if (extra.item !== void 0) this.item = extra.item;
  }
};
var commandsOf = (app) => app.commands ??= [];
var inputNames = (input) => Array.isArray(input) ? input.flatMap((x) => typeof x === "string" ? [x] : Object.keys(x)) : Object.keys(input ?? {});
function command(app, method, path, spec, handler) {
  commandsOf(app).push({ ...spec, method, path, input: spec.input ?? {}, by: spec.by ?? "anyone", read: method === "GET" });
  app.on(method, path, async (c) => {
    const actor = c.req.header("x-actor") || "";
    if (spec.by === "person" && !actor.startsWith("person:")) throw new Refused(`Only a person can do this: ask them. (${spec.name})`, 403);
    const body = method === "GET" ? c.req.query() : await c.req.json().catch(() => ({}));
    const input = {};
    for (const k of inputNames(spec.input)) if (body[k] !== void 0) input[k] = body[k];
    for (const [k, v] of Object.entries(c.req.param())) input[k] = /^\d+$/.test(v) ? Number(v) : v;
    return c.json(await handler(input, { actor }) ?? { ok: true });
  });
}
function mountErrors(app) {
  app.onError((e, c) => c.json({ error: e.message, code: e.code ?? (e.status && e.status < 500 ? "REFUSED" : "FAILED"), ...e.item !== void 0 ? { item: e.item } : {} }, e.status ?? 500));
  app.get("/_commands", (c) => c.json(commandsOf(app)));
}

// shared/core.mjs
var import_invcore = __toESM(require_invcore(), 1);
var C = globalThis.InvCore;
var core_default = C;

// server/services/util.mjs
var T = {
  settings: "inv_settings",
  series: "inv_series",
  clients: "inv_clients",
  docs: "inv_documents",
  emails: "inv_emails",
  links: "inv_links",
  responses: "inv_responses",
  recurring: "inv_recurring"
};
var nowOf = (deps) => deps && deps.now ? deps.now() : /* @__PURE__ */ new Date();
var sqlTime = (d) => new Date(d).toISOString().slice(0, 19).replace("T", " ");
var clean = (v, max = 600) => String(v == null ? "" : v).replace(/\r\n/g, "\n").trim().slice(0, max);
var isPerson = (actor) => String(actor || "").startsWith("person:");
var whoOf = (actor) => String(actor || "").replace(/^(person|agent):/, "") || "platform";
var jsonOf = (text, fallback) => {
  if (text == null || text === "") return fallback;
  if (typeof text === "object") return text;
  try {
    return JSON.parse(text);
  } catch {
    return fallback;
  }
};
var DEFAULT_SETTINGS = {
  company_name: "",
  tax_id: "",
  address: "",
  country: "",
  email: "",
  phone: "",
  logo_url: "",
  bank_details: "",
  payment_note: "",
  currency: "EUR",
  tax_rate: 21,
  withholding_rate: 0,
  payment_days: 30,
  quote_valid_days: 30,
  invoice_prefix: "",
  quote_prefix: "Q-",
  number_digits: 4,
  language: "es",
  timezone: "Europe/Madrid",
  reminders_on: "yes",
  reminder_days: 7,
  public_url: ""
};
async function settingsOf(db) {
  const row = await db.one(`SELECT * FROM ${T.settings} WHERE _deleted = 0 ORDER BY _id LIMIT 1`);
  const s = { ...DEFAULT_SETTINGS };
  for (const [k, v] of Object.entries(row || {})) if (v !== null && v !== "") s[k] = v;
  s._id = row ? row._id : null;
  return s;
}
var todayOf = (s, deps) => core_default.today(s.timezone, nowOf(deps));
function idOf(v, field = "id") {
  const n = Number(v);
  if (!Number.isInteger(n) || n <= 0) throw new Refused(`${field} is the number of the row (a whole number above 0).`, 400, { code: "BAD_INPUT" });
  return n;
}
function dayOf(v, field = "day") {
  if (v == null || String(v).trim() === "") return null;
  const s = String(v).trim();
  const m = s.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
  const iso = m ? `${m[3]}-${m[2].padStart(2, "0")}-${m[1].padStart(2, "0")}` : s.slice(0, 10);
  const day = core_default.realDay(iso);
  if (!day) throw new Refused(`${field} is not a real day: write it as 2026-11-23.`, 400, { code: "BAD_DATE", item: field });
  return day;
}
function linesFrom(input, currency, s) {
  let list = input;
  if (typeof list === "string") list = jsonOf(list, null);
  if (!Array.isArray(list)) throw new Refused("lines is a list: [{ description, qty, price, tax, disc }], price in the currency (1000 = 1.000 \u20AC), tax and disc in %.", 400, { code: "BAD_LINES" });
  if (list.length > core_default.MAX_LINES) throw new Refused(`A document has at most ${core_default.MAX_LINES} lines.`, 400, { code: "BAD_LINES" });
  return list.map((raw2, i) => {
    const r = raw2 && typeof raw2 === "object" ? raw2 : {};
    const price = core_default.toMinor(r.price ?? r.unit_price ?? "", currency);
    if (price === null) throw new Refused(`Line ${i + 1}: price is not an amount (write 1000 or 1.000,50).`, 400, { code: "BAD_LINES", item: i });
    const qty = r.qty ?? r.quantity;
    return {
      description: clean(r.description, 600),
      qty: qty == null || qty === "" ? 1 : core_default.qtyOf(qty),
      price,
      tax: r.tax == null || r.tax === "" ? core_default.pct(r.tax_rate ?? s.tax_rate) : core_default.pct(r.tax),
      disc: core_default.pct(r.disc ?? r.discount ?? 0)
    };
  });
}
var linesOut = (lines, currency) => core_default.linesOf(lines).map((l) => ({ description: l.description, qty: l.qty, price: core_default.fromMinor(l.price, currency), tax: l.tax, disc: l.disc }));
var money = (minor, currency) => core_default.money(Number(minor) || 0, currency || "EUR", "es-ES");
var linkOf = (s, doc) => doc && doc.link_token && s.public_url ? `${String(s.public_url).replace(/#.*$/, "")}#/${doc.link_token}` : null;
var wantsAll = (actor, input) => isPerson(actor) || input.full === true || input.full === "true";

// server/services/links.mjs
import crypto2 from "node:crypto";
var sha = (s) => crypto2.createHash("sha256").update(s).digest("hex");
async function sealDoc(db, s, d) {
  if (!d || !d.link_token || ["Draft", "Discarded"].includes(d.status)) return false;
  const snap = core_default.snapshot(d, s);
  const hash = sha(`${d.link_token}
${JSON.stringify(snap)}`);
  const row = await db.one(`SELECT _id, hash FROM ${T.links} WHERE _deleted = 0 AND doc_id = ?`, [d._id]);
  if (row && row.hash === hash) return false;
  const data = { doc_id: d._id, k: await core_default.linkKey(d.link_token), box: await core_default.seal(d.link_token, snap), hash, built_at: sqlTime(/* @__PURE__ */ new Date()), doc_seen: d._updated_at || null };
  if (row) await db.update(T.links, row._id, data);
  else await db.insert(T.links, data);
  return true;
}
async function sealAll(db, s) {
  const docs = await db.all(`SELECT * FROM ${T.docs} WHERE _deleted = 0 AND status NOT IN ('Draft', 'Discarded') AND COALESCE(link_token, '') <> ''`);
  let n = 0;
  for (const d of docs) if (await sealDoc(db, s, d)) n += 1;
  return n;
}

// server/services/clients.mjs
var FIELDS = ["name", "tax_id", "email", "contact_name", "address", "country", "notes", "crm_company_id"];
var norm = (v) => clean(v, 160).toLowerCase().replace(/\s+/g, " ");
async function clientFor(db, input, actor) {
  if (input.client_id) {
    const c = await db.one(`SELECT _id FROM ${T.clients} WHERE _id = ? AND _deleted = 0`, [idOf(input.client_id, "client_id")]);
    if (!c) throw new Refused(`There is no client ${input.client_id}: list them with clients, or name the client (client).`, 404, { code: "NO_CLIENT", item: input.client_id });
    return { id: c._id, created: false };
  }
  const given = typeof input.client === "object" && input.client ? input.client : { name: input.client };
  if (!clean(given.name)) throw new Refused("Say who it is for: client_id, or client (a name, or { name, tax_id, email, address }).", 400, { code: "NO_CLIENT" });
  const found = await findClient(db, given);
  if (found) return { id: found._id, created: false };
  const [id] = await saveClients(db, { items: [given] });
  return { id: id.id, created: true };
}
async function findClient(db, given) {
  if (clean(given.tax_id)) {
    const c = await db.one(`SELECT _id FROM ${T.clients} WHERE _deleted = 0 AND UPPER(REPLACE(tax_id, ' ', '')) = ?`, [clean(given.tax_id).toUpperCase().replace(/\s/g, "")]);
    if (c) return c;
  }
  const all = await db.all(`SELECT _id, name FROM ${T.clients} WHERE _deleted = 0`);
  return all.find((c) => norm(c.name) === norm(given.name)) || null;
}
async function saveClients(db, { items }) {
  if (!Array.isArray(items) || !items.length) throw new Refused("items is a list of clients: [{ name, tax_id, email, contact_name, address, country }].", 400, { code: "BAD_INPUT" });
  if (items.length > 100) throw new Refused("At most 100 clients in one call.", 400, { code: "TOO_MANY" });
  const out = [];
  for (const raw2 of items) {
    const data = {};
    for (const f of FIELDS) if (raw2[f] !== void 0) data[f] = f === "crm_company_id" ? raw2[f] ? Number(raw2[f]) || null : null : clean(raw2[f], f === "notes" || f === "address" ? 600 : 160);
    if (data.email && !core_default.isEmail(data.email)) throw new Refused(`${data.email} is not an email address.`, 400, { code: "BAD_EMAIL", item: raw2.id ?? raw2.name });
    const existing = raw2.id ? await db.one(`SELECT _id FROM ${T.clients} WHERE _id = ? AND _deleted = 0`, [idOf(raw2.id)]) : await findClient(db, raw2);
    if (existing) {
      if (Object.keys(data).length) await db.update(T.clients, existing._id, data);
      out.push({ id: existing._id, created: false });
      continue;
    }
    if (!data.name) throw new Refused("A new client needs a name.", 400, { code: "BAD_INPUT", item: raw2.name });
    out.push({ id: await db.insert(T.clients, { ...data, archived: "no" }), created: true });
  }
  return out;
}
async function listClients(db, s, input, deps) {
  const today = todayOf(s, deps);
  const rows = await db.all(`SELECT * FROM ${T.clients} WHERE _deleted = 0 AND COALESCE(archived, 'no') <> 'yes' ORDER BY name COLLATE NOCASE`);
  const sums = new Map((await db.all(`SELECT client_id, SUM(CASE WHEN kind = 'invoice' AND status IN ('Issued', 'Paid') THEN total ELSE 0 END) AS billed, SUM(CASE WHEN kind = 'invoice' AND status = 'Issued' THEN total ELSE 0 END) AS owed, SUM(CASE WHEN kind = 'invoice' AND status = 'Issued' AND due_date < ? THEN 1 ELSE 0 END) AS late, COUNT(*) AS docs FROM ${T.docs} WHERE _deleted = 0 AND status <> 'Discarded' GROUP BY client_id`, [today])).map((r) => [r.client_id, r]));
  const fees = new Map((await db.all(`SELECT client_id, COUNT(*) AS n FROM ${T.recurring} WHERE _deleted = 0 AND state = 'active' GROUP BY client_id`)).map((r) => [r.client_id, r.n]));
  const q = input.q ? norm(input.q) : "";
  return {
    rows: rows.filter((c) => !q || norm(c.name).includes(q) || norm(c.tax_id).includes(q)).map((c) => {
      const x = sums.get(c._id) || {};
      return { id: c._id, name: c.name, tax_id: c.tax_id || "", email: c.email || "", billed: x.billed || 0, owed: x.owed || 0, owed_text: money(x.owed || 0, s.currency), billed_text: money(x.billed || 0, s.currency), late: x.late || 0, documents: x.docs || 0, fees: fees.get(c._id) || 0, ...c.crm_company_id ? { crm_company_id: c.crm_company_id } : {} };
    })
  };
}
async function getClient(db, id) {
  const c = await db.one(`SELECT * FROM ${T.clients} WHERE _id = ? AND _deleted = 0`, [idOf(id)]);
  if (!c) throw new Refused(`There is no client ${id}.`, 404, { code: "NOT_FOUND", item: id });
  return { id: c._id, ...Object.fromEntries(FIELDS.map((f) => [f, c[f] ?? null])), archived: c.archived === "yes" };
}
async function archiveClient(db, { id }) {
  const c = await getClient(db, id);
  const open = await db.one(`SELECT COUNT(*) AS n FROM ${T.docs} WHERE _deleted = 0 AND client_id = ? AND status IN ('Draft', 'Sent', 'Issued')`, [c.id]);
  if (open.n) throw new Refused(`${c.name} has ${open.n} document(s) still open (drafts, quotes waiting, invoices unpaid): close them first.`, 409, { code: "HAS_OPEN", item: c.id });
  await db.update(T.clients, c.id, { archived: "yes" });
  return { id: c.id, archived: true };
}

// server/services/documents.mjs
var LIVE = "_deleted = 0 AND status <> 'Discarded'";
var KINDS = { quote: "presupuesto", invoice: "factura" };
function stateOf(doc, today) {
  const st = core_default.stateOf(doc, today);
  if (doc.kind === "quote" && st === "Void") return "Withdrawn";
  if (doc.kind === "quote" && st === "Accepted" && doc.invoice_id) return "Invoiced";
  return st;
}
var daysLate = (doc, today) => doc.status === "Issued" && doc.due_date && doc.due_date < today ? core_default.daysBetween(doc.due_date, today) : 0;
var clientName = (doc, clients) => jsonOf(doc.client_snapshot, {}).name || clients && clients.get(doc.client_id) || "";
async function docOf(db, id) {
  const d = await db.one(`SELECT * FROM ${T.docs} WHERE _id = ? AND _deleted = 0`, [idOf(id)]);
  if (!d) throw new Refused(`There is no document ${id}: list them with documents.`, 404, { code: "NOT_FOUND", item: id });
  return d;
}
function rowOf(d, today, clients) {
  return {
    id: d._id,
    kind: d.kind,
    number: d.number || null,
    title: d.title || "",
    client: clientName(d, clients),
    client_id: d.client_id ?? null,
    state: stateOf(d, today),
    total: Number(d.total) || core_default.totals(d).total,
    currency: d.currency,
    total_text: money(Number(d.total) || core_default.totals(d).total, d.currency),
    issue_date: d.issue_date || null,
    due_date: d.due_date || null,
    days_late: daysLate(d, today),
    paid_at: d.paid_at || null,
    ...d.recurring_id ? { recurring_id: d.recurring_id, period: d.period_label || d.period || null } : {},
    ...d.origin ? { origin: d.origin } : {}
  };
}
var STATE_FILTER = {
  draft: "status = 'Draft'",
  waiting: "status = 'Sent'",
  accepted: "status = 'Accepted'",
  declined: "status IN ('Declined')",
  withdrawn: "kind = 'quote' AND status = 'Void'",
  unpaid: "status = 'Issued'",
  overdue: "status = 'Issued' AND due_date < ?",
  paid: "status = 'Paid'",
  void: "kind = 'invoice' AND status = 'Void'"
};
async function listDocs(db, s, input, deps, whole) {
  const today = todayOf(s, deps);
  const where = [LIVE];
  const params = [];
  if (input.kind) {
    if (!KINDS[input.kind]) throw new Refused("kind is quote or invoice.", 400, { code: "BAD_INPUT" });
    where.push("kind = ?");
    params.push(input.kind);
  }
  if (input.client_id) {
    where.push("client_id = ?");
    params.push(idOf(input.client_id, "client_id"));
  }
  if (input.recurring_id) {
    where.push("recurring_id = ?");
    params.push(idOf(input.recurring_id, "recurring_id"));
  }
  if (input.origin) {
    where.push("origin = ?");
    params.push(clean(input.origin, 120));
  }
  if (input.q) {
    where.push("(LOWER(COALESCE(number,'') || ' ' || COALESCE(title,'') || ' ' || COALESCE(client_snapshot,'')) LIKE ? OR client_id IN (SELECT _id FROM inv_clients WHERE LOWER(name) LIKE ?))");
    const q = `%${clean(input.q, 80).toLowerCase()}%`;
    params.push(q, q);
  }
  const base = where.join(" AND ");
  const counts = {};
  for (const [k, sql] of Object.entries(STATE_FILTER)) {
    const r = await db.one(`SELECT COUNT(*) AS n FROM ${T.docs} WHERE ${base} AND ${sql}`, [...params, ...sql.includes("?") ? [today] : []]);
    if (r.n) counts[k] = r.n;
  }
  if (input.state) {
    const f = STATE_FILTER[input.state];
    if (!f) throw new Refused(`state is one of ${Object.keys(STATE_FILTER).join(", ")}.`, 400, { code: "BAD_INPUT" });
    where.push(f);
    if (f.includes("?")) params.push(today);
  }
  const limit = Math.max(1, Math.min(whole ? 500 : 20, Number(input.limit) || (whole ? 500 : 20)));
  const offset = Math.max(0, Number(input.offset) || 0);
  const rows = await db.all(`SELECT * FROM ${T.docs} WHERE ${where.join(" AND ")} ORDER BY CASE WHEN status = 'Draft' THEN 0 ELSE 1 END, COALESCE(issue_date, substr(_created_at, 1, 10)) DESC, _id DESC LIMIT ? OFFSET ?`, [...params, limit + 1, offset]);
  const clients = new Map((await db.all(`SELECT _id, name FROM ${T.clients} WHERE _deleted = 0`)).map((c) => [c._id, c.name]));
  const out = { rows: rows.slice(0, limit).map((d) => rowOf(d, today, clients)), counts };
  if (rows.length > limit) out.more = `More: offset ${offset + limit}.`;
  return out;
}
async function getDoc(db, s, id, deps) {
  const d = await docOf(db, id);
  const today = todayOf(s, deps);
  const t = core_default.totals(d);
  const client = d.client_id ? await db.one(`SELECT * FROM ${T.clients} WHERE _id = ?`, [d.client_id]) : null;
  const emails = await db.all(`SELECT _id AS id, purpose, n, to_email, subject, body, status, error, sent_at FROM ${T.emails} WHERE _deleted = 0 AND doc_id = ? ORDER BY _id DESC LIMIT 10`, [d._id]);
  const other = d.kind === "quote" && d.invoice_id ? await db.one(`SELECT _id, number, status FROM ${T.docs} WHERE _id = ?`, [d.invoice_id]) : d.quote_id ? await db.one(`SELECT _id, number, status FROM ${T.docs} WHERE _id = ?`, [d.quote_id]) : null;
  const rec = d.recurring_id ? await db.one(`SELECT _id, title FROM ${T.recurring} WHERE _id = ?`, [d.recurring_id]) : null;
  const frozen = jsonOf(d.client_snapshot, null);
  return {
    ...rowOf(d, today, null),
    client: frozen && frozen.name || client && client.name || "",
    client_card: frozen || (client ? { name: client.name, tax_id: client.tax_id, email: client.email, contact_name: client.contact_name, address: client.address, country: client.country } : null),
    lines: linesOut(d.lines, d.currency),
    totals: { subtotal: t.subtotal, taxes: t.taxes, withholding_rate: t.withholdingRate, withholding: t.withholding, total: t.total },
    withholding_rate: t.withholdingRate,
    notes: d.notes || "",
    link: d.status === "Draft" ? null : linkOf(s, d),
    sent_at: d.sent_at || null,
    accepted: d.accepted_at ? { name: d.accepted_name, at: d.accepted_at, by: d.answered_by } : null,
    declined: d.declined_at ? { at: d.declined_at, reason: d.decline_reason || "" } : null,
    void: d.void_at ? { at: d.void_at, reason: d.void_reason || "", by: d.voided_by } : null,
    paid: d.paid_at ? { at: d.paid_at, how: d.paid_how, by: d.paid_by } : null,
    pay_url: d.pay_url || null,
    reminders: Number(d.reminders) || 0,
    last_reminder_at: d.last_reminder_at || null,
    issue_note: d.issue_note || null,
    quote: d.quote_id && other ? { id: other._id, number: other.number } : null,
    invoice: d.kind === "quote" && other ? { id: other._id, number: other.number, status: other.status } : null,
    recurring: rec ? { id: rec._id, title: rec.title } : null,
    emails,
    can: canOf(d, today)
  };
}
function canOf(d, today) {
  const st = d.status;
  return {
    edit: st === "Draft",
    issue: st === "Draft",
    discard: st === "Draft",
    email: d.kind === "quote" && st === "Sent" || d.kind === "invoice" && st === "Issued",
    answer: d.kind === "quote" && st === "Sent" && !(d.due_date && d.due_date < today),
    withdraw: d.kind === "quote" && st === "Sent",
    to_invoice: d.kind === "quote" && st === "Accepted" && !d.invoice_id,
    paid: d.kind === "invoice" && st === "Issued",
    not_paid: d.kind === "invoice" && st === "Paid" && d.paid_how !== "stripe",
    void: d.kind === "invoice" && st === "Issued",
    pay_url: d.kind === "invoice" && st === "Issued",
    duplicate: st !== "Discarded"
  };
}
async function saveDraft(db, s, input, actor, deps) {
  const old = input.id ? await docOf(db, input.id) : null;
  if (old && old.status !== "Draft") throw new Refused(`${old.number || "This document"} is issued, so it is never changed: duplicate it (duplicate) to write a new draft from it.`, 409, { code: "NOT_A_DRAFT", item: old._id });
  const kind = old ? old.kind : input.kind;
  if (!KINDS[kind]) throw new Refused("kind is quote (a presupuesto) or invoice (a factura).", 400, { code: "BAD_INPUT", item: "kind" });
  const currency = String(input.currency || old && old.currency || s.currency || "EUR").toUpperCase();
  if (!core_default.CURRENCIES.includes(currency)) throw new Refused(`currency is one of ${core_default.CURRENCIES.join(", ")}.`, 400, { code: "BAD_INPUT", item: "currency" });
  const data = { currency };
  if (input.client_id !== void 0 || input.client !== void 0) data.client_id = (await clientFor(db, input, actor)).id;
  if (input.title !== void 0) data.title = clean(input.title, 200);
  if (input.notes !== void 0) data.notes = clean(input.notes, 2e3);
  if (input.origin !== void 0) data.origin = clean(input.origin, 120) || null;
  if (input.due_date !== void 0) data.due_date = dayOf(input.due_date, "due_date");
  if (input.withholding_rate !== void 0 && input.withholding_rate !== "") data.withholding_rate = core_default.pct(input.withholding_rate);
  if (input.lines !== void 0) data.lines = JSON.stringify(linesFrom(input.lines, currency, s));
  if (!old) {
    if (data.withholding_rate === void 0) data.withholding_rate = core_default.pct(s.withholding_rate);
    if (data.lines === void 0) data.lines = "[]";
    const totals2 = core_default.totals({ ...data });
    const id = await db.insert(T.docs, { kind, status: "Draft", ...data, subtotal: totals2.subtotal, tax_total: totals2.taxTotal, withholding: totals2.withholding, total: totals2.total, created_by: whoOf(actor), reminders: 0 });
    return { id, kind, total: totals2.total, total_text: money(totals2.total, currency) };
  }
  const totals = core_default.totals({ ...old, ...data });
  const changed = await db.update(T.docs, old._id, { ...data, subtotal: totals.subtotal, tax_total: totals.taxTotal, withholding: totals.withholding, total: totals.total }, { status: "Draft" });
  if (!changed) throw new Refused("It was issued or removed a moment ago: read it again.", 409, { code: "CHANGED", item: old._id });
  return { id: old._id, kind, total: totals.total, total_text: money(totals.total, currency) };
}
async function discardDraft(db, id) {
  const d = await docOf(db, id);
  if (d.status !== "Draft") throw new Refused(`${d.number} is issued: an invoice is voided (invoice_void), a quote withdrawn (quote_withdraw), never deleted.`, 409, { code: "NOT_A_DRAFT", item: d._id });
  await db.update(T.docs, d._id, { status: "Discarded" }, { status: "Draft" });
  return { id: d._id, discarded: true };
}
async function issue(db, s, id, actor, deps) {
  for (let attempt = 0; attempt < 6; attempt += 1) {
    const d = await docOf(db, id);
    if (d.status !== "Draft") throw new Refused(`${d.number || "It"} is already issued.`, 409, { code: "ALREADY_ISSUED", item: d._id });
    const client = d.client_id ? await db.one(`SELECT * FROM ${T.clients} WHERE _id = ? AND _deleted = 0`, [d.client_id]) : null;
    const problems = core_default.issueProblems(d, client);
    if (problems.length) throw new Refused(`It cannot be issued yet: ${problems.join(" ")} Fix the draft (draft_save) and issue it again.`, 409, { code: "NOT_READY", item: d._id });
    const day = todayOf(s, deps);
    const year = Number(day.slice(0, 4));
    const kind = d.kind;
    const series = await db.one(`SELECT * FROM ${T.series} WHERE _deleted = 0 AND kind = ? AND year = ?`, [kind, year]);
    const n = (series ? Number(series.last) || 0 : 0) + 1;
    const number = core_default.numberOf(core_default.prefixOf(kind, s), year, n, s.number_digits);
    const t = core_default.totals(d);
    const days = kind === "quote" ? Number(s.quote_valid_days) || 30 : Number(s.payment_days) || 30;
    const due = core_default.realDay(d.due_date) && d.due_date >= day ? d.due_date : core_default.addDays(day, days);
    const frozen = Object.fromEntries(["name", "tax_id", "email", "contact_name", "address", "country"].map((k) => [k, clean(client[k], 600)]));
    const ops = [
      series ? { op: "update", table: T.series, id: series._id, where: { last: series.last }, data: { last: n } } : { op: "insert", table: T.series, data: { kind, year, last: n } },
      { op: "update", table: T.docs, id: d._id, where: { status: "Draft" }, data: {
        status: kind === "quote" ? "Sent" : "Issued",
        number,
        series_year: year,
        seq: n,
        issue_date: day,
        due_date: due,
        currency: String(d.currency || s.currency || "EUR").toUpperCase(),
        client_snapshot: JSON.stringify(frozen),
        lines: JSON.stringify(t.lines.map(({ description, qty, price, tax, disc }) => ({ description, qty, price, tax, disc }))),
        subtotal: t.subtotal,
        tax_total: t.taxTotal,
        withholding: t.withholding,
        total: t.total,
        withholding_rate: t.withholdingRate,
        link_token: d.link_token || core_default.newToken(),
        issued_at: sqlTime(nowOf(deps)),
        issued_by: whoOf(actor),
        issue_note: null,
        reminders: 0
      } }
    ];
    try {
      await db.batch(ops);
    } catch {
      continue;
    }
    const after = await docOf(db, d._id);
    if (after.number !== number) continue;
    await sealDoc(db, s, after);
    return { id: d._id, number, total: t.total, total_text: money(t.total, after.currency), due_date: due, link: linkOf(s, after) };
  }
  throw new Refused("It could not take a number after several tries (others were issuing at the same time): issue it again.", 409, { code: "BUSY" });
}
async function settle(db, s, d, data, where) {
  const changed = await db.update(T.docs, d._id, data, where);
  if (!changed) throw new Refused("It changed a moment ago: read it again.", 409, { code: "CHANGED", item: d._id });
  const after = await docOf(db, d._id);
  await sealDoc(db, s, after);
  return after;
}
async function voidInvoice(db, s, { id, reason }, actor, deps) {
  const d = await docOf(db, id);
  if (d.kind !== "invoice" || d.status !== "Issued") throw new Refused(d.kind !== "invoice" ? "A quote is withdrawn (quote_withdraw), not voided." : `Only an issued invoice waiting for payment is voided; this one is ${d.status}.${d.status === "Paid" ? " If it was not paid after all, use not_paid first." : ""}`, 409, { code: "CANNOT_VOID", item: d._id });
  if (!clean(reason)) throw new Refused("Say why it is voided (reason): it is kept with the invoice, which keeps its number.", 400, { code: "BAD_INPUT", item: "reason" });
  await settle(db, s, d, { status: "Void", void_at: sqlTime(nowOf(deps)), void_reason: clean(reason, 400), voided_by: whoOf(actor) }, { status: "Issued" });
  return { id: d._id, number: d.number, state: "Void" };
}
async function withdrawQuote(db, s, { id, reason }, actor, deps) {
  const d = await docOf(db, id);
  if (d.kind !== "quote" || d.status !== "Sent") throw new Refused(`Only a quote waiting for an answer is withdrawn; this one is ${d.status}.`, 409, { code: "CANNOT_WITHDRAW", item: d._id });
  await settle(db, s, d, { status: "Void", void_at: sqlTime(nowOf(deps)), void_reason: clean(reason, 400) || null, voided_by: whoOf(actor) }, { status: "Sent" });
  return { id: d._id, number: d.number, state: "Withdrawn" };
}
async function markPaid(db, s, { id, day, how }, actor, deps) {
  const d = await docOf(db, id);
  if (d.kind !== "invoice" || d.status !== "Issued") throw new Refused(`Only an issued invoice is marked paid; this one is ${d.kind === "quote" ? "a quote" : d.status}.`, 409, { code: "CANNOT_PAY", item: d._id });
  const paid = dayOf(day, "day") || todayOf(s, deps);
  await settle(db, s, d, { status: "Paid", paid_at: paid, paid_how: ["bank", "card", "cash", "other"].includes(how) ? how : "bank", paid_by: whoOf(actor) }, { status: "Issued" });
  return { id: d._id, number: d.number, state: "Paid", paid_at: paid };
}
async function notPaid(db, s, { id }) {
  const d = await docOf(db, id);
  if (d.kind !== "invoice" || d.status !== "Paid") throw new Refused("Only a paid invoice goes back to waiting for payment.", 409, { code: "NOT_PAID", item: d._id });
  if (d.paid_how === "stripe") throw new Refused("Stripe recorded this payment: refund it in Stripe instead.", 409, { code: "PAID_BY_STRIPE", item: d._id });
  await settle(db, s, d, { status: "Issued", paid_at: null, paid_how: null, paid_by: null }, { status: "Paid" });
  return { id: d._id, number: d.number, state: "Issued" };
}
async function answerQuote(db, s, { id, decision, name, reason }, actor, deps) {
  const d = await docOf(db, id);
  if (d.kind !== "quote" || d.status !== "Sent") throw new Refused(`Only a quote waiting for an answer is answered; this one is ${d.status}.`, 409, { code: "NOT_WAITING", item: d._id });
  if (!["accept", "decline"].includes(decision)) throw new Refused("decision is accept or decline.", 400, { code: "BAD_INPUT", item: "decision" });
  const at = sqlTime(nowOf(deps));
  const data = decision === "accept" ? { status: "Accepted", accepted_at: at, accepted_name: clean(name, 120) || jsonOf(d.client_snapshot, {}).name || "", answered_by: whoOf(actor) } : { status: "Declined", declined_at: at, decline_reason: clean(reason, 500) || null, answered_by: whoOf(actor) };
  await settle(db, s, d, data, { status: "Sent" });
  return { id: d._id, number: d.number, state: data.status };
}
async function quoteToInvoice(db, s, { id }, actor) {
  const q = await docOf(db, id);
  if (q.kind !== "quote" || q.status !== "Accepted") throw new Refused(`Only an accepted quote becomes an invoice; this one is ${q.status}. If the client said yes outside the link, record it first (quote_answer).`, 409, { code: "NOT_ACCEPTED", item: q._id });
  if (q.invoice_id) {
    const inv = await db.one(`SELECT _id, number, status FROM ${T.docs} WHERE _id = ? AND ${LIVE} AND status <> 'Void'`, [q.invoice_id]);
    if (inv) throw new Refused(`It already has its invoice (${inv.number || "a draft"}, id ${inv._id}).`, 409, { code: "ALREADY_INVOICED", item: inv._id });
  }
  const t = core_default.totals(q);
  let id2;
  try {
    [id2] = await db.batch([{ op: "insert", table: T.docs, data: { kind: "invoice", status: "Draft", client_id: q.client_id, title: q.title, currency: q.currency, lines: q.lines, withholding_rate: q.withholding_rate, notes: q.notes, quote_id: q._id, origin: q.origin || null, subtotal: t.subtotal, tax_total: t.taxTotal, withholding: t.withholding, total: t.total, created_by: whoOf(actor), reminders: 0 } }]);
  } catch {
    throw new Refused("It already has its invoice: read the quote again.", 409, { code: "ALREADY_INVOICED", item: q._id });
  }
  await db.update(T.docs, q._id, { invoice_id: id2 });
  return { id: id2, quote_id: q._id, total: t.total, total_text: money(t.total, q.currency) };
}
async function duplicate(db, s, { id, kind }, actor) {
  const d = await docOf(db, id);
  const k = kind && KINDS[kind] ? kind : d.kind;
  const t = core_default.totals(d);
  const id2 = await db.insert(T.docs, { kind: k, status: "Draft", client_id: d.client_id, title: d.title, currency: d.currency, lines: d.lines, withholding_rate: d.withholding_rate, notes: d.notes, origin: d.origin || null, subtotal: t.subtotal, tax_total: t.taxTotal, withholding: t.withholding, total: t.total, created_by: whoOf(actor), reminders: 0 });
  return { id: id2, kind: k, total_text: money(t.total, d.currency) };
}
async function setPayUrl(db, s, { id, url }) {
  const d = await docOf(db, id);
  if (d.kind !== "invoice" || d.status !== "Issued") throw new Refused("Only an issued invoice waiting for payment gets a payment link.", 409, { code: "NOT_PAYABLE", item: d._id });
  const u = clean(url, 600);
  if (u && !/^https:\/\/[^\s]+$/.test(u)) throw new Refused("url is the https address of the payment page (a Stripe Payment Link, for instance); empty removes it.", 400, { code: "BAD_INPUT", item: "url" });
  await settle(db, s, d, { pay_url: u || null }, { status: "Issued" });
  return { id: d._id, number: d.number, pay_url: u || null };
}
async function importDocs(db, s, { items, dry_run }, actor) {
  if (!Array.isArray(items) || !items.length) throw new Refused("items is a list: [{ kind, number, client, issue_date, due_date, title, lines | base, tax, status (issued|paid|void), paid_at }].", 400, { code: "BAD_INPUT" });
  if (items.length > 200) throw new Refused("At most 200 documents in one call: send the rest in another.", 400, { code: "TOO_MANY" });
  const dry = dry_run !== false && dry_run !== "false";
  const out = { would: dry, imported: [], skipped: [] };
  const highest = /* @__PURE__ */ new Map();
  for (const [i, raw2] of items.entries()) {
    try {
      const kind = raw2.kind === "quote" ? "quote" : "invoice";
      const number = clean(raw2.number, 40);
      if (!number) throw new Refused("It has no number.", 400, { code: "NO_NUMBER" });
      if (await db.one(`SELECT _id FROM ${T.docs} WHERE _deleted = 0 AND kind = ? AND number = ?`, [kind, number])) throw new Refused(`${number} is already here.`, 409, { code: "DUPLICATE" });
      const issueDay = dayOf(raw2.issue_date, "issue_date");
      if (!issueDay) throw new Refused("It has no issue_date.", 400, { code: "NO_DATE" });
      const currency = String(raw2.currency || s.currency || "EUR").toUpperCase();
      const lines = raw2.lines ? linesFrom(raw2.lines, currency, s) : linesFrom([{ description: raw2.title || number, qty: 1, price: raw2.base, tax: raw2.tax ?? s.tax_rate }], currency, s);
      const t = core_default.totals({ lines, withholding_rate: raw2.withholding_rate ?? 0 });
      const status = { paid: "Paid", void: "Void", issued: kind === "quote" ? "Sent" : "Issued", accepted: "Accepted", declined: "Declined" }[String(raw2.status || "issued").toLowerCase()] || "Issued";
      const year = Number(issueDay.slice(0, 4));
      const seq = core_default.seqOf(number, core_default.prefixOf(kind, s), year);
      if (seq) {
        const key = `${kind}:${year}`;
        highest.set(key, Math.max(highest.get(key) || 0, seq));
      }
      const row = { kind, number, status, issue_date: issueDay, due_date: dayOf(raw2.due_date, "due_date") || core_default.addDays(issueDay, Number(s.payment_days) || 30), title: clean(raw2.title, 200), currency, lines: JSON.stringify(lines), withholding_rate: t.withholdingRate, subtotal: t.subtotal, tax_total: t.taxTotal, withholding: t.withholding, total: t.total, paid_at: status === "Paid" ? dayOf(raw2.paid_at, "paid_at") || issueDay : null, paid_how: status === "Paid" ? "bank" : null, series_year: seq ? year : null, seq: seq || null, notes: clean(raw2.notes, 2e3), created_by: whoOf(actor), imported: "yes", reminders: 0 };
      if (!dry) {
        const client = await clientFor(db, { client: raw2.client, client_id: raw2.client_id }, actor);
        const c = await db.one(`SELECT * FROM ${T.clients} WHERE _id = ?`, [client.id]);
        row.client_id = client.id;
        row.client_snapshot = JSON.stringify(Object.fromEntries(["name", "tax_id", "email", "contact_name", "address", "country"].map((k) => [k, clean(c[k])])));
        row.link_token = core_default.newToken();
        const id = await db.insert(T.docs, row);
        await sealDoc(db, s, await docOf(db, id));
        out.imported.push({ index: i, id, number });
      } else out.imported.push({ index: i, number, total_text: money(t.total, currency), state: status });
    } catch (e) {
      out.skipped.push({ index: i, code: e.code || "FAILED", why: e.message });
    }
  }
  if (!dry) for (const [key, last] of highest) await raiseSeries(db, key.split(":")[0], Number(key.split(":")[1]), last);
  out.next = { invoice: await nextNumber(db, s, "invoice", Number(todayOf(s, {}).slice(0, 4))), quote: await nextNumber(db, s, "quote", Number(todayOf(s, {}).slice(0, 4))) };
  return out;
}
async function raiseSeries(db, kind, year, last) {
  const row = await db.one(`SELECT * FROM ${T.series} WHERE _deleted = 0 AND kind = ? AND year = ?`, [kind, year]);
  if (!row) await db.insert(T.series, { kind, year, last });
  else if ((Number(row.last) || 0) < last) await db.update(T.series, row._id, { last }, { last: row.last });
}
async function nextNumber(db, s, kind, year) {
  const row = await db.one(`SELECT last FROM ${T.series} WHERE _deleted = 0 AND kind = ? AND year = ?`, [kind, year]);
  return core_default.numberOf(core_default.prefixOf(kind, s), year, (row ? Number(row.last) || 0 : 0) + 1, s.number_digits);
}
async function numbering(db, s, deps) {
  const year = Number(todayOf(s, deps).slice(0, 4));
  return { year, invoice: { prefix: core_default.prefixOf("invoice", s), next: await nextNumber(db, s, "invoice", year) }, quote: { prefix: core_default.prefixOf("quote", s), next: await nextNumber(db, s, "quote", year) }, digits: Number(s.number_digits) || 4 };
}
async function setNumbering(db, s, { kind, next }, deps) {
  if (!KINDS[kind]) throw new Refused("kind is quote or invoice.", 400, { code: "BAD_INPUT", item: "kind" });
  const n = Math.trunc(Number(next));
  if (!(n >= 1 && n < 10 ** 6)) throw new Refused("next is the sequence the next one takes (12 makes DUG-2026-012).", 400, { code: "BAD_INPUT", item: "next" });
  const year = Number(todayOf(s, deps).slice(0, 4));
  const used = await db.one(`SELECT MAX(seq) AS m FROM ${T.docs} WHERE _deleted = 0 AND kind = ? AND series_year = ?`, [kind, year]);
  if (used && used.m && n <= used.m) throw new Refused(`${core_default.numberOf(core_default.prefixOf(kind, s), year, used.m, s.number_digits)} is already used this year: the next can only be ${used.m + 1} or later. Numbers never repeat.`, 409, { code: "NUMBER_USED", item: used.m });
  const row = await db.one(`SELECT * FROM ${T.series} WHERE _deleted = 0 AND kind = ? AND year = ?`, [kind, year]);
  if (!row) await db.insert(T.series, { kind, year, last: n - 1 });
  else await db.update(T.series, row._id, { last: n - 1 });
  return { kind, next: core_default.numberOf(core_default.prefixOf(kind, s), year, n, s.number_digits) };
}

// server/services/emails.mjs
var OPEN = "('Review', 'Approved', 'Sending')";
async function prepareEmail(db, s, { id, to, purpose = "send", approved_by }) {
  const d = await docOf(db, id);
  if (!["Sent", "Issued"].includes(d.status)) throw new Refused(d.status === "Draft" ? "Issue it first (issue): a draft has no number and no link to send." : `It is ${d.status}: nothing to send.`, 409, { code: "NOT_SENDABLE", item: d._id });
  const link = linkOf(s, d);
  if (!link) throw new Refused("The address of the client's page is not known yet (it is set when the module is installed): reinstall or update Invoices from M\xF3dulos.", 409, { code: "NO_PUBLIC_PAGE" });
  const open = await db.one(`SELECT _id, status FROM ${T.emails} WHERE _deleted = 0 AND doc_id = ? AND purpose = ? AND status IN ${OPEN}`, [d._id, purpose]);
  if (open) return { id: open._id, status: open.status, existed: true };
  const address = clean(to, 160) || jsonOf(d.client_snapshot, {}).email || "";
  if (!core_default.isEmail(address)) throw new Refused(`The client has no email address${address ? ` (${address} is not one)` : ""}: pass to, or complete the client (clients_save).`, 400, { code: "NO_ADDRESS", item: d.client_id });
  const words = purpose === "reminder" ? core_default.reminderEmail(d, s, link) : core_default.sendEmail(d, s, link);
  const n = purpose === "reminder" ? (Number(d.reminders) || 0) + 1 : 0;
  const status = approved_by ? "Approved" : "Review";
  const eid = await db.insert(T.emails, { doc_id: d._id, purpose, n, to_email: address, subject: words.subject, body: words.body, status, drafted_by: "invoices", ...approved_by ? { approved_by, approved_at: sqlTime(/* @__PURE__ */ new Date()) } : {} });
  return { id: eid, status, to: address, subject: words.subject };
}
async function editEmail(db, s, { id, subject, body, to }) {
  const e = await emailOf(db, id);
  if (e.status !== "Review") throw new Refused(`It is ${e.status}: only an email waiting for review is changed.`, 409, { code: "NOT_IN_REVIEW", item: e._id });
  const data = {};
  if (subject !== void 0) data.subject = clean(subject, 200);
  if (body !== void 0) data.body = clean(body, 6e3);
  if (to !== void 0) {
    if (!core_default.isEmail(to)) throw new Refused(`${to} is not an email address.`, 400, { code: "BAD_EMAIL" });
    data.to_email = clean(to, 160);
  }
  const d = await docOf(db, e.doc_id);
  const link = linkOf(s, d);
  if (data.body !== void 0 && link && !data.body.includes(d.link_token)) data.body = `${data.body}

${link}`;
  await db.update(T.emails, e._id, data, { status: "Review" });
  return { id: e._id, changed: Object.keys(data) };
}
async function emailOf(db, id) {
  const e = await db.one(`SELECT * FROM ${T.emails} WHERE _id = ? AND _deleted = 0`, [idOf(id)]);
  if (!e) throw new Refused(`There is no email ${id}.`, 404, { code: "NOT_FOUND", item: id });
  return e;
}
async function approveEmails(db, { ids }, actor, deps) {
  const list = (Array.isArray(ids) ? ids : [ids]).map((x) => idOf(x, "ids"));
  const out = [];
  for (const id of list) {
    const n = await db.update(T.emails, id, { status: "Approved", approved_by: whoOf(actor), approved_at: sqlTime(nowOf(deps)) }, { status: "Review" });
    out.push({ id, approved: !!n });
  }
  return { rows: out };
}
async function dropEmails(db, { ids }) {
  const list = (Array.isArray(ids) ? ids : [ids]).map((x) => idOf(x, "ids"));
  for (const id of list) {
    await db.update(T.emails, id, { status: "Dropped" }, { status: "Review" });
    await db.update(T.emails, id, { status: "Dropped" }, { status: "Approved" });
  }
  return { dropped: list.length };
}
async function emailsToSend(db) {
  const rows = await db.all(`SELECT e._id, e.doc_id, e.purpose, e.to_email, e.subject, e.body, d.number FROM ${T.emails} e JOIN ${T.docs} d ON d._id = e.doc_id WHERE e._deleted = 0 AND e.status = 'Approved' ORDER BY e._id LIMIT 20`);
  return { items: rows.map((e) => ({ key: `email:${e._id}`, text: `${e.purpose === "reminder" ? "Reminder for" : "Send"} ${e.number} to ${e.to_email}`, email_id: e._id, doc_id: e.doc_id, number: e.number, to: e.to_email, subject: e.subject, body: e.body })) };
}
async function emailsSent(db, { items }, actor, deps) {
  if (!Array.isArray(items) || !items.length) throw new Refused("items is a list: [{ id, ok: true }] or [{ id, ok: false, error }].", 400, { code: "BAD_INPUT" });
  const at = sqlTime(nowOf(deps));
  const out = [];
  for (const it of items) {
    const e = await emailOf(db, it.id);
    if (e.status !== "Approved" && e.status !== "Sending") {
      out.push({ id: e._id, skipped: e.status });
      continue;
    }
    if (it.ok === false) {
      await db.update(T.emails, e._id, { status: "Failed", error: clean(it.error, 400) || "Not sent" });
      out.push({ id: e._id, status: "Failed" });
      continue;
    }
    await db.update(T.emails, e._id, { status: "Sent", sent_at: at, error: null });
    const d = await docOf(db, e.doc_id);
    await db.update(T.docs, d._id, e.purpose === "reminder" ? { reminders: (Number(d.reminders) || 0) + 1, last_reminder_at: at } : { sent_at: d.sent_at || at });
    out.push({ id: e._id, status: "Sent" });
  }
  return { rows: out };
}
async function retryEmail(db, { id }, actor, deps) {
  const e = await emailOf(db, id);
  if (e.status !== "Failed") throw new Refused(`It is ${e.status}, not failed.`, 409, { code: "NOT_FAILED", item: e._id });
  await db.update(T.emails, e._id, { status: "Approved", error: null, approved_by: whoOf(actor), approved_at: sqlTime(nowOf(deps)) });
  return { id: e._id, status: "Approved" };
}
async function remindersDue(db, s, deps) {
  if (s.reminders_on === "no" || !s.public_url) return [];
  const today = todayOf(s, deps);
  const every = Math.max(1, Number(s.reminder_days) || 7);
  const docs = await db.all(`SELECT * FROM ${T.docs} WHERE _deleted = 0 AND kind = 'invoice' AND status = 'Issued' AND due_date < ? AND COALESCE(reminders, 0) < 3 AND NOT EXISTS (SELECT 1 FROM ${T.emails} e WHERE e._deleted = 0 AND e.doc_id = ${T.docs}._id AND e.purpose = 'reminder' AND e.status IN ${OPEN})`, [today]);
  const made = [];
  for (const d of docs) {
    if (d.last_reminder_at && core_default.daysBetween(d.last_reminder_at.slice(0, 10), today) < every) continue;
    if (!core_default.isEmail(jsonOf(d.client_snapshot, {}).email)) continue;
    try {
      made.push({ doc: d._id, ...await prepareEmail(db, s, { id: d._id, purpose: "reminder" }) });
    } catch {
    }
  }
  return made;
}

// server/services/recurring.mjs
var MONTHS = { month: 1, quarter: 3, year: 12 };
var ES_MONTHS = ["enero", "febrero", "marzo", "abril", "mayo", "junio", "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre"];
var EN_MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
var daysIn = (y, m) => new Date(Date.UTC(y, m + 1, 0)).getUTCDate();
function addMonths(day, n, anchor) {
  const [y, m, d] = day.split("-").map(Number);
  const total = y * 12 + (m - 1) + n;
  const ny = Math.floor(total / 12);
  const nm = total - ny * 12;
  const dd = Math.min(Number(anchor) || d, daysIn(ny, nm));
  return `${ny}-${String(nm + 1).padStart(2, "0")}-${String(dd).padStart(2, "0")}`;
}
function periodOf(on, every, bills) {
  const m = MONTHS[every] || 1;
  const first = `${on.slice(0, 7)}-01`;
  const start = bills === "arrears" ? addMonths(first, -m, 1) : first;
  return { start, end: core_default.addDays(addMonths(start, m, 1), -1) };
}
function periodLabel({ start, end }, every, lang = "es") {
  const names = lang === "en" ? EN_MONTHS : ES_MONTHS;
  const [ys, ms] = start.split("-").map(Number);
  const [ye, me] = end.split("-").map(Number);
  if (ys === ye && ms === me) return `${names[ms - 1]} ${ys}`;
  if (ys === ye && ms === 1 && me === 12) return String(ys);
  const short = (x) => names[x - 1].slice(0, 3);
  return ys === ye ? `${short(ms)} \u2013 ${short(me)} ${ye}` : `${short(ms)} ${ys} \u2013 ${short(me)} ${ye}`;
}
var fill = (text, label) => String(text || "").replace(/\{(periodo|period)\}/g, label);
function dueDates(rec, today, max = 12) {
  const out = [];
  let d = rec.next_on;
  while (d && d <= today && (!rec.until_on || d <= rec.until_on) && out.length < max) {
    out.push(d);
    d = addMonths(d, MONTHS[rec.every] || 1, rec.anchor_day);
  }
  return out;
}
var recOf = async (db, id) => {
  const r = await db.one(`SELECT * FROM ${T.recurring} WHERE _id = ? AND _deleted = 0`, [idOf(id)]);
  if (!r) throw new Refused(`There is no recurring fee ${id}: list them with recurring_list.`, 404, { code: "NOT_FOUND", item: id });
  return r;
};
function feeRow(r, clients, s, today) {
  const t = core_default.totals(r);
  const per = MONTHS[r.every] || 1;
  const next = r.state === "active" && r.next_on ? r.next_on : null;
  return {
    id: r._id,
    title: r.title || "",
    client: clients ? clients.get(r.client_id) || "" : void 0,
    client_id: r.client_id,
    state: r.state,
    every: r.every,
    bills: r.bills,
    total: t.total,
    subtotal: t.subtotal,
    total_text: money(t.total, r.currency),
    monthly: Math.round(t.subtotal / per),
    monthly_text: money(Math.round(t.subtotal / per), r.currency),
    next_on: next,
    next_period: next ? periodLabel(periodOf(next, r.every, r.bills), r.every, s.language === "en" ? "en" : "es") : null,
    due: !!(next && next <= today),
    until_on: r.until_on || null,
    mode: r.mode || "draft",
    send: r.send === "yes",
    made: Number(r.issued_count) || 0,
    last_on: r.last_on || null,
    ...r.origin ? { origin: r.origin } : {}
  };
}
async function listRecurring(db, s, input, deps) {
  const today = todayOf(s, deps);
  const where = ["_deleted = 0"];
  const params = [];
  if (input.client_id) {
    where.push("client_id = ?");
    params.push(idOf(input.client_id, "client_id"));
  }
  if (input.origin) {
    where.push("origin = ?");
    params.push(clean(input.origin, 120));
  }
  if (input.state) {
    where.push("state = ?");
    params.push(input.state);
  } else where.push("state <> 'ended'");
  const rows = await db.all(`SELECT * FROM ${T.recurring} WHERE ${where.join(" AND ")} ORDER BY CASE state WHEN 'active' THEN 0 ELSE 1 END, next_on, _id`, params);
  const clients = new Map((await db.all(`SELECT _id, name FROM ${T.clients} WHERE _deleted = 0`)).map((c) => [c._id, c.name]));
  const fees = rows.map((r) => feeRow(r, clients, s, today));
  const active = fees.filter((f) => f.state === "active");
  const monthly = active.reduce((a, f) => a + f.monthly, 0);
  return { rows: fees, active: active.length, monthly, monthly_text: money(monthly, s.currency), yearly_text: money(monthly * 12, s.currency) };
}
async function getRecurring(db, s, id, deps) {
  const r = await recOf(db, id);
  const today = todayOf(s, deps);
  const client = await db.one(`SELECT _id, name FROM ${T.clients} WHERE _id = ?`, [r.client_id]);
  const made = await db.all(`SELECT _id, number, status, period_label, total, issue_date, due_date, kind FROM ${T.docs} WHERE ${LIVE} AND recurring_id = ? ORDER BY period DESC, _id DESC LIMIT 24`, [r._id]);
  const t = core_default.totals(r);
  const coming = [];
  for (let d = r.next_on, i = 0; r.state === "active" && d && i < 3 && (!r.until_on || d <= r.until_on); i += 1, d = addMonths(d, MONTHS[r.every] || 1, r.anchor_day)) coming.push({ on: d, period: periodLabel(periodOf(d, r.every, r.bills), r.every, s.language === "en" ? "en" : "es") });
  return {
    ...feeRow(r, null, s, today),
    client: client ? client.name : "",
    lines: linesOut(r.lines, r.currency),
    currency: r.currency,
    withholding_rate: core_default.pct(r.withholding_rate),
    notes: r.notes || "",
    totals: { subtotal: t.subtotal, taxes: t.taxes, withholding: t.withholding, total: t.total },
    coming,
    made: made.map((d) => ({ id: d._id, number: d.number, state: d.status, period: d.period_label, total_text: money(d.total, r.currency), issue_date: d.issue_date, due_date: d.due_date })),
    quote_id: r.quote_id || null
  };
}
async function saveRecurring(db, s, input, actor, deps) {
  const old = input.id ? await recOf(db, input.id) : null;
  const person = isPerson(actor);
  if (old && old.state === "ended") throw new Refused("This fee has ended: add a new one instead.", 409, { code: "ENDED", item: old._id });
  if (!person && (input.mode === "issue" && (!old || old.mode !== "issue") || (input.send === true || input.send === "yes") && (!old || old.send !== "yes"))) throw new Refused("Only a person lets invoices be issued or emailed by themselves: save the fee as drafts (mode draft, the default) and tell them they can switch it in \xABRecurrentes\xBB.", 403, { code: "PERSON_ONLY" });
  if (!person && old && old.mode === "issue" && (input.lines !== void 0 || input.withholding_rate !== void 0 || input.currency !== void 0)) throw new Refused("This fee is issued by itself on a person's say-so, so its amounts are changed by a person: tell them what to change.", 403, { code: "PERSON_ONLY", item: old._id });
  const quote = input.quote_id ? await docOf(db, input.quote_id) : null;
  const currency = String(input.currency || old && old.currency || quote && quote.currency || s.currency || "EUR").toUpperCase();
  const data = { currency };
  if (input.client_id !== void 0 || input.client !== void 0) data.client_id = (await clientFor(db, input, actor)).id;
  else if (!old && quote) data.client_id = quote.client_id;
  if (input.title !== void 0) data.title = clean(input.title, 200);
  else if (!old && quote) data.title = quote.title;
  if (input.lines !== void 0) data.lines = JSON.stringify(linesFrom(input.lines, currency, s));
  else if (!old && quote) data.lines = quote.lines;
  if (input.notes !== void 0) data.notes = clean(input.notes, 2e3);
  if (input.origin !== void 0) data.origin = clean(input.origin, 120) || null;
  else if (!old && quote && quote.origin) data.origin = quote.origin;
  if (input.withholding_rate !== void 0 && input.withholding_rate !== "") data.withholding_rate = core_default.pct(input.withholding_rate);
  if (input.every !== void 0) {
    if (!MONTHS[input.every]) throw new Refused("every is month, quarter or year.", 400, { code: "BAD_INPUT", item: "every" });
    data.every = input.every;
  }
  if (input.bills !== void 0) {
    if (!["advance", "arrears"].includes(input.bills)) throw new Refused("bills is advance (the period that starts that day) or arrears (the period that just ended).", 400, { code: "BAD_INPUT", item: "bills" });
    data.bills = input.bills;
  }
  if (input.next_on !== void 0) {
    const d = dayOf(input.next_on, "next_on");
    if (!d) throw new Refused("next_on is the day the next invoice is made.", 400, { code: "BAD_INPUT", item: "next_on" });
    data.next_on = d;
    data.anchor_day = Number(d.slice(8));
  }
  if (input.until_on !== void 0) data.until_on = dayOf(input.until_on, "until_on");
  if (input.mode !== void 0) {
    if (!["draft", "issue"].includes(input.mode)) throw new Refused("mode is draft (a person issues each one) or issue (issued by itself).", 400, { code: "BAD_INPUT", item: "mode" });
    data.mode = input.mode;
    if (input.mode === "issue") data.mode_set_by = whoOf(actor);
  }
  if (input.send !== void 0) data.send = input.send === true || input.send === "yes" ? "yes" : "no";
  if (input.quote_id) data.quote_id = quote._id;
  const merged = { ...old || {}, ...data };
  if (!merged.client_id) throw new Refused("Say who it is for: client_id or client.", 400, { code: "NO_CLIENT" });
  if (!core_default.linesOf(merged.lines).length || core_default.totals(merged).total <= 0) throw new Refused("A fee needs its lines, with a total above zero: lines [{ description, qty, price, tax }] (price in the currency; {periodo} in a description becomes \xABnoviembre 2026\xBB).", 400, { code: "BAD_LINES" });
  if (merged.send === "yes" && merged.mode !== "issue") throw new Refused("Only an invoice issued by itself can be emailed by itself: set mode issue too, or leave send off.", 400, { code: "BAD_INPUT", item: "send" });
  if (!old) {
    const start = data.next_on || addMonths(`${todayOf(s, deps).slice(0, 7)}-01`, 1, 1);
    const id = await db.insert(T.recurring, { state: "active", every: "month", bills: "advance", mode: "draft", send: "no", withholding_rate: core_default.pct(s.withholding_rate), issued_count: 0, created_by: whoOf(actor), ...data, next_on: start, anchor_day: Number(start.slice(8)) });
    const r = await recOf(db, id);
    return { id, next_on: r.next_on, total_text: money(core_default.totals(r).total, currency), every: r.every, mode: r.mode };
  }
  await db.update(T.recurring, old._id, data);
  return { id: old._id, updated: Object.keys(data).filter((k) => k !== "currency") };
}
async function setRecurringState(db, { id, state }) {
  const r = await recOf(db, id);
  if (!["active", "paused", "ended"].includes(state)) throw new Refused("state is active, paused or ended.", 400, { code: "BAD_INPUT", item: "state" });
  if (r.state === "ended") throw new Refused("It has already ended: add a new fee instead.", 409, { code: "ENDED", item: r._id });
  await db.update(T.recurring, r._id, { state });
  return { id: r._id, state };
}
async function runRecurring(db, s, deps, { id } = {}) {
  const today = todayOf(s, deps);
  const lang = s.language === "en" ? "en" : "es";
  const fees = id ? [await recOf(db, id)] : await db.all(`SELECT * FROM ${T.recurring} WHERE _deleted = 0 AND state = 'active' AND next_on <= ? ORDER BY next_on, _id`, [today]);
  const out = { made: [], failed: [] };
  for (const r of fees) {
    if (r.state !== "active") continue;
    for (const on of dueDates(r, today)) {
      const p = periodOf(on, r.every, r.bills);
      const label = periodLabel(p, r.every, lang);
      const lines = core_default.linesOf(r.lines).map((l) => ({ ...l, description: fill(l.description, label) }));
      const t = core_default.totals({ lines, withholding_rate: r.withholding_rate });
      const next = addMonths(on, MONTHS[r.every] || 1, r.anchor_day);
      const ended = r.until_on && next > r.until_on;
      let docId;
      try {
        [docId] = await db.batch([
          { op: "insert", table: T.docs, data: { kind: "invoice", status: "Draft", client_id: r.client_id, title: fill(r.title, label), currency: r.currency, lines: JSON.stringify(lines), withholding_rate: r.withholding_rate, notes: fill(r.notes, label), origin: r.origin || null, recurring_id: r._id, period: p.start, period_label: label, subtotal: t.subtotal, tax_total: t.taxTotal, withholding: t.withholding, total: t.total, created_by: "recurring", reminders: 0 } },
          { op: "update", table: T.recurring, id: r._id, where: { next_on: on }, data: { next_on: next, last_on: on, issued_count: (Number(r.issued_count) || 0) + 1, ...ended ? { state: "ended" } : {} } }
        ]);
      } catch {
        break;
      }
      r.next_on = next;
      r.issued_count = (Number(r.issued_count) || 0) + 1;
      await db.update(T.recurring, r._id, { last_doc_id: docId });
      const made = { fee: r._id, id: docId, period: label, state: "Draft", total_text: money(t.total, r.currency) };
      if (r.mode === "issue") {
        try {
          const done = await issue(db, s, docId, `platform:recurring:${r.mode_set_by || ""}`, deps);
          made.number = done.number;
          made.state = "Issued";
          if (r.send === "yes") {
            const e = await prepareEmail(db, s, { id: docId, approved_by: r.mode_set_by || "recurring" });
            made.email = e.id;
          }
        } catch (e) {
          await db.update(T.docs, docId, { issue_note: `Not issued by itself: ${e.message}` });
          out.failed.push({ fee: r._id, id: docId, why: e.message });
        }
      }
      out.made.push(made);
      if (ended) break;
    }
  }
  return out;
}
async function feesByOrigin(db, s, origin, deps) {
  return (await listRecurring(db, s, { origin, state: void 0 }, deps)).rows.map(({ id, title, state, every, total_text, monthly_text, next_on, next_period }) => ({ id, title, state, every, total_text, monthly_text, next_on, next_period }));
}

// server/services/responses.mjs
var MIN_MS = 3e3;
function judge(r, doc, today) {
  if (String(r.hp || "").trim()) return { reject: "The hidden field was filled (a bot)" };
  if (!(Number(r.ms) >= MIN_MS)) return { reject: "Sent too fast to be a person" };
  if (!["accept", "decline"].includes(r.decision)) return { reject: "Neither accept nor decline" };
  if (!core_default.TOKEN.test(String(r.token || ""))) return { reject: "No link token" };
  if (!doc) return { reject: "The link opens no quote" };
  if (doc.status === "Accepted" && r.decision === "accept" || doc.status === "Declined" && r.decision === "decline") return { repeat: true, doc };
  if (doc.status !== "Sent") return { reject: `The quote is ${doc.status}, not waiting for an answer`, doc };
  if (doc.due_date && doc.due_date < today) return { reject: "The quote has expired", doc };
  if (r.decision === "accept") {
    if (String(r.name || "").trim().length < 2) return { reject: "Accepted without a name", doc };
    if (r.agreed !== "yes") return { reject: "Accepted without ticking the box", doc };
  }
  return { doc };
}
async function processResponses(db, s, deps) {
  const today = todayOf(s, deps);
  const out = { accepted: [], declined: [], rejected: 0, repeated: 0 };
  const news = await db.all(`SELECT * FROM ${T.responses} WHERE _deleted = 0 AND status = 'New' ORDER BY _id LIMIT 200`);
  for (const r of news) {
    const doc = core_default.TOKEN.test(String(r.token || "")) ? await db.one(`SELECT * FROM ${T.docs} WHERE _deleted = 0 AND link_token = ? AND kind = 'quote'`, [r.token]) : null;
    const v = judge(r, doc, today);
    const at = sqlTime(nowOf(deps));
    if (v.reject || v.repeat) {
      await db.update(T.responses, r._id, { status: v.repeat ? "Done" : "Rejected", reason: v.repeat ? "The same answer again" : v.reject, doc_id: v.doc ? v.doc._id : null, processed_at: at }, { status: "New" });
      if (v.repeat) out.repeated += 1;
      else out.rejected += 1;
      continue;
    }
    const accept = r.decision === "accept";
    const data = accept ? { status: "Accepted", accepted_at: at, accepted_name: clean(r.name, 120), answered_by: "client" } : { status: "Declined", declined_at: at, decline_reason: clean(r.note, 500) || null, answered_by: "client" };
    const changed = await db.update(T.docs, v.doc._id, data, { status: "Sent" });
    await db.update(T.responses, r._id, { status: changed ? "Done" : "Rejected", reason: changed ? null : "Answered meanwhile", doc_id: v.doc._id, processed_at: at }, { status: "New" });
    if (!changed) continue;
    const after = await db.one(`SELECT * FROM ${T.docs} WHERE _id = ?`, [v.doc._id]);
    await sealDoc(db, s, after);
    const fact = { id: after._id, number: after.number, client: jsonOf(after.client_snapshot, {}).name || "", total: money(after.total, after.currency), name: clean(r.name, 120), note: clean(r.note, 200) };
    (accept ? out.accepted : out.declined).push(fact);
    if (deps.announce) {
      await deps.announce(accept ? "quote_accepted" : "quote_declined", { number: fact.number, client: fact.client || fact.name || "\u2014", total: fact.total, note: fact.note || "\u2014" }, { refs: [{ type: "record", id: `invoices:document:${after._id}`, title: fact.number }], key: `answer:${after._id}` }).catch(() => null);
    }
  }
  return out;
}

// server/services/overview.mjs
var MONTH_ES = ["ene", "feb", "mar", "abr", "may", "jun", "jul", "ago", "sep", "oct", "nov", "dic"];
var monthsBack = (today, n) => {
  const [y, m] = today.split("-").map(Number);
  const out = [];
  for (let i = n - 1; i >= 0; i -= 1) {
    const t = y * 12 + (m - 1) - i;
    out.push(`${Math.floor(t / 12)}-${String(t % 12 + 1).padStart(2, "0")}`);
  }
  return out;
};
function byMonth(rows, months) {
  const at = new Map(months.map((m) => [m, { month: m, label: `${MONTH_ES[Number(m.slice(5)) - 1]} ${m.slice(2, 4)}`, invoiced: 0, collected: 0 }]));
  for (const d of rows) {
    if (d.status !== "Void" && d.issue_date && at.has(d.issue_date.slice(0, 7))) at.get(d.issue_date.slice(0, 7)).invoiced += Number(d.subtotal) || 0;
    if (d.status === "Paid" && d.paid_at && at.has(d.paid_at.slice(0, 7))) at.get(d.paid_at.slice(0, 7)).collected += Number(d.total) || 0;
  }
  return [...at.values()];
}
async function overview(db, s, deps, actor, input = {}) {
  const today = todayOf(s, deps);
  const cur = s.currency;
  const docs = await db.all(`SELECT _id, kind, status, number, title, client_snapshot, client_id, total, subtotal, issue_date, due_date, paid_at, invoice_id, recurring_id, period_label, issue_note FROM ${T.docs} WHERE ${LIVE}`);
  const inv = docs.filter((d) => d.kind === "invoice");
  const owed = inv.filter((d) => d.status === "Issued");
  const late = owed.filter((d) => d.due_date && d.due_date < today);
  const month = today.slice(0, 7);
  const collected = inv.filter((d) => d.status === "Paid" && String(d.paid_at || "").slice(0, 7) === month);
  const waitingQuotes = docs.filter((d) => d.kind === "quote" && d.status === "Sent" && !(d.due_date && d.due_date < today));
  const sum = (l, k = "total") => l.reduce((a, d) => a + (Number(d[k]) || 0), 0);
  const name = (d) => jsonOf(d.client_snapshot, {}).name || "";
  const clients = new Map((await db.all(`SELECT _id, name FROM ${T.clients} WHERE _deleted = 0`)).map((c) => [c._id, c.name]));
  const who = (d) => name(d) || clients.get(d.client_id) || "";
  const emails = await db.all(`SELECT e._id, e.purpose, e.status, e.to_email, e.error, d._id AS doc, d.number FROM ${T.emails} e JOIN ${T.docs} d ON d._id = e.doc_id WHERE e._deleted = 0 AND e.status IN ('Review', 'Approved', 'Failed') ORDER BY e._id`);
  const fees = await listRecurring(db, s, {}, deps);
  const yours = [
    ...docs.filter((d) => d.kind === "quote" && d.status === "Accepted" && !d.invoice_id).map((d) => ({ kind: "to_invoice", id: d._id, text: `${d.number} aceptado por ${who(d)}: hazle la factura` })),
    ...emails.filter((e) => e.status === "Review").map((e) => ({ kind: "email_review", id: e.doc, email: e._id, text: `${e.purpose === "reminder" ? "Recordatorio de pago" : "Correo"} de ${e.number} para ${e.to_email}: l\xE9elo y env\xEDalo` })),
    ...emails.filter((e) => e.status === "Failed").map((e) => ({ kind: "email_failed", id: e.doc, email: e._id, text: `El correo de ${e.number} no sali\xF3: ${e.error || "sin motivo"}` })),
    ...docs.filter((d) => d.status === "Draft" && d.recurring_id).map((d) => ({ kind: "fee_draft", id: d._id, text: `Factura recurrente de ${who(d)} (${d.period_label || ""}) en borrador: rev\xEDsala y em\xEDtela${d.issue_note ? ` \u2014 ${d.issue_note}` : ""}` })),
    ...docs.filter((d) => d.status === "Draft" && !d.recurring_id).map((d) => ({ kind: "draft", id: d._id, text: `${d.kind === "quote" ? "Presupuesto" : "Factura"} en borrador${who(d) ? ` para ${who(d)}` : ""}${d.title ? `: ${d.title}` : ""}` }))
  ];
  const agents = emails.filter((e) => e.status === "Approved").map((e) => ({ kind: "email_to_send", id: e.doc, email: e._id, text: `${e.number}: correo aprobado, esperando a que tu agente lo env\xEDe` }));
  const whole = wantsAll(actor, input);
  const out = {
    today,
    currency: cur,
    owed: sum(owed),
    owed_text: money(sum(owed), cur),
    owed_count: owed.length,
    late: sum(late),
    late_text: money(sum(late), cur),
    late_count: late.length,
    collected_month: sum(collected),
    collected_month_text: money(sum(collected), cur),
    quotes_waiting: waitingQuotes.length,
    quotes_waiting_text: money(sum(waitingQuotes), cur),
    monthly_fees: fees.monthly,
    monthly_fees_text: fees.monthly_text,
    fees_active: fees.active,
    next_fee: fees.rows.filter((f) => f.next_on).sort((a, b) => a.next_on.localeCompare(b.next_on))[0] || null,
    yours: whole ? yours : yours.slice(0, 8),
    for_agent: agents,
    late_list: late.sort((a, b) => a.due_date.localeCompare(b.due_date)).slice(0, whole ? 50 : 5).map((d) => ({ id: d._id, number: d.number, client: who(d), total_text: money(d.total, cur), due_date: d.due_date, days_late: core_default.daysBetween(d.due_date, today) })),
    responses_new: (await db.one(`SELECT COUNT(*) AS n FROM ${T.responses} WHERE _deleted = 0 AND status = 'New'`)).n,
    empty: !docs.length && !fees.rows.length
  };
  if (whole) out.months = byMonth(inv, monthsBack(today, 12));
  return out;
}
async function revenue(db, s, deps, { months }) {
  const today = todayOf(s, deps);
  const n = Math.max(1, Math.min(36, Number(months) || 12));
  const rows = await db.all(`SELECT status, subtotal, total, issue_date, paid_at FROM ${T.docs} WHERE ${LIVE} AND kind = 'invoice'`);
  const list = byMonth(rows, monthsBack(today, n));
  return { currency: s.currency, rows: list.map((m) => ({ month: m.month, invoiced: m.invoiced, collected: m.collected, invoiced_text: money(m.invoiced, s.currency), collected_text: money(m.collected, s.currency) })), invoiced_text: money(list.reduce((a, m) => a + m.invoiced, 0), s.currency), collected_text: money(list.reduce((a, m) => a + m.collected, 0), s.currency) };
}
function pageNeeds(s) {
  const needs = [];
  if (!String(s.company_name || "").trim() || !String(s.tax_id || "").trim()) needs.push({ id: "company", kind: "setting", title: "Los datos de tu empresa", unlocks: "Tu raz\xF3n social, NIF y direcci\xF3n salen en cada presupuesto y factura: sin ellos no se puede emitir con validez.", door: "settings", section: "empresa", places: ["resumen", "facturas", "presupuestos"] });
  if (!String(s.bank_details || "").trim()) needs.push({ id: "bank", kind: "setting", title: "C\xF3mo te pagan", unlocks: "Tu IBAN sale en cada factura, para que el cliente sepa d\xF3nde pagar.", door: "settings", section: "cobro", places: ["resumen", "facturas", "recurrentes"] });
  if (!String(s.public_url || "").trim()) needs.push({ id: "page", kind: "module", title: "La p\xE1gina que abre tu cliente", unlocks: "Sin ella no hay enlace para aceptar un presupuesto o pagar una factura: actualiza Facturas desde M\xF3dulos.", door: "keys", places: ["resumen"] });
  return { needs };
}
async function byOrigin(db, s, deps, { origin }) {
  const o = String(origin || "").trim().slice(0, 120);
  if (!o) return { documents: [], fees: [] };
  const today = todayOf(s, deps);
  const docs = await db.all(`SELECT _id, kind, status, number, title, total, currency, issue_date, due_date, paid_at, invoice_id FROM ${T.docs} WHERE ${LIVE} AND origin = ? ORDER BY _id`, [o]);
  return {
    documents: docs.map((d) => ({ id: d._id, kind: d.kind, number: d.number || null, title: d.title || "", state: stateOf(d, today), total_text: money(d.total, d.currency), issue_date: d.issue_date || null, due_date: d.due_date || null, paid_at: d.paid_at || null })),
    fees: await feesByOrigin(db, s, o, deps)
  };
}
async function alDia(db, s, deps) {
  const answers = await processResponses(db, s, deps);
  const fees = await runRecurring(db, s, deps);
  const reminders = await remindersDue(db, s, deps);
  const sealed = await sealAll(db, s);
  const parts = [];
  if (answers.accepted.length) parts.push(`Presupuestos aceptados: ${answers.accepted.map((a) => `${a.number} (${a.client}, ${a.total})`).join(", ")}.`);
  if (answers.declined.length) parts.push(`Presupuestos rechazados: ${answers.declined.map((a) => a.number).join(", ")}.`);
  const issued = fees.made.filter((m) => m.number);
  const drafts = fees.made.filter((m) => !m.number);
  if (issued.length) parts.push(`Facturas recurrentes emitidas: ${issued.map((m) => `${m.number} (${m.period}, ${m.total_text})`).join(", ")}.`);
  if (drafts.length) parts.push(`Facturas recurrentes en borrador para revisar: ${drafts.length} (${drafts.map((m) => m.period).join(", ")}).`);
  if (fees.failed.length) parts.push(`No se pudieron emitir solas: ${fees.failed.length}; est\xE1n en borrador con el motivo.`);
  if (reminders.length) parts.push(`Recordatorios de pago para revisar: ${reminders.length}.`);
  if (deps.announce && fees.made.length) await deps.announce("fees_made", { n: String(fees.made.length), what: issued.length === fees.made.length ? "emitidas" : "listas para revisar" }, { key: `fees:${todayOf(s, deps)}` }).catch(() => null);
  if (deps.announce && reminders.length) await deps.announce("reminders_ready", { n: String(reminders.length) }, { key: `reminders:${todayOf(s, deps)}` }).catch(() => null);
  return { texto: parts.length ? parts.join(" ") : "Al d\xEDa: nada nuevo en facturas.", answers: { accepted: answers.accepted.length, declined: answers.declined.length, rejected: answers.rejected }, fees: { made: fees.made.length, issued: issued.length, failed: fees.failed.length }, reminders: reminders.length, pages: sealed };
}

// server/routes/invoices.mjs
var LINES = "lines: [{ description, qty, price, tax, disc }] \u2014 price in the currency (1000 = 1.000 \u20AC), tax and disc in %; a line with no tax takes the usual rate.";
var SETTINGS = ["company_name", "tax_id", "address", "country", "email", "phone", "logo_url", "bank_details", "payment_note", "currency", "tax_rate", "withholding_rate", "payment_days", "quote_valid_days", "invoice_prefix", "quote_prefix", "number_digits", "language", "timezone", "reminders_on", "reminder_days"];
function invoices(app, db, deps = {}) {
  const s = () => settingsOf(db);
  command(
    app,
    "GET",
    "/overview",
    { name: "overview", summary: "Where the money stands: owed, late, collected this month, quotes waiting, recurring fees a month, and what waits for the person (yours) and for you (for_agent). START here. full: true adds 12 months of money.", input: { full: "true for the months" } },
    async (i, { actor }) => overview(db, await s(), deps, actor, i)
  );
  command(
    app,
    "GET",
    "/documents",
    { name: "documents", summary: "Quotes and invoices, newest first, with counts by state. kind quote|invoice; state draft|waiting|accepted|declined|withdrawn|unpaid|overdue|paid|void; client_id, recurring_id, origin or q narrow it; 20 rows (limit, offset).", input: { kind: "quote | invoice", state: "a state", client_id: "number", recurring_id: "number", origin: "text", q: "words", limit: "number", offset: "number", full: "true" } },
    async (i, { actor }) => listDocs(db, await s(), i, deps, wantsAll(actor, i))
  );
  command(
    app,
    "GET",
    "/documents/:id",
    { name: "document", summary: "One quote or invoice whole: lines, totals, client, its client link, emails, where it came from, and `can` (what may be done now).", input: { id: "number" } },
    async (i) => getDoc(db, await s(), i.id, deps)
  );
  command(
    app,
    "GET",
    "/clients",
    { name: "clients", summary: "Every client with what was billed, what is owed (late count) and its active recurring fees. q narrows by name or tax ID.", input: { q: "words" } },
    async (i) => listClients(db, await s(), i, deps)
  );
  command(
    app,
    "GET",
    "/clients/:id",
    { name: "client", summary: "One client: its details, its documents (brief) and its recurring fees.", input: { id: "number" } },
    async (i, { actor }) => {
      const st = await s();
      return { ...await getClient(db, i.id), documents: (await listDocs(db, st, { client_id: i.id }, deps, wantsAll(actor, i))).rows, fees: (await listRecurring(db, st, { client_id: i.id }, deps)).rows };
    }
  );
  command(
    app,
    "GET",
    "/recurring",
    { name: "recurring_list", summary: "The recurring fees (cuotas): client, amount per period and per month, how often, the next day and period, draft or issued by itself. Ended ones only with state ended.", input: { client_id: "number", origin: "text", state: "active | paused | ended" } },
    async (i) => listRecurring(db, await s(), i, deps)
  );
  command(
    app,
    "GET",
    "/recurring/:id",
    { name: "recurring_get", summary: "One recurring fee whole: its lines, the next three periods and the invoices it made.", input: { id: "number" } },
    async (i) => getRecurring(db, await s(), i.id, deps)
  );
  command(
    app,
    "GET",
    "/revenue",
    { name: "revenue", summary: "Money by month: invoiced (base, by issue day) and collected (by paid day), the last `months` (12).", input: { months: "number" } },
    async (i) => revenue(db, await s(), deps, i)
  );
  command(
    app,
    "GET",
    "/numbering",
    { name: "numbering", summary: "This year's next invoice and quote numbers, their prefixes and digits." },
    async () => numbering(db, await s(), deps)
  );
  command(
    app,
    "GET",
    "/settings",
    { name: "settings", summary: "The settings: the company's details on every document and how it gets paid. Also currency, IVA %, IRPF %, days to pay, prefixes, language." },
    async () => {
      const st = await s();
      return { _id: st._id, ...Object.fromEntries(SETTINGS.map((k) => [k, st[k]])) };
    }
  );
  command(
    app,
    "GET",
    "/needs",
    { name: "page_needs", summary: "What a page still needs (company details, bank details, the client page), each with what it unlocks." },
    async () => pageNeeds(await s())
  );
  command(
    app,
    "GET",
    "/by-origin",
    { name: "by_origin", summary: "For other modules: the quotes, invoices and fees made from one of their records, by origin (\xABCRM #12\xBB): number, state, total, dates.", input: { origin: "text" } },
    async (i) => byOrigin(db, await s(), deps, i)
  );
  command(
    app,
    "GET",
    "/emails/to-send",
    { name: "emails_to_send", summary: "Emails a person approved, waiting for you to send from the team's mailbox: each { email_id, to, subject, body }. Then email_sent." },
    async () => emailsToSend(db)
  );
  command(
    app,
    "GET",
    "/quotes/accepted",
    { name: "quotes_accepted", summary: "Accepted quotes that have no invoice yet: each { key, text, quote_id, number, client }. Make each one's draft with quote_to_invoice." },
    async () => ({ items: (await db.all(`SELECT _id, number, client_snapshot FROM ${T.docs} WHERE _deleted = 0 AND kind = 'quote' AND status = 'Accepted' AND invoice_id IS NULL ORDER BY _id LIMIT 50`)).map((d) => ({ key: `quote:${d._id}`, text: `${d.number} was accepted: its invoice is to be drafted`, quote_id: d._id, number: d.number, client: JSON.parse(d.client_snapshot || "{}").name || "" })) })
  );
  command(
    app,
    "POST",
    "/drafts",
    { name: "draft_save", summary: `Write a draft quote or invoice, or change one: { id?, kind (new), client_id | client, title, lines, notes, withholding_rate, due_date, origin }. ${LINES} client is a name or { name, tax_id, email, address }: an unknown one is added. origin names another module's record (\xABCRM #12\xBB). Answers { id, total }.`, input: { id: "number", kind: "quote | invoice", client_id: "number", client: "name or object", title: "text", lines: "list", notes: "text", withholding_rate: "%", due_date: "day", origin: "text", currency: "code" } },
    async (i, { actor }) => saveDraft(db, await s(), i, actor, deps)
  );
  command(
    app,
    "POST",
    "/drafts/discard",
    { name: "draft_discard", summary: "Throw away a draft (it never had a number). An issued one is voided or withdrawn instead.", input: { id: "number" } },
    async (i) => discardDraft(db, i.id)
  );
  command(
    app,
    "POST",
    "/issue",
    { name: "issue", by: "person", summary: "Issue a draft: it takes the next number, today's date and its due day, and its client page. A person's decision.", input: { id: "number" } },
    async (i, { actor }) => issue(db, await s(), i.id, actor, deps)
  );
  command(
    app,
    "POST",
    "/duplicate",
    { name: "duplicate", summary: "A new draft from any document (same client, lines, notes); kind makes a quote an invoice or the other way.", input: { id: "number", kind: "quote | invoice" } },
    async (i, { actor }) => duplicate(db, await s(), i, actor)
  );
  command(
    app,
    "POST",
    "/quotes/answer",
    { name: "quote_answer", by: "person", summary: "Record a client's answer given outside the link (email, phone): decision accept|decline, name, reason. A person's.", input: { id: "number", decision: "accept | decline", name: "text", reason: "text" } },
    async (i, { actor }) => answerQuote(db, await s(), i, actor, deps)
  );
  command(
    app,
    "POST",
    "/quotes/withdraw",
    { name: "quote_withdraw", by: "person", summary: "Withdraw a quote still waiting for an answer: it keeps its number, its page says withdrawn. A person's.", input: { id: "number", reason: "text" } },
    async (i, { actor }) => withdrawQuote(db, await s(), i, actor, deps)
  );
  command(
    app,
    "POST",
    "/quotes/invoice",
    { name: "quote_to_invoice", summary: "An accepted quote becomes an invoice draft with its lines (one per quote). Then a person issues it.", input: { id: "number" } },
    async (i, { actor }) => quoteToInvoice(db, await s(), i, actor)
  );
  command(
    app,
    "POST",
    "/invoices/void",
    { name: "invoice_void", by: "person", summary: "Void an issued, unpaid invoice with a reason: it keeps its number (no credit notes yet). A person's.", input: { id: "number", reason: "text" } },
    async (i, { actor }) => voidInvoice(db, await s(), i, actor, deps)
  );
  command(
    app,
    "POST",
    "/invoices/paid",
    { name: "invoice_paid", by: "person", summary: "Mark an invoice paid on a day (today by default), how bank|card|cash|other. A person's: ask them when the money arrived.", input: { id: "number", day: "day", how: "bank | card | cash | other" } },
    async (i, { actor }) => markPaid(db, await s(), i, actor, deps)
  );
  command(
    app,
    "POST",
    "/invoices/not-paid",
    { name: "invoice_not_paid", by: "person", summary: "A payment recorded by mistake: the invoice waits for payment again. A person's.", input: { id: "number" } },
    async (i) => notPaid(db, await s(), i)
  );
  command(
    app,
    "POST",
    "/invoices/pay-link",
    { name: "pay_link_set", summary: "The https address where the client pays an issued invoice by card (a payment link made with the company's provider); empty removes it. Its page shows \xABPagar\xBB.", input: { id: "number", url: "https address" } },
    async (i) => setPayUrl(db, await s(), i)
  );
  command(
    app,
    "POST",
    "/import",
    { name: "import_documents", summary: "Bring in past invoices or quotes as they were, keeping their numbers: items [{ kind, number, client, issue_date, due_date, title, lines | base + tax, status issued|paid|void, paid_at }]. dry_run (default true) says what would happen; the series then follow the highest number.", input: { items: "list", dry_run: "true | false" } },
    async (i, { actor }) => importDocs(db, await s(), i, actor)
  );
  command(
    app,
    "POST",
    "/numbering",
    { name: "numbering_set", by: "person", summary: "The sequence the next number of this year takes (kind invoice|quote, next 12 \u2192 DUG-2026-012); never one already used. A person's.", input: { kind: "quote | invoice", next: "number" } },
    async (i) => setNumbering(db, await s(), i, deps)
  );
  command(
    app,
    "POST",
    "/emails/prepare",
    { name: "email_prepare", summary: "Write the email that carries an issued document (purpose send) or a payment reminder (purpose reminder) to its client. It waits for a person to read and send it; it has the client link. to overrides the client's address.", input: { id: "number", to: "email", purpose: "send | reminder" } },
    async (i) => prepareEmail(db, await s(), { id: i.id, to: i.to, purpose: i.purpose === "reminder" ? "reminder" : "send" })
  );
  command(
    app,
    "POST",
    "/emails/edit",
    { name: "email_edit", summary: "Rewrite an email still waiting for review (subject, body, to); the client's link is kept in it.", input: { id: "number", subject: "text", body: "text", to: "email" } },
    async (i) => editEmail(db, await s(), i)
  );
  command(
    app,
    "POST",
    "/emails/approve",
    { name: "email_approve", by: "person", summary: "A person says send: the emails then wait for the team's agent (trigger email_por_enviar).", input: { ids: "list of email ids" } },
    async (i, { actor }) => approveEmails(db, i, actor, deps)
  );
  command(
    app,
    "POST",
    "/emails/drop",
    { name: "email_drop", summary: "Drop emails that will not be sent.", input: { ids: "list of email ids" } },
    async (i) => dropEmails(db, i)
  );
  command(
    app,
    "POST",
    "/emails/retry",
    { name: "email_retry", by: "person", summary: "Try a failed email again. A person's.", input: { id: "number" } },
    async (i, { actor }) => retryEmail(db, i, actor, deps)
  );
  command(
    app,
    "POST",
    "/emails/sent",
    { name: "email_sent", summary: "After sending approved emails from the team's mailbox, say how each went: items [{ id, ok: true }] or [{ id, ok: false, error }].", input: { items: "list" } },
    async (i, { actor }) => emailsSent(db, i, actor, deps)
  );
  command(
    app,
    "POST",
    "/clients",
    { name: "clients_save", summary: "Add or complete clients in one call: items [{ id?, name, tax_id, email, contact_name, address, country, notes, crm_company_id }]; matched by id, tax ID or name.", input: { items: "list" } },
    async (i) => ({ rows: await saveClients(db, i) })
  );
  command(
    app,
    "POST",
    "/clients/archive",
    { name: "client_archive", summary: "Archive a client with nothing open (no drafts, waiting quotes or unpaid invoices).", input: { id: "number" } },
    async (i) => archiveClient(db, i)
  );
  command(
    app,
    "POST",
    "/recurring",
    { name: "recurring_save", summary: `Add or change a recurring fee: { id?, client_id | client, title, lines, every month|quarter|year, bills advance|arrears, next_on (the day its next invoice is made), until_on, origin, notes, quote_id (copies its client and lines) }. ${LINES} {periodo} in a description or title becomes the period (\xABnoviembre 2026\xBB). Invoices are drafts for a person to issue; mode issue / send yes are a person's.`, input: { id: "number", client_id: "number", client: "name or object", title: "text", lines: "list", every: "month | quarter | year", bills: "advance | arrears", next_on: "day", until_on: "day", mode: "draft | issue", send: "yes | no", origin: "text", notes: "text", withholding_rate: "%", currency: "code", quote_id: "number" } },
    async (i, { actor }) => saveRecurring(db, await s(), i, actor, deps)
  );
  command(
    app,
    "POST",
    "/recurring/state",
    { name: "recurring_state", summary: "Pause, resume or end a recurring fee: state paused|active|ended. A paused fee makes nothing; resuming catches up from its next day.", input: { id: "number", state: "active | paused | ended" } },
    async (i) => setRecurringState(db, i)
  );
  command(
    app,
    "POST",
    "/recurring/run",
    { name: "recurring_run", summary: "Make now every recurring invoice that is due (id: only that fee's). The daily job does it by itself.", input: { id: "number" } },
    async (i) => runRecurring(db, await s(), deps, i.id ? { id: idOf(i.id) } : {})
  );
  command(
    app,
    "POST",
    "/responses/process",
    { name: "responses_process", summary: "Read the clients' answers left on their quote pages (also done daily and right after each answer)." },
    async () => processResponses(db, await s(), deps)
  );
  command(
    app,
    "POST",
    "/al-dia",
    { name: "al_dia", summary: "The daily job: clients' answers read, recurring invoices made, payment reminders written for review, client pages up to date." },
    async () => alDia(db, await s(), deps)
  );
  command(
    app,
    "POST",
    "/settings",
    { name: "set_settings", by: "admin", summary: "Change the settings (only the fields given); every client page shows the new details.", input: Object.fromEntries(SETTINGS.map((k) => [k, "value"])) },
    async (i) => {
      const st = await s();
      const data = {};
      for (const k of SETTINGS) if (i[k] !== void 0) data[k] = typeof i[k] === "string" ? clean(i[k], 600) : i[k];
      if (data.currency && !core_default.CURRENCIES.includes(String(data.currency).toUpperCase())) throw new Refused(`currency is one of ${core_default.CURRENCIES.join(", ")}.`, 400, { code: "BAD_INPUT", item: "currency" });
      if (data.number_digits !== void 0 && !(Number(data.number_digits) >= 1 && Number(data.number_digits) <= 6)) throw new Refused("number_digits is 1 to 6 (3 makes DUG-2026-012).", 400, { code: "BAD_INPUT", item: "number_digits" });
      if (st._id) await db.update(T.settings, st._id, data);
      else await db.insert(T.settings, data);
      return { updated: Object.keys(data), pages: await sealAll(db, await s()) };
    }
  );
}

// server/app.mjs
function createApp(db, deps = {}) {
  const app = new Hono2();
  mountErrors(app);
  invoices(app, db, deps);
  return app;
}

// server/db.mjs
function dataClient(url = process.env.APP_DATA_URL, token = process.env.APP_DATA_TOKEN) {
  const call = async (path, body) => {
    const r = await fetch(`${url}${path}`, { method: "POST", headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` }, body: JSON.stringify(body) });
    const j = await r.json().catch(() => null);
    if (!r.ok || !j) throw new Error(j?.error ?? `Data ${r.status}`);
    return j;
  };
  return {
    all: async (sql, params = []) => (await call("/all", { sql, params })).rows,
    one: async (sql, params = []) => (await call("/all", { sql, params })).rows[0] ?? null,
    insert: async (table, data) => (await call("/batch", { ops: [{ op: "insert", table, data }] })).ids[0],
    update: async (table, id, data, where = {}) => (await call("/update", { table, id, data, where })).changed,
    batch: async (ops) => (await call("/batch", { ops })).ids,
    // Which of the modules app.json `suggests` are installed for the company: [{ module, installed, name, version, for, unlocks }].
    // Read when asked, never kept; nothing of the other module is reachable (the guide: «Modules unlock each other»).
    peers: async () => (await call("/peers", {})).peers,
    // One read command another module EXPORTS and app.json `reads` declares: { installed: false } when that module is
    // not installed, else { installed: true, result }. Never its tables, never a write (the guide: «Reading another module»).
    read: async (module, command2, params = {}) => call("/read", { module, command: command2, params })
  };
}

// server/announce.mjs
function announceClient(url = process.env.APP_DATA_URL, token = process.env.APP_DATA_TOKEN) {
  return {
    announce: async (id, facts = {}, { to = "spaces", refs, key } = {}) => {
      const r = await globalThis.fetch(`${url}/announce`, { method: "POST", headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` }, body: JSON.stringify({ id, facts, to, ...refs ? { refs } : {}, ...key != null ? { key: String(key) } : {} }) });
      const j = await r.json().catch(() => null);
      if (!r.ok || !j) throw new Error(j ? [j.error, j.how].filter(Boolean).join(" ") : `Announce ${r.status}`);
      return j;
    }
  };
}

// server/main.mjs
var { announce } = announceClient();
serve({ fetch: createApp(dataClient(), { announce }).fetch, hostname: "127.0.0.1", port: Number(process.env.PORT) });
