// What every document carries (your company, how you get paid, numbering and
// defaults, the language your clients read) and where you hear about answers
// are managed in Orchestra (Apps → Invoices → Ajustes and Conexiones): typed,
// next to who drafts quotes and reminders. Here, what they are now and a way
// there. Saving there rewrites the clients' pages of documents already sent,
// never a document's number, lines or totals.
import { C, head, settings, when } from '../data.js';

const { el, fmt } = Orch;

export function render() {
  Orch.load('view', async () => {
    const s = await settings(true);
    if (!s._id) return el('p', { class: 'oc-state' }, 'Invoices is not installed here.');
    return el('div', { class: 'oc-stack oc-stack--loose' }, [head('Settings', 'What every quote and invoice carries, and how they get to your clients. Managed in Orchestra.'), managed(s), fiscal()]);
  });
}

function managed(s) {
  const link = el('a', { class: 'oc-btn oc-btn--primary', target: '_blank', rel: 'noopener', hidden: true }, 'Open the settings in Orchestra');
  const where = el('p', { class: 'oc-help' }, 'In Orchestra: Apps → Invoices → Ajustes.');
  if (Orch.manageUrl) Orch.manageUrl('settings').then((url) => { if (url) { link.href = url; link.hidden = false; where.hidden = true; } });
  const year = new Date().getFullYear();
  const stripe = s.stripe_on !== 'yes' ? 'off'
    : s.stripe_status === 'ok' ? `on (Stripe answered ${s.stripe_checked_at ? fmt.ago(when(s.stripe_checked_at).toISOString()) : ''})`
      : s.stripe_note ? `on, but: ${s.stripe_note}` : 'on (not checked yet: it is checked the first time an invoice is issued)';
  const facts = [
    ['Company', s.company_name || '— (not set yet)'],
    ['Bank details', s.bank_details ? 'set' : '— (not set yet)'],
    ['Card payments with Stripe', stripe],
    ['Currency and tax', `${s.currency || 'EUR'} · ${s.tax_rate ?? 21}%${Number(s.withholding_rate) ? ` · withholding ${s.withholding_rate}%` : ''}`],
    ['Next numbers', `${C.numberOf(s.invoice_prefix ?? '', year, 1).replace(/0001$/, '…')} · ${C.numberOf(s.quote_prefix ?? 'Q-', year, 1).replace(/0001$/, '…')}`],
    ['Your clients read', s.language === 'es' ? 'Español' : 'English'],
    ['Payment reminders', s.reminders_on === 'no' ? 'off' : `on, every ${s.reminder_days || 7} days, waiting for your OK`],
    ['Telegram notices', s.notify_telegram ? 'on' : 'off'],
  ];
  return el('section', { class: 'oc-card oc-stack' }, [
    el('h2', { class: 'oc-h2' }, 'Managed in Orchestra'),
    el('p', { class: 'oc-help' }, 'Your company, how you get paid, numbering, the language your clients read and notices are set in Orchestra, next to the Gmail and Stripe connections and the agent that drafts quotes and reminders.'),
    el('ul', { class: 'oc-stack' }, facts.map(([k, v]) => el('li', [el('b', `${k}: `), v]))),
    el('div', { class: 'oc-row' }, [link]), where,
  ]);
}

const fiscal = () => el('section', { class: 'oc-card oc-stack iv-fiscal' }, [
  el('h2', { class: 'oc-h2' }, 'Not certified fiscal software'),
  el('p', 'Invoices numbers your documents without gaps and never changes one once issued, but it is not certified invoicing software: it does not send anything to a tax authority (no Verifactu, SII, TicketBAI or e-invoicing). If your country requires that, keep using certified software for it, or ask your accountant.'),
]);
