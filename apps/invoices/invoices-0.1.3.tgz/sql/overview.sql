SELECT currency,
       SUM(CASE WHEN kind = 'invoice' AND status = 'Issued' THEN total ELSE 0 END) AS outstanding,
       SUM(CASE WHEN kind = 'invoice' AND status = 'Issued' THEN 1 ELSE 0 END) AS outstanding_n,
       SUM(CASE WHEN kind = 'invoice' AND status = 'Issued' AND due_date < date('now') THEN total ELSE 0 END) AS overdue,
       SUM(CASE WHEN kind = 'invoice' AND status = 'Issued' AND due_date < date('now') THEN 1 ELSE 0 END) AS overdue_n,
       SUM(CASE WHEN kind = 'invoice' AND status = 'Paid' AND paid_at >= date('now', 'start of month') THEN total ELSE 0 END) AS paid_month,
       SUM(CASE WHEN kind = 'invoice' AND status = 'Paid' AND paid_at >= date('now', 'start of month') THEN 1 ELSE 0 END) AS paid_month_n,
       SUM(CASE WHEN kind = 'quote' AND status = 'Sent' AND due_date >= date('now') THEN total ELSE 0 END) AS quotes_open,
       SUM(CASE WHEN kind = 'quote' AND status = 'Sent' AND due_date >= date('now') THEN 1 ELSE 0 END) AS quotes_open_n
FROM inv_documents
WHERE status NOT IN ('Draft', 'Discarded')
GROUP BY currency
