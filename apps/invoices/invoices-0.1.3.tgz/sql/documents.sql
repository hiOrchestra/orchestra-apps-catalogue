SELECT d._id, d.kind, d.status, d.number, d.title, d.currency, d.total, d.issue_date, d.due_date, d.paid_at, d.client_id,
       d.issue_asked_at, d.issue_note, d.ai_status, d.reminders, d.sent_at, d._created_at, d.seq, d.series_year,
       COALESCE(NULLIF(json_extract(d.client_snapshot, '$.name'), ''), c.name, '') AS client_name,
       CASE
         WHEN d.status = 'Issued' AND d.due_date < date('now') THEN 'Overdue'
         WHEN d.status = 'Sent' AND d.due_date < date('now') THEN 'Expired'
         ELSE d.status
       END AS state,
       CASE WHEN d.status = 'Draft' THEN '0' ELSE '1' END AS issued
FROM inv_documents d
LEFT JOIN inv_clients c ON c._id = d.client_id
WHERE d.status <> 'Discarded'
