---
name: app-invoices
version: 0.1.3
description: >-
  Work in the Invoices app: quotes and invoices, clients, the client's page
  with its link, payments and payment reminders. Load it when someone says
  "who owes me money / quién me debe", "what is overdue / qué está vencido",
  "make a quote for … / hazme un presupuesto", "invoice this client /
  factúrale a …", "they paid / ya pagó, márcala cobrada", "send a reminder /
  manda un recordatorio", "issue and send it / emítela y mándala", "add a
  client / alta de cliente", "the quote was accepted / aceptaron el
  presupuesto", "void the invoice / anula la factura". Needs the Invoices app
  installed in a project you work in.
metadata:
  openclaw:
    emoji: "🧾"
---
# Invoices — quotes, invoices, and what is owed

Quotes and invoices for a small company: a draft gets its number when issued,
the client opens it from a link (accepts a quote, pays an invoice), and the
agent drafts payment reminders that wait for a person's OK. Not certified
fiscal software: it submits nothing to a tax authority.

```bash
ls -d ~/.openclaw/orchestra/projects/*/apps/invoices   # the directory name under projects/ is the project id
P=<project>; cat ~/.openclaw/orchestra/projects/$P/apps/invoices/workflows.json   # ids: docs, send, respond, draft, remind, stripe
orch-canvas url invoices                               # the desk, for the person
```

If nothing is listed, Invoices is not installed in a project you work in: say
so, and do not keep quotes or invoices some other way. Every `orch-database`
command takes `--project $P`; always filter `_deleted = 0`.

## The model (tables `inv_*`)

| Table | One row per | Notes |
|---|---|---|
| `inv_settings` | one row | company, `bank_details`, `stripe_on`, `currency`, `tax_rate`, `payment_days`, `quote_valid_days`, prefixes, `language` (en/es: the client's page and emails), `timezone`, `agent`, `reminders_on`, `reminder_days`, `public_url`, `crm_available` |
| `inv_clients` | client | `name`, `tax_id`, `email`, `contact_name`, `address`, `country`, `notes`, `crm_company_id`, `archived` yes/no |
| `inv_documents` | quote or invoice | `kind` quote/invoice, `status`, `number`, `client_id` + `client_snapshot` (frozen on issue), `lines` (JSON), totals, dates, `link_token`, payment, void, answer, `quote_id`/`invoice_id`, `ai_status` |
| `inv_emails` | email | `purpose` send/reminder, `to_email`, `subject`, `body`, `status` |
| `inv_series`, `inv_links`, `inv_responses` | numbering, the sealed client pages, answers from the page | scripts only: never write them |

Money is an integer in minor units (EUR 450000 = 4.500,00 €; JPY none, KWD
three decimals). Lines: `{"description","qty","price","tax","disc"}`, `price`
in minor units, `tax`/`disc` in percent.

Statuses (set only as below):
- Quote: `Draft` → `Sent` (set on issue, emailed or not; `sent_at` = emailed)
  → `Accepted` / `Declined` (the client's page, or a person recording it).
  Expired = Sent and past `due_date`, derived. A Sent quote cannot be voided.
- Invoice: `Draft` → `Issued` → `Paid` (a person, or Stripe by itself) or
  `Void` (terminal). Paid can go back to Issued ("Not paid after all").
  Overdue = Issued and past `due_date`; derived.
- `Discarded`: a deleted draft (it never had a number).
- An issued document is never edited: no action changes its lines, client or
  totals. To change one, void it and issue a new one (credit notes do not exist).
- Numbering: a draft has none. On issue the `docs` workflow gives the next of
  its kind and year (`Q-2026-0007`, `2026-0007`; prefixes in Settings), no
  gaps, never twice; sets today as issue day, the due day, freezes the client,
  recomputes the totals, makes the link token. A voided number stays used.
- Emails: `Review` (waiting for a person) → `Approved` → `Sending` → `Sent`;
  `Failed`, `Dropped`. Only Approved emails go out, from the connected Gmail.

## How you act

- The app's work is done by its workflows; you start them with
  `orch-workflows run <id> --args '{"mode":"--now"}'` (id from `workflows.json`)
  and check with `orch-workflows runs --limit 5` / `orch-workflows status <run>`.
  `docs` must run after every status change you write: it numbers, switches
  Stripe links off and rewrites the client's page.
- Where you must write a row, use `orch-database batch` with a `when` that
  repeats the app's own precondition, and set exactly the fields below. The
  batch fails if the row moved on; read it again, do not force it.
- `number`, `seq`, `series_year`, `issue_date`, `client_snapshot`, `link_token`
  and the totals of an issued document belong to the scripts.
- An email is Approved only after the person said "send it" having seen to
  whom and what. Void needs a confirmation that names what goes with it.
- A document's link: `<public_url>#/<link_token>` (`public_url` in `inv_settings`).

Below, `NOW=$(date -u +%FT%TZ)` and `WHO` is your agent id.

## Recipes

**Who owes me / what is overdue.**
```bash
orch-database --project $P query "SELECT _id, number, json_extract(client_snapshot,'\$.name') AS client, total, currency, due_date, reminders FROM inv_documents WHERE _deleted = 0 AND kind = 'invoice' AND status = 'Issued' ORDER BY due_date"
```
Overdue: `due_date` before today. Totals per currency. Quotes waiting: `kind = 'quote' AND status = 'Sent'`.

**Draft a quote from a description.** Find the client's `_id` in `inv_clients`,
read `currency` and `quote_valid_days` from `inv_settings`, then insert the
draft as the desk's "Draft with the agent" does, and start `draft`:
```bash
orch-database --project $P insert inv_documents --data '{"kind":"quote","status":"Draft","ai_status":"Waiting","ai_prompt":"<their words, with prices if given>","client_id":12,"currency":"EUR","due_date":"<today + quote_valid_days>","withholding_rate":0,"lines":"[]","created_by":"<WHO>"}'
orch-workflows run <draft> --args '{"mode":"--auto"}'
```
Then read the row: `ai_status` Done or Failed (`ai_note`). It stays a draft for the person to review.

**Issue (and send) a document.** Only a draft the person reviewed, with their
OK to issue. It must have a client, lines with descriptions and a quantity,
and a total above zero.
```bash
orch-database --project $P batch --ops '[{"op":"update","table":"inv_documents","id":42,"when":{"status":"Draft"},"data":{"issue_asked_at":"'$NOW'","issued_by":"<WHO>","issue_note":null}}]'
orch-workflows run <docs> --args '{"mode":"--now"}'
```
Read it back: a `number` and status Sent/Issued, or `issue_note` "Not issued: …"
and still Draft. To email it: write subject and body in the Settings
`language`, naming the number, total and due day, with the link in the body;
show them to the person. Only on their "send it":
```bash
orch-database --project $P insert inv_emails --data '{"doc_id":42,"purpose":"send","n":0,"to_email":"<client email>","subject":"…","body":"…","status":"Approved","drafted_by":"<WHO>","approved_by":"<person>","approved_at":"'$NOW'"}'
orch-workflows run <send> --args '{"mode":"--now"}'
```
Without that OK, insert it with `"status":"Review"` and no `approved_*`: it
waits under "Waiting for you" in the desk.

**Mark an invoice paid.** Ask the day if they did not say it (default today).
```bash
orch-database --project $P batch --ops '[{"op":"update","table":"inv_documents","id":42,"when":{"status":"Issued","kind":"invoice"},"data":{"status":"Paid","paid_at":"2026-10-04","paid_how":"bank","paid_by":"<WHO>"}}]'
orch-workflows run <docs> --args '{"mode":"--now"}'
```

**Send a payment reminder.** Run `remind` (`--args '{"mode":"--auto"}'`). With
reminders on, each overdue invoice with a client email, under 3 reminders and
none in the last `reminder_days` gets one drafted in `Review`. Show it; on
"send it", batch-update it `when {"status":"Review"}` to `"status":"Approved"`
plus `approved_by`/`approved_at`, then run `send`. Or they approve it in the desk.

**The quote was accepted.** The client's page does it by itself. Told by
phone: update `when {"status":"Sent","kind":"quote"}` to `"status":"Accepted",
"accepted_at":NOW,"accepted_name":"<who>","answered_by":"<WHO>"` (or
`Declined`, `declined_at`, `decline_reason`), then run `docs`. Make the
invoice from it, in one batch (as the desk's "Make the invoice"):
```bash
orch-database --project $P batch --ops '[{"op":"insert","table":"inv_documents","as":"inv","data":{"kind":"invoice","status":"Draft","quote_id":7,"client_id":12,"title":"…","currency":"EUR","lines":"<the quote lines, as they are>","withholding_rate":0,"notes":"…","subtotal":<q>,"tax_total":<q>,"withholding":<q>,"total":<q>,"due_date":"<today + payment_days>","created_by":"<WHO>"}},{"op":"update","table":"inv_documents","id":7,"when":{"status":"Accepted","invoice_id":null},"data":{"invoice_id":"$inv._id"}}]'
```
Copy subtotal, tax_total, withholding and total from the quote. It is a draft
invoice: issuing it is the recipe above.

**Add a client.**
`orch-database --project $P insert inv_clients --data '{"name":"Acme SL","tax_id":"…","email":"…","contact_name":"…","address":"…","country":"ES","notes":"","archived":"no"}'`
Check first that it is not there. Editing a client never changes issued documents.

**Void an invoice.** Only `Issued` invoices. Say first: it cannot be undone,
the number stays used and is never given again, the client's page will say
void, and its Stripe link (if any) is switched off; to bill again, a new
invoice. Ask for the reason. Then, on a second clear yes:
```bash
orch-database --project $P batch --ops '[{"op":"update","table":"inv_documents","id":42,"when":{"status":"Issued"},"data":{"status":"Void","void_at":"'$NOW'","void_reason":"<why>","voided_by":"<WHO>"}}]'
orch-workflows run <docs> --args '{"mode":"--now"}'
```

## Other apps

- CRM: with it in the project, the desk's "From CRM" fills a new client from
  `crm_companies` and its first `crm_contacts` row with an email, keeping
  `crm_company_id`. You can do the same with the insert above.
- A won CRM deal creates no quote or invoice: today by hand. No other app
  reads or writes Invoices.

## Never

- Edit an issued document, or delete one: void it (invoices) instead.
- Write `inv_series`, `inv_links` or `inv_responses`, or set a `number`.
- Approve or send an email, issue, void or discard without the person's OK in this conversation.
- Change Settings (bank details, Stripe, prefixes): the person does it in the desk.
- Turn Stripe on, or tell a client an invoice is paid before it is `Paid`.
