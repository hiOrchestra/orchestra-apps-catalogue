// What the desk reads, the only things it writes, and what the screens share.
// Numbers are given on the instance (automations/docs.js), never here: Issue
// only asks. Every write is a declared action (A). invcore.js holds the
// rules the scripts and the client's page share (money, totals, numbering).
import './invcore.js';

export const C = self.InvCore;
const { el, router } = Orch;

export const T = { settings: 'inv_settings', clients: 'inv_clients', docs: 'inv_documents', emails: 'inv_emails', crmCompanies: 'crm_companies', crmContacts: 'crm_contacts' };
export const V = { docs: 'documents', overview: 'overview', clients: 'clients_list' };
export const A = {
  create: 'create_document', createAgent: 'create_with_agent', draftAgain: 'draft_again', save: 'save_draft', issue: 'issue_document', discard: 'discard_draft',
  paid: 'mark_paid', unpaid: 'mark_unpaid', void: 'void_invoice', accepted: 'mark_accepted', declined: 'mark_declined', makeInvoice: 'make_invoice',
  retryStripe: 'retry_stripe', writeEmail: 'write_email', approve: 'approve_email', saveEmail: 'save_email', dropEmail: 'drop_email',
  retryEmail: 'retry_email', wasSent: 'email_was_sent', dropFailed: 'drop_failed', sendNow: 'send_now', linksNow: 'links_now', stripeNow: 'stripe_now',
  createClient: 'create_client', updateClient: 'update_client', archiveClient: 'archive_client', restoreClient: 'restore_client', settings: 'update_settings',
};

/** Where Gmail and Stripe are connected: the portal's Integrations, in the top window. */
// The app is served from the instance, not the portal, so a relative link would
// 404. The portal is where the person came from (the referrer); otherwise Orchestra's address.
const PORTAL_ORIGIN = (() => {
  try {
    const o = document.referrer ? new URL(document.referrer).origin : '';
    if (/^https:\/\/([a-z0-9-]+\.)*(hiorchestra\.com|orchestra-portal[a-z0-9-]*\.up\.railway\.app)$/.test(o)) return o;
  } catch { /* no referrer */ }
  return 'https://hiorchestra.com';
})();
export const INTEGRATIONS = `${PORTAL_ORIGIN}/portal/integrations`;
export const integrations = (text) => el('a', { href: INTEGRATIONS, target: '_top', rel: 'noopener' }, text);

/** Run a declared action, say how it went, and hand back its result (null on failure). */
export async function act(name, params, done) {
  try {
    const r = await Orch.action(name, params);
    if (done) Orch.toast(done);
    return r || {};
  } catch (e) {
    Orch.toast(e.status === 409 ? 'It changed in the meantime: look again.' : (e.message || 'That did not work.'), { error: true });
    return null;
  }
}

let cached = null;
/** The one settings row (kept for the page's life unless asked fresh). */
export async function settings(fresh) {
  if (!cached || fresh) cached = (await Orch.db.list(T.settings, { sort: '_id:asc', limit: 1 })).rows[0] || {};
  return cached;
}

export const today = (s) => C.today((s && s.timezone) || undefined);
/** An amount as a person reads it, in their browser's way of writing numbers. */
export const money = (n, cur) => C.money(n, cur || 'EUR');
export const parse = (text, fallback) => { if (!text) return fallback; if (typeof text === 'object') return text; try { return JSON.parse(text); } catch { return fallback; } };

/** '2026-10-03 10:00:00' (UTC, as rows are stamped) or ISO, as a Date. */
export function when(v) {
  if (!v) return null;
  const s = String(v).trim();
  const d = new Date(/[zZ]|[+-]\d\d:?\d\d$/.test(s) ? s : `${s.replace(' ', 'T')}Z`);
  return Number.isNaN(d.getTime()) ? null : d;
}
/** "3 Oct 2026" for a day 'YYYY-MM-DD'. */
export function day(v) {
  const d = C.realDay(v);
  return d ? new Intl.DateTimeFormat(undefined, { day: 'numeric', month: 'short', year: 'numeric', timeZone: 'UTC' }).format(new Date(`${d}T00:00:00Z`)) : '—';
}
export const kindWord = (kind, cap) => (kind === 'quote' ? (cap ? 'Quote' : 'quote') : (cap ? 'Invoice' : 'invoice'));

const TONE = { Paid: 'good', Accepted: 'good', Overdue: 'bad', Void: 'bad', Declined: 'bad', Expired: 'warn', Issued: 'accent', Sent: 'accent', Draft: '' };
const SAID = { Issued: 'Issued', Sent: 'Sent' };
export const badge = (state) => el('span', { class: `oc-badge${TONE[state] ? ` oc-badge--${TONE[state]}` : ''}` }, SAID[state] || state || '—');

/** The client's link for a document out of draft. */
export function linkOf(d, s) {
  if (!d || !d.link_token) return '';
  const own = `${location.origin}${location.pathname.replace(/\/canvas\/a\/[^/]+\/?.*$/, '/canvas/a/invoice/')}`;
  return `${(s && s.public_url) || own}#/${d.link_token}`;
}

export async function copy(text, said) {
  try { await navigator.clipboard.writeText(text); Orch.toast(said || 'Copied.'); } catch { Orch.toast('Select the link and copy it.', { error: true }); }
}

/** A dialog that closes when the screen changes: a link inside it must not leave it over the next screen. */
export function sheet(content, opts) {
  const d = Orch.dialog(content, opts);
  window.addEventListener('hashchange', () => { try { d.close(); } catch { /* already closed */ } }, { once: true });
  return d;
}

/** A screen's head: its title, a sentence, and tools on the right. */
export const head = (title, lede, tools) => el('header', { class: 'iv-head' }, [
  el('div', { class: 'iv-head__title' }, [el('h1', { class: 'oc-h1 oc-h1--collection' }, title), lede ? el('p', { class: 'oc-lede' }, lede) : null]),
  tools ? el('div', { class: 'iv-head__tools' }, tools) : null,
]);

export const input = (value, attrs) => el('input', Object.assign({ class: 'oc-input', value: value == null ? '' : String(value) }, attrs || {}));
export const area = (value, rows, attrs) => el('textarea', Object.assign({ class: 'oc-textarea', rows: String(rows || 3) }, attrs || {}), value == null ? '' : String(value));
export const field = (label, control, help) => el('label', { class: 'oc-field' }, [el('span', { class: 'oc-label' }, label), control, help ? el('span', { class: 'oc-help' }, help) : null]);
export const select = (value, options) => el('select', { class: 'oc-select' }, options.map(([v, label]) => el('option', { value: v, selected: String(v) === String(value) }, label)));

/** A new document: the client's currency and the usual dates; it opens on its own page. */
export async function newDoc(kind, extra) {
  const s = await settings();
  const t = today(s);
  const days = kind === 'quote' ? Number(s.quote_valid_days) || 30 : Number(s.payment_days) || 30;
  const params = Object.assign({ kind, currency: s.currency || 'EUR', due_date: C.addDays(t, days), withholding_rate: Number(s.withholding_rate) || 0,
    lines: JSON.stringify([{ description: '', qty: 1, price: 0, tax: Number(s.tax_rate) || 0, disc: 0 }]) }, extra || {});
  const r = await act(extra && extra.ai_prompt ? A.createAgent : A.create, params);
  if (r && r._id) router.go(`/doc/${r._id}`);
  return r;
}

/** A row that opens something: a mono first column, the name, a sub-line, and figures on the right. */
export function row({ to, onClick, first, name, sub, right, extra }) {
  const inner = [el('span', { class: 'iv-row__first oc-value' }, first || ''), el('span', { class: 'iv-row__name' }, [el('span', name || '—'), sub ? el('span', { class: 'iv-row__sub' }, sub) : null]),
    el('span', { class: 'iv-row__right' }, right || '')];
  return el('li', { class: 'iv-row' }, [
    to ? router.link(to, inner, { class: 'iv-row__open' }) : el('button', { type: 'button', class: 'iv-row__open', onClick }, inner),
    extra || null,
  ]);
}
