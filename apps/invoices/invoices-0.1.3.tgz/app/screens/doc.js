// One document, on its own page. A draft is its editor; once issued it is
// the paper exactly as the client sees it, with what you can do beside it
// (its link, the email, payment, void). While the instance is numbering it
// (Issue was pressed) or the agent is writing its lines, the page waits and
// looks again by itself.
import { C, T, badge, kindWord, parse, settings, today } from '../data.js';
import { editor } from './editor.js';
import { issued } from './issued.js';

const { el, router } = Orch;
let timer = null;

/** Look again every few seconds, quietly, and redraw only once the instance moved it on. */
function watch(d, again) {
  const sig = (x) => [x && x.status, x && x.issue_asked_at, x && x.ai_status].join('|');
  const was = sig(d);
  let tries = 0;
  const tick = async () => {
    if (!location.hash.startsWith(`#/doc/${d._id}`)) return;
    tries += 1;
    const now = await Orch.db.get(T.docs, d._id).catch(() => null);
    if (now && sig(now) !== was) again();
    else if (tries < 120) timer = setTimeout(tick, tries < 20 ? 2000 : 6000);
  };
  timer = setTimeout(tick, 2000);
}

export function render({ id }) {
  clearTimeout(timer);
  const again = () => render({ id });
  Orch.load('view', async () => {
    const [d, s] = await Promise.all([Orch.db.get(T.docs, Number(id)), settings(true)]);
    if (!d || d.status === 'Discarded') {
      return el('div', { class: 'oc-card oc-state' }, [el('p', { class: 'oc-state__title' }, 'This document is not here.'), el('p', { class: 'oc-help' }, 'It may have been a draft that was deleted.'), router.link('/invoices', 'Go to Invoices', { class: 'oc-btn' })]);
    }
    const client = d.client_id ? await Orch.db.get(T.clients, d.client_id) : null;
    const state = C.stateOf(d, today(s));
    const waiting = (d.status === 'Draft' && d.issue_asked_at) || ['Waiting', 'Working'].includes(d.ai_status);
    if (waiting) watch(d, again);
    const back = d.kind === 'quote' ? ['/quotes', 'Quotes'] : ['/invoices', 'Invoices'];
    const title = d.number || `New ${kindWord(d.kind)}`;
    const frozen = parse(d.client_snapshot, null);
    const who = (frozen && frozen.name) || (client && client.name) || 'No client yet';
    return el('div', { class: 'oc-stack oc-stack--loose iv-doc' }, [
      el('header', { class: 'iv-dochead' }, [
        router.link(back[0], `← ${back[1]}`, { class: 'iv-back' }),
        el('div', { class: 'iv-dochead__line' }, [
          el('div', { class: 'iv-dochead__name' }, [el('h1', { class: 'oc-h1 iv-doctitle' }, title), el('p', { class: 'oc-lede' }, d.number ? [kindWord(d.kind, true), ' for ', who] : (client ? `Draft for ${who}: it gets its number when you issue it` : 'Draft: it gets its number when you issue it'))]),
          badge(d.status === 'Draft' && d.issue_asked_at ? 'Issuing…' : state),
        ]),
      ]),
      d.status === 'Draft' ? await editor(d, s, client, again, waiting) : await issued(d, s, again),
    ]);
  });
}
