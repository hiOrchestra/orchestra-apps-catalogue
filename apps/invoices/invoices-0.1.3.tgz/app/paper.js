// The document as the client sees it: one sheet, in the client's language,
// drawn from a snapshot (invcore.snapshot). The desk shows the very same
// sheet (its preview, and an issued document's page), so what the owner
// looks at is what the client gets. Prints on A4 (styles: .pp-*).
// test/sync.js copies this file to app/ and public/.
import './invcore.js';

const C = self.InvCore;
const { el } = Orch;

export const WORDS = {
  en: {
    invoice: 'Invoice', quote: 'Quote', issued: 'Date', due: 'Due', valid: 'Valid until', to: 'Bill to', taxId: 'Tax ID',
    desc: 'Description', qty: 'Qty', price: 'Price', tax: 'Tax', amount: 'Amount', off: 'off',
    subtotal: 'Subtotal', taxOn: (r) => `Tax ${r}%`, withholding: (r) => `Withholding ${r}%`, total: 'Total',
    notes: 'Notes', pay: 'How to pay', draft: 'Draft', ref: 'Reference',
    Paid: 'Paid', Void: 'Void', Accepted: 'Accepted', Declined: 'Declined', Expired: 'Expired', Overdue: 'Overdue', Draft: 'Draft',
  },
  es: {
    invoice: 'Factura', quote: 'Presupuesto', issued: 'Fecha', due: 'Vencimiento', valid: 'Válido hasta', to: 'Cliente', taxId: 'NIF',
    desc: 'Concepto', qty: 'Cant.', price: 'Precio', tax: 'IVA', amount: 'Importe', off: 'dto.',
    subtotal: 'Base imponible', taxOn: (r) => `IVA ${r}%`, withholding: (r) => `Retención ${r}%`, total: 'Total',
    notes: 'Notas', pay: 'Forma de pago', draft: 'Borrador', ref: 'Referencia',
    Paid: 'Pagada', Void: 'Anulada', Accepted: 'Aceptado', Declined: 'Rechazado', Expired: 'Caducado', Overdue: 'Vencida', Draft: 'Borrador',
  },
};

const lines = (text) => String(text || '').split('\n').map((x) => x.trim()).filter(Boolean);
const num = (n, lang) => new Intl.NumberFormat(C.localeOf(lang), { maximumFractionDigits: 3 }).format(n);

/** The state the stamp shows, or null for a document simply waiting (Issued, Sent). */
export function stampOf(snap, today) {
  if (snap.void_at || snap.status === 'Void') return 'Void';
  if (snap.status === 'Paid') return 'Paid';
  if (snap.status === 'Accepted') return 'Accepted';
  if (snap.status === 'Declined') return 'Declined';
  if (snap.status === 'Draft') return 'Draft';
  if (snap.due_date && today && snap.due_date < today) return snap.kind === 'quote' ? 'Expired' : 'Overdue';
  return null;
}

/** The sheet. opts.today (YYYY-MM-DD) decides Overdue/Expired; opts.payment false leaves the bank details out. */
export function paper(snap, opts = {}) {
  const lang = snap.lang === 'es' ? 'es' : 'en';
  const w = WORDS[lang];
  const loc = C.localeOf(lang);
  const m = (n) => C.money(n, snap.currency, loc);
  const co = snap.company || {};
  const cl = snap.client || {};
  const stamp = stampOf(snap, opts.today);
  const t = snap.totals || {};
  const quote = snap.kind === 'quote';
  const anyDisc = (snap.lines || []).some((l) => l.x);
  return el('article', { class: `pp pp--${snap.kind}${stamp ? ` pp--${stamp.toLowerCase()}` : ''}`, 'aria-label': `${quote ? w.quote : w.invoice} ${snap.number || w.draft}` }, [
    el('header', { class: 'pp-head' }, [
      el('div', { class: 'pp-from' }, [
        co.logo_url && /^https:\/\//.test(co.logo_url) ? el('img', { class: 'pp-logo', src: co.logo_url, alt: '' }) : null,
        el('p', { class: 'pp-company' }, co.company_name || '—'),
        el('p', { class: 'pp-lines' }, [co.tax_id ? `${w.taxId} ${co.tax_id}` : null, ...lines(co.address), co.country, co.email, co.phone].filter(Boolean).map((x) => el('span', x))),
      ]),
      el('div', { class: 'pp-what' }, [
        el('p', { class: 'pp-kind' }, quote ? w.quote : w.invoice),
        el('p', { class: 'pp-number' }, snap.number || w.draft),
        el('dl', { class: 'pp-dates' }, [
          snap.issue_date ? el('div', [el('dt', w.issued), el('dd', C.longDay(snap.issue_date, lang))]) : null,
          snap.due_date ? el('div', [el('dt', quote ? w.valid : w.due), el('dd', C.longDay(snap.due_date, lang))]) : null,
        ]),
        stamp ? el('p', { class: `pp-stamp pp-stamp--${stamp.toLowerCase()}` }, w[stamp]) : null,
      ]),
    ]),
    el('section', { class: 'pp-to' }, [
      el('p', { class: 'pp-label' }, w.to),
      el('p', { class: 'pp-client' }, cl.name || '—'),
      el('p', { class: 'pp-lines' }, [cl.tax_id ? `${w.taxId} ${cl.tax_id}` : null, ...lines(cl.address), cl.country, cl.email].filter(Boolean).map((x) => el('span', x))),
    ]),
    // The reference, unless it only repeats the one line.
    snap.title && !((snap.lines || []).length === 1 && snap.lines[0].d.trim() === snap.title.trim()) ? el('p', { class: 'pp-title' }, [el('span', { class: 'pp-label' }, w.ref), ' ', snap.title]) : null,
    el('table', { class: 'pp-table' }, [
      el('thead', el('tr', [el('th', { scope: 'col' }, w.desc), el('th', { scope: 'col', class: 'pp-n' }, w.qty), el('th', { scope: 'col', class: 'pp-n' }, w.price),
        el('th', { scope: 'col', class: 'pp-n pp-tax' }, w.tax), el('th', { scope: 'col', class: 'pp-n' }, w.amount)])),
      el('tbody', (snap.lines || []).map((l) => el('tr', [
        el('td', { class: 'pp-desc' }, [el('span', l.d), anyDisc && l.x ? el('span', { class: 'pp-off' }, `−${num(l.x, lang)}% ${w.off}`) : null]),
        el('td', { class: 'pp-n' }, num(l.q, lang)),
        el('td', { class: 'pp-n' }, m(l.p)),
        el('td', { class: 'pp-n pp-tax' }, `${num(l.t, lang)}%`),
        el('td', { class: 'pp-n' }, m(l.n)),
      ]))),
    ]),
    el('dl', { class: 'pp-totals' }, [
      el('div', [el('dt', w.subtotal), el('dd', m(t.subtotal))]),
      ...(t.taxes || []).filter((g) => g.rate || g.tax).map((g) => el('div', [el('dt', [w.taxOn(num(g.rate, lang)), (t.taxes || []).length > 1 ? el('span', { class: 'pp-on' }, ` · ${m(g.base)}`) : null]), el('dd', m(g.tax))])),
      t.withholding ? el('div', [el('dt', w.withholding(num(t.withholding_rate, lang))), el('dd', `−${m(t.withholding)}`)]) : null,
      el('div', { class: 'pp-total' }, [el('dt', w.total), el('dd', m(t.total))]),
    ]),
    snap.notes ? el('section', { class: 'pp-notes' }, [el('p', { class: 'pp-label' }, w.notes), el('p', { class: 'pp-text' }, snap.notes)]) : null,
    !quote && opts.payment !== false && !stampOf({ ...snap, due_date: '' }) && snap.pay && (snap.pay.bank || snap.pay.note)
      ? el('section', { class: 'pp-notes pp-pay' }, [el('p', { class: 'pp-label' }, w.pay), snap.pay.bank ? el('p', { class: 'pp-text pp-mono' }, snap.pay.bank) : null, snap.pay.note ? el('p', { class: 'pp-text' }, snap.pay.note) : null])
      : null,
  ]);
}
