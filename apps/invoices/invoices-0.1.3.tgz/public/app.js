// The client's page. #/<token> is the whole address of a document: the
// page hashes it to find its row in the public view `doc_links` and opens the
// row with it. Nothing about the document is readable without the link, and
// the token never leaves the browser (the part after # is not sent).
//
// A quote waiting for an answer gets Accept (typed name + box) and Decline;
// an answer is not "sent" until the action answered, and on a busy platform
// it retries on its own for about two minutes. Then the page asks for it to
// be read (`process`, carrying nothing) and looks again until the document
// says so. An invoice gets how to pay it.
import './invcore.js';
import { paper } from './paper.js';
import { WORDS, guessLang } from './words.js';

const C = self.InvCore;
const { el } = Orch;
const T0 = Date.now();
const WAITS = [3, 6, 12, 20, 30, 30, 30];
const sleep = (ms) => new Promise((r) => { setTimeout(r, ms); });
const BASE = (() => { const p = location.pathname; const i = p.indexOf('/canvas/a/'); return i < 0 ? '.' : `${p.slice(0, i)}/canvas/a/${p.slice(i + 10).split('/')[0]}`; })();
const store = {
  get(k) { try { return JSON.parse(localStorage.getItem(k) || 'null'); } catch { return null; } },
  set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch { /* private window */ } },
};
const todayHere = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; };

let w = WORDS[guessLang()];
const token = decodeURIComponent(location.hash.replace(/^#\/?/, '').split(/[/?&]/)[0] || '');

function show(...nodes) {
  Orch.mount('page', nodes);
  const h = document.querySelector('#page h1');
  if (h) h.focus({ preventScroll: true });
}
const state = (title, text, extra) => el('section', { class: 'ip-card ip-state', 'aria-live': 'polite' }, [el('h1', { class: 'ip-title', tabindex: '-1' }, title), text ? el('p', text) : null, extra || null]);
const again = () => el('button', { type: 'button', class: 'oc-btn', onClick: () => start() }, w.again);

/** The document for this link, opened; null when the link opens nothing. Throws on a platform error. */
async function fetchDoc() {
  const k = await C.linkKey(token);
  const r = await Orch.db.view('doc_links', { filter: { k }, limit: 1 });
  const row = (r.rows || [])[0];
  return row ? C.open(token, row.box) : null;
}

async function start() {
  if (!C.TOKEN.test(token)) { show(state(w.badTitle, w.badText)); return; }
  show(el('section', { class: 'ip-card ip-state' }, el('p', w.loading)));
  let snap;
  try { snap = await fetchDoc(); } catch (e) {
    if (e.reason === 'public-view-pending' || e.status === 403) show(state(w.pendingTitle, w.pendingText));
    else if (e.status === 429) show(state(w.busyTitle, w.busyText, again()));
    else show(state(w.brokenTitle, w.brokenText, again()));
    return;
  }
  if (!snap) { show(state(w.goneTitle, w.goneText)); return; }
  draw(snap);
}

function draw(snap) {
  w = WORDS[snap.lang === 'es' ? 'es' : 'en'];
  document.documentElement.lang = snap.lang === 'es' ? 'es' : 'en';
  const what = snap.kind === 'quote' ? (snap.lang === 'es' ? 'Presupuesto' : 'Quote') : (snap.lang === 'es' ? 'Factura' : 'Invoice');
  document.title = `${what} ${snap.number}${snap.company.company_name ? ` · ${snap.company.company_name}` : ''}`;
  const day = (d) => C.longDay(String(d || '').slice(0, 10), snap.lang);
  const total = C.money(snap.totals.total, snap.currency, C.localeOf(snap.lang));
  show(
    el('div', { class: 'ip-bar' }, [
      el('h1', { class: 'ip-bar__title', tabindex: '-1' }, [el('span', { class: 'oc-eyebrow' }, snap.company.company_name || ''), el('span', `${what} ${snap.number}`)]),
      el('button', { type: 'button', class: 'oc-btn oc-btn--sm', title: w.printHelp, onClick: () => window.print() }, w.print),
    ]),
    // An invoice: how to pay comes first. A quote: read it first, answer under it.
    snap.kind === 'quote' ? null : payPanel(snap, day, total),
    paper(snap, { today: todayHere() }),
    snap.kind === 'quote' ? quotePanel(snap, day) : null,
  );
}

function payPanel(snap, day, total) {
  if (snap.void_at || snap.status === 'Void') return el('section', { class: 'ip-card ip-note ip-note--bad' }, el('p', w.voided));
  if (snap.status === 'Paid') return el('section', { class: 'ip-card ip-note ip-note--good' }, el('p', w.paid(day(snap.paid_at))));
  const late = snap.due_date && snap.due_date < todayHere();
  const pay = snap.pay || {};
  return el('section', { class: 'ip-card ip-pay' }, [
    el('h2', { class: 'ip-h2' }, w.payTitle),
    el('p', { class: late ? 'ip-late' : '' }, (late ? w.payLate : w.payDue)(total, day(snap.due_date))),
    pay.url ? el('div', { class: 'ip-stack' }, [el('a', { class: 'oc-btn oc-btn--primary ip-big', href: pay.url, rel: 'noopener' }, w.payCard(total)), el('p', { class: 'ip-small' }, w.payCardHelp)]) : null,
    pay.bank ? el('div', { class: 'ip-stack' }, [
      el('p', { class: 'ip-small' }, pay.url ? w.payBank : w.payBankOnly),
      el('div', { class: 'ip-bank' }, [el('pre', pay.bank), el('button', { type: 'button', class: 'oc-btn oc-btn--sm', onClick: () => copy(pay.bank) }, w.copy)]),
      el('p', { class: 'ip-small' }, w.payRef(snap.number)),
    ]) : null,
  ]);
}

async function copy(text) {
  try { await navigator.clipboard.writeText(text); Orch.toast(w.copied); } catch { /* the text is there to select */ }
}

function quotePanel(snap, day) {
  const mine = store.get(`invoice:answer:${token}`);
  if (snap.status === 'Accepted' && snap.accepted) return el('section', { class: 'ip-card ip-note ip-note--good' }, el('p', w.acceptedBy(snap.accepted.name, day(snap.accepted.at))));
  if (snap.status === 'Declined') return el('section', { class: 'ip-card ip-note' }, el('p', w.declinedOn(day(snap.declined_at))));
  if (snap.status !== 'Sent') return null;
  if (mine) return el('section', { class: 'ip-card ip-note ip-note--good' }, el('p', mine.decision === 'accept' ? w.thanksAccept : w.thanksDecline));
  if (snap.due_date && snap.due_date < todayHere()) return el('section', { class: 'ip-card ip-note' }, el('p', w.expired(day(snap.due_date))));
  return answerForm(snap, day);
}

function answerForm(snap, day) {
  const host = el('section', { class: 'ip-card ip-answer' });
  const visit = (self.crypto && crypto.randomUUID) ? crypto.randomUUID() : `${Date.now()}${Math.random()}`;
  const hp = el('input', { type: 'text', name: 'website', tabindex: '-1', autocomplete: 'off', class: 'ip-hp', 'aria-hidden': 'true' });
  const status = el('p', { class: 'ip-status', role: 'status', 'aria-live': 'polite' });
  const acceptView = () => {
    const name = el('input', { class: 'oc-input', autocomplete: 'name', maxlength: '120', required: true });
    const box = el('input', { type: 'checkbox' });
    const go = el('button', { type: 'submit', class: 'oc-btn oc-btn--primary ip-big' }, w.accept);
    const f = el('form', { class: 'ip-stack' }, [
      el('label', { class: 'oc-field' }, [el('span', { class: 'oc-label' }, w.name), name]),
      el('label', { class: 'ip-check' }, [box, el('span', w.agree)]),
      hp, go, status,
      el('button', { type: 'button', class: 'ip-link', onClick: declineView }, w.declineOpen),
    ]);
    f.addEventListener('submit', async (e) => {
      e.preventDefault();
      if (name.value.trim().length < 2) { status.textContent = w.needName; name.focus(); return; }
      if (!box.checked) { status.textContent = w.needBox; return; }
      go.disabled = true;
      await send({ decision: 'accept', name: name.value.trim(), agreed: 'yes', note: '' }, () => { go.disabled = false; });
    });
    Orch.mount(host, [el('h2', { class: 'ip-h2' }, w.quoteTitle), el('p', w.quoteText(day(snap.due_date))), f]);
  };
  const declineView = () => {
    const why = el('textarea', { class: 'oc-textarea', rows: '3', maxlength: '500' });
    const go = el('button', { type: 'submit', class: 'oc-btn' }, w.decline);
    const f = el('form', { class: 'ip-stack' }, [el('label', { class: 'oc-field' }, [el('span', { class: 'oc-label' }, w.declineWhy), why]), hp,
      el('div', { class: 'oc-row' }, [go, el('button', { type: 'button', class: 'oc-btn oc-btn--ghost', onClick: acceptView }, w.keep)]), status]);
    f.addEventListener('submit', async (e) => { e.preventDefault(); go.disabled = true; await send({ decision: 'decline', name: '', agreed: '', note: why.value.trim() }, () => { go.disabled = false; }); });
    Orch.mount(host, [el('h2', { class: 'ip-h2' }, w.quoteTitle), f]);
  };
  async function send(answer, failed) {
    status.textContent = w.sending;
    const params = Object.assign({ token, hp: hp.value || '', ms: Date.now() - T0, visit }, answer);
    for (let i = 0; ; i += 1) {
      try { await Orch.action('respond', params); break; } catch (e) {
        const passing = !e.status || e.status === 429 || e.status >= 500;
        if (!passing || i >= WAITS.length) { status.textContent = w.failed; failed(); return; }
        for (let s = WAITS[i]; s > 0; s -= 1) { status.textContent = w.retrying(s); await sleep(1000); }
      }
    }
    store.set(`invoice:answer:${token}`, { decision: answer.decision, at: new Date().toISOString() });
    process();
    Orch.mount(host, el('p', { class: 'ip-thanks', role: 'status' }, answer.decision === 'accept' ? w.thanksAccept : w.thanksDecline));
    follow(snap.status);
  }
  acceptView();
  return host;
}

/** Ask for the answer to be read now. It carries nothing; a refused beacon is picked up by the half-hourly check. */
function process() {
  const body = new Blob([JSON.stringify({ params: {} })], { type: 'application/json' });
  try { if (navigator.sendBeacon && navigator.sendBeacon(`${BASE}/api/actions/process`, body)) return; } catch { /* plain call below */ }
  Orch.action('process', {}).catch(() => { /* the half-hourly check takes it */ });
}

/** Look again a few times until the document shows the answer, then draw it. */
async function follow(was) {
  for (const s of [3, 4, 6, 8, 12]) {
    await sleep(s * 1000);
    try { const snap = await fetchDoc(); if (snap && snap.status !== was) { draw(snap); return; } } catch { /* keep the thank-you */ }
  }
}

window.addEventListener('hashchange', () => location.reload());
start();
