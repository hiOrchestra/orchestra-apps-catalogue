// The client's page in the document's language (Settings → "Your clients
// read"). Before the document is open, the browser's language decides.
export const WORDS = {
  en: {
    loading: 'Opening the document…', print: 'Save as PDF', printHelp: 'Opens your browser\'s print window: choose "Save as PDF".',
    badTitle: 'This link is not complete', badText: 'Open it again from the email you received, or ask the sender for the link.',
    goneTitle: 'This document is not available', goneText: 'The link may be old or mistyped. Ask the sender for a new one.',
    pendingTitle: 'Not open yet', pendingText: 'This page is waiting to be switched on. Please try again a little later.',
    busyTitle: 'Many people are here right now', busyText: 'Please try again in a minute.', brokenTitle: 'This page could not load', brokenText: 'Check your connection and try again.', again: 'Try again',
    payTitle: 'Pay this invoice', payDue: (t, d) => `${t}, due on ${d}.`, payLate: (t, d) => `${t}, due since ${d}.`, payCard: (t) => `Pay ${t} by card`, payCardHelp: 'On Stripe\'s secure page. Your card details never reach us.',
    payBank: 'Or by bank transfer, to:', payBankOnly: 'By bank transfer, to:', copy: 'Copy', copied: 'Copied.', payRef: (n) => `Put ${n} as the reference.`,
    paid: (d) => `Paid${d ? ` on ${d}` : ''}. Thank you.`, voided: 'This invoice was voided by its sender: there is nothing to pay.',
    quoteTitle: 'Your answer', quoteText: (d) => `This quote is valid until ${d}.`, name: 'Your full name', agree: 'I accept this quote, its prices and its conditions.',
    accept: 'Accept the quote', declineOpen: 'Decline it', declineWhy: 'Anything you want to tell them? (optional)', decline: 'Decline the quote', keep: 'Back',
    needName: 'Write your name to accept.', needBox: 'Tick the box to accept.',
    sending: 'Sending…', retrying: (s) => `Busy right now. Trying again in ${s} s…`, failed: 'It could not be sent. Your answer is still here: try again.',
    acceptedBy: (n, d) => `Accepted by ${n}${d ? ` on ${d}` : ''}. Thank you: the sender has been told.`, declinedOn: (d) => `Declined${d ? ` on ${d}` : ''}. The sender has been told.`,
    thanksAccept: 'Thank you: your acceptance was sent. The sender will be in touch.', thanksDecline: 'Thank you: your answer was sent.',
    expired: (d) => `This quote expired on ${d}. Ask the sender for a new one if you are still interested.`,
  },
  es: {
    loading: 'Abriendo el documento…', print: 'Guardar en PDF', printHelp: 'Abre la ventana de impresión: elige "Guardar como PDF".',
    badTitle: 'Este enlace no está completo', badText: 'Ábrelo de nuevo desde el correo que recibiste, o pide el enlace a quien lo envió.',
    goneTitle: 'Este documento no está disponible', goneText: 'El enlace puede ser antiguo o estar mal copiado. Pide uno nuevo a quien lo envió.',
    pendingTitle: 'Todavía no está abierto', pendingText: 'Esta página está pendiente de activarse. Vuelve a intentarlo un poco más tarde.',
    busyTitle: 'Hay mucha gente ahora mismo', busyText: 'Vuelve a intentarlo en un minuto.', brokenTitle: 'No se pudo cargar la página', brokenText: 'Revisa tu conexión y vuelve a intentarlo.', again: 'Intentar de nuevo',
    payTitle: 'Pagar esta factura', payDue: (t, d) => `${t}, con vencimiento el ${d}.`, payLate: (t, d) => `${t}, vencida desde el ${d}.`, payCard: (t) => `Pagar ${t} con tarjeta`, payCardHelp: 'En la página segura de Stripe. Los datos de tu tarjeta nunca llegan a nosotros.',
    payBank: 'O por transferencia, a:', payBankOnly: 'Por transferencia, a:', copy: 'Copiar', copied: 'Copiado.', payRef: (n) => `Indica ${n} como concepto.`,
    paid: (d) => `Pagada${d ? ` el ${d}` : ''}. Gracias.`, voided: 'Quien la emitió anuló esta factura: no hay nada que pagar.',
    quoteTitle: 'Tu respuesta', quoteText: (d) => `Este presupuesto es válido hasta el ${d}.`, name: 'Tu nombre completo', agree: 'Acepto este presupuesto, sus precios y sus condiciones.',
    accept: 'Aceptar el presupuesto', declineOpen: 'Rechazarlo', declineWhy: '¿Quieres decirles algo? (opcional)', decline: 'Rechazar el presupuesto', keep: 'Volver',
    needName: 'Escribe tu nombre para aceptar.', needBox: 'Marca la casilla para aceptar.',
    sending: 'Enviando…', retrying: (s) => `Hay mucha carga. Reintentando en ${s} s…`, failed: 'No se pudo enviar. Tu respuesta sigue aquí: inténtalo de nuevo.',
    acceptedBy: (n, d) => `Aceptado por ${n}${d ? ` el ${d}` : ''}. Gracias: ya se ha avisado a quien lo envió.`, declinedOn: (d) => `Rechazado${d ? ` el ${d}` : ''}. Ya se ha avisado a quien lo envió.`,
    thanksAccept: 'Gracias: tu aceptación se ha enviado. Se pondrán en contacto contigo.', thanksDecline: 'Gracias: tu respuesta se ha enviado.',
    expired: (d) => `Este presupuesto caducó el ${d}. Pide uno nuevo a quien lo envió si todavía te interesa.`,
  },
};
export const guessLang = () => (/^es\b/i.test(navigator.language || '') ? 'es' : 'en');
