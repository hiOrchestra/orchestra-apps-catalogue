// How a company's quotes and invoices look (0.5.0: «manage a bit the layout… always ensuring the final
// look still looks good»). A curated set of choices, never free CSS: a template, an accent from a palette (or a custom
// colour that reads on white paper), a pair of typefaces, what optional parts show, a few short texts. What the law asks
// of an invoice is never a choice: LEGAL lists it, and the paper draws it whatever `show` says.
// Pure, the same file for the server, the desk and the client's page. test/design.test.mjs.

export const TEMPLATES = {
  clasico: { es: 'Clásico', en: 'Classic', line: { es: 'Tu nombre en serif, filetes finos y mucho aire. Como hasta ahora.', en: 'Your name in a serif, fine rules, plenty of air.' } },
  moderno: { es: 'Moderno', en: 'Modern', line: { es: 'Una franja de tu color arriba, títulos firmes y los totales destacados.', en: 'A band of your colour, firm headings, totals set apart.' } },
  minimal: { es: 'Minimal', en: 'Minimal', line: { es: 'Solo lo necesario: letra pequeña, sin líneas, todo alineado a la izquierda.', en: 'Only what is needed: small type, no rules.' } },
};

/** Accents that read well on white: each at least 4.5 : 1 against the paper. */
export const PALETTE = {
  tinta: { hex: '#1b1a17', es: 'Tinta', en: 'Ink' },
  noche: { hex: '#1f3a5f', es: 'Azul noche', en: 'Night blue' },
  petroleo: { hex: '#1d5560', es: 'Petróleo', en: 'Petrol' },
  bosque: { hex: '#2f5d46', es: 'Verde bosque', en: 'Forest' },
  burdeos: { hex: '#7a2836', es: 'Burdeos', en: 'Burgundy' },
  teja: { hex: '#9c4127', es: 'Teja', en: 'Brick' },
  ciruela: { hex: '#553a6b', es: 'Ciruela', en: 'Plum' },
  oro: { hex: '#7a5c14', es: 'Oro viejo', en: 'Old gold' },
};

/** Pairs of typefaces: a face for the name, the number and the total, and one for everything else. */
export const FONTS = {
  clasica: { es: 'Clásica', en: 'Classic', display: 'Source Serif 4', text: 'Inter', google: 'family=Source+Serif+4:opsz,wght@8..60,400;8..60,600&family=Inter:wght@400;500;600' },
  moderna: { es: 'Moderna', en: 'Modern', display: 'Manrope', text: 'Inter', google: 'family=Manrope:wght@500;700;800&family=Inter:wght@400;500;600' },
  tecnica: { es: 'Técnica', en: 'Technical', display: 'IBM Plex Sans', text: 'IBM Plex Sans', google: 'family=IBM+Plex+Sans:wght@400;500;600;700&family=IBM+Plex+Mono:wght@400;500' },
};

/** The optional parts a person may show or hide. Never a legal one (LEGAL). */
export const SHOW = {
  contact: { es: 'Persona de contacto del cliente', en: 'Client contact person', default: true },
  due_date: { es: 'Fecha de vencimiento', en: 'Due date', default: true },
  bank: { es: 'Datos bancarios (IBAN)', en: 'Bank details (IBAN)', default: true },
  pay_link: { es: 'Enlace para pagar con tarjeta', en: 'Card payment link', default: true },
  notes: { es: 'Notas del documento', en: 'Document notes', default: true },
  line_numbers: { es: 'Número de línea', en: 'Line numbers', default: false },
  discount_column: { es: 'Columna de descuento', en: 'Discount column', default: false },
};

/** Short texts, each with its limit. */
export const TEXTS = {
  footer: { es: 'Pie de página', en: 'Footer', max: 160, help: { es: 'En cada página, abajo. Por ejemplo, tu web o tu registro mercantil.', en: 'On every page, at the foot.' } },
  thanks: { es: 'Línea de agradecimiento', en: 'Thank-you line', max: 120, help: { es: 'Al final, sobre el pie. Por ejemplo «Gracias por confiar en nosotros».', en: 'At the end, above the footer.' } },
  quote_terms: { es: 'Validez del presupuesto', en: 'Quote validity', max: 300, help: { es: 'Solo en presupuestos. {fecha} es el día hasta el que vale.', en: 'Quotes only. {fecha} is the last valid day.' } },
  invoice_legal: { es: 'Menciones legales de la factura', en: 'Invoice legal lines', max: 500, help: { es: 'Solo en facturas: una exención de IVA, tu inscripción registral… Se añaden a lo obligatorio, nunca lo quitan.', en: 'Invoices only: added to what the law requires, never instead.' } },
};

/**
 * What a Spanish invoice must say (Real Decreto 1619/2012, art. 6), drawn whatever the design: never a toggle. A quote
 * carries the same parts but the law asks nothing of it.
 */
export const LEGAL = ['number', 'issue_date', 'issuer_name', 'issuer_tax_id', 'issuer_address', 'client_name', 'client_tax_id', 'client_address', 'lines', 'base', 'tax_rate', 'tax_amount', 'total', 'withholding'];

export const DEFAULT_DESIGN = {
  template: 'clasico', accent: 'tinta', fonts: 'clasica',
  show: Object.fromEntries(Object.entries(SHOW).map(([k, v]) => [k, v.default])),
  texts: { footer: '', thanks: '', quote_terms: '', invoice_legal: '' },
};

// ── colour ─────────────────────────────────────────────────────────────
const HEX = /^#([0-9a-f]{3}|[0-9a-f]{6})$/i;
export function hexOf(v) {
  const s = String(v || '').trim();
  if (PALETTE[s]) return PALETTE[s].hex;
  if (!HEX.test(s)) return null;
  const h = s.slice(1).toLowerCase();
  return '#' + (h.length === 3 ? h.split('').map((c) => c + c).join('') : h);
}
const channel = (c) => { const x = c / 255; return x <= 0.03928 ? x / 12.92 : ((x + 0.055) / 1.055) ** 2.4; };
export function luminance(hex) {
  const h = hexOf(hex).slice(1);
  const [r, g, b] = [0, 2, 4].map((i) => parseInt(h.slice(i, i + 2), 16));
  return 0.2126 * channel(r) + 0.7152 * channel(g) + 0.0722 * channel(b);
}
/** WCAG contrast of a colour against white paper, 1 to 21. */
export const contrastOnWhite = (hex) => Math.round((1.05 / (luminance(hex) + 0.05)) * 10) / 10;
export const MIN_CONTRAST = 4.5;

/**
 * An accent a person typed or chose → { value } (a palette key or a #rrggbb that reads on white) or { problem } in
 * Spanish, saying why and what to do.
 */
export function accentVerdict(v) {
  const s = String(v || '').trim();
  if (PALETTE[s]) return { value: s };
  const hex = hexOf(s);
  if (!hex) return { problem: 'Ese color no se entiende: elige uno de la paleta o escribe uno como #1f3a5f.' };
  const c = contrastOnWhite(hex);
  if (c < MIN_CONTRAST) return { problem: `Ese color se leería mal sobre el papel blanco (contraste ${String(c).replace('.', ',')} : 1; hace falta al menos 4,5 : 1). Prueba uno más oscuro.`, contrast: c };
  return { value: hex, contrast: c };
}

/** A tint of the accent for backgrounds (mixed with white), as #rrggbb. */
export function tint(hex, amount = 0.08) {
  const h = (hexOf(hex) || '#1b1a17').slice(1);
  return '#' + [0, 2, 4].map((i) => Math.round(255 - (255 - parseInt(h.slice(i, i + 2), 16)) * amount).toString(16).padStart(2, '0')).join('');
}

// ── the design as stored, read, and changed ────────────────────────────
const obj = (v) => { if (v && typeof v === 'object') return v; try { return JSON.parse(v || '{}') || {}; } catch { return {}; } };
const cut = (s, n) => String(s == null ? '' : s).replace(/\r\n/g, '\n').trim().slice(0, n);

/** Whatever is stored (JSON or nothing, an older version) → a whole, valid design. Never throws. */
export function designOf(stored) {
  const d = obj(stored);
  const show = obj(d.show);
  const texts = obj(d.texts);
  const accent = accentVerdict(d.accent).value || DEFAULT_DESIGN.accent;
  return {
    template: TEMPLATES[d.template] ? d.template : DEFAULT_DESIGN.template,
    accent,
    fonts: FONTS[d.fonts] ? d.fonts : DEFAULT_DESIGN.fonts,
    show: Object.fromEntries(Object.keys(SHOW).map((k) => [k, typeof show[k] === 'boolean' ? show[k] : show[k] === 1 || show[k] === '1' || show[k] === 'yes' ? true : show[k] === 0 || show[k] === '0' || show[k] === 'no' ? false : DEFAULT_DESIGN.show[k]])),
    texts: Object.fromEntries(Object.entries(TEXTS).map(([k, t]) => [k, cut(texts[k], t.max)])),
  };
}

/**
 * A change asked by a person or an agent → { design } (the whole new one) or { problems: [{ field, why }] }. Only what
 * is sent changes. Unknown parts are refused by name, so a typo never passes silently; a legal part cannot be hidden.
 */
export function designChange(current, input) {
  const d = designOf(current);
  const problems = [];
  const i = input || {};
  if (i.template !== undefined) { if (TEMPLATES[i.template]) d.template = i.template; else problems.push({ field: 'template', why: `template is one of ${Object.keys(TEMPLATES).join(', ')}.` }); }
  if (i.fonts !== undefined) { if (FONTS[i.fonts]) d.fonts = i.fonts; else problems.push({ field: 'fonts', why: `fonts is one of ${Object.keys(FONTS).join(', ')}.` }); }
  if (i.accent !== undefined) { const v = accentVerdict(i.accent); if (v.value) d.accent = v.value; else problems.push({ field: 'accent', why: v.problem }); }
  if (i.show !== undefined) {
    for (const [k, v] of Object.entries(obj(i.show))) {
      if (LEGAL.includes(k)) problems.push({ field: `show.${k}`, why: `${k} is what the law asks of an invoice: it is always printed.` });
      else if (!SHOW[k]) problems.push({ field: `show.${k}`, why: `show takes ${Object.keys(SHOW).join(', ')}.` });
      else d.show[k] = v === true || v === 1 || v === '1' || v === 'yes' || v === 'true';
    }
  }
  if (i.texts !== undefined) {
    for (const [k, v] of Object.entries(obj(i.texts))) {
      if (!TEXTS[k]) problems.push({ field: `texts.${k}`, why: `texts takes ${Object.keys(TEXTS).join(', ')}.` });
      else if (String(v ?? '').trim().length > TEXTS[k].max) problems.push({ field: `texts.${k}`, why: `${TEXTS[k].en} is at most ${TEXTS[k].max} characters.` });
      else d.texts[k] = cut(v, TEXTS[k].max);
    }
  }
  return problems.length ? { problems } : { design: d };
}

/** What the paper needs to draw the design: the colours and faces resolved. */
export function looksOf(design) {
  const d = designOf(design);
  const accent = hexOf(d.accent) || PALETTE.tinta.hex;
  return { ...d, accentHex: accent, accentTint: tint(accent, 0.07), accentLine: tint(accent, 0.35), font: FONTS[d.fonts] };
}

/**
 * What the company's details still lack for an invoice the law accepts: the issuer's legal name, tax ID and address
 * (the client's are checked when it is issued). → [{ field, es }], empty when nothing is missing.
 */
export function legalGaps(company) {
  const c = company || {};
  const out = [];
  if (!String(c.company_name || '').trim()) out.push({ field: 'company_name', es: 'tu razón social' });
  if (!String(c.tax_id || '').trim()) out.push({ field: 'tax_id', es: 'tu NIF' });
  // 0.5.7: the street and «08001 Barcelona» are their own fields; 0.5.6's one text, or a snapshot's, still counts
  if (!String(c.address || '').trim()) out.push({ field: 'address', es: 'tu dirección' });
  else if (c.postal_code !== undefined && !String(c.city || '').trim() && !String(c.postal_code || '').trim() && !/\n|\d{5}/.test(String(c.address))) out.push({ field: 'city', es: 'tu código postal y municipio' });
  return out;
}

/** The PDF's name: «Factura FAC-2026-011 — Reformas Ribera SL», a draft «Factura (borrador) — …». */
export function fileNameOf(snap) {
  const es = snap.lang !== 'en';
  const what = snap.kind === 'quote' ? (es ? 'Presupuesto' : 'Quote') : (es ? 'Factura' : 'Invoice');
  const number = snap.number || (es ? '(borrador)' : '(draft)');
  const c = snap.client || {};
  const who = String(c.legal_name || c.name || '').trim();
  return `${what} ${number}${who ? ` — ${who}` : ''}`.replace(/[\\/:*?"<>|]+/g, ' ').replace(/\s+/g, ' ').trim();
}

/** A logo a person uploaded, as kept: a data URL of a PNG, JPEG or SVG, at most LOGO_MAX bytes. → { value } | { problem }. */
export const LOGO_MAX = 200 * 1024;
export function logoVerdict(v) {
  const s = String(v || '');
  if (!s) return { value: '' };
  const m = /^data:image\/(png|jpeg|svg\+xml);base64,([A-Za-z0-9+/=]+)$/.exec(s);
  if (!m) return { problem: 'El logo es una imagen PNG, JPG o SVG.' };
  if (s.length > LOGO_MAX * 1.37) return { problem: 'Ese logo pesa demasiado: súbelo más pequeño (como mucho 200 KB).' };
  if (m[1] === 'svg+xml') {
    const text = typeof atob === 'function' ? atob(m[2]) : Buffer.from(m[2], 'base64').toString('utf8');
    if (/<script|\son[a-z]+\s*=|<foreignObject|javascript:|xlink:href\s*=\s*["']?(?!#)|href\s*=\s*["']?(?:https?:|\/\/)/i.test(text)) return { problem: 'Ese SVG lleva código o enlaces de fuera: guárdalo como una imagen simple (o súbelo en PNG).' };
  }
  return { value: s };
}
