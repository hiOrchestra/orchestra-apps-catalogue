SELECT k, box FROM inv_link_files
