// «Tu factura» (0.7): a company's own invoice, a PDF it already sends, becomes its design — the same places, sizes,
// colours, letters, rules and logo, computed from what is printed on it (the platform reads the PDF: server/document.mjs),
// never imitated by eye. Three steps, all pure:
//   labelRuns(page)                what each printed run is (the number, the client, a line's price…): rules first; the
//                                  company's AI only fills what they leave (server/services/own.mjs)
//   buildOwn(page, roles, fit)     the template: bands between the page's rules, blocks of lines in them, the table, the
//                                  totals; each value replaced by what it is ({number}, {client.name}…). `fit` says the web
//                                  face and weight of each printed letter (pages/parts/fit.js measures them)
//   ownParts(own, snap, look)      a document drawn with it, as paper.js's own templates are
// Texts are placed by their baseline, in points, from the page's left edge. What the law asks is always drawn: what the
// example did not carry is added at the end (LEGAL gaps, ownGaps).
// test/own.test.mjs.

export const OWN_VERSION = 1;

// ── reading what is printed ────────────────────────────────────────────
const flat = (s) => String(s == null ? '' : s).replace(/\s+/g, ' ').trim();
const low = (s) => flat(s).toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '');
export const TAX_ID = /\b(?:ES[- ]?)?(?:[A-HJNPQRSUVW][- ]?\d{7}[0-9A-J]|\d{8}[- ]?[A-Z]|[XYZ][- ]?\d{7}[- ]?[A-Z])\b/i;
export const IBAN = /\b[A-Z]{2}\d{2}(?:[ ]?[A-Z0-9]{4}){3,7}(?:[ ]?[A-Z0-9]{1,4})?\b/;
export const EMAIL = /[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i;
export const MONEY = /^[-−]?\s*(?:€|EUR|\$|£)?\s*\d{1,3}(?:[.,\s]\d{3})*(?:[.,]\d{1,2})?\s*(?:€|EUR|\$|£)?$/;
const MONTHS = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre'];
const MONTHS_EN = ['january', 'february', 'march', 'april', 'may', 'june', 'july', 'august', 'september', 'october', 'november', 'december'];
const DATE_NUM = /\b(\d{1,2})([\/.\-])(\d{1,2})\2(\d{4}|\d{2})\b/;
const DATE_ISO = /\b(\d{4})-(\d{2})-(\d{2})\b/;
const DATE_ES = new RegExp(`\\b(\\d{1,2})(?:\\s+de)?\\s+(${MONTHS.join('|')})(?:\\s+de[l]?)?,?\\s+(\\d{4})\\b`, 'i');
const DATE_EN = new RegExp(`\\b(${MONTHS_EN.join('|')})\\s+(\\d{1,2}),?\\s+(\\d{4})\\b`, 'i');
const two = (n) => String(n).padStart(2, '0');

/** A printed date → { iso, how } (how: the format to print others the same way), or null. */
export function readDate(text) {
  const s = flat(text);
  let m = DATE_ISO.exec(s);
  if (m) return { iso: m[0], how: 'iso', said: m[0] };
  m = DATE_NUM.exec(s);
  if (m) { const y = m[4].length === 2 ? `20${m[4]}` : m[4]; if (Number(m[3]) >= 1 && Number(m[3]) <= 12) return { iso: `${y}-${two(m[3])}-${two(m[1])}`, how: `num:${m[2]}:${m[1].length < 2 || m[1][0] !== '0' && Number(m[1]) < 10 ? 1 : 2}:${m[4].length}`, said: m[0] }; }
  m = DATE_ES.exec(s);
  if (m) return { iso: `${m[3]}-${two(MONTHS.indexOf(m[2].toLowerCase()) + 1)}-${two(m[1])}`, how: / de /i.test(m[0]) ? 'es:de' : 'es', said: m[0] };
  m = DATE_EN.exec(s);
  if (m) return { iso: `${m[3]}-${two(MONTHS_EN.indexOf(m[1].toLowerCase()) + 1)}-${two(m[2])}`, how: 'en', said: m[0] };
  return null;
}
/** A day printed the way the example prints its own. */
export function writeDate(iso, how = 'num:/:2:4') {
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(String(iso || ''));
  if (!m) return '';
  const [, y, mo, d] = m;
  if (how === 'iso') return `${y}-${mo}-${d}`;
  if (how === 'es:de') return `${Number(d)} de ${MONTHS[mo - 1]} de ${y}`;
  if (how === 'es') return `${Number(d)} ${MONTHS[mo - 1]} ${y}`;
  if (how === 'en') { const w = MONTHS_EN[mo - 1]; return `${w[0].toUpperCase()}${w.slice(1)} ${Number(d)}, ${y}`; }
  const [, sep, pad, yl] = how.split(':');
  return [pad === '1' ? String(Number(d)) : d, pad === '1' ? String(Number(mo)) : mo, yl === '2' ? y.slice(2) : y].join(sep || '/');
}
/** A printed amount → cents, or null. */
export function readMoney(text) {
  let s = flat(text).replace(/[€$£]|EUR/gi, '').replace(/\s/g, '').replace('−', '-');
  if (!/^-?[\d.,]+$/.test(s)) return null;
  const c = s.lastIndexOf(','); const d = s.lastIndexOf('.');
  const dec = c > d ? ',' : d > c ? '.' : '';
  const tail = dec ? s.length - s.lastIndexOf(dec) - 1 : 0;
  if (dec && tail === 3 && (s.match(/[.,]/g) || []).length === 1) s = s.replace(dec, '');
  else if (dec) s = s.slice(0, s.lastIndexOf(dec)).replace(/[.,]/g, '') + '.' + s.slice(s.lastIndexOf(dec) + 1);
  const n = Number(s);
  return Number.isFinite(n) ? Math.round(n * 100) : null;
}
/** How the example writes money: its separators, its sign and where. */
export function moneyHow(text) {
  const s = flat(text);
  const sign = /€/.test(s) ? '€' : /EUR/i.test(s) ? 'EUR' : (/[$£]/.exec(s) || [''])[0];
  const before = !!sign && s.replace('−', '-').replace(/^-/, '').trim().startsWith(sign);
  const digits = s.replace(/[^\d.,]/g, '');
  const dec = digits.lastIndexOf(',') > digits.lastIndexOf('.') ? ',' : '.';
  const thousands = new RegExp(`\\d\\${dec === ',' ? '.' : ','}\\d{3}`).test(digits) ? (dec === ',' ? '.' : ',') : /\d \d{3}/.test(s) ? ' ' : (Math.abs(readMoney(s) || 0) >= 100000 ? '' : dec === ',' ? '.' : ',');
  return { sign, before, space: sign ? /\s/.test(before ? s.slice(s.indexOf(sign) + sign.length, s.indexOf(sign) + sign.length + 1) : s.slice(s.indexOf(sign) - 1, s.indexOf(sign))) : false, dec, thousands };
}
export function writeMoney(cents, how, currency = 'EUR') {
  const h = how || { sign: '€', before: false, space: true, dec: ',', thousands: '.' };
  const n = Math.abs(Number(cents) || 0) / 100;
  const [i, d] = n.toFixed(2).split('.');
  const text = i.replace(/\B(?=(\d{3})+(?!\d))/g, h.thousands) + h.dec + d;
  const sign = currency && currency !== 'EUR' ? currency : h.sign;
  return `${Number(cents) < 0 ? '−' : ''}${!sign ? text : h.before ? `${sign}${h.space ? ' ' : ''}${text}` : `${text}${h.space ? ' ' : ''}${sign}`}`;
}

// ── what each run is ───────────────────────────────────────────────────
export const ROLES = ['label', 'static', 'kind', 'number', 'issue_date', 'due_date', 'extra_label', 'extra', 'issuer_name', 'issuer_tax_id', 'issuer_address', 'issuer_contact', 'client_name', 'client_tax_id', 'client_address', 'client_email', 'client_contact', 'client_trade', 'title_ref', 'th', 'line_section', 'line_title', 'line_detail', 'line_qty', 'line_price', 'line_disc', 'line_tax', 'line_amount', 'base_label', 'base', 'tax_label', 'tax', 'withholding_label', 'withholding', 'total_label', 'total', 'pay_method', 'holder', 'iban', 'bank', 'bic', 'pay_key', 'pay_note', 'notes', 'thanks', 'legal', 'footer'];
const TH = [['desc', /^(descripcion|concepto|detalle|servicio|articulo|producto|item|description|service)/], ['qty', /^(cant|unid|uds|ud\.?$|qty|quantity|horas|hours|units?$)/], ['price', /^(precio|p\.? ?unit|importe unit|unit ?price|tarifa|price|rate$|coste)/], ['disc', /^(dto|desc\.|descuento|discount)/], ['tax', /^(iva|vat|impuesto|igic|tax|% ?iva)/], ['amount', /^(importe|total|amount|subtotal|neto)/], ['n', /^(n\.?º|#|ref)/]];
/** «Factura nº: F2026/0042» → «F2026/0042»; a number alone, as it is. */
export const numberOfText = (t) => { const m = /(?:^|[\s:#])((?=[A-Z0-9./_-]*\d)[A-Z0-9][A-Z0-9./_-]{1,24})\s*$/i.exec(flat(t)); return m ? m[1] : ''; };
export const colKey = (text) => { const s = low(text); return (TH.find(([, re]) => re.test(s)) || [null])[0]; };

/** A heading over some lines: capitals, in letters of their own (smaller, spaced or another face than the details). */
const headingOf = (r, details) => { const t = r.s.replace(/[^\p{L}]/gu, ''); if (!t || t !== t.toUpperCase()) return false; const other = details.filter((d) => d !== r && !(d.s === d.s.toUpperCase())); return r.ls > 0.3 || !other.length || other.every((d) => d.f !== r.f || Math.abs(d.z - r.z) > 0.3); };

/**
 * What the rules can tell of each run → { roles: { index: role }, line: { index: n }, sure: 0–1, missing: [role] }. The AI
 * completes it (server); a person corrects it on screen.
 */
export function labelRuns(page) {
  const R = page.runs;
  const roles = {}; const line = {};
  const set = (i, r) => { if (roles[i] === undefined) roles[i] = r; };
  const same = (a, b, e = 3) => Math.abs(R[a].y - R[b].y) <= e;
  // the table's heads: a line with at least two column words
  const numberIn = numberOfText;
  const byY = R.map((r, i) => i).sort((a, b) => R[a].y - R[b].y || R[a].x - R[b].x);
  let th = [];
  for (const i of byY) { const row = byY.filter((j) => same(i, j, 2.2)); const keys = row.map((j) => colKey(R[j].s)).filter(Boolean); if (new Set(keys).size >= 2 && keys.includes('amount') && row.length >= 2) { th = row; break; } }
  const thY = th.length ? R[th[0]].y : null;
  for (const i of th) set(i, 'th');
  // the totals: labels with their amount on the right
  const amountOf = (i) => byY.filter((j) => j !== i && same(i, j, 4.5) && R[j].x > R[i].x && readMoney(R[j].s) !== null && /\d/.test(R[j].s)).sort((a, b) => R[b].x1 - R[a].x1)[0];
  const below = byY.filter((i) => thY === null || R[i].y > thY + 4);
  let baseY = Infinity;
  for (const i of below) {
    const s = low(R[i].s); const v = amountOf(i);
    if (v === undefined) continue;
    const put = (l, r) => { if (!Object.values(roles).includes(r) || r === 'tax') { set(i, l); set(v, r); baseY = Math.min(baseY, R[i].y); } };
    if (/^(base imponible|base|subtotal|sub total|neto|importe neto|net)\b/.test(s)) put('base_label', 'base');
    else if (/^(iva|i\.v\.a|igic|vat|tax)\b/.test(s)) put('tax_label', 'tax');
    else if (/^(irpf|retencion|ret\.|withholding)/.test(s)) put('withholding_label', 'withholding');
    else if (/^(total|importe total|total factura|a pagar|total a pagar|amount due)\b/.test(s)) put('total_label', 'total');
  }
  // the lines between the heads and the totals: each begins where an amount is printed, its title on that baseline
  if (thY !== null) {
    const cols = th.map((i) => ({ i, key: colKey(R[i].s), x: R[i].x, x1: R[i].x1 })).sort((a, b) => a.x - b.x);
    const first = cols.find((c) => c.key === 'desc') || cols.find((c) => !['qty', 'n', 'price', 'amount', 'tax', 'disc'].includes(c.key)) || cols[0];
    const after = cols[cols.indexOf(first) + 1]; const before = cols[cols.indexOf(first) - 1];
    const others = cols.filter((c) => c !== first);
    const body = byY.filter((i) => R[i].y > thY + 2 && R[i].y < baseY - 2 && roles[i] === undefined);
    // of the description when it starts where its head does and is no amount under another head
    const off = (r, c) => Math.min(Math.abs(r.x1 - c.x1), Math.abs(r.x - c.x), Math.abs((r.x + r.x1) / 2 - (c.x + c.x1) / 2));
    const inDesc = (r) => r.x >= first.x - 6 - (before ? 0 : 4) && (!after || r.x < after.x - 2) && !(/^[-−]?[\d.,]+\s*(€|EUR|%)?$/.test(r.s.trim()) && others.some((c) => off(r, c) < off(r, first) && off(r, c) < 30));
    const col = (r) => others.reduce((best, c) => (!best || off(r, c) < best.d ? { c, d: off(r, c) } : best), null)?.c;
    const amountCol = cols.find((c) => c.key === 'amount');
    const starts = body.filter((i) => !inDesc(R[i]) && col(R[i]) === amountCol && readMoney(R[i].s) !== null).map((i) => R[i].y).filter((y, k, l) => k === 0 || y - l[k - 1] > 3);
    const rowOf = (y) => { let n = -1; starts.forEach((t, k) => { if (y >= t - 3.5) n = k; }); return n; };
    for (const i of body) {
      const r = R[i]; const n = rowOf(r.y);
      if (inDesc(r)) {
        if (n < 0) { set(i, 'static'); continue; }
        const t = body.find((j) => roles[j] === 'line_title' && line[j] === n); const prev = body.filter((j) => line[j] === n && roles[j] === 'line_title').pop();
        const wraps = t !== undefined && R[t].f === r.f && Math.abs(R[t].z - r.z) < 0.1 && R[t].c === r.c && r.y - R[prev].y < r.z * 1.8;
        set(i, Math.abs(r.y - starts[n]) <= 3.5 || wraps ? 'line_title' : 'line_detail'); line[i] = n;
      } else {
        const role = { qty: 'line_qty', price: 'line_price', disc: 'line_disc', tax: 'line_tax', amount: 'line_amount' }[col(r)?.key];
        if (role) { set(i, role); line[i] = Math.max(0, n); }
      }
    }
    // a heading over a line: the last thing in the description's column before its title, in letters of its own
    const descs = body.filter((i) => ['line_title', 'line_detail', 'static'].includes(roles[i]) && inDesc(R[i]));
    const details = descs.filter((i) => roles[i] === 'line_detail').map((i) => R[i]);
    starts.forEach((t, k) => {
      const title = descs.find((i) => roles[i] === 'line_title' && line[i] === k);
      if (title === undefined) return;
      const above = descs.filter((i) => R[i].y < R[title].y - 3).pop();
      if (above !== undefined && roles[above] !== 'line_title' && headingOf(R[above], details)) { roles[above] = 'line_section'; line[above] = k; }
    });
  }
  // the number: what follows «factura», or the largest text with digits and a dash
  const top = byY.filter((i) => thY === null || R[i].y < thY);
  const kindAt = top.find((i) => /^(factura|invoice|presupuesto|quote)\b/.test(low(R[i].s)));
  if (kindAt !== undefined) {
    if (/^(factura|invoice|presupuesto|quote)$/.test(low(R[kindAt].s))) set(kindAt, 'kind');
  }
  const numbered = top.filter((i) => /\d/.test(R[i].s) && /^[A-Z0-9][A-Z0-9 _./\-–]{1,24}$/i.test(R[i].s) && !readDate(R[i].s) && !TAX_ID.test(R[i].s) && !/^\d{5}\b/.test(R[i].s) && readMoney(R[i].s) === null);
  const score = (i) => R[i].z + (/[-/]\d/.test(R[i].s) ? 6 : 0) + (/20\d\d/.test(R[i].s) ? 4 : 0) + (kindAt !== undefined && Math.abs(R[i].y - R[kindAt].y) < 40 ? 4 : 0);
  let num = numbered.sort((a, b) => score(b) - score(a))[0];
  const inline = top.find((i) => /^(factura|n[uú]mero|presupuesto|invoice|fra)?\.?\s*(n[º°.o]\.?|n[uú]m(ero)?\.?|number|#)?\s*(de factura)?\s*:?\s*\S*\d/i.test(R[i].s) && /n[º°]|n[uú]m|factura|invoice|#/i.test(R[i].s) && numberIn(R[i].s) && !readDate(R[i].s) && !TAX_ID.test(R[i].s));
  if (inline !== undefined && (num === undefined || score(num) < 14)) num = inline;
  if (num !== undefined && (num === inline || score(num) >= 12)) set(num, 'number');
  // dates, by the label above or before them
  const labelOf = (i) => { const r = R[i]; return top.filter((j) => j !== i && ((Math.abs(R[j].x - r.x) < 6 && r.y - R[j].y > 0 && r.y - R[j].y < 24) || (same(i, j, 3) && R[j].x1 <= r.x + 2 && r.x - R[j].x1 < 60))).sort((a, b) => Math.abs(r.y - R[a].y) - Math.abs(r.y - R[b].y))[0]; };
  for (const i of top) {
    const self = low(R[i].s); const l = labelOf(i); const lab = l !== undefined ? low(R[l].s) : '';
    if (readDate(R[i].s)) { const due = /venc|due|pago antes|valid/.test(`${lab} ${self}`); if (!Object.values(roles).includes(due ? 'due_date' : 'issue_date')) { set(i, due ? 'due_date' : 'issue_date'); if (l !== undefined) set(l, 'label'); } }
    else if (l !== undefined && /^(fecha de )?(venc|due)/.test(lab) && lab.length < 26 && !readDate(R[l].s) && !/venc|due/.test(self) && roles[i] === undefined) { set(i, 'due_date'); set(l, 'label'); }
    else if (l !== undefined && /^(referencia|ref\.?|asunto|proyecto|subject)$/.test(lab.replace(/:$/, '')) && roles[i] === undefined) { set(i, 'title_ref'); set(l, 'label'); }
    else if (/^(fecha|date|vencimiento|fecha de vencimiento|emisor|cliente|facturar a|de:?|para:?|bill to|from|forma de pago|notas|observaciones|periodo|referencia|hito)$/.test(self.replace(/:$/, ''))) set(i, 'label');
  }
  // one more fact beside the dates («Período», «Hito», «Pedido»): the company's own, different on each document
  const issue = Object.keys(roles).map(Number).find((i) => roles[i] === 'issue_date');
  const issueLabel = issue === undefined ? undefined : labelOf(issue);
  if (issueLabel !== undefined && R[issue].y > R[issueLabel].y + 4) {
    const beside = top.find((i) => (roles[i] === undefined || roles[i] === 'label') && same(i, issueLabel, 1.5) && i !== issueLabel && R[i].f === R[issueLabel].f && !/venc|due/.test(low(R[i].s)) && top.some((j) => roles[j] === undefined && same(j, issue, 1.5) && Math.abs(R[j].x - R[i].x) < 4));
    if (beside !== undefined) { roles[beside] = 'extra_label'; for (const j of top) if (roles[j] === undefined && Math.abs(R[j].x - R[beside].x) < 4 && R[j].y > R[beside].y && R[j].y - R[issue].y < R[issue].z * 4) roles[j] = 'extra'; }
  }
  // the parties: the block under «cliente» / «emisor», else by their tax IDs
  const blockUnder = (i) => byY.filter((j) => j !== i && R[j].y > R[i].y && R[j].y - R[i].y < 130 && Math.abs(R[j].x - R[i].x) < 4 && (thY === null || R[j].y < thY)).reduce((l, j) => (l.length && R[j].y - R[l[l.length - 1]].y > 30 ? l : l.concat(j)), []);
  const STREET = /^(c\/|calle|carrer|av\.?|avda|avenida|paseo|passeig|plaza|pla[cç]a|pol[ií]gono|ctra|carretera|rambla|ronda|camino|cam[ií]|travessera|urb)\b|\b\d{5}\b/i;
  const party = (who, list) => {
    let named = false;
    for (const j of list) {
      const t = R[j].s;
      if (roles[j] !== undefined && roles[j] !== 'static') continue;
      if (/^(a la atenci[oó]n|att|attn|contacto)\b/i.test(t)) set(j, who === 'client' ? 'client_contact' : 'issuer_contact');
      else if (TAX_ID.test(t)) set(j, `${who}_tax_id`);
      else if (EMAIL.test(t) || /^(tel|telf|m[oó]vil|www\.|https?:|\+?\d[\d ]{7,})/i.test(t)) set(j, who === 'client' ? 'client_email' : 'issuer_contact');
      else if (!named && !STREET.test(t)) { set(j, `${who}_name`); named = R[j].s; }
      else if (who === 'client' && named && low(named).startsWith(low(t))) set(j, 'client_trade');
      else set(j, `${who}_address`);
    }
    return named;
  };
  const at = (re) => top.find((i) => re.test(low(R[i].s).replace(/:$/, '')));
  const cl = at(/^(cliente|facturar a|para|bill to|datos del cliente|destinatario|customer)$/);
  const em = at(/^(emisor|de|from|datos fiscales|proveedor|issuer)$/);
  if (cl !== undefined) { set(cl, 'label'); party('client', blockUnder(cl)); }
  if (em !== undefined) { set(em, 'label'); party('issuer', blockUnder(em)); }
  const ids = top.filter((i) => TAX_ID.test(R[i].s) && roles[i] === undefined);
  const around = (i) => { const up = byY.filter((j) => Math.abs(R[j].x - R[i].x) < 4 && Math.abs(R[j].y - R[i].y) < 75 && (thY === null || R[j].y < thY)); return up; };
  if (em === undefined && ids.length) { const i = ids[0]; party('issuer', around(i)); }
  if (cl === undefined && ids.length > 1) party('client', around(ids[ids.length - 1]));
  // the issuer's name elsewhere: what looks like a company's, or the largest words at the top
  if (!Object.values(roles).includes('issuer_name')) {
    const free = top.filter((i) => (roles[i] === undefined || roles[i] === 'static') && /\p{L}{3}/u.test(R[i].s) && !STREET.test(R[i].s) && !TAX_ID.test(R[i].s) && !readDate(R[i].s));
    const best = free.find((i) => /\b(S\.?\s?L\.?(\s?U\.?)?|S\.?\s?A\.?(\s?U\.?)?|S\.?\s?C\.?\s?P?\.?|S\.?\s?Coop\.?|C\.?\s?B\.?)\s*$/i.test(R[i].s)) ?? free.sort((a, b) => R[b].z - R[a].z)[0];
    if (best !== undefined) roles[best] = 'issuer_name';
  }
  // how to pay, notes, the foot
  const after = byY.filter((i) => Number.isFinite(baseY) && R[i].y > baseY - 2);
  const totalY = Math.max(-1, ...Object.entries(roles).filter(([, r]) => r === 'total').map(([i]) => R[i].y));
  const issuerName = Object.entries(roles).find(([, r]) => r === 'issuer_name'); const iname = issuerName ? low(R[issuerName[0]].s) : '';
  for (const i of after) {
    if (R[i].y <= totalY + 3 || roles[i] !== undefined) continue;
    const s = low(R[i].s);
    if (/^(forma de pago|metodo de pago|datos bancarios|pago|payment|notas|observaciones|notes|condiciones|terminos)$/.test(s.replace(/:$/, ''))) set(i, 'label');
    else if (IBAN.test(R[i].s)) set(i, 'iban');
    else if (/^(transferencia|tarjeta|domiciliacion|bizum|efectivo|bank transfer)/.test(s)) set(i, 'pay_method');
    else if (/^(bic|swift)/.test(s)) set(i, 'bic');
  }
  const lab = (re) => after.find((i) => re.test(low(R[i].s).replace(/:$/, '')) && roles[i] === 'label');
  const blockBelow = (i, reach = 200) => after.filter((j) => j !== i && R[j].y > R[i].y && R[j].y - R[i].y < reach && R[j].x >= R[i].x - 4 && !after.some((k) => k !== i && roles[k] === 'label' && R[k].y <= R[j].y && R[k].y > R[i].y - 3 && R[k].x > R[i].x + 20 && R[k].x <= R[j].x + 4)).reduce((l, j) => (l.stop || (l.length && R[j].y - R[l[l.length - 1]].y > 36) || roles[j] === 'label' ? Object.assign(l, { stop: true }) : Object.assign(l.concat(j), {})), []);
  const footY = page.rules.filter((r) => r[1] > totalY + 10 && r[2] - r[0] > page.w * 0.5).map((r) => r[1]).sort((a, b) => b - a)[0] ?? Infinity;
  const keys = [[/^iban$/, 'iban'], [/^(titular|beneficiario|account holder)$/, 'holder'], [/^(banco|entidad|bank)$/, 'bank'], [/^(bic|swift|bic ?\/ ?swift)$/, 'bic']];
  for (const i of after) { const k = keys.find(([re]) => re.test(low(R[i].s).replace(/:$/, ''))); const v = k && after.filter((j) => j !== i && same(i, j, 1.5) && R[j].x > R[i].x).sort((a, b) => R[a].x - R[b].x)[0]; if (v !== undefined) { roles[i] = 'pay_key'; roles[v] = k[1]; } }
  const pay = lab(/^(forma de pago|metodo de pago|datos bancarios|pago|payment)$/);
  if (pay !== undefined) for (const j of blockBelow(pay)) { if (R[j].y > footY) continue; const s = low(R[j].s); if (roles[j] === undefined) set(j, iname && s === iname ? 'holder' : R[j].s.length > 44 || /indi[cq]|concepto|n[uú]mero de|referencia|plazo/.test(s) || Object.values(roles).includes('pay_key') ? 'pay_note' : 'bank'); }
  const note = lab(/^(notas|observaciones|notes|condiciones|terminos)$/);
  if (note !== undefined) for (const j of blockBelow(note, 260)) { if (R[j].y > footY || roles[j] !== undefined) continue; const s = low(R[j].s); set(j, /gracias|thank/.test(s) ? 'thanks' : 'notes'); }
  // «indicar el número de factura en el concepto»: the same on every invoice
  const number = num !== undefined ? R[num].s : null;
  if (number) {
    const here = after.filter((i) => roles[i] === 'notes' || R[i].s.includes(number) && R[i].y < footY);
    for (const i of here) if (R[i].s.includes(number) && R[i].y < footY && roles[i] !== 'th') { roles[i] = 'pay_note'; for (const j of here) if (same(i, j, 1.5) || (R[j].y > R[i].y && R[j].y - R[i].y < R[i].z * 1.9 && Math.abs(R[j].x - (R[here.find((k) => same(i, k, 1.5) && R[k].x <= R[i].x)] || R[i]).x) < 3)) if (roles[j] === 'notes') roles[j] = 'pay_note'; }
  }
  for (const i of byY) if (roles[i] === undefined) roles[i] = R[i].y > footY || R[i].y > page.h * 0.93 ? 'footer' : 'static';
  const need = ['number', 'issue_date', 'issuer_name', 'client_name', 'th', 'line_title', 'line_amount', 'total'];
  const have = new Set(Object.values(roles));
  const missing = need.filter((r) => !have.has(r));
  return { roles, line, missing, sure: 1 - missing.length / need.length };
}

/** Runs on one baseline, side by side, as one line → [{ x, x1, y, z, f, c, ls, s, parts: [run] }], top to bottom. */
export function mergeLines(runs) {
  const out = [];
  for (const r of [...runs].sort((a, b) => a.y - b.y || a.x - b.x)) {
    const l = out.find((k) => Math.abs(k.y - r.y) < 0.8 && r.x - k.x1 < Math.max(6, r.z * 0.9) && r.x - k.x1 > -3);
    if (l) { l.s += (r.lead || l.tail || (r.x - l.x1 > r.z * 0.18) ? ' ' : '') + r.s.replace(/^\s+/, ''); l.x1 = r.x1; l.tail = r.tail; l.parts.push(r); } else out.push({ ...r, s: r.s.replace(/^\s+/, ''), parts: [r] });
  }
  return out;
}
const firstWord = (s) => /^\S+/.exec(s)?.[0] || '';
const perChar = (l) => (l.x1 - l.x) / Math.max(1, l.s.length);
/** The right edge some wrapped lines were broken at: between the longest one and what a broken one could not take. */
export function wrapLimit(lines) { const { lo, hi } = wrapBounds(lines); return Number.isFinite(hi) ? (lo + hi) / 2 : lo + 2; }
export function wrapBounds(lines) {
  const lo = Math.max(0, ...lines.map((l) => l.x1));
  let hi = Infinity;
  for (let i = 0; i + 1 < lines.length; i += 1) {
    const a = lines[i]; const b = lines[i + 1];
    if (b.y - a.y > a.z * 2.1 || Math.abs(a.x - b.x) > 3 || a.f !== b.f) continue;
    const would = a.x1 + perChar(a) * (firstWord(b.s).length + 1) * 0.94;
    if (would > lo && (/^[(0-9\p{Ll}]/u.test(b.s) || /[,·\-–]$/.test(a.s)) && would < hi) hi = would;
  }
  return { lo, hi };
}
const minGap = (lines) => Math.min(Infinity, ...lines.slice(1).map((l, i) => l.y - lines[i].y).filter((g) => g > 2));
/** Wrapped lines → its paragraphs as they were written (a blank one where the page leaves one). */
export function joinWrapped(lines, limit) {
  const out = [];
  const step = minGap(lines);
  lines.forEach((l, i) => {
    const p = lines[i - 1];
    const blank = p && l.y - p.y > Math.max(p.z * 2.3, step * 1.55);
    const soft = p && !blank && p.x1 + perChar(p) * (firstWord(l.s).length + 1) > limit - (/^\p{Ll}/u.test(l.s) ? 8 : 0) && Math.abs(p.x - l.x) < 3;
    if (!p) out.push(l.s);
    else if (soft) out[out.length - 1] += (/[-–]$/.test(p.s) && /^\d/.test(l.s) ? '' : ' ') + l.s;
    else { if (blank) out.push(''); out.push(l.s); }
  });
  return out;
}

/** What the document says, as data: from the roles → { number, issue_date, client, lines, totals, pay… } (amounts in cents). */
export function factsOf(page, { roles, line }) {
  const R = page.runs;
  const of = (r) => Object.keys(roles).filter((i) => roles[i] === r).map(Number).sort((a, b) => R[a].y - R[b].y || R[a].x - R[b].x);
  const text = (r) => { const l = of(r); return l.length ? flat(l.map((i) => R[i].s).join(' ')) : ''; };
  const lines = (r) => of(r).map((i) => flat(R[i].s));
  const limits = { detail: wrapLimit(mergeLines(of('line_detail').map((i) => R[i]))) };
  const noteX = of('notes').map((i) => R[i].x); const inNotes = (i) => !noteX.length ? lab(i) : R[i].x >= Math.min(...noteX) - 3;
  const lab = (i) => { const t = Object.keys(roles).filter((j) => roles[j] === 'label' && /^(notas|observaciones|notes)/.test(low(R[j].s))).map(Number)[0]; return t !== undefined && R[i].x >= R[t].x - 3 && R[i].y > R[t].y; };
  const noteLines = mergeLines([...of('notes'), ...of('pay_note').filter(inNotes)].map((i) => R[i]));
  const edge = Math.max(0, ...page.rules.filter((r) => r[2] - r[0] > page.w * 0.4).map((r) => r[2]), ...noteLines.map((l) => l.x1));
  const noteText = joinWrapped(noteLines, edge).join('\n');
  const payLines = mergeLines(of('pay_note').map((i) => R[i]));
  const taxId = (r) => { const m = TAX_ID.exec(text(r)); return m ? m[0].toUpperCase().replace(/[ -]/g, '') : ''; };
  const date = (r) => readDate(text(r));
  const n = new Set(Object.values(line || {}));
  const items = [...n].sort((a, b) => a - b).map((k) => {
    const pick = (r) => of(r).filter((i) => line[i] === k);
    const num = (r) => { const i = pick(r)[0]; return i === undefined ? null : readMoney(R[i].s); };
    const qty = num('line_qty');
    return { title: flat(mergeLines(pick('line_title').map((i) => R[i])).map((l) => l.s).join(' ')), section: flat(pick('line_section').map((i) => R[i].s).join(' ')), detail: joinWrapped(mergeLines(pick('line_detail').map((i) => R[i])), limits.detail), qty: qty === null ? 1 : qty / 100, price: num('line_price'), disc: num('line_disc'), tax: num('line_tax'), amount: num('line_amount') };
  }).filter((l) => l.title);
  const rateOf = (r) => { const m = /(\d{1,2}(?:[.,]\d{1,2})?)\s*%/.exec(text(r)); return m ? Number(m[1].replace(',', '.')) : null; };
  const due = date('due_date');
  return {
    kind: /presupuesto|quote/i.test(text('kind')) ? 'quote' : 'invoice', number: /[:ºº°#]|\s/.test(text('number')) && numberOfText(text('number')) || text('number'), issue_date: date('issue_date')?.iso || '', due_date: due?.iso || '', due_terms: due ? '' : text('due_date'),
    issuer: { name: text('issuer_name'), tax_id: taxId('issuer_tax_id'), address: lines('issuer_address'), email: (EMAIL.exec(text('issuer_contact')) || [''])[0] },
    client: { name: text('client_name'), trade: text('client_trade'), contact: text('client_contact').replace(/^.*:\s*/, ''), tax_id: taxId('client_tax_id'), address: lines('client_address'), email: (EMAIL.exec(text('client_email')) || [''])[0] },
    lines: items, base: of('base').length ? readMoney(R[of('base')[0]].s) : null, tax: of('tax').length ? of('tax').reduce((a, i) => a + (readMoney(R[i].s) || 0), 0) : null, tax_rate: rateOf('tax_label'),
    withholding: of('withholding').length ? Math.abs(readMoney(R[of('withholding')[0]].s) || 0) : null, withholding_rate: rateOf('withholding_label'), total: of('total').length ? readMoney(R[of('total')[0]].s) : null,
    pay: { iban: (IBAN.exec(text('iban')) || [''])[0], holder: text('holder'), bank_name: text('bank'), bic: text('bic').replace(/^.*[:\s]/, ''), method: text('pay_method') }, pay_note: joinWrapped(payLines, Infinity).join(' '), notes: noteText, thanks: text('thanks'), title: text('title_ref'), extra: text('extra'), extra_label: text('extra_label'),
  };
}

// ── the template ───────────────────────────────────────────────────────
const near = (a, b, e = 2) => Math.abs(a - b) <= e;
const r2 = (n) => Math.round(n * 100) / 100;
const r3 = (n) => Math.round(n * 1000) / 1000;
/** The leading some lines were set with: a whole twentieth of their size when it fits what is printed (each line snaps to the screen's pixel). */
const leading = (avg, z, n) => { const k = Math.round((avg / z) * 20) / 20; return Math.abs(k * z - avg) <= 0.8 / Math.max(1, n) + 0.02 ? r3(k * z) : r3(avg); };
const bare = (f) => String(f || '').replace(/^[A-Z]{6}\+/, '');
/** From the top of a line to its baseline, in points: the browser rounds a letter's box, and half the leading, to whole pixels. */
export const baseOf = (f, z, lh) => { const px = z / 0.75; const a = Math.round((f.asc ?? 0.97) * px); const d = Math.round((f.desc ?? 0.25) * px); return (Math.floor((lh / 0.75 - a - d) / 2) + a) * 0.75; };
export const isHex = (c) => /^#[0-9a-f]{6}$/i.test(String(c || ''));
const chroma = (hex) => { const [r, g, b] = [1, 3, 5].map((i) => parseInt(hex.slice(i, i + 2), 16)); return Math.max(r, g, b) - Math.min(r, g, b); };
const lum = (hex) => { const [r, g, b] = [1, 3, 5].map((i) => parseInt(hex.slice(i, i + 2), 16)); return 0.299 * r + 0.587 * g + 0.114 * b; };
const rx = (s) => String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

/**
 * The template of a company's documents, from one printed example. page: what the platform read; labels: labelRuns(page);
 * fit: { [printed letter's name]: { family, google, weight, italic, bo, generic } } measured on screen; others: more examples
 * [{ page, labels }] of the same company (what varies between them is theirs, never fixed text).
 */
export function buildOwn(page, labels, fit = {}, { others = [], name = '' } = {}) {
  const R = page.runs.map((r, i) => ({ ...r, i, role: labels.roles[i] || 'static', rx1: r.x1 + (r.ls || 0) }));
  const facts = factsOf(page, labels);
  const styles = []; const fonts = {};
  const styleOf = (r) => {
    const key = bare(r.f);
    const f = fit[r.f] || fit[key] || { family: 'Inter', google: 'family=Inter:wght@400;500;600;700', weight: 400, asc: 0.97, desc: 0.25, generic: 'sans-serif' };
    const fk = `${f.family}|${f.weight}|${f.italic ? 1 : 0}${f.opsz ? `|${f.opsz}` : ''}${f.tnum ? '|t' : ''}`;
    if (!fonts[fk]) fonts[fk] = { family: f.family, google: f.google || '', weight: f.weight, italic: !!f.italic, asc: f.asc ?? 0.97, desc: f.desc ?? 0.25, generic: f.generic || 'sans-serif', ...(f.opsz ? { opsz: f.opsz } : {}), ...(f.tnum ? { tnum: 1 } : {}) };
    const z = r.z; const ls = r.ls && Math.abs(r.ls) > z * 0.012 ? r3(r.ls) : 0;
    const at = styles.findIndex((x) => x.f === fk && near(x.z, z, 0.02) && x.c === r.c && near(x.ls, ls, 0.03));
    if (at >= 0) return at;
    styles.push({ f: fk, z, c: r.c, ls });
    return styles.length - 1;
  };
  // texts as patterns: what is the document's own becomes its name
  const known = [[facts.number, '{number}'], [facts.issuer.name, '{issuer.name}'], [facts.issuer.email, '{issuer.email}'], ...facts.issuer.address.map((a, i) => [a, `{issuer.address.${i}}`])].filter(([v]) => v && v.length > 3).sort((a, b) => b[0].length - a[0].length);
  const pattern = (text) => {
    let t = text;
    if (facts.issuer.tax_id) { const m = TAX_ID.exec(t); if (m && m[0].toUpperCase().replace(/[ -]/g, '') === facts.issuer.tax_id) t = t.replace(m[0], '{issuer.tax_id}'); }
    for (const [v, k] of known) t = t.replace(new RegExp(rx(v), 'gi'), (hit) => (k === '{number}' && hit !== v ? hit : hit !== v && hit === hit.toLocaleUpperCase('es') ? k.toUpperCase() : k));
    t = t.replace(/(p[aá]g(?:ina|\.)?\s*)\d+(\s*(?:de|\/)\s*)\d+/i, '$1{page}$2{pages}');
    return t;
  };
  const span = (r) => ({ s: styleOf(r), t: textOf(r) });
  const textOf = (r) => {
    const t = r.s.replace(/\s+/g, ' ');
    const put = (re, k) => { const m = re.exec(t); return m ? t.replace(m[0], k) : k; };
    switch (r.role) {
      case 'kind': return t === t.toUpperCase() ? '{KIND}' : '{kind}';
      case 'number': return t.trim() === facts.number || !facts.number ? '{number}' : t.replace(facts.number, '{number}');
      case 'issue_date': { const d = readDate(t); return d ? t.replace(d.said, '{issue_date}') : '{issue_date}'; }
      case 'due_date': { const d = readDate(t); return d ? t.replace(d.said, '{due}') : '{due}'; }
      case 'issuer_name': return '{issuer.name}';
      case 'issuer_tax_id': return put(TAX_ID, '{issuer.tax_id}');
      case 'client_name': return '{client.name}';
      case 'client_tax_id': return put(TAX_ID, '{client.tax_id}');
      case 'client_email': return put(EMAIL, '{client.email}');
      case 'client_contact': return /:/.test(t) ? t.replace(/:.*$/, ': {client.contact}') : '{client.contact}';
      case 'client_trade': return '{client.trade}';
      case 'title_ref': return '{title}';
      case 'pay_key': { const same = R.find((q) => ['iban', 'holder', 'bank', 'bic'].includes(q.role) && Math.abs(q.y - r.y) < 1.5); return same ? `${t}{?pay.${{ iban: 'iban', holder: 'holder', bank: 'bank_name', bic: 'bic' }[same.role]}}` : t; }
      case 'extra_label': return t === t.toUpperCase() ? '{EXTRA_LABEL}' : '{extra.label}';
      case 'extra': return '{extra.value}';
      case 'iban': return put(IBAN, '{pay.iban}');
      case 'holder': return facts.issuer.name && low(t) === low(facts.issuer.name) ? '{pay.holder}' : t.replace(facts.pay.holder, '{pay.holder}');
      case 'bank': return '{pay.bank_name}';
      case 'thanks': return '{thanks}';
      case 'bic': return /[:\s]/.test(t.trim()) ? t.replace(/\S+$/, '{pay.bic}') : '{pay.bic}';
      case 'tax_label': return t.replace(/\d{1,2}(?:[.,]\d+)?(?=\s*%)/, '{rate}');
      case 'withholding_label': return t.replace(/\d{1,2}(?:[.,]\d+)?(?=\s*%)/, '{rate}');
      case 'issuer_contact': return pattern(t);
      case 'label': case 'th': return t;
      default: return pattern(t);
    }
  };
  // ── the page's regions
  const W = page.w; const H = page.h;
  const isH = (r) => r[2] - r[0] > (r[3] - r[1]) * 3;
  const hr = page.rules.filter(isH).map((r) => ({ x: r[0], y: r[1], x1: r[2], y1: r[3], c: r[4] }));
  const vr = page.rules.filter((r) => !isH(r)).map((r) => ({ x: r[0], y: r[1], x1: r[2], y1: r[3], c: r[4] }));
  const printed = R.filter((r) => r.s.trim());
  const x0 = Math.min(...printed.map((r) => r.x), ...hr.map((r) => r.x)); const x1 = Math.max(...printed.map((r) => Math.min(r.rx1, W)), ...hr.map((r) => r.x1));
  const wide = hr.filter((r) => r.x1 - r.x > (x1 - x0) * 0.62);
  const th = R.filter((r) => r.role === 'th');
  const inTable = (r) => r.role === 'th' || r.role.startsWith('line_');
  const tableRuns = R.filter(inTable);
  const thBase = Math.min(...th.map((r) => r.y));
  const lastLine = Math.max(thBase, ...tableRuns.map((r) => r.y));
  const totalsRuns = R.filter((r) => /^(base|tax|withholding|total)(_label)?$/.test(r.role));
  const footRuns = R.filter((r) => r.role === 'footer');
  const footBase = footRuns.length ? Math.min(...footRuns.map((r) => r.y - r.z)) : H - 30;
  const bodyEnd = Math.max(lastLine, ...R.filter((r) => r.role !== 'footer').map((r) => r.y));
  const footRule = wide.filter((r) => r.y > bodyEnd - 1 && r.y < footBase + 2).sort((a, b) => b.y - a.y)[0];
  const footTop = footRule ? footRule.y : footBase - 6;
  const headEnd = Math.max(0, ...wide.filter((r) => r.y1 < thBase - th[0].z * 0.6).map((r) => r.y1), ...R.filter((r) => !inTable(r) && r.y < thBase - 2).map((r) => r.y + r.z * 0.25), ...[...hr, ...vr].filter((r) => r.y1 < thBase - th[0].z * 1.1).map((r) => r.y1), ...(page.boxes || []).filter((b) => b[3] < thBase - th[0].z).map((b) => b[3]));
  const under = hr.filter((r) => r.y > thBase - 1 && r.y < thBase + 30 && r.x1 - r.x > (x1 - x0) * 0.5 && !tableRuns.some((t) => t.role !== 'th' && t.y < r.y)).sort((a, b) => a.y - b.y)[0];
  const afterTable = hr.filter((r) => r.y >= lastLine && r.x1 - r.x > (x1 - x0) * 0.5 && !R.some((t) => !inTable(t) && t.y > lastLine && t.y < r.y)).sort((a, b) => a.y - b.y)[0];
  const tableEnd = afterTable ? afterTable.y1 : lastLine + 6;

  // ── stacks of lines in a region
  const logoImg = page.images.slice().sort((a, b) => (a.y > H * 0.4) - (b.y > H * 0.4) || (b.x1 - b.x) * (b.y1 - b.y) - (a.x1 - a.x) * (a.y1 - a.y))[0] || null;
  const measured = {};
  const stacksOf = (runs, top, bottom, boxes) => {
    const lines = mergeLines(runs).map((l) => ({ ...l, rx1: Math.max(...l.parts.map((p) => p.rx1)), role: (l.parts.find((p) => !['static', 'label'].includes(p.role)) || l.parts[0]).role }));
    const stacks = [];
    for (const l of lines) {
      const left = stacks.find((k) => k.a !== 'r' && near(k.x, l.x, 1.6) && !overlapped(stacks, k, l));
      const right = stacks.find((k) => (k.a === 'r' || k.lines.length === 1) && near(k.x1, l.rx1, 1.8) && !near(k.x, l.x, 1.6));
      if (left) { left.lines.push(l); if (left.lines.length > 1 && !left.a) left.a = 'l'; left.x1 = Math.max(left.x1, l.rx1); } else if (right) { right.a = 'r'; right.lines.push(l); right.x = Math.min(right.x, l.x); } else stacks.push({ x: l.x, x1: l.rx1, a: null, lines: [l] });
    }
    const mid = (x0 + x1) / 2;
    for (const k of stacks) if (!k.a) k.a = near(k.x1, x1, 2.5) && k.x > mid ? 'r' : near((k.x + k.x1) / 2, mid, 2) && k.x > x0 + 20 ? 'c' : 'l';
    return stacks.map((k) => {
      const beside = stacks.filter((o) => o !== k && o.x > k.x + 4 && o.lines.some((a) => k.lines.some((b) => a.y > b.y - 60 && a.y < b.y + 60))).map((o) => (o.a === 'r' ? o.x : o.x)).sort((a, b) => a - b)[0];
      const bar = vr.filter((v) => v.x > k.x && v.y < k.lines[0].y && v.y1 > k.lines[0].y).map((v) => v.x).sort((a, b) => a - b)[0];
      const hard = Math.min(bar ?? Infinity, beside !== undefined ? beside - 6 : Infinity, Math.max(x1, k.x1) + 0.4);
      const para = k.lines.filter((l) => l.role === 'notes' || l.role === 'pay_note' || l.role === 'extra');
      const wb = para.length > 1 ? wrapBounds(para) : null;
      const limit = k.a === 'l' ? Math.max(k.x1 + 0.4, wb && Number.isFinite(wb.hi) && hard > wb.hi ? (wb.lo + wb.hi) / 2 : hard) : k.x1;
      const out = []; let prev = top;
      for (let i = 0; i < k.lines.length; i += 1) {
        const l = k.lines[i];
        const group = /^(notes|pay_note|client_name|issuer_name|extra|thanks|legal|client_address|issuer_address|due_date)$/.test(l.role) ? l.role : null;
        const item = { d: r2(l.y - prev), role: l.role, spans: spansOf(l), lh: r2(l.z * 1.5) };
        if (group) {
          // the same thing on several lines: one block that wraps, or one line each (an address)
          let j = i; const step = [];
          const block = (role) => (role === 'notes' || role === 'pay_note' ? 'notes' : role);
          while (j + 1 < k.lines.length && block(k.lines[j + 1].role) === block(l.role)) { step.push(k.lines[j + 1].y - k.lines[j].y); j += 1; }
          const even = step.filter((g) => g < Math.min(l.z * 2.2, Math.min(...step) * 1.5)); if (even.length) { item.lh = leading(even.reduce((a, b) => a + b, 0) / even.length, l.z, even.length); measured[item.spans[0].s] = item.lh; }
          if (/address$/.test(group)) { item.each = group === 'client_address' ? 'client.address' : 'issuer.address'; item.spans = [{ s: styleOf(l.parts[0]), t: '{.}' }]; item.de = step.length ? leading(step.reduce((a, b) => a + b, 0) / step.length, l.z, step.length) : r2(l.z * 1.6); }
          else if (group === 'notes' || group === 'pay_note') {
            item.role = 'notes'; item.block = 'notes'; item.hasNotes = k.lines.slice(i, j + 1).some((x) => x.role === 'notes') || /^(notas|observaciones|notes)/.test(low(k.lines[0].s)); item.hasPayNote = k.lines.slice(i, j + 1).some((x) => x.role === 'pay_note');
            const main = k.lines.slice(i, j + 1).flatMap((x) => x.parts).sort((a, b) => b.s.length - a.s.length)[0];
            item.spans = [{ s: styleOf(main), t: '{notes}' }];
            const em = k.lines.slice(i, j + 1).flatMap((x) => x.parts).find((p) => facts.number && p.s.includes(facts.number) && p.f !== main.f);
            if (em) item.em = styleOf(em);
            const bl = step.find((g) => g > item.lh * 1.5); if (bl) item.blank = r2(bl - item.lh);
          } else if (j > i) item.spans = [item.spans[0]];
          if (group === 'extra' && j > i) item.spans = [{ ...item.spans[0], t: '{extra.value}' }];
          i = j; prev = k.lines[j].y;
        } else prev = l.y;
        out.push(item);
      }
      return { x: r2(k.x), x1: r2(limit), a: k.a, end: r2(Math.max(...k.lines.map((l) => l.y)) - top), lines: out };
    });
    function spansOf(l) {
      const list = l.parts.map(span);
      const gapOf = (i) => (i ? l.parts[i].x - l.parts[i - 1].x1 : 0);
      const full = list.map((s, i) => ({ ...s, ...(gapOf(i) > l.parts[i].z * 0.5 ? { g: r2(gapOf(i) - (l.parts[i - 1].ls || 0)) } : {}), t: (i && gapOf(i) <= l.parts[i].z * 0.5 && (l.parts[i].lead || l.parts[i - 1].tail || l.parts[i].x - l.parts[i - 1].x1 > l.parts[i].z * 0.18) ? ' ' : '') + s.t.trim() }));
      return full;
    }
    function overlapped(all, k, l) { return all.some((o) => o !== k && o.a === 'l' && false && l); }
  };
  const bandsOf = (runs, from, to, rules) => {
    const marks = rules.filter((r) => r.y >= from - 0.5 && r.y1 <= to + 0.5).sort((a, b) => a.y - b.y);
    const out = []; let top = from;
    const push = (bottom) => {
      const mine = runs.filter((r) => r.y > top - 0.2 && r.y <= bottom + 0.2);
      const bars = vr.filter((v) => v.y >= top - 2 && v.y1 <= bottom + 2 && !(tb && v.x > tb.x - 14 && v.x1 < tb.x1 + 14 && v.y > tb.y - 14 && v.y1 < tb.y1 + 14)).map((v) => ({ x: r2(v.x), w: r2(v.x1 - v.x), c: v.c, y: r2(v.y - top), h: r2(v.y1 - v.y), full: v.y1 - v.y > (bottom - top) * 0.85 }));
      const boxes = (page.boxes || []).filter((b) => !(tb && b[0] >= tb.x - 16 && b[2] <= tb.x1 + 16 && b[1] > tb.y - 16 && b[3] < tb.y1 + 16) && b[1] >= top - 2 && b[3] <= bottom + 2).map((b) => ({ x: r2(b[0]), w: r2(b[2] - b[0]), y: r2(b[1] - top), h: r2(b[3] - b[1]), c: b[4], full: b[3] - b[1] > (bottom - top) * 0.85 }));
      const small = hr.filter((r) => !wide.includes(r) && r.y > top && r.y1 < bottom && !(totalsBox && r.y > totalsBox.y - 1 && r.y1 < totalsBox.y1 + 1 && r.x > totalsBox.x - 5)).map((r) => ({ x: r2(r.x), w: r2(r.x1 - r.x), y: r2(r.y - top), h: r2(r.y1 - r.y), c: r.c }));
      const logo = logoImg && logoImg.y >= top - 2 && logoImg.y1 <= bottom + 2 ? { x: r2(logoImg.x), y: r2(logoImg.y - top), w: r2(logoImg.x1 - logoImg.x), h: r2(logoImg.y1 - logoImg.y), a: logoImg.x > (x0 + x1) / 2 ? 'r' : 'l' } : null;
      const tot = totalsBox && totalsBox.y >= top - 1 && totalsBox.y <= bottom ? totals(top) : null;
      const st = stacksOf(mine.filter((r) => !(tot && totalsRuns.includes(r))), top, bottom, boxes);
      const end = Math.max(0, ...st.map((k) => k.end), logo ? logo.y + logo.h : 0, tot ? tot.end : 0);
      if (!mine.length && !logo && !tot && bottom - top < 1) return;
      out.push({ k: 'band', h: r2(bottom - top), pb: r2(Math.max(0, bottom - top - end)), stacks: st, bars, boxes, small, logo, totals: tot });
    };
    for (const m of marks) { push(m.y); out.push({ k: 'rule', x: r2(m.x), w: r2(m.x1 - m.x), t: r2(m.y1 - m.y), c: m.c }); top = m.y1; }
    push(to);
    return out;
  };
  // ── the totals: rows of a label and its amount, and the rules between them
  const tb = totalsRuns.length ? { x: Math.min(...totalsRuns.map((r) => r.x)), x1: Math.max(...totalsRuns.map((r) => r.rx1)), y: Math.min(...totalsRuns.map((r) => r.y - r.z)), y1: Math.max(...totalsRuns.map((r) => r.y + r.z * 0.4)) } : null;
  const totalsBox = tb && { ...tb };
  const ofRule = (r) => tb && r.x >= tb.x - 14 && r.x1 <= tb.x1 + 14 && r.y > tb.y - 4 && r.y1 < tb.y1 + 14 && !wide.includes(r);
  const totals = (top) => {
    const inner = hr.filter(ofRule);
    const fills = (page.boxes || []).filter((b) => b[0] >= tb.x - 16 && b[2] <= tb.x1 + 16 && b[1] > tb.y - 16 && b[3] < tb.y1 + 16);
    const x = Math.min(tb.x, ...inner.map((r) => r.x)); const xe = Math.max(tb.x1, ...inner.map((r) => r.x1));
    const rows = [];
    for (const key of ['base', 'tax', 'withholding', 'total']) {
      const vals = R.filter((r) => r.role === key).sort((a, b) => a.y - b.y); const labs = R.filter((r) => r.role === `${key}_label`).sort((a, b) => a.y - b.y);
      const v = vals[0]; const l = labs[0];
      if (!v) continue;
      rows.push({ k: 'row', key, y: l ? l.y : v.y, last: vals[vals.length - 1].y, dy: l ? r2(v.y - l.y) : 0, label: l ? [span(l)] : null, lx: l ? r2(l.x - x) : 0, value: [{ s: styleOf(v), t: `{${key}}` }], vx: r2(xe - v.rx1) });
    }
    for (const row of rows) { const b = fills.find((q) => q[1] < row.y - 2 && q[3] > row.y); if (b) row.fill = { c: b[4], x: r2(b[0] - x), w: r2(b[2] - b[0]), dy: r2(b[1] - row.y), h: r2(b[3] - b[1]) }; }
    const items = [...rows, ...inner.map((r) => ({ k: 'rule', y: r.y, t: r2(r.y1 - r.y), c: r.c, x: r2(r.x - x), w: r2(r.x1 - r.x) }))].sort((a, b) => a.y - b.y);
    let prev = top;
    for (const it of items) { it.d = r2(it.y - prev); prev = it.k === 'rule' ? it.y + it.t : Math.max(it.y, it.last || it.y); }
    const maxDy = Math.max(0, ...rows.map((r) => r.y + r.dy)) - prev;
    const end = r2(prev - top + Math.max(0, maxDy));
    const bars = vr.filter((v) => v.x > x - 14 && v.x1 < xe + 14 && v.y > tb.y - 14 && v.y1 < tb.y1 + 14).reduce((l, v) => { const o = l.find((q) => Math.abs(q.x - v.x) < 1); if (o) { o.y = Math.min(o.y, v.y); o.y1 = Math.max(o.y1, v.y1); } else l.push({ ...v }); return l; }, []);
    return { x: r2(x), x1: r2(xe), end, items: items.map(({ y, last, ...k }) => k), bars: bars.map((v) => ({ x: r2(v.x - x), w: r2(v.x1 - v.x), c: v.c, y: r2(v.y - top), b: r2(end - (v.y1 - top)) })) };
  };
  const head = bandsOf(R.filter((r) => !inTable(r) && r.y < thBase - 2), 0, headEnd, wide.filter((r) => r.y1 <= headEnd + 0.5));
  const tail = bandsOf(R.filter((r) => !inTable(r) && r.role !== 'footer' && r.y > lastLine), tableEnd, footTop, wide.filter((r) => r.y >= tableEnd && r.y1 < footTop));
  // an email under the client's details when another example prints one
  if (others.some((o) => Object.values(o.labels.roles).includes('client_email'))) for (const b of head) for (const k of b.stacks || []) {
    const at = k.lines.map((l) => l.role).lastIndexOf('client_address');
    if (at >= 0 && !head.some((x) => (x.stacks || []).some((y) => y.lines.some((l) => l.role === 'client_email')))) k.lines.splice(at + 1, 0, { d: k.lines[at].de || r2(styles[k.lines[at].spans[0].s].z * 1.6), role: 'client_email', spans: [{ s: k.lines[at].spans[0].s, t: '{client.email}' }], lh: k.lines[at].lh });
  }
  // the leading one block shows is that of every line set alike: side by side they stand on the same line
  for (const b of [...head, ...tail]) for (const k of b.stacks || []) for (const l of k.lines) if (measured[l.spans[0].s]) l.lh = measured[l.spans[0].s];
  const foot = bandsOf(footRuns, footTop, H, wide.filter((r) => r.y >= footTop - 0.5));

  for (let i = foot.length - 1; i >= 0; i -= 1) if (foot[i].k === 'band') { foot[i].pb = Math.min(foot[i].pb, 4); break; }
  // a foot that follows what is above it, or one fixed at the bottom: the examples tell, or the room left under it
  const tailEnd = Math.max(tableEnd, ...R.filter((r) => r.role !== 'footer' && !inTable(r)).map((r) => r.y));
  const footEnd = footRuns.length ? Math.max(...footRuns.map((r) => r.y + r.z * 0.3)) : footTop;
  const top0 = Math.min(...R.map((r) => r.y - r.z), ...(logoImg ? [logoImg.y] : []));
  const footsAt = others.filter((o) => Math.abs(Math.min(...o.page.runs.map((r) => r.x)) - x0) < 1 && Object.values(o.labels.roles).includes('footer') && Object.values(o.labels.roles).includes('total')).map((o) => Math.min(...Object.keys(o.labels.roles).filter((i) => o.labels.roles[i] === 'footer').map((i) => o.page.runs[i].y)));
  const footFlows = footsAt.length ? footsAt.some((y) => Math.abs(y - Math.min(...footRuns.map((r) => r.y))) > 3) : footRuns.length > 0 && footTop - tailEnd < 46 && H - footEnd > top0 + 22;

  // ── the table
  const cols = th.slice().sort((a, b) => a.x - b.x).map((r) => ({ r, key: colKey(r.s) }));
  if (cols[0] && !cols.some((c) => c.key === 'desc')) cols[0].key = cols[0].key === 'n' ? 'n' : 'desc';
  const roleKey = { qty: 'line_qty', price: 'line_price', disc: 'line_disc', tax: 'line_tax', amount: 'line_amount' };
  const descRuns = tableRuns.filter((r) => ['line_title', 'line_detail', 'line_section'].includes(r.role));
  const colDefs = cols.filter((c) => c.key).map((c) => {
    const cells = roleKey[c.key] ? tableRuns.filter((r) => r.role === roleKey[c.key]) : descRuns;
    const right = cells.length && c.key !== 'desc' ? (near(Math.max(...cells.map((q) => q.rx1)), c.r.rx1, 3) ? 'r' : near(cells[0].x, c.r.x, 2) ? 'l' : 'c') : c.key === 'desc' ? 'l' : 'r';
    const edge = right === 'r' ? Math.max(c.r.rx1, ...cells.map((q) => q.rx1)) : right === 'l' ? c.r.x : (c.r.x + c.r.rx1) / 2;
    return { key: c.key, a: right, at: r2(edge), th: { s: styleOf(c.r), t: c.r.s }, tha: right, s: cells.find((q) => q.role !== 'line_detail' && q.role !== 'line_section') ? styleOf(cells.find((q) => q.role !== 'line_detail' && q.role !== 'line_section')) : null, dy: 0, sample: cells[0] ? cells[0].s : '' };
  });
  const title = tableRuns.find((r) => r.role === 'line_title'); const details = mergeLines(tableRuns.filter((r) => r.role === 'line_detail'));
  const section = tableRuns.find((r) => r.role === 'line_section');
  const rowTop0 = under ? under.y1 : thBase + 8;
  const firstTitle = title ? title.y : rowTop0 + 18;
  const firstOfRow = tableRuns.filter((r) => r.role === 'line_section' || r.role === 'line_title').sort((a, b) => a.y - b.y)[0] || title;
  const allTitles = tableRuns.filter((r) => r.role === 'line_title').sort((a, b) => a.y - b.y);
  const titles = allTitles.filter((r, k) => k === 0 || labels.line[r.i] !== labels.line[allTitles[k - 1].i]);
  const titleSteps = allTitles.slice(1).filter((r, k) => labels.line[r.i] === labels.line[allTitles[k].i]).map((r) => r.y - allTitles.filter((q) => q.y < r.y).pop().y);
  const rowRules = hr.filter((r) => r.y > firstTitle && r.y <= tableEnd + 0.5 && r.x1 - r.x > (x1 - x0) * 0.5);
  const rowEnd = rowRules.length ? Math.min(...rowRules.map((r) => r.y)) : titles[1] ? titles[1].y - (firstTitle - rowTop0) : tableEnd;
  const firstRowLines = tableRuns.filter((r) => r.y > rowTop0 && r.y < rowEnd);
  const lastInRow = firstRowLines.length ? firstRowLines.slice().sort((a, b) => b.y - a.y || (a.role === 'line_detail' ? -1 : 1))[0] : title;
  const steps = details.slice(1).map((l, i) => l.y - details[i].y).filter((g) => g > 2 && g < details[0].z * 2.2);
  const detailLh = steps.length ? leading(steps.reduce((a, b) => a + b, 0) / steps.length, details[0].z, steps.length) : details[0] ? details[0].z * 1.5 : 12.9;
  const ownDetail = details.filter((d) => !titles[1] || d.y < titles[1].y);
  const descCol = colDefs.find((c) => c.key === 'desc');
  const nextCol = colDefs[colDefs.indexOf(descCol) + 1];
  const nextLeft = nextCol ? Math.min(nextCol.a === 'l' ? nextCol.at : Infinity, ...tableRuns.filter((r) => r.role === roleKey[nextCol.key] || (r.role === 'th' && r.s === nextCol.th.t)).map((r) => r.x)) - 4 : x1;
  // where the descriptions break: between the longest line of any example set alike and what a broken one could not take
  const db = [{ page, labels }, ...others].filter((o) => near(Math.min(...Object.keys(o.labels.roles).filter((i) => o.labels.roles[i] === 'line_title').map((i) => o.page.runs[i].x)), title ? title.x : 0, 1)).map((o) => wrapBounds(mergeLines(Object.keys(o.labels.roles).filter((i) => o.labels.roles[i] === 'line_detail').map((i) => o.page.runs[i]))));
  const dlo = Math.max(0, ...db.map((b) => b.lo)); const dhi = Math.min(Infinity, ...db.map((b) => b.hi).filter((h) => h > dlo));
  const wl = Number.isFinite(dhi) ? (dlo + dhi) / 2 : 0;
  const table = {
    x: r2(x0), x1: r2(x1), cols: colDefs,
    thd: r2(thBase - headEnd), thpb: r2((under ? under.y : rowTop0 - 4) - thBase), thrule: under ? { t: r2(under.y1 - under.y), c: under.c } : null,
    thbox: (() => { const b = (page.boxes || []).find((q) => q[1] < thBase - 2 && q[3] > thBase + 1 && q[2] - q[0] > (x1 - x0) * 0.6 && q[3] - q[1] < 60); return b ? { c: b[4], y: r2(thBase - b[1]), h: r2(b[3] - b[1]), x: r2(b[0]), w: r2(b[2] - b[0]) } : null; })(),
    title: title ? { s: styleOf(title), d: r2(section ? firstOfRow.y - rowTop0 : firstTitle - rowTop0), lh: titleSteps.length ? leading(titleSteps.reduce((a, b) => a + b, 0) / titleSteps.length, title.z, titleSteps.length) : r2(title.z * 1.6) } : null,
    detail: details[0] ? { s: styleOf(details[0]), d: r2(details[0].y - (allTitles.filter((q) => q.y < details[0].y + 0.5).pop() || title).y), lh: r3(detailLh) } : null,
    section: section ? { s: styleOf(section), d: r2(firstOfRow.y - rowTop0), gap: r2(titles[0].y - firstOfRow.y) } : null,
    vlines: vlinesOf(),
    rowrule: rowRules[0] ? { t: r2(rowRules[0].y1 - rowRules[0].y), c: rowRules[0].c } : null,
    wrap: r2(Math.max(...descRuns.map((r) => r.rx1), Math.min(nextLeft, wl || nextLeft))),
  };
  // the vertical lines of a table drawn as a grid
  function vlinesOf() {
    const out = [];
    for (const v of vr.filter((q) => q.y > thBase - 2 && q.y1 < tableEnd + 3 && q.y1 - q.y > 6)) if (!out.some((o) => Math.abs(o.x - v.x) < 1)) out.push({ x: r2(v.x), w: r2(v.x1 - v.x), c: v.c });
    return out.slice(0, 12);
  }
  // the end of a row: from its last line's box, so a row without details ends as it would
  const lastSt = lastInRow && lastInRow.role === 'line_detail' ? table.detail : table.title;
  table.pb = lastSt ? r2(Math.max(0, rowEnd - lastInRow.y - (lastSt.lh - baseOf(fonts[styles[lastSt.s].f], styles[lastSt.s].z, lastSt.lh)))) : 8;
  if (!table.detail && table.title) table.detail = { s: table.title.s, d: r2(styles[table.title.s].z * 1.6), lh: r2(styles[table.title.s].z * 1.45), guess: true };

  if (!footFlows) for (let i = tail.length - 1; i >= 0; i -= 1) if (tail[i].k === 'band') { tail[i].pb = Math.min(tail[i].pb, 12); break; }

  // ── how it writes days and money, and its colours
  const dateHow = (r) => { const d = R.filter((q) => q.role === r).map((q) => readDate(q.s)).find(Boolean); return d ? d.how : null; };
  const amount = R.find((r) => r.role === 'line_amount' || r.role === 'total');
  const big = R.filter((r) => ['total', 'line_amount', 'base'].includes(r.role)).sort((a, b) => Math.abs(readMoney(b.s) || 0) - Math.abs(readMoney(a.s) || 0))[0] || amount;
  const unsigned = R.find((r) => r.role === 'line_price') || null;
  const weight = {}; for (const r of R) weight[r.c] = (weight[r.c] || 0) + r.s.length; for (const b of page.boxes || []) weight[b[4]] = (weight[b[4]] || 0) + 30; for (const r of page.rules) weight[r[4]] = (weight[r[4]] || 0) + 6;
  const colourful = Object.keys(weight).filter((c) => isHex(c) && chroma(c) > 40 && lum(c) < 200).sort((a, b) => weight[b] - weight[a])[0];
  const ink = Object.keys(weight).filter((c) => isHex(c) && chroma(c) <= 40).sort((a, b) => lum(a) - lum(b))[0] || '#000000';
  const own = {
    v: OWN_VERSION, name: String(name || '').slice(0, 120), number: facts.number, w: r2(W), h: r2(H), x: r2(x0), x1: r2(x1), styles, fonts,
    accent: colourful || ink, colourful: !!colourful, ink,
    dates: { issue: dateHow('issue_date') || 'num:/:2:4', due: dateHow('due_date') || dateHow('issue_date') || 'num:/:2:4' },
    money: moneyHow(big ? big.s : '1.000,00 €'), pricemoney: unsigned ? moneyHow(unsigned.s) : null,
    head, table, tail, foot: { h: r2(H - footTop), bands: foot, flow: footFlows, gap: r2(footTop - tailEnd), end: r2(H - footEnd) },
    email: R.some((r) => r.role === 'client_email'), extra: facts.extra_label || '', due: R.some((r) => r.role === 'due_date'),
  };
  // what more examples of the same company tell: a heading over the lines, whether an email is ever printed
  for (const o of others || []) {
    const has = Object.entries(o.labels.roles);
    if (has.some(([, r]) => r === 'client_email')) own.email = true;
    const si = has.filter(([, r]) => r === 'line_section').map(([i]) => o.page.runs[i]).sort((a, b) => a.y - b.y)[0];
    if (!own.table.section && si && has.some(([, r]) => r === 'line_title')) {
      const t = has.filter(([, r]) => r === 'line_title').map(([i]) => o.page.runs[i]).filter((r) => r.y > si.y).sort((a, b) => a.y - b.y)[0];
      const oth = has.filter(([, r]) => r === 'th').map(([i]) => o.page.runs[i].y)[0];
      const rule = o.page.rules.filter((r) => r[1] > oth && r[1] < si.y && r[2] - r[0] > 100).map((r) => r[3]).pop();
      if (t) own.table.section = { s: styleOf(si), d: r2(rule ? si.y - rule : own.table.title.d), gap: r2(t.y - si.y) };
    }
  }
  if (!own.table.section && cols[0]) own.table.section = { s: styleOf(cols[0].r), d: own.table.title ? own.table.title.d : 20, gap: 24, guess: true };
  return own;
}

/** A stored template, whole and safe to draw, or null. */
export function ownOf(v) {
  let o = v;
  if (typeof o === 'string') { try { o = JSON.parse(o); } catch { return null; } }
  if (!o || typeof o !== 'object' || o.v !== OWN_VERSION || !Array.isArray(o.styles) || !o.fonts || !o.table || !Array.isArray(o.table.cols) || !Array.isArray(o.head) || !Array.isArray(o.tail) || !o.foot) return null;
  if (JSON.stringify(o).length > OWN_MAX) return null;
  if (!o.table.cols.some((c) => c.key === 'desc') || !o.table.cols.some((c) => c.key === 'amount')) return null;
  return o;
}
export const OWN_MAX = 90 * 1024;

// ── a document drawn with it ───────────────────────────────────────────
const esc = (t) => String(t == null ? '' : t).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const pt = (n) => `${r3(n)}pt`;
const LEGAL_OF = { number: 'number', issue_date: 'issue_date', issuer_name: 'issuer_name', issuer_tax_id: 'issuer_tax_id', issuer_address: 'issuer_address', client_name: 'client_name', client_tax_id: 'client_tax_id', client_address: 'client_address', base: 'base', tax: 'tax_amount', tax_label: 'tax_rate', total: 'total', withholding: 'withholding' };
const WRAPS = new Set(['client_name', 'issuer_name', 'client_address', 'issuer_address', 'extra', 'due_date', 'notes', 'thanks', 'legal', 'bank']);
const PAY = new Set(['pay_method', 'holder', 'iban', 'bank', 'bic', 'pay_key']);
const upper = (t) => String(t || '').toLocaleUpperCase('es');

/** Its look with the person's own changes on top: another accent, another pair of letters (both «como la tuya» until then). */
export function ownLook(own, design, hexOf, FONTS) {
  const accent = design.accent && design.accent !== 'propia' ? hexOf(design.accent) : null;
  const pair = design.fonts && design.fonts !== 'propia' ? FONTS[design.fonts] : null;
  const recolour = (c) => (accent && c === own.accent ? accent : c);
  const faces = {};
  for (const [k, f] of Object.entries(own.fonts)) faces[k] = pair ? { ...f, family: pair.text, asc: 0.97, desc: 0.25, opsz: 0 } : f;
  const styleCss = own.styles.map((st) => {
    const f = { ...faces[st.f] };
    if (pair && st.z >= 13) f.family = pair.display;
    const safe = (n) => String(n).replace(/[^\w .-]/g, '');
    return `font:${f.italic ? 'italic ' : ''}${Number(f.weight) || 400} ${pt(st.z)}/1 '${safe(f.family)}',${f.generic === 'monospace' ? 'ui-monospace,monospace' : f.generic === 'serif' ? 'Georgia,serif' : 'Helvetica,Arial,sans-serif'};color:${isHex(recolour(st.c)) ? recolour(st.c) : '#000'}${`;letter-spacing:${st.ls ? pt(st.ls) : 0}`}${f.opsz ? `;font-variation-settings:'opsz' ${Number(f.opsz)}` : ''}${f.tnum ? ';font-variant-numeric:lining-nums tabular-nums' : ''}`;
  });
  const google = pair ? [pair.google] : [...new Set(Object.values(own.fonts).map((f) => f.google).filter((g) => /^family=[\w+:;,@.&=-]+$/.test(g || '')))];
  const list = pair ? [`400 16px "${pair.display}"`, `600 16px "${pair.display}"`, `400 16px "${pair.text}"`, `500 16px "${pair.text}"`] : Object.values(own.fonts).map((f) => `${f.italic ? 'italic ' : ''}${Number(f.weight) || 400} 16px "${String(f.family).replace(/["\\]/g, '')}"`);
  return { recolour: (c) => (isHex(recolour(c)) ? recolour(c) : '#000000'), styleCss, google, faces: list, base: (s, lh) => baseOf(faces[own.styles[s].f], own.styles[s].z, lh) };
}

/**
 * The parts of a document in the company's own template, for paper.js: { head1, headN, colgroup, thead, rows, closing,
 * foot, footHeight, tableStyle }. ctx: { w (WORDS), money, num, day, look (ownLook), design, stamp, number, what, dueShown, disc, logo }.
 */
export function ownParts(own, snap, ctx) {
  const { w, look, design, num } = ctx;
  const show = design.show; const tx = design.texts;
  const co = snap.company || {}; const cl = snap.client || {}; const pay = snap.pay || {}; const t = snap.totals || {};
  const quote = snap.kind === 'quote';
  const lines = (a) => String(a || '').split('\n').map((x) => x.trim()).filter(Boolean);
  const money = (c, how) => writeMoney(c, how || own.money, snap.currency || 'EUR');
  const payNote = !quote && pay.note ? String(pay.note).replace(/\{n[uú]mero\}/gi, ctx.number) : '';
  const bankShown = show.bank && !quote;
  const extra = snap.extra && (snap.extra.value || snap.extra.label) ? snap.extra : { label: '', value: '' };
  const V = {
    number: ctx.number, kind: ctx.what, KIND: upper(ctx.what), issue_date: snap.issue_date ? writeDate(snap.issue_date, own.dates.issue) : '—',
    due: !ctx.dueShown ? '' : snap.due_terms || (snap.due_date ? writeDate(snap.due_date, own.dates.due) : ''),
    'issuer.name': co.company_name, 'issuer.tax_id': co.tax_id, 'issuer.email': co.email, 'issuer.phone': co.phone,
    'client.name': cl.legal_name || cl.name || '—', 'client.tax_id': cl.tax_id, 'client.email': own.email || ctx.emailShown ? cl.email : '', 'client.contact': show.contact ? cl.contact_name : '',
    'extra.label': extra.value ? extra.label : '', EXTRA_LABEL: extra.value ? upper(extra.label) : '', 'extra.value': extra.value,
    'pay.iban': bankShown ? pay.iban || pay.bank : '', 'pay.holder': bankShown ? pay.holder || (pay.iban ? co.company_name : '') : '', 'pay.bank_name': bankShown ? pay.bank_name : '', 'pay.bic': bankShown ? pay.bic : '',
    'client.trade': cl.legal_name && cl.name && cl.legal_name !== cl.name ? cl.name : '', title: snap.title,
    thanks: tx.thanks, page: '{i}', pages: '{n}',
  };
  const EACH = { 'client.address': [...lines(cl.address), cl.country].filter(Boolean), 'issuer.address': [...lines(co.address), co.country].filter(Boolean) };
  EACH['issuer.address'].forEach((a, i) => { V[`issuer.address.${i}`] = a; });
  /** A pattern with its values, or null when everything it would say is missing. */
  const say = (text, extraV) => {
    let had = false; let some = false;
    const out = String(text).replace(/\{(\??)([\w.]+)\}/g, (all, only, k) => { const lk = k.toLowerCase(); const v = extraV && k in extraV ? extraV[k] : k in V ? V[k] : lk !== k && lk in V ? upper(V[lk]) : lk.startsWith('issuer.address.') ? '' : null; if (v === null) return all; had = true; if (v) some = true; return only ? '' : v ?? ''; });
    return had && !some ? null : out.replace(/(^|·)\s*·\s*(?=$)/, '').replace(/\s+·\s*$/, '');
  };
  const st = (i) => look.styleCss[i] || '';
  const up = look.base;
  const legalAttr = (role) => (LEGAL_OF[role] ? ` data-legal="${LEGAL_OF[role]}"` : '');
  const spans = (list, main) => list.map((x, i) => { const css = st(x.s).replace(/\/1 /, '/0 '); return i === 0 && x.s === main ? esc(x.t) : `<span style="${css}${x.g ? `;margin-left:${pt(x.g)}` : ''}">${esc(x.t)}</span>`; }).join('');
  /** One block of text, its first baseline `d` under what came before, its last one where the next begins. */
  const block = (s, lh, d, html, { wrap, align, role } = {}) => {
    const u = up(s, lh);
    return `<div${legalAttr(role)} style="${st(s).replace(/\/1 /, `/${pt(lh)} `)};margin:${pt(d - u)} 0 ${pt(u - lh)};white-space:${wrap ? 'pre-wrap' : 'pre'}${wrap ? ';overflow-wrap:anywhere' : ''}${align ? `;text-align:${align}` : ''}">${html}</div>`;
  };
  const notesText = show.notes && snap.notes ? String(snap.notes) : '';
  const placed = { notes: false, payNote: false, thanks: false, payUrl: false };
  const blocks = own.tail.filter((b) => b.k === 'band').flatMap((b) => b.stacks).flatMap((k) => k.lines).filter((l) => l.block === 'notes');
  const norm = (x) => String(x).replace(/\s+/g, ' ').trim().toLowerCase();

  const stack = (k) => {
    const out = [];
    for (let i = 0; i < k.lines.length; i += 1) {
      const l = k.lines[i]; const main = l.spans[0].s;
      let html = null; let many = null;
      if (l.role === 'extra_label' || l.role === 'label') {
        // a label goes with what it labels: «VENCIMIENTO» of a quote is until when it is valid
        const next = k.lines[i + 1];
        let text = l.spans.map((x) => ({ ...x, t: say(x.t) }));
        if (text.some((x) => x.t === null)) text = [];
        if (next && next.role === 'due_date' && quote) text = [{ s: main, t: l.spans[0].t === upper(l.spans[0].t) ? upper(w.valid) : w.valid }];
        out.push({ label: true, d: l.d, html: text.length ? block(main, l.lh, l.d, spans(text, main)) : null });
        continue;
      }
      if (l.each) {
        many = EACH[l.each].map((a, n) => block(main, Math.min(l.lh, l.de || l.lh), n ? l.de : l.d, esc(a), { wrap: true, role: n ? null : l.role }));
      } else if (l.block === 'notes') {
        const here = !l.hasPayNote && blocks.some((b) => b.hasPayNote) ? '' : payNote;
        const parts = [l.hasNotes ? notesText : '', here && bankShown && !norm(notesText).includes(norm(here)) ? here : ''].filter(Boolean);
        if (l.hasNotes) placed.notes = true;
        if (here) placed.payNote = true;
        if (parts.length) {
          const body = esc(parts.join('\n')).split('\n');
          const em = (x) => (l.em !== undefined && ctx.number ? x.split(esc(ctx.number)).join(`<span style="${st(l.em).replace(/\/1 /, '/0 ')}">${esc(ctx.number)}</span>`) : x);
          const paras = []; for (const x of body) { if (x === '') paras.push([]); else { if (!paras.length) paras.push([]); paras[paras.length - 1].push(em(x)); } }
          many = paras.filter((x) => x.length).map((x, n) => block(main, l.lh, n ? (l.blank || l.lh) + l.lh : l.d, x.join('\n'), { wrap: true }));
        }
      } else {
        const isPay = PAY.has(l.role);
        const text = l.spans.map((x) => ({ ...x, t: say(x.t) }));
        const ok = !text.some((x) => x.t === null) && text.some((x) => String(x.t).trim());
        if (l.role === 'thanks') placed.thanks = true;
        if (ok && !(isPay && !bankShown) && !(isPay && !pay.iban && !pay.bank)) html = block(main, l.lh, l.d, spans(text, main), { wrap: WRAPS.has(l.role), role: l.role });
      }
      if (many && many.length) out.push({ d: l.d, html: many.join('') }); else out.push({ d: l.d, html });
    }
    const kept = [];
    for (let i = 0; i < out.length; i += 1) {
      if (!out[i].html) continue;
      if (out[i].label) { const rest = out.slice(i + 1); const stop = rest.findIndex((o) => o.label); const mine = stop < 0 ? rest : rest.slice(0, stop); if (mine.length && !mine.some((o) => o.html)) continue; }
      kept.push(out[i].html);
    }
    return kept.join('');
  };
  const stackBox = (k) => {
    const inner = stack(k);
    if (!inner) return '';
    const pos = k.a === 'r' ? `width:${pt(k.x1)};text-align:right` : k.a === 'c' ? `width:${pt(own.w)};text-align:center` : `margin-left:${pt(k.x)};width:${pt(k.x1 - k.x)}`;
    return `<div class="st" style="${pos}">${inner}</div>`;
  };
  // the totals: a tax of its own row each, the withholding where the total is about to be said
  const totalsBox = (b) => {
    const at = (key) => b.items.findIndex((x) => x.k === 'row' && x.key === key);
    const items = [];
    const bi = at('base'); const ti = at('tax'); const wi = at('withholding');
    const taxes = (t.taxes || []).filter((g) => g.rate || g.tax); const list = taxes.length ? taxes : [{ rate: 0, tax: 0, base: t.subtotal }];
    const between = ti > 0 ? b.items.slice(Math.max(0, bi + 1), ti) : [];
    b.items.forEach((it, i) => {
      if (it.k === 'rule') { items.push(it); return; }
      if (it.key === 'tax') list.forEach((g, n) => { if (n) items.push(...between); items.push({ ...it, g, many: list.length > 1 }); });
      else if (it.key === 'withholding') { if (t.withholding) items.push({ ...it }); } else items.push(it);
      if (i === ti && wi < 0 && t.withholding) { items.push(...between, { ...it, key: 'withholding', made: true }); }
    });
    const row = (it) => {
      const val = it.key === 'base' ? money(t.subtotal) : it.key === 'tax' ? money(it.g.tax) : it.key === 'withholding' ? `−${money(t.withholding)}` : money(t.total);
      const V2 = { rate: num(it.key === 'withholding' ? t.withholding_rate : it.g ? it.g.rate : 0) };
      const label = it.made ? w.withholding(num(t.withholding_rate)) : it.label ? say(it.label[0].t, V2) : it.key === 'total' ? w.total : '';
      const more = it.many ? ` · ${money(it.g.base)}` : '';
      const ls = it.label ? it.label[0].s : it.value[0].s; const vs = it.value[0].s;
      const lh = (s) => own.styles[s].z * 1.2;
      const one = (s, dy, html, css, role) => `<div${legalAttr(role)} style="position:absolute;top:${pt(it.d + dy - up(s, lh(s)))};${css};${st(s).replace(/\/1 /, `/${pt(lh(s))} `)};white-space:pre">${html}</div>`;
      const f = it.fill ? `<div style="position:absolute;left:${pt(it.fill.x)};top:${pt(it.d + it.fill.dy)};width:${pt(it.fill.w)};height:${pt(it.fill.h)};background:${look.recolour(it.fill.c)}"></div>` : '';
      return `<div style="position:relative;height:${pt(it.d)}">${f}${label ? one(ls, 0, esc(label + more), `left:${pt(it.lx)}`, it.key === 'withholding' ? 'withholding' : `${it.key}_label`) : ''}${one(vs, it.dy, esc(val), `right:${pt(it.vx)}`, it.key === 'withholding' ? null : it.key)}</div>`;
    };
    const tailPad = Math.max(0, b.end - b.items.reduce((a, x) => a + x.d + (x.k === 'rule' ? x.t : 0), 0));
    return `<div class="st" style="margin-left:${pt(b.x)};width:${pt(b.x1 - b.x)};padding-bottom:${pt(tailPad)}">${(b.bars || []).map((v) => `<i style="position:absolute;display:block;left:${pt(v.x)};width:${pt(v.w)};top:${pt(v.y)};bottom:${pt(v.b)};background:${look.recolour(v.c)}"></i>`).join('')}${items.map((it) => (it.k === 'rule' ? `<div style="margin:${pt(it.d)} 0 0 ${pt(it.x)};width:${pt(it.w)};height:${pt(it.t)};background:${look.recolour(it.c)}"></div>` : row(it))).join('')}</div>`;
  };
  const band = (b) => {
    const st2 = b.stacks.map((k) => ({ k, html: stackBox(k) }));
    const inked = st2.filter((x) => x.html);
    if (!inked.length && !b.totals && !b.logo) return '';
    // a separator before a cell that has nothing to say goes with it
    const rightOf = (k, v) => k.x > v.x || (k.a === 'r' && k.x1 > v.x + 20);
    const bars = b.bars.filter((v) => !b.stacks.some((k) => rightOf(k, v)) || inked.some((x) => rightOf(x.k, v)));
    const boxes = b.boxes.filter(() => inked.length || b.totals);
    const abs = (v, full) => `left:${pt(v.x)};width:${pt(v.w)};top:${pt(v.y)};${full ? `bottom:${pt(b.h - v.y - v.h)}` : `height:${pt(v.h)}`};background:${look.recolour(v.c)}`;
    return `<div class="bd" style="padding-bottom:${pt(b.pb)}">${boxes.map((v) => `<i style="${abs(v, v.full)}"></i>`).join('')}${bars.map((v) => `<i style="${abs(v, v.full)}"></i>`).join('')}${b.small.map((v) => `<i style="${abs(v, false)}"></i>`).join('')}`
      + `${b.logo && ctx.logo ? `<div class="st" style="margin:${pt(b.logo.y)} 0 0 ${pt(b.logo.x)};width:${pt(b.logo.w)};height:${pt(b.logo.h)}"><img src="${esc(ctx.logo)}" alt="" style="width:100%;height:100%;object-fit:contain;object-position:${b.logo.a === 'r' ? 'right' : 'left'} center;display:block"></div>` : ''}${inked.map((x) => x.html).join('')}${b.totals ? totalsBox(b.totals) : ''}</div>`;
  };
  const rule = (r) => `<div class="rl" style="margin-left:${pt(r.x)};width:${pt(r.w)};height:${pt(r.t)};background:${look.recolour(r.c)}"></div>`;
  const zone = (list) => {
    const drawn = list.map((x) => (x.k === 'rule' ? { rule: true, html: rule(x) } : { html: band(x) }));
    // a rule over nothing goes with it
    return drawn.map((x, i) => (x.rule && list.slice(i + 1).length && !drawn.slice(i + 1).some((y) => !y.rule && y.html) && i > 0 ? '' : x.html)).join('');
  };
  // ── the table
  const T = own.table; const cols = T.cols;
  const edges = [T.x];
  for (let i = 0; i + 1 < cols.length; i += 1) edges.push(cols[i].a === 'r' ? cols[i].at : cols[i + 1].a === 'l' ? cols[i + 1].at : cols[i + 1].a === 'c' ? cols[i + 1].at - 22 : Math.min(T.wrap + 6, cols[i + 1].at - 24));
  edges.push(T.x1);
  const colgroup = `<colgroup>${cols.map((c, i) => `<col style="width:${pt(Math.max(8, edges[i + 1] - edges[i]))}">`).join('')}</colgroup>`;
  const cell = (c, i) => (c.a === 'r' ? `justify-content:flex-end;padding-right:${pt(edges[i + 1] - c.at)}` : c.a === 'c' ? 'justify-content:center' : `justify-content:flex-start;padding-left:${pt(Math.max(0, c.at - edges[i]))}`);
  const zh = own.styles[cols[0].th.s].z * 1.4;
  const thTop = T.thd - up(cols[0].th.s, zh);
  const taxWord = (x) => x;
  const thead = `<thead><tr>${cols.map((c, i) => `<th scope="col" style="padding:${pt(Math.max(0, thTop))} 0 ${pt(Math.max(0, T.thpb - (zh - up(cols[0].th.s, zh))))};${T.thrule ? `border-bottom:${pt(T.thrule.t)} solid ${look.recolour(T.thrule.c)};` : ''}"><div style="display:flex;${cell(c, i)};${st(c.th.s).replace(/\/1 /, `/${pt(zh)} `)};white-space:pre;position:relative">${i === 0 && T.thbox ? `<i style="position:absolute;left:${pt(T.thbox.x - T.x - (c.a === 'l' ? Math.max(0, c.at - edges[0]) * 0 : 0))};top:${pt(up(cols[0].th.s, zh) - T.thbox.y)};width:${pt(T.thbox.w)};height:${pt(T.thbox.h)};background:${look.recolour(T.thbox.c)};z-index:-1"></i>` : ''}${esc(taxWord(c.th.t))}</div></th>`).join('')}</tr></thead>`;
  const ti = T.title; const de = T.detail; const se = T.section;
  const rows = (snap.lines || []).map((l, n) => {
    const all = String(l.d || '').split('\n'); const head = all[0]; const rest = all.slice(1).join('\n').trim();
    const disc = l.x && !cols.some((c) => c.key === 'disc') ? `−${num(l.x)}% ${w.off}` : '';
    const more = [rest, disc].filter(Boolean).join('\n');
    const top = (l.s ? se.d + se.gap : ti.d) - up(ti.s, ti.lh);
    const rr = T.rowrule ? `border-bottom:${pt(T.rowrule.t)} solid ${look.recolour(T.rowrule.c)};` : '';
    return `<tr data-legal="lines">${cols.map((c, i) => {
      const s = c.s ?? ti.s;
      const base = `padding:${pt(top)} 0 ${pt(T.pb)};${rr}`;
      const grid = i === 0 ? (T.vlines || []).map((v) => `<i style="position:absolute;display:block;left:${pt(v.x - edges[0])};width:${pt(v.w)};top:0;bottom:0;background:${look.recolour(v.c)}"></i>`).join('') : '';
      if (c.key === 'desc') {
        const sec = l.s ? `<div style="position:absolute;left:${pt(Math.max(0, c.at - edges[i]))};top:${pt(se.d - up(se.s, own.styles[se.s].z * 1.4))};${st(se.s).replace(/\/1 /, `/${pt(own.styles[se.s].z * 1.4)} `)};white-space:pre">${esc(upper(l.s))}</div>` : '';
        const dTop = de.d - (ti.lh - up(ti.s, ti.lh)) - up(de.s, de.lh);
        return `<td style="${base};position:relative">${grid}${sec}<div style="padding-left:${pt(Math.max(0, c.at - edges[i]))};width:${pt(Math.max(60, T.wrap - edges[i]))}"><div style="${st(ti.s).replace(/\/1 /, `/${pt(ti.lh)} `)};white-space:pre-wrap;overflow-wrap:anywhere">${show.line_numbers && !cols.some((k) => k.key === 'n') ? `${n + 1}. ` : ''}${esc(head)}</div>${more ? `<div style="${st(de.s).replace(/\/1 /, `/${pt(de.lh)} `)};margin-top:${pt(dTop)};white-space:pre-wrap;overflow-wrap:anywhere">${esc(more)}</div>` : ''}</div></td>`;
      }
      const v = c.key === 'qty' ? num(l.q) : c.key === 'price' ? money(l.p, own.pricemoney) : c.key === 'disc' ? (l.x ? `${num(l.x)}%` : '') : c.key === 'tax' ? `${num(l.t)}%` : c.key === 'n' ? String(n + 1) : c.key === 'amount' ? money(l.n) : '';
      return `<td style="${base}${grid ? 'position:relative' : ''}">${grid}<div style="display:flex;${cell(c, i)};${st(s).replace(/\/1 /, `/${pt(ti.lh)} `)};white-space:pre">${esc(v)}</div></td>`;
    }).join('')}</tr>`;
  });
  const head1 = `<div class="hd">${zone(own.head)}${ctx.stamp && ctx.stamp !== 'Draft' ? `<p class="stamp stamp--${ctx.stamp.toLowerCase()} own-stamp" style="right:${pt(own.w - own.x1)}">${esc(w[ctx.stamp])}</p>` : ''}</div>`;
  const small = cols[0].th.s;
  const contRule = own.head.find((x) => x.k === 'rule');
  const headN = `<div class="hd"><div class="bd" style="padding-bottom:9pt"><div class="st" style="margin-left:${pt(own.x)};width:${pt((own.x1 - own.x) / 2)}">${block(small, 10, 42, esc(co.company_name || ''))}</div><div class="st" style="width:${pt(own.x1)};text-align:right">${block(small, 10, 42, esc(`${ctx.what} ${ctx.number} · ${w.cont}`))}</div></div>${contRule ? rule(contRule) : ''}<div style="height:10pt"></div></div>`;
  const tailHtml = zone(own.tail);
  // what this document says and the example had no place for: after it, in its own letters
  const noteStack = own.tail.filter((x) => x.k === 'band').flatMap((b) => b.stacks).find((k) => k.lines.some((l) => l.role === 'notes' || PAY.has(l.role)));
  const noteLine = noteStack && (noteStack.lines.find((l) => l.role === 'notes') || noteStack.lines[noteStack.lines.length - 1]);
  const xs = noteLine ? noteLine.spans[0].s : de.s; const xlh = own.styles[xs].z * 1.6; const labelStyle = noteStack && noteStack.lines[0].role === 'label' ? noteStack.lines[0].spans[0].s : small;
  const legalText = [head1, tailHtml].join('');
  const missing = [];
  const lack = (k, v) => { if (v && !legalText.includes(`data-legal="${k}"`)) missing.push(v); };
  if (!quote) {
    lack('issuer_name', co.company_name); lack('issuer_tax_id', co.tax_id && `${w.taxId} ${co.tax_id}`); lack('issuer_address', EACH['issuer.address'].join(', '));
    lack('client_name', V['client.name']); lack('client_tax_id', cl.tax_id && `${w.to}: ${w.taxId} ${cl.tax_id}`); lack('client_address', EACH['client.address'].length && `${w.to}: ${EACH['client.address'].join(', ')}`);
    lack('number', `${ctx.what} ${ctx.number}`); lack('issue_date', `${w.issued}: ${V.issue_date}`);
    lack('base', `${w.subtotal}: ${money(t.subtotal)}`); if (!legalText.includes('data-legal="tax_amount"')) for (const g of (t.taxes || [])) missing.push(`${w.taxOn(num(g.rate))}: ${money(g.tax)}`); lack('total', `${w.total}: ${money(t.total)}`);
  }
  const extras = [
    !placed.notes && notesText ? [w.notes, notesText] : null,
    !placed.payNote && payNote && bankShown && (pay.iban || pay.bank) && !norm(notesText).includes(norm(payNote)) ? ['', payNote] : null,
    show.pay_link && pay.url ? [w.payCard, pay.url] : null,
    snap.conditions ? [w.conditions, snap.conditions] : null,
    quote && snap.due_date ? ['', tx.quote_terms ? tx.quote_terms.replace(/\{fecha\}/g, writeDate(snap.due_date, own.dates.due)) : w.validLine(writeDate(snap.due_date, own.dates.due))] : null,
    !quote && tx.invoice_legal ? ['', tx.invoice_legal] : null,
    missing.length ? ['', missing.join(' · ')] : null,
    tx.thanks && !placed.thanks ? ['', tx.thanks] : null,
  ].filter(Boolean);
  const extraHtml = extras.length ? `<div style="margin:12pt 0 0 ${pt(own.x)};width:${pt(own.x1 - own.x)};display:flex;flex-direction:column">${extras.map(([a, b]) => `${a ? block(labelStyle, 10, 16, esc(own.styles[labelStyle].ls ? upper(a) : a)) : ''}${block(xs, xlh, a ? 18 : 16, esc(b), { wrap: true })}`).join('')}</div>` : '';
  // the foot, on every sheet, where the example has it; with several sheets, which one this is
  let footBands = own.foot.bands;
  if (tx.footer) footBands = footBands.map((b) => (b.k !== 'band' ? b : { ...b, stacks: b.stacks.map((k, i) => (i === 0 ? { ...k, lines: [{ ...k.lines[0], role: 'thanks', spans: [{ s: k.lines[0].spans[0].s, t: tx.footer }] }] } : k)) }));
  const footHtml = zone(footBands);
  const fs = footBands.find((b) => b.k === 'band' && b.stacks[0])?.stacks[0].lines[0].spans[0].s ?? small;
  const pages = JSON.stringify(footBands).includes('{page}') ? '' : `<span class="pg" style="${st(fs)};right:${pt(own.w - own.x1)}">${esc(w.page('{i}', '{n}'))}</span>`;
  const flow = own.foot.flow;
  const closing = `<div class="closing">${tailHtml}${extraHtml ? extraHtml + (flow ? `<div style="height:${pt(own.foot.gap)}"></div>` : '') : ''}${flow ? `<div>${footHtml}</div>` : ''}</div>`;
  return { head1, headN, colgroup, thead, rows, closing, foot: flow ? `<div class="ownfoot" style="height:24pt">${pages}</div>` : `<div class="ownfoot" style="height:${pt(own.foot.h)}">${footHtml}${pages}</div>`, footHeight: flow ? Math.min(own.foot.end, 24) : own.foot.h, tableStyle: `margin-left:${pt(T.x)};width:${pt(T.x1 - T.x)}` };
}

/** What its sheets need besides paper.js's own CSS. */
export const OWN_CSS = `
.t-propia { font-variant-numeric: normal; line-height: 1 }
.t-propia .sheet { padding: 0; color: #000 }
.t-propia .hd { position: relative; display: flex; flex-direction: column; flex: none }
.t-propia .bd { display: grid; position: relative; grid-template-columns: minmax(0, 1fr); align-items: start; justify-items: start }
.t-propia .st { grid-area: 1 / 1; display: flex; flex-direction: column; min-width: 0; position: relative; top: .2pt }
.t-propia th > div, .t-propia td > div { position: relative; top: .2pt }
.t-propia .bd > i, .t-propia th i { position: absolute; display: block }
.t-propia .rl { flex: none }
.t-propia table { border-collapse: separate; border-spacing: 0; flex: none }
.t-propia th, .t-propia td { text-align: left; font-weight: inherit; letter-spacing: inherit; text-transform: none; vertical-align: top; border: 0 }
.t-propia tr { position: relative }
.t-propia th { z-index: 0; position: relative }
.t-propia .closing { display: flex; flex-direction: column; gap: 0; padding: 0; flex: none }
.t-propia .ownfoot { position: absolute; left: 0; right: 0; bottom: 0; overflow: visible }
.t-propia .pg { position: absolute; bottom: 12pt; display: none }
.t-propia .many .pg { display: block }
.t-propia .own-stamp { position: absolute; top: 5mm; margin: 0 }
`;

/** The example said again as a document (a snapshot, invcore.snapshot's shape): what «Tu factura» draws to compare with it. */
export function exampleSnapshot(f, { design, logo = '' } = {}) {
  return {
    v: 1, lang: 'es', kind: f.kind, status: 'Issued', number: f.number, issue_date: f.issue_date, due_date: f.due_date, due_terms: f.due_terms, currency: 'EUR',
    company: { company_name: f.issuer.name, tax_id: f.issuer.tax_id, address: f.issuer.address.join('\n'), email: f.issuer.email, logo },
    client: { name: f.client.trade || f.client.name, legal_name: f.client.name, contact_name: f.client.contact, tax_id: f.client.tax_id, address: f.client.address.join('\n'), email: f.client.email },
    lines: f.lines.map((l) => ({ d: [l.title, ...l.detail].join('\n'), q: l.qty, p: l.price ?? l.amount, t: l.tax !== null ? l.tax / 100 : f.tax_rate ?? 21, x: l.disc ? l.disc / 100 : 0, n: l.amount ?? 0, ...(l.section ? { s: l.section } : {}) })),
    totals: { subtotal: f.base ?? (f.total || 0) - (f.tax || 0), taxes: f.tax ? [{ rate: f.tax_rate ?? 21, base: f.base || 0, tax: f.tax }] : [], withholding_rate: f.withholding_rate || 0, withholding: f.withholding || 0, total: f.total || 0 },
    title: f.title || '', notes: f.notes, conditions: '', pay: { iban: f.pay.iban, holder: f.pay.holder, bank_name: f.pay.bank_name, bic: f.pay.bic, note: f.pay_note, url: '' }, extra: { label: f.extra_label, value: f.extra }, design: { ...design, texts: { ...(design && design.texts), thanks: f.thanks } },
  };
}

// ── the words it always prints («Forma de pago», «Transferencia bancaria», the column heads), for a person to change
const wordsIn = (own) => {
  const out = [];
  const zone = (list) => list.forEach((b) => { if (b.k !== 'band') return; for (const k of b.stacks) for (const l of k.lines) for (const x of l.spans) out.push(x); if (b.totals) for (const it of b.totals.items) if (it.label) out.push(it.label[0]); });
  zone(own.head); out.push(...own.table.cols.map((c) => c.th)); zone(own.tail); zone(own.foot.bands);
  return out;
};
/** → [{ text }]: each fixed text once, in the order it is printed. What a document fills in is not among them. */
export function fixedTexts(own) {
  const seen = new Set(); const out = [];
  for (const x of wordsIn(own)) { const t = flat(x.t.replace(/\{\??[\w.]+\}/g, '')); if (t.length > 1 && /\p{L}/u.test(t) && !seen.has(x.t)) { seen.add(x.t); out.push(x.t); } }
  return out;
}
/** A copy where one fixed text says another thing. What a document fills in ({number}…) stays in it. */
export function retext(own, from, to) {
  const o = JSON.parse(JSON.stringify(own));
  const keep = from.match(/\{\??[\w.]+\}/g) || [];
  const t = String(to).slice(0, 160);
  const safe = t.replace(/\{\??[\w.]+\}/g, (m) => (keep.includes(m) ? m : ''));
  for (const x of wordsIn(o)) if (x.t === from) x.t = keep.every((k) => safe.includes(k)) ? safe : `${safe} ${keep.filter((k) => !safe.includes(k)).join(' ')}`.trim();
  return o;
}

/** What an example says that Facturas keeps in its settings → { field: value }, only what it has. */
export function settingsOfExample(f) {
  const out = {};
  const put = (k, v) => { if (v !== undefined && v !== null && String(v).trim()) out[k] = v; };
  put('company_name', f.issuer.name); put('tax_id', f.issuer.tax_id); put('email', f.issuer.email);
  const at = f.issuer.address.findIndex((a) => /^\d{5}\s+\S/.test(a));
  if (at >= 0) {
    const m = /^(\d{5})\s+([^,(]+)(?:[,(]\s*([^,)]+))?/.exec(f.issuer.address[at]);
    put('address', f.issuer.address.slice(0, at).join(', ')); put('postal_code', m[1]); put('city', flat(m[2])); put('province', m[3] && flat(m[3]));
  } else put('address', f.issuer.address.join('\n'));
  put('iban', f.pay.iban); put('bank_name', f.pay.bank_name); put('bic', f.pay.bic); if (f.pay.holder && low(f.pay.holder) !== low(f.issuer.name)) put('account_holder', f.pay.holder);
  if (f.pay_note) put('payment_note', f.number ? f.pay_note.split(f.number).join('{numero}') : f.pay_note);
  if (f.tax_rate !== null) put('tax_rate', f.tax_rate);
  const m = /^(.*?)(\d{4})-(\d{1,6})$/.exec(f.number);
  if (m && f.kind === 'invoice') { out.invoice_prefix = m[1]; out.number_digits = m[3].length; }
  return out;
}
/** An example as import_documents takes it. `status`: issued | paid. */
export function importOfExample(f, status = 'issued') {
  const item = { kind: f.kind, number: f.number, issue_date: f.issue_date, ...(f.due_date ? { due_date: f.due_date } : f.due_terms ? { due_terms: f.due_terms } : {}), title: f.title || (f.lines[0] ? f.lines[0].title : f.number), notes: f.notes, status,
    client: { name: f.client.name, ...(f.client.tax_id ? { tax_id: f.client.tax_id } : {}), ...(f.client.address.length ? { address: f.client.address.join('\n') } : {}), ...(f.client.email ? { email: f.client.email } : {}) },
    lines: f.lines.map((l) => ({ description: [l.title, ...l.detail].join('\n'), qty: l.qty, price: (l.price ?? Math.round((l.amount || 0) / (l.qty || 1))) / 100, tax: l.tax !== null ? l.tax / 100 : f.tax_rate ?? 0, disc: l.disc ? l.disc / 100 : 0, ...(l.section ? { section: l.section } : {}) })),
    ...(f.withholding_rate ? { withholding_rate: f.withholding_rate } : {}), ...(f.extra ? { extra_label: f.extra_label, extra_value: f.extra } : {}) };
  return item;
}
/** Does what it adds up to agree with what it prints? → null, or what differs (cents). */
export function sumsOff(f) {
  const lines = f.lines.reduce((a, l) => a + (l.amount ?? 0), 0);
  if (f.base !== null && Math.abs(lines - f.base) > 2) return { what: 'base', said: f.base, sums: lines };
  const total = (f.base ?? lines) + (f.tax || 0) - (f.withholding || 0);
  if (f.total !== null && Math.abs(total - f.total) > 2) return { what: 'total', said: f.total, sums: total };
  return null;
}
