// The document as its client gets it (0.5.0): ONE renderer for the desk's preview, the client's page, the emailed link
// and the PDF, so what the owner looks at is what the client gets. `documentHtml(snap)` answers a whole HTML page of A4
// sheets, drawn from a snapshot (invcore.snapshot) with its design (shared/design.js). The page lays itself out when it
// opens: it measures each part, `paginate` decides the pages (a row never split, the header and the table's column
// heads on every sheet, the totals, taxes and how to pay together on the last one), and every sheet says «Página 1 de
// 3». The platform prints the same page to PDF once it says `printReady` (openclaw-railway lib/module-print.js).
// Pure strings, no DOM at import: the server builds the PDF's page with it. test/sync.mjs copies it to public/.
import './invcore.js';
import { LEGAL, FONTS, designOf, looksOf, hexOf, fileNameOf } from './design.js';
import { OWN_CSS, ownLook, ownParts } from './own.js';

const C = globalThis.InvCore;

export const WORDS = {
  en: {
    invoice: 'Invoice', quote: 'Quote', issued: 'Date', due: 'Due', valid: 'Valid until', from: 'From', to: 'Bill to', taxId: 'Tax ID',
    desc: 'Description', qty: 'Qty', price: 'Price', tax: 'Tax', disc: 'Disc.', amount: 'Amount', off: 'off', n: '#',
    subtotal: 'Subtotal', taxOn: (r) => `Tax ${r}%`, withholding: (r) => `Withholding ${r}%`, total: 'Total',
    notes: 'Notes', pay: 'How to pay', payCard: 'Pay by card', draft: 'Draft', ref: 'Reference', attn: 'Attn.', cont: 'continued', conditions: 'Terms', iban: 'IBAN', holder: 'Account holder', bank: 'Bank', bic: 'BIC/SWIFT',
    page: (i, n) => `Page ${i} of ${n}`, validLine: (d) => `This quote is valid until ${d}.`,
    Paid: 'Paid', Void: 'Void', Withdrawn: 'Withdrawn', Accepted: 'Accepted', Declined: 'Declined', Expired: 'Expired', Overdue: 'Overdue', Draft: 'Draft',
    mark: { Draft: 'DRAFT', Void: 'VOID', Withdrawn: 'WITHDRAWN' },
  },
  es: {
    invoice: 'Factura', quote: 'Presupuesto', issued: 'Fecha', due: 'Vencimiento', valid: 'Válido hasta', from: 'De', to: 'Cliente', taxId: 'NIF',
    desc: 'Concepto', qty: 'Cant.', price: 'Precio', tax: 'IVA', disc: 'Dto.', amount: 'Importe', off: 'dto.', n: 'Nº',
    subtotal: 'Base imponible', taxOn: (r) => `IVA ${r}%`, withholding: (r) => `Retención IRPF ${r}%`, total: 'Total',
    notes: 'Notas', pay: 'Forma de pago', payCard: 'Paga con tarjeta', draft: 'Borrador', ref: 'Referencia', attn: 'A la atención de', cont: 'continuación', conditions: 'Condiciones', iban: 'IBAN', holder: 'Titular', bank: 'Banco', bic: 'BIC/SWIFT',
    page: (i, n) => `Página ${i} de ${n}`, validLine: (d) => `Este presupuesto es válido hasta el ${d}.`,
    Paid: 'Pagada', Void: 'Anulada', Withdrawn: 'Retirado', Accepted: 'Aceptado', Declined: 'Rechazado', Expired: 'Caducado', Overdue: 'Vencida', Draft: 'Borrador',
    mark: { Draft: 'BORRADOR', Void: 'ANULADA', Withdrawn: 'RETIRADO' },
  },
};

/** The state the stamp shows, or null for a document simply waiting (Issued, Sent). A void quote was withdrawn. */
export function stampOf(snap, today) {
  if (snap.void_at || snap.status === 'Void') return snap.kind === 'quote' ? 'Withdrawn' : 'Void';
  if (snap.status === 'Paid') return 'Paid';
  if (snap.status === 'Accepted') return 'Accepted';
  if (snap.status === 'Declined') return 'Declined';
  if (snap.status === 'Draft' || !snap.status) return 'Draft';
  if (!snap.due_terms && snap.due_date && today && snap.due_date < today) return snap.kind === 'quote' ? 'Expired' : 'Overdue';
  return null;
}

/**
 * How the client of an invoice can pay it, for their page: { url, bank, note, reference } — or null when there is
 * nothing to pay (a quote, paid, void) or no way to pay was set (no IBAN, no card link): the page then shows no pay box
 * at all, never an empty one; the sender is told in their own page what is missing (page_needs «bank»).
 */
export function payWays(snap) {
  if (!snap || snap.kind !== 'invoice' || snap.void_at || ['Void', 'Paid', 'Draft'].includes(snap.status)) return null;
  const pay = snap.pay || {};
  const url = /^https:\/\//.test(String(pay.url || '')) ? String(pay.url) : '';
  // 0.5.7: the IBAN and its parts, each its own line; before, one text (`bank`) that «Copiar» searched for an IBAN
  const iban = String(pay.iban || '').trim();
  const text = iban ? '' : String(pay.bank || '').trim();
  if (!iban && !text && !url) return null;
  const m = text ? /\b[A-Z]{2}\d{2}(?:[ ]?[A-Z0-9]{4}){2,7}(?:[ ]?[A-Z0-9]{1,4})?\b/.exec(text.replace(/\n/g, ' ')) : null;
  const has = !!(iban || text);
  return {
    url, text, iban: iban || (m ? m[0] : ''), copy: iban ? iban.replace(/ /g, '') : m ? m[0].replace(/ /g, '') : text,
    holder: iban ? String(pay.holder || '').trim() : '', bank_name: iban ? String(pay.bank_name || '').trim() : '', bic: iban ? String(pay.bic || '').trim() : '',
    note: has ? String(pay.note || '').trim() : '', reference: snap.number || '',
  };
}

// ── pages ──────────────────────────────────────────────────────────────
/**
 * Which rows go on which sheet. m: { first, next } the height each sheet has for its rows once its header and the
 * table's column heads are drawn (the first sheet's header is taller), rows: [height], closing: the height of what must
 * stay together at the end (totals, taxes, how to pay, notes). → [{ from, to, closing }]: rows [from, to) on that sheet,
 * `closing` on the last one only. A row is never split; a row taller than a sheet gets one of its own. When the closing
 * does not fit under the last row, the last row goes with it to the next sheet (never totals alone on a page) unless
 * that would empty a sheet. Self-contained: it is also written into the page as text.
 */
export function paginate(m) {
  const rows = m.rows || [];
  const pages = [{ from: 0, to: 0, closing: false }];
  let left = m.first;
  for (let i = 0; i < rows.length; i += 1) {
    const p = pages[pages.length - 1];
    if (rows[i] <= left || p.to === p.from) { p.to = i + 1; left -= rows[i]; continue; }
    pages.push({ from: i, to: i + 1, closing: false });
    left = m.next - rows[i];
  }
  const last = pages[pages.length - 1];
  if (m.closing <= left || (last.to === last.from && pages.length === 1)) { last.closing = true; return pages; }
  if (last.to - last.from >= 2 && rows[last.to - 1] + m.closing <= m.next) {
    last.to -= 1;
    pages.push({ from: last.to, to: last.to + 1, closing: true });
    return pages;
  }
  pages.push({ from: last.to, to: last.to, closing: true });
  return pages;
}

// ── the parts, as HTML strings ─────────────────────────────────────────
const esc = (s) => String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const linesOf = (text) => String(text || '').split('\n').map((x) => x.trim()).filter(Boolean);
const num = (n, lang) => new Intl.NumberFormat(C.localeOf(lang), { maximumFractionDigits: 3 }).format(n);
const br = (text) => linesOf(text).map(esc).join('<br>');
const safeImg = (src) => (/^data:image\/(png|jpeg|svg\+xml);base64,[A-Za-z0-9+/=]+$/.test(src) || /^https:\/\/[^\s"'<>]+$/.test(src) ? src : '');

/**
 * Everything one document draws, as strings: the first sheet's header (`head1`, with the client), the next sheets'
 * (`headN`), the column heads (`thead`, `colgroup`), each line (`rows`), what stays together at the end (`closing`),
 * the footer's text and the watermark. Every LEGAL part is drawn, whatever `show` says (test/design.test.mjs).
 */
export function paperParts(snap, opts = {}) {
  const lang = snap.lang === 'en' ? 'en' : 'es';
  const w = WORDS[lang];
  const look = looksOf(snap.design);
  const show = look.show;
  const m = (n) => C.money(Number(n) || 0, snap.currency || 'EUR', C.localeOf(lang));
  const co = snap.company || {};
  const cl = snap.client || {};
  const quote = snap.kind === 'quote';
  const t = snap.totals || {};
  const stamp = stampOf(snap, opts.today);
  const what = quote ? w.quote : w.invoice;
  const number = snap.number || w.draft;
  const logo = safeImg(co.logo || co.logo_url || '');
  const day = (d) => C.longDay(d, lang);
  const contact = show.contact && cl.contact_name ? cl.contact_name : '';
  const disc = (snap.lines || []).some((l) => l.x);
  const discCol = disc && show.discount_column;
  const dueShown = quote || show.due_date;
  const dates = [
    `<div><dt>${esc(w.issued)}</dt><dd data-legal="issue_date">${esc(snap.issue_date ? day(snap.issue_date) : '—')}</dd></div>`,
    dueShown && snap.due_terms ? `<div><dt>${esc(w.due)}</dt><dd>${esc(snap.due_terms)}</dd></div>`
      : dueShown && snap.due_date ? `<div><dt>${esc(quote ? w.valid : w.due)}</dt><dd>${esc(day(snap.due_date))}</dd></div>` : '',
  ].join('');
  if (look.template === 'propia' && look.own) {
    const mark = stamp === 'Draft' || stamp === 'Void' || stamp === 'Withdrawn' ? w.mark[stamp] : '';
    const own = ownLook(look.own, look, hexOf, FONTS);
    const parts = ownParts(look.own, snap, { w, look: own, design: look, num: (n) => num(Number(n) || 0, lang), stamp, number, what, dueShown, logo });
    return { lang, look: { ...look, font: { display: look.font.display, text: look.font.text, google: own.google.join('&') }, faces: own.faces, links: own.google }, ...parts, mark, footer: '', title: fileNameOf(snap) };
  }
  const fromLines = [`<span data-legal="issuer_tax_id">${co.tax_id ? `${esc(w.taxId)} ${esc(co.tax_id)}` : ''}</span>`, `<span data-legal="issuer_address">${br(co.address)}</span>`, co.country ? `<span>${esc(co.country)}</span>` : '', co.email ? `<span>${esc(co.email)}</span>` : '', co.phone ? `<span>${esc(co.phone)}</span>` : ''].join('');
  const toLines = [`<span data-legal="client_tax_id">${cl.tax_id ? `${esc(w.taxId)} ${esc(cl.tax_id)}` : ''}</span>`, `<span data-legal="client_address">${br(cl.address)}</span>`, cl.country ? `<span>${esc(cl.country)}</span>` : '', cl.email ? `<span>${esc(cl.email)}</span>` : '', contact ? `<span class="attn">${esc(w.attn)}: ${esc(contact)}</span>` : ''].join('');
  const trade = C.tradeName(cl);
  const stampHtml = stamp && stamp !== 'Draft' ? `<p class="stamp stamp--${stamp.toLowerCase()}">${esc(w[stamp])}</p>` : '';
  const logoBox = logo ? `<div class="logo"><img src="${esc(logo)}" alt=""></div>` : '';
  const company = (cls = '') => `<p class="company${cls}" data-legal="issuer_name">${esc(co.company_name || '—')}</p>`;
  const client = `<p class="client" data-legal="client_name">${esc(cl.legal_name || cl.name || '—')}${trade ? `<span class="trade">${esc(trade)}</span>` : ''}</p>`;
  const kind = `<p class="kind">${esc(what)}</p>`;
  const numberP = `<p class="number" data-legal="number">${esc(number)}</p>`;
  const reference = snap.title && !((snap.lines || []).length === 1 && String(snap.lines[0].d).trim() === String(snap.title).trim()) ? `<p class="ref"><span class="label">${esc(w.ref)}</span> ${esc(snap.title)}</p>` : '';
  const whatBlock = `<div class="what">${kind}${numberP}<dl class="dates">${dates}</dl>${stampHtml}</div>`;
  const head1 = look.template === 'moderno'
    ? `<header class="head head--first"><div class="band"></div><div class="top">${logoBox ? `<div class="from">${logoBox}</div>` : `<div class="from">${company()}</div>`}${whatBlock}</div>`
      + `<div class="parties"><section class="party"><p class="label">${esc(w.from)}</p>${logoBox ? company(' company--party') : ''}<p class="plines">${fromLines}</p></section>`
      + `<section class="party"><p class="label">${esc(w.to)}</p>${client}<p class="plines">${toLines}</p></section></div>${reference}</header>`
    : `<header class="head head--first"><div class="top"><div class="from">${logoBox}${company()}<p class="plines">${fromLines}</p></div>${whatBlock}</div>`
      + `<section class="to"><p class="label">${esc(w.to)}</p>${client}<p class="plines">${toLines}</p></section>${reference}</header>`;
  const headN = `<header class="head head--next">${logo ? `<div class="logo logo--small"><img src="${esc(logo)}" alt=""></div>` : `<p class="company company--small">${esc(co.company_name || '')}</p>`}<p class="cont">${esc(what)} ${esc(number)} · ${esc(w.cont)}</p></header>`;
  // the columns: a fixed layout, so a row is as tall on its own sheet as when it was measured
  const cols = [show.line_numbers ? ['n', '7%'] : null, ['desc', null], ['qty', '9%'], ['price', '15%'], discCol ? ['disc', '8%'] : null, ['tax', '8%'], ['amount', '16%']].filter(Boolean);
  const colgroup = `<colgroup>${cols.map(([k, wd]) => `<col class="c-${k}"${wd ? ` style="width:${wd}"` : ''}>`).join('')}</colgroup>`;
  const th = { n: w.n, desc: w.desc, qty: w.qty, price: w.price, disc: w.disc, tax: w.tax, amount: w.amount };
  const thead = `<thead><tr>${cols.map(([k]) => `<th scope="col" class="${k === 'desc' ? 'desc' : 'num'}">${esc(th[k])}</th>`).join('')}</tr></thead>`;
  const rows = (snap.lines || []).map((l, i) => `<tr data-legal="lines">${cols.map(([k]) => {
    if (k === 'n') return `<td class="num muted">${i + 1}</td>`;
    if (k === 'desc') return `<td class="desc">${l.s ? `<span class="sec">${esc(l.s)}</span>` : ''}<span>${esc(l.d)}</span>${disc && !discCol && l.x ? `<span class="off">−${esc(num(l.x, lang))}% ${esc(w.off)}</span>` : ''}</td>`;
    if (k === 'qty') return `<td class="num">${esc(num(l.q, lang))}</td>`;
    if (k === 'price') return `<td class="num">${esc(m(l.p))}</td>`;
    if (k === 'disc') return `<td class="num">${l.x ? `${esc(num(l.x, lang))}%` : ''}</td>`;
    if (k === 'tax') return `<td class="num">${esc(num(l.t, lang))}%</td>`;
    return `<td class="num">${esc(m(l.n))}</td>`;
  }).join('')}</tr>`);
  const taxes = (t.taxes || []).filter((g) => g.rate || g.tax);
  const totals = `<dl class="totals"><div><dt>${esc(w.subtotal)}</dt><dd data-legal="base">${esc(m(t.subtotal))}</dd></div>`
    + (taxes.length ? taxes : [{ rate: 0, tax: 0, base: t.subtotal }]).map((g) => `<div><dt data-legal="tax_rate">${esc(w.taxOn(num(g.rate, lang)))}${taxes.length > 1 ? `<span class="on"> · ${esc(m(g.base))}</span>` : ''}</dt><dd data-legal="tax_amount">${esc(m(g.tax))}</dd></div>`).join('')
    + (t.withholding ? `<div><dt data-legal="withholding">${esc(w.withholding(num(t.withholding_rate, lang)))}</dt><dd>−${esc(m(t.withholding))}</dd></div>` : '')
    + `<div class="total"><dt>${esc(w.total)}</dt><dd data-legal="total">${esc(m(t.total))}</dd></div></dl>`;
  const pay = snap.pay || {};
  // how to pay by transfer, one labelled line each (0.5.7): IBAN, holder, bank, BIC — or 0.5.6's text as it was written
  const bankLines = pay.iban ? [[w.iban, pay.iban, true], [w.holder, pay.holder], [w.bank, pay.bank_name], [w.bic, pay.bic, true]].filter(([, v]) => v)
    .map(([k, v, mono]) => `<p class="text bankline"><span class="k">${esc(k)}</span> <span${mono ? ' class="mono"' : ''}>${esc(v)}</span></p>`).join('') : pay.bank ? `<p class="text mono">${esc(pay.bank)}</p>` : '';
  const payParts = !quote && !['Paid', 'Void'].includes(stamp) ? [
    show.bank && bankLines ? bankLines : '',
    show.bank && bankLines && pay.note ? `<p class="text">${esc(pay.note)}</p>` : '',
    show.pay_link && pay.url ? `<p class="text">${esc(w.payCard)}: <span class="mono">${esc(pay.url)}</span></p>` : '',
  ].filter(Boolean) : [];
  const tx = look.texts;
  const closing = `<div class="closing">${totals}`
    + (payParts.length ? `<section class="block pay"><p class="label">${esc(w.pay)}</p>${payParts.join('')}</section>` : '')
    + (snap.conditions ? `<section class="block"><p class="label">${esc(w.conditions)}</p><p class="text">${esc(snap.conditions)}</p></section>` : '')
    + (show.notes && snap.notes ? `<section class="block"><p class="label">${esc(w.notes)}</p><p class="text">${esc(snap.notes)}</p></section>` : '')
    + (quote && snap.due_date ? `<p class="fine">${esc(tx.quote_terms ? tx.quote_terms.replace(/\{fecha\}/g, day(snap.due_date)) : w.validLine(day(snap.due_date)))}</p>` : '')
    + (!quote && tx.invoice_legal ? `<p class="fine">${esc(tx.invoice_legal)}</p>` : '')
    + (tx.thanks ? `<p class="thanks">${esc(tx.thanks)}</p>` : '') + '</div>';
  const mark = stamp === 'Draft' || stamp === 'Void' || stamp === 'Withdrawn' ? w.mark[stamp] : '';
  const footer = tx.footer || [co.company_name, co.tax_id ? `${w.taxId} ${co.tax_id}` : ''].filter(Boolean).join(' · ');
  return { lang, look, head1, headN, colgroup, thead, rows, closing, footer, mark, title: fileNameOf(snap) };
}

// ── the page ───────────────────────────────────────────────────────────
// A4 at 96 px to the inch; the sheet's padding in mm (16 top, 18 sides, 22 bottom with the footer in it): what the
// measure and the print agree on.
const CSS = `
@page { size: A4; margin: 0 }
*, *::before, *::after { box-sizing: border-box }
html, body { margin: 0; padding: 0 }
body { font-family: var(--text), system-ui, sans-serif; color: #1b1a17; font-size: 9.6pt; line-height: 1.45; -webkit-print-color-adjust: exact; print-color-adjust: exact; font-variant-numeric: lining-nums tabular-nums }
p, dl, dd { margin: 0 }
.sheet { position: relative; width: 210mm; height: 297mm; padding: 16mm 18mm 22mm; background: #fff; overflow: hidden; display: flex; flex-direction: column }
.sheet.measure { position: absolute; left: -10000px; top: 0; height: auto; visibility: hidden }
.label, .kind, .dates dt, th { font-size: 7.2pt; letter-spacing: .1em; text-transform: uppercase; color: #77736a; font-weight: 500 }
.company { font-family: var(--display), Georgia, serif; font-size: 17pt; line-height: 1.15 }
.company--small { font-size: 10.5pt }
.plines { display: flex; flex-direction: column; color: #5d5a53; font-size: 8.6pt; margin-top: 4px }
.plines span:empty { display: none }
.attn { color: #1b1a17; margin-top: 2px }
.logo { width: 52mm; height: 17mm; display: flex; align-items: center; justify-content: flex-start; margin-bottom: 8px }
.logo img { max-width: 100%; max-height: 100%; object-fit: contain }
.logo--small { width: 30mm; height: 8mm; margin: 0 }
.top { display: flex; justify-content: space-between; gap: 10mm; align-items: flex-start }
.from { min-width: 0; max-width: 58% }
.what { display: flex; flex-direction: column; align-items: flex-end; text-align: right; gap: 3px; flex: none }
.number { font-family: var(--display), Georgia, serif; font-size: 21pt; line-height: 1.05 }
.dates { display: flex; flex-direction: column; gap: 2px; margin-top: 4px }
.dates div { display: flex; gap: 8px; justify-content: flex-end; align-items: baseline }
.dates dd { font-size: 9pt }
.stamp { margin-top: 4px; padding: 2px 8px; border: 1px solid currentColor; font-size: 7.6pt; letter-spacing: .12em; text-transform: uppercase }
.stamp--paid, .stamp--accepted { color: #2f6b45 } .stamp--void, .stamp--declined, .stamp--overdue, .stamp--withdrawn { color: #a23a2a } .stamp--expired { color: #8a6a1c }
.to { margin-top: 7mm; padding-top: 5mm; border-top: 1px solid #e4e0d7; display: flex; flex-direction: column; gap: 2px }
.client { font-size: 12pt; margin-top: 2px }
.trade { display: block; font-size: 9pt; color: #5d5a53 }
.ref { margin-top: 5mm }
.head--first { padding-bottom: 7mm }
.head--next { display: flex; justify-content: space-between; align-items: center; gap: 8mm; padding-bottom: 4mm; margin-bottom: 4mm; border-bottom: 1px solid #e4e0d7 }
.cont { font-size: 8pt; color: #77736a }
table { width: 100%; border-collapse: collapse; table-layout: fixed }
th { text-align: left; padding: 0 6px 6px; border-bottom: 1px solid var(--accent) }
th.num { text-align: right }
td { padding: 7px 6px; border-bottom: 1px solid #ebe7de; vertical-align: top }
th:first-child, td:first-child { padding-left: 0 } th:last-child, td:last-child { padding-right: 0 }
tr { break-inside: avoid }
.num { text-align: right; white-space: nowrap; font-size: 9pt }
.muted { color: #9a968c }
.desc { white-space: pre-wrap; overflow-wrap: anywhere }
.desc span { display: block }
.off { color: #77736a; font-size: 8.4pt }
.sec { font-size: 7.2pt; letter-spacing: .1em; text-transform: uppercase; color: #77736a; margin-bottom: 3px }
.closing { display: flex; flex-direction: column; gap: 5mm; padding-top: 5mm }
.totals { margin-left: auto; width: 82mm; display: flex; flex-direction: column }
.totals div { display: flex; justify-content: space-between; gap: 12px; padding: 4px 0; border-bottom: 1px solid #ebe7de }
.totals dt { color: #5d5a53 } .totals dd { font-size: 9.4pt }
.on { color: #9a968c; font-size: 8.4pt }
.totals .total { border-bottom: 0; border-top: 1px solid var(--accent); padding-top: 7px; margin-top: 2px; align-items: baseline }
.totals .total dt { color: #1b1a17; font-size: 11pt }
.totals .total dd { font-family: var(--display), Georgia, serif; font-size: 17pt; color: var(--accent) }
.block { display: flex; flex-direction: column; gap: 3px; padding-top: 4mm; border-top: 1px solid #e4e0d7 }
.text { white-space: pre-wrap; overflow-wrap: anywhere }
.mono { font-family: 'IBM Plex Mono', ui-monospace, Menlo, monospace; font-size: 8.8pt }
.bankline { margin: 0 }
.bankline .k { display: inline-block; min-width: 22mm; color: #77736a }
.fine { font-size: 8.2pt; color: #5d5a53; white-space: pre-wrap }
.thanks { font-family: var(--display), Georgia, serif; font-size: 11pt; color: var(--accent) }
.foot { position: absolute; left: 18mm; right: 18mm; bottom: 10mm; display: flex; justify-content: space-between; gap: 8mm; font-size: 7.6pt; color: #8a867c; border-top: 1px solid #ebe7de; padding-top: 3mm }
.foot span:first-child { min-width: 0; overflow: hidden; text-overflow: ellipsis; white-space: nowrap }
.foot span:last-child { white-space: nowrap }
.mark { position: absolute; inset: 0; display: flex; align-items: center; justify-content: center; pointer-events: none; z-index: 2 }
.mark span { transform: rotate(-32deg); font-family: var(--text), sans-serif; font-weight: 700; font-size: 88pt; letter-spacing: .08em; color: rgba(27,26,23,.07) }
.is-void .mark span { color: rgba(162,58,42,.11) }
.t-moderno .band { position: absolute; left: 0; right: 0; top: 0; height: 5mm; background: var(--accent) }
.t-moderno .head--first .top { align-items: center; padding-top: 2mm }
.t-moderno .kind { font-family: var(--display), sans-serif; font-size: 20pt; letter-spacing: .01em; text-transform: none; color: var(--accent); font-weight: 700 }
.t-moderno .number { font-family: var(--text), sans-serif; font-size: 12pt; font-weight: 600 }
.t-moderno .company { font-weight: 700; font-size: 15pt }
.t-moderno .company--party { font-size: 11pt; font-weight: 700 }
.t-moderno .company--small { font-size: 10.5pt }
.t-moderno .parties { display: grid; grid-template-columns: 1fr 1fr; gap: 6mm; margin-top: 7mm }
.t-moderno .party { padding: 4mm 5mm; background: var(--accent-tint); border-radius: 2mm; display: flex; flex-direction: column; gap: 2px; min-width: 0 }
.t-moderno .party .client { font-size: 11pt; font-weight: 600 }
.t-moderno th { background: var(--accent-tint); color: var(--accent); border-bottom: 0; padding-top: 6px; font-weight: 600 }
.t-moderno th:first-child, .t-moderno td:first-child { padding-left: 6px } .t-moderno th:last-child, .t-moderno td:last-child { padding-right: 6px }
.t-moderno .totals .total { background: var(--accent-tint); border-top: 0; padding: 8px 10px; margin-top: 6px; border-radius: 2mm }
.t-moderno .totals .total dd { font-family: var(--display), sans-serif; font-weight: 700; font-size: 15pt }
.t-moderno .thanks { font-weight: 700 }
.t-moderno .head--next { border-bottom-color: var(--accent-line) }
.t-minimal { font-size: 9pt }
.t-minimal .company { font-family: var(--text), sans-serif; font-size: 11pt; font-weight: 600 }
.t-minimal .number { font-family: var(--text), sans-serif; font-size: 11pt; font-weight: 600 }
.t-minimal .kind, .t-minimal .label, .t-minimal .dates dt, .t-minimal th { text-transform: none; letter-spacing: 0; font-size: 8pt; color: #8a867c }
.t-minimal .to { border-top: 0; padding-top: 0; margin-top: 9mm }
.t-minimal .client { font-size: 10.5pt; font-weight: 500 }
.t-minimal th { border-bottom: 1px solid #e4e0d7 }
.t-minimal td { border-bottom: 0; padding-top: 5px; padding-bottom: 5px }
.t-minimal .totals div { border-bottom: 0; padding: 2px 0 }
.t-minimal .totals .total { border-top: 1px solid #e4e0d7; padding-top: 6px }
.t-minimal .totals .total dd { font-family: var(--text), sans-serif; font-weight: 600; font-size: 13pt }
.t-minimal .block { border-top: 0; padding-top: 0 }
.t-minimal .thanks { font-family: var(--text), sans-serif; font-size: 9.6pt }
.t-minimal .foot { border-top: 0 }
@media screen {
  html { background: var(--ground, #e9e7e2) }
  body { padding: 12px 0 }
  .sheet:not(.measure) { margin: 0 auto 14px; box-shadow: 0 1px 2px rgba(0,0,0,.08), 0 6px 24px rgba(0,0,0,.07) }
}
@media print { html, body { background: #fff; padding: 0; zoom: 1 !important } .sheet { break-after: page; box-shadow: none; margin: 0 } .sheet:last-child { break-after: auto } }
`;

/*
 * The page's own script: wait for the faces and the logo, measure every part on a hidden sheet, decide the pages
 * (paginate, given), build the sheets with «Página i de N», fit the screen's width, tell the parent its height and say
 * printReady. Self-contained: it is written into the page as text.
 */
async function lay(paginateFn, D) {
  const sleep = (ms) => new Promise((r) => { setTimeout(r, ms); });
  const doc = document;
  try {
    for (const link of doc.querySelectorAll('link[rel=stylesheet]')) if (!link.sheet) await Promise.race([new Promise((r) => { link.onload = r; link.onerror = r; }), sleep(2500)]);
    await Promise.race([Promise.all(D.faces.map((f) => doc.fonts.load(f).catch(() => null))), sleep(2500)]);
    await Promise.race([doc.fonts.ready, sleep(1500)]);
  } catch (e) { /* the system's faces will do */ }
  await Promise.all([...doc.images].map((i) => (i.decode ? i.decode().catch(() => null) : null)));
  const root = doc.getElementById('pages');
  const mm = 96 / 25.4;
  const room = 297 * mm - (D.keep ? D.keep * (96 / 72) : (16 + 22) * mm);
  const ms = doc.createElement('section');
  ms.className = 'sheet measure';
  ms.innerHTML = `<div class="h1">${D.head1}</div><div class="hn">${D.headN}</div><table style="${D.tableStyle || ''}">${D.colgroup}${D.thead}<tbody>${D.rows.join('')}</tbody></table>${D.closing}`;
  root.appendChild(ms);
  const hOf = (el) => (el ? el.getBoundingClientRect().height : 0);
  const head = hOf(ms.querySelector('thead'));
  const rows = [...ms.querySelectorAll('tbody tr')].map(hOf);
  const closing = hOf(ms.querySelector('.closing'));
  const h1 = hOf(ms.querySelector('.h1'));
  const hn = hOf(ms.querySelector('.hn'));
  root.removeChild(ms);
  const plan = paginateFn({ first: room - h1 - head - 3, next: room - hn - head - 3, rows, closing });
  const n = plan.length;
  root.innerHTML = plan.map((p, i) => `<section class="sheet${D.void ? ' is-void' : ''}${n > 1 ? ' many' : ''}">${i === 0 ? D.head1 : D.headN}${p.to > p.from || i === 0 ? `<table style="${D.tableStyle || ''}">${D.colgroup}${D.thead}<tbody>${D.rows.slice(p.from, p.to).join('')}</tbody></table>` : ''}${p.closing ? D.closing : ''}${D.foot ? D.foot.split('{i}').join(i + 1).split('{n}').join(n) : `<footer class="foot"><span>${D.footer}</span><span>${D.page.replace('{i}', i + 1).replace('{n}', n)}</span></footer>`}${D.mark ? `<div class="mark"><span>${D.mark}</span></div>` : ''}</section>`).join('');
  doc.documentElement.dataset.pages = String(n);
  const fit = () => {
    if (window.matchMedia && window.matchMedia('print').matches) return;
    const z = Math.min(1, Math.max(0.2, (window.innerWidth - (D.edge || 0)) / (210 * mm)));
    doc.body.style.zoom = String(z);
    try { window.parent.postMessage({ type: 'inv-paper', id: D.id, height: Math.ceil((n * (297 * mm + 14) + 24) * z) + 2, pages: n }, '*'); } catch (e) { /* alone */ }
  };
  fit();
  window.addEventListener('resize', fit);
  window.addEventListener('beforeprint', () => { doc.body.style.zoom = '1'; });
  window.addEventListener('afterprint', fit);
  doc.documentElement.dataset.printReady = '1';
}

const jsonIn = (v) => JSON.stringify(v).replace(/</g, '\\u003c').replace(/[\u2028\u2029]/g, (c) => (c === '\u2028' ? '\\u2028' : '\\u2029'));

/**
 * The whole page for a snapshot: its <title> is the file's name (what the browser's «Guardar como PDF» proposes).
 * opts: today (YYYY-MM-DD, for Overdue/Expired), id (the tag of its messages to the parent), edge (px kept free beside
 * the sheet when fitting the screen; 0 for print), ground (the colour around the sheets on screen), bare (no room around).
 */
export function documentHtml(snap, opts = {}) {
  const p = paperParts({ ...snap, design: designOf(snap.design) }, opts);
  const f = p.look.font;
  const lang = p.lang;
  const data = {
    head1: p.head1, headN: p.headN, colgroup: p.colgroup, thead: p.thead, rows: p.rows, closing: p.closing,
    footer: esc(p.footer), page: WORDS[lang].page('{i}', '{n}'), mark: p.mark, void: !!p.mark && p.mark !== WORDS[lang].mark.Draft,
    foot: p.foot || '', keep: p.footHeight ? p.footHeight + 6 : 0, tableStyle: p.tableStyle || '',
    faces: p.look.faces || [`400 16px "${f.display}"`, `600 16px "${f.display}"`, `400 16px "${f.text}"`, `500 16px "${f.text}"`], id: opts.id || '', edge: opts.edge ?? 24,
  };
  return `<!doctype html><html lang="${lang}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="robots" content="noindex">
<title>${esc(p.title)}</title>
<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
${(p.look.links || [f.google]).map((g) => `<link rel="stylesheet" href="https://fonts.googleapis.com/css2?${esc(g)}&amp;display=block">`).join('')}
<style>:root{--accent:${p.look.accentHex};--accent-tint:${p.look.accentTint};--accent-line:${p.look.accentLine};--display:'${f.display}';--text:'${f.text}';${opts.ground ? `--ground:${opts.ground};` : ''}}${CSS}${opts.bare ? '@media screen{html{background:#fff}body{padding:0}.sheet:not(.measure){margin:0;box-shadow:none}}' : ''}${p.look.own && p.look.template === 'propia' ? OWN_CSS : ''}</style>
</head><body class="t-${p.look.template}"><main id="pages"></main>
<script>(${lay.toString()})((${paginate.toString()}), ${jsonIn(data)});</script>
</body></html>`;
}

export { LEGAL };
