SELECT k, box FROM inv_links
