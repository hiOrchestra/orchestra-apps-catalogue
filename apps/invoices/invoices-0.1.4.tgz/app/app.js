// The router and the bar. Overview is home: what is owed, what is late, the
// quotes waiting, and what waits for you. Invoices and Quotes are the lists;
// a document opens on its own page (/doc/<id>): a draft as its editor, an
// issued one as the paper the client sees with what you can do beside it.
import { render as overview } from './screens/overview.js';
import { render as list } from './screens/list.js';
import { render as doc } from './screens/doc.js';
import { render as clients } from './screens/clients.js';
import { render as settings } from './screens/settings.js';

const { el, router } = Orch;

router.define({
  '/': overview,
  '/invoices': (p, path) => list({ kind: 'invoice', ...p }, path),
  '/invoices/:state': (p, path) => list({ kind: 'invoice', ...p }, path),
  '/quotes': (p, path) => list({ kind: 'quote', ...p }, path),
  '/quotes/:state': (p, path) => list({ kind: 'quote', ...p }, path),
  '/doc/:id': doc,
  '/clients': clients,
  '/clients/:state': clients,
  '/settings': settings,
}, () => Orch.mount('view', el('div', { class: 'oc-state' }, [
  el('p', 'There is no screen here.'), router.link('/', 'Go to the overview'),
]))).start();

Orch.mount('nav', [
  router.link('/', 'Overview', { class: 'oc-tab' }),
  router.link('/invoices', 'Invoices', { class: 'oc-tab' }),
  router.link('/quotes', 'Quotes', { class: 'oc-tab' }),
  router.link('/clients', 'Clients', { class: 'oc-tab' }),
  router.link('/settings', 'Settings', { class: 'oc-tab' }),
]);
