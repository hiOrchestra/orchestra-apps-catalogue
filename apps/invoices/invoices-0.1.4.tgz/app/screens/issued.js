// An issued document: the paper exactly as the client sees it, and beside
// it one place for each thing you do with it — its link, the email that
// carries it, the payment (or the client's answer to a quote), and Void (an
// invoice) or Withdraw (a quote still waiting), which asks twice and says
// what it takes with it.
import { A, C, T, act, area, copy, day, field, input, integrations, kindWord, linkOf, money, newDoc, today } from '../data.js';
import { paper } from '../paper.js';
import { openEmail } from './email.js';
import { voidStep } from './void.js';
import { answer } from './answer.js';

const { el } = Orch;

export async function issued(d, s, again) {
  const emails = (await Orch.db.list(T.emails, { filter: { doc_id: d._id }, sort: '_id:desc', limit: 50 })).rows || [];
  const link = linkOf(d, s);
  const quote = d.kind === 'quote';
  // Its invoice; a discarded draft frees the quote to make another.
  const made = quote && d.invoice_id ? await Orch.db.get(T.docs, d.invoice_id).catch(() => null) : null;
  return el('div', { class: 'iv-split' }, [
    el('div', { class: 'iv-paperwrap' }, paper(C.snapshot(d, s), { today: today(s) })),
    el('aside', { class: 'iv-side oc-stack' }, [
      section('Client\'s link', [
        el('p', { class: 'oc-help' }, quote ? 'Where the client reads the quote and accepts or declines it.' : 'Where the client reads the invoice, saves it as a PDF and pays it.'),
        el('div', { class: 'iv-code' }, [el('code', link), el('button', { type: 'button', class: 'oc-btn oc-btn--sm', onClick: () => copy(link, 'Link copied.') }, 'Copy')]),
        el('a', { href: link, target: '_blank', rel: 'noopener', class: 'oc-small' }, 'Open it as the client sees it ↗'),
      ]),
      mail(d, s, emails.filter((m) => m.purpose !== 'reminder'), link, again),
      quote ? answer(d, s, again, made && made.status !== 'Discarded' ? made : null) : payment(d, s, again),
      reminders(emails.filter((m) => m.purpose === 'reminder'), again),
      section('More', [
        el('button', { type: 'button', class: 'oc-btn oc-btn--ghost oc-btn--sm', onClick: () => newDoc(d.kind, { client_id: d.client_id || '', title: d.title || '', currency: d.currency, lines: d.lines, withholding_rate: d.withholding_rate || 0, notes: d.notes || '' }) }, `Duplicate as a new draft ${kindWord(d.kind)}`),
        d.status === (quote ? 'Sent' : 'Issued') ? voidStep(d, again) : null,
        d.status === 'Void' ? el('p', { class: 'oc-help' }, `${quote ? 'Withdrawn' : 'Voided'} ${day(String(d.void_at || '').slice(0, 10))}${d.void_reason ? `: ${d.void_reason}` : ''}. Its number stays used, and the client's page says it ${quote ? 'was withdrawn' : 'is void'}.`) : null,
      ]),
    ]),
  ]);
}

const section = (title, body) => el('section', { class: 'iv-sidesec oc-stack oc-stack--tight' }, [el('h2', { class: 'oc-eyebrow' }, title), ...body]);

/** The email that carries it: written here from the template, read, and sent with one click. */
function mail(d, s, list, link, again) {
  const last = list[0];
  if (last && ['Approved', 'Sending'].includes(last.status)) return section('Email', [el('p', `Going out to ${last.to_email} now, from your Gmail.`)]);
  if (last && last.status === 'Failed') {
    return section('Email', [el('p', { class: 'iv-bad' }, `The email to ${last.to_email} did not go out.`),
      el('button', { type: 'button', class: 'oc-btn oc-btn--sm', onClick: () => openEmail(last._id, again) }, 'See why, and send it again')]);
  }
  const sent = list.find((m) => m.status === 'Sent');
  const frozen = JSON.parse(d.client_snapshot || '{}');
  const t = C.sendEmail(d, s, link);
  const to = input(frozen.email || '', { type: 'email', maxlength: '200' });
  const subject = input(t.subject, { maxlength: '160' });
  const body = area(t.body, 9, { maxlength: '5000' });
  const go = el('button', { type: 'button', class: 'oc-btn oc-btn--primary' }, sent ? 'Send it again' : `Send ${kindWord(d.kind)}`);
  go.addEventListener('click', async () => {
    const v = { doc_id: d._id, to_email: C.normEmail(to.value), subject: subject.value.trim(), body: body.value.replace(/\r\n/g, '\n').trim() };
    if (!C.isEmail(v.to_email)) { Orch.toast('The address does not look right.', { error: true }); return; }
    if (!v.subject || !v.body) { Orch.toast('It needs a subject and a message.', { error: true }); return; }
    if (!v.body.includes(link)) { Orch.toast('Keep the link in the message: it is how the client opens the document.', { error: true }); return; }
    go.disabled = true;
    if (await act(A.writeEmail, v)) { await act(A.sendNow, {}, `Sending to ${v.to_email}.`); setTimeout(again, 1500); }
    go.disabled = false;
  });
  const form = el('div', { class: 'oc-stack oc-stack--tight' }, [
    field('To', to), field('Subject', subject), field('Message', body),
    el('p', { class: 'oc-help' }, ['Sent from the Gmail account connected in ', integrations('Orchestra → Integrations'), '. Not connected yet? Connect it there first, or copy the link above into your own email.']),
    el('div', { class: 'oc-row' }, go),
  ]);
  if (sent) return section('Email', [el('p', `Emailed to ${sent.to_email} on ${day(String(sent.sent_at || '').slice(0, 10))}.`), el('details', { class: 'iv-details' }, [el('summary', 'Send it again'), form])]);
  return section('Email', [el('p', { class: 'oc-help' }, `Not sent yet. Read it, change what you like, and send: nothing goes out until you press ${go.textContent}.`), form]);
}

function payment(d, s, again) {
  if (d.status === 'Paid') {
    // Only a payment a person recorded can be undone here; Stripe's is refunded in Stripe.
    if (d.paid_how === 'stripe') return section('Payment', [el('p', `Paid on ${day(d.paid_at)}, online with Stripe.`), el('p', { class: 'oc-help' }, 'A card payment is undone in Stripe (a refund), not here.')]);
    return section('Payment', [el('p', `Paid on ${day(d.paid_at)}.`),
      el('button', { type: 'button', class: 'oc-btn oc-btn--ghost oc-btn--sm', onClick: async () => {
        if (!(await Orch.confirm(`Mark ${d.number} as not paid? The payment recorded for ${day(d.paid_at)} is removed, the invoice goes back to outstanding (overdue if its day has passed), and the client's page asks for payment again.`, { yes: 'Not paid' }))) return;
        if (await act(A.unpaid, { id: d._id }, 'Back to outstanding.')) again();
      } }, 'Not paid after all')]);
  }
  if (d.status !== 'Issued') return null;
  const on = input(today(s), { type: 'date' });
  const stripe = s.stripe_on !== 'yes' ? null
    : d.stripe_link_active === 'yes' ? el('p', { class: 'oc-help' }, ['The client can pay by card on Stripe from their page; it is marked paid here by itself within the hour. ', el('a', { href: d.stripe_link_url, target: '_blank', rel: 'noopener' }, 'Stripe page ↗')])
      : d.stripe_note ? el('div', { class: 'oc-stack oc-stack--tight' }, [el('p', { class: 'iv-bad' }, d.stripe_note),
        el('button', { type: 'button', class: 'oc-btn oc-btn--sm', onClick: async () => { if (await act(A.retryStripe, { id: d._id }, 'Trying again.')) setTimeout(again, 2500); } }, 'Try again')])
        : el('p', { class: 'oc-help' }, 'Making the Stripe payment link…');
  return section('Payment', [
    el('p', `${money(d.total, d.currency)} ${C.stateOf(d, today(s)) === 'Overdue' ? `was due on ${day(d.due_date)}` : `due on ${day(d.due_date)}`}.`),
    stripe,
    el('div', { class: 'iv-paidrow' }, [field('Paid on', on), el('button', { type: 'button', class: 'oc-btn oc-btn--primary', onClick: async () => {
      if (!C.realDay(on.value)) { Orch.toast('Pick the day it was paid.', { error: true }); return; }
      if (await act(A.paid, { id: d._id, paid_at: on.value }, 'Marked as paid.')) again();
    } }, 'Mark as paid')]),
  ]);
}

function reminders(list, again) {
  if (!list.length) return null;
  return section('Payment reminders', [el('ul', { class: 'iv-mini' }, list.map((m) => el('li', [
    el('button', { type: 'button', class: 'iv-linkish', onClick: () => openEmail(m._id, again) }, `Reminder ${m.n || ''}: ${m.status === 'Review' ? 'waiting for your OK' : m.status.toLowerCase()}`),
    m.sent_at ? el('span', { class: 'oc-value oc-muted' }, ` ${day(String(m.sent_at).slice(0, 10))}`) : null,
  ])))]);
}
