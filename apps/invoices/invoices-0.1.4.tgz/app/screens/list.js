// Invoices and Quotes: thin rows, one tab per state. Overdue and Expired
// are not stored: an issued invoice past its due day is overdue, an issued
// quote past its day has expired (the `documents` view works it out, in
// Settings' time zone). A quote's status Sent means issued, emailed or not.
// Quotes also offer "Draft with the agent": one sentence becomes the lines.
import { T, V, field, head, area, newDoc, select, settings, sheet } from '../data.js';
import { docRow } from './overview.js';

const { el, router, fmt } = Orch;

const TABS = {
  invoice: [['', 'All', {}], ['drafts', 'Drafts', { status: 'Draft' }], ['outstanding', 'Outstanding', { status: 'Issued' }], ['overdue', 'Overdue', { state: 'Overdue' }],
    ['paid', 'Paid', { status: 'Paid' }], ['void', 'Void', { status: 'Void' }]],
  quote: [['', 'All', {}], ['drafts', 'Drafts', { status: 'Draft' }], ['waiting', 'Waiting', { state: 'Sent' }], ['accepted', 'Accepted', { status: 'Accepted' }],
    ['declined', 'Declined', { status: 'Declined' }], ['expired', 'Expired', { state: 'Expired' }], ['withdrawn', 'Withdrawn', { status: 'Void' }]],
};
const EMPTY = {
  invoice: { '': 'No invoices yet. New invoice starts one; a quote that is accepted becomes one with a click.', overdue: 'Nothing is overdue.', outstanding: 'Nobody owes you anything.' },
  quote: { '': 'No quotes yet. Write one, or let the agent draft it from a sentence.', waiting: 'No quote is waiting for an answer.' },
};

export function render({ kind, state = '' }, path) {
  Orch.load('view', async () => {
    const tabs = TABS[kind];
    const tab = tabs.find((x) => x[0] === state) || tabs[0];
    const [list, counts, late] = await Promise.all([
      Orch.db.view(V.docs, { filter: Object.assign({ kind }, tab[2]), sort: tab[0] === 'drafts' ? '_id:desc' : 'issued:asc', limit: 300 }),
      Orch.db.count(T.docs, { filter: { kind, status: { ne: 'Discarded' } }, group: 'status' }),
      Orch.db.view(V.docs, { filter: { kind, state: kind === 'quote' ? 'Expired' : 'Overdue' }, limit: 1, count: true }),
    ]);
    const by = (st) => (((counts.groups || []).find((g) => g.value === st) || {}).count || 0);
    const lateN = late.total || 0;
    const n = (t) => {
      if (!t[0]) return (counts.groups || []).reduce((a, g) => a + g.count, 0);
      if (t[2].status) return by(t[2].status);
      if (t[2].state === 'Sent') return by('Sent') - lateN;
      return lateN;
    };
    // Drafts first, newest first; then the rest by number, newest first.
    const rows = (list.rows || []).sort((a, b) => (a.issued === b.issued ? (b.issued === '1' ? (Number(b.series_year) - Number(a.series_year)) || (Number(b.seq) - Number(a.seq)) : b._id - a._id) : a.issued < b.issued ? -1 : 1));
    const tools = kind === 'quote'
      ? [el('button', { type: 'button', class: 'oc-btn', onClick: () => withAgent() }, 'Draft with the agent'), el('button', { type: 'button', class: 'oc-btn oc-btn--primary', onClick: () => newDoc('quote') }, 'New quote')]
      : [el('button', { type: 'button', class: 'oc-btn oc-btn--primary', onClick: () => newDoc('invoice') }, 'New invoice')];
    const base = kind === 'quote' ? '/quotes' : '/invoices';
    return el('div', { class: 'oc-stack oc-stack--loose' }, [
      head(kind === 'quote' ? 'Quotes' : 'Invoices', kind === 'quote'
        ? 'What you offered, and what the client answered. An accepted quote becomes an invoice with one click.'
        : 'Every invoice: drafts have no number until you issue them; an issued one can only be marked paid or voided.', tools),
      el('nav', { class: 'oc-tabs', 'aria-label': 'Which ones' }, tabs.filter((t) => !t[0] || t === tab || n(t)).map((t) => router.link(
        `${base}${t[0] ? `/${t[0]}` : ''}`, [t[1], el('span', { class: 'oc-count' }, fmt.number(Math.max(0, n(t))))],
        { class: 'oc-tab', 'aria-current': t === tab ? 'page' : null }))),
      rows.length ? el('ul', { class: 'iv-rows' }, rows.map(docRow))
        : el('div', { class: 'oc-card oc-state' }, el('p', { class: 'oc-help' }, (EMPTY[kind][tab[0]]) || 'Nothing here.')),
    ]);
  });
}

/** One sentence (and, if you like, the client) → a draft quote the agent fills in. */
export async function withAgent() {
  const s = await settings();
  if (!s.agent) { Orch.toast('No agent is set in Settings, so nobody can draft it. Write the quote yourself, or set the agent.', { error: true }); return; }
  const clients = (await Orch.db.list(T.clients, { filter: { archived: { ne: 'yes' } }, sort: 'name:asc', limit: 500 })).rows || [];
  const what = area('', 4, { maxlength: '2000', required: true, placeholder: 'Web redesign for Acme: 3 pages and a CMS, 4,500 € in total, delivered in 6 weeks.' });
  const who = select('', [['', 'Choose later'], ...clients.map((c) => [c._id, c.name])]);
  const go = el('button', { type: 'submit', class: 'oc-btn oc-btn--primary' }, 'Draft it');
  const form = el('form', { class: 'oc-stack' }, [
    el('p', { class: 'oc-help' }, 'Say what you are quoting, for whom, and the price if you know it. The agent writes the lines; you check them before anything goes to the client.'),
    field('What is it?', what), field('Client', who),
    el('div', { class: 'oc-row' }, go),
  ]);
  const d = sheet(form, { title: 'Draft a quote with the agent' });
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    if (String(what.value).trim().length < 8) { Orch.toast('Say a little more about what it is.', { error: true }); return; }
    go.disabled = true;
    const extra = { ai_prompt: String(what.value).trim(), lines: '[]' };
    if (who.value) extra.client_id = Number(who.value);
    const r = await newDoc('quote', extra);
    if (r) { d.close(); Orch.toast('The agent is writing it: the lines appear here in a minute or two.'); }
    go.disabled = false;
  });
}

