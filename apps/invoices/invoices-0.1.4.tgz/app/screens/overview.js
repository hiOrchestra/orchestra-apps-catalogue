// Home. Four numbers that each open their list (outstanding, overdue, paid
// this month, quotes waiting), what waits for you (reminders to approve,
// emails that failed, documents that could not be issued), and the latest
// documents. Getting started sits on top until the company and the way you
// get paid are set.
import { T, V, badge, day, head, kindWord, money, newDoc, row, settings } from '../data.js';
import { startCard } from './start.js';
import { openEmail } from './email.js';

const { el, router } = Orch;

export function render() {
  Orch.load('view', async () => {
    const s = await settings(true);
    if (!s._id) return el('p', { class: 'oc-state' }, 'Invoices is not installed in this project.');
    const [ov, waiting, recent] = await Promise.all([
      Orch.db.view(V.overview, { limit: 50 }),
      Orch.db.list(T.emails, { filter: { status: ['Review', 'Failed'] }, sort: '_id:desc', limit: 20 }),
      Orch.db.view(V.docs, { sort: '_id:desc', limit: 8 }),
    ]);
    const cur = s.currency || 'EUR';
    const rows = ov.rows || [];
    const mine = rows.find((r) => r.currency === cur) || { currency: cur };
    const others = rows.filter((r) => r.currency !== cur && (r.outstanding_n || r.quotes_open_n || r.paid_month_n));
    const stuck = (recent.rows || []).filter((d) => d.issue_note && d.status === 'Draft');
    return el('div', { class: 'oc-stack oc-stack--loose' }, [
      head('Overview', 'What you are owed, who is late, and the quotes waiting for an answer.', [
        el('button', { type: 'button', class: 'oc-btn', onClick: () => newDoc('quote') }, 'New quote'),
        el('button', { type: 'button', class: 'oc-btn oc-btn--primary', onClick: () => newDoc('invoice') }, 'New invoice'),
      ]),
      startCard(s, render),
      el('div', { class: 'oc-metrics iv-metrics' }, [
        metric('Outstanding', money(mine.outstanding || 0, cur), count(mine.outstanding_n, 'invoice', 'invoices'), '/invoices/outstanding'),
        metric('Overdue', money(mine.overdue || 0, cur), count(mine.overdue_n, 'invoice', 'invoices'), '/invoices/overdue', mine.overdue_n ? 'bad' : ''),
        metric('Paid this month', money(mine.paid_month || 0, cur), count(mine.paid_month_n, 'invoice', 'invoices'), '/invoices/paid'),
        metric('Quotes waiting', money(mine.quotes_open || 0, cur), count(mine.quotes_open_n, 'quote', 'quotes'), '/quotes/waiting'),
      ]),
      others.length ? el('p', { class: 'oc-help' }, `Also in other currencies: ${others.map((r) => `${money(r.outstanding || 0, r.currency)} outstanding`).join(' · ')}.`) : null,
      waitingFor(waiting.rows || [], stuck),
      el('section', { class: 'oc-stack' }, [
        el('div', { class: 'oc-row oc-row--between' }, [el('h2', { class: 'oc-h2' }, 'Latest'), router.link('/invoices', 'All invoices →', { class: 'oc-small' })]),
        (recent.rows || []).length
          ? el('ul', { class: 'iv-rows' }, recent.rows.map(docRow))
          : el('div', { class: 'oc-card oc-state' }, [el('p', { class: 'oc-state__title' }, 'No quotes or invoices yet.'), el('p', { class: 'oc-help' }, 'Start with New invoice, or a quote the agent drafts from one sentence (Quotes).')]),
      ]),
    ]);
  });
}

const count = (n, one, many) => `${n || 0} ${Number(n) === 1 ? one : many}`;

function metric(label, value, sub, path, tone) {
  return router.link(path, [
    el('span', { class: 'oc-kpi__label' }, label),
    el('span', { class: `oc-kpi__value iv-metric__value${tone ? ` iv-metric__value--${tone}` : ''}` }, value),
    el('span', { class: 'iv-metric__sub' }, sub),
  ], { class: 'oc-metric iv-metric' });
}

export function docRow(d) {
  const state = d.state || d.status;
  return row({
    to: `/doc/${d._id}`,
    first: d.number || 'Draft',
    name: d.client_name || 'No client yet',
    sub: [kindWord(d.kind, true), d.title ? ` · ${d.title}` : '', d.issue_date ? ` · ${day(d.issue_date)}` : '', d.due_date && d.status !== 'Draft' && d.status !== 'Paid' ? ` · ${d.kind === 'quote' ? 'valid until' : 'due'} ${day(d.due_date)}` : ''].join(''),
    right: [el('span', { class: 'oc-value' }, money(d.total || 0, d.currency)), badge(state, d)],
  });
}

function waitingFor(emails, stuck) {
  if (!emails.length && !stuck.length) return null;
  return el('section', { class: 'oc-stack' }, [
    el('h2', { class: 'oc-h2' }, 'Waiting for you'),
    el('ul', { class: 'iv-rows' }, [
      ...emails.map((m) => row({
        onClick: () => openEmail(m._id, render),
        first: m.status === 'Failed' ? 'Failed' : m.purpose === 'reminder' ? `Reminder ${m.n || ''}` : 'Email',
        name: m.subject || '—',
        sub: m.status === 'Failed' ? `To ${m.to_email} · it did not go out: open it to send it again or drop it` : `To ${m.to_email} · written ${m.drafted_by === 'agent' ? 'by the agent' : 'from the template'}: read it, then approve or drop`,
        right: badge(m.status === 'Failed' ? 'Failed' : 'Review'),
      })),
      ...stuck.map((d) => row({ to: `/doc/${d._id}`, first: 'Draft', name: d.client_name || 'No client yet', sub: d.issue_note, right: badge('Draft') })),
    ]),
  ]);
}

