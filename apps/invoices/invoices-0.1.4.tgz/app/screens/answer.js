// A quote's answer: accepted (and the one invoice made from it), declined,
// or waiting, where a person can record what the client said elsewhere.
import { A, C, act, day, field, input, today } from '../data.js';

const { el, router } = Orch;

const section = (title, body) => el('section', { class: 'iv-sidesec oc-stack oc-stack--tight' }, [el('h2', { class: 'oc-eyebrow' }, title), ...body]);

export function answer(d, s, again, made) {
  if (d.status === 'Void') return null;
  if (d.status === 'Accepted') {
    // One invoice per quote: this button, and a unique index on quote_id (a second make_invoice rolls back).
    return section('Answer', [
      el('p', `Accepted${d.accepted_name ? ` by ${d.accepted_name}` : ''} on ${day(String(d.accepted_at || '').slice(0, 10))}${d.answered_by === 'client' ? ', on their page' : ''}.`),
      made ? router.link(`/doc/${made._id}`, 'Open its invoice →', { class: 'oc-btn oc-btn--sm' })
        : el('button', { type: 'button', class: 'oc-btn oc-btn--primary', onClick: async (e) => {
          if (e.target.disabled) return;
          e.target.disabled = true;
          const r = await act(A.makeInvoice, { quote_id: d._id, client_id: d.client_id, title: d.title || '', currency: d.currency, lines: d.lines, due_date: C.addDays(today(s), Number(s.payment_days) || 30), withholding_rate: d.withholding_rate || 0,
            notes: d.notes || '', subtotal: d.subtotal, tax_total: d.tax_total, withholding: d.withholding, total: d.total }, 'Invoice drafted from the quote.');
          const inv = r && (r.results || []).find((x) => x.op === 'insert');
          if (inv) router.go(`/doc/${inv._id}`); else again(); // made meanwhile (another tab): show it
        } }, 'Make the invoice'),
    ]);
  }
  if (d.status === 'Declined') return section('Answer', [el('p', `Declined on ${day(String(d.declined_at || '').slice(0, 10))}${d.decline_reason ? `: "${d.decline_reason}"` : '.'}`)]);
  const who = input('', { maxlength: '120', placeholder: 'Who accepted' });
  return section('Answer', [
    el('p', { class: 'oc-help' }, 'The client answers on their page. If they told you another way, record it here.'),
    el('div', { class: 'iv-paidrow' }, [field('Accepted by', who), el('button', { type: 'button', class: 'oc-btn', onClick: async () => {
      if (await act(A.accepted, { id: d._id, accepted_name: who.value.trim() || 'Told by phone or email' }, 'Marked as accepted.')) again();
    } }, 'Mark accepted')]),
    el('button', { type: 'button', class: 'oc-btn oc-btn--ghost oc-btn--sm', onClick: async () => {
      if (!(await Orch.confirm('Mark this quote as declined?', { yes: 'Declined' }))) return;
      if (await act(A.declined, { id: d._id, decline_reason: 'Told by phone or email' }, 'Marked as declined.')) again();
    } }, 'Mark declined'),
  ]);
}
