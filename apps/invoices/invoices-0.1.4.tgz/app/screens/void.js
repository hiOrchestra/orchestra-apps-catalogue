// Void, the one destructive thing on an issued document: an invoice is
// voided, a quote waiting for an answer is withdrawn. Two steps: the second
// says what goes with it (the number stays used, the client's page says so,
// an invoice's Stripe link goes off, a quote can no longer be accepted), and
// its button waits for the tick.
import { A, act, field, input } from '../data.js';

const { el } = Orch;

export function voidStep(d, again) {
  const quote = d.kind === 'quote';
  const host = el('div', { class: 'oc-stack oc-stack--tight' });
  const first = el('button', { type: 'button', class: 'oc-btn oc-btn--ghost oc-btn--sm iv-danger', onClick: () => {
    const reason = input('', { maxlength: '300', placeholder: 'Why (for your records)' });
    const ack = el('input', { type: 'checkbox' });
    const go = el('button', { type: 'button', class: 'oc-btn oc-btn--danger oc-btn--sm', disabled: true }, `${quote ? 'Withdraw' : 'Void'} ${d.number}`);
    ack.addEventListener('change', () => { go.disabled = !ack.checked; });
    go.addEventListener('click', async () => {
      go.disabled = true;
      const ok = await act(quote ? A.withdraw : A.void, { id: d._id, void_reason: reason.value.trim() || (quote ? 'Withdrawn' : 'Voided') }, `${d.number} is ${quote ? 'withdrawn' : 'void'}.`);
      if (ok) again(); else go.disabled = false;
    });
    Orch.mount(host, el('div', { class: 'iv-void oc-stack oc-stack--tight' }, [
      el('p', quote
        ? `Withdrawing ${d.number} cannot be undone. The number stays used and is never given again; the client's page will say the quote was withdrawn, and it can no longer be accepted. To offer again, issue a new quote.`
        : `Voiding ${d.number} cannot be undone. The number stays used and is never given again; the client's page will say the invoice is void${d.stripe_link_active === 'yes' ? ', and its Stripe payment link is switched off' : ''}. To bill again, issue a new invoice.`),
      field('Reason', reason),
      el('label', { class: 'iv-check' }, [ack, el('span', quote ? 'I understand: the client can no longer accept this quote' : 'I understand: this invoice will never be payable again')]),
      el('div', { class: 'oc-row' }, [go, el('button', { type: 'button', class: 'oc-btn oc-btn--ghost oc-btn--sm', onClick: () => Orch.mount(host, first) }, 'Keep it')]),
    ]));
  } }, quote ? 'Withdraw quote…' : 'Void invoice…');
  Orch.mount(host, first);
  return host;
}
