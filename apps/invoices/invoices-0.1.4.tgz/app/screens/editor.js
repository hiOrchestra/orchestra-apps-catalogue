// A draft: who it is for, its lines with the totals worked out as you type
// (invcore.totals, the same rule the instance and the client's page use),
// notes, and Issue. Issuing only asks: the instance gives the number, so two
// people can never take the same one. Preview shows the client's paper.
import { A, C, T, act, area, field, input, kindWord, select, sheet } from '../data.js';
import { paper } from '../paper.js';
import { clientDialog } from './clients.js';

const { el, router } = Orch;

export async function editor(d, s, client, again, waiting) {
  const cur0 = String(d.currency || s.currency || 'EUR').toUpperCase();
  const clients = (await Orch.db.list(T.clients, { filter: { archived: { ne: 'yes' } }, sort: 'name:asc', limit: 500 })).rows || [];
  const quote = d.kind === 'quote';
  const lock = !!waiting;
  // The lines as typed (strings), so "4.500,5" stays what was typed until it is read.
  let rows = C.linesOf(d.lines).map((l) => ({ description: l.description, qty: String(l.qty), price: l.price ? C.plain(l.price, cur0) : '', tax: String(l.tax), disc: l.disc ? String(l.disc) : '' }));
  if (!rows.length && !lock) rows = [{ description: '', qty: '1', price: '', tax: String(s.tax_rate ?? 21), disc: '' }];

  const who = select(d.client_id || '', [['', 'Choose a client'], ...clients.map((c) => [c._id, c.name]), ['new', '+ New client…'], ...(s.crm_available === 'yes' ? [['crm', '+ From CRM…']] : [])]);
  const title = input(d.title, { maxlength: '160', placeholder: quote ? 'Website redesign' : 'October retainer' });
  const currency = select(cur0, C.CURRENCIES.map((c) => [c, c]));
  const due = input(d.due_date, { type: 'date' });
  const withholding = input(d.withholding_rate ? String(d.withholding_rate) : '', { inputmode: 'decimal', placeholder: '0' });
  const notes = area(d.notes, 3, { maxlength: '1500', placeholder: quote ? 'What is included, what is not, timing.' : 'Anything the client should know.' });
  const linesHost = el('div', { class: 'iv-lines' });
  const totalsHost = el('dl', { class: 'iv-totals' });

  const values = () => {
    const cur = currency.value;
    // A line left empty (no description, no price) is not a line.
    const lines = rows.filter((r) => r.description.trim() || String(r.price).trim()).map((r) => ({ description: r.description.trim(), qty: C.qtyOf(r.qty), price: C.toMinor(r.price, cur) || 0, tax: C.pct(r.tax), disc: C.pct(r.disc) }));
    const t = C.totals({ lines, withholding_rate: withholding.value });
    return { id: d._id, client_id: Number(who.value) || '', title: title.value.trim(), currency: cur, due_date: C.realDay(due.value) || '', lines: JSON.stringify(lines),
      withholding_rate: t.withholdingRate, notes: notes.value.trim(), subtotal: t.subtotal, tax_total: t.taxTotal, withholding: t.withholding, total: t.total };
  };
  const draw = () => {
    const cur = currency.value;
    Orch.mount(linesHost, [
      el('div', { class: 'iv-line iv-line--head', 'aria-hidden': 'true' }, ['Description', 'Qty', `Price (${cur})`, 'Tax %', 'Disc. %', 'Amount', ''].map((x) => el('span', { class: 'oc-eyebrow' }, x))),
      ...rows.map((r, i) => line(r, i, cur)),
    ]);
    sums();
  };
  const sums = () => {
    const v = values();
    const t = C.totals({ lines: v.lines, withholding_rate: v.withholding_rate });
    const m = (n) => C.money(n, v.currency);
    Orch.mount(totalsHost, [
      el('div', [el('dt', 'Subtotal'), el('dd', m(t.subtotal))]),
      ...t.taxes.filter((g) => g.rate).map((g) => el('div', [el('dt', `Tax ${g.rate}%`), el('dd', m(g.tax))])),
      t.withholding ? el('div', [el('dt', `Withholding ${t.withholdingRate}%`), el('dd', `−${m(t.withholding)}`)]) : null,
      el('div', { class: 'iv-totals__total' }, [el('dt', 'Total'), el('dd', m(t.total))]),
    ]);
    for (const [i, node] of [...linesHost.querySelectorAll('[data-amount]')].entries()) {
      const r = rows[i];
      node.textContent = r ? m(C.totals({ lines: [{ qty: C.qtyOf(r.qty), price: C.toMinor(r.price, v.currency) || 0, disc: C.pct(r.disc), tax: 0 }] }).subtotal) : '';
    }
  };
  function line(r, i, cur) {
    const set = (k) => (e) => { r[k] = e.target.value; sums(); };
    const cell = (k, attrs) => el('input', Object.assign({ class: 'oc-input', value: r[k], disabled: lock, onInput: set(k), inputmode: 'decimal' }, attrs));
    return el('div', { class: 'iv-line' }, [
      el('textarea', { class: 'oc-textarea iv-line__desc', rows: '1', maxlength: '600', disabled: lock, placeholder: 'What you deliver', 'aria-label': `Line ${i + 1}: description`, onInput: set('description') }, r.description),
      cell('qty', { 'aria-label': `Line ${i + 1}: quantity` }),
      cell('price', { 'aria-label': `Line ${i + 1}: unit price in ${cur}`, placeholder: '0.00' }),
      cell('tax', { 'aria-label': `Line ${i + 1}: tax %` }),
      cell('disc', { 'aria-label': `Line ${i + 1}: discount %`, placeholder: '—' }),
      el('span', { class: 'oc-value iv-line__amount', 'data-amount': '' }),
      lock ? el('span') : el('button', { type: 'button', class: 'oc-btn oc-btn--ghost oc-btn--sm iv-line__x', 'aria-label': `Remove line ${i + 1}`, onClick: () => { rows.splice(i, 1); draw(); } }, '×'),
    ]);
  }
  currency.addEventListener('change', draw);
  withholding.addEventListener('input', sums);
  who.addEventListener('change', async () => {
    if (who.value !== 'new' && who.value !== 'crm') return;
    const mode = who.value;
    who.value = d.client_id || '';
    const made = await clientDialog(null, { crm: mode === 'crm' });
    if (made && await act(A.save, Object.assign(values(), { client_id: made }))) again();
  });
  draw();

  const save = el('button', { type: 'button', class: 'oc-btn', disabled: lock, onClick: async () => { if (await act(A.save, values(), 'Saved.')) again(); } }, 'Save draft');
  const issue = el('button', { type: 'button', class: 'oc-btn oc-btn--primary', disabled: lock, onClick: async () => {
    const v = values();
    const c = clients.find((x) => x._id === Number(v.client_id));
    const problems = C.issueProblems({ ...v, lines: v.lines }, c);
    if (problems.length) { Orch.toast(problems.join(' '), { error: true }); return; }
    if (!(await Orch.confirm(`Issue this ${kindWord(d.kind)} for ${C.money(v.total, v.currency)} to ${c.name}? It takes the next number and can no longer be edited${quote ? '' : ': only marked paid or voided'}. Nothing is sent yet: the email comes next, for you to read.`, { yes: `Issue ${kindWord(d.kind)}` }))) return;
    issue.disabled = true;
    if (await act(A.issue, v, 'Issuing: it gets its number in a moment.')) again();
    issue.disabled = false;
  } }, `Issue ${kindWord(d.kind)}`);
  const preview = el('button', { type: 'button', class: 'oc-btn oc-btn--ghost', onClick: () => {
    const v = values();
    const c = clients.find((x) => x._id === Number(v.client_id)) || {};
    sheet(el('div', { class: 'iv-sheetpaper' }, paper(C.snapshot({ ...d, ...v, status: 'Draft', number: '', client_snapshot: c, issue_date: '' }, s))), { title: 'What the client will see' });
  } }, 'Preview');
  const del = el('button', { type: 'button', class: 'oc-btn oc-btn--ghost iv-danger', disabled: lock, onClick: async () => {
    if (!(await Orch.confirm(`Delete this draft? It has no number yet, so nothing else changes.`, { yes: 'Delete draft', danger: true }))) return;
    if (await act(A.discard, { id: d._id }, 'Draft deleted.')) router.go(quote ? '/quotes' : '/invoices');
  } }, 'Delete draft');

  return el('div', { class: 'oc-stack oc-stack--loose' }, [
    notices(d, s, again),
    el('section', { class: 'oc-card oc-stack' }, [
      el('div', { class: 'iv-two' }, [field('Client', who), field('Reference', title, 'A few words the client recognises it by.')]),
      el('div', { class: 'iv-three' }, [field(quote ? 'Valid until' : 'Due', due, 'Set again on issue if it has passed.'), field('Currency', currency), field('Withholding %', withholding, 'A retention on the subtotal (IRPF in Spain). Empty if none.')]),
    ]),
    el('section', { class: 'oc-card oc-stack' }, [
      el('h2', { class: 'oc-h2' }, 'Lines'),
      linesHost,
      lock ? null : el('div', { class: 'oc-row' }, el('button', { type: 'button', class: 'oc-btn oc-btn--sm', onClick: () => { rows.push({ description: '', qty: '1', price: '', tax: String(s.tax_rate ?? 21), disc: '' }); draw(); } }, '+ Add line')),
      totalsHost,
    ]),
    el('section', { class: 'oc-card oc-stack' }, [field('Notes', notes, 'Printed under the lines.')]),
    el('div', { class: 'oc-row iv-actions' }, [issue, save, preview, el('span', { class: 'iv-grow' }), del]),
  ]);
}

/** What is happening to this draft: being numbered, being written by the agent, or why it was not issued. */
function notices(d, s, again) {
  if (d.issue_asked_at) return el('div', { class: 'iv-notice' }, 'Issuing: the instance is giving it its number and making the client\'s link. This takes a few seconds.');
  if (['Waiting', 'Working'].includes(d.ai_status)) return el('div', { class: 'iv-notice' }, [el('p', 'The agent is writing the lines from what you said:'), el('p', { class: 'iv-quote' }, `"${d.ai_prompt || ''}"`)]);
  const out = [];
  if (d.issue_note) out.push(el('div', { class: 'iv-notice iv-notice--bad' }, d.issue_note));
  if (d.ai_status === 'Failed') {
    const what = area(d.ai_prompt, 2, { maxlength: '2000' });
    out.push(el('div', { class: 'iv-notice iv-notice--bad oc-stack' }, [
      el('p', `The agent could not draft it: ${d.ai_note || 'no reason given'}. Say it again (or more precisely), or write the lines yourself below.`),
      what,
      el('div', { class: 'oc-row' }, el('button', { type: 'button', class: 'oc-btn oc-btn--sm', onClick: async () => { if (await act(A.draftAgain, { id: d._id, ai_prompt: String(what.value).trim() }, 'Asked again.')) again(); } }, 'Ask the agent again')),
    ]));
  }
  if (d.ai_status === 'Done' && d.ai_prompt) out.push(el('p', { class: 'oc-help' }, `Lines drafted by the agent from "${d.ai_prompt}". Check them before you issue.`));
  return out.length ? el('div', { class: 'oc-stack' }, out) : null;
}

