// Everything that is the same on every document: your company, how you get
// paid, numbering and defaults, the language your clients read, and who
// drafts quotes and reminders. One form, one Save. Saving rewrites the
// clients' pages of documents already sent (your new address or bank
// details show there), but never a document's number, lines or totals.
import { A, C, act, area, field, head, input, integrations, select, settings, when } from '../data.js';

const { el, fmt } = Orch;

export function render() {
  Orch.load('view', async () => {
    const s = await settings(true);
    if (!s._id) return el('p', { class: 'oc-state' }, 'Invoices is not installed in this project.');
    return el('div', { class: 'oc-stack oc-stack--loose' }, [head('Settings', 'What every quote and invoice carries, and how they get to your clients.'), form(s), fiscal()]);
  });
}

const ZONES = ['Europe/Madrid', 'Europe/London', 'Europe/Lisbon', 'Europe/Paris', 'Europe/Berlin', 'America/New_York', 'America/Chicago', 'America/Los_Angeles',
  'America/Mexico_City', 'America/Bogota', 'America/Lima', 'America/Santiago', 'America/Argentina/Buenos_Aires', 'America/Sao_Paulo', 'UTC'];

function form(s) {
  const year = new Date().getFullYear();
  const c = {
    company_name: input(s.company_name, { maxlength: '160' }), tax_id: input(s.tax_id, { maxlength: '40' }),
    address: area(s.address, 3, { maxlength: '400' }), country: input(s.country, { maxlength: '60' }),
    email: input(s.email, { type: 'email', maxlength: '160' }), phone: input(s.phone, { maxlength: '40' }),
    logo_url: input(s.logo_url, { type: 'url', maxlength: '400', placeholder: 'https://yourcompany.com/logo.png' }),
    bank_details: area(s.bank_details, 3, { maxlength: '600' }), payment_note: area(s.payment_note, 2, { maxlength: '400', placeholder: 'Please put the invoice number in the transfer.' }),
    stripe_on: select(s.stripe_on === 'yes' ? 'yes' : 'no', [['no', 'Off: bank transfer only'], ['yes', 'On: a Pay button on every new invoice']]),
    currency: select(s.currency || 'EUR', C.CURRENCIES.map((x) => [x, x])), tax_rate: input(s.tax_rate ?? 21, { inputmode: 'decimal' }),
    withholding_rate: input(s.withholding_rate || '', { inputmode: 'decimal', placeholder: '0' }),
    payment_days: input(s.payment_days ?? 30, { type: 'number', min: '0', max: '365' }), quote_valid_days: input(s.quote_valid_days ?? 30, { type: 'number', min: '1', max: '365' }),
    invoice_prefix: input(s.invoice_prefix ?? '', { maxlength: '12', placeholder: 'none' }), quote_prefix: input(s.quote_prefix ?? 'Q-', { maxlength: '12' }),
    language: select(s.language === 'es' ? 'es' : 'en', [['en', 'English'], ['es', 'Español']]),
    timezone: select(s.timezone || 'Europe/Madrid', [...new Set([s.timezone || 'Europe/Madrid', ...ZONES])].map((z) => [z, z])),
    agent: input(s.agent, { maxlength: '60', placeholder: 'Empty: no agent' }),
    reminders_on: select(s.reminders_on === 'no' ? 'no' : 'yes', [['yes', 'On: drafted for me to approve'], ['no', 'Off']]),
    reminder_days: input(s.reminder_days ?? 7, { type: 'number', min: '1', max: '60' }),
    notify_telegram: input(s.notify_telegram, { maxlength: '40', placeholder: '@channel or chat id' }),
  };
  const example = el('span', { class: 'oc-value' });
  const showExample = () => { example.textContent = `Next: ${C.numberOf(c.invoice_prefix.value, year, 1).replace(/0001$/, '…')} · ${C.numberOf(c.quote_prefix.value, year, 1).replace(/0001$/, '…')}`; };
  c.invoice_prefix.addEventListener('input', showExample);
  c.quote_prefix.addEventListener('input', showExample);
  showExample();
  const stripeSaid = s.stripe_on !== 'yes' ? null
    : s.stripe_status === 'ok' ? el('p', { class: 'oc-help' }, `Stripe answered ${s.stripe_checked_at ? fmt.ago(when(s.stripe_checked_at).toISOString()) : ''}.`)
      : s.stripe_note ? el('p', { class: 'iv-bad' }, [s.stripe_note, ' ', integrations('Orchestra → Integrations')]) : el('p', { class: 'oc-help' }, 'Not checked yet: it is the first time an invoice is issued.');
  const save = el('button', { type: 'submit', class: 'oc-btn oc-btn--primary' }, 'Save');
  const f = el('form', { class: 'oc-stack oc-stack--loose iv-form' }, [
    el('section', { class: 'oc-card oc-stack' }, [el('h2', { class: 'oc-h2' }, 'Your company'), el('p', { class: 'oc-help' }, 'At the top of every quote and invoice.'),
      field('Legal name', c.company_name), el('div', { class: 'iv-two' }, [field('Tax ID', c.tax_id), field('Country', c.country)]), field('Address', c.address),
      el('div', { class: 'iv-two' }, [field('Email', c.email), field('Phone', c.phone)]),
      field('Logo', c.logo_url, 'The address of an image of your logo (https). A wide one, about 3 to 1, prints best.')]),
    el('section', { class: 'oc-card oc-stack' }, [el('h2', { class: 'oc-h2' }, 'How you get paid'),
      field('Bank details', c.bank_details, 'Printed on every invoice, as written here.'), field('Payment note', c.payment_note, 'One line under them. Optional.'),
      field('Card payments with Stripe', c.stripe_on, 'The client pays on Stripe\'s own page, and the invoice is marked paid within the hour. Your Stripe account must be connected in Orchestra → Integrations. Card details never reach this workspace.'),
      stripeSaid]),
    el('section', { class: 'oc-card oc-stack' }, [el('h2', { class: 'oc-h2' }, 'Documents'),
      el('div', { class: 'iv-three' }, [field('Currency', c.currency), field('Tax %', c.tax_rate, 'For new lines.'), field('Withholding %', c.withholding_rate, 'IRPF in Spain. Empty if none.')]),
      el('div', { class: 'iv-two' }, [field('Days to pay', c.payment_days, 'An invoice is due this many days after it is issued.'), field('Days a quote is valid', c.quote_valid_days)]),
      el('div', { class: 'iv-two' }, [field('Invoice prefix', c.invoice_prefix), field('Quote prefix', c.quote_prefix)]), example,
      el('p', { class: 'oc-help' }, 'Numbers are given when a document is issued, one after another per year, with no gaps. A changed prefix applies to the next one.'),
      el('div', { class: 'iv-two' }, [field('Your clients read', c.language, 'The language of their page and of the emails.'), field('Time zone', c.timezone, 'Decides the date a document is issued on.')])]),
    el('section', { class: 'oc-card oc-stack' }, [el('h2', { class: 'oc-h2' }, 'Emails and the agent'),
      el('p', { class: 'oc-help' }, ['Emails go from the Gmail account connected in ', integrations('Orchestra → Integrations'), ', and only when you press Send or Approve.']),
      field('Agent', c.agent, 'Drafts quotes from a sentence, and payment reminders. It sends nothing.'),
      el('div', { class: 'iv-two' }, [field('Payment reminders', c.reminders_on, 'For overdue invoices, at most three, waiting for your OK.'), field('Days between reminders', c.reminder_days)]),
      field('Telegram', c.notify_telegram, 'Where you hear that a quote was answered or an invoice paid online. Optional.')]),
    el('div', { class: 'oc-row' }, save),
  ]);
  f.addEventListener('submit', async (e) => {
    e.preventDefault();
    const params = { id: s._id };
    for (const [k, node] of Object.entries(c)) params[k] = String(node.value).trim();
    for (const k of ['tax_rate', 'withholding_rate']) params[k] = C.pct(params[k]);
    for (const k of ['payment_days', 'quote_valid_days', 'reminder_days']) params[k] = Math.max(0, Math.round(Number(params[k]) || 0));
    if (params.logo_url && !/^https:\/\//.test(params.logo_url)) { Orch.toast('The logo must be an https:// address.', { error: true }); return; }
    if (params.email && !C.isEmail(params.email)) { Orch.toast('The email does not look right.', { error: true }); return; }
    save.disabled = true;
    if (await act(A.settings, params, 'Saved. Pages already sent show the new details in a moment.')) render();
    save.disabled = false;
  });
  return f;
}

const fiscal = () => el('section', { class: 'oc-card oc-stack iv-fiscal' }, [
  el('h2', { class: 'oc-h2' }, 'Not certified fiscal software'),
  el('p', 'Invoices numbers your documents without gaps and never changes one once issued, but it is not certified invoicing software: it does not send anything to a tax authority (no Verifactu, SII, TicketBAI or e-invoicing). If your country requires that, keep using certified software for it, or ask your accountant.'),
]);
