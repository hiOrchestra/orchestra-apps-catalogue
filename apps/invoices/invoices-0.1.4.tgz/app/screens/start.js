// Getting started: the two things a document cannot go out without, asked
// on the Overview in two thin rows, each checked from the data every time it
// draws (never ticked by hand). Gone once both are done; everything else
// has a sensible default in Settings. Gmail is not asked here: it is
// mentioned the first time you send an email.
import { A, act, area, field, input, integrations } from '../data.js';

const { el } = Orch;

export const companyDone = (s) => !!(String(s.company_name || '').trim() && String(s.tax_id || '').trim() && String(s.address || '').trim());
export const payDone = (s) => !!(String(s.bank_details || '').trim() || s.stripe_on === 'yes');

export function startCard(s, again) {
  const steps = [
    { id: 'company', title: 'Your company', done: companyDone(s), body: company },
    { id: 'pay', title: 'How you get paid', done: payDone(s), body: pay },
  ];
  if (steps.every((x) => x.done)) return null;
  const open = steps.find((x) => !x.done);
  return el('section', { class: 'oc-card oc-card--pad0 iv-start', 'aria-label': 'Getting started' }, [
    el('div', { class: 'iv-start__head' }, [el('h2', { class: 'oc-h2' }, 'Getting started'), el('span', { class: 'oc-value oc-muted' }, `${steps.filter((x) => x.done).length} of ${steps.length}`)]),
    el('p', { class: 'oc-help iv-start__lede' }, 'Two things every quote and invoice carries. The rest has a default you can change in Settings.'),
    el('ol', { class: 'iv-steps' }, steps.map((x, i) => el('li', { class: `iv-step${x.done ? ' iv-step--done' : ''}` }, [
      el('div', { class: 'iv-step__head' }, [el('span', { class: 'oc-value iv-step__n' }, String(i + 1).padStart(2, '0')), el('span', { class: 'iv-step__title' }, x.title),
        el('span', { class: `oc-badge${x.done ? ' oc-badge--good' : ''}` }, x.done ? 'Done' : 'To do')]),
      x === open ? el('div', { class: 'iv-step__body' }, x.body(s, again)) : null,
    ]))),
  ]);
}

function company(s, again) {
  const c = {
    company_name: input(s.company_name, { maxlength: '160', required: true, placeholder: 'Lumen Studio S.L.' }),
    tax_id: input(s.tax_id, { maxlength: '40', required: true, placeholder: 'B12345678' }),
    address: area(s.address, 3, { maxlength: '400', required: true, placeholder: 'Street and number\nPostcode and city' }),
    country: input(s.country, { maxlength: '60', placeholder: 'Spain' }),
    email: input(s.email, { type: 'email', maxlength: '160', placeholder: 'billing@yourcompany.com' }),
  };
  const save = el('button', { type: 'submit', class: 'oc-btn oc-btn--primary' }, 'Save and continue');
  const f = el('form', { class: 'oc-stack iv-start__form' }, [
    el('p', { class: 'iv-step__why' }, 'Your legal name, tax ID and address go at the top of every document: a client cannot book an invoice without them.'),
    field('Legal name', c.company_name),
    el('div', { class: 'iv-two' }, [field('Tax ID', c.tax_id, 'NIF, VAT number or EIN.'), field('Country', c.country)]),
    field('Address', c.address),
    field('Email on your documents', c.email, 'Where clients write back. Optional.'),
    el('div', { class: 'oc-row' }, save),
  ]);
  f.addEventListener('submit', async (e) => {
    e.preventDefault();
    const params = { id: s._id };
    for (const [k, node] of Object.entries(c)) params[k] = String(node.value).trim();
    save.disabled = true;
    if (await act(A.settings, params, 'Saved.')) again();
    save.disabled = false;
  });
  return f;
}

function pay(s, again) {
  const bank = area(s.bank_details, 3, { maxlength: '600', placeholder: 'IBAN ES12 3456 7890 1234 5678 9012\nBIC ABCDESMMXXX\nHolder: Lumen Studio S.L.' });
  const stripe = el('input', { type: 'checkbox', checked: s.stripe_on === 'yes' });
  const save = el('button', { type: 'submit', class: 'oc-btn oc-btn--primary' }, 'Save');
  const f = el('form', { class: 'oc-stack iv-start__form' }, [
    el('p', { class: 'iv-step__why' }, 'Your bank details are printed on every invoice, so the client knows where to transfer. You can also let clients pay by card with Stripe: they pay on Stripe\'s own page, and the invoice is marked paid by itself.'),
    field('Bank details', bank, 'As you want them printed: IBAN, BIC, the account holder.'),
    el('label', { class: 'iv-check' }, [stripe, el('span', 'Also take card payments with Stripe')]),
    el('p', { class: 'oc-help' }, ['Stripe needs your Stripe account connected in ', integrations('Orchestra → Integrations'), '. Card details never reach this workspace.']),
    el('div', { class: 'oc-row' }, save),
  ]);
  f.addEventListener('submit', async (e) => {
    e.preventDefault();
    const params = { id: s._id, bank_details: String(bank.value).trim(), stripe_on: stripe.checked ? 'yes' : 'no' };
    if (!params.bank_details && params.stripe_on !== 'yes') { Orch.toast('Add your bank details, or turn on Stripe.', { error: true }); return; }
    save.disabled = true;
    if (await act(A.settings, params, 'Saved. You are ready: create your first invoice.')) again();
    save.disabled = false;
  });
  return f;
}
