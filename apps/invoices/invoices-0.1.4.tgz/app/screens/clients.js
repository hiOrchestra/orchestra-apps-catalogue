// Clients: who you bill. A client's details are copied onto a document when
// it is issued, so editing a client later never changes what was sent. When
// the project has the CRM, "From CRM" fills a new client from a company there
// (read only: the CRM is not changed, and Invoices works without it).
import { A, C, T, V, act, area, day, field, head, input, money, newDoc, row, settings, sheet } from '../data.js';
import { docRow } from './overview.js';

const { el, router, fmt } = Orch;

export function render({ state = '' } = {}) {
  Orch.load('view', async () => {
    const s = await settings();
    const archived = state === 'archived';
    const [list, counts] = await Promise.all([
      Orch.db.view(V.clients, { filter: { archived: archived ? 'yes' : { ne: 'yes' } }, sort: 'name:asc', limit: 500 }),
      Orch.db.count(T.clients, { group: 'archived' }),
    ]);
    const nArch = ((counts.groups || []).find((g) => g.value === 'yes') || {}).count || 0;
    const nAll = (counts.groups || []).reduce((a, g) => a + g.count, 0);
    const tools = [
      s.crm_available === 'yes' ? el('button', { type: 'button', class: 'oc-btn', onClick: async () => { if (await clientDialog(null, { crm: true })) render({ state }); } }, 'From CRM') : null,
      el('button', { type: 'button', class: 'oc-btn oc-btn--primary', onClick: async () => { if (await clientDialog(null)) render({ state }); } }, 'New client'),
    ];
    const rows = list.rows || [];
    return el('div', { class: 'oc-stack oc-stack--loose' }, [
      head('Clients', 'Who you bill. Their details are copied onto each document when it is issued.', tools),
      nArch ? el('nav', { class: 'oc-tabs', 'aria-label': 'Which clients' }, [
        router.link('/clients', ['Active', el('span', { class: 'oc-count' }, fmt.number(nAll - nArch))], { class: 'oc-tab', 'aria-current': archived ? null : 'page' }),
        router.link('/clients/archived', ['Archived', el('span', { class: 'oc-count' }, fmt.number(nArch))], { class: 'oc-tab', 'aria-current': archived ? 'page' : null })]) : null,
      rows.length ? el('ul', { class: 'iv-rows' }, rows.map((c) => row({
        onClick: () => openClient(c._id, () => render({ state })),
        first: c.tax_id || '—',
        name: c.name,
        sub: [c.contact_name, c.email, c.country].filter(Boolean).join(' · ') || 'No email yet',
        right: [c.outstanding ? el('span', { class: 'oc-value' }, `${money(c.outstanding, c.outstanding_currency)} owed`) : null,
          el('span', { class: 'oc-value oc-muted' }, `${c.invoices || 0} invoice${Number(c.invoices) === 1 ? '' : 's'}`)],
      }))) : el('div', { class: 'oc-card oc-state' }, el('p', { class: 'oc-help' }, archived ? 'No archived clients.' : 'No clients yet. Add one here, or from a new invoice.')),
    ]);
  });
}

async function openClient(id, after) {
  const c = await Orch.db.get(T.clients, id);
  if (!c) return;
  const docs = (await Orch.db.view(V.docs, { filter: { client_id: id }, sort: '_id:desc', limit: 50 })).rows || [];
  const box = el('div', { class: 'oc-stack' });
  const d = sheet(box, { title: c.name, drawer: true });
  const done = () => { d.close(); after(); };
  Orch.mount(box, [
    el('div', { class: 'oc-row' }, [
      el('button', { type: 'button', class: 'oc-btn oc-btn--primary oc-btn--sm', onClick: () => newDoc('invoice', { client_id: id }) }, 'New invoice'),
      el('button', { type: 'button', class: 'oc-btn oc-btn--sm', onClick: () => newDoc('quote', { client_id: id }) }, 'New quote'),
    ]),
    docs.length ? el('ul', { class: 'iv-rows iv-rows--tight' }, docs.map(docRow)) : el('p', { class: 'oc-help' }, 'Nothing issued to them yet.'),
    el('h3', { class: 'oc-h3' }, 'Details'),
    form(c, async (v) => { if (await act(A.updateClient, Object.assign({ id }, v), 'Saved. Documents already issued keep the details they were sent with.')) done(); }),
    el('div', { class: 'oc-row' }, el('button', { type: 'button', class: 'oc-btn oc-btn--ghost oc-btn--sm', onClick: async () => {
      if (await act(c.archived === 'yes' ? A.restoreClient : A.archiveClient, { id }, c.archived === 'yes' ? 'Back among your clients.' : 'Archived: hidden from the lists, their documents stay.')) done();
    } }, c.archived === 'yes' ? 'Restore' : 'Archive')),
    c.crm_company_id ? el('p', { class: 'oc-help' }, `Came from the CRM ${day(String(c._created_at || '').slice(0, 10))}.`) : null,
  ]);
}

function form(c, onSave, extra) {
  const f = {
    name: input(c.name, { maxlength: '160', required: true }), tax_id: input(c.tax_id, { maxlength: '40' }),
    email: input(c.email, { type: 'email', maxlength: '200' }), contact_name: input(c.contact_name, { maxlength: '120', placeholder: 'Who reads your emails there' }),
    address: area(c.address, 3, { maxlength: '400' }), country: input(c.country, { maxlength: '60' }),
  };
  const save = el('button', { type: 'submit', class: 'oc-btn oc-btn--primary' }, c._id ? 'Save' : 'Add client');
  const node = el('form', { class: 'oc-stack' }, [
    ...(extra || []),
    field('Name', f.name, 'The legal name, as it goes on the invoice.'),
    el('div', { class: 'iv-two' }, [field('Tax ID', f.tax_id), field('Country', f.country)]),
    el('div', { class: 'iv-two' }, [field('Email', f.email, 'Where their quotes and invoices are sent.'), field('Contact person', f.contact_name)]),
    field('Address', f.address),
    el('div', { class: 'oc-row' }, save),
  ]);
  node.fill = (v) => { for (const [k, x] of Object.entries(v)) if (f[k] && x) f[k].value = x; };
  node.addEventListener('submit', async (e) => {
    e.preventDefault();
    const v = Object.fromEntries(Object.entries(f).map(([k, x]) => [k, String(x.value).trim()]));
    if (!v.name) { Orch.toast('It needs a name.', { error: true }); return; }
    if (v.email && !C.isEmail(v.email)) { Orch.toast('The email does not look right.', { error: true }); return; }
    v.email = C.normEmail(v.email);
    save.disabled = true;
    await onSave(Object.assign(v, node.crm ? { crm_company_id: node.crm } : {}));
    save.disabled = false;
  });
  return node;
}

/** A new client (optionally from the CRM). Resolves with its id, or null if closed. */
export function clientDialog(_, { crm } = {}) {
  return new Promise((resolve) => {
    let made = null;
    const box = el('div', { class: 'oc-stack' });
    const d = sheet(box, { title: crm ? 'A client from the CRM' : 'New client' });
    const f = form({}, async (v) => {
      const r = await act(A.createClient, v, `${v.name} added.`);
      if (r && r._id) { made = r._id; d.close(); }
    }, crm ? [crmPicker((pick) => { f.fill(pick); f.crm = pick.crm_company_id; })] : null);
    Orch.mount(box, f);
    (d.el || box.closest('dialog') || box).addEventListener('close', () => resolve(made), { once: true });
  });
}

/** Search the CRM's companies; picking one fills the form (name, email of its first contact with one, country). */
function crmPicker(onPick) {
  const q = input('', { type: 'search', placeholder: 'Type a company name' });
  const out = el('ul', { class: 'iv-rows iv-rows--tight' });
  let t = null;
  q.addEventListener('input', () => {
    clearTimeout(t);
    t = setTimeout(async () => {
      const text = q.value.trim();
      if (text.length < 2) { Orch.mount(out, []); return; }
      let rows = [];
      try { rows = (await Orch.db.list(T.crmCompanies, { filter: { name: { like: text } }, sort: 'name:asc', limit: 8 })).rows || []; } catch { Orch.mount(out, el('li', { class: 'oc-help' }, 'The CRM could not be read.')); return; }
      Orch.mount(out, rows.length ? rows.map((c) => row({ onClick: async () => {
        const people = ((await Orch.db.list(T.crmContacts, { filter: { company_id: c._id }, limit: 20 }).catch(() => ({ rows: [] }))).rows || []).filter((p) => C.isEmail(p.email));
        onPick({ name: c.name, email: people[0] ? people[0].email : '', contact_name: people[0] ? people[0].name : '', country: c.location || '', crm_company_id: c._id });
        Orch.mount(out, []);
        q.value = c.name;
      }, first: c.domain || '', name: c.name, sub: c.location || c.industry || '' })) : el('li', { class: 'oc-help' }, 'No company by that name in the CRM.'));
    }, 250);
  });
  return el('div', { class: 'oc-stack oc-stack--tight' }, [field('Find it in the CRM', q, 'Picking one fills the details below; check the legal name and tax ID before saving.'), out]);
}
