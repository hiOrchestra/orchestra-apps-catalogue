// One email in its own panel, with every way out of its state:
//   Review    (a reminder the agent wrote) edit it, approve it, or drop it
//   Approved  going out within a minute
//   Failed    what happened in plain words, the raw error under it, and
//             send again / edit / it did go out / drop, right there
// Nothing leaves without a person's click.
import { A, C, T, act, area, day, field, input, integrations, sheet } from '../data.js';

const { el, router } = Orch;

export async function openEmail(id, after) {
  const m = await Orch.db.get(T.emails, id);
  if (!m) { Orch.toast('That email is gone.', { error: true }); return; }
  const doc = m.doc_id ? await Orch.db.get(T.docs, m.doc_id) : null;
  const box = el('div', { class: 'oc-stack' });
  const d = sheet(box, { title: m.subject || 'Email', drawer: true });
  const done = () => { d.close(); if (after) after(); };
  const about = el('p', { class: 'oc-small oc-muted' }, [
    m.purpose === 'reminder' ? `Payment reminder ${m.n || ''}` : 'Email',
    doc ? [' for ', router.link(`/doc/${doc._id}`, doc.number || 'a draft')] : '',
    m.drafted_by === 'agent' ? ', written by the agent' : m.drafted_by === 'template' ? ', from the template' : '',
  ]);
  if (m.status === 'Review') return Orch.mount(box, review(m, about, done));
  if (m.status === 'Failed') return Orch.mount(box, failed(m, about, done));
  const say = { Approved: 'Approved: it goes out from your Gmail within a minute.', Sending: 'Going out now.', Sent: `Sent ${day(String(m.sent_at || '').slice(0, 10))} from your Gmail.`, Dropped: 'Dropped: it was never sent.' }[m.status] || '';
  return Orch.mount(box, [about, el('p', { class: 'oc-help' }, say), el('p', { class: 'oc-eyebrow' }, `To ${m.to_email}`), el('p', m.subject || ''), el('pre', { class: 'iv-mail' }, m.body || '')]);
}

function editors(m) {
  const to = input(m.to_email, { type: 'email', required: true });
  const subject = input(m.subject, { required: true, maxlength: '160' });
  const body = area(m.body, 12, { required: true, maxlength: '5000' });
  const values = () => ({ id: m._id, to_email: C.normEmail(to.value), subject: subject.value.trim(), body: body.value.replace(/\r\n/g, '\n').trim() });
  const valid = (v) => {
    if (!C.isEmail(v.to_email)) { Orch.toast('The address does not look right.', { error: true }); return false; }
    if (!v.subject || !v.body) { Orch.toast('It needs a subject and a message.', { error: true }); return false; }
    return true;
  };
  return { fields: [field('To', to), field('Subject', subject), field('Message', body, 'Plain text. The link to the invoice is at the end: keep it.')], values, valid };
}

function review(m, about, done) {
  const e = editors(m);
  const approve = el('button', { class: 'oc-btn oc-btn--primary', type: 'button' }, 'Approve and send');
  approve.addEventListener('click', async () => {
    const v = e.values();
    if (!e.valid(v)) return;
    approve.disabled = true;
    if (await act(A.approve, v)) { await act(A.sendNow, {}, 'Approved: it goes out within a minute.'); done(); }
    approve.disabled = false;
  });
  const save = el('button', { class: 'oc-btn', type: 'button', onClick: async () => { const v = e.values(); if (e.valid(v) && await act(A.saveEmail, v, 'Saved. It still waits for your OK.')) done(); } }, 'Save changes');
  const drop = el('button', { class: 'oc-btn oc-btn--ghost', type: 'button', onClick: async () => { if (await act(A.dropEmail, { id: m._id }, 'Dropped: it will not be sent.')) done(); } }, 'Drop');
  return [about, el('p', { class: 'oc-help' }, ['It goes from the Gmail account connected in ', integrations('Orchestra → Integrations'), '.']), ...e.fields, el('div', { class: 'oc-row' }, [approve, save, drop])];
}

function failed(m, about, done) {
  const maybe = /may or may not/i.test(m.error || '');
  const e = editors(m);
  const retry = el('button', { class: 'oc-btn oc-btn--primary', type: 'button' }, 'Send again');
  retry.addEventListener('click', async () => {
    if (maybe && !(await Orch.confirm('It may have gone out already. Did you check Gmail\'s Sent folder, and it is not there?', { yes: 'Not there: send again' }))) return;
    const v = e.values();
    if (!e.valid(v)) return;
    if (await act(A.retryEmail, v)) { await act(A.sendNow, {}, 'Sending again.'); done(); }
  });
  const sent = el('button', { class: 'oc-btn oc-btn--ghost', type: 'button', onClick: async () => { if (await act(A.wasSent, { id: m._id }, 'Marked as sent.')) done(); } }, 'It did go out');
  const drop = el('button', { class: 'oc-btn oc-btn--ghost', type: 'button', onClick: async () => { if (await act(A.dropFailed, { id: m._id }, 'Dropped.')) done(); } }, 'Drop');
  const said = String(m.error || 'It did not go out.');
  const plain = said.replace(/\s*\(.*\)\s*$/s, '');
  const raw = said.length > plain.length ? said.slice(plain.length).trim().replace(/^\(|\)$/g, '') : '';
  const notConnected = /not connected/i.test(said);
  return [about,
    el('div', { class: 'iv-notice iv-notice--bad' }, [el('p', plain), notConnected ? el('p', [integrations('Connect Gmail in Orchestra → Integrations'), ', then send again.']) : null, raw ? el('p', { class: 'oc-value oc-muted' }, raw) : null]),
    ...e.fields, el('div', { class: 'oc-row' }, [retry, sent, drop])];
}
