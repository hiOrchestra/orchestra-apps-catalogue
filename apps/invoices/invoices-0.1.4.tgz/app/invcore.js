/**
 * The rules of Invoices that the desk, the scripts and the client's page must
 * agree on, in one file: money in whole minor units, the rounding rule, the
 * totals, numbering, what a document needs before it is issued, the snapshot
 * the client sees, the sealed link, and the emails' words.
 * Pure functions, no database, no DOM. test/sync.js copies this file to app/,
 * public/ and automations/, and a test fails if a copy is stale.
 *
 * THE ROUNDING RULE (docs/apps/invoices.md): per line, then the sum.
 *   line net  = round(qty × unit price × (1 − discount %))
 *   line tax  = round(line net × tax %)
 *   subtotal  = Σ line nets;  tax per rate = Σ its lines' taxes
 *   withholding = round(subtotal × withholding %)
 *   total     = subtotal + taxes − withholding
 * round() is to the currency's minor unit, half away from zero.
 */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.InvCore = api;
}(typeof self !== 'undefined' ? self : this, () => {
  'use strict';

  const CURRENCIES = ['EUR', 'USD', 'GBP', 'CHF', 'MXN', 'COP', 'ARS', 'CLP', 'PEN', 'BRL', 'CAD', 'AUD', 'SEK', 'NOK', 'DKK', 'PLN', 'JPY', 'KWD'];
  const MAX_LINES = 60;

  /** How many decimals a currency's minor unit has: EUR 2, JPY 0, KWD 3. */
  function decimals(currency) {
    try { return new Intl.NumberFormat('en', { style: 'currency', currency: String(currency || 'EUR').toUpperCase() }).resolvedOptions().maximumFractionDigits; } catch { return 2; }
  }
  const scale = (currency) => 10 ** decimals(currency);

  /** Half away from zero, to a whole number; the tiny nudge undoes float noise (1.005 × 100 = 100.49999…). */
  function round(x) {
    const n = Number(x);
    if (!Number.isFinite(n)) return 0;
    const a = Math.floor(Math.abs(n) + 0.5 + 1e-9);
    return n < 0 ? -a : a;
  }

  /**
   * A typed amount as a number: "4.500", "4,500.50", "4.500,50", "1234,5", " 12 ". Null when it is not one.
   * With both marks the last is the decimal one; a lone comma followed by 1–3 digits is decimal, otherwise grouping.
   */
  function parseAmount(text) {
    if (typeof text === 'number') return Number.isFinite(text) ? text : null;
    let s = String(text == null ? '' : text).replace(/[\s '€$£¥]/g, '').trim();
    if (!s) return null;
    const neg = /^-/.test(s);
    s = s.replace(/^[-+]/, '');
    const dot = s.lastIndexOf('.');
    const comma = s.lastIndexOf(',');
    if (dot >= 0 && comma >= 0) {
      const dec = dot > comma ? '.' : ',';
      s = s.split(dec === '.' ? ',' : '.').join('').replace(dec, '.');
    } else if (comma >= 0) {
      s = /^\d{1,3}(,\d{3})+$/.test(s) && !/,\d{1,2}$/.test(s) ? s.replace(/,/g, '') : s.replace(',', '.');
    } else if (dot >= 0 && /^\d{1,3}(\.\d{3})+$/.test(s) && (s.match(/\./g) || []).length > 1) {
      s = s.replace(/\./g, '');
    }
    if (!/^\d+(\.\d+)?$/.test(s)) return null;
    const n = Number(s);
    return neg ? -n : n;
  }

  /** A typed amount in the currency's minor units (an integer), or null. */
  function toMinor(text, currency) {
    const n = parseAmount(text);
    return n === null ? null : round(n * scale(currency));
  }
  const fromMinor = (n, currency) => Number(n || 0) / scale(currency);

  /** "4.500,00 €" (es) / "€4,500.00" (en): how a person reads an amount. */
  function money(n, currency, locale) {
    const cur = String(currency || 'EUR').toUpperCase();
    try { return new Intl.NumberFormat(locale || undefined, { style: 'currency', currency: cur }).format(fromMinor(n, cur)); } catch { return `${fromMinor(n, cur).toFixed(decimals(cur))} ${cur}`; }
  }
  /** An amount for an input: "4500.5" → "4500.50" in the currency's decimals, a plain dot. */
  const plain = (n, currency) => fromMinor(n, currency).toFixed(decimals(currency));

  const pct = (v) => { const n = parseAmount(v); return n === null ? 0 : Math.max(0, Math.min(100, Math.round(n * 100) / 100)); };
  const qtyOf = (v) => { const n = parseAmount(v); return n === null ? 0 : Math.round(n * 1000) / 1000; };

  /** One line, cleaned: { description, qty, price (minor units), tax (%), disc (%) }. */
  function lineOf(raw) {
    const r = raw && typeof raw === 'object' ? raw : {};
    return {
      description: String(r.description == null ? '' : r.description).replace(/\r\n/g, '\n').slice(0, 600),
      qty: qtyOf(r.qty),
      price: Number.isFinite(Number(r.price)) ? Math.trunc(Number(r.price)) : 0,
      tax: pct(r.tax),
      disc: pct(r.disc),
    };
  }
  function linesOf(text) {
    let v = text;
    if (typeof v === 'string') { try { v = JSON.parse(v || '[]'); } catch { v = []; } }
    return (Array.isArray(v) ? v : []).slice(0, MAX_LINES).map(lineOf);
  }

  /** Every total of a document, by THE ROUNDING RULE. */
  function totals(doc) {
    const lines = linesOf(doc && doc.lines).map((l) => {
      const net = round(l.qty * l.price * (100 - l.disc) / 100);
      return Object.assign({}, l, { net, taxAmount: round(net * l.tax / 100) });
    });
    const byRate = new Map();
    for (const l of lines) {
      const g = byRate.get(l.tax) || { rate: l.tax, base: 0, tax: 0 };
      g.base += l.net;
      g.tax += l.taxAmount;
      byRate.set(l.tax, g);
    }
    const subtotal = lines.reduce((s, l) => s + l.net, 0);
    const taxes = [...byRate.values()].sort((a, b) => b.rate - a.rate);
    const taxTotal = taxes.reduce((s, g) => s + g.tax, 0);
    const withholdingRate = pct(doc && doc.withholding_rate);
    const withholding = round(subtotal * withholdingRate / 100);
    return { lines, subtotal, taxes, taxTotal, withholdingRate, withholding, total: subtotal + taxTotal - withholding };
  }

  // ── numbering ──────────────────────────────────────────────────────────
  const KINDS = ['quote', 'invoice'];
  /** "Q-2026-0007" (prefix "Q-"), "2026-0007" (no prefix): the n-th of its series that year. */
  function numberOf(prefix, year, n) {
    return `${String(prefix || '').trim()}${year}-${String(n).padStart(4, '0')}`;
  }
  const prefixOf = (kind, s) => (kind === 'quote' ? (s && s.quote_prefix != null ? s.quote_prefix : 'Q-') : (s && s.invoice_prefix != null ? s.invoice_prefix : ''));

  // ── days ───────────────────────────────────────────────────────────────
  const DAY = /^\d{4}-\d{2}-\d{2}$/;
  /** A real calendar day 'YYYY-MM-DD' (2026-02-30 is not one), or ''. */
  function realDay(v) {
    const s = String(v || '').slice(0, 10);
    if (!DAY.test(s)) return '';
    const d = new Date(`${s}T00:00:00Z`);
    return !Number.isNaN(d.getTime()) && d.toISOString().slice(0, 10) === s ? s : '';
  }
  function addDays(day, n) {
    const d = new Date(`${realDay(day) || '1970-01-01'}T00:00:00Z`);
    d.setUTCDate(d.getUTCDate() + Number(n || 0));
    return d.toISOString().slice(0, 10);
  }
  /** Today where the company is (Settings' time zone). */
  function today(tz, now) {
    const at = now ? new Date(now) : new Date();
    try { return new Intl.DateTimeFormat('en-CA', { timeZone: tz || 'UTC', year: 'numeric', month: '2-digit', day: '2-digit' }).format(at); } catch { return at.toISOString().slice(0, 10); }
  }
  /** Minutes east of UTC that the time zone is at a moment (ms). */
  function offsetAt(tz, ms) {
    const p = {};
    for (const x of new Intl.DateTimeFormat('en-US', { timeZone: tz, hourCycle: 'h23', year: 'numeric', month: '2-digit', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit' }).formatToParts(new Date(ms))) p[x.type] = x.value;
    const local = Date.UTC(Number(p.year), Number(p.month) - 1, Number(p.day), Number(p.hour) % 24, Number(p.minute), Number(p.second));
    return Math.round((local - Math.floor(ms / 1000) * 1000) / 60000);
  }
  /**
   * What the SQL views need to count days where the company is (a view
   * cannot read a time zone): the offset now, the moment it next changes
   * (daylight saving) and the offset after it. The views use the second
   * offset from that moment on, and the docs workflow runs again after it to
   * look one change further. No change within a year (UTC, most of Asia):
   * change_at '9999-12-31 00:00:00'. Stored on inv_settings as tz_offset,
   * tz_change_at and tz_next_offset.
   */
  function tzWindow(tz, now) {
    const t0 = now ? new Date(now).getTime() : Date.now();
    let zone = tz || 'UTC';
    try { offsetAt(zone, t0); } catch { zone = 'UTC'; }
    const offset = offsetAt(zone, t0);
    let lo = t0;
    let hi = null;
    for (let t = t0 + 86400000; t <= t0 + 400 * 86400000; t += 86400000) {
      if (offsetAt(zone, t) !== offset) { hi = t; break; }
      lo = t;
    }
    if (hi === null) return { tz_offset: offset, tz_change_at: '9999-12-31 00:00:00', tz_next_offset: offset };
    while (hi - lo > 1000) {
      const mid = lo + Math.floor((hi - lo) / 2);
      if (offsetAt(zone, mid) === offset) lo = mid; else hi = mid;
    }
    const at = new Date(Math.floor(hi / 1000) * 1000).toISOString().slice(0, 19).replace('T', ' ');
    return { tz_offset: offset, tz_change_at: at, tz_next_offset: offsetAt(zone, hi) };
  }
  const daysBetween = (a, b) => Math.round((Date.parse(`${b}T00:00:00Z`) - Date.parse(`${a}T00:00:00Z`)) / 86400000);

  const isEmail = (v) => /^[^\s@<>()"',;]+@[^\s@<>()"',;]+\.[a-z]{2,}$/i.test(String(v || '').trim());
  const normEmail = (v) => String(v || '').trim().toLowerCase();

  /** What stops a document from being issued, in words; empty when it can be. */
  function issueProblems(doc, client) {
    const out = [];
    if (!client || !String(client.name || '').trim()) out.push('It has no client.');
    const t = totals(doc);
    if (!t.lines.length) out.push('It has no lines.');
    if (t.lines.some((l) => !l.description.trim())) out.push('A line has no description.');
    if (t.lines.some((l) => l.qty === 0)) out.push('A line has a quantity of zero.');
    if (t.total <= 0) out.push('Its total is not above zero.');
    if (!CURRENCIES.includes(String(doc && doc.currency || '').toUpperCase())) out.push('Its currency is not one Invoices knows.');
    if (doc && doc.due_date && !realDay(doc.due_date)) out.push('Its due date is not a real day.');
    return out;
  }

  /** The derived state a person sees: Overdue and Expired are not stored. */
  function stateOf(doc, day) {
    const st = doc && doc.status;
    if (st === 'Issued' && doc.due_date && doc.due_date < day) return 'Overdue';
    if (st === 'Sent' && doc.due_date && doc.due_date < day) return 'Expired';
    return st || 'Draft';
  }

  // ── what the client sees ───────────────────────────────────────────────
  const pick = (o, keys) => Object.fromEntries(keys.map((k) => [k, String((o && o[k]) || '')]));
  /**
   * The document as the client's page draws it: nothing it does not need. Built
   * by the script that writes the sealed link, and by the desk for its preview,
   * so the two are the same paper.
   */
  function snapshot(doc, s, extra) {
    const t = totals(doc);
    let client = doc.client_snapshot;
    if (typeof client === 'string') { try { client = JSON.parse(client); } catch { client = {}; } }
    return {
      v: 1,
      lang: s && s.language === 'es' ? 'es' : 'en',
      kind: doc.kind,
      status: doc.status,
      number: doc.number || '',
      title: String(doc.title || ''),
      issue_date: doc.issue_date || '',
      due_date: doc.due_date || '',
      currency: String(doc.currency || 'EUR').toUpperCase(),
      company: pick(s, ['company_name', 'tax_id', 'address', 'country', 'email', 'phone', 'logo_url']),
      client: pick(client || {}, ['name', 'tax_id', 'email', 'address', 'country']),
      lines: t.lines.map((l) => ({ d: l.description, q: l.qty, p: l.price, t: l.tax, x: l.disc, n: l.net })),
      totals: { subtotal: t.subtotal, taxes: t.taxes, withholding_rate: t.withholdingRate, withholding: t.withholding, total: t.total },
      notes: String(doc.notes || ''),
      pay: doc.kind === 'invoice' ? { bank: String((s && s.bank_details) || ''), note: String((s && s.payment_note) || ''), url: doc.stripe_link_url && doc.stripe_link_active === 'yes' ? doc.stripe_link_url : '' } : null,
      paid_at: doc.paid_at || '',
      accepted: doc.accepted_at ? { name: doc.accepted_name || '', at: doc.accepted_at } : null,
      declined_at: doc.declined_at || '',
      void_at: doc.void_at || '',
      ...(extra || {}),
    };
  }

  // ── the sealed link ────────────────────────────────────────────────────
  // The public view cannot be made to require a filter, so what it holds must
  // mean nothing without the link: k = SHA-256("inv-k:"+token) finds the row,
  // and the row is AES-GCM sealed with SHA-256("inv-e:"+token). WebCrypto, so
  // the same code runs in Node (the scripts, the tests) and in the browser.
  const subtle = () => (globalThis.crypto && globalThis.crypto.subtle) || null;
  const enc = (s) => new TextEncoder().encode(s);
  const b64u = (bytes) => btoa(String.fromCharCode(...new Uint8Array(bytes))).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, '');
  const unb64u = (s) => Uint8Array.from(atob(String(s).replace(/-/g, '+').replace(/_/g, '/') + '==='.slice((String(s).length + 3) % 4)), (c) => c.charCodeAt(0));
  const hex = (bytes) => [...new Uint8Array(bytes)].map((b) => b.toString(16).padStart(2, '0')).join('');
  const TOKEN = /^[A-Za-z0-9_-]{22,64}$/;

  /** A new link token: 128 random bits, base64url (22 characters). */
  function newToken() { const b = new Uint8Array(16); globalThis.crypto.getRandomValues(b); return b64u(b); }
  async function linkKey(token) { return hex(await subtle().digest('SHA-256', enc(`inv-k:${token}`))); }
  async function boxKey(token, use) {
    const raw = await subtle().digest('SHA-256', enc(`inv-e:${token}`));
    return subtle().importKey('raw', raw, { name: 'AES-GCM' }, false, [use]);
  }
  /** The snapshot sealed for its token: base64url(iv ‖ ciphertext+tag). */
  async function seal(token, obj) {
    const iv = new Uint8Array(12);
    globalThis.crypto.getRandomValues(iv);
    const ct = await subtle().encrypt({ name: 'AES-GCM', iv }, await boxKey(token, 'encrypt'), enc(JSON.stringify(obj)));
    const out = new Uint8Array(12 + ct.byteLength);
    out.set(iv, 0);
    out.set(new Uint8Array(ct), 12);
    return b64u(out);
  }
  /** The snapshot back from its box, or null when the token does not open it. */
  async function open(token, box) {
    try {
      const all = unb64u(box);
      const pt = await subtle().decrypt({ name: 'AES-GCM', iv: all.slice(0, 12) }, await boxKey(token, 'decrypt'), all.slice(12));
      return JSON.parse(new TextDecoder().decode(pt));
    } catch { return null; }
  }

  // ── the emails' words (the client's language, Settings) ────────────────
  const WORDS = {
    en: {
      invoice: 'invoice', quote: 'quote',
      sendSubject: (d) => `${d.kind === 'quote' ? 'Quote' : 'Invoice'} ${d.number} from ${d.company}`,
      sendBody: (d) => [`Hello${d.contact ? ` ${d.contact}` : ''},`, '',
        d.kind === 'quote'
          ? `Here is our quote ${d.number}${d.title ? ` for ${d.title}` : ''}, for ${d.total}. It is valid until ${d.due}. You can read it, accept it or decline it here:`
          : `Here is invoice ${d.number}${d.title ? ` for ${d.title}` : ''}, for ${d.total}, due on ${d.due}. You can read it, save it as a PDF and pay it here:`,
        d.link, '', 'Thank you,', d.company].join('\n'),
      remindSubject: (d) => `Reminder: invoice ${d.number} is overdue`,
      remindBody: (d) => [`Hello${d.contact ? ` ${d.contact}` : ''},`, '',
        `Invoice ${d.number} for ${d.total} was due on ${d.due} and we have not received the payment yet. If it is already on its way, please ignore this message.`,
        '', 'Thank you,', d.company].join('\n'),
      view: 'Read and pay it here',
    },
    es: {
      invoice: 'factura', quote: 'presupuesto',
      sendSubject: (d) => `${d.kind === 'quote' ? 'Presupuesto' : 'Factura'} ${d.number} de ${d.company}`,
      sendBody: (d) => [`Hola${d.contact ? ` ${d.contact}` : ''}:`, '',
        d.kind === 'quote'
          ? `Te enviamos nuestro presupuesto ${d.number}${d.title ? ` para ${d.title}` : ''}, por ${d.total}. Es válido hasta el ${d.due}. Puedes verlo, aceptarlo o rechazarlo aquí:`
          : `Te enviamos la factura ${d.number}${d.title ? ` por ${d.title}` : ''}, de ${d.total}, con vencimiento el ${d.due}. Puedes verla, guardarla en PDF y pagarla aquí:`,
        d.link, '', 'Gracias,', d.company].join('\n'),
      remindSubject: (d) => `Recordatorio: la factura ${d.number} está vencida`,
      remindBody: (d) => [`Hola${d.contact ? ` ${d.contact}` : ''}:`, '',
        `La factura ${d.number} de ${d.total} vencía el ${d.due} y todavía no hemos recibido el pago. Si ya está en camino, ignora este mensaje.`,
        '', 'Gracias,', d.company].join('\n'),
      view: 'Puedes verla y pagarla aquí',
    },
  };
  const localeOf = (lang) => (lang === 'es' ? 'es-ES' : 'en-GB');
  function longDay(day, lang) {
    const d = realDay(day);
    if (!d) return '';
    return new Intl.DateTimeFormat(localeOf(lang), { day: 'numeric', month: 'long', year: 'numeric', timeZone: 'UTC' }).format(new Date(`${d}T00:00:00Z`));
  }
  /** What the words need from a document: number, total, due day, the link, who. */
  function mailFacts(doc, s, link) {
    const lang = s && s.language === 'es' ? 'es' : 'en';
    let client = doc.client_snapshot;
    if (typeof client === 'string') { try { client = JSON.parse(client); } catch { client = {}; } }
    return {
      lang, kind: doc.kind, number: doc.number || '', title: String(doc.title || '').trim(),
      total: money(Number.isFinite(Number(doc.total)) && doc.total !== null && doc.total !== '' ? Number(doc.total) : totals(doc).total, doc.currency, localeOf(lang)),
      due: longDay(doc.due_date, lang), link: link || '', company: String((s && s.company_name) || '').trim(),
      contact: '', client: String((client && client.name) || ''),
    };
  }
  /** The email that carries a document to its client. */
  function sendEmail(doc, s, link) {
    const f = mailFacts(doc, s, link);
    const w = WORDS[f.lang];
    return { subject: w.sendSubject(f), body: w.sendBody(f) };
  }
  /** A payment reminder in plain words, when no agent wrote one. */
  function reminderEmail(doc, s, link) {
    const f = mailFacts(doc, s, link);
    const w = WORDS[f.lang];
    return { subject: w.remindSubject(f), body: `${w.remindBody(f)}\n\n${w.view}: ${link}` };
  }

  return {
    CURRENCIES, KINDS, MAX_LINES, TOKEN, WORDS,
    decimals, round, parseAmount, toMinor, fromMinor, money, plain, pct, qtyOf, lineOf, linesOf, totals,
    numberOf, prefixOf, realDay, addDays, today, tzWindow, daysBetween, isEmail, normEmail, issueProblems, stateOf,
    snapshot, newToken, linkKey, seal, open, b64u, localeOf, longDay, mailFacts, sendEmail, reminderEmail,
  };
}));
