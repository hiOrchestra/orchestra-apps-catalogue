// Invoices, installed into one project of this instance: tables and indexes,
// the settings row (only into an empty table), the scripts, six workflows
// with their checks (each one runs only when its --where finds work), the
// desk `invoices` and the client's page `invoice` with their grants, views,
// actions, brand and brief, and the links the scripts give out. Converges:
// run it again after a change and it ends in the same state. Sends nothing
// and turns nothing on: Stripe starts off, and every email waits for a person.
//
// When the project also has the CRM (crm_companies, crm_contacts), the desk
// asks to read them, for "From CRM" when picking a client. Without it nothing
// is asked; installing the CRM later and running this again adds it.
//
//   as node, by the team over ssh:        gosu node node install.js <bundle> --project default --agent dario
//   as the project's agent, over the MCP: projects.run → node <bundle>/install.js <bundle> --project default --agent dario
// Over the MCP each call has 120 s: run it in parts with --only (in this order):
//   --only files,tables,seed  ·  --only workflows,schedule  ·  --only desk  ·  --only public,settings
// Prints one JSON line per step, and at the end what a person still has to do.
'use strict';
const { execFileSync } = require('child_process');
const fs = require('fs');
const path = require('path');

const B = path.resolve(process.argv[2] || __dirname);
const flag = (name, fallback) => { const i = process.argv.indexOf(`--${name}`); return i > 0 && process.argv[i + 1] ? process.argv[i + 1] : fallback; };
const PROJECT = flag('project', 'default');
const AGENT = flag('agent', '');
const ONLY = new Set((flag('only', 'files,tables,seed,workflows,schedule,desk,public,settings')).split(','));
const STATE = process.env.OPENCLAW_STATE_DIR || '/home/node/.openclaw';
const HOME = path.join(STATE, 'orchestra', 'projects', PROJECT);
const AUTO = path.join(HOME, 'apps', 'invoices', 'automations');
const read = (f) => fs.readFileSync(path.join(B, f), 'utf8');
const json = (f) => JSON.parse(read(f));
const todo = [];
const out = (step, data) => console.log(JSON.stringify(Object.assign({ step }, data)));

function cli(bin, args, { soft = false } = {}) {
  let text;
  try {
    text = execFileSync(bin, args, { encoding: 'utf8', timeout: 100000, maxBuffer: 32 << 20 });
  } catch (e) {
    text = String(e.stdout || '') || String(e.stderr || e.message);
    if (!soft) out('warn', { bin, args: args.slice(0, 3), said: text.trim().slice(0, 300) });
  }
  try { return JSON.parse(text); } catch { return { raw: String(text).trim().slice(0, 600) }; }
}
const db = (...a) => cli('orch-database', ['--project', PROJECT, ...a]);
const canvas = (...a) => cli('orch-canvas', a);
const wf = (...a) => cli('orch-workflows', a);
const pick = (o, keys) => Object.fromEntries(keys.filter((k) => o && o[k] !== undefined).map((k) => [k, o[k]]));
const ids = () => { try { return JSON.parse(fs.readFileSync(path.join(AUTO, '..', 'workflows.json'), 'utf8')); } catch { return {}; } };
const WORKFLOWS = ['docs', 'send', 'respond', 'draft', 'remind', 'stripe'];
// Staggered, so the checks never start in the same minute. Reminders once a day.
const CRON = { docs: '*/30 * * * *', send: '5,35 * * * *', respond: '10,40 * * * *', draft: '15,45 * * * *', remind: '0 8 * * *', stripe: '20 * * * *' };
const CHECK = { docs: 'Issue and update links (half-hourly check)', send: 'Send emails (half-hourly check)', respond: 'Client answers (half-hourly check)',
  draft: 'Draft a quote (half-hourly check)', remind: 'Payment reminders (daily, only when an invoice is overdue)', stripe: 'Stripe payments (hourly, only while Stripe is on)' };
const CRM_TABLES = ['crm_companies', 'crm_contacts'];
/** Whether this project has the CRM: both of its tables answer a count. */
const hasCrm = () => CRM_TABLES.every((t) => { const r = cli('orch-database', ['--project', PROJECT, 'query', `SELECT COUNT(*) AS n FROM ${t}`], { soft: true }); return Array.isArray(r.rows); });

// ── 1. the scripts ───────────────────────────────────────────────────────
if (ONLY.has('files')) {
  fs.mkdirSync(AUTO, { recursive: true });
  for (const f of fs.readdirSync(path.join(B, 'automations'))) fs.copyFileSync(path.join(B, 'automations', f), path.join(AUTO, f));
  out('files', { dir: AUTO, files: fs.readdirSync(AUTO) });
}

// ── 2. tables and indexes ────────────────────────────────────────────────
const schema = json('schema.json');
if (ONLY.has('tables')) {
  for (const [table, cols] of Object.entries(schema.tables)) {
    out('table', Object.assign({ table }, pick(db('ensure-table', table, '--columns', ...cols), ['ok', 'action', 'created', 'added', 'error', 'raw'])));
  }
  for (const sql of schema.indexes) out('index', Object.assign({ sql: sql.slice(0, 80) }, pick(db('sql', sql, '--confirm'), ['ok', 'error', 'raw'])));
}

// ── 3. seed, only into empty tables ──────────────────────────────────────
if (ONLY.has('seed')) {
  const count = (t) => (((db('query', `SELECT COUNT(*) AS n FROM ${t} WHERE _deleted = 0`).rows || [{}])[0]) || {}).n;
  for (const [table, rows] of Object.entries(json('seed.json'))) {
    if (count(table) > 0) { out('seed', { table, left: 'it has rows' }); continue; }
    const data = rows.map((r) => Object.fromEntries(Object.entries(r).map(([k, v]) => [k, v !== null && typeof v === 'object' ? JSON.stringify(v) : v])));
    if (table === 'inv_settings' && AGENT) data[0].agent = AGENT;
    out('seed', Object.assign({ table }, pick(db('insert-many', table, '--data', JSON.stringify(data)), ['ok', 'count', 'inserted', 'error', 'raw'])));
  }
}

// ── 4. workflows (by name: created once, updated after) ─────────────────
if (ONLY.has('workflows')) {
  if (!AGENT) throw new Error('--agent <id> names the project member the scripts run as and who drafts quotes and reminders (the project\'s coordinator)');
  const existing = wf('list').workflows || [];
  const WF = {};
  const tmp = fs.mkdtempSync('/tmp/invoices-wf-');
  for (const key of WORKFLOWS) {
    // runsAs: the scripts run as this agent (orch-as), so it must be a member of the project to reach its database.
    const spec = Object.assign(JSON.parse(read(`workflows/${key}.json`).replace(/__AUTO__/g, AUTO).replace(/__AGENT__/g, AGENT)),
      { project: PROJECT, runsAs: AGENT });
    const file = path.join(tmp, `${key}.json`);
    fs.writeFileSync(file, JSON.stringify(spec));
    const found = existing.find((w) => w.name === spec.name);
    const r = found ? wf('update', found.id, '--file', file) : wf('create', '--file', file);
    WF[key] = found ? found.id : ((r.workflow && r.workflow.id) || r.id || r.workflowId);
    out('workflow', { name: spec.name, id: WF[key], did: found ? 'updated' : 'created', error: r.error || undefined });
  }
  fs.rmSync(tmp, { recursive: true, force: true });
  // The actions' $WF_* are these ids.
  fs.writeFileSync(path.join(AUTO, '..', 'workflows.json'), JSON.stringify(WF, null, 1));
}

// ── 5. the half-hourly checks: each one only when its --where finds work ──
if (ONLY.has('schedule')) {
  const WF = ids();
  for (const key of WORKFLOWS) {
    if (!WF[key]) { out('schedule', { workflow: key, error: 'not created: run --only workflows first' }); continue; }
    for (const s of (wf('schedules', WF[key]).schedules || [])) out('unschedule', pick(wf('unschedule', s.jobId), ['ok', 'error']));
    out('schedule', Object.assign({ workflow: key }, pick(wf('schedule', WF[key], '--cron', CRON[key], '--timezone', 'UTC', '--name', `Invoices · ${CHECK[key]}`,
      '--table', 'inv_settings', '--where', read(`workflows/${key}.where`), '--limit', '1'), ['ok', 'jobId', 'schedule', 'error', 'raw'])));
  }
}

// ── 6. the apps ──────────────────────────────────────────────────────────
function app(id, src, brief) {
  let a = (canvas('list').apps || []).find((x) => x.id === id);
  if (!a) {
    out('init', Object.assign({ app: id }, pick(canvas('init', id, '--project', PROJECT, '--pattern', 'list', '--confirmed', ...brief), ['ok', 'dir', 'url', 'error', 'raw'])));
    a = (canvas('list').apps || []).find((x) => x.id === id);
  }
  if (!a) throw new Error(`The app ${id} could not be created`);
  const dir = path.join(STATE, 'orchestra', a.dir);
  const ours = new Set();
  const copy = (from, to) => {
    for (const f of fs.readdirSync(from)) {
      const s = path.join(from, f);
      const d = path.join(to, f);
      if (fs.statSync(s).isDirectory()) { fs.mkdirSync(d, { recursive: true }); copy(s, d); } else { fs.copyFileSync(s, d); ours.add(path.relative(dir, d)); }
    }
  };
  copy(path.join(B, src), dir);
  // What the starter wrote and Invoices does not use goes, so the app is exactly the source.
  const sweep = (d) => {
    for (const f of fs.readdirSync(d)) {
      const p = path.join(d, f);
      const rel = path.relative(dir, p);
      if (rel.startsWith('_') || rel.startsWith('.')) continue;
      if (fs.statSync(p).isDirectory()) sweep(p); else if (!ours.has(rel)) { fs.unlinkSync(p); out('removed', { app: id, file: rel }); }
    }
  };
  sweep(dir);
  out('files', { app: id, dir, count: ours.size });
  return a;
}

function actions(id, list) {
  const WF = ids();
  const sub = (v) => (typeof v === 'string' && v.startsWith('$WF_') ? WF[v.slice(4).toLowerCase()] : v);
  for (const a of list) {
    const args = ['action', 'add', id, '--name', a.name, '--type', a.type, '--access', a.access || 'members'];
    if (a.table) args.push('--table', a.table);
    if (a.fields) args.push('--fields', a.fields.join(','));
    if (a.defaults) args.push('--defaults', JSON.stringify(a.defaults));
    if (a.precondition) args.push('--precondition', JSON.stringify(a.precondition));
    if (a.bulk) args.push('--bulk');
    if (a.steps) args.push('--steps', JSON.stringify(a.steps));
    if (a.workflow) args.push('--workflow', sub(a.workflow));
    if (a.args) args.push('--args', JSON.stringify(a.args));
    if (a.trigger) args.push('--trigger-workflow', sub(a.trigger));
    out('action', Object.assign({ app: id, name: a.name }, pick(canvas(...args), ['ok', 'error', 'raw'])));
  }
}

function brand(id, spec) {
  const args = ['brand', 'set', id, '--preset', spec.preset];
  for (const [k, v] of Object.entries(spec.brand || {})) args.push(`--${k}`, v);
  out('brand', Object.assign({ app: id }, pick(canvas(...args), ['ok', 'error', 'raw'])));
}

if (ONLY.has('desk')) {
  app('invoices', 'app', ['--name', 'Invoices', '--icon', '🧾', '--desc', 'Quotes and invoices: issue them, send them, and see what is owed',
    '--user', 'The owner, or whoever keeps the books, of a small company or a freelancer',
    '--frequency', 'Several times a week',
    '--question', 'How much am I owed, and who is late?',
    '--question', 'Which quotes are waiting for an answer?',
    '--question', 'What did I invoice this client?',
    '--primary-action', 'Issue an invoice or a quote, and send it to the client']);
  const crm = hasCrm();
  const grants = ['inv_settings', 'inv_clients', 'inv_documents', 'inv_emails'].map((t) => `${t}:action`).concat(crm ? CRM_TABLES.map((t) => `${t}:read`) : []);
  // One --grant with every table: the flag is nargs="*", so repeating it keeps only the last.
  const g = canvas('grants', 'set', 'invoices', '--grant', ...grants);
  out('grants', Object.assign({ app: 'invoices', crm }, pick(g, ['ok', 'grants', 'pendingApproval', 'error', 'raw'])));
  if ((g.pendingApproval || []).length) todo.push(`Approve the tables Invoices asks for: ${g.pendingApproval.map((x) => x.table || x).join(', ')} (Canvas → Invoices → who gets in)`);
  for (const f of fs.readdirSync(path.join(B, 'sql'))) {
    const r = canvas('view', 'add', 'invoices', '--name', f.replace(/\.sql$/, ''), '--sql-file', path.join(B, 'sql', f), '--description', f.replace(/\.sql$/, '').replace(/_/g, ' '));
    out('view', Object.assign({ app: 'invoices', name: f }, pick(r, ['ok', 'reads', 'pending', 'error', 'raw'])));
  }
  actions('invoices', json('actions.json'));
  brand('invoices', json('brand.json').invoices);
  out('brief', pick(canvas('brief', 'set', 'invoices', '--density', 'balanced', '--variety', 'focused', '--confirmed'), ['ok', 'error', 'raw']));
  todo.push('Publish Invoices (Canvas → Invoices → History)');
}

const PUBLIC_VIEWS = {
  doc_links: 'One sealed row per quote or invoice sent to a client: a hash of the link\'s token and the document encrypted with that token. Without the link a row says nothing; nothing in it is readable.',
};
if (ONLY.has('public')) {
  app('invoice', 'public', ['--name', 'Invoice', '--icon', '🧾', '--desc', 'The page a client opens from their link: a quote to accept, or an invoice to pay',
    '--user', 'Your clients, from the link in your email',
    '--frequency', 'Once or twice per document',
    '--question', 'What am I being asked to pay or accept, and how?',
    '--primary-action', 'Accept the quote, or pay the invoice']);
  for (const [name, description] of Object.entries(PUBLIC_VIEWS)) {
    const r = canvas('view', 'add', 'invoice', '--name', name, '--access', 'public', '--sql-file', path.join(B, 'public-sql', `${name}.sql`), '--description', description);
    out('view', Object.assign({ app: 'invoice', name }, pick(r, ['ok', 'pending', 'status', 'error', 'raw'])));
  }
  actions('invoice', json('public-actions.json'));
  brand('invoice', json('brand.json').invoice);
  todo.push('Approve the public list "doc_links" for the internet (Canvas → Invoice → the first tab)');
  todo.push('Set Invoice to Public, and publish it (Canvas → Invoice)');
}

// ── 7. where the apps live, for the links the scripts give out ───────────
if (ONLY.has('settings')) {
  const url = (id) => { const u = canvas('url', id).url || ''; return u.endsWith('/') ? u : (u ? `${u}/` : ''); };
  const s = (db('query', 'SELECT _id, agent FROM inv_settings WHERE _deleted = 0 ORDER BY _id LIMIT 1').rows || [])[0];
  if (s) {
    const data = { public_url: url('invoice'), desk_url: url('invoices'), installed_version: read('VERSION').trim(), crm_available: hasCrm() ? 'yes' : 'no' };
    if (AGENT && !s.agent) data.agent = AGENT;
    out('settings', Object.assign(data, pick(db('update', 'inv_settings', '--id', String(s._id), '--data', JSON.stringify(data)), ['ok', 'error'])));
  }
  todo.push('Open Invoices: Getting started asks for your company and how you get paid');
}

out('done', { project: PROJECT, a_person_still_has_to: todo });
