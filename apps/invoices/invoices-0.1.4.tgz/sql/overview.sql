SELECT d.currency,
       SUM(CASE WHEN d.kind = 'invoice' AND d.status = 'Issued' THEN d.total ELSE 0 END) AS outstanding,
       SUM(CASE WHEN d.kind = 'invoice' AND d.status = 'Issued' THEN 1 ELSE 0 END) AS outstanding_n,
       SUM(CASE WHEN d.kind = 'invoice' AND d.status = 'Issued' AND d.due_date < here.today THEN d.total ELSE 0 END) AS overdue,
       SUM(CASE WHEN d.kind = 'invoice' AND d.status = 'Issued' AND d.due_date < here.today THEN 1 ELSE 0 END) AS overdue_n,
       SUM(CASE WHEN d.kind = 'invoice' AND d.status = 'Paid' AND d.paid_at >= substr(here.today, 1, 8) || '01' THEN d.total ELSE 0 END) AS paid_month,
       SUM(CASE WHEN d.kind = 'invoice' AND d.status = 'Paid' AND d.paid_at >= substr(here.today, 1, 8) || '01' THEN 1 ELSE 0 END) AS paid_month_n,
       SUM(CASE WHEN d.kind = 'quote' AND d.status = 'Sent' AND d.due_date >= here.today THEN d.total ELSE 0 END) AS quotes_open,
       SUM(CASE WHEN d.kind = 'quote' AND d.status = 'Sent' AND d.due_date >= here.today THEN 1 ELSE 0 END) AS quotes_open_n
FROM inv_documents d
CROSS JOIN (SELECT COALESCE((SELECT date('now', COALESCE(CASE WHEN datetime('now') < COALESCE(s.tz_change_at, '9999-12-31') THEN s.tz_offset ELSE s.tz_next_offset END, 0) || ' minutes') FROM inv_settings s WHERE s._deleted = 0 ORDER BY s._id LIMIT 1), date('now')) AS today) here
WHERE d.status NOT IN ('Draft', 'Discarded')
GROUP BY d.currency
