SELECT d._id, d.kind, d.status, d.number, d.title, d.currency, d.total, d.issue_date, d.due_date, d.paid_at, d.client_id,
       d.issue_asked_at, d.issue_note, d.ai_status, d.reminders, d.sent_at, d._created_at, d.seq, d.series_year,
       COALESCE(NULLIF(json_extract(d.client_snapshot, '$.name'), ''), c.name, '') AS client_name,
       CASE
         WHEN d.status = 'Issued' AND d.due_date < here.today THEN 'Overdue'
         WHEN d.status = 'Sent' AND d.due_date < here.today THEN 'Expired'
         ELSE d.status
       END AS state,
       CASE WHEN d.status = 'Draft' THEN '0' ELSE '1' END AS issued
FROM inv_documents d
LEFT JOIN inv_clients c ON c._id = d.client_id
CROSS JOIN (SELECT COALESCE((SELECT date('now', COALESCE(CASE WHEN datetime('now') < COALESCE(s.tz_change_at, '9999-12-31') THEN s.tz_offset ELSE s.tz_next_offset END, 0) || ' minutes') FROM inv_settings s WHERE s._deleted = 0 ORDER BY s._id LIMIT 1), date('now')) AS today) here
WHERE d.status <> 'Discarded'
