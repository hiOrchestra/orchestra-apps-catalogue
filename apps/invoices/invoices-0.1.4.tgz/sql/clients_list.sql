SELECT c._id, c.name, c.tax_id, c.email, c.contact_name, c.country, c.archived, c.crm_company_id,
       (SELECT COUNT(*) FROM inv_documents d WHERE d.client_id = c._id AND d.kind = 'invoice' AND d.status IN ('Issued', 'Paid')) AS invoices,
       (SELECT COALESCE(SUM(d.total), 0) FROM inv_documents d WHERE d.client_id = c._id AND d.kind = 'invoice' AND d.status = 'Issued') AS outstanding,
       (SELECT MAX(d.currency) FROM inv_documents d WHERE d.client_id = c._id AND d.kind = 'invoice' AND d.status = 'Issued') AS outstanding_currency,
       (SELECT MAX(d.issue_date) FROM inv_documents d WHERE d.client_id = c._id AND d.status NOT IN ('Draft', 'Discarded')) AS last_at
FROM inv_clients c
