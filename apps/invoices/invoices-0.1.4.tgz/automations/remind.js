'use strict';
/**
 * Invoices · Payment reminders, once a day. Nothing is sent from here: each
 * reminder is an email waiting in Review for a person's Approve.
 *
 *   node remind.js pick  the overdue invoices that need one: issued, past due,
 *                        a client address, fewer than 3 reminders, none waiting,
 *                        the last one at least `reminder_days` ago (10 a run)
 *   (the agent)          answers JSON only: one {id, subject, body} per invoice,
 *                        polite the first time, firmer the second and third
 *   node remind.js save  checks each email (subject, length, no placeholders);
 *                        one that does not pass is replaced by the plain
 *                        template, so every invoice picked gets its draft. The
 *                        link to the invoice is added by the script, never by
 *                        the agent. Then the owner hears it on Telegram.
 */
const L = require('./lib');
const C = require('./invcore');

const MAX = 3;
const PER_RUN = 10;

function due(s) {
  const day = C.today(s.timezone, L.now());
  const every = Math.max(1, Number(s.reminder_days) || 7);
  return L.all(`SELECT d.* FROM inv_documents d WHERE d._deleted = 0 AND d.kind = 'invoice' AND d.status = 'Issued'
      AND d.due_date < ? AND COALESCE(d.reminders, 0) < ${MAX}
      AND (COALESCE(d.last_reminder_at, '') = '' OR datetime(d.last_reminder_at) <= datetime(?, '-${every} days'))
      AND NOT EXISTS (SELECT 1 FROM inv_emails e WHERE e._deleted = 0 AND e.doc_id = d._id AND e.purpose = 'reminder' AND e.status IN ('Review', 'Approved', 'Sending'))
    ORDER BY d.due_date, d._id LIMIT 50`, day, L.sqlNow())
    .map((d) => Object.assign(d, { client: L.jsonOf(d.client_snapshot, {}) }))
    .filter((d) => C.isEmail(d.client.email))
    .slice(0, PER_RUN)
    .map((d) => Object.assign(d, { late: C.daysBetween(d.due_date, day) }));
}

function pick() {
  const s = L.settings();
  if (s.reminders_on !== 'yes') return { skip: true, why: 'Reminders are off in Settings' };
  const list = due(s);
  if (!list.length) return { skip: true, why: 'No overdue invoice needs a reminder today' };
  const locale = C.localeOf(s.language);
  return {
    language: s.language === 'es' ? 'Spanish' : 'English',
    company: s.company_name || '',
    invoices: list.map((d) => ({
      id: d._id, number: d.number, client: d.client.name, contact: d.client.contact_name || '',
      total: C.money(d.total, d.currency, locale), due: C.longDay(d.due_date, s.language), days_overdue: d.late,
      reminder: (Number(d.reminders) || 0) + 1, earlier: L.all("SELECT subject, sent_at FROM inv_emails WHERE _deleted = 0 AND doc_id = ? AND purpose = 'reminder' AND status = 'Sent' ORDER BY _id", d._id),
    })),
  };
}

const PLACEHOLDER = /\{\{|\}\}|\[(name|client|amount|date|link|number|your name)\]|<(name|link)>|lorem ipsum/i;
/** One agent email, cleaned, or null when it cannot be sent as written. */
function checkOne(e) {
  if (!e || typeof e !== 'object') return null;
  const subject = L.clean(e.subject, 160).replace(/\n/g, ' ');
  const body = L.clean(e.body, 3000);
  if (subject.length < 4 || body.length < 20) return null;
  if (PLACEHOLDER.test(subject) || PLACEHOLDER.test(body)) return null;
  if (/https?:\/\//i.test(body)) return null; // the link is ours to add
  return { subject, body };
}

function save() {
  const picked = L.stepOut('STEP_pick');
  if (picked.skip || !Array.isArray(picked.invoices)) return { ok: true, skipped: picked.why || 'Nothing was picked' };
  const s = L.settings();
  const given = L.jsonIn(process.env.PRIOR);
  const emails = given && Array.isArray(given.emails) ? given.emails : [];
  const still = new Map(due(s).map((d) => [d._id, d]));
  const ops = [];
  const out = { ok: true, drafted: [], template: [], skipped: [] };
  for (const p of picked.invoices) {
    const d = still.get(p.id);
    if (!d) { out.skipped.push(p.id); continue; } // paid, voided or reminded meanwhile
    const link = s.public_url ? `${s.public_url}#/${d.link_token}` : '';
    const w = C.WORDS[s.language === 'es' ? 'es' : 'en'];
    const mine = checkOne(emails.find((e) => e && Number(e.id) === d._id));
    const mail = mine ? { subject: mine.subject, body: `${mine.body}\n\n${w.view}: ${link}` } : C.reminderEmail(d, s, link);
    ops.push({ op: 'insert', table: 'inv_emails', data: {
      doc_id: d._id, purpose: 'reminder', n: (Number(d.reminders) || 0) + 1, to_email: C.normEmail(d.client.email),
      subject: mail.subject, body: mail.body, status: 'Review', drafted_by: mine ? 'agent' : 'template' } });
    (mine ? out.drafted : out.template).push(d._id);
  }
  ops.push({ op: 'update', table: 'inv_settings', id: s._id, data: { reminders_run_at: L.sqlNow() } });
  L.write(ops);
  const n = out.drafted.length + out.template.length;
  if (n) L.telegram(s.notify_telegram, `${n} payment reminder${n > 1 ? 's wait' : ' waits'} for your OK in Invoices.${s.desk_url ? `\n${s.desk_url}` : ''}`);
  return out;
}

if (require.main === module) {
  const cmd = process.argv[2];
  let out;
  try { out = cmd === 'pick' ? pick() : cmd === 'save' ? save() : { ok: false, error: 'node remind.js pick|save' }; } catch (e) { out = { ok: false, error: e.message }; }
  L.done(out);
}

module.exports = { pick, save, due, checkOne };
