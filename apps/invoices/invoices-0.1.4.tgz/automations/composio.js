'use strict';
/**
 * Every call Invoices makes to Composio, and nothing else: the tool slugs,
 * their arguments, and how each answer is read. When Composio renames an
 * argument, this is the only file to change.
 *
 *   gmailSend({ to, subject, body })     GMAIL_SEND_EMAIL              one email, from the connected account
 *   stripeLink(doc, settings)            STRIPE_CREATE_PRICE           a one-off price for the invoice's total
 *                                        STRIPE_CREATE_PAYMENT_LINK    a hosted page that charges it (cards never touch us)
 *   stripePaid(linkId)                   STRIPE_LIST_CHECKOUT_SESSIONS completed, paid sessions of that link
 *   stripeOff(linkId)                    STRIPE_UPDATE_PAYMENT_LINK    active: false, so nobody pays twice
 *
 * The four Stripe slugs exist in Composio's Stripe toolkit (docs.composio.dev,
 * 04/10/2026); their argument names follow Stripe's API and must be checked
 * with `orch-composio schema --slug …` on a live instance before Stripe is
 * offered (README, "Before it goes live").
 *
 * Calls go through the instance (POST 127.0.0.1:3001/api/composio/execute) as
 * the workflow's agent (lib.composio). INV_FAKE_COMPOSIO=1 answers from
 * INV_FAKE_DATA, a JSON file: { fail: {SLUG: "why"}, timeout: {SLUG: true},
 * sessions: {linkId: [{payment_status, status}]}, links: {}, sent: [] };
 * every email the fake "sends" is appended to `sent`.
 */
const fs = require('fs');
const L = require('./lib');

const SLUG = {
  send: 'GMAIL_SEND_EMAIL', price: 'STRIPE_CREATE_PRICE', link: 'STRIPE_CREATE_PAYMENT_LINK',
  sessions: 'STRIPE_LIST_CHECKOUT_SESSIONS', update: 'STRIPE_UPDATE_PAYMENT_LINK',
};

/** The first scalar under `key` anywhere in a nested answer (Composio wraps answers differently per tool). */
function valueAt(obj, key, depth = 0) {
  if (!obj || typeof obj !== 'object' || depth > 5) return undefined;
  if (obj[key] !== undefined && obj[key] !== null && typeof obj[key] !== 'object') return obj[key];
  for (const v of Object.values(obj)) {
    const found = valueAt(v, key, depth + 1);
    if (found !== undefined) return found;
  }
  return undefined;
}
/** Every object anywhere in an answer that has `key` (sessions inside data.data, or data, or items). */
function objectsWith(obj, key, out = [], depth = 0) {
  if (!obj || typeof obj !== 'object' || depth > 6) return out;
  if (!Array.isArray(obj) && obj[key] !== undefined) out.push(obj);
  for (const v of Object.values(obj)) objectsWith(v, key, out, depth + 1);
  return out;
}

/** One email from the Gmail account connected to the workspace. { id } or throws (with .timeout when it may have gone). */
function gmailSend({ to, subject, body, account }) {
  const r = L.composio(SLUG.send, Object.assign({ recipient_email: to, subject, body, is_html: false, user_id: 'me' }, account ? { account } : {}), 60);
  if (!r.ok) throw Object.assign(new Error(r.why), { timeout: !!r.timedOut });
  return { id: String(valueAt(r.data, 'id') || valueAt(r.data, 'messageId') || '') || null };
}

/**
 * A Stripe Payment Link for an issued invoice's total: one price (made with
 * its own product, named after the invoice), then the link, quantity fixed at
 * one. { priceId, linkId, url } or throws with Stripe's sentence.
 */
function stripeLink(doc, s) {
  const name = `${s.language === 'es' ? 'Factura' : 'Invoice'} ${doc.number}${s.company_name ? ` · ${s.company_name}` : ''}`.slice(0, 200);
  const price = L.composio(SLUG.price, {
    currency: String(doc.currency || 'EUR').toLowerCase(),
    unit_amount: Number(doc.total),
    product_data: { name, metadata: { orchestra_invoice: String(doc._id) } },
  });
  if (!price.ok) throw new Error(price.why);
  const priceId = valueAt(price.data, 'id');
  if (!priceId || !String(priceId).startsWith('price_')) throw new Error('Stripe made no price for it');
  const link = L.composio(SLUG.link, {
    line_items: [{ price: priceId, quantity: 1 }],
    metadata: { orchestra_invoice: String(doc._id), number: String(doc.number) },
    after_completion: { type: 'hosted_confirmation', hosted_confirmation: { custom_message: s.language === 'es' ? `Gracias: la factura ${doc.number} está pagada.` : `Thank you: invoice ${doc.number} is paid.` } },
  });
  if (!link.ok) throw new Error(link.why);
  const linkId = valueAt(link.data, 'id');
  const url = valueAt(link.data, 'url');
  if (!linkId || !/^https:\/\//.test(String(url || ''))) throw new Error('Stripe made no payment link for it');
  // Composio's create takes no `restrictions` (its update does, live schema
  // 2026-10-04): one payment only, set right after. Best effort — the hourly
  // payment check switches the link off once it is paid anyway.
  L.composio(SLUG.update, { payment_link: String(linkId), restrictions: { completed_sessions: { limit: 1 } } });
  return { priceId: String(priceId), linkId: String(linkId), url: String(url) };
}

/** Whether a link has a completed, paid checkout: { paid, at } or throws. */
function stripePaid(linkId) {
  const r = L.composio(SLUG.sessions, { payment_link: linkId, status: 'complete', limit: 10 });
  if (!r.ok) throw new Error(r.why);
  const paid = objectsWith(r.data, 'payment_status').filter((x) => x.payment_status === 'paid' && (!x.payment_link || x.payment_link === linkId));
  if (!paid.length) return { paid: false };
  const t = Math.min(...paid.map((x) => Number(x.created) || Infinity));
  return { paid: true, at: Number.isFinite(t) ? new Date(t * 1000).toISOString().slice(0, 10) : null, session: paid[0].id || null };
}

/** Switch a link off. { ok } — never throws: an old link left on is told, not fatal. */
function stripeOff(linkId) {
  const r = L.composio(SLUG.update, { payment_link: linkId, active: false });
  return r.ok ? { ok: true } : { ok: false, why: r.why };
}

/** Composio said "this account is not connected" (or expired, revoked). */
const NOT_CONNECTED = /not connected|no (active )?connect|connected.?account.*(not found|missing|required)|no .*account.*(found|for)|connectedaccountnotfound|auth(entication)? (config )?(required|not found)|\b401\b|unauthori[sz]ed|invalid.*(token|api key)/i;

// ── the fake, for tests and the local harness ──────────────────────────
function fake(slug, args) {
  const file = process.env.INV_FAKE_DATA;
  const st = file && fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : {};
  const save = () => { if (file) fs.writeFileSync(file, JSON.stringify(st)); };
  if (st.timeout && st.timeout[slug]) return { ok: false, why: 'Operation timed out after 60000 milliseconds', timedOut: true };
  if (st.fail && st.fail[slug]) return { ok: false, why: st.fail[slug] };
  st.n = (st.n || 0) + 1;
  if (slug === SLUG.send) {
    if (/^fail@/.test(args.recipient_email)) return { ok: false, why: 'Invalid To header' };
    (st.sent = st.sent || []).push({ to: args.recipient_email, subject: args.subject, body: args.body });
    save();
    return { ok: true, data: { response_data: { id: `msg${st.n}`, threadId: `t${st.n}` } } };
  }
  if (slug === SLUG.price) { save(); return { ok: true, data: { id: `price_${st.n}`, unit_amount: args.unit_amount, currency: args.currency } }; }
  if (slug === SLUG.link) {
    const id = `plink_${st.n}`;
    (st.links = st.links || {})[id] = { active: true, price: args.line_items[0].price };
    save();
    return { ok: true, data: { id, url: `https://buy.stripe.com/test_${id}`, active: true } };
  }
  if (slug === SLUG.sessions) return { ok: true, data: { data: { object: 'list', data: (st.sessions && st.sessions[args.payment_link]) || [] } } };
  if (slug === SLUG.update) { if (st.links && st.links[args.payment_link]) st.links[args.payment_link].active = !!args.active; save(); return { ok: true, data: { id: args.payment_link, active: !!args.active } }; }
  return { ok: false, why: `The fake does not know ${slug}` };
}

module.exports = { SLUG, gmailSend, stripeLink, stripePaid, stripeOff, NOT_CONNECTED, fake, valueAt };
