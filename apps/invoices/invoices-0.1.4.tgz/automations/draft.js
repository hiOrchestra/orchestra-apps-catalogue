'use strict';
/**
 * Invoices · Draft a quote from a sentence ("web redesign for Acme, 3 pages +
 * CMS, 4.500 €"). The desk saves the sentence on a draft (ai_status Waiting)
 * and starts this workflow:
 *
 *   node draft.js pick   claims ONE waiting draft (Waiting → Working, atomic) and
 *                        prints what the agent needs: the sentence, the client,
 *                        the currency, the usual tax, the language, and lines
 *                        this company has quoted before (for its own prices)
 *   (the agent)          answers JSON only: title, lines, notes
 *   node draft.js save   checks the answer ($PRIOR) and writes the lines into the
 *                        draft — only while it is still a Waiting/Working draft.
 *                        Anything wrong: Failed with the reason; the draft is
 *                        left as it was. The agent writes nothing itself.
 */
const L = require('./lib');
const C = require('./invcore');

const STALE_MIN = 20;

function pick() {
  const s = L.settings();
  // A Working draft whose run died is put back once, then Failed.
  for (const d of L.all(`SELECT _id, ai_note FROM inv_documents WHERE _deleted = 0 AND ai_status = 'Working' AND datetime(_updated_at) <= datetime(?, '-${STALE_MIN} minutes')`, L.sqlNow())) {
    try { L.write([{ op: 'update', table: 'inv_documents', id: d._id, when: { ai_status: 'Working' }, data: { ai_status: 'Failed', ai_note: 'The agent did not finish. Try again.' } }]); } catch { /* moved on */ }
  }
  const d = L.one("SELECT * FROM inv_documents WHERE _deleted = 0 AND status = 'Draft' AND ai_status = 'Waiting' ORDER BY _id LIMIT 1");
  if (!d) return { skip: true, why: 'No draft is waiting for the agent' };
  try { L.write([{ op: 'update', table: 'inv_documents', id: d._id, when: { ai_status: 'Waiting', status: 'Draft' }, data: { ai_status: 'Working', ai_note: null } }]); } catch { return { skip: true, why: 'Taken by another run' }; }
  const client = d.client_id ? L.one('SELECT name, country FROM inv_clients WHERE _id = ?', d.client_id) : null;
  const cur = String(d.currency || s.currency || 'EUR').toUpperCase();
  const before = L.all(`SELECT lines, currency FROM inv_documents WHERE _deleted = 0 AND status NOT IN ('Draft', 'Discarded', 'Void') AND currency = ? ORDER BY _id DESC LIMIT 20`, cur);
  const seen = new Map();
  for (const b of before) for (const l of C.linesOf(b.lines)) if (l.description && !seen.has(l.description.toLowerCase())) seen.set(l.description.toLowerCase(), { description: l.description.slice(0, 160), unit_price: C.fromMinor(l.price, cur) });
  return {
    doc: d._id,
    request: L.clean(d.ai_prompt, 2000),
    client: client ? client.name : null,
    currency: cur,
    usual_tax_rate: Number(s.tax_rate) || 0,
    language: s.language === 'es' ? 'Spanish' : 'English',
    company: s.company_name || '',
    earlier_lines: [...seen.values()].slice(0, 25),
  };
}

/** The answer as lines the draft takes, or the reason it cannot be used. */
function check(given, cur) {
  if (!given || typeof given !== 'object' || Array.isArray(given)) return { error: 'The agent did not answer with JSON' };
  const raw = Array.isArray(given.lines) ? given.lines : [];
  if (!raw.length) return { error: 'The agent proposed no lines' };
  if (raw.length > 30) return { error: 'The agent proposed more than 30 lines' };
  const lines = [];
  for (const r of raw) {
    const description = L.clean(r && r.description, 300);
    const qty = Number(r && r.quantity);
    const unit = typeof (r && r.unit_price) === 'number' ? r.unit_price : C.parseAmount(r && r.unit_price);
    const tax = Number(r && r.tax_rate);
    const disc = r && r.discount !== undefined && r.discount !== null && r.discount !== '' ? Number(r.discount) : 0;
    if (!description) return { error: 'A line has no description' };
    if (/\{\{|\[(name|client|price|amount)\]|lorem ipsum/i.test(description)) return { error: 'A line has a placeholder in it' };
    if (!Number.isFinite(qty) || qty <= 0 || qty > 1e6) return { error: `"${description.slice(0, 40)}" has no sensible quantity` };
    if (unit === null || !Number.isFinite(unit) || unit < 0 || unit > 1e9) return { error: `"${description.slice(0, 40)}" has no sensible price` };
    if (!Number.isFinite(tax) || tax < 0 || tax > 100) return { error: `"${description.slice(0, 40)}" has no sensible tax rate` };
    if (!Number.isFinite(disc) || disc < 0 || disc > 100) return { error: `"${description.slice(0, 40)}" has no sensible discount` };
    lines.push(C.lineOf({ description, qty, price: C.round(unit * 10 ** C.decimals(cur)), tax, disc }));
  }
  if (C.totals({ lines }).total <= 0) return { error: 'The lines add up to nothing' };
  return { lines, title: L.clean(given.title, 160), notes: L.clean(given.notes, 1500) };
}

function save() {
  const picked = L.stepOut('STEP_pick');
  if (picked.skip || !Number.isInteger(picked.doc)) return { ok: true, skipped: 'Nothing was picked' };
  const d = L.one('SELECT * FROM inv_documents WHERE _id = ? AND _deleted = 0', picked.doc);
  if (!d || d.ai_status !== 'Working' || d.status !== 'Draft') return { ok: true, skipped: `Document ${picked.doc} is not waiting for the agent` };
  const c = check(L.jsonIn(process.env.PRIOR), String(d.currency || 'EUR').toUpperCase());
  if (c.error) {
    L.write([{ op: 'update', table: 'inv_documents', id: d._id, when: { ai_status: 'Working' }, data: { ai_status: 'Failed', ai_note: c.error } }]);
    return { ok: false, doc: d._id, failed: c.error };
  }
  const data = { lines: JSON.stringify(c.lines), ai_status: 'Done', ai_note: null };
  if (!String(d.title || '').trim() && c.title) data.title = c.title;
  if (!String(d.notes || '').trim() && c.notes) data.notes = c.notes;
  const t = C.totals({ lines: c.lines, withholding_rate: d.withholding_rate });
  Object.assign(data, { subtotal: t.subtotal, tax_total: t.taxTotal, withholding: t.withholding, total: t.total });
  L.write([{ op: 'update', table: 'inv_documents', id: d._id, when: { ai_status: 'Working', status: 'Draft' }, data }]);
  return { ok: true, doc: d._id, lines: c.lines.length, total: t.total };
}

if (require.main === module) {
  const cmd = process.argv[2];
  let out;
  try { out = cmd === 'pick' ? pick() : cmd === 'save' ? save() : { ok: false, error: 'node draft.js pick|save' }; } catch (e) { out = { ok: false, error: e.message }; }
  L.done(out);
}

module.exports = { pick, save, check };
