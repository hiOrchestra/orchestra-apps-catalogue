'use strict';
/**
 * Invoices · Send emails, from the Gmail account connected to the workspace
 * (Composio GMAIL_SEND_EMAIL), in plain text.
 *
 * Only what a person approved goes out: the email that carries a document is
 * written on its page and sent with its Send button (it is inserted Approved),
 * and a payment reminder the agent drafted waits in Review for Approve. Each
 * email is CLAIMED before Gmail is called (Approved → Sending, atomic), so none
 * leaves twice. One left Sending (a run that died, or Gmail did not answer) is
 * marked Failed and says it may have gone out: never retried blind.
 *
 * After it leaves: a document's email stamps `sent_at` on it; a reminder adds
 * one to the invoice's `reminders` and stamps `last_reminder_at`.
 *   node send.js [--auto|--now] [--dry-run]
 */
const L = require('./lib');
const C = require('./invcore');
const X = require('./composio');

const STALE_MIN = 15;

function run(mode = '--auto', { dry = false } = {}) {
  const held = L.lock('send');
  if (!held) return { ok: true, mode, skipped: 'Another run is sending' };
  try {
    const s = L.settings();
    const out = { ok: true, mode, sent: [], failed: [] };
    const stale = L.all(`SELECT _id FROM inv_emails WHERE _deleted = 0 AND status = 'Sending'
      AND datetime(lock_at) <= datetime(?, '-${STALE_MIN} minutes')`, L.sqlNow());
    if (stale.length && !dry) {
      L.write(stale.map((r) => ({ op: 'update', table: 'inv_emails', id: r._id, when: { status: 'Sending' }, data: {
        status: 'Failed', error: 'The send did not finish, so it may or may not have gone out. Look in Gmail\'s Sent folder before sending again.' } })));
    }
    if (stale.length) out.unfinished = stale.length;
    const queue = L.all("SELECT * FROM inv_emails WHERE _deleted = 0 AND status = 'Approved' ORDER BY approved_at, _id LIMIT 30");
    if (!queue.length) return Object.assign(out, { skipped: 'Nothing is approved' });
    if (dry) return Object.assign(out, { dry: true, wouldSend: queue.map((m) => ({ id: m._id, to: m.to_email, subject: m.subject })) });
    for (const m of queue) {
      const to = C.normEmail(m.to_email);
      if (!C.isEmail(to) || !String(m.subject || '').trim() || !String(m.body || '').trim()) {
        fail(m, 'It has no valid address, subject or message: nothing went out. Fix it and send it again.', out);
        continue;
      }
      try {
        L.write([{ op: 'update', table: 'inv_emails', id: m._id, when: { status: 'Approved' }, data: { status: 'Sending', lock_at: L.sqlNow(), error: null } }]);
      } catch { continue; } // dropped or taken meanwhile
      let res;
      try {
        res = X.gmailSend({ to, subject: m.subject, body: m.body, account: s.gmail_account || undefined });
      } catch (e) {
        fail(m, e.timeout
          ? `Gmail did not answer in time, so it may or may not have gone out. Look in Gmail's Sent folder before sending again. (${e.message})`
          : `Gmail did not take it: nothing went out. ${readable(e.message)}`, out, 'Sending');
        continue;
      }
      sent(m, to, res, out);
    }
    return out;
  } finally {
    held.release();
  }
}

/** What Gmail said, in words a person can act on, with the raw text after it. */
function readable(why) {
  const t = String(why || '');
  if (X.NOT_CONNECTED.test(t)) return `Gmail is not connected for this workspace: connect it in Orchestra → Integrations, then send again. (${t.slice(0, 200)})`;
  if (/invalid to|recipient|address/i.test(t)) return `The address was refused: check it and send again. (${t.slice(0, 200)})`;
  return `(${t.slice(0, 240)})`;
}

function fail(m, error, out, from = 'Approved') {
  try { L.write([{ op: 'update', table: 'inv_emails', id: m._id, when: { status: from }, data: { status: 'Failed', error: error.slice(0, 500) } }]); } catch { /* changed meanwhile */ }
  out.failed.push({ id: m._id, to: m.to_email, error: error.slice(0, 200) });
}

function sent(m, to, res, out) {
  const at = L.sqlNow();
  const ops = [{ op: 'update', table: 'inv_emails', id: m._id, data: { status: 'Sent', sent_at: at, gmail_message_id: res.id || null, error: null } }];
  const d = m.doc_id ? L.one('SELECT _id, reminders, sent_at FROM inv_documents WHERE _id = ? AND _deleted = 0', m.doc_id) : null;
  if (d && m.purpose === 'reminder') ops.push({ op: 'update', table: 'inv_documents', id: d._id, data: { reminders: (Number(d.reminders) || 0) + 1, last_reminder_at: at } });
  else if (d) ops.push({ op: 'update', table: 'inv_documents', id: d._id, data: { sent_at: at } });
  try { L.write(ops); } catch {
    // It went out: say so on the email even if the document could not be stamped.
    L.write([ops[0]]);
  }
  out.sent.push({ id: m._id, to, gmail: res.id || null });
}

if (require.main === module) {
  const argv = process.argv.slice(2);
  try {
    L.done(run(argv.includes('--now') ? '--now' : '--auto', { dry: argv.includes('--dry-run') }));
  } catch (e) { L.done({ ok: false, error: e.message }); process.exitCode = 1; }
}

module.exports = { run, readable };
