'use strict';
/**
 * Invoices · Client answers. The client's page leaves an answer to a quote in
 * inv_responses (a public insert: token, accept or decline, the typed name, the
 * box ticked, the trap field and the time on the page), then starts this
 * workflow carrying nothing. Each New answer is judged again here, because
 * the page is not to be trusted (a curl can call the action too):
 *
 *   Rejected  a bot (trap filled, under 3 seconds), a token that opens no quote,
 *             a quote that is not waiting for an answer (already answered,
 *             expired, a draft), an accept without a name or without the box
 *   Done      the quote becomes Accepted (with the name and the time) or Declined
 *
 * The same answer twice (the page retried) is Done with nothing changed. The
 * owner hears it on Telegram when a chat is set. The workflow's next step
 * (docs.js) rewrites the client's link, so their page shows the answer.
 *   node respond.js [--auto|--now]
 */
const L = require('./lib');
const C = require('./invcore');

const MIN_MS = 3000;

function run(mode = '--auto') {
  const held = L.lock('respond');
  if (!held) return { ok: true, mode, skipped: 'Another run is reading answers' };
  try {
    const s = L.settings();
    const day = C.today(s.timezone, L.now());
    const out = { ok: true, mode, accepted: [], declined: [], rejected: [], repeated: 0 };
    const news = L.all("SELECT * FROM inv_responses WHERE _deleted = 0 AND status = 'New' ORDER BY _id LIMIT 200");
    for (const r of news) {
      const verdict = judge(r, day);
      const at = L.sqlNow();
      if (verdict.reject) {
        close(r, 'Rejected', verdict.reject, verdict.doc ? verdict.doc._id : null, at);
        out.rejected.push({ id: r._id, why: verdict.reject });
        continue;
      }
      if (verdict.repeat) { close(r, 'Done', 'The same answer again', verdict.doc._id, at); out.repeated += 1; continue; }
      const d = verdict.doc;
      const accept = r.decision === 'accept';
      const data = accept
        ? { status: 'Accepted', accepted_at: at, accepted_name: L.clean(r.name, 120), answered_by: 'client' }
        : { status: 'Declined', declined_at: at, decline_reason: L.clean(r.note, 500) || null, answered_by: 'client' };
      try {
        L.write([
          { op: 'update', table: 'inv_documents', id: d._id, when: { status: 'Sent' }, data },
          { op: 'update', table: 'inv_responses', id: r._id, when: { status: 'New' }, data: { status: 'Done', doc_id: d._id, processed_at: at, reason: null } },
        ]);
      } catch { continue; } // answered meanwhile: the next run sees it as a repeat or a reject
      (accept ? out.accepted : out.declined).push({ id: d._id, number: d.number });
      const who = accept ? L.clean(r.name, 120) : (JSON.parse(d.client_snapshot || '{}').name || 'The client');
      const total = C.money(d.total, d.currency, C.localeOf(s.language));
      const desk = s.desk_url ? `\n${s.desk_url}#/doc/${d._id}` : '';
      L.telegram(s.notify_telegram, accept
        ? `Quote ${d.number} (${total}) was accepted by ${who}. Make it an invoice from its page.${desk}`
        : `Quote ${d.number} (${total}) was declined${r.note ? `: "${L.clean(r.note, 200)}"` : '.'}${desk}`);
    }
    return out;
  } finally {
    held.release();
  }
}

/** What to do with one answer: { reject } with the reason, { repeat }, or { doc } to apply. */
function judge(r, day) {
  if (String(r.hp || '').trim()) return { reject: 'The hidden field was filled (a bot)' };
  if (!(Number(r.ms) >= MIN_MS)) return { reject: 'Sent too fast to be a person' };
  if (!['accept', 'decline'].includes(r.decision)) return { reject: 'Neither accept nor decline' };
  if (!C.TOKEN.test(String(r.token || ''))) return { reject: 'No link token' };
  const doc = L.one("SELECT * FROM inv_documents WHERE _deleted = 0 AND link_token = ? AND kind = 'quote'", r.token);
  if (!doc) return { reject: 'The link opens no quote' };
  if ((doc.status === 'Accepted' && r.decision === 'accept') || (doc.status === 'Declined' && r.decision === 'decline')) return { repeat: true, doc };
  if (doc.status !== 'Sent') return { reject: `The quote is ${doc.status}, not waiting for an answer`, doc };
  if (doc.due_date && doc.due_date < day) return { reject: 'The quote has expired', doc };
  if (r.decision === 'accept') {
    if (String(r.name || '').trim().length < 2) return { reject: 'Accepted without a name', doc };
    if (r.agreed !== 'yes') return { reject: 'Accepted without ticking the box', doc };
  }
  return { doc };
}

function close(r, status, reason, docId, at) {
  try { L.write([{ op: 'update', table: 'inv_responses', id: r._id, when: { status: 'New' }, data: { status, reason, doc_id: docId, processed_at: at } }]); } catch { /* another run took it */ }
}

if (require.main === module) {
  try { L.done(run(process.argv.includes('--now') ? '--now' : '--auto')); } catch (e) { L.done({ ok: false, error: e.message }); process.exitCode = 1; }
}

module.exports = { run, judge };
