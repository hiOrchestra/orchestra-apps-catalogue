'use strict';
/**
 * Invoices · Issue and update links.
 *
 *   1. ISSUE. Each draft a person asked to issue (issue_asked_at) is checked
 *      (a client, lines, a total above zero), then numbered: the next of its
 *      series and year. The series row and the document change in ONE
 *      transaction, each with a `when` (the series still at the number read,
 *      the document still the draft that was asked), so two runs can never
 *      give the same number, and a number is never skipped: if the write
 *      fails, nothing was used. A unique index on (kind, number) backs it.
 *      Issuing also freezes the client's details on the document, recomputes
 *      the totals from the lines (the desk's figures are never trusted), sets
 *      the due date, and makes the client's link token.
 *   2. STRIPE, when it is on: a Payment Link for each issued invoice that has
 *      none (once: a failure is kept on the invoice with a Try again on the
 *      desk), and the link switched off once the invoice is paid or void.
 *   3. LINKS. Every document out of draft gets its sealed row in inv_links
 *      (invcore.snapshot → seal), rewritten only when what the client sees
 *      changed (a hash of the snapshot).
 *   4. THE DAY. The views count overdue and expired days where the company
 *      is: each run stores Settings' time zone as an offset, when it next
 *      changes and the offset after (invcore.tzWindow); the schedule runs it
 *      again once that change has passed.
 *
 * Started by the desk (Issue, Mark paid, Void, Settings) and every 30 minutes
 * when something waits. One run at a time (a lock); the `when`s are what
 * guarantee the numbering.
 *   node docs.js [--auto|--now] [--dry-run]
 */
const crypto = require('crypto');
const L = require('./lib');
const C = require('./invcore');
const X = require('./composio');

const sha = (s) => crypto.createHash('sha256').update(s).digest('hex');

async function run(mode = '--auto', { dry = false } = {}) {
  const held = process.env.INV_NO_LOCK === '1' ? { release() {} } : L.lock('docs');
  if (!held) return { ok: true, mode, skipped: 'Another run is issuing' };
  const out = { ok: true, mode, issued: [], refused: [], stripe: [], links: 0 };
  try {
    // A second pass picks up what was asked while the first was working.
    for (let pass = 0; pass < 3; pass += 1) {
      const n = issueAll(out, dry);
      if (!n) break;
    }
    if (dry) return out;
    stripe(out);
    out.links = await links();
    const s = L.settings();
    L.write([{ op: 'update', table: 'inv_settings', id: s._id, data: Object.assign({ links_built_at: L.sqlNow(), links_note: null }, C.tzWindow(s.timezone, L.now())) }]);
    return out;
  } catch (e) {
    try { const s = L.settings(); L.write([{ op: 'update', table: 'inv_settings', id: s._id, data: { links_note: `Could not finish: ${String(e.message).slice(0, 240)}` } }]); } catch { /* the note can wait */ }
    throw e;
  } finally {
    held.release();
  }
}

/** Issue every draft that was asked; how many were looked at. */
function issueAll(out, dry) {
  const asked = L.all("SELECT * FROM inv_documents WHERE _deleted = 0 AND status = 'Draft' AND COALESCE(issue_asked_at, '') <> '' ORDER BY issue_asked_at, _id");
  for (const d of asked) issueOne(d, out, dry);
  return asked.length;
}

function issueOne(asked, out, dry) {
  for (let attempt = 0; attempt < 6; attempt += 1) {
    const s = L.settings();
    const d = L.one('SELECT * FROM inv_documents WHERE _id = ? AND _deleted = 0', asked._id);
    if (!d || d.status !== 'Draft' || !d.issue_asked_at) return; // issued by another run, or withdrawn
    const client = d.client_id ? L.one('SELECT * FROM inv_clients WHERE _id = ? AND _deleted = 0', d.client_id) : null;
    const problems = C.issueProblems(d, client);
    if (problems.length) {
      if (!dry) {
        try { L.write([{ op: 'update', table: 'inv_documents', id: d._id, when: { status: 'Draft', issue_asked_at: d.issue_asked_at }, data: { issue_asked_at: null, issue_note: `Not issued: ${problems.join(' ')}` } }]); } catch { /* changed meanwhile */ }
      }
      out.refused.push({ id: d._id, why: problems });
      return;
    }
    const day = C.today(s.timezone, L.now());
    const year = Number(day.slice(0, 4));
    const kind = d.kind === 'quote' ? 'quote' : 'invoice';
    const series = L.one('SELECT * FROM inv_series WHERE _deleted = 0 AND kind = ? AND year = ?', kind, year);
    const n = (series ? Number(series.last) || 0 : 0) + 1;
    const number = C.numberOf(C.prefixOf(kind, s), year, n);
    const t = C.totals(d);
    const days = kind === 'quote' ? Number(s.quote_valid_days) || 30 : Number(s.payment_days) || 30;
    const due = C.realDay(d.due_date) && d.due_date >= day ? d.due_date : C.addDays(day, days);
    const frozen = Object.fromEntries(['name', 'tax_id', 'email', 'contact_name', 'address', 'country'].map((k) => [k, L.clean(client[k], 600)]));
    if (dry) { out.issued.push({ id: d._id, number, total: t.total, dry: true }); return; }
    const ops = [
      series
        ? { op: 'update', table: 'inv_series', id: series._id, when: { last: series.last }, data: { last: n } }
        : { op: 'insert', table: 'inv_series', data: { kind, year, last: n } },
      { op: 'update', table: 'inv_documents', id: d._id, when: { status: 'Draft', issue_asked_at: d.issue_asked_at }, data: {
        status: kind === 'quote' ? 'Sent' : 'Issued', number, series_year: year, seq: n,
        issue_date: day, due_date: due, currency: String(d.currency || s.currency || 'EUR').toUpperCase(),
        client_snapshot: JSON.stringify(frozen), lines: JSON.stringify(t.lines.map(({ description, qty, price, tax, disc }) => ({ description, qty, price, tax, disc }))),
        subtotal: t.subtotal, tax_total: t.taxTotal, withholding: t.withholding, total: t.total, withholding_rate: t.withholdingRate,
        link_token: d.link_token || C.newToken(), issued_at: L.sqlNow(), issue_note: null,
        stripe_link_active: null, reminders: 0,
      } },
    ];
    try {
      L.write(ops);
      out.issued.push({ id: d._id, number, total: t.total });
      return;
    } catch (e) {
      // The series moved (another run issued meanwhile), or the draft changed: read again and retry.
      out.retried = (out.retried || 0) + 1;
      if (attempt === 5) out.refused.push({ id: d._id, why: [`Could not take a number: ${String(e.message).slice(0, 200)}`] });
    }
  }
}

/** Payment links for issued invoices, and off for paid or void ones. */
function stripe(out) {
  const s = L.settings();
  if (s.stripe_on === 'yes') {
    const need = L.all(`SELECT * FROM inv_documents WHERE _deleted = 0 AND kind = 'invoice' AND status = 'Issued'
      AND COALESCE(stripe_link_id, '') = '' AND COALESCE(stripe_note, '') = '' ORDER BY _id LIMIT 20`);
    for (const d of need) {
      try {
        const link = X.stripeLink(d, s);
        L.write([{ op: 'update', table: 'inv_documents', id: d._id, when: { status: 'Issued' }, data: {
          stripe_price_id: link.priceId, stripe_link_id: link.linkId, stripe_link_url: link.url, stripe_link_active: 'yes', stripe_note: null } }]);
        L.write([{ op: 'update', table: 'inv_settings', id: s._id, data: { stripe_status: 'ok', stripe_checked_at: L.sqlNow(), stripe_note: null } }]);
        out.stripe.push({ id: d._id, link: link.linkId });
      } catch (e) {
        const notConnected = X.NOT_CONNECTED.test(e.message);
        const why = notConnected ? `Stripe is not connected: connect it in Orchestra → Integrations, then Try again. (${e.message})` : `Stripe did not make the payment link: ${e.message}`;
        try { L.write([{ op: 'update', table: 'inv_documents', id: d._id, data: { stripe_note: why.slice(0, 400) } }]); } catch { /* changed meanwhile */ }
        L.write([{ op: 'update', table: 'inv_settings', id: s._id, data: { stripe_status: notConnected ? 'not_connected' : 'error', stripe_checked_at: L.sqlNow(), stripe_note: why.slice(0, 400) } }]);
        out.stripe.push({ id: d._id, failed: why.slice(0, 200) });
        if (notConnected) break; // the others would say the same
      }
    }
  }
  // Paid or void: nobody should be able to pay it again.
  for (const d of L.all("SELECT _id, stripe_link_id FROM inv_documents WHERE _deleted = 0 AND status IN ('Paid', 'Void') AND stripe_link_active = 'yes'")) {
    const r = X.stripeOff(d.stripe_link_id);
    L.write([{ op: 'update', table: 'inv_documents', id: d._id, data: r.ok ? { stripe_link_active: 'no' }
      : { stripe_link_active: 'stuck', stripe_note: `The Stripe payment link could not be switched off: switch it off in Stripe (Payment links). (${String(r.why).slice(0, 200)})` } }]);
    out.stripe.push({ id: d._id, off: r.ok });
  }
}

/** Seal what each document's client sees; rewrite only what changed. How many rows were touched. */
async function links() {
  const s = L.settings();
  const have = new Map(L.all('SELECT _id, doc_id, hash, doc_seen FROM inv_links WHERE _deleted = 0').map((r) => [r.doc_id, r]));
  const docs = L.all("SELECT * FROM inv_documents WHERE _deleted = 0 AND status NOT IN ('Draft', 'Discarded') AND COALESCE(link_token, '') <> ''");
  const ops = [];
  for (const d of docs) {
    const snap = C.snapshot(d, s);
    const hash = sha(`${d.link_token}\n${JSON.stringify(snap)}`);
    const row = have.get(d._id);
    if (row && row.hash === hash) {
      // Nothing the client sees changed; remember the version looked at, so the half-hourly check rests.
      if (row.doc_seen !== d._updated_at) ops.push({ op: 'update', table: 'inv_links', id: row._id, data: { doc_seen: d._updated_at } });
      continue;
    }
    const data = { doc_id: d._id, k: await C.linkKey(d.link_token), box: await C.seal(d.link_token, snap), hash, built_at: L.isoZ(), doc_seen: d._updated_at };
    ops.push(row ? { op: 'update', table: 'inv_links', id: row._id, data } : { op: 'insert', table: 'inv_links', data });
  }
  if (ops.length) L.write(ops);
  return ops.length;
}

if (require.main === module) {
  const argv = process.argv.slice(2);
  const mode = argv.includes('--now') ? '--now' : '--auto';
  run(mode, { dry: argv.includes('--dry-run') })
    .then((r) => L.done(r))
    .catch((e) => { L.done({ ok: false, error: e.message }); process.exitCode = 1; });
}

module.exports = { run, links };
