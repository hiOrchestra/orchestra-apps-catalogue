'use strict';
/**
 * Invoices · Stripe payments. For each issued invoice with a live Payment
 * Link, asks Stripe (Composio STRIPE_LIST_CHECKOUT_SESSIONS) whether a
 * checkout of that link completed and was paid; if so the invoice is Paid
 * (`paid_how` stripe, the day of the payment). The workflow's next step
 * (docs.js) switches the link off and rewrites the client's page. A script,
 * no agent turn; hourly, only while such invoices exist. Card data never
 * reaches the instance: Stripe hosts the payment page.
 *   node stripe.js [--auto|--now]
 */
const L = require('./lib');
const C = require('./invcore');
const X = require('./composio');

function run(mode = '--auto') {
  const held = L.lock('stripe');
  if (!held) return { ok: true, mode, skipped: 'Another run is asking Stripe' };
  try {
    const s = L.settings();
    if (s.stripe_on !== 'yes') return { ok: true, mode, skipped: 'Stripe is off in Settings' };
    const out = { ok: true, mode, paid: [], open: 0 };
    const docs = L.all("SELECT * FROM inv_documents WHERE _deleted = 0 AND kind = 'invoice' AND status = 'Issued' AND stripe_link_active = 'yes' ORDER BY _id LIMIT 100");
    for (const d of docs) {
      let r;
      try { r = X.stripePaid(d.stripe_link_id); } catch (e) {
        L.write([{ op: 'update', table: 'inv_settings', id: s._id, data: { stripe_status: X.NOT_CONNECTED.test(e.message) ? 'not_connected' : 'error', stripe_checked_at: L.sqlNow(), stripe_note: `Could not ask Stripe about payments: ${String(e.message).slice(0, 240)}` } }]);
        return Object.assign(out, { ok: false, error: e.message });
      }
      if (!r.paid) { out.open += 1; continue; }
      try {
        L.write([{ op: 'update', table: 'inv_documents', id: d._id, when: { status: 'Issued' }, data: { status: 'Paid', paid_at: r.at || C.today(s.timezone, L.now()), paid_how: 'stripe', paid_by: 'Stripe' } }]);
      } catch { continue; } // marked by hand meanwhile
      out.paid.push({ id: d._id, number: d.number });
      L.telegram(s.notify_telegram, `Invoice ${d.number} (${C.money(d.total, d.currency, C.localeOf(s.language))}) was paid online with Stripe.${s.desk_url ? `\n${s.desk_url}#/doc/${d._id}` : ''}`);
    }
    L.write([{ op: 'update', table: 'inv_settings', id: s._id, data: { stripe_status: 'ok', stripe_checked_at: L.sqlNow() } }]);
    return out;
  } finally {
    held.release();
  }
}

if (require.main === module) {
  try { L.done(run(process.argv.includes('--now') ? '--now' : '--auto')); } catch (e) { L.done({ ok: false, error: e.message }); process.exitCode = 1; }
}

module.exports = { run };
