// What an article must be, checked: one engine for the screen and for the process
// that writes articles_checks. A check runs only if the company has a rule for it.
// This is the only logic both share. No client's words live here: lists, limits
// and "why" come from the rules table.
(function (root, factory) {
  if (typeof module === 'object' && module.exports) module.exports = factory();
  else root.ArticleCore = factory();
})(typeof self !== 'undefined' ? self : this, function () {
'use strict';
const ruleApplies = (r, kind) => r.applies_to.includes('all') || r.applies_to.includes(kind);
const TYPE_OF = { 'intro-links': 'no_links_in_intro', 'para-links': 'one_link_per_paragraph', 'section-links': 'one_link_per_section', 'links-count': 'internal_links_range', 'links-exist': 'links_exist', anchors: 'banned_anchors', competitors: 'no_competitor_links', sources: 'sources_respond', 'title-case': 'title_case', closing: 'closing_not_generic', cta: 'cta_in_closing', faq: 'faq_count', tables: 'no_empty_cells', 'h2-h3': 'heading_then_text', depth: 'paragraph_depth', 'one-line': 'no_one_line_paragraphs', bullets: 'has_bullets', bold: 'has_bold', 'staff-aug': 'staff_aug_phrases', 'intro-stats': 'intro_no_stats', 'no-tables': 'no_tables', 'em-dash': 'no_em_dashes', 'max-words': 'max_words' };
const SMALL = new Set(['a', 'an', 'and', 'as', 'at', 'but', 'by', 'for', 'in', 'of', 'on', 'or', 'the', 'to', 'vs', 'vs.', 'with', 'from', 'is', 'it', 'do', 'how', 'when', 'what', 'who', 'which', 'why', 'you', 'your', 'are', 'be']);
const pathOf = (href) => { try {
    return new URL(href).pathname.replace(/\/?$/, '/');
}
catch {
    return null;
} };
const hostOf = (href) => { try {
    return new URL(href).hostname.replace(/^www\./, '');
}
catch {
    return '';
} };

const sentences = (t) => t.split(/(?<=[.!?])\s+(?=["“A-Z0-9])/).filter((s) => s.trim().length > 0).length;
const count = (text, q) => (q ? (text.toLowerCase().match(new RegExp(q.toLowerCase().replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'g')) || []).length : 0);
function isTitleCase(t) {
    const words = t.replace(/[“”"(),:?!]/g, ' ').split(/\s+/).filter(Boolean);
    return words.every((w, i) => {
        if (!/^[a-z]/.test(w))
            return true;
        return i > 0 && SMALL.has(w);
    });
}
function runChecks({ seo, blocks, notes, site, external, rules, kind = 'blog-buyer', plan, domain = '', limits = {} }) {
    const isInternal = (href) => !!domain && hostOf(href).endsWith(domain);
    const dropHost = (u) => (domain ? u.replace(new RegExp(`^https?://(www\\.)?${domain.replace(/\./g, '\\.')}`), '') : u);
    const out = [];
    const live = rules ? rules.filter((r) => r.status === 'active' && r.kind === 'check' && ruleApplies(r, kind)) : null;
    const num = (type, key, d) => { const v = live?.find((r) => r.check_type === type)?.params[key]; return typeof v === 'number' ? v : d; };
    const list = (type, key, d) => { const v = live?.flatMap((r) => (r.check_type === type && Array.isArray(r.params[key]) ? r.params[key] : [])); return v?.length ? v : d; };
    const banned = list('banned_anchors', 'phrases', []);
    const rivals = list('no_competitor_links', 'domains', []);
    const staff = list('staff_aug_phrases', 'phrases', []);
    const titleMax = Number(limits.titleMax) || 60;
    const descMax = Number(limits.descMax) || 160;
    const descMin = Number(limits.descMin) || 120;
    const kwMin = Number(limits.keywordMin) || 3;
    const linksMin = num('internal_links_range', 'min', 1);
    const linksMax = num('internal_links_range', 'max', 7);
    const faqWant = num('faq_count', 'count', 4);
    const depthMin = num('paragraph_depth', 'min_sentences', 4);
    const maxWords = num('max_words', 'max', 1000);
    const q = seo.mainQuery.trim();
    const firstH2 = blocks.findIndex((b) => b.type === 'heading' && b.level === 2);
    const intro = firstH2 >= 0 ? blocks.slice(0, firstH2) : blocks;
    const introText = intro.filter((b) => b.type !== 'heading').map((b) => b.text).join(' ');
    const bodyText = blocks.map((b) => b.text).join(' ');
    const words = bodyText.trim() ? bodyText.trim().split(/\s+/).length : 0;
    const empty = words === 0;
    // Sections: each H2 with what follows it.
    const sections = [];
    blocks.forEach((b) => {
        if (b.type === 'heading' && b.level === 2)
            sections.push({ head: b, body: [] });
        else if (sections.length)
            sections[sections.length - 1].body.push(b);
    });
    const isFaq = (s) => /^faqs?\b|frequently asked/i.test(s.head.text);
    const closing = [...sections].reverse().find((s) => !isFaq(s));
    // SEO
    const has = [seo.mainQuery && 'keyword', seo.metaTitle && 'title', seo.metaDescription && 'desc', seo.slug && 'slug'].filter(Boolean).length;
    out.push({ id: 'package', group: 'SEO', label: 'Keyword, meta title, meta description y slug', status: has === 4 ? 'pass' : 'fail', detail: has === 4 ? undefined : `Faltan ${4 - has}`, fix: 'Completá lo que falte de keyword principal, meta title, meta description y slug.' });
    const t = seo.metaTitle.length;
    if (t)
        out.push({ id: 'meta-title', group: 'SEO', label: `Meta title de hasta ${titleMax} caracteres`, status: t <= titleMax ? 'pass' : 'warn', detail: `${t} caracteres`, fix: `Acortá el meta title a ${titleMax} caracteres o menos, con "${q}".` });
    const d = seo.metaDescription.length;
    if (d)
        out.push({ id: 'meta-desc', group: 'SEO', label: `Meta description de hasta ${descMax} caracteres`, status: d > descMax ? 'fail' : d < descMin ? 'warn' : 'pass', detail: `${d} caracteres`, fix: `Dejá la meta description entre ${descMin} y ${descMax} caracteres, con la keyword principal.` });
    if (q) {
        const inMeta = count(seo.metaTitle, q) > 0 && count(seo.metaDescription, q) > 0;
        out.push({ id: 'kw-meta', group: 'SEO', label: 'Keyword en meta title y description', status: inMeta ? 'pass' : 'fail', fix: `Usá "${q}" tal cual en el meta title y en la meta description.` });
        out.push({ id: 'kw-intro', group: 'SEO', label: 'Keyword en la introducción', status: count(introText, q) > 0 ? 'pass' : 'fail', blockId: intro.find((b) => b.type === 'paragraph')?.id, fix: `Sumá "${q}" de forma natural en la introducción.` });
        const n = count(bodyText, q);
        out.push({ id: 'kw-count', group: 'SEO', label: `Keyword al menos ${kwMin} veces`, status: n >= kwMin ? 'pass' : 'fail', detail: `${n} ${n === 1 ? 'vez' : 'veces'}`, fix: `Usá "${q}" al menos ${kwMin} veces en total, sin forzarla.` });
    }
    // Links
    const links = blocks.flatMap((b) => b.links);
    const internal = links.filter((l) => isInternal(l.href));
    const ext = links.filter((l) => !isInternal(l.href));
    const introLink = intro.flatMap((b) => b.links)[0];
    out.push({ id: 'intro-links', group: 'Enlaces', label: 'La introducción no tiene enlaces', status: introLink ? 'fail' : 'pass', blockId: introLink?.blockId, fix: 'Sacá los enlaces de la introducción y ubicalos en otra sección.' });
    const twoInParaAll = blocks.filter((b) => b.type === 'paragraph' && b.links.length > 1);
    const twoInPara = twoInParaAll[0];
    out.push({ id: 'para-links', group: 'Enlaces', label: 'Un enlace por párrafo como máximo', status: twoInPara ? 'fail' : 'pass', blockId: twoInPara?.id, fix: 'Dejá un solo enlace en este párrafo.' });
    const heavyAll = sections.filter((s) => !isFaq(s) && s.body.flatMap((b) => b.links).length > 1);
    const heavy = heavyAll[0];
    out.push({ id: 'section-links', group: 'Enlaces', label: 'Un enlace por sección', status: heavy ? 'warn' : 'pass', detail: heavy ? heavy.head.text : undefined, blockId: heavy?.head.id, fix: heavy ? `La sección "${heavy.head.text}" tiene más de un enlace. Dejá uno y repartí el resto.` : undefined });
    out.push({ id: 'links-count', group: 'Enlaces', label: `Entre ${linksMin} y ${linksMax} enlaces internos`, status: internal.length >= linksMin && internal.length <= linksMax ? 'pass' : 'fail', detail: `${internal.length} ${internal.length === 1 ? 'enlace' : 'enlaces'}`, fix: internal.length > linksMax ? `Dejá ${linksMax} enlaces internos como máximo, los más útiles.` : 'Sumá enlaces internos a páginas reales del sitio, repartidos entre secciones.' });
    const dead = site ? internal.filter((l) => { const p = pathOf(l.href); return !p || !site.includes(p); }) : [];
    out.push({
        id: 'links-exist', group: 'Enlaces', label: `Los enlaces internos existen en ${domain || 'el sitio'}`,
        status: !internal.length ? 'pass' : !site ? 'wait' : dead.length ? 'fail' : 'pass',
        detail: !site && internal.length ? 'Comprobando el sitio' : dead.length ? `No está en el sitio: ${dropHost(dead[0].href)}` : undefined,
        blockId: dead[0]?.blockId,
        fix: dead.length ? `El enlace a ${dead[0].href} no está en el sitio. Reemplazalo por una página real.` : undefined,
    });
    const badAnchorAll = links.filter((l) => banned.some((b) => l.text.toLowerCase().includes(b) || l.sentence.toLowerCase().includes(b)));
    const badAnchor = badAnchorAll[0];
    out.push({ id: 'anchors', group: 'Enlaces', label: 'Anchors integrados en la frase', status: badAnchor ? 'fail' : 'pass', detail: badAnchor ? `"${badAnchor.text}"` : undefined, blockId: badAnchor?.blockId, fix: badAnchor ? `Reescribí la frase del enlace "${badAnchor.text}" para que el link sea parte natural del argumento, sin frases como "use this guide" o "read more".` : undefined });
    const rivalAll = links.filter((l) => rivals.includes(hostOf(l.href)));
    const rival = rivalAll[0];
    out.push({ id: 'competitors', group: 'Enlaces', label: 'Sin enlaces a competidores', status: rival ? 'fail' : 'pass', detail: rival ? hostOf(rival.href) : undefined, blockId: rival?.blockId, fix: rival ? `Quitá el enlace a ${hostOf(rival.href)}, es un competidor.` : undefined });
    const brokenExt = ext.filter((l) => { const s = external[l.href]; return s === null || (typeof s === 'number' && s >= 400 && s !== 403 && s !== 429); });
    const pendingExt = ext.some((l) => !(l.href in external));
    out.push({
        id: 'sources', group: 'Enlaces', label: 'Las fuentes externas responden',
        status: !ext.length ? 'pass' : pendingExt ? 'wait' : brokenExt.length ? 'fail' : 'pass',
        detail: pendingExt ? 'Comprobando' : brokenExt.length ? brokenExt[0].href : ext.length ? `${ext.length} comprobadas` : 'No hay fuentes externas',
        blockId: brokenExt[0]?.blockId, fix: brokenExt.length ? `La fuente ${brokenExt[0].href} no responde. Reemplazala por una que funcione.` : undefined,
    });
    // Structure
    const faqStart = blocks.findIndex((b) => b.type === 'heading' && /^faqs?\b|frequently asked/i.test(b.text));
    const badCaseAll = blocks.filter((b, i) => b.type === 'heading' && !(faqStart >= 0 && i > faqStart && b.level === 3) && !isTitleCase(b.text));
    const badCase = badCaseAll[0];
    out.push({ id: 'title-case', group: 'Estructura', label: 'Títulos en Title Case, menos las FAQs', status: badCase ? 'fail' : 'pass', detail: badCase?.text, blockId: badCase?.id, fix: badCase ? `Pasá el título "${badCase.text}" a Title Case.` : undefined });
    const badClose = closing && /conclusion|final thoughts/i.test(closing.head.text);
    out.push({ id: 'closing', group: 'Estructura', label: 'El cierre no se llama "Conclusion"', status: badClose ? 'fail' : 'pass', detail: badClose ? closing.head.text : undefined, blockId: closing?.head.id, fix: 'Poné un título propio a la sección de cierre, relacionado con el tema.' });
    const closeLink = closing ? closing.body.flatMap((b) => b.links)[0] : null;
    out.push({ id: 'cta', group: 'Estructura', label: 'El CTA está en el cierre', status: closeLink ? 'pass' : 'fail', blockId: closing?.head.id, fix: 'Sumá un CTA con enlace en la sección de cierre, hacia una página propia.' });
    const faq = sections.find(isFaq);
    const faqCount = faq ? faq.body.filter((b) => b.type === 'heading').length : 0;
    out.push({ id: 'faq', group: 'Estructura', label: `Sección de FAQs, ${faqWant} preguntas`, status: !faq ? 'fail' : faqCount === faqWant ? 'pass' : 'warn', detail: faq ? `${faqCount} preguntas` : 'No tiene', blockId: faq?.head.id, fix: faq ? `Dejá ${faqWant} FAQs, las más útiles para el lector.` : `Sumá ${faqWant} FAQs al final, antes del cierre.` });
    const emptyTAll = blocks.filter((b) => (b.emptyCells || 0) > 0);
    const emptyT = emptyTAll[0];
    out.push({ id: 'tables', group: 'Estructura', label: 'Sin celdas vacías en las tablas', status: emptyT ? 'fail' : 'pass', detail: emptyT ? `${emptyT.emptyCells} vacías` : undefined, blockId: emptyT?.id, fix: 'Completá las celdas vacías de esta tabla, o quitá la columna si no aporta.' });
    const stackedAll = blocks.filter((b, i) => b.type === 'heading' && b.level === 3 && blocks[i - 1]?.type === 'heading' && blocks[i - 1]?.level === 2 && !/^faqs?\b|frequently asked/i.test(blocks[i - 1].text));
    const stacked = stackedAll[0];
    out.push({ id: 'h2-h3', group: 'Estructura', label: 'Cada título abre con texto', status: stacked ? 'fail' : 'pass', blockId: stacked?.id, fix: 'Sumá un párrafo de introducción entre el título y el subtítulo.' });
    const shallow = sections.filter((s) => !isFaq(s) && !s.body.some((b) => b.type === 'paragraph' && sentences(b.text) >= depthMin));
    out.push({ id: 'depth', group: 'Estructura', label: `Cada sección con un párrafo de ${depthMin} oraciones`, status: shallow.length ? 'warn' : 'pass', detail: shallow.length ? `${shallow.length} ${shallow.length === 1 ? 'sección' : 'secciones'}` : undefined, blockId: shallow[0]?.head.id, fix: shallow[0] ? `Desarrollá la sección "${shallow[0].head.text}" con un párrafo de al menos 4 oraciones.` : undefined });
    const loneAll = blocks.filter((b) => b.type === 'paragraph' && b.text.trim() && !/:\s*$/.test(b.text.trim()) && sentences(b.text) === 1);
    const lone = loneAll[0];
    out.push({ id: 'one-line', group: 'Estructura', label: 'Sin párrafos de una sola oración', status: lone ? 'warn' : 'pass', blockId: lone?.id, fix: 'Desarrollá este párrafo o unilo con el anterior.' });
    const hasList = blocks.some((b) => b.type === 'ul' || b.type === 'ol');
    out.push({ id: 'bullets', group: 'Estructura', label: 'Combina texto y bullets', status: hasList ? 'pass' : 'warn' });
    out.push({ id: 'bold', group: 'Estructura', label: 'Puntos importantes en negrita', status: blocks.some((b) => b.hasBold) ? 'pass' : 'warn' });
    const tableBlockAll = blocks.filter((b) => b.type === 'table');
    const tableBlock = tableBlockAll[0];
    out.push({ id: 'no-tables', group: 'Estructura', label: 'Sin tablas', status: tableBlock ? 'fail' : 'pass', blockId: tableBlock?.id, fix: 'Convertí esta tabla en texto.' });
    const dashAll = blocks.filter((b) => b.text.includes('—'));
    const dash = dashAll[0];
    out.push({ id: 'em-dash', group: 'Estructura', label: 'Sin guiones largos', status: dash ? 'fail' : 'pass', blockId: dash?.id, fix: 'Quitá los guiones largos del artículo.' });
    out.push({ id: 'max-words', group: 'Estructura', label: `Hasta ${maxWords.toLocaleString('es-AR')} palabras`, status: words > maxWords ? 'fail' : 'pass', detail: `${words.toLocaleString('es-AR')} palabras`, fix: `Recortá el artículo a ${maxWords} palabras.` });
    // Message
    const lowAll = blocks.filter((b) => staff.some((p) => b.text.toLowerCase().includes(p)));
    const low = lowAll[0];
    out.push({ id: 'staff-aug', group: 'Mensaje', label: 'No deja mal a staff augmentation', status: low ? 'fail' : 'pass', blockId: low?.id, fix: 'Reescribí este párrafo: no puede dar a entender que staff augmentation sale peor o más caro.' });
    const stat = /[%$]|\b\d{3,}\b|\b\d+[.,]\d+\b/.test(introText);
    out.push({ id: 'intro-stats', group: 'Mensaje', label: 'La introducción no abre con cifras', status: stat ? 'warn' : 'pass', blockId: intro.find((b) => b.type === 'paragraph')?.id, fix: 'Mové las cifras de la introducción a otra sección.' });
    const open = notes.filter((n) => !n.done).length;
    if (notes.length)
        out.push({ id: 'notes', group: 'Mensaje', label: 'Pendientes resueltos', status: open ? 'warn' : 'pass', detail: open ? `${open} sin resolver` : undefined });
    out.push({ id: 'words', group: 'Mensaje', label: 'Extensión', status: words >= 800 ? 'pass' : 'warn', detail: `${words.toLocaleString('es-AR')} palabras` });
    // The plan comes first: what this article promised to do.
    if (plan) {
        const hrefs = links.map((l) => l.href.toLowerCase());
        const missing = (plan.links ?? []).filter((u) => !hrefs.some((h) => h.includes(dropHost(u.toLowerCase()).replace(/\/$/, ''))));
        out.push({ id: 'plan-links', group: 'Mensaje', label: 'Tiene los enlaces del plan', status: missing.length ? 'fail' : 'pass', detail: missing.length ? `Faltan ${missing.length}: ${missing.slice(0, 3).join(', ')}` : undefined, fix: missing.length ? `Sumá estos enlaces del plan donde encajen de forma natural: ${missing.join(', ')}.` : undefined });
        if (plan.wordMax)
            out.push({ id: 'plan-words', group: 'Mensaje', label: `Entre ${plan.wordMin.toLocaleString('es-AR')} y ${plan.wordMax.toLocaleString('es-AR')} palabras`, status: words > plan.wordMax * 1.05 || words < plan.wordMin * 0.95 ? 'fail' : 'pass', detail: `${words.toLocaleString('es-AR')} palabras`, fix: `El artículo tiene ${words} palabras y el plan pide entre ${plan.wordMin} y ${plan.wordMax}. Recortá lo que menos aporta, sin perder datos ni enlaces.` });
        out.push({ id: 'plan-sources', group: 'Enlaces', label: 'Los datos externos tienen su fuente', status: ext.length ? 'pass' : 'fail', detail: ext.length ? undefined : 'No hay fuentes externas', fix: ext.length ? undefined : 'Enlazá los datos externos a la fuente que leíste. Si no pudiste abrirla, decilo en vez de citar el dato sin enlace.' });
        if (plan.unknowns?.length)
            out.push({ id: 'plan-unknowns', group: 'Mensaje', label: 'Datos que falta confirmar', status: 'warn', detail: plan.unknowns.join('; ') });
    }
    // Every case, not only the first: the person and the agent both have to see how many there are.
    const short = (t) => (t.length > 90 ? `${t.slice(0, 89)}…` : t);
    const cases = {
        'para-links': twoInParaAll.map((b) => ({ text: short(b.text), blockId: b.id })),
        'section-links': heavyAll.map((x) => ({ text: x.head.text, blockId: x.head.id })),
        'links-exist': dead.map((l) => ({ text: dropHost(l.href), blockId: l.blockId })),
        anchors: badAnchorAll.map((l) => ({ text: `"${l.text}"`, blockId: l.blockId })),
        competitors: rivalAll.map((l) => ({ text: hostOf(l.href), blockId: l.blockId })),
        sources: brokenExt.map((l) => ({ text: l.href, blockId: l.blockId })),
        'title-case': badCaseAll.map((b) => ({ text: b.text, blockId: b.id })),
        tables: emptyTAll.map((b) => ({ text: `${b.emptyCells} celdas vacías`, blockId: b.id })),
        'h2-h3': stackedAll.map((b) => ({ text: b.text, blockId: b.id })),
        depth: shallow.map((x) => ({ text: x.head.text, blockId: x.head.id })),
        'one-line': loneAll.map((b) => ({ text: short(b.text), blockId: b.id })),
        'no-tables': tableBlockAll.map((b) => ({ text: 'Tabla', blockId: b.id })),
        'em-dash': dashAll.map((b) => ({ text: short(b.text), blockId: b.id })),
        'staff-aug': lowAll.map((b) => ({ text: short(b.text), blockId: b.id })),
    };
    for (const c of out)
        if (c.status !== 'pass' && cases[c.id]?.length)
            c.issues = cases[c.id];
    // Why it matters is what the person said when they asked for the rule.
    for (const c of out) {
        const rule = live && TYPE_OF[c.id] ? live.find((r) => r.check_type === TYPE_OF[c.id]) : null;
        if (rule && rule.source) c.why = rule.source;
    }
    // Only the checks whose rule is on and applies to this type of article. Forbes rules never reach a blog.
    const types = live ? new Set(live.map((r) => r.check_type)) : null;
    const kept = out.filter((c) => {
        const t = TYPE_OF[c.id];
        if (!t)
            return true;
        return !!types && types.has(t);
    });
    return empty ? kept.filter((c) => c.id === 'package') : kept;
}
/** One block of markdown as the checks read it. */
function blockInfo(id, markdown) {
  const md = String(markdown || '').trim();
  const h = /^(#{1,6})\s+/.exec(md);
  const isTable = /^\|.*\|\s*\n\|?\s*:?-{2,}/.test(md);
  const isUl = /^[-*+]\s/.test(md);
  const isOl = /^\d+\.\s/.test(md);
  const links = [];
  const plain = (t) => t.replace(/!\[[^\]]*\]\([^)]*\)/g, '').replace(/\[([^\]]*)\]\([^)]*\)/g, '$1').replace(/(\*\*|__)(.*?)\1/g, '$2').replace(/(^|[^*_])[*_]([^*_\n]+)[*_]/g, '$1$2').replace(/`([^`]*)`/g, '$1');
  const pieces = (isUl || isOl) ? md.split(/\n(?=\s*(?:[-*+]|\d+\.)\s)/) : isTable ? md.split('\n') : [md];
  for (const piece of pieces) {
    for (const m of piece.matchAll(/(?<!!)\[([^\]]*)\]\(\s*<?([^)\s>]+)>?[^)]*\)/g)) {
      links.push({ href: m[2], text: plain(m[1]), blockId: id, sentence: plain(piece.replace(/^\s*(?:[-*+]|\d+\.)\s+/, '').replace(/^\|/, '')).trim() });
    }
  }
  let emptyCells = 0;
  if (isTable) {
    md.split('\n').slice(2).forEach((row) => { row.replace(/^\s*\|/, '').replace(/\|\s*$/, '').split('|').forEach((c) => { if (!c.trim()) emptyCells += 1; }); });
  }
  const text = isTable
    ? md.split('\n').filter((_, i) => i !== 1).map((r) => plain(r).replace(/\|/g, '')).join('')
    : (isUl || isOl) ? pieces.map((p) => plain(p.replace(/^\s*(?:[-*+]|\d+\.)\s+/, ''))).join('')
      : plain(h ? md.slice(h[0].length) : md);
  return {
    id, type: h ? 'heading' : isTable ? 'table' : isUl ? 'ul' : isOl ? 'ol' : 'paragraph', level: h ? h[1].length : undefined,
    text, links, emptyCells, hasBold: /\*\*[^*]+\*\*|__[^_]+__/.test(md),
  };
}

/** One line for an agent: what fails and every place it fails. */
function checkLine(c) {
  const all = c.issues || [];
  return `${c.group}: ${c.label}${all.length > 1 ? ` (${all.length} casos)` : ''}${all.length ? `: ${all.map((x) => x.text + (x.blockId ? ` [block ${x.blockId}]` : '')).join('; ')}` : c.detail ? `. ${c.detail}` : ''}`;
}

return { runChecks, checkLine, blockInfo, ruleApplies };
});
