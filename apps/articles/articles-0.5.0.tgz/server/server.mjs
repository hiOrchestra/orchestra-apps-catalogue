var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// ../shared/articore.js
var require_articore = __commonJS({
  "../shared/articore.js"(exports, module) {
    (function(root, factory) {
      if (typeof module === "object" && module.exports) module.exports = factory();
      else root.ArticleCore = factory();
    })(typeof self !== "undefined" ? self : exports, function() {
      "use strict";
      const ruleApplies = (r, kind) => r.applies_to.includes("all") || r.applies_to.includes(kind);
      const TYPE_OF = { "intro-links": "no_links_in_intro", "para-links": "one_link_per_paragraph", "section-links": "one_link_per_section", "links-count": "internal_links_range", "links-exist": "links_exist", anchors: "banned_anchors", competitors: "no_competitor_links", sources: "sources_respond", "title-case": "title_case", closing: "closing_not_generic", cta: "cta_in_closing", faq: "faq_count", tables: "no_empty_cells", "h2-h3": "heading_then_text", depth: "paragraph_depth", "one-line": "no_one_line_paragraphs", bullets: "has_bullets", bold: "has_bold", "staff-aug": "staff_aug_phrases", "intro-stats": "intro_no_stats", "no-tables": "no_tables", "em-dash": "no_em_dashes", "max-words": "max_words" };
      const SMALL = /* @__PURE__ */ new Set(["a", "an", "and", "as", "at", "but", "by", "for", "in", "of", "on", "or", "the", "to", "vs", "vs.", "with", "from", "is", "it", "do", "how", "when", "what", "who", "which", "why", "you", "your", "are", "be"]);
      const pathOf = (href) => {
        try {
          return new URL(href).pathname.replace(/\/?$/, "/");
        } catch {
          return null;
        }
      };
      const hostOf = (href) => {
        try {
          return new URL(href).hostname.replace(/^www\./, "");
        } catch {
          return "";
        }
      };
      const sentences = (t) => t.split(/(?<=[.!?])\s+(?=["“A-Z0-9])/).filter((s) => s.trim().length > 0).length;
      const count = (text, q) => q ? (text.toLowerCase().match(new RegExp(q.toLowerCase().replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "g")) || []).length : 0;
      function isTitleCase(t) {
        const words = t.replace(/[“”"(),:?!]/g, " ").split(/\s+/).filter(Boolean);
        return words.every((w, i) => {
          if (!/^[a-z]/.test(w))
            return true;
          return i > 0 && SMALL.has(w);
        });
      }
      function runChecks({ seo, blocks, notes: notes2, site, external, rules: rules2, kind = "blog-buyer", plan, domain = "", limits = {} }) {
        const isInternal = (href) => !!domain && hostOf(href).endsWith(domain);
        const dropHost = (u) => domain ? u.replace(new RegExp(`^https?://(www\\.)?${domain.replace(/\./g, "\\.")}`), "") : u;
        const out = [];
        const live = rules2 ? rules2.filter((r) => r.status === "active" && r.kind === "check" && ruleApplies(r, kind)) : null;
        const num = (type, key, d2) => {
          const v = live?.find((r) => r.check_type === type)?.params[key];
          return typeof v === "number" ? v : d2;
        };
        const list2 = (type, key, d2) => {
          const v = live?.flatMap((r) => r.check_type === type && Array.isArray(r.params[key]) ? r.params[key] : []);
          return v?.length ? v : d2;
        };
        const banned = list2("banned_anchors", "phrases", []);
        const rivals = list2("no_competitor_links", "domains", []);
        const staff = list2("staff_aug_phrases", "phrases", []);
        const titleMax = Number(limits.titleMax) || 60;
        const descMax = Number(limits.descMax) || 160;
        const descMin = Number(limits.descMin) || 120;
        const kwMin = Number(limits.keywordMin) || 3;
        const linksMin = num("internal_links_range", "min", 1);
        const linksMax = num("internal_links_range", "max", 7);
        const faqWant = num("faq_count", "count", 4);
        const depthMin = num("paragraph_depth", "min_sentences", 4);
        const maxWords = num("max_words", "max", 1e3);
        const q = seo.mainQuery.trim();
        const firstH2 = blocks.findIndex((b) => b.type === "heading" && b.level === 2);
        const intro = firstH2 >= 0 ? blocks.slice(0, firstH2) : blocks;
        const introText = intro.filter((b) => b.type !== "heading").map((b) => b.text).join(" ");
        const bodyText = blocks.map((b) => b.text).join(" ");
        const words = bodyText.trim() ? bodyText.trim().split(/\s+/).length : 0;
        const empty = words === 0;
        const sections = [];
        blocks.forEach((b) => {
          if (b.type === "heading" && b.level === 2)
            sections.push({ head: b, body: [] });
          else if (sections.length)
            sections[sections.length - 1].body.push(b);
        });
        const isFaq = (s) => /^faqs?\b|frequently asked/i.test(s.head.text);
        const closing = [...sections].reverse().find((s) => !isFaq(s));
        const has = [seo.mainQuery && "keyword", seo.metaTitle && "title", seo.metaDescription && "desc", seo.slug && "slug"].filter(Boolean).length;
        out.push({ id: "package", group: "SEO", label: "Keyword, meta title, meta description y slug", status: has === 4 ? "pass" : "fail", detail: has === 4 ? void 0 : `Faltan ${4 - has}`, fix: "Complet\xE1 lo que falte de keyword principal, meta title, meta description y slug." });
        const t = seo.metaTitle.length;
        if (t)
          out.push({ id: "meta-title", group: "SEO", label: `Meta title de hasta ${titleMax} caracteres`, status: t <= titleMax ? "pass" : "warn", detail: `${t} caracteres`, fix: `Acort\xE1 el meta title a ${titleMax} caracteres o menos, con "${q}".` });
        const d = seo.metaDescription.length;
        if (d)
          out.push({ id: "meta-desc", group: "SEO", label: `Meta description de hasta ${descMax} caracteres`, status: d > descMax ? "fail" : d < descMin ? "warn" : "pass", detail: `${d} caracteres`, fix: `Dej\xE1 la meta description entre ${descMin} y ${descMax} caracteres, con la keyword principal.` });
        if (q) {
          const inMeta = count(seo.metaTitle, q) > 0 && count(seo.metaDescription, q) > 0;
          out.push({ id: "kw-meta", group: "SEO", label: "Keyword en meta title y description", status: inMeta ? "pass" : "fail", fix: `Us\xE1 "${q}" tal cual en el meta title y en la meta description.` });
          out.push({ id: "kw-intro", group: "SEO", label: "Keyword en la introducci\xF3n", status: count(introText, q) > 0 ? "pass" : "fail", blockId: intro.find((b) => b.type === "paragraph")?.id, fix: `Sum\xE1 "${q}" de forma natural en la introducci\xF3n.` });
          const n = count(bodyText, q);
          out.push({ id: "kw-count", group: "SEO", label: `Keyword al menos ${kwMin} veces`, status: n >= kwMin ? "pass" : "fail", detail: `${n} ${n === 1 ? "vez" : "veces"}`, fix: `Us\xE1 "${q}" al menos ${kwMin} veces en total, sin forzarla.` });
        }
        const links = blocks.flatMap((b) => b.links);
        const internal = links.filter((l) => isInternal(l.href));
        const ext = links.filter((l) => !isInternal(l.href));
        const introLink = intro.flatMap((b) => b.links)[0];
        out.push({ id: "intro-links", group: "Enlaces", label: "La introducci\xF3n no tiene enlaces", status: introLink ? "fail" : "pass", blockId: introLink?.blockId, fix: "Sac\xE1 los enlaces de la introducci\xF3n y ubicalos en otra secci\xF3n." });
        const twoInParaAll = blocks.filter((b) => b.type === "paragraph" && b.links.length > 1);
        const twoInPara = twoInParaAll[0];
        out.push({ id: "para-links", group: "Enlaces", label: "Un enlace por p\xE1rrafo como m\xE1ximo", status: twoInPara ? "fail" : "pass", blockId: twoInPara?.id, fix: "Dej\xE1 un solo enlace en este p\xE1rrafo." });
        const heavyAll = sections.filter((s) => !isFaq(s) && s.body.flatMap((b) => b.links).length > 1);
        const heavy = heavyAll[0];
        out.push({ id: "section-links", group: "Enlaces", label: "Un enlace por secci\xF3n", status: heavy ? "warn" : "pass", detail: heavy ? heavy.head.text : void 0, blockId: heavy?.head.id, fix: heavy ? `La secci\xF3n "${heavy.head.text}" tiene m\xE1s de un enlace. Dej\xE1 uno y repart\xED el resto.` : void 0 });
        out.push({ id: "links-count", group: "Enlaces", label: `Entre ${linksMin} y ${linksMax} enlaces internos`, status: internal.length >= linksMin && internal.length <= linksMax ? "pass" : "fail", detail: `${internal.length} ${internal.length === 1 ? "enlace" : "enlaces"}`, fix: internal.length > linksMax ? `Dej\xE1 ${linksMax} enlaces internos como m\xE1ximo, los m\xE1s \xFAtiles.` : "Sum\xE1 enlaces internos a p\xE1ginas reales del sitio, repartidos entre secciones." });
        const dead = site ? internal.filter((l) => {
          const p = pathOf(l.href);
          return !p || !site.includes(p);
        }) : [];
        out.push({
          id: "links-exist",
          group: "Enlaces",
          label: `Los enlaces internos existen en ${domain || "el sitio"}`,
          status: !internal.length ? "pass" : !site ? "wait" : dead.length ? "fail" : "pass",
          detail: !site && internal.length ? "Comprobando el sitio" : dead.length ? `No est\xE1 en el sitio: ${dropHost(dead[0].href)}` : void 0,
          blockId: dead[0]?.blockId,
          fix: dead.length ? `El enlace a ${dead[0].href} no est\xE1 en el sitio. Reemplazalo por una p\xE1gina real.` : void 0
        });
        const badAnchorAll = links.filter((l) => banned.some((b) => l.text.toLowerCase().includes(b) || l.sentence.toLowerCase().includes(b)));
        const badAnchor = badAnchorAll[0];
        out.push({ id: "anchors", group: "Enlaces", label: "Anchors integrados en la frase", status: badAnchor ? "fail" : "pass", detail: badAnchor ? `"${badAnchor.text}"` : void 0, blockId: badAnchor?.blockId, fix: badAnchor ? `Reescrib\xED la frase del enlace "${badAnchor.text}" para que el link sea parte natural del argumento, sin frases como "use this guide" o "read more".` : void 0 });
        const rivalAll = links.filter((l) => rivals.includes(hostOf(l.href)));
        const rival = rivalAll[0];
        out.push({ id: "competitors", group: "Enlaces", label: "Sin enlaces a competidores", status: rival ? "fail" : "pass", detail: rival ? hostOf(rival.href) : void 0, blockId: rival?.blockId, fix: rival ? `Quit\xE1 el enlace a ${hostOf(rival.href)}, es un competidor.` : void 0 });
        const brokenExt = ext.filter((l) => {
          const s = external[l.href];
          return s === null || typeof s === "number" && s >= 400 && s !== 403 && s !== 429;
        });
        const pendingExt = ext.some((l) => !(l.href in external));
        out.push({
          id: "sources",
          group: "Enlaces",
          label: "Las fuentes externas responden",
          status: !ext.length ? "pass" : pendingExt ? "wait" : brokenExt.length ? "fail" : "pass",
          detail: pendingExt ? "Comprobando" : brokenExt.length ? brokenExt[0].href : ext.length ? `${ext.length} comprobadas` : "No hay fuentes externas",
          blockId: brokenExt[0]?.blockId,
          fix: brokenExt.length ? `La fuente ${brokenExt[0].href} no responde. Reemplazala por una que funcione.` : void 0
        });
        const faqStart = blocks.findIndex((b) => b.type === "heading" && /^faqs?\b|frequently asked/i.test(b.text));
        const badCaseAll = blocks.filter((b, i) => b.type === "heading" && !(faqStart >= 0 && i > faqStart && b.level === 3) && !isTitleCase(b.text));
        const badCase = badCaseAll[0];
        out.push({ id: "title-case", group: "Estructura", label: "T\xEDtulos en Title Case, menos las FAQs", status: badCase ? "fail" : "pass", detail: badCase?.text, blockId: badCase?.id, fix: badCase ? `Pas\xE1 el t\xEDtulo "${badCase.text}" a Title Case.` : void 0 });
        const badClose = closing && /conclusion|final thoughts/i.test(closing.head.text);
        out.push({ id: "closing", group: "Estructura", label: 'El cierre no se llama "Conclusion"', status: badClose ? "fail" : "pass", detail: badClose ? closing.head.text : void 0, blockId: closing?.head.id, fix: "Pon\xE9 un t\xEDtulo propio a la secci\xF3n de cierre, relacionado con el tema." });
        const closeLink = closing ? closing.body.flatMap((b) => b.links)[0] : null;
        out.push({ id: "cta", group: "Estructura", label: "El CTA est\xE1 en el cierre", status: closeLink ? "pass" : "fail", blockId: closing?.head.id, fix: "Sum\xE1 un CTA con enlace en la secci\xF3n de cierre, hacia una p\xE1gina propia." });
        const faq = sections.find(isFaq);
        const faqCount = faq ? faq.body.filter((b) => b.type === "heading").length : 0;
        out.push({ id: "faq", group: "Estructura", label: `Secci\xF3n de FAQs, ${faqWant} preguntas`, status: !faq ? "fail" : faqCount === faqWant ? "pass" : "warn", detail: faq ? `${faqCount} preguntas` : "No tiene", blockId: faq?.head.id, fix: faq ? `Dej\xE1 ${faqWant} FAQs, las m\xE1s \xFAtiles para el lector.` : `Sum\xE1 ${faqWant} FAQs al final, antes del cierre.` });
        const emptyTAll = blocks.filter((b) => (b.emptyCells || 0) > 0);
        const emptyT = emptyTAll[0];
        out.push({ id: "tables", group: "Estructura", label: "Sin celdas vac\xEDas en las tablas", status: emptyT ? "fail" : "pass", detail: emptyT ? `${emptyT.emptyCells} vac\xEDas` : void 0, blockId: emptyT?.id, fix: "Complet\xE1 las celdas vac\xEDas de esta tabla, o quit\xE1 la columna si no aporta." });
        const stackedAll = blocks.filter((b, i) => b.type === "heading" && b.level === 3 && blocks[i - 1]?.type === "heading" && blocks[i - 1]?.level === 2 && !/^faqs?\b|frequently asked/i.test(blocks[i - 1].text));
        const stacked = stackedAll[0];
        out.push({ id: "h2-h3", group: "Estructura", label: "Cada t\xEDtulo abre con texto", status: stacked ? "fail" : "pass", blockId: stacked?.id, fix: "Sum\xE1 un p\xE1rrafo de introducci\xF3n entre el t\xEDtulo y el subt\xEDtulo." });
        const shallow = sections.filter((s) => !isFaq(s) && !s.body.some((b) => b.type === "paragraph" && sentences(b.text) >= depthMin));
        out.push({ id: "depth", group: "Estructura", label: `Cada secci\xF3n con un p\xE1rrafo de ${depthMin} oraciones`, status: shallow.length ? "warn" : "pass", detail: shallow.length ? `${shallow.length} ${shallow.length === 1 ? "secci\xF3n" : "secciones"}` : void 0, blockId: shallow[0]?.head.id, fix: shallow[0] ? `Desarroll\xE1 la secci\xF3n "${shallow[0].head.text}" con un p\xE1rrafo de al menos 4 oraciones.` : void 0 });
        const loneAll = blocks.filter((b) => b.type === "paragraph" && b.text.trim() && !/:\s*$/.test(b.text.trim()) && sentences(b.text) === 1);
        const lone = loneAll[0];
        out.push({ id: "one-line", group: "Estructura", label: "Sin p\xE1rrafos de una sola oraci\xF3n", status: lone ? "warn" : "pass", blockId: lone?.id, fix: "Desarroll\xE1 este p\xE1rrafo o unilo con el anterior." });
        const hasList = blocks.some((b) => b.type === "ul" || b.type === "ol");
        out.push({ id: "bullets", group: "Estructura", label: "Combina texto y bullets", status: hasList ? "pass" : "warn" });
        out.push({ id: "bold", group: "Estructura", label: "Puntos importantes en negrita", status: blocks.some((b) => b.hasBold) ? "pass" : "warn" });
        const tableBlockAll = blocks.filter((b) => b.type === "table");
        const tableBlock = tableBlockAll[0];
        out.push({ id: "no-tables", group: "Estructura", label: "Sin tablas", status: tableBlock ? "fail" : "pass", blockId: tableBlock?.id, fix: "Convert\xED esta tabla en texto." });
        const dashAll = blocks.filter((b) => b.text.includes("\u2014"));
        const dash = dashAll[0];
        out.push({ id: "em-dash", group: "Estructura", label: "Sin guiones largos", status: dash ? "fail" : "pass", blockId: dash?.id, fix: "Quit\xE1 los guiones largos del art\xEDculo." });
        out.push({ id: "max-words", group: "Estructura", label: `Hasta ${maxWords.toLocaleString("es-AR")} palabras`, status: words > maxWords ? "fail" : "pass", detail: `${words.toLocaleString("es-AR")} palabras`, fix: `Recort\xE1 el art\xEDculo a ${maxWords} palabras.` });
        const lowAll = blocks.filter((b) => staff.some((p) => b.text.toLowerCase().includes(p)));
        const low = lowAll[0];
        out.push({ id: "staff-aug", group: "Mensaje", label: "No deja mal a staff augmentation", status: low ? "fail" : "pass", blockId: low?.id, fix: "Reescrib\xED este p\xE1rrafo: no puede dar a entender que staff augmentation sale peor o m\xE1s caro." });
        const stat = /[%$]|\b\d{3,}\b|\b\d+[.,]\d+\b/.test(introText);
        out.push({ id: "intro-stats", group: "Mensaje", label: "La introducci\xF3n no abre con cifras", status: stat ? "warn" : "pass", blockId: intro.find((b) => b.type === "paragraph")?.id, fix: "Mov\xE9 las cifras de la introducci\xF3n a otra secci\xF3n." });
        const open = notes2.filter((n) => !n.done).length;
        if (notes2.length)
          out.push({ id: "notes", group: "Mensaje", label: "Pendientes resueltos", status: open ? "warn" : "pass", detail: open ? `${open} sin resolver` : void 0 });
        out.push({ id: "words", group: "Mensaje", label: "Extensi\xF3n", status: words >= 800 ? "pass" : "warn", detail: `${words.toLocaleString("es-AR")} palabras` });
        if (plan) {
          const hrefs = links.map((l) => l.href.toLowerCase());
          const missing = (plan.links ?? []).filter((u) => !hrefs.some((h) => h.includes(dropHost(u.toLowerCase()).replace(/\/$/, ""))));
          out.push({ id: "plan-links", group: "Mensaje", label: "Tiene los enlaces del plan", status: missing.length ? "fail" : "pass", detail: missing.length ? `Faltan ${missing.length}: ${missing.slice(0, 3).join(", ")}` : void 0, fix: missing.length ? `Sum\xE1 estos enlaces del plan donde encajen de forma natural: ${missing.join(", ")}.` : void 0 });
          if (plan.wordMax)
            out.push({ id: "plan-words", group: "Mensaje", label: `Entre ${plan.wordMin.toLocaleString("es-AR")} y ${plan.wordMax.toLocaleString("es-AR")} palabras`, status: words > plan.wordMax * 1.05 || words < plan.wordMin * 0.95 ? "fail" : "pass", detail: `${words.toLocaleString("es-AR")} palabras`, fix: `El art\xEDculo tiene ${words} palabras y el plan pide entre ${plan.wordMin} y ${plan.wordMax}. Recort\xE1 lo que menos aporta, sin perder datos ni enlaces.` });
          out.push({ id: "plan-sources", group: "Enlaces", label: "Los datos externos tienen su fuente", status: ext.length ? "pass" : "fail", detail: ext.length ? void 0 : "No hay fuentes externas", fix: ext.length ? void 0 : "Enlaz\xE1 los datos externos a la fuente que le\xEDste. Si no pudiste abrirla, decilo en vez de citar el dato sin enlace." });
          if (plan.unknowns?.length)
            out.push({ id: "plan-unknowns", group: "Mensaje", label: "Datos que falta confirmar", status: "warn", detail: plan.unknowns.join("; ") });
        }
        const short = (t2) => t2.length > 90 ? `${t2.slice(0, 89)}\u2026` : t2;
        const cases = {
          "para-links": twoInParaAll.map((b) => ({ text: short(b.text), blockId: b.id })),
          "section-links": heavyAll.map((x) => ({ text: x.head.text, blockId: x.head.id })),
          "links-exist": dead.map((l) => ({ text: dropHost(l.href), blockId: l.blockId })),
          anchors: badAnchorAll.map((l) => ({ text: `"${l.text}"`, blockId: l.blockId })),
          competitors: rivalAll.map((l) => ({ text: hostOf(l.href), blockId: l.blockId })),
          sources: brokenExt.map((l) => ({ text: l.href, blockId: l.blockId })),
          "title-case": badCaseAll.map((b) => ({ text: b.text, blockId: b.id })),
          tables: emptyTAll.map((b) => ({ text: `${b.emptyCells} celdas vac\xEDas`, blockId: b.id })),
          "h2-h3": stackedAll.map((b) => ({ text: b.text, blockId: b.id })),
          depth: shallow.map((x) => ({ text: x.head.text, blockId: x.head.id })),
          "one-line": loneAll.map((b) => ({ text: short(b.text), blockId: b.id })),
          "no-tables": tableBlockAll.map((b) => ({ text: "Tabla", blockId: b.id })),
          "em-dash": dashAll.map((b) => ({ text: short(b.text), blockId: b.id })),
          "staff-aug": lowAll.map((b) => ({ text: short(b.text), blockId: b.id }))
        };
        for (const c of out)
          if (c.status !== "pass" && cases[c.id]?.length)
            c.issues = cases[c.id];
        for (const c of out) {
          const rule = live && TYPE_OF[c.id] ? live.find((r) => r.check_type === TYPE_OF[c.id]) : null;
          if (rule && rule.source) c.why = rule.source;
        }
        const types = live ? new Set(live.map((r) => r.check_type)) : null;
        const kept = out.filter((c) => {
          const t2 = TYPE_OF[c.id];
          if (!t2)
            return true;
          return !!types && types.has(t2);
        });
        return empty ? kept.filter((c) => c.id === "package") : kept;
      }
      function blockInfo(id, markdown) {
        const md = String(markdown || "").trim();
        const h = /^(#{1,6})\s+/.exec(md);
        const isTable = /^\|.*\|\s*\n\|?\s*:?-{2,}/.test(md);
        const isUl = /^[-*+]\s/.test(md);
        const isOl = /^\d+\.\s/.test(md);
        const links = [];
        const plain = (t) => t.replace(/!\[[^\]]*\]\([^)]*\)/g, "").replace(/\[([^\]]*)\]\([^)]*\)/g, "$1").replace(/(\*\*|__)(.*?)\1/g, "$2").replace(/(^|[^*_])[*_]([^*_\n]+)[*_]/g, "$1$2").replace(/`([^`]*)`/g, "$1");
        const pieces = isUl || isOl ? md.split(/\n(?=\s*(?:[-*+]|\d+\.)\s)/) : isTable ? md.split("\n") : [md];
        for (const piece of pieces) {
          for (const m of piece.matchAll(/(?<!!)\[([^\]]*)\]\(\s*<?([^)\s>]+)>?[^)]*\)/g)) {
            links.push({ href: m[2], text: plain(m[1]), blockId: id, sentence: plain(piece.replace(/^\s*(?:[-*+]|\d+\.)\s+/, "").replace(/^\|/, "")).trim() });
          }
        }
        let emptyCells = 0;
        if (isTable) {
          md.split("\n").slice(2).forEach((row) => {
            row.replace(/^\s*\|/, "").replace(/\|\s*$/, "").split("|").forEach((c) => {
              if (!c.trim()) emptyCells += 1;
            });
          });
        }
        const text = isTable ? md.split("\n").filter((_, i) => i !== 1).map((r) => plain(r).replace(/\|/g, "")).join("") : isUl || isOl ? pieces.map((p) => plain(p.replace(/^\s*(?:[-*+]|\d+\.)\s+/, ""))).join("") : plain(h ? md.slice(h[0].length) : md);
        return {
          id,
          type: h ? "heading" : isTable ? "table" : isUl ? "ul" : isOl ? "ol" : "paragraph",
          level: h ? h[1].length : void 0,
          text,
          links,
          emptyCells,
          hasBold: /\*\*[^*]+\*\*|__[^_]+__/.test(md)
        };
      }
      function checkLine(c) {
        const all = c.issues || [];
        return `${c.group}: ${c.label}${all.length > 1 ? ` (${all.length} casos)` : ""}${all.length ? `: ${all.map((x) => x.text + (x.blockId ? ` [block ${x.blockId}]` : "")).join("; ")}` : c.detail ? `. ${c.detail}` : ""}`;
      }
      return { runChecks, checkLine, blockInfo, ruleApplies };
    });
  }
});

// node_modules/@hono/node-server/dist/index.mjs
import { createServer as createServerHTTP } from "http";
import { Http2ServerRequest as Http2ServerRequest2 } from "http2";
import { Http2ServerRequest } from "http2";
import { Readable } from "stream";
import crypto from "crypto";
var RequestError = class extends Error {
  constructor(message, options) {
    super(message, options);
    this.name = "RequestError";
  }
};
var toRequestError = (e) => {
  if (e instanceof RequestError) {
    return e;
  }
  return new RequestError(e.message, { cause: e });
};
var GlobalRequest = global.Request;
var Request2 = class extends GlobalRequest {
  constructor(input, options) {
    if (typeof input === "object" && getRequestCache in input) {
      input = input[getRequestCache]();
    }
    if (typeof options?.body?.getReader !== "undefined") {
      ;
      options.duplex ??= "half";
    }
    super(input, options);
  }
};
var wrapBodyStream = Symbol("wrapBodyStream");
var newRequestFromIncoming = (method, url, incoming, abortController) => {
  const headerRecord = [];
  const rawHeaders = incoming.rawHeaders;
  for (let i = 0; i < rawHeaders.length; i += 2) {
    const { [i]: key, [i + 1]: value } = rawHeaders;
    if (key.charCodeAt(0) !== /*:*/
    58) {
      headerRecord.push([key, value]);
    }
  }
  const init = {
    method,
    headers: headerRecord,
    signal: abortController.signal
  };
  if (method === "TRACE") {
    init.method = "GET";
    const req = new Request2(url, init);
    Object.defineProperty(req, "method", {
      get() {
        return "TRACE";
      }
    });
    return req;
  }
  if (!(method === "GET" || method === "HEAD")) {
    if ("rawBody" in incoming && incoming.rawBody instanceof Buffer) {
      init.body = new ReadableStream({
        start(controller) {
          controller.enqueue(incoming.rawBody);
          controller.close();
        }
      });
    } else if (incoming[wrapBodyStream]) {
      let reader;
      init.body = new ReadableStream({
        async pull(controller) {
          try {
            reader ||= Readable.toWeb(incoming).getReader();
            const { done, value } = await reader.read();
            if (done) {
              controller.close();
            } else {
              controller.enqueue(value);
            }
          } catch (error) {
            controller.error(error);
          }
        }
      });
    } else {
      init.body = Readable.toWeb(incoming);
    }
  }
  return new Request2(url, init);
};
var getRequestCache = Symbol("getRequestCache");
var requestCache = Symbol("requestCache");
var incomingKey = Symbol("incomingKey");
var urlKey = Symbol("urlKey");
var abortControllerKey = Symbol("abortControllerKey");
var getAbortController = Symbol("getAbortController");
var requestPrototype = {
  get method() {
    return this[incomingKey].method || "GET";
  },
  get url() {
    return this[urlKey];
  },
  [getAbortController]() {
    this[getRequestCache]();
    return this[abortControllerKey];
  },
  [getRequestCache]() {
    this[abortControllerKey] ||= new AbortController();
    return this[requestCache] ||= newRequestFromIncoming(
      this.method,
      this[urlKey],
      this[incomingKey],
      this[abortControllerKey]
    );
  }
};
[
  "body",
  "bodyUsed",
  "cache",
  "credentials",
  "destination",
  "headers",
  "integrity",
  "mode",
  "redirect",
  "referrer",
  "referrerPolicy",
  "signal",
  "keepalive"
].forEach((k) => {
  Object.defineProperty(requestPrototype, k, {
    get() {
      return this[getRequestCache]()[k];
    }
  });
});
["arrayBuffer", "blob", "clone", "formData", "json", "text"].forEach((k) => {
  Object.defineProperty(requestPrototype, k, {
    value: function() {
      return this[getRequestCache]()[k]();
    }
  });
});
Object.setPrototypeOf(requestPrototype, Request2.prototype);
var newRequest = (incoming, defaultHostname) => {
  const req = Object.create(requestPrototype);
  req[incomingKey] = incoming;
  const incomingUrl = incoming.url || "";
  if (incomingUrl[0] !== "/" && // short-circuit for performance. most requests are relative URL.
  (incomingUrl.startsWith("http://") || incomingUrl.startsWith("https://"))) {
    if (incoming instanceof Http2ServerRequest) {
      throw new RequestError("Absolute URL for :path is not allowed in HTTP/2");
    }
    try {
      const url2 = new URL(incomingUrl);
      req[urlKey] = url2.href;
    } catch (e) {
      throw new RequestError("Invalid absolute URL", { cause: e });
    }
    return req;
  }
  const host = (incoming instanceof Http2ServerRequest ? incoming.authority : incoming.headers.host) || defaultHostname;
  if (!host) {
    throw new RequestError("Missing host header");
  }
  let scheme;
  if (incoming instanceof Http2ServerRequest) {
    scheme = incoming.scheme;
    if (!(scheme === "http" || scheme === "https")) {
      throw new RequestError("Unsupported scheme");
    }
  } else {
    scheme = incoming.socket && incoming.socket.encrypted ? "https" : "http";
  }
  const url = new URL(`${scheme}://${host}${incomingUrl}`);
  if (url.hostname.length !== host.length && url.hostname !== host.replace(/:\d+$/, "")) {
    throw new RequestError("Invalid host header");
  }
  req[urlKey] = url.href;
  return req;
};
var responseCache = Symbol("responseCache");
var getResponseCache = Symbol("getResponseCache");
var cacheKey = Symbol("cache");
var GlobalResponse = global.Response;
var Response2 = class _Response {
  #body;
  #init;
  [getResponseCache]() {
    delete this[cacheKey];
    return this[responseCache] ||= new GlobalResponse(this.#body, this.#init);
  }
  constructor(body, init) {
    let headers;
    this.#body = body;
    if (init instanceof _Response) {
      const cachedGlobalResponse = init[responseCache];
      if (cachedGlobalResponse) {
        this.#init = cachedGlobalResponse;
        this[getResponseCache]();
        return;
      } else {
        this.#init = init.#init;
        headers = new Headers(init.#init.headers);
      }
    } else {
      this.#init = init;
    }
    if (typeof body === "string" || typeof body?.getReader !== "undefined" || body instanceof Blob || body instanceof Uint8Array) {
      headers ||= init?.headers || { "content-type": "text/plain; charset=UTF-8" };
      this[cacheKey] = [init?.status || 200, body, headers];
    }
  }
  get headers() {
    const cache = this[cacheKey];
    if (cache) {
      if (!(cache[2] instanceof Headers)) {
        cache[2] = new Headers(cache[2]);
      }
      return cache[2];
    }
    return this[getResponseCache]().headers;
  }
  get status() {
    return this[cacheKey]?.[0] ?? this[getResponseCache]().status;
  }
  get ok() {
    const status = this.status;
    return status >= 200 && status < 300;
  }
};
["body", "bodyUsed", "redirected", "statusText", "trailers", "type", "url"].forEach((k) => {
  Object.defineProperty(Response2.prototype, k, {
    get() {
      return this[getResponseCache]()[k];
    }
  });
});
["arrayBuffer", "blob", "clone", "formData", "json", "text"].forEach((k) => {
  Object.defineProperty(Response2.prototype, k, {
    value: function() {
      return this[getResponseCache]()[k]();
    }
  });
});
Object.setPrototypeOf(Response2, GlobalResponse);
Object.setPrototypeOf(Response2.prototype, GlobalResponse.prototype);
async function readWithoutBlocking(readPromise) {
  return Promise.race([readPromise, Promise.resolve().then(() => Promise.resolve(void 0))]);
}
function writeFromReadableStreamDefaultReader(reader, writable, currentReadPromise) {
  const handleError = () => {
  };
  writable.on("error", handleError);
  (currentReadPromise ?? reader.read()).then(flow, handleStreamError);
  return reader.closed.finally(() => {
    writable.off("error", handleError);
  });
  function handleStreamError(error) {
    if (error) {
      writable.destroy(error);
    }
  }
  function onDrain() {
    reader.read().then(flow, handleStreamError);
  }
  function flow({ done, value }) {
    try {
      if (done) {
        writable.end();
      } else if (!writable.write(value)) {
        writable.once("drain", onDrain);
      } else {
        return reader.read().then(flow, handleStreamError);
      }
    } catch (e) {
      handleStreamError(e);
    }
  }
}
function writeFromReadableStream(stream, writable) {
  if (stream.locked) {
    throw new TypeError("ReadableStream is locked.");
  } else if (writable.destroyed) {
    return;
  }
  return writeFromReadableStreamDefaultReader(stream.getReader(), writable);
}
var buildOutgoingHttpHeaders = (headers) => {
  const res = {};
  if (!(headers instanceof Headers)) {
    headers = new Headers(headers ?? void 0);
  }
  const cookies = [];
  for (const [k, v] of headers) {
    if (k === "set-cookie") {
      cookies.push(v);
    } else {
      res[k] = v;
    }
  }
  if (cookies.length > 0) {
    res["set-cookie"] = cookies;
  }
  res["content-type"] ??= "text/plain; charset=UTF-8";
  return res;
};
var X_ALREADY_SENT = "x-hono-already-sent";
var webFetch = global.fetch;
if (typeof global.crypto === "undefined") {
  global.crypto = crypto;
}
global.fetch = (info, init) => {
  init = {
    // Disable compression handling so people can return the result of a fetch
    // directly in the loader without messing with the Content-Encoding header.
    compress: false,
    ...init
  };
  return webFetch(info, init);
};
var outgoingEnded = Symbol("outgoingEnded");
var handleRequestError = () => new Response(null, {
  status: 400
});
var handleFetchError = (e) => new Response(null, {
  status: e instanceof Error && (e.name === "TimeoutError" || e.constructor.name === "TimeoutError") ? 504 : 500
});
var handleResponseError = (e, outgoing) => {
  const err = e instanceof Error ? e : new Error("unknown error", { cause: e });
  if (err.code === "ERR_STREAM_PREMATURE_CLOSE") {
    console.info("The user aborted a request.");
  } else {
    console.error(e);
    if (!outgoing.headersSent) {
      outgoing.writeHead(500, { "Content-Type": "text/plain" });
    }
    outgoing.end(`Error: ${err.message}`);
    outgoing.destroy(err);
  }
};
var flushHeaders = (outgoing) => {
  if ("flushHeaders" in outgoing && outgoing.writable) {
    outgoing.flushHeaders();
  }
};
var responseViaCache = async (res, outgoing) => {
  let [status, body, header] = res[cacheKey];
  if (header instanceof Headers) {
    header = buildOutgoingHttpHeaders(header);
  }
  if (typeof body === "string") {
    header["Content-Length"] = Buffer.byteLength(body);
  } else if (body instanceof Uint8Array) {
    header["Content-Length"] = body.byteLength;
  } else if (body instanceof Blob) {
    header["Content-Length"] = body.size;
  }
  outgoing.writeHead(status, header);
  if (typeof body === "string" || body instanceof Uint8Array) {
    outgoing.end(body);
  } else if (body instanceof Blob) {
    outgoing.end(new Uint8Array(await body.arrayBuffer()));
  } else {
    flushHeaders(outgoing);
    await writeFromReadableStream(body, outgoing)?.catch(
      (e) => handleResponseError(e, outgoing)
    );
  }
  ;
  outgoing[outgoingEnded]?.();
};
var responseViaResponseObject = async (res, outgoing, options = {}) => {
  if (res instanceof Promise) {
    if (options.errorHandler) {
      try {
        res = await res;
      } catch (err) {
        const errRes = await options.errorHandler(err);
        if (!errRes) {
          return;
        }
        res = errRes;
      }
    } else {
      res = await res.catch(handleFetchError);
    }
  }
  if (cacheKey in res) {
    return responseViaCache(res, outgoing);
  }
  const resHeaderRecord = buildOutgoingHttpHeaders(res.headers);
  if (res.body) {
    const reader = res.body.getReader();
    const values = [];
    let done = false;
    let currentReadPromise = void 0;
    if (resHeaderRecord["transfer-encoding"] !== "chunked") {
      let maxReadCount = 2;
      for (let i = 0; i < maxReadCount; i++) {
        currentReadPromise ||= reader.read();
        const chunk = await readWithoutBlocking(currentReadPromise).catch((e) => {
          console.error(e);
          done = true;
        });
        if (!chunk) {
          if (i === 1) {
            await new Promise((resolve) => setTimeout(resolve));
            maxReadCount = 3;
            continue;
          }
          break;
        }
        currentReadPromise = void 0;
        if (chunk.value) {
          values.push(chunk.value);
        }
        if (chunk.done) {
          done = true;
          break;
        }
      }
      if (done && !("content-length" in resHeaderRecord)) {
        resHeaderRecord["content-length"] = values.reduce((acc, value) => acc + value.length, 0);
      }
    }
    outgoing.writeHead(res.status, resHeaderRecord);
    values.forEach((value) => {
      ;
      outgoing.write(value);
    });
    if (done) {
      outgoing.end();
    } else {
      if (values.length === 0) {
        flushHeaders(outgoing);
      }
      await writeFromReadableStreamDefaultReader(reader, outgoing, currentReadPromise);
    }
  } else if (resHeaderRecord[X_ALREADY_SENT]) {
  } else {
    outgoing.writeHead(res.status, resHeaderRecord);
    outgoing.end();
  }
  ;
  outgoing[outgoingEnded]?.();
};
var getRequestListener = (fetchCallback, options = {}) => {
  const autoCleanupIncoming = options.autoCleanupIncoming ?? true;
  if (options.overrideGlobalObjects !== false && global.Request !== Request2) {
    Object.defineProperty(global, "Request", {
      value: Request2
    });
    Object.defineProperty(global, "Response", {
      value: Response2
    });
  }
  return async (incoming, outgoing) => {
    let res, req;
    try {
      req = newRequest(incoming, options.hostname);
      let incomingEnded = !autoCleanupIncoming || incoming.method === "GET" || incoming.method === "HEAD";
      if (!incomingEnded) {
        ;
        incoming[wrapBodyStream] = true;
        incoming.on("end", () => {
          incomingEnded = true;
        });
        if (incoming instanceof Http2ServerRequest2) {
          ;
          outgoing[outgoingEnded] = () => {
            if (!incomingEnded) {
              setTimeout(() => {
                if (!incomingEnded) {
                  setTimeout(() => {
                    incoming.destroy();
                    outgoing.destroy();
                  });
                }
              });
            }
          };
        }
      }
      outgoing.on("close", () => {
        const abortController = req[abortControllerKey];
        if (abortController) {
          if (incoming.errored) {
            req[abortControllerKey].abort(incoming.errored.toString());
          } else if (!outgoing.writableFinished) {
            req[abortControllerKey].abort("Client connection prematurely closed.");
          }
        }
        if (!incomingEnded) {
          setTimeout(() => {
            if (!incomingEnded) {
              setTimeout(() => {
                incoming.destroy();
              });
            }
          });
        }
      });
      res = fetchCallback(req, { incoming, outgoing });
      if (cacheKey in res) {
        return responseViaCache(res, outgoing);
      }
    } catch (e) {
      if (!res) {
        if (options.errorHandler) {
          res = await options.errorHandler(req ? e : toRequestError(e));
          if (!res) {
            return;
          }
        } else if (!req) {
          res = handleRequestError();
        } else {
          res = handleFetchError(e);
        }
      } else {
        return handleResponseError(e, outgoing);
      }
    }
    try {
      return await responseViaResponseObject(res, outgoing, options);
    } catch (e) {
      return handleResponseError(e, outgoing);
    }
  };
};
var createAdaptorServer = (options) => {
  const fetchCallback = options.fetch;
  const requestListener = getRequestListener(fetchCallback, {
    hostname: options.hostname,
    overrideGlobalObjects: options.overrideGlobalObjects,
    autoCleanupIncoming: options.autoCleanupIncoming
  });
  const createServer = options.createServer || createServerHTTP;
  const server = createServer(options.serverOptions || {}, requestListener);
  return server;
};
var serve = (options, listeningListener) => {
  const server = createAdaptorServer(options);
  server.listen(options?.port ?? 3e3, options.hostname, () => {
    const serverInfo = server.address();
    listeningListener && listeningListener(serverInfo);
  });
  return server;
};

// node_modules/hono/dist/compose.js
var compose = (middleware, onError, onNotFound) => {
  return (context, next) => {
    let index = -1;
    return dispatch(0);
    async function dispatch(i) {
      if (i <= index) {
        throw new Error("next() called multiple times");
      }
      index = i;
      let res;
      let isError = false;
      let handler;
      if (middleware[i]) {
        handler = middleware[i][0][0];
        context.req.routeIndex = i;
      } else {
        handler = i === middleware.length && next || void 0;
      }
      if (handler) {
        try {
          res = await handler(context, () => dispatch(i + 1));
        } catch (err) {
          if (err instanceof Error && onError) {
            context.error = err;
            res = await onError(err, context);
            isError = true;
          } else {
            throw err;
          }
        }
      } else {
        if (context.finalized === false && onNotFound) {
          res = await onNotFound(context);
        }
      }
      if (res && (context.finalized === false || isError)) {
        context.res = res;
      }
      return context;
    }
  };
};

// node_modules/hono/dist/request/constants.js
var GET_MATCH_RESULT = /* @__PURE__ */ Symbol();

// node_modules/hono/dist/utils/body.js
var parseBody = async (request, options = /* @__PURE__ */ Object.create(null)) => {
  const { all = false, dot = false } = options;
  const headers = request instanceof HonoRequest ? request.raw.headers : request.headers;
  const contentType = headers.get("Content-Type");
  if (contentType?.startsWith("multipart/form-data") || contentType?.startsWith("application/x-www-form-urlencoded")) {
    return parseFormData(request, { all, dot });
  }
  return {};
};
async function parseFormData(request, options) {
  const formData = await request.formData();
  if (formData) {
    return convertFormDataToBodyData(formData, options);
  }
  return {};
}
function convertFormDataToBodyData(formData, options) {
  const form = /* @__PURE__ */ Object.create(null);
  formData.forEach((value, key) => {
    const shouldParseAllValues = options.all || key.endsWith("[]");
    if (!shouldParseAllValues) {
      form[key] = value;
    } else {
      handleParsingAllValues(form, key, value);
    }
  });
  if (options.dot) {
    Object.entries(form).forEach(([key, value]) => {
      const shouldParseDotValues = key.includes(".");
      if (shouldParseDotValues) {
        handleParsingNestedValues(form, key, value);
        delete form[key];
      }
    });
  }
  return form;
}
var handleParsingAllValues = (form, key, value) => {
  if (form[key] !== void 0) {
    if (Array.isArray(form[key])) {
      ;
      form[key].push(value);
    } else {
      form[key] = [form[key], value];
    }
  } else {
    if (!key.endsWith("[]")) {
      form[key] = value;
    } else {
      form[key] = [value];
    }
  }
};
var handleParsingNestedValues = (form, key, value) => {
  let nestedForm = form;
  const keys = key.split(".");
  keys.forEach((key2, index) => {
    if (index === keys.length - 1) {
      nestedForm[key2] = value;
    } else {
      if (!nestedForm[key2] || typeof nestedForm[key2] !== "object" || Array.isArray(nestedForm[key2]) || nestedForm[key2] instanceof File) {
        nestedForm[key2] = /* @__PURE__ */ Object.create(null);
      }
      nestedForm = nestedForm[key2];
    }
  });
};

// node_modules/hono/dist/utils/url.js
var splitPath = (path) => {
  const paths = path.split("/");
  if (paths[0] === "") {
    paths.shift();
  }
  return paths;
};
var splitRoutingPath = (routePath) => {
  const { groups, path } = extractGroupsFromPath(routePath);
  const paths = splitPath(path);
  return replaceGroupMarks(paths, groups);
};
var extractGroupsFromPath = (path) => {
  const groups = [];
  path = path.replace(/\{[^}]+\}/g, (match2, index) => {
    const mark = `@${index}`;
    groups.push([mark, match2]);
    return mark;
  });
  return { groups, path };
};
var replaceGroupMarks = (paths, groups) => {
  for (let i = groups.length - 1; i >= 0; i--) {
    const [mark] = groups[i];
    for (let j = paths.length - 1; j >= 0; j--) {
      if (paths[j].includes(mark)) {
        paths[j] = paths[j].replace(mark, groups[i][1]);
        break;
      }
    }
  }
  return paths;
};
var patternCache = {};
var getPattern = (label, next) => {
  if (label === "*") {
    return "*";
  }
  const match2 = label.match(/^\:([^\{\}]+)(?:\{(.+)\})?$/);
  if (match2) {
    const cacheKey2 = `${label}#${next}`;
    if (!patternCache[cacheKey2]) {
      if (match2[2]) {
        patternCache[cacheKey2] = next && next[0] !== ":" && next[0] !== "*" ? [cacheKey2, match2[1], new RegExp(`^${match2[2]}(?=/${next})`)] : [label, match2[1], new RegExp(`^${match2[2]}$`)];
      } else {
        patternCache[cacheKey2] = [label, match2[1], true];
      }
    }
    return patternCache[cacheKey2];
  }
  return null;
};
var tryDecode = (str, decoder) => {
  try {
    return decoder(str);
  } catch {
    return str.replace(/(?:%[0-9A-Fa-f]{2})+/g, (match2) => {
      try {
        return decoder(match2);
      } catch {
        return match2;
      }
    });
  }
};
var tryDecodeURI = (str) => tryDecode(str, decodeURI);
var getPath = (request) => {
  const url = request.url;
  const start = url.indexOf("/", url.indexOf(":") + 4);
  let i = start;
  for (; i < url.length; i++) {
    const charCode = url.charCodeAt(i);
    if (charCode === 37) {
      const queryIndex = url.indexOf("?", i);
      const hashIndex = url.indexOf("#", i);
      const end = queryIndex === -1 ? hashIndex === -1 ? void 0 : hashIndex : hashIndex === -1 ? queryIndex : Math.min(queryIndex, hashIndex);
      const path = url.slice(start, end);
      return tryDecodeURI(path.includes("%25") ? path.replace(/%25/g, "%2525") : path);
    } else if (charCode === 63 || charCode === 35) {
      break;
    }
  }
  return url.slice(start, i);
};
var getPathNoStrict = (request) => {
  const result = getPath(request);
  return result.length > 1 && result.at(-1) === "/" ? result.slice(0, -1) : result;
};
var mergePath = (base, sub, ...rest) => {
  if (rest.length) {
    sub = mergePath(sub, ...rest);
  }
  return `${base?.[0] === "/" ? "" : "/"}${base}${sub === "/" ? "" : `${base?.at(-1) === "/" ? "" : "/"}${sub?.[0] === "/" ? sub.slice(1) : sub}`}`;
};
var checkOptionalParameter = (path) => {
  if (path.charCodeAt(path.length - 1) !== 63 || !path.includes(":")) {
    return null;
  }
  const segments = path.split("/");
  const results = [];
  let basePath = "";
  segments.forEach((segment) => {
    if (segment !== "" && !/\:/.test(segment)) {
      basePath += "/" + segment;
    } else if (/\:/.test(segment)) {
      if (/\?/.test(segment)) {
        if (results.length === 0 && basePath === "") {
          results.push("/");
        } else {
          results.push(basePath);
        }
        const optionalSegment = segment.replace("?", "");
        basePath += "/" + optionalSegment;
        results.push(basePath);
      } else {
        basePath += "/" + segment;
      }
    }
  });
  return results.filter((v, i, a) => a.indexOf(v) === i);
};
var _decodeURI = (value) => {
  if (!/[%+]/.test(value)) {
    return value;
  }
  if (value.indexOf("+") !== -1) {
    value = value.replace(/\+/g, " ");
  }
  return value.indexOf("%") !== -1 ? tryDecode(value, decodeURIComponent_) : value;
};
var _getQueryParam = (url, key, multiple) => {
  let encoded;
  if (!multiple && key && !/[%+]/.test(key)) {
    let keyIndex2 = url.indexOf("?", 8);
    if (keyIndex2 === -1) {
      return void 0;
    }
    if (!url.startsWith(key, keyIndex2 + 1)) {
      keyIndex2 = url.indexOf(`&${key}`, keyIndex2 + 1);
    }
    while (keyIndex2 !== -1) {
      const trailingKeyCode = url.charCodeAt(keyIndex2 + key.length + 1);
      if (trailingKeyCode === 61) {
        const valueIndex = keyIndex2 + key.length + 2;
        const endIndex = url.indexOf("&", valueIndex);
        return _decodeURI(url.slice(valueIndex, endIndex === -1 ? void 0 : endIndex));
      } else if (trailingKeyCode == 38 || isNaN(trailingKeyCode)) {
        return "";
      }
      keyIndex2 = url.indexOf(`&${key}`, keyIndex2 + 1);
    }
    encoded = /[%+]/.test(url);
    if (!encoded) {
      return void 0;
    }
  }
  const results = {};
  encoded ??= /[%+]/.test(url);
  let keyIndex = url.indexOf("?", 8);
  while (keyIndex !== -1) {
    const nextKeyIndex = url.indexOf("&", keyIndex + 1);
    let valueIndex = url.indexOf("=", keyIndex);
    if (valueIndex > nextKeyIndex && nextKeyIndex !== -1) {
      valueIndex = -1;
    }
    let name = url.slice(
      keyIndex + 1,
      valueIndex === -1 ? nextKeyIndex === -1 ? void 0 : nextKeyIndex : valueIndex
    );
    if (encoded) {
      name = _decodeURI(name);
    }
    keyIndex = nextKeyIndex;
    if (name === "") {
      continue;
    }
    let value;
    if (valueIndex === -1) {
      value = "";
    } else {
      value = url.slice(valueIndex + 1, nextKeyIndex === -1 ? void 0 : nextKeyIndex);
      if (encoded) {
        value = _decodeURI(value);
      }
    }
    if (multiple) {
      if (!(results[name] && Array.isArray(results[name]))) {
        results[name] = [];
      }
      ;
      results[name].push(value);
    } else {
      results[name] ??= value;
    }
  }
  return key ? results[key] : results;
};
var getQueryParam = _getQueryParam;
var getQueryParams = (url, key) => {
  return _getQueryParam(url, key, true);
};
var decodeURIComponent_ = decodeURIComponent;

// node_modules/hono/dist/request.js
var tryDecodeURIComponent = (str) => tryDecode(str, decodeURIComponent_);
var HonoRequest = class {
  /**
   * `.raw` can get the raw Request object.
   *
   * @see {@link https://hono.dev/docs/api/request#raw}
   *
   * @example
   * ```ts
   * // For Cloudflare Workers
   * app.post('/', async (c) => {
   *   const metadata = c.req.raw.cf?.hostMetadata?
   *   ...
   * })
   * ```
   */
  raw;
  #validatedData;
  // Short name of validatedData
  #matchResult;
  routeIndex = 0;
  /**
   * `.path` can get the pathname of the request.
   *
   * @see {@link https://hono.dev/docs/api/request#path}
   *
   * @example
   * ```ts
   * app.get('/about/me', (c) => {
   *   const pathname = c.req.path // `/about/me`
   * })
   * ```
   */
  path;
  bodyCache = {};
  constructor(request, path = "/", matchResult = [[]]) {
    this.raw = request;
    this.path = path;
    this.#matchResult = matchResult;
    this.#validatedData = {};
  }
  param(key) {
    return key ? this.#getDecodedParam(key) : this.#getAllDecodedParams();
  }
  #getDecodedParam(key) {
    const paramKey = this.#matchResult[0][this.routeIndex][1][key];
    const param = this.#getParamValue(paramKey);
    return param && /\%/.test(param) ? tryDecodeURIComponent(param) : param;
  }
  #getAllDecodedParams() {
    const decoded = {};
    const keys = Object.keys(this.#matchResult[0][this.routeIndex][1]);
    for (const key of keys) {
      const value = this.#getParamValue(this.#matchResult[0][this.routeIndex][1][key]);
      if (value !== void 0) {
        decoded[key] = /\%/.test(value) ? tryDecodeURIComponent(value) : value;
      }
    }
    return decoded;
  }
  #getParamValue(paramKey) {
    return this.#matchResult[1] ? this.#matchResult[1][paramKey] : paramKey;
  }
  query(key) {
    return getQueryParam(this.url, key);
  }
  queries(key) {
    return getQueryParams(this.url, key);
  }
  header(name) {
    if (name) {
      return this.raw.headers.get(name) ?? void 0;
    }
    const headerData = {};
    this.raw.headers.forEach((value, key) => {
      headerData[key] = value;
    });
    return headerData;
  }
  async parseBody(options) {
    return this.bodyCache.parsedBody ??= await parseBody(this, options);
  }
  #cachedBody = (key) => {
    const { bodyCache, raw: raw2 } = this;
    const cachedBody = bodyCache[key];
    if (cachedBody) {
      return cachedBody;
    }
    const anyCachedKey = Object.keys(bodyCache)[0];
    if (anyCachedKey) {
      return bodyCache[anyCachedKey].then((body) => {
        if (anyCachedKey === "json") {
          body = JSON.stringify(body);
        }
        return new Response(body)[key]();
      });
    }
    return bodyCache[key] = raw2[key]();
  };
  /**
   * `.json()` can parse Request body of type `application/json`
   *
   * @see {@link https://hono.dev/docs/api/request#json}
   *
   * @example
   * ```ts
   * app.post('/entry', async (c) => {
   *   const body = await c.req.json()
   * })
   * ```
   */
  json() {
    return this.#cachedBody("text").then((text) => JSON.parse(text));
  }
  /**
   * `.text()` can parse Request body of type `text/plain`
   *
   * @see {@link https://hono.dev/docs/api/request#text}
   *
   * @example
   * ```ts
   * app.post('/entry', async (c) => {
   *   const body = await c.req.text()
   * })
   * ```
   */
  text() {
    return this.#cachedBody("text");
  }
  /**
   * `.arrayBuffer()` parse Request body as an `ArrayBuffer`
   *
   * @see {@link https://hono.dev/docs/api/request#arraybuffer}
   *
   * @example
   * ```ts
   * app.post('/entry', async (c) => {
   *   const body = await c.req.arrayBuffer()
   * })
   * ```
   */
  arrayBuffer() {
    return this.#cachedBody("arrayBuffer");
  }
  /**
   * Parses the request body as a `Blob`.
   * @example
   * ```ts
   * app.post('/entry', async (c) => {
   *   const body = await c.req.blob();
   * });
   * ```
   * @see https://hono.dev/docs/api/request#blob
   */
  blob() {
    return this.#cachedBody("blob");
  }
  /**
   * Parses the request body as `FormData`.
   * @example
   * ```ts
   * app.post('/entry', async (c) => {
   *   const body = await c.req.formData();
   * });
   * ```
   * @see https://hono.dev/docs/api/request#formdata
   */
  formData() {
    return this.#cachedBody("formData");
  }
  /**
   * Adds validated data to the request.
   *
   * @param target - The target of the validation.
   * @param data - The validated data to add.
   */
  addValidatedData(target, data) {
    this.#validatedData[target] = data;
  }
  valid(target) {
    return this.#validatedData[target];
  }
  /**
   * `.url()` can get the request url strings.
   *
   * @see {@link https://hono.dev/docs/api/request#url}
   *
   * @example
   * ```ts
   * app.get('/about/me', (c) => {
   *   const url = c.req.url // `http://localhost:8787/about/me`
   *   ...
   * })
   * ```
   */
  get url() {
    return this.raw.url;
  }
  /**
   * `.method()` can get the method name of the request.
   *
   * @see {@link https://hono.dev/docs/api/request#method}
   *
   * @example
   * ```ts
   * app.get('/about/me', (c) => {
   *   const method = c.req.method // `GET`
   * })
   * ```
   */
  get method() {
    return this.raw.method;
  }
  get [GET_MATCH_RESULT]() {
    return this.#matchResult;
  }
  /**
   * `.matchedRoutes()` can return a matched route in the handler
   *
   * @deprecated
   *
   * Use matchedRoutes helper defined in "hono/route" instead.
   *
   * @see {@link https://hono.dev/docs/api/request#matchedroutes}
   *
   * @example
   * ```ts
   * app.use('*', async function logger(c, next) {
   *   await next()
   *   c.req.matchedRoutes.forEach(({ handler, method, path }, i) => {
   *     const name = handler.name || (handler.length < 2 ? '[handler]' : '[middleware]')
   *     console.log(
   *       method,
   *       ' ',
   *       path,
   *       ' '.repeat(Math.max(10 - path.length, 0)),
   *       name,
   *       i === c.req.routeIndex ? '<- respond from here' : ''
   *     )
   *   })
   * })
   * ```
   */
  get matchedRoutes() {
    return this.#matchResult[0].map(([[, route]]) => route);
  }
  /**
   * `routePath()` can retrieve the path registered within the handler
   *
   * @deprecated
   *
   * Use routePath helper defined in "hono/route" instead.
   *
   * @see {@link https://hono.dev/docs/api/request#routepath}
   *
   * @example
   * ```ts
   * app.get('/posts/:id', (c) => {
   *   return c.json({ path: c.req.routePath })
   * })
   * ```
   */
  get routePath() {
    return this.#matchResult[0].map(([[, route]]) => route)[this.routeIndex].path;
  }
};

// node_modules/hono/dist/utils/html.js
var HtmlEscapedCallbackPhase = {
  Stringify: 1,
  BeforeStream: 2,
  Stream: 3
};
var raw = (value, callbacks) => {
  const escapedString = new String(value);
  escapedString.isEscaped = true;
  escapedString.callbacks = callbacks;
  return escapedString;
};
var resolveCallback = async (str, phase, preserveCallbacks, context, buffer) => {
  if (typeof str === "object" && !(str instanceof String)) {
    if (!(str instanceof Promise)) {
      str = str.toString();
    }
    if (str instanceof Promise) {
      str = await str;
    }
  }
  const callbacks = str.callbacks;
  if (!callbacks?.length) {
    return Promise.resolve(str);
  }
  if (buffer) {
    buffer[0] += str;
  } else {
    buffer = [str];
  }
  const resStr = Promise.all(callbacks.map((c) => c({ phase, buffer, context }))).then(
    (res) => Promise.all(
      res.filter(Boolean).map((str2) => resolveCallback(str2, phase, false, context, buffer))
    ).then(() => buffer[0])
  );
  if (preserveCallbacks) {
    return raw(await resStr, callbacks);
  } else {
    return resStr;
  }
};

// node_modules/hono/dist/context.js
var TEXT_PLAIN = "text/plain; charset=UTF-8";
var setDefaultContentType = (contentType, headers) => {
  return {
    "Content-Type": contentType,
    ...headers
  };
};
var createResponseInstance = (body, init) => new Response(body, init);
var Context = class {
  #rawRequest;
  #req;
  /**
   * `.env` can get bindings (environment variables, secrets, KV namespaces, D1 database, R2 bucket etc.) in Cloudflare Workers.
   *
   * @see {@link https://hono.dev/docs/api/context#env}
   *
   * @example
   * ```ts
   * // Environment object for Cloudflare Workers
   * app.get('*', async c => {
   *   const counter = c.env.COUNTER
   * })
   * ```
   */
  env = {};
  #var;
  finalized = false;
  /**
   * `.error` can get the error object from the middleware if the Handler throws an error.
   *
   * @see {@link https://hono.dev/docs/api/context#error}
   *
   * @example
   * ```ts
   * app.use('*', async (c, next) => {
   *   await next()
   *   if (c.error) {
   *     // do something...
   *   }
   * })
   * ```
   */
  error;
  #status;
  #executionCtx;
  #res;
  #layout;
  #renderer;
  #notFoundHandler;
  #preparedHeaders;
  #matchResult;
  #path;
  /**
   * Creates an instance of the Context class.
   *
   * @param req - The Request object.
   * @param options - Optional configuration options for the context.
   */
  constructor(req, options) {
    this.#rawRequest = req;
    if (options) {
      this.#executionCtx = options.executionCtx;
      this.env = options.env;
      this.#notFoundHandler = options.notFoundHandler;
      this.#path = options.path;
      this.#matchResult = options.matchResult;
    }
  }
  /**
   * `.req` is the instance of {@link HonoRequest}.
   */
  get req() {
    this.#req ??= new HonoRequest(this.#rawRequest, this.#path, this.#matchResult);
    return this.#req;
  }
  /**
   * @see {@link https://hono.dev/docs/api/context#event}
   * The FetchEvent associated with the current request.
   *
   * @throws Will throw an error if the context does not have a FetchEvent.
   */
  get event() {
    if (this.#executionCtx && "respondWith" in this.#executionCtx) {
      return this.#executionCtx;
    } else {
      throw Error("This context has no FetchEvent");
    }
  }
  /**
   * @see {@link https://hono.dev/docs/api/context#executionctx}
   * The ExecutionContext associated with the current request.
   *
   * @throws Will throw an error if the context does not have an ExecutionContext.
   */
  get executionCtx() {
    if (this.#executionCtx) {
      return this.#executionCtx;
    } else {
      throw Error("This context has no ExecutionContext");
    }
  }
  /**
   * @see {@link https://hono.dev/docs/api/context#res}
   * The Response object for the current request.
   */
  get res() {
    return this.#res ||= createResponseInstance(null, {
      headers: this.#preparedHeaders ??= new Headers()
    });
  }
  /**
   * Sets the Response object for the current request.
   *
   * @param _res - The Response object to set.
   */
  set res(_res) {
    if (this.#res && _res) {
      _res = createResponseInstance(_res.body, _res);
      for (const [k, v] of this.#res.headers.entries()) {
        if (k === "content-type") {
          continue;
        }
        if (k === "set-cookie") {
          const cookies = this.#res.headers.getSetCookie();
          _res.headers.delete("set-cookie");
          for (const cookie of cookies) {
            _res.headers.append("set-cookie", cookie);
          }
        } else {
          _res.headers.set(k, v);
        }
      }
    }
    this.#res = _res;
    this.finalized = true;
  }
  /**
   * `.render()` can create a response within a layout.
   *
   * @see {@link https://hono.dev/docs/api/context#render-setrenderer}
   *
   * @example
   * ```ts
   * app.get('/', (c) => {
   *   return c.render('Hello!')
   * })
   * ```
   */
  render = (...args) => {
    this.#renderer ??= (content) => this.html(content);
    return this.#renderer(...args);
  };
  /**
   * Sets the layout for the response.
   *
   * @param layout - The layout to set.
   * @returns The layout function.
   */
  setLayout = (layout) => this.#layout = layout;
  /**
   * Gets the current layout for the response.
   *
   * @returns The current layout function.
   */
  getLayout = () => this.#layout;
  /**
   * `.setRenderer()` can set the layout in the custom middleware.
   *
   * @see {@link https://hono.dev/docs/api/context#render-setrenderer}
   *
   * @example
   * ```tsx
   * app.use('*', async (c, next) => {
   *   c.setRenderer((content) => {
   *     return c.html(
   *       <html>
   *         <body>
   *           <p>{content}</p>
   *         </body>
   *       </html>
   *     )
   *   })
   *   await next()
   * })
   * ```
   */
  setRenderer = (renderer) => {
    this.#renderer = renderer;
  };
  /**
   * `.header()` can set headers.
   *
   * @see {@link https://hono.dev/docs/api/context#header}
   *
   * @example
   * ```ts
   * app.get('/welcome', (c) => {
   *   // Set headers
   *   c.header('X-Message', 'Hello!')
   *   c.header('Content-Type', 'text/plain')
   *
   *   return c.body('Thank you for coming')
   * })
   * ```
   */
  header = (name, value, options) => {
    if (this.finalized) {
      this.#res = createResponseInstance(this.#res.body, this.#res);
    }
    const headers = this.#res ? this.#res.headers : this.#preparedHeaders ??= new Headers();
    if (value === void 0) {
      headers.delete(name);
    } else if (options?.append) {
      headers.append(name, value);
    } else {
      headers.set(name, value);
    }
  };
  status = (status) => {
    this.#status = status;
  };
  /**
   * `.set()` can set the value specified by the key.
   *
   * @see {@link https://hono.dev/docs/api/context#set-get}
   *
   * @example
   * ```ts
   * app.use('*', async (c, next) => {
   *   c.set('message', 'Hono is hot!!')
   *   await next()
   * })
   * ```
   */
  set = (key, value) => {
    this.#var ??= /* @__PURE__ */ new Map();
    this.#var.set(key, value);
  };
  /**
   * `.get()` can use the value specified by the key.
   *
   * @see {@link https://hono.dev/docs/api/context#set-get}
   *
   * @example
   * ```ts
   * app.get('/', (c) => {
   *   const message = c.get('message')
   *   return c.text(`The message is "${message}"`)
   * })
   * ```
   */
  get = (key) => {
    return this.#var ? this.#var.get(key) : void 0;
  };
  /**
   * `.var` can access the value of a variable.
   *
   * @see {@link https://hono.dev/docs/api/context#var}
   *
   * @example
   * ```ts
   * const result = c.var.client.oneMethod()
   * ```
   */
  // c.var.propName is a read-only
  get var() {
    if (!this.#var) {
      return {};
    }
    return Object.fromEntries(this.#var);
  }
  #newResponse(data, arg, headers) {
    const responseHeaders = this.#res ? new Headers(this.#res.headers) : this.#preparedHeaders ?? new Headers();
    if (typeof arg === "object" && "headers" in arg) {
      const argHeaders = arg.headers instanceof Headers ? arg.headers : new Headers(arg.headers);
      for (const [key, value] of argHeaders) {
        if (key.toLowerCase() === "set-cookie") {
          responseHeaders.append(key, value);
        } else {
          responseHeaders.set(key, value);
        }
      }
    }
    if (headers) {
      for (const [k, v] of Object.entries(headers)) {
        if (typeof v === "string") {
          responseHeaders.set(k, v);
        } else {
          responseHeaders.delete(k);
          for (const v2 of v) {
            responseHeaders.append(k, v2);
          }
        }
      }
    }
    const status = typeof arg === "number" ? arg : arg?.status ?? this.#status;
    return createResponseInstance(data, { status, headers: responseHeaders });
  }
  newResponse = (...args) => this.#newResponse(...args);
  /**
   * `.body()` can return the HTTP response.
   * You can set headers with `.header()` and set HTTP status code with `.status`.
   * This can also be set in `.text()`, `.json()` and so on.
   *
   * @see {@link https://hono.dev/docs/api/context#body}
   *
   * @example
   * ```ts
   * app.get('/welcome', (c) => {
   *   // Set headers
   *   c.header('X-Message', 'Hello!')
   *   c.header('Content-Type', 'text/plain')
   *   // Set HTTP status code
   *   c.status(201)
   *
   *   // Return the response body
   *   return c.body('Thank you for coming')
   * })
   * ```
   */
  body = (data, arg, headers) => this.#newResponse(data, arg, headers);
  #useFastPath() {
    return !this.#preparedHeaders && !this.#status && !this.finalized;
  }
  /**
   * `.text()` can render text as `Content-Type:text/plain`.
   *
   * @see {@link https://hono.dev/docs/api/context#text}
   *
   * @example
   * ```ts
   * app.get('/say', (c) => {
   *   return c.text('Hello!')
   * })
   * ```
   */
  text = (text, arg, headers) => {
    return this.#useFastPath() && !arg && !headers ? createResponseInstance(text) : this.#newResponse(
      text,
      arg,
      setDefaultContentType(TEXT_PLAIN, headers)
    );
  };
  /**
   * `.json()` can render JSON as `Content-Type:application/json`.
   *
   * @see {@link https://hono.dev/docs/api/context#json}
   *
   * @example
   * ```ts
   * app.get('/api', (c) => {
   *   return c.json({ message: 'Hello!' })
   * })
   * ```
   */
  json = (object, arg, headers) => {
    return this.#useFastPath() && !arg && !headers ? Response.json(object) : this.#newResponse(
      JSON.stringify(object),
      arg,
      setDefaultContentType("application/json", headers)
    );
  };
  html = (html, arg, headers) => {
    const res = (html2) => this.#newResponse(html2, arg, setDefaultContentType("text/html; charset=UTF-8", headers));
    return typeof html === "object" ? resolveCallback(html, HtmlEscapedCallbackPhase.Stringify, false, {}).then(res) : res(html);
  };
  /**
   * `.redirect()` can Redirect, default status code is 302.
   *
   * @see {@link https://hono.dev/docs/api/context#redirect}
   *
   * @example
   * ```ts
   * app.get('/redirect', (c) => {
   *   return c.redirect('/')
   * })
   * app.get('/redirect-permanently', (c) => {
   *   return c.redirect('/', 301)
   * })
   * ```
   */
  redirect = (location, status) => {
    const locationString = String(location);
    this.header(
      "Location",
      // Multibyes should be encoded
      // eslint-disable-next-line no-control-regex
      !/[^\x00-\xFF]/.test(locationString) ? locationString : encodeURI(locationString)
    );
    return this.newResponse(null, status ?? 302);
  };
  /**
   * `.notFound()` can return the Not Found Response.
   *
   * @see {@link https://hono.dev/docs/api/context#notfound}
   *
   * @example
   * ```ts
   * app.get('/notfound', (c) => {
   *   return c.notFound()
   * })
   * ```
   */
  notFound = () => {
    this.#notFoundHandler ??= () => createResponseInstance();
    return this.#notFoundHandler(this);
  };
};

// node_modules/hono/dist/router.js
var METHOD_NAME_ALL = "ALL";
var METHOD_NAME_ALL_LOWERCASE = "all";
var METHODS = ["get", "post", "put", "delete", "options", "patch"];
var MESSAGE_MATCHER_IS_ALREADY_BUILT = "Can not add a route since the matcher is already built.";
var UnsupportedPathError = class extends Error {
};

// node_modules/hono/dist/utils/constants.js
var COMPOSED_HANDLER = "__COMPOSED_HANDLER";

// node_modules/hono/dist/hono-base.js
var notFoundHandler = (c) => {
  return c.text("404 Not Found", 404);
};
var errorHandler = (err, c) => {
  if ("getResponse" in err) {
    const res = err.getResponse();
    return c.newResponse(res.body, res);
  }
  console.error(err);
  return c.text("Internal Server Error", 500);
};
var Hono = class _Hono {
  get;
  post;
  put;
  delete;
  options;
  patch;
  all;
  on;
  use;
  /*
    This class is like an abstract class and does not have a router.
    To use it, inherit the class and implement router in the constructor.
  */
  router;
  getPath;
  // Cannot use `#` because it requires visibility at JavaScript runtime.
  _basePath = "/";
  #path = "/";
  routes = [];
  constructor(options = {}) {
    const allMethods = [...METHODS, METHOD_NAME_ALL_LOWERCASE];
    allMethods.forEach((method) => {
      this[method] = (args1, ...args) => {
        if (typeof args1 === "string") {
          this.#path = args1;
        } else {
          this.#addRoute(method, this.#path, args1);
        }
        args.forEach((handler) => {
          this.#addRoute(method, this.#path, handler);
        });
        return this;
      };
    });
    this.on = (method, path, ...handlers) => {
      for (const p of [path].flat()) {
        this.#path = p;
        for (const m of [method].flat()) {
          handlers.map((handler) => {
            this.#addRoute(m.toUpperCase(), this.#path, handler);
          });
        }
      }
      return this;
    };
    this.use = (arg1, ...handlers) => {
      if (typeof arg1 === "string") {
        this.#path = arg1;
      } else {
        this.#path = "*";
        handlers.unshift(arg1);
      }
      handlers.forEach((handler) => {
        this.#addRoute(METHOD_NAME_ALL, this.#path, handler);
      });
      return this;
    };
    const { strict, ...optionsWithoutStrict } = options;
    Object.assign(this, optionsWithoutStrict);
    this.getPath = strict ?? true ? options.getPath ?? getPath : getPathNoStrict;
  }
  #clone() {
    const clone = new _Hono({
      router: this.router,
      getPath: this.getPath
    });
    clone.errorHandler = this.errorHandler;
    clone.#notFoundHandler = this.#notFoundHandler;
    clone.routes = this.routes;
    return clone;
  }
  #notFoundHandler = notFoundHandler;
  // Cannot use `#` because it requires visibility at JavaScript runtime.
  errorHandler = errorHandler;
  /**
   * `.route()` allows grouping other Hono instance in routes.
   *
   * @see {@link https://hono.dev/docs/api/routing#grouping}
   *
   * @param {string} path - base Path
   * @param {Hono} app - other Hono instance
   * @returns {Hono} routed Hono instance
   *
   * @example
   * ```ts
   * const app = new Hono()
   * const app2 = new Hono()
   *
   * app2.get("/user", (c) => c.text("user"))
   * app.route("/api", app2) // GET /api/user
   * ```
   */
  route(path, app) {
    const subApp = this.basePath(path);
    app.routes.map((r) => {
      let handler;
      if (app.errorHandler === errorHandler) {
        handler = r.handler;
      } else {
        handler = async (c, next) => (await compose([], app.errorHandler)(c, () => r.handler(c, next))).res;
        handler[COMPOSED_HANDLER] = r.handler;
      }
      subApp.#addRoute(r.method, r.path, handler);
    });
    return this;
  }
  /**
   * `.basePath()` allows base paths to be specified.
   *
   * @see {@link https://hono.dev/docs/api/routing#base-path}
   *
   * @param {string} path - base Path
   * @returns {Hono} changed Hono instance
   *
   * @example
   * ```ts
   * const api = new Hono().basePath('/api')
   * ```
   */
  basePath(path) {
    const subApp = this.#clone();
    subApp._basePath = mergePath(this._basePath, path);
    return subApp;
  }
  /**
   * `.onError()` handles an error and returns a customized Response.
   *
   * @see {@link https://hono.dev/docs/api/hono#error-handling}
   *
   * @param {ErrorHandler} handler - request Handler for error
   * @returns {Hono} changed Hono instance
   *
   * @example
   * ```ts
   * app.onError((err, c) => {
   *   console.error(`${err}`)
   *   return c.text('Custom Error Message', 500)
   * })
   * ```
   */
  onError = (handler) => {
    this.errorHandler = handler;
    return this;
  };
  /**
   * `.notFound()` allows you to customize a Not Found Response.
   *
   * @see {@link https://hono.dev/docs/api/hono#not-found}
   *
   * @param {NotFoundHandler} handler - request handler for not-found
   * @returns {Hono} changed Hono instance
   *
   * @example
   * ```ts
   * app.notFound((c) => {
   *   return c.text('Custom 404 Message', 404)
   * })
   * ```
   */
  notFound = (handler) => {
    this.#notFoundHandler = handler;
    return this;
  };
  /**
   * `.mount()` allows you to mount applications built with other frameworks into your Hono application.
   *
   * @see {@link https://hono.dev/docs/api/hono#mount}
   *
   * @param {string} path - base Path
   * @param {Function} applicationHandler - other Request Handler
   * @param {MountOptions} [options] - options of `.mount()`
   * @returns {Hono} mounted Hono instance
   *
   * @example
   * ```ts
   * import { Router as IttyRouter } from 'itty-router'
   * import { Hono } from 'hono'
   * // Create itty-router application
   * const ittyRouter = IttyRouter()
   * // GET /itty-router/hello
   * ittyRouter.get('/hello', () => new Response('Hello from itty-router'))
   *
   * const app = new Hono()
   * app.mount('/itty-router', ittyRouter.handle)
   * ```
   *
   * @example
   * ```ts
   * const app = new Hono()
   * // Send the request to another application without modification.
   * app.mount('/app', anotherApp, {
   *   replaceRequest: (req) => req,
   * })
   * ```
   */
  mount(path, applicationHandler, options) {
    let replaceRequest;
    let optionHandler;
    if (options) {
      if (typeof options === "function") {
        optionHandler = options;
      } else {
        optionHandler = options.optionHandler;
        if (options.replaceRequest === false) {
          replaceRequest = (request) => request;
        } else {
          replaceRequest = options.replaceRequest;
        }
      }
    }
    const getOptions = optionHandler ? (c) => {
      const options2 = optionHandler(c);
      return Array.isArray(options2) ? options2 : [options2];
    } : (c) => {
      let executionContext = void 0;
      try {
        executionContext = c.executionCtx;
      } catch {
      }
      return [c.env, executionContext];
    };
    replaceRequest ||= (() => {
      const mergedPath = mergePath(this._basePath, path);
      const pathPrefixLength = mergedPath === "/" ? 0 : mergedPath.length;
      return (request) => {
        const url = new URL(request.url);
        url.pathname = url.pathname.slice(pathPrefixLength) || "/";
        return new Request(url, request);
      };
    })();
    const handler = async (c, next) => {
      const res = await applicationHandler(replaceRequest(c.req.raw), ...getOptions(c));
      if (res) {
        return res;
      }
      await next();
    };
    this.#addRoute(METHOD_NAME_ALL, mergePath(path, "*"), handler);
    return this;
  }
  #addRoute(method, path, handler) {
    method = method.toUpperCase();
    path = mergePath(this._basePath, path);
    const r = { basePath: this._basePath, path, method, handler };
    this.router.add(method, path, [handler, r]);
    this.routes.push(r);
  }
  #handleError(err, c) {
    if (err instanceof Error) {
      return this.errorHandler(err, c);
    }
    throw err;
  }
  #dispatch(request, executionCtx, env, method) {
    if (method === "HEAD") {
      return (async () => new Response(null, await this.#dispatch(request, executionCtx, env, "GET")))();
    }
    const path = this.getPath(request, { env });
    const matchResult = this.router.match(method, path);
    const c = new Context(request, {
      path,
      matchResult,
      env,
      executionCtx,
      notFoundHandler: this.#notFoundHandler
    });
    if (matchResult[0].length === 1) {
      let res;
      try {
        res = matchResult[0][0][0][0](c, async () => {
          c.res = await this.#notFoundHandler(c);
        });
      } catch (err) {
        return this.#handleError(err, c);
      }
      return res instanceof Promise ? res.then(
        (resolved) => resolved || (c.finalized ? c.res : this.#notFoundHandler(c))
      ).catch((err) => this.#handleError(err, c)) : res ?? this.#notFoundHandler(c);
    }
    const composed = compose(matchResult[0], this.errorHandler, this.#notFoundHandler);
    return (async () => {
      try {
        const context = await composed(c);
        if (!context.finalized) {
          throw new Error(
            "Context is not finalized. Did you forget to return a Response object or `await next()`?"
          );
        }
        return context.res;
      } catch (err) {
        return this.#handleError(err, c);
      }
    })();
  }
  /**
   * `.fetch()` will be entry point of your app.
   *
   * @see {@link https://hono.dev/docs/api/hono#fetch}
   *
   * @param {Request} request - request Object of request
   * @param {Env} Env - env Object
   * @param {ExecutionContext} - context of execution
   * @returns {Response | Promise<Response>} response of request
   *
   */
  fetch = (request, ...rest) => {
    return this.#dispatch(request, rest[1], rest[0], request.method);
  };
  /**
   * `.request()` is a useful method for testing.
   * You can pass a URL or pathname to send a GET request.
   * app will return a Response object.
   * ```ts
   * test('GET /hello is ok', async () => {
   *   const res = await app.request('/hello')
   *   expect(res.status).toBe(200)
   * })
   * ```
   * @see https://hono.dev/docs/api/hono#request
   */
  request = (input, requestInit, Env, executionCtx) => {
    if (input instanceof Request) {
      return this.fetch(requestInit ? new Request(input, requestInit) : input, Env, executionCtx);
    }
    input = input.toString();
    return this.fetch(
      new Request(
        /^https?:\/\//.test(input) ? input : `http://localhost${mergePath("/", input)}`,
        requestInit
      ),
      Env,
      executionCtx
    );
  };
  /**
   * `.fire()` automatically adds a global fetch event listener.
   * This can be useful for environments that adhere to the Service Worker API, such as non-ES module Cloudflare Workers.
   * @deprecated
   * Use `fire` from `hono/service-worker` instead.
   * ```ts
   * import { Hono } from 'hono'
   * import { fire } from 'hono/service-worker'
   *
   * const app = new Hono()
   * // ...
   * fire(app)
   * ```
   * @see https://hono.dev/docs/api/hono#fire
   * @see https://developer.mozilla.org/en-US/docs/Web/API/Service_Worker_API
   * @see https://developers.cloudflare.com/workers/reference/migrate-to-module-workers/
   */
  fire = () => {
    addEventListener("fetch", (event) => {
      event.respondWith(this.#dispatch(event.request, event, void 0, event.request.method));
    });
  };
};

// node_modules/hono/dist/router/reg-exp-router/matcher.js
var emptyParam = [];
function match(method, path) {
  const matchers = this.buildAllMatchers();
  const match2 = ((method2, path2) => {
    const matcher = matchers[method2] || matchers[METHOD_NAME_ALL];
    const staticMatch = matcher[2][path2];
    if (staticMatch) {
      return staticMatch;
    }
    const match3 = path2.match(matcher[0]);
    if (!match3) {
      return [[], emptyParam];
    }
    const index = match3.indexOf("", 1);
    return [matcher[1][index], match3];
  });
  this.match = match2;
  return match2(method, path);
}

// node_modules/hono/dist/router/reg-exp-router/node.js
var LABEL_REG_EXP_STR = "[^/]+";
var ONLY_WILDCARD_REG_EXP_STR = ".*";
var TAIL_WILDCARD_REG_EXP_STR = "(?:|/.*)";
var PATH_ERROR = /* @__PURE__ */ Symbol();
var regExpMetaChars = new Set(".\\+*[^]$()");
function compareKey(a, b) {
  if (a.length === 1) {
    return b.length === 1 ? a < b ? -1 : 1 : -1;
  }
  if (b.length === 1) {
    return 1;
  }
  if (a === ONLY_WILDCARD_REG_EXP_STR || a === TAIL_WILDCARD_REG_EXP_STR) {
    return 1;
  } else if (b === ONLY_WILDCARD_REG_EXP_STR || b === TAIL_WILDCARD_REG_EXP_STR) {
    return -1;
  }
  if (a === LABEL_REG_EXP_STR) {
    return 1;
  } else if (b === LABEL_REG_EXP_STR) {
    return -1;
  }
  return a.length === b.length ? a < b ? -1 : 1 : b.length - a.length;
}
var Node = class _Node {
  #index;
  #varIndex;
  #children = /* @__PURE__ */ Object.create(null);
  insert(tokens, index, paramMap, context, pathErrorCheckOnly) {
    if (tokens.length === 0) {
      if (this.#index !== void 0) {
        throw PATH_ERROR;
      }
      if (pathErrorCheckOnly) {
        return;
      }
      this.#index = index;
      return;
    }
    const [token, ...restTokens] = tokens;
    const pattern = token === "*" ? restTokens.length === 0 ? ["", "", ONLY_WILDCARD_REG_EXP_STR] : ["", "", LABEL_REG_EXP_STR] : token === "/*" ? ["", "", TAIL_WILDCARD_REG_EXP_STR] : token.match(/^\:([^\{\}]+)(?:\{(.+)\})?$/);
    let node;
    if (pattern) {
      const name = pattern[1];
      let regexpStr = pattern[2] || LABEL_REG_EXP_STR;
      if (name && pattern[2]) {
        if (regexpStr === ".*") {
          throw PATH_ERROR;
        }
        regexpStr = regexpStr.replace(/^\((?!\?:)(?=[^)]+\)$)/, "(?:");
        if (/\((?!\?:)/.test(regexpStr)) {
          throw PATH_ERROR;
        }
      }
      node = this.#children[regexpStr];
      if (!node) {
        if (Object.keys(this.#children).some(
          (k) => k !== ONLY_WILDCARD_REG_EXP_STR && k !== TAIL_WILDCARD_REG_EXP_STR
        )) {
          throw PATH_ERROR;
        }
        if (pathErrorCheckOnly) {
          return;
        }
        node = this.#children[regexpStr] = new _Node();
        if (name !== "") {
          node.#varIndex = context.varIndex++;
        }
      }
      if (!pathErrorCheckOnly && name !== "") {
        paramMap.push([name, node.#varIndex]);
      }
    } else {
      node = this.#children[token];
      if (!node) {
        if (Object.keys(this.#children).some(
          (k) => k.length > 1 && k !== ONLY_WILDCARD_REG_EXP_STR && k !== TAIL_WILDCARD_REG_EXP_STR
        )) {
          throw PATH_ERROR;
        }
        if (pathErrorCheckOnly) {
          return;
        }
        node = this.#children[token] = new _Node();
      }
    }
    node.insert(restTokens, index, paramMap, context, pathErrorCheckOnly);
  }
  buildRegExpStr() {
    const childKeys = Object.keys(this.#children).sort(compareKey);
    const strList = childKeys.map((k) => {
      const c = this.#children[k];
      return (typeof c.#varIndex === "number" ? `(${k})@${c.#varIndex}` : regExpMetaChars.has(k) ? `\\${k}` : k) + c.buildRegExpStr();
    });
    if (typeof this.#index === "number") {
      strList.unshift(`#${this.#index}`);
    }
    if (strList.length === 0) {
      return "";
    }
    if (strList.length === 1) {
      return strList[0];
    }
    return "(?:" + strList.join("|") + ")";
  }
};

// node_modules/hono/dist/router/reg-exp-router/trie.js
var Trie = class {
  #context = { varIndex: 0 };
  #root = new Node();
  insert(path, index, pathErrorCheckOnly) {
    const paramAssoc = [];
    const groups = [];
    for (let i = 0; ; ) {
      let replaced = false;
      path = path.replace(/\{[^}]+\}/g, (m) => {
        const mark = `@\\${i}`;
        groups[i] = [mark, m];
        i++;
        replaced = true;
        return mark;
      });
      if (!replaced) {
        break;
      }
    }
    const tokens = path.match(/(?::[^\/]+)|(?:\/\*$)|./g) || [];
    for (let i = groups.length - 1; i >= 0; i--) {
      const [mark] = groups[i];
      for (let j = tokens.length - 1; j >= 0; j--) {
        if (tokens[j].indexOf(mark) !== -1) {
          tokens[j] = tokens[j].replace(mark, groups[i][1]);
          break;
        }
      }
    }
    this.#root.insert(tokens, index, paramAssoc, this.#context, pathErrorCheckOnly);
    return paramAssoc;
  }
  buildRegExp() {
    let regexp = this.#root.buildRegExpStr();
    if (regexp === "") {
      return [/^$/, [], []];
    }
    let captureIndex = 0;
    const indexReplacementMap = [];
    const paramReplacementMap = [];
    regexp = regexp.replace(/#(\d+)|@(\d+)|\.\*\$/g, (_, handlerIndex, paramIndex) => {
      if (handlerIndex !== void 0) {
        indexReplacementMap[++captureIndex] = Number(handlerIndex);
        return "$()";
      }
      if (paramIndex !== void 0) {
        paramReplacementMap[Number(paramIndex)] = ++captureIndex;
        return "";
      }
      return "";
    });
    return [new RegExp(`^${regexp}`), indexReplacementMap, paramReplacementMap];
  }
};

// node_modules/hono/dist/router/reg-exp-router/router.js
var nullMatcher = [/^$/, [], /* @__PURE__ */ Object.create(null)];
var wildcardRegExpCache = /* @__PURE__ */ Object.create(null);
function buildWildcardRegExp(path) {
  return wildcardRegExpCache[path] ??= new RegExp(
    path === "*" ? "" : `^${path.replace(
      /\/\*$|([.\\+*[^\]$()])/g,
      (_, metaChar) => metaChar ? `\\${metaChar}` : "(?:|/.*)"
    )}$`
  );
}
function clearWildcardRegExpCache() {
  wildcardRegExpCache = /* @__PURE__ */ Object.create(null);
}
function buildMatcherFromPreprocessedRoutes(routes) {
  const trie = new Trie();
  const handlerData = [];
  if (routes.length === 0) {
    return nullMatcher;
  }
  const routesWithStaticPathFlag = routes.map(
    (route) => [!/\*|\/:/.test(route[0]), ...route]
  ).sort(
    ([isStaticA, pathA], [isStaticB, pathB]) => isStaticA ? 1 : isStaticB ? -1 : pathA.length - pathB.length
  );
  const staticMap = /* @__PURE__ */ Object.create(null);
  for (let i = 0, j = -1, len = routesWithStaticPathFlag.length; i < len; i++) {
    const [pathErrorCheckOnly, path, handlers] = routesWithStaticPathFlag[i];
    if (pathErrorCheckOnly) {
      staticMap[path] = [handlers.map(([h]) => [h, /* @__PURE__ */ Object.create(null)]), emptyParam];
    } else {
      j++;
    }
    let paramAssoc;
    try {
      paramAssoc = trie.insert(path, j, pathErrorCheckOnly);
    } catch (e) {
      throw e === PATH_ERROR ? new UnsupportedPathError(path) : e;
    }
    if (pathErrorCheckOnly) {
      continue;
    }
    handlerData[j] = handlers.map(([h, paramCount]) => {
      const paramIndexMap = /* @__PURE__ */ Object.create(null);
      paramCount -= 1;
      for (; paramCount >= 0; paramCount--) {
        const [key, value] = paramAssoc[paramCount];
        paramIndexMap[key] = value;
      }
      return [h, paramIndexMap];
    });
  }
  const [regexp, indexReplacementMap, paramReplacementMap] = trie.buildRegExp();
  for (let i = 0, len = handlerData.length; i < len; i++) {
    for (let j = 0, len2 = handlerData[i].length; j < len2; j++) {
      const map = handlerData[i][j]?.[1];
      if (!map) {
        continue;
      }
      const keys = Object.keys(map);
      for (let k = 0, len3 = keys.length; k < len3; k++) {
        map[keys[k]] = paramReplacementMap[map[keys[k]]];
      }
    }
  }
  const handlerMap = [];
  for (const i in indexReplacementMap) {
    handlerMap[i] = handlerData[indexReplacementMap[i]];
  }
  return [regexp, handlerMap, staticMap];
}
function findMiddleware(middleware, path) {
  if (!middleware) {
    return void 0;
  }
  for (const k of Object.keys(middleware).sort((a, b) => b.length - a.length)) {
    if (buildWildcardRegExp(k).test(path)) {
      return [...middleware[k]];
    }
  }
  return void 0;
}
var RegExpRouter = class {
  name = "RegExpRouter";
  #middleware;
  #routes;
  constructor() {
    this.#middleware = { [METHOD_NAME_ALL]: /* @__PURE__ */ Object.create(null) };
    this.#routes = { [METHOD_NAME_ALL]: /* @__PURE__ */ Object.create(null) };
  }
  add(method, path, handler) {
    const middleware = this.#middleware;
    const routes = this.#routes;
    if (!middleware || !routes) {
      throw new Error(MESSAGE_MATCHER_IS_ALREADY_BUILT);
    }
    if (!middleware[method]) {
      ;
      [middleware, routes].forEach((handlerMap) => {
        handlerMap[method] = /* @__PURE__ */ Object.create(null);
        Object.keys(handlerMap[METHOD_NAME_ALL]).forEach((p) => {
          handlerMap[method][p] = [...handlerMap[METHOD_NAME_ALL][p]];
        });
      });
    }
    if (path === "/*") {
      path = "*";
    }
    const paramCount = (path.match(/\/:/g) || []).length;
    if (/\*$/.test(path)) {
      const re = buildWildcardRegExp(path);
      if (method === METHOD_NAME_ALL) {
        Object.keys(middleware).forEach((m) => {
          middleware[m][path] ||= findMiddleware(middleware[m], path) || findMiddleware(middleware[METHOD_NAME_ALL], path) || [];
        });
      } else {
        middleware[method][path] ||= findMiddleware(middleware[method], path) || findMiddleware(middleware[METHOD_NAME_ALL], path) || [];
      }
      Object.keys(middleware).forEach((m) => {
        if (method === METHOD_NAME_ALL || method === m) {
          Object.keys(middleware[m]).forEach((p) => {
            re.test(p) && middleware[m][p].push([handler, paramCount]);
          });
        }
      });
      Object.keys(routes).forEach((m) => {
        if (method === METHOD_NAME_ALL || method === m) {
          Object.keys(routes[m]).forEach(
            (p) => re.test(p) && routes[m][p].push([handler, paramCount])
          );
        }
      });
      return;
    }
    const paths = checkOptionalParameter(path) || [path];
    for (let i = 0, len = paths.length; i < len; i++) {
      const path2 = paths[i];
      Object.keys(routes).forEach((m) => {
        if (method === METHOD_NAME_ALL || method === m) {
          routes[m][path2] ||= [
            ...findMiddleware(middleware[m], path2) || findMiddleware(middleware[METHOD_NAME_ALL], path2) || []
          ];
          routes[m][path2].push([handler, paramCount - len + i + 1]);
        }
      });
    }
  }
  match = match;
  buildAllMatchers() {
    const matchers = /* @__PURE__ */ Object.create(null);
    Object.keys(this.#routes).concat(Object.keys(this.#middleware)).forEach((method) => {
      matchers[method] ||= this.#buildMatcher(method);
    });
    this.#middleware = this.#routes = void 0;
    clearWildcardRegExpCache();
    return matchers;
  }
  #buildMatcher(method) {
    const routes = [];
    let hasOwnRoute = method === METHOD_NAME_ALL;
    [this.#middleware, this.#routes].forEach((r) => {
      const ownRoute = r[method] ? Object.keys(r[method]).map((path) => [path, r[method][path]]) : [];
      if (ownRoute.length !== 0) {
        hasOwnRoute ||= true;
        routes.push(...ownRoute);
      } else if (method !== METHOD_NAME_ALL) {
        routes.push(
          ...Object.keys(r[METHOD_NAME_ALL]).map((path) => [path, r[METHOD_NAME_ALL][path]])
        );
      }
    });
    if (!hasOwnRoute) {
      return null;
    } else {
      return buildMatcherFromPreprocessedRoutes(routes);
    }
  }
};

// node_modules/hono/dist/router/smart-router/router.js
var SmartRouter = class {
  name = "SmartRouter";
  #routers = [];
  #routes = [];
  constructor(init) {
    this.#routers = init.routers;
  }
  add(method, path, handler) {
    if (!this.#routes) {
      throw new Error(MESSAGE_MATCHER_IS_ALREADY_BUILT);
    }
    this.#routes.push([method, path, handler]);
  }
  match(method, path) {
    if (!this.#routes) {
      throw new Error("Fatal error");
    }
    const routers = this.#routers;
    const routes = this.#routes;
    const len = routers.length;
    let i = 0;
    let res;
    for (; i < len; i++) {
      const router = routers[i];
      try {
        for (let i2 = 0, len2 = routes.length; i2 < len2; i2++) {
          router.add(...routes[i2]);
        }
        res = router.match(method, path);
      } catch (e) {
        if (e instanceof UnsupportedPathError) {
          continue;
        }
        throw e;
      }
      this.match = router.match.bind(router);
      this.#routers = [router];
      this.#routes = void 0;
      break;
    }
    if (i === len) {
      throw new Error("Fatal error");
    }
    this.name = `SmartRouter + ${this.activeRouter.name}`;
    return res;
  }
  get activeRouter() {
    if (this.#routes || this.#routers.length !== 1) {
      throw new Error("No active router has been determined yet.");
    }
    return this.#routers[0];
  }
};

// node_modules/hono/dist/router/trie-router/node.js
var emptyParams = /* @__PURE__ */ Object.create(null);
var hasChildren = (children) => {
  for (const _ in children) {
    return true;
  }
  return false;
};
var Node2 = class _Node2 {
  #methods;
  #children;
  #patterns;
  #order = 0;
  #params = emptyParams;
  constructor(method, handler, children) {
    this.#children = children || /* @__PURE__ */ Object.create(null);
    this.#methods = [];
    if (method && handler) {
      const m = /* @__PURE__ */ Object.create(null);
      m[method] = { handler, possibleKeys: [], score: 0 };
      this.#methods = [m];
    }
    this.#patterns = [];
  }
  insert(method, path, handler) {
    this.#order = ++this.#order;
    let curNode = this;
    const parts = splitRoutingPath(path);
    const possibleKeys = [];
    for (let i = 0, len = parts.length; i < len; i++) {
      const p = parts[i];
      const nextP = parts[i + 1];
      const pattern = getPattern(p, nextP);
      const key = Array.isArray(pattern) ? pattern[0] : p;
      if (key in curNode.#children) {
        curNode = curNode.#children[key];
        if (pattern) {
          possibleKeys.push(pattern[1]);
        }
        continue;
      }
      curNode.#children[key] = new _Node2();
      if (pattern) {
        curNode.#patterns.push(pattern);
        possibleKeys.push(pattern[1]);
      }
      curNode = curNode.#children[key];
    }
    curNode.#methods.push({
      [method]: {
        handler,
        possibleKeys: possibleKeys.filter((v, i, a) => a.indexOf(v) === i),
        score: this.#order
      }
    });
    return curNode;
  }
  #pushHandlerSets(handlerSets, node, method, nodeParams, params) {
    for (let i = 0, len = node.#methods.length; i < len; i++) {
      const m = node.#methods[i];
      const handlerSet = m[method] || m[METHOD_NAME_ALL];
      const processedSet = {};
      if (handlerSet !== void 0) {
        handlerSet.params = /* @__PURE__ */ Object.create(null);
        handlerSets.push(handlerSet);
        if (nodeParams !== emptyParams || params && params !== emptyParams) {
          for (let i2 = 0, len2 = handlerSet.possibleKeys.length; i2 < len2; i2++) {
            const key = handlerSet.possibleKeys[i2];
            const processed = processedSet[handlerSet.score];
            handlerSet.params[key] = params?.[key] && !processed ? params[key] : nodeParams[key] ?? params?.[key];
            processedSet[handlerSet.score] = true;
          }
        }
      }
    }
  }
  search(method, path) {
    const handlerSets = [];
    this.#params = emptyParams;
    const curNode = this;
    let curNodes = [curNode];
    const parts = splitPath(path);
    const curNodesQueue = [];
    const len = parts.length;
    let partOffsets = null;
    for (let i = 0; i < len; i++) {
      const part = parts[i];
      const isLast = i === len - 1;
      const tempNodes = [];
      for (let j = 0, len2 = curNodes.length; j < len2; j++) {
        const node = curNodes[j];
        const nextNode = node.#children[part];
        if (nextNode) {
          nextNode.#params = node.#params;
          if (isLast) {
            if (nextNode.#children["*"]) {
              this.#pushHandlerSets(handlerSets, nextNode.#children["*"], method, node.#params);
            }
            this.#pushHandlerSets(handlerSets, nextNode, method, node.#params);
          } else {
            tempNodes.push(nextNode);
          }
        }
        for (let k = 0, len3 = node.#patterns.length; k < len3; k++) {
          const pattern = node.#patterns[k];
          const params = node.#params === emptyParams ? {} : { ...node.#params };
          if (pattern === "*") {
            const astNode = node.#children["*"];
            if (astNode) {
              this.#pushHandlerSets(handlerSets, astNode, method, node.#params);
              astNode.#params = params;
              tempNodes.push(astNode);
            }
            continue;
          }
          const [key, name, matcher] = pattern;
          if (!part && !(matcher instanceof RegExp)) {
            continue;
          }
          const child = node.#children[key];
          if (matcher instanceof RegExp) {
            if (partOffsets === null) {
              partOffsets = new Array(len);
              let offset = path[0] === "/" ? 1 : 0;
              for (let p = 0; p < len; p++) {
                partOffsets[p] = offset;
                offset += parts[p].length + 1;
              }
            }
            const restPathString = path.substring(partOffsets[i]);
            const m = matcher.exec(restPathString);
            if (m) {
              params[name] = m[0];
              this.#pushHandlerSets(handlerSets, child, method, node.#params, params);
              if (hasChildren(child.#children)) {
                child.#params = params;
                const componentCount = m[0].match(/\//)?.length ?? 0;
                const targetCurNodes = curNodesQueue[componentCount] ||= [];
                targetCurNodes.push(child);
              }
              continue;
            }
          }
          if (matcher === true || matcher.test(part)) {
            params[name] = part;
            if (isLast) {
              this.#pushHandlerSets(handlerSets, child, method, params, node.#params);
              if (child.#children["*"]) {
                this.#pushHandlerSets(
                  handlerSets,
                  child.#children["*"],
                  method,
                  params,
                  node.#params
                );
              }
            } else {
              child.#params = params;
              tempNodes.push(child);
            }
          }
        }
      }
      const shifted = curNodesQueue.shift();
      curNodes = shifted ? tempNodes.concat(shifted) : tempNodes;
    }
    if (handlerSets.length > 1) {
      handlerSets.sort((a, b) => {
        return a.score - b.score;
      });
    }
    return [handlerSets.map(({ handler, params }) => [handler, params])];
  }
};

// node_modules/hono/dist/router/trie-router/router.js
var TrieRouter = class {
  name = "TrieRouter";
  #node;
  constructor() {
    this.#node = new Node2();
  }
  add(method, path, handler) {
    const results = checkOptionalParameter(path);
    if (results) {
      for (let i = 0, len = results.length; i < len; i++) {
        this.#node.insert(method, results[i], handler);
      }
      return;
    }
    this.#node.insert(method, path, handler);
  }
  match(method, path) {
    return this.#node.search(method, path);
  }
};

// node_modules/hono/dist/hono.js
var Hono2 = class extends Hono {
  /**
   * Creates an instance of the Hono class.
   *
   * @param options - Optional configuration options for the Hono instance.
   */
  constructor(options = {}) {
    super(options);
    this.router = options.router ?? new SmartRouter({
      routers: [new RegExpRouter(), new TrieRouter()]
    });
  }
};

// command.mjs
var Refused = class extends Error {
  constructor(message, status = 409) {
    super(message);
    this.status = status;
  }
};
var commandsOf = (app) => app.commands ??= [];
var inputNames = (input) => Array.isArray(input) ? input.flatMap((x) => typeof x === "string" ? [x] : Object.keys(x)) : Object.keys(input ?? {});
function command(app, method, path, spec, handler) {
  commandsOf(app).push({ ...spec, method, path, input: spec.input ?? {}, by: spec.by ?? "anyone", read: method === "GET" });
  app.on(method, path, async (c) => {
    const actor = c.req.header("x-actor") || "";
    if (spec.by === "person" && !actor.startsWith("person:")) throw new Refused(`Only a person can do this: ask them. (${spec.name})`, 403);
    const body = method === "GET" ? c.req.query() : await c.req.json().catch(() => ({}));
    const input = {};
    for (const k of inputNames(spec.input)) if (body[k] !== void 0) input[k] = body[k];
    for (const [k, v] of Object.entries(c.req.param())) input[k] = /^\d+$/.test(v) ? Number(v) : v;
    return c.json(await handler(input, { actor }) ?? { ok: true });
  });
}
function mountErrors(app) {
  app.onError((e, c) => c.json({ error: e.message }, e.status ?? 500));
  app.get("/_commands", (c) => c.json(commandsOf(app)));
}

// services/util.mjs
var now = () => (/* @__PURE__ */ new Date()).toISOString();
var pick = (o, keys) => Object.fromEntries(keys.filter((k) => o[k] !== void 0).map((k) => [k, o[k]]));
var json = (t, d) => {
  if (!t) return d;
  try {
    return JSON.parse(t);
  } catch {
    return d;
  }
};
async function updateIf(db, table, id, data, where = {}, stale = "It changed: read it again.") {
  const changed = await db.update(table, id, data, where);
  if (!changed) {
    const row = await db.one(`SELECT _id FROM "${table}" WHERE _id = ? AND _deleted = 0`, [id]);
    throw row ? new Refused(stale) : new Refused(`There is no ${id} in ${table}.`, 404);
  }
  return { id, ok: true };
}

// services/articles.mjs
var T = "articles_articles";
var NEW = { state: "draft", archived: 0, failing: 0 };
var list = (db) => db.all(`SELECT * FROM ${T} WHERE archived = 0 AND _deleted = 0 ORDER BY _id DESC`);
async function get(db, id) {
  const a = await db.one(`SELECT * FROM ${T} WHERE _id = ? AND _deleted = 0`, [id]);
  if (!a) throw new Refused(`There is no article ${id}.`, 404);
  const blocks = await db.all("SELECT * FROM articles_blocks WHERE article_id = ? AND deleted = 0 AND _deleted = 0 ORDER BY position, _id", [id]);
  return { ...a, plan: json(a.plan, null), outline: json(a.outline, null), blocks };
}
var create = (db, input, actor) => db.insert(T, { ...pick(input, ["title", "main_query", "kind", "brief", "local_key"]), ...NEW, created_by: actor }).then((id) => ({ id }));
var parsed = (v, what) => {
  if (typeof v !== "string") return v;
  const p = json(v, void 0);
  if (p === void 0) throw new Refused(`${what} must be JSON.`, 400);
  return p;
};
function setPlan(db, { id, plan }) {
  const p = parsed(plan, "plan");
  if (!p || typeof p !== "object" || Array.isArray(p) || !p.angle) throw new Refused('plan needs at least {"angle": "\u2026"}: the point of view of the article.', 400);
  return updateIf(db, T, id, { plan: JSON.stringify(p) });
}
function setOutline(db, { id, outline }) {
  const o = parsed(outline, "outline");
  if (!Array.isArray(o) || !o.length) throw new Refused('outline is a list: [{"title": "\u2026", "points": "\u2026"}], with an empty title for the intro.', 400);
  return updateIf(db, T, id, { outline: JSON.stringify(o) });
}
var setSeo = (db, input) => updateIf(db, T, input.id, pick(input, ["title", "main_query", "meta_title", "meta_description", "slug", "supporting", "persona"]));
var setBrief = (db, input) => updateIf(db, T, input.id, pick(input, ["kind", "brief"]));
var setState = (db, { id, state }) => updateIf(db, T, id, { state });
var move = (to, from) => (db, { id }) => updateIf(db, T, id, { state: to }, { state: from }, `The article is not in ${from}.`);
var reopen = move("draft", "review");
var approve = move("ready", "review");
var publish = move("published", "ready");
var archive = (db, { id }) => updateIf(db, T, id, { archived: 1 });

// services/quality.mjs
var import_articore = __toESM(require_articore(), 1);
import crypto2 from "node:crypto";
var UA = { "User-Agent": "Mozilla/5.0 (compatible; OrchestraArticles)" };
var WEEK = 7 * 864e5;
var blocksOf = (db, id) => db.all("SELECT _id, position, markdown FROM articles_blocks WHERE article_id = ? AND deleted = 0 AND _deleted = 0 ORDER BY position, _id", [id]);
var hashOf = (blocks, a) => crypto2.createHash("sha1").update(JSON.stringify([blocks.map((b) => b.markdown), a.title, a.main_query, a.meta_title, a.meta_description, a.slug])).digest("hex").slice(0, 16);
var seoOf = (a) => ({ mainQuery: a.main_query || "", metaTitle: a.meta_title || "", metaDescription: a.meta_description || "", slug: a.slug || "", supporting: a.supporting || "", persona: a.persona || "" });
async function linkStatuses(db, urls, fetchLink) {
  const known = Object.fromEntries((await db.all("SELECT _id, url, status, checked_at FROM articles_links WHERE _deleted = 0")).map((r) => [r.url, r]));
  const out = {};
  const ops = [];
  await Promise.all(urls.slice(0, 40).map(async (u) => {
    const k = known[u];
    if (k && Date.now() - Date.parse(k.checked_at) < WEEK) {
      out[u] = k.status;
      return;
    }
    const status = await fetchLink(u);
    out[u] = status;
    const data = { url: u, status, checked_at: now() };
    ops.push(k ? { op: "update", table: "articles_links", id: k._id, data } : { op: "insert", table: "articles_links", data });
  }));
  if (ops.length) await db.batch(ops);
  return out;
}
var liveLink = (u) => fetch(u, { redirect: "follow", signal: AbortSignal.timeout(1e4), headers: UA }).then((r) => r.status).catch(() => null);
async function evaluate(db, id, fetchLink) {
  const a = await db.one("SELECT * FROM articles_articles WHERE _id = ? AND _deleted = 0", [id]);
  if (!a) throw new Refused(`There is no article ${id}.`, 404);
  const s = await db.one("SELECT * FROM articles_settings WHERE _deleted = 0 ORDER BY _id LIMIT 1") ?? {};
  const blocks = await blocksOf(db, id);
  const infos = blocks.map((b) => import_articore.default.blockInfo(String(b._id), b.markdown));
  const pages = (await db.all("SELECT path FROM articles_site_pages WHERE _deleted = 0")).map((r) => r.path);
  const domain = s.domain || "";
  const ext = [...new Set(infos.flatMap((b) => b.links).map((l) => l.href).filter((h) => !domain || !h.includes(domain)))];
  const external = await linkStatuses(db, ext, fetchLink);
  const notes2 = (await db.all("SELECT _id AS id, text, done FROM articles_notes WHERE article_id = ? AND kind = 'open' AND _deleted = 0", [id])).map((n) => ({ ...n, done: !!n.done }));
  const rules2 = (await db.all("SELECT * FROM articles_rules WHERE status = 'active' AND _deleted = 0")).map((r) => ({ ...r, params: json(r.params, {}), applies_to: json(r.applies_to, ["all"]) }));
  const checks = import_articore.default.runChecks({ title: a.title, seo: seoOf(a), blocks: infos, notes: notes2, site: pages.length ? pages : null, external, rules: rules2, kind: a.kind || "all", plan: json(a.plan, null) || void 0, domain, limits: { titleMax: s.title_max, descMin: s.desc_min, descMax: s.desc_max, keywordMin: s.keyword_min } });
  return { a, blocks, checks, hash: hashOf(blocks, a) };
}
async function check(db, { id }, actor, fetchLink = liveLink) {
  const { a, blocks, checks, hash } = await evaluate(db, id, fetchLink);
  const old = Object.fromEntries((await db.all("SELECT _id, check_id FROM articles_checks WHERE article_id = ? AND _deleted = 0", [id])).map((r) => [r.check_id, r._id]));
  const ops = checks.map((c) => {
    const data = { article_id: id, content_hash: hash, check_id: c.id, grp: c.group, label: c.label, status: c.status, detail: c.detail || null, why: c.why || null, fix: c.fix || null, block_id: c.blockId || null, issues: c.issues ? JSON.stringify(c.issues) : null };
    return old[c.id] ? { op: "update", table: "articles_checks", id: old[c.id], data } : { op: "insert", table: "articles_checks", data };
  });
  const failing = checks.filter((c) => c.status === "fail").length;
  ops.push({ op: "update", table: "articles_articles", id, data: { content_hash: hash, failing } });
  const last = await db.one("SELECT content_hash FROM articles_versions WHERE article_id = ? AND _deleted = 0 ORDER BY _id DESC LIMIT 1", [id]);
  if (blocks.length && (!last || last.content_hash !== hash)) ops.push({ op: "insert", table: "articles_versions", data: { article_id: id, content_hash: hash, title: a.title, seo: JSON.stringify(seoOf(a)), blocks: JSON.stringify(blocks.map((b) => ({ position: b.position, markdown: b.markdown }))), saved_by: actor } });
  await db.batch(ops);
  return { id, content_hash: hash, failing, warnings: checks.filter((c) => c.status === "warn").length, results: checks.filter((c) => c.status !== "pass").map((c) => ({ id: c.id, status: c.status, label: c.label, detail: c.detail, fix: c.fix, block: c.blockId })) };
}
async function details(db, { id }, fetchLink = liveLink) {
  const { checks, hash } = await evaluate(db, id, fetchLink);
  const count = (status) => checks.filter((c) => c.status === status).length;
  return { id, content_hash: hash, failing: count("fail"), warnings: count("warn"), passed: count("pass"), results: checks };
}
async function sendToReview(db, { id, reason }, actor, fetchLink = liveLink) {
  const r = await check(db, { id }, actor, fetchLink);
  const given = reason && reason !== "none" ? String(reason).slice(0, 500) : null;
  if (r.failing && !given) return { ...r, moved: false, why: `${r.failing} checks fail. Fix them, or send it again with a reason.` };
  await db.update("articles_articles", id, { state: "review", review_reason: given });
  return { ...r, moved: true };
}
async function undo(db, { id }) {
  const a = await db.one("SELECT content_hash FROM articles_articles WHERE _id = ?", [id]);
  const versions = await db.all("SELECT * FROM articles_versions WHERE article_id = ? AND _deleted = 0 ORDER BY _id DESC", [id]);
  const target = versions.find((v) => v.content_hash !== a?.content_hash);
  if (!target) return { id, undone: false, why: "There is no earlier version." };
  const rev = now();
  const ops = (await blocksOf(db, id)).map((b) => ({ op: "update", table: "articles_blocks", id: b._id, data: { deleted: 1, rev } }));
  for (const b of json(target.blocks, [])) ops.push({ op: "insert", table: "articles_blocks", data: { article_id: id, position: b.position, markdown: b.markdown, rev, deleted: 0, updated_by: "undo" } });
  await db.batch(ops);
  return { id, undone: true, to: target.content_hash };
}
async function readSite(db, fetchText = (u) => fetch(u, { signal: AbortSignal.timeout(2e4), headers: UA }).then((r) => r.ok ? r.text() : null).catch(() => null)) {
  const s = await db.one("SELECT * FROM articles_settings WHERE _deleted = 0 ORDER BY _id LIMIT 1") ?? {};
  if (!s.domain) return { skipped: "No domain set." };
  const queue = [`https://${s.domain}/sitemap.xml`];
  const seen = /* @__PURE__ */ new Set();
  const pages = /* @__PURE__ */ new Set();
  while (queue.length && seen.size < 50) {
    const u = queue.pop();
    if (seen.has(u)) continue;
    seen.add(u);
    const text = await fetchText(u);
    if (!text) continue;
    for (const m of text.matchAll(/<loc>(.*?)<\/loc>/g)) {
      if (m[1].endsWith(".xml") || m[1].includes("/sitemap/")) queue.push(m[1]);
      else {
        try {
          pages.add(new URL(m[1]).pathname.replace(/\/?$/, "/"));
        } catch {
        }
      }
    }
  }
  if (!pages.size) return { pages: 0, kept: "The sitemap gave nothing: the previous list stays." };
  const have = new Set((await db.all("SELECT path FROM articles_site_pages WHERE _deleted = 0")).map((r) => r.path));
  const add = [...pages].filter((p) => !have.has(p)).map((p) => ({ op: "insert", table: "articles_site_pages", data: { path: p } }));
  await db.batch([...add, { op: "update", table: "articles_settings", id: s._id, data: { sitemap_at: now() } }]);
  return { pages: pages.size };
}

// routes/articles.mjs
var SEO = ["title", "main_query", "meta_title", "meta_description", "slug", "supporting", "persona"];
function articles_default(app, db, deps) {
  command(app, "GET", "/articles", { name: "articles", summary: "The articles." }, () => list(db));
  command(app, "GET", "/articles/:id", { name: "article", on: "article", summary: "One article with its blocks, in order." }, ({ id }) => get(db, id));
  command(app, "POST", "/articles", { name: "create_article", summary: "A new draft.", of: "article", input: ["title", "main_query", "kind", "brief"] }, (i, { actor }) => create(db, i, actor));
  command(app, "POST", "/articles/from-screen", { name: "create_from_screen", of: "article", by: "person", primary: true, then: "articulo/{id}", label: { es: "Art\xEDculo nuevo", en: "New article" }, summary: "A new draft from the screen.", input: ["title", "kind", "main_query", "brief", { local_key: "text" }] }, (i, { actor }) => create(db, i, actor));
  command(app, "POST", "/articles/:id/plan", { name: "set_plan", on: "article", summary: "Save the plan: {angle, reader, facts, links, unknowns, wordMin, wordMax}.", input: { plan: "object" } }, (i) => setPlan(db, i));
  command(app, "POST", "/articles/:id/outline", { name: "set_outline", on: "article", summary: "Save the structure: [{title, points}], empty title for the intro.", input: { outline: "list" } }, (i) => setOutline(db, i));
  command(app, "POST", "/articles/:id/seo", { name: "set_seo", on: "article", summary: "Title, keyword, meta and slug.", input: SEO }, (i) => setSeo(db, i));
  command(app, "POST", "/articles/:id/brief", { name: "set_brief", on: "article", summary: "Kind and brief.", input: ["kind", "brief"] }, (i) => setBrief(db, i));
  command(app, "POST", "/articles/:id/state", { name: "set_state", on: "article", by: "person", summary: "Move it to any state.", input: ["state"] }, (i) => setState(db, i));
  command(app, "POST", "/articles/:id/check", { name: "check", on: "article", summary: "Run the rules now and answer what fails." }, (i, { actor }) => check(db, i, actor, deps.fetchLink));
  command(app, "GET", "/articles/:id/check/details", { name: "check_details", on: "article", summary: "Every check as it stands now, passed ones too, with its group, why and cases. Saves nothing: check is what records." }, (i) => details(db, i, deps.fetchLink));
  command(app, "POST", "/articles/:id/review", { name: "send_to_review", on: "article", summary: "Check, and move to review. If something fails on purpose, say why in reason.", input: { reason: "text" } }, (i, { actor }) => sendToReview(db, i, actor, deps.fetchLink));
  command(app, "POST", "/articles/:id/undo", { name: "undo", on: "article", summary: "Back to the previous version." }, (i) => undo(db, i));
  command(app, "POST", "/articles/:id/reopen", { name: "reopen", on: "article", summary: "From review back to draft." }, (i) => reopen(db, i));
  command(app, "POST", "/articles/:id/approve", { name: "approve", on: "article", by: "person", summary: "Approve it." }, (i) => approve(db, i));
  command(app, "POST", "/articles/:id/publish", { name: "publish", on: "article", by: "person", summary: "Mark it published." }, (i) => publish(db, i));
  command(app, "POST", "/articles/:id/archive", { name: "archive", on: "article", by: "person", confirm: true, label: { es: "Archivar", en: "Archive" }, summary: "Archive it." }, (i) => archive(db, i));
  command(app, "POST", "/site/read", { name: "read_site", summary: "Read the site's pages from its sitemap." }, () => readSite(db, deps.fetchText));
}

// services/blocks.mjs
var T2 = "articles_blocks";
var STALE = "The person changed this block: read it again.";
var insert = (db, input, actor) => db.insert(T2, { ...pick(input, ["article_id", "position", "markdown", "block_key"]), rev: now(), deleted: 0, updated_by: actor }).then((id) => ({ id }));
async function insertMany(db, { article_id, after = null, blocks }, actor) {
  if (!Array.isArray(blocks) || !blocks.length) throw new Refused("blocks is a list of markdown strings, one per heading, paragraph, list or table.", 400);
  const rows = await db.all("SELECT position FROM articles_blocks WHERE article_id = ? AND deleted = 0 AND _deleted = 0 ORDER BY position", [article_id]);
  const start = after ?? (rows.length ? rows[rows.length - 1].position : 0);
  const next = rows.find((r) => r.position > start)?.position ?? start + blocks.length + 1;
  const step = (next - start) / (blocks.length + 1);
  const rev = now();
  const ids = await db.batch(blocks.map((markdown, i) => ({ op: "insert", table: T2, data: { article_id, position: start + step * (i + 1), markdown: String(markdown), rev, deleted: 0, updated_by: actor } })));
  return { ids };
}
var replace = (db, { id, markdown, rev }, actor) => updateIf(db, T2, id, { markdown, rev: now(), updated_by: actor }, { rev }, STALE);
var move2 = (db, { id, position }, actor) => updateIf(db, T2, id, { position, updated_by: actor });
var remove = (db, { id, rev }, actor) => updateIf(db, T2, id, { deleted: 1, rev: now(), updated_by: actor }, { rev }, STALE);

// services/guidance.mjs
var RULE = ["text", "kind", "check_type", "params", "applies_to", "source", "status", "owner", "frequency", "topic"];
var insert2 = (db, t, data) => db.insert(t, data).then((id) => ({ id }));
var notes = {
  list: (db, { id }) => db.all("SELECT * FROM articles_notes WHERE article_id = ? AND _deleted = 0 ORDER BY _id", [id]),
  add: (db, input, actor) => insert2(db, "articles_notes", { ...pick(input, ["article_id", "text"]), kind: "open", done: 0, created_by: actor }),
  forThisArticle: (db, input, actor) => insert2(db, "articles_notes", { ...pick(input, ["article_id", "text"]), kind: "rule", done: 0, created_by: actor }),
  resolve: (db, { id }) => updateIf(db, "articles_notes", id, { done: 1 })
};
var rules = {
  list: (db) => db.all("SELECT * FROM articles_rules WHERE _deleted = 0 ORDER BY frequency DESC, _id"),
  propose: (db, input, actor) => insert2(db, "articles_rules", { ...pick(input, ["text", "applies_to", "topic"]), kind: "guidance", status: "proposed", owner: "client", source: actor }),
  accept: (db, input) => updateIf(db, "articles_rules", input.id, { ...pick(input, ["text", "applies_to", "topic"]), status: "active" }, { status: "proposed" }, "It is no longer proposed."),
  reject: (db, { id }) => updateIf(db, "articles_rules", id, { status: "off" }, { status: "proposed" }, "It is no longer proposed."),
  turn: (status) => (db, { id }) => updateIf(db, "articles_rules", id, { status }),
  import: (db, input) => insert2(db, "articles_rules", pick(input, RULE)),
  update: (db, input) => updateIf(db, "articles_rules", input.id, pick(input, RULE))
};
var kinds = {
  list: (db) => db.all("SELECT * FROM articles_kinds WHERE archived = 0 AND _deleted = 0 ORDER BY position, _id"),
  add: (db, input) => insert2(db, "articles_kinds", { ...pick(input, ["key", "label", "description", "position"]), archived: 0 }),
  update: (db, input) => updateIf(db, "articles_kinds", input.id, pick(input, ["label", "description", "position"])),
  archive: (db, { id }) => updateIf(db, "articles_kinds", id, { archived: 1 })
};
var settings = {
  get: async (db) => await db.one("SELECT * FROM articles_settings WHERE _deleted = 0 ORDER BY _id LIMIT 1") ?? {},
  set: (db, input) => updateIf(db, "articles_settings", input.id, pick(input, ["domain", "language", "method", "title_max", "desc_min", "desc_max", "keyword_min"]))
};

// routes/blocks.mjs
function blocks_default(app, db) {
  command(app, "POST", "/articles/:article_id/blocks", { name: "insert_block", summary: "One heading, paragraph, list or table.", input: { position: "number", markdown: "text", block_key: "text" } }, (i, { actor }) => insert(db, i, actor));
  command(app, "POST", "/articles/:article_id/blocks/many", { name: "insert_blocks", summary: "A whole section at once, in order: faster than one by one.", input: { after: "position, default the end", blocks: "list of markdown" } }, (i, { actor }) => insertMany(db, i, actor));
  command(app, "POST", "/blocks/:id/replace", { name: "replace_block", summary: "Change a block. Refused if the person changed it since you read it.", input: { markdown: "text", rev: "the rev you read" } }, (i, { actor }) => replace(db, i, actor));
  command(app, "POST", "/blocks/:id/move", { name: "move_block", summary: "Move a block.", input: { position: "number" } }, (i, { actor }) => move2(db, i, actor));
  command(app, "POST", "/blocks/:id/delete", { name: "delete_block", summary: "Delete a block.", input: { rev: "the rev you read" } }, (i, { actor }) => remove(db, i, actor));
  command(app, "GET", "/articles/:id/notes", { name: "notes", summary: "Notes of an article." }, (i) => notes.list(db, i));
  command(app, "POST", "/articles/:article_id/notes", { name: "add_note", summary: "Leave something visibly open.", input: { text: "text" } }, (i, { actor }) => notes.add(db, i, actor));
  command(app, "POST", "/articles/:article_id/notes/rule", { name: "note_for_this_article", summary: "A rule for this article only.", input: { text: "text" } }, (i, { actor }) => notes.forThisArticle(db, i, actor));
  command(app, "POST", "/notes/:id/resolve", { name: "resolve_note", summary: "Mark a note done." }, (i) => notes.resolve(db, i));
}

// routes/guidance.mjs
var admin = "admin";
var WRITABLE = ["text", "topic", "applies_to", "params"];
var RULE2 = [...WRITABLE, { kind: "guidance|check", check_type: "text", source: "text", status: "proposed|active|off", owner: "text", frequency: "number" }];
function guidance_default(app, db) {
  command(app, "GET", "/rules", { name: "rules", summary: "The company's rules." }, () => rules.list(db));
  command(app, "POST", "/rules/propose", { name: "propose_rule", of: "rule", summary: "Propose a preference for future articles; it applies once accepted.", input: ["text", "applies_to", "topic"] }, (i, { actor }) => rules.propose(db, i, actor));
  command(app, "POST", "/rules/:id/accept", { name: "accept_rule", on: "rule", when: { status: "proposed" }, by: admin, partial: true, ask: true, label: { es: "Aceptar", en: "Accept" }, summary: "Accept a proposal, as written or changed.", input: ["text", "applies_to", "topic"] }, (i) => rules.accept(db, i));
  command(app, "POST", "/rules/:id/reject", { name: "reject_rule", on: "rule", when: { status: "proposed" }, by: admin, label: { es: "Rechazar", en: "Reject" }, summary: "Reject a proposal." }, (i) => rules.reject(db, i));
  command(app, "POST", "/rules/:id/off", { name: "turn_rule_off", on: "rule", switch: "off", when: { status: "active" }, by: admin, label: { es: "Apagar", en: "Turn off" }, summary: "Turn a rule off." }, (i) => rules.turn("off")(db, i));
  command(app, "POST", "/rules/:id/on", { name: "turn_rule_on", on: "rule", switch: "on", when: { status: "off" }, by: admin, label: { es: "Encender", en: "Turn on" }, summary: "Turn a rule on." }, (i) => rules.turn("active")(db, i));
  command(app, "POST", "/rules/add", { name: "add_rule", of: "rule", by: admin, primary: true, label: { es: "A\xF1adir regla", en: "Add rule" }, summary: "A rule the person writes: guidance for the agent, active at once.", input: ["text", "topic", "applies_to"] }, (i) => rules.import(db, { applies_to: '["all"]', ...i, kind: "guidance", status: "active", owner: "client", source: "person" }));
  command(app, "POST", "/rules/import", { name: "import_rule", by: admin, summary: "Bring in a rule.", input: RULE2 }, (i) => rules.import(db, i));
  command(app, "POST", "/rules/:id", { name: "update_rule", on: "rule", by: admin, partial: true, label: { es: "Editar", en: "Edit" }, summary: "Change a rule.", input: RULE2 }, (i) => rules.update(db, i));
  command(app, "GET", "/kinds", { name: "kinds", summary: "The kinds of article." }, () => kinds.list(db));
  command(app, "POST", "/kinds", { name: "add_kind", of: "kind", by: admin, primary: true, label: { es: "A\xF1adir tipo", en: "Add kind" }, summary: "A new kind.", input: ["key", "label", "description", "position"] }, (i) => kinds.add(db, i));
  command(app, "POST", "/kinds/:id", { name: "update_kind", on: "kind", by: admin, partial: true, label: { es: "Editar", en: "Edit" }, summary: "Change a kind.", input: ["label", "description", "position"] }, (i) => kinds.update(db, i));
  command(app, "POST", "/kinds/:id/archive", { name: "archive_kind", on: "kind", by: admin, confirm: true, label: { es: "Archivar", en: "Archive" }, summary: "Archive a kind." }, (i) => kinds.archive(db, i));
  command(app, "GET", "/settings", { name: "settings", of: "config", summary: "The company's settings for articles." }, () => settings.get(db));
  command(app, "POST", "/settings/:id", { name: "set_settings", on: "config", by: admin, partial: true, summary: "Domain, language, method and limits.", input: ["domain", "language", "method", "title_max", "desc_min", "desc_max", "keyword_min"] }, (i) => settings.set(db, i));
}

// app.mjs
function createApp(db, deps = {}) {
  const app = new Hono2();
  mountErrors(app);
  const d = { fetchLink: liveLink, ...deps };
  articles_default(app, db, d);
  blocks_default(app, db);
  guidance_default(app, db);
  return app;
}

// db.mjs
function dataClient(url = process.env.APP_DATA_URL, token = process.env.APP_DATA_TOKEN) {
  const call = async (path, body) => {
    const r = await fetch(`${url}${path}`, { method: "POST", headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` }, body: JSON.stringify(body) });
    const j = await r.json().catch(() => null);
    if (!r.ok || !j) throw new Error(j?.error ?? `Data ${r.status}`);
    return j;
  };
  return {
    all: async (sql, params = []) => (await call("/all", { sql, params })).rows,
    one: async (sql, params = []) => (await call("/all", { sql, params })).rows[0] ?? null,
    insert: async (table, data) => (await call("/batch", { ops: [{ op: "insert", table, data }] })).ids[0],
    update: async (table, id, data, where = {}) => (await call("/update", { table, id, data, where })).changed,
    batch: async (ops) => (await call("/batch", { ops })).ids
  };
}

// main.mjs
serve({ fetch: createApp(dataClient()).fetch, hostname: "127.0.0.1", port: Number(process.env.PORT) });
