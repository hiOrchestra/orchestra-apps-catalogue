'use strict';
/**
 * Artículos: what an action cannot do by itself, because it needs logic.
 *   check   runs the rules on the current text, writes articles_checks, keeps a version if the text changed
 *   review  checks, then moves to review unless something fails and no reason was given
 *   undo    restores the version before the current text
 *   site    reads the site's real pages from its sitemap
 * Reads the company database directly and read-only; writes only through orch-database batch.
 * ARTICLES_LOCAL=1 runs against ARTICLES_DB for the tests, with no network.
 */
const { DatabaseSync } = require('node:sqlite');
const { execFileSync } = require('child_process');
const crypto = require('crypto');
const path = require('path');
const Core = require('./articore');

const STATE = process.env.OPENCLAW_STATE_DIR || '/home/node/.openclaw';
const DB_PATH = process.env.ARTICLES_DB || path.join(STATE, 'orchestra', 'data', 'company.db');
const LOCAL = process.env.ARTICLES_LOCAL === '1';

const db = () => { const d = new DatabaseSync(DB_PATH, { readOnly: !LOCAL }); d.exec('PRAGMA busy_timeout = 5000'); return d; };
const rd = db();
const all = (sql, ...p) => rd.prepare(sql).all(...p);
const one = (sql, ...p) => rd.prepare(sql).get(...p);
const json = (t, d) => { if (!t) return d; try { return JSON.parse(t); } catch { return d; } };

function batch(ops) {
  if (!ops.length) return;
  if (LOCAL) {
    const w = new DatabaseSync(DB_PATH);
    w.exec('BEGIN');
    for (const op of ops) {
      const data = { ...op.data };
      if (op.op === 'insert') {
        const k = Object.keys(data);
        w.prepare(`INSERT INTO "${op.table}" (${k.map((x) => `"${x}"`).join(',')}) VALUES (${k.map(() => '?').join(',')})`).run(...k.map((x) => data[x]));
      } else {
        const k = Object.keys(data);
        w.prepare(`UPDATE "${op.table}" SET ${k.map((x) => `"${x}" = ?`).join(',')} WHERE _id = ?`).run(...k.map((x) => data[x]), op.id);
      }
    }
    w.exec('COMMIT');
    w.close();
    return;
  }
  // Large articles: a batch argument has a size limit.
  let cur = []; let size = 0; const chunks = [];
  for (const op of ops) {
    const n = JSON.stringify(op).length;
    if (cur.length && size + n > 90000) { chunks.push(cur); cur = []; size = 0; }
    cur.push(op); size += n;
  }
  if (cur.length) chunks.push(cur);
  for (const c of chunks) execFileSync('orch-database', ['batch', '--ops', JSON.stringify(c)], { encoding: 'utf8', timeout: 60000, maxBuffer: 16 << 20 });
}

const blocksOf = (id) => all('SELECT _id, position, markdown FROM articles_blocks WHERE article_id = ? AND deleted = 0 AND _deleted = 0 ORDER BY position, _id', id);
const hashOf = (blocks, a) => crypto.createHash('sha1').update(JSON.stringify([blocks.map((b) => b.markdown), a.title, a.main_query, a.meta_title, a.meta_description, a.slug])).digest('hex').slice(0, 16);
const seoOf = (a) => ({ mainQuery: a.main_query || '', metaTitle: a.meta_title || '', metaDescription: a.meta_description || '', slug: a.slug || '', supporting: a.supporting || '', persona: a.persona || '' });
const rulesOf = () => all("SELECT * FROM articles_rules WHERE status = 'active' AND _deleted = 0").map((r) => ({
  ...r, params: json(r.params, {}), applies_to: json(r.applies_to, ['all']),
}));

async function linkStatuses(urls) {
  const known = {};
  for (const r of all('SELECT url, status, checked_at FROM articles_links WHERE _deleted = 0')) known[r.url] = r;
  const out = {}; const ops = [];
  await Promise.all(urls.slice(0, 40).map(async (u) => {
    const k = known[u];
    if (k && Date.now() - Date.parse(k.checked_at) < 7 * 86400_000) { out[u] = k.status; return; }
    if (LOCAL) { out[u] = 200; return; }
    const status = await fetch(u, { method: 'GET', redirect: 'follow', signal: AbortSignal.timeout(10000), headers: { 'User-Agent': 'Mozilla/5.0 (compatible; OrchestraArticles)' } }).then((r) => r.status).catch(() => null);
    out[u] = status;
    const data = { url: u, status, checked_at: new Date().toISOString() };
    ops.push(k ? { op: 'update', table: 'articles_links', id: k._id, data } : { op: 'insert', table: 'articles_links', data });
  }));
  batch(ops);
  return out;
}

async function evaluate(id) {
  const a = one('SELECT * FROM articles_articles WHERE _id = ? AND _deleted = 0', id);
  if (!a) throw new Error(`No article ${id}`);
  const settings = one('SELECT * FROM articles_settings WHERE _deleted = 0 ORDER BY _id LIMIT 1') || {};
  const blocks = blocksOf(id);
  const infos = blocks.map((b) => Core.blockInfo(String(b._id), b.markdown));
  const pages = all('SELECT path FROM articles_site_pages WHERE _deleted = 0').map((r) => r.path);
  const domain = settings.domain || '';
  const ext = [...new Set(infos.flatMap((b) => b.links).map((l) => l.href).filter((h) => !domain || !h.includes(domain)))];
  const external = await linkStatuses(ext);
  const notes = all('SELECT _id AS id, text, done FROM articles_notes WHERE article_id = ? AND kind = ? AND _deleted = 0', id, 'open').map((n) => ({ ...n, done: !!n.done }));
  const checks = Core.runChecks({ title: a.title, seo: seoOf(a), blocks: infos, notes, site: pages.length ? pages : null, external, rules: rulesOf(), kind: a.kind || 'all', plan: json(a.plan, null) || undefined, domain });
  return { a, blocks, checks, hash: hashOf(blocks, a) };
}

async function check(id) {
  const { a, blocks, checks, hash } = await evaluate(id);
  // One row per check per article, updated in place: rows of a check that no longer runs keep the old hash, so they read as stale.
  const old = Object.fromEntries(all('SELECT _id, check_id FROM articles_checks WHERE article_id = ? AND _deleted = 0', id).map((r) => [r.check_id, r._id]));
  const ops = checks.map((c) => {
    const data = { article_id: id, content_hash: hash, check_id: c.id, grp: c.group, label: c.label, status: c.status, detail: c.detail || null, why: c.why || null, fix: c.fix || null, block_id: c.blockId || null, issues: c.issues ? JSON.stringify(c.issues) : null };
    return old[c.id] ? { op: 'update', table: 'articles_checks', id: old[c.id], data } : { op: 'insert', table: 'articles_checks', data };
  });
  const failing = checks.filter((c) => c.status === 'fail').length;
  ops.push({ op: 'update', table: 'articles_articles', id, data: { content_hash: hash, failing } });
  const last = one('SELECT content_hash FROM articles_versions WHERE article_id = ? AND _deleted = 0 ORDER BY _id DESC LIMIT 1', id);
  if (blocks.length && (!last || last.content_hash !== hash)) {
    ops.push({ op: 'insert', table: 'articles_versions', data: { article_id: id, content_hash: hash, title: a.title, seo: JSON.stringify(seoOf(a)), blocks: JSON.stringify(blocks.map((b) => ({ position: b.position, markdown: b.markdown }))), saved_by: process.env.ORCHESTRA_ACTOR || null } });
  }
  batch(ops);
  return { id, content_hash: hash, failing, warnings: checks.filter((c) => c.status === 'warn').length };
}

async function review(id, reason) {
  const r = await check(id);
  const given = reason && reason !== 'none' ? String(reason).slice(0, 500) : null;
  if (r.failing && !given) return { ...r, moved: false, why: `${r.failing} checks fail. Fix them, or send it again with a reason.` };
  batch([{ op: 'update', table: 'articles_articles', id, data: { state: 'review', review_reason: given } }]);
  return { ...r, moved: true };
}

function undo(id) {
  const a = one('SELECT content_hash FROM articles_articles WHERE _id = ?', id);
  const versions = all('SELECT * FROM articles_versions WHERE article_id = ? AND _deleted = 0 ORDER BY _id DESC', id);
  const target = versions.find((v) => v.content_hash !== (a && a.content_hash));
  if (!target) return { id, undone: false, why: 'There is no earlier version.' };
  const now = new Date().toISOString();
  const ops = blocksOf(id).map((b) => ({ op: 'update', table: 'articles_blocks', id: b._id, data: { deleted: 1, rev: now } }));
  for (const b of json(target.blocks, [])) ops.push({ op: 'insert', table: 'articles_blocks', data: { article_id: id, position: b.position, markdown: b.markdown, rev: now, deleted: 0, updated_by: 'undo' } });
  batch(ops);
  return { id, undone: true, to: target.content_hash };
}

async function site() {
  const settings = one('SELECT * FROM articles_settings WHERE _deleted = 0 ORDER BY _id LIMIT 1') || {};
  if (!settings.domain) return { skipped: 'No domain set.' };
  const queue = [`https://${settings.domain}/sitemap.xml`]; const seen = new Set(); const pages = new Set();
  while (queue.length && seen.size < 50) {
    const u = queue.pop();
    if (seen.has(u)) continue;
    seen.add(u);
    const r = await fetch(u, { signal: AbortSignal.timeout(20000), headers: { 'User-Agent': 'Mozilla/5.0 (compatible; OrchestraArticles)' } }).catch(() => null);
    if (!r || !r.ok) continue;
    for (const m of (await r.text()).matchAll(/<loc>(.*?)<\/loc>/g)) {
      if (m[1].endsWith('.xml') || m[1].includes('/sitemap/')) queue.push(m[1]);
      else { try { pages.add(new URL(m[1]).pathname.replace(/\/?$/, '/')); } catch { /* not a URL */ } }
    }
  }
  if (!pages.size) return { pages: 0, kept: 'The sitemap gave nothing: the previous list stays.' };
  const have = new Set(all('SELECT path FROM articles_site_pages WHERE _deleted = 0').map((r) => r.path));
  batch([...pages].filter((p) => !have.has(p)).map((p) => ({ op: 'insert', table: 'articles_site_pages', data: { path: p } })));
  batch([{ op: 'update', table: 'articles_settings', id: settings._id, data: { sitemap_at: new Date().toISOString() } }]);
  return { pages: pages.size };
}

if (require.main === module) {
  const arg = (n) => { const i = process.argv.indexOf(`--${n}`); return i > 0 ? process.argv[i + 1] : undefined; };
  const cmd = process.argv[2];
  const id = Number(arg('id'));
  const run = { check: () => check(id), review: () => review(id, arg('reason')), undo: () => undo(id), site: () => site() }[cmd];
  if (!run) { console.error('check | review | undo | site'); process.exit(2); }
  Promise.resolve().then(run).then((r) => console.log(JSON.stringify(r))).catch((e) => { console.error(e.message); process.exit(1); });
}

module.exports = { evaluate, check, review, undo, site };
