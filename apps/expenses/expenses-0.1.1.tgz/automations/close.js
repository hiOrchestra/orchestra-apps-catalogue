'use strict';
/**
 * Expenses · Close the month. A script, no agent. For a month a person asked
 * to close (ex_months status Closing, claimed → Working):
 *
 *   1. its Approved expenses, and their receipts from Files;
 *   2. one PDF: the summary (per currency: totals, VAT per rate, per category,
 *      owed back to people; with Invoices in the project, what was invoiced
 *      and its VAT beside it), the list, then every receipt — a photo or a
 *      mail on its own page, a PDF receipt behind a one-line cover page (qpdf
 *      puts the original pages there, untouched);
 *   3. the CSV;
 *   4. both saved in Files (folder "Expenses", this project), and sealed in
 *      ex_links for the accountant's page (the month's token, kept when the
 *      month is closed again, so an old link gets the new files); the month
 *      Closed with their ids and the summary;
 *   5. when the person pressed Send (send_asked_at after the last send), the
 *      email to the accountant (Approved: their click) with the link, which
 *      send.js sends. No attachments: neither Composio send takes bytes.
 *
 * A failure leaves the month Open with the reason (close_note): Close again.
 *   node close.js [--auto|--check]
 */
const { execFileSync } = require('child_process');
const fs = require('fs');
const os = require('os');
const path = require('path');
const L = require('./lib');
const C = require('./excore');
const { toPdf } = require('./pdf');

const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const FIT = `
import sys, base64, io
from PIL import Image, ImageOps
im = ImageOps.exif_transpose(Image.open(sys.argv[1])).convert('RGB')
im.thumbnail((1400, 1400))
b = io.BytesIO(); im.save(b, 'JPEG', quality=80, optimize=True)
sys.stdout.write('data:image/jpeg;base64,' + base64.b64encode(b.getvalue()).decode())
`;
const photo = (file) => execFileSync(process.env.EX_PYTHON || 'python3', ['-c', FIT, file], { encoding: 'utf8', timeout: 60000, maxBuffer: 32 << 20 });
const pages = (file) => Number(execFileSync('qpdf', ['--show-npages', file], { encoding: 'utf8', timeout: 30000 }).trim());

/** What Invoices says about the month, when it is in the project: per currency { total, tax, count }. */
function invoiced(month) {
  try {
    const rows = L.all(`SELECT currency, COUNT(*) AS n, SUM(total) AS total, SUM(tax_total) AS tax FROM inv_documents
      WHERE _deleted = 0 AND kind = 'invoice' AND status IN ('Issued', 'Paid') AND substr(issue_date, 1, 7) = ? GROUP BY currency`, month);
    return Object.fromEntries(rows.map((r) => [r.currency || 'EUR', { count: r.n, total: Number(r.total) || 0, tax: Number(r.tax) || 0 }]));
  } catch { return null; }
}

function css() {
  return `@page { size: A4; margin: 16mm 15mm; }
body { font-family: "Geist", "Helvetica Neue", Arial, "DejaVu Sans", sans-serif; font-size: 10.5px; color: #1b1b1a; margin: 0; }
h1 { font-family: Georgia, "DejaVu Serif", serif; font-weight: 600; font-size: 22px; margin: 0 0 2px; }
h2 { font-size: 11px; text-transform: uppercase; letter-spacing: .06em; color: #4a4943; margin: 18px 0 6px; }
.sub { color: #6b6a63; margin: 0 0 14px; }
table { border-collapse: collapse; width: 100%; }
th, td { text-align: left; padding: 4px 6px; border-bottom: 1px solid #e6e3da; vertical-align: top; }
th { font-weight: 600; color: #4a4943; background: #f6f5f1; }
.r { text-align: right; font-variant-numeric: tabular-nums; white-space: nowrap; }
.big td { font-size: 12px; }
.tot td { font-weight: 600; border-top: 1px solid #1b1b1a; }
.page { break-before: page; }
.cover { display: flex; flex-direction: column; justify-content: flex-start; height: 255mm; overflow: hidden; }
.cover h3 { font-size: 14px; margin: 0 0 4px; }
.cover .meta { color: #4a4943; margin-bottom: 10px; }
.cover img { display: block; width: auto; height: auto; max-width: 100%; max-height: 225mm; align-self: flex-start; border: 1px solid #e6e3da; }
.cover pre { white-space: pre-wrap; font-family: "DejaVu Sans Mono", Menlo, monospace; font-size: 9.5px; border: 1px solid #e6e3da; padding: 10px; }
.note { color: #6b6a63; font-size: 9.5px; margin-top: 10px; }`;
}

function html({ s, month, expenses, sums, inv, sections }) {
  const lang = C.langOf(s.language);
  const es = lang === 'es';
  const W = es ? { title: 'Gastos', of: 'de', count: 'gastos aprobados', cat: 'Por categoría', vat: 'IVA soportado por tipo', base: 'Base', vatAmt: 'IVA', total: 'Total',
    owed: 'A reembolsar', list: 'La lista', date: 'Fecha', vendor: 'Proveedor', category: 'Categoría', paid: 'Pagó', receipt: 'Recibo', company: 'la empresa', inv: 'Facturado este mes (Invoices)',
    invVat: 'IVA repercutido', expVat: 'IVA soportado', diff: 'Diferencia', noTax: 'sin IVA desglosado', rate: 'Tipo', follows: 'El recibo original sigue en las páginas siguientes.' }
    : { title: 'Expenses', of: 'for', count: 'approved expenses', cat: 'By category', vat: 'Input VAT by rate', base: 'Net', vatAmt: 'VAT', total: 'Total',
      owed: 'Owed back', list: 'The list', date: 'Date', vendor: 'Vendor', category: 'Category', paid: 'Paid by', receipt: 'Receipt', company: 'the company', inv: 'Invoiced this month (Invoices)',
      invVat: 'Output VAT', expVat: 'Input VAT', diff: 'Difference', noTax: 'with no VAT shown', rate: 'Rate', follows: 'The original receipt follows on the next pages.' };
  const cat = (c) => (es && C.CATEGORIES_ES[c]) || c;
  const m = (n, cur) => esc(C.money(n, cur, es ? 'es-ES' : 'en-GB'));
  const blocks = sums.map((u) => `
<h2>${esc(u.currency)}</h2>
<table class="big"><tr><td>${W.total}</td><td class="r">${m(u.total, u.currency)}</td></tr><tr><td>${W.base}</td><td class="r">${m(u.net, u.currency)}</td></tr>
<tr><td>${W.vatAmt}</td><td class="r">${m(u.tax, u.currency)}</td></tr>${u.noTax ? `<tr><td>${W.total} ${W.noTax}</td><td class="r">${m(u.noTax, u.currency)}</td></tr>` : ''}</table>
<h2>${W.cat}</h2><table><tr><th>${W.category}</th><th class="r">#</th><th class="r">${W.vatAmt}</th><th class="r">${W.total}</th></tr>
${Object.entries(u.byCategory).sort((a, b) => b[1].total - a[1].total).map(([k, v]) => `<tr><td>${esc(cat(k))}</td><td class="r">${v.count}</td><td class="r">${m(v.tax, u.currency)}</td><td class="r">${m(v.total, u.currency)}</td></tr>`).join('')}</table>
<h2>${W.vat}</h2><table><tr><th>${W.rate}</th><th class="r">${W.base}</th><th class="r">${W.vatAmt}</th></tr>
${Object.entries(u.byRate).map(([k, v]) => `<tr><td>${esc(k)}${k === '?' ? '' : ' %'}</td><td class="r">${m(v.net, u.currency)}</td><td class="r">${m(v.tax, u.currency)}</td></tr>`).join('')}</table>
${inv && inv[u.currency] ? `<h2>${W.inv}</h2><table><tr><td>${W.total}</td><td class="r">${m(inv[u.currency].total, u.currency)}</td></tr><tr><td>${W.invVat}</td><td class="r">${m(inv[u.currency].tax, u.currency)}</td></tr>
<tr><td>${W.expVat}</td><td class="r">${m(u.tax, u.currency)}</td></tr><tr class="tot"><td>${W.diff}</td><td class="r">${m(inv[u.currency].tax - u.tax, u.currency)}</td></tr></table>` : ''}
${Object.keys(u.reimburse).length ? `<h2>${W.owed}</h2><table>${Object.entries(u.reimburse).map(([k, v]) => `<tr><td>${esc(k)}</td><td class="r">${m(v, u.currency)}</td></tr>`).join('')}</table>` : ''}`).join('');
  const list = `<h2>${W.list}</h2><table><tr><th>#</th><th>${W.date}</th><th>${W.vendor}</th><th>${W.category}</th><th>${W.paid}</th><th class="r">${W.vatAmt}</th><th class="r">${W.total}</th></tr>
${expenses.map((e, i) => `<tr><td>${i + 1}</td><td>${esc(e.date)}</td><td>${esc(e.vendor)}${e.number ? `<br><span class="note">${esc(e.number)}</span>` : ''}</td><td>${esc(cat(e.category))}</td><td>${esc(e.paid_by === 'company' || !e.paid_by ? W.company : e.paid_by)}</td><td class="r">${e.tax === null || e.tax === undefined ? '—' : m(e.tax, e.currency)}</td><td class="r">${m(e.total, e.currency)}</td></tr>`).join('')}</table>`;
  const covers = sections.map((x) => `<section class="page cover"><h3>#${x.n} · ${esc(x.e.vendor)}</h3><div class="meta">${esc(x.e.date)} · ${m(x.e.total, x.e.currency)}${x.e.receipt_name ? ` · ${esc(x.e.receipt_name)}` : ''}</div>
${x.image ? `<img src="${x.image}" alt="">` : x.text ? `<pre>${esc(x.text)}</pre>` : x.pdf ? `<p class="note">${W.follows}</p>` : '<p class="note">—</p>'}</section>`).join('');
  return `<!doctype html><html lang="${lang}"><head><meta charset="utf-8"><title>${esc(W.title)} ${esc(month)}</title><style>${css()}</style></head><body>
<h1>${esc(W.title)} ${W.of} ${esc(C.monthName(month, lang))}</h1><p class="sub">${esc(s.company_name || '')} · ${expenses.length} ${W.count}</p>
${blocks}${list}${covers}</body></html>`;
}

async function closeOne(s, mo) {
  const expenses = L.all(`SELECT e.*, r.file_id AS receipt_file, r.file_name AS receipt_name, r.file_type AS receipt_type, r.text AS receipt_text, r.kind AS receipt_kind
    FROM ex_expenses e LEFT JOIN ex_receipts r ON r._id = e.receipt_id WHERE e._deleted = 0 AND e.status = 'Approved' AND e.month = ? ORDER BY e.date, e._id`, mo.month);
  if (!expenses.length) throw new Error(`No approved expenses in ${mo.month}: approve them first (To review), then close.`);
  const work = fs.mkdtempSync(path.join(os.tmpdir(), 'expenses-close-'));
  try {
    const sections = [];
    for (const [i, e] of expenses.entries()) {
      const x = { n: i + 1, e };
      if (e.receipt_type === 'text' || e.receipt_kind === 'text' && !e.receipt_file) x.text = String(e.receipt_text || '').slice(0, 3500);
      else if (e.receipt_file) {
        const file = path.join(work, `r${i}.${e.receipt_type || 'pdf'}`);
        const got = L.fileDownload(e.receipt_file, file);
        if (!got.ok) x.missing = true;
        else if (e.receipt_type === 'pdf') x.pdf = file;
        else x.image = photo(file);
      }
      sections.push(x);
    }
    const sums = C.summary(expenses);
    const inv = invoiced(mo.month);
    const summaryPdf = path.join(work, 'summary.pdf');
    fs.writeFileSync(summaryPdf, await toPdf(html({ s, month: mo.month, expenses, sums, inv, sections })));
    // The summary's own pages, then each cover page and, behind it, the receipt's PDF.
    const total = pages(summaryPdf);
    const head = total - sections.length;
    const args = ['--empty', '--pages', summaryPdf, `1-${head}`];
    sections.forEach((x, i) => { args.push(summaryPdf, String(head + i + 1)); if (x.pdf) args.push(x.pdf, '1-z'); });
    const finalPdf = path.join(work, 'final.pdf');
    execFileSync('qpdf', [...args, '--', finalPdf], { timeout: 120000 });
    const name = `${s.language === 'es' ? 'Gastos' : 'Expenses'} ${mo.month}`;
    const pdfUp = L.fileUpload({ name, type: 'pdf', bytes: fs.readFileSync(finalPdf), folder: 'Expenses', description: `Expenses of ${mo.month}: summary and every receipt` });
    if (!pdfUp.ok) throw new Error(`Files did not take the PDF: ${pdfUp.why}`);
    const csvUp = L.fileUpload({ name, type: 'csv', bytes: Buffer.from(C.csv(expenses), 'utf8'), folder: 'Expenses', description: `Expenses of ${mo.month}, one line each` });
    if (!csvUp.ok) throw new Error(`Files did not take the CSV: ${csvUp.why}`);
    return { pdf: pdfUp.file, csv: csvUp.file, name, sums, inv, count: expenses.length, pages: pages(finalPdf),
      pdfB64: fs.readFileSync(finalPdf).toString('base64'), csvB64: Buffer.from(C.csv(expenses), 'utf8').toString('base64') };
  } finally { fs.rmSync(work, { recursive: true, force: true }); }
}

/** The month for its accountant's page: its state and both files, sealed with the month's token. */
async function sealMonth(s, mo, r) {
  const token = C.TOKEN.test(mo.token || '') ? mo.token : C.newToken();
  const lang = s.language === 'es' ? 'es' : 'en';
  const pdfParts = C.chunks(r.pdfB64);
  const csvParts = C.chunks(r.csvB64);
  const state = { v: 1, lang, company: s.company_name || '', month: mo.month, monthName: C.monthName(mo.month, lang), count: r.count, closed_at: L.isoZ(),
    totals: r.sums.map((u) => ({ currency: u.currency, total: u.total, tax: u.tax })),
    pdf: { name: `${r.name}.pdf`, parts: pdfParts.length, size: Math.round(r.pdfB64.length * 0.75) },
    csv: { name: `${r.name}.csv`, parts: csvParts.length } };
  const rows = [[C.PART.state, state], ...pdfParts.map((x, i) => [C.PART.pdf(i), x]), ...csvParts.map((x, i) => [C.PART.csv(i), x])];
  const ops = [];
  for (const [part, value] of rows) ops.push({ op: 'insert', table: 'ex_links', data: { month_id: mo._id, part, k: await C.linkKey(token, part), box: await C.seal(token, value), built_at: L.sqlNow() } });
  // The same token finds the same keys: the old version goes first (a page open meanwhile says to look again).
  L.softDelete('ex_links', L.all('SELECT _id FROM ex_links WHERE _deleted = 0 AND month_id = ?', mo._id).map((x) => x._id));
  L.write(ops);
  return token;
}

async function run(mode = '--auto') {
  if (mode === '--check') return { ok: true, mode, skipped: 'send.js checks Resend' };
  const held = L.lock('close');
  if (!held) return { ok: true, skipped: 'Another run is closing' };
  try {
    const s = L.settings();
    const out = { ok: true, closed: 0, failed: 0, emails: 0 };
    for (const mo of L.all("SELECT * FROM ex_months WHERE _deleted = 0 AND status = 'Closing' ORDER BY month LIMIT 3")) {
      try { L.write([{ op: 'update', table: 'ex_months', id: mo._id, when: { status: 'Closing' }, data: { status: 'Working' } }]); } catch { continue; }
      let r;
      let token;
      try { r = await closeOne(s, mo); token = await sealMonth(s, mo, r); } catch (e) {
        L.write([{ op: 'update', table: 'ex_months', id: mo._id, data: { status: 'Open', close_note: String(e.message).slice(0, 400) } }]);
        out.failed += 1;
        continue;
      }
      L.write([{ op: 'update', table: 'ex_months', id: mo._id, data: { status: 'Closed', closed_at: L.isoZ(), close_note: null, count: r.count, token,
        pdf_file_id: r.pdf.id, pdf_name: `${r.name}.pdf`, csv_file_id: r.csv.id, csv_name: `${r.name}.csv`, summary: JSON.stringify({ sums: r.sums, invoiced: r.inv, pages: r.pages }) } }]);
      out.closed += 1;
    }
    // A Send pressed on a closed month: the email, approved by that click.
    for (const mo of L.all("SELECT * FROM ex_months WHERE _deleted = 0 AND status = 'Closed' AND send_asked_at IS NOT NULL AND (sent_at IS NULL OR datetime(send_asked_at) > datetime(sent_at))")) {
      if (L.one("SELECT 1 AS x FROM ex_emails WHERE _deleted = 0 AND month_id = ? AND status IN ('Approved', 'Sending')", mo._id)) continue;
      if (L.one("SELECT 1 AS x FROM ex_emails WHERE _deleted = 0 AND month_id = ? AND status IN ('Sent', 'Failed') AND datetime(_created_at) >= datetime(?)", mo._id, mo.send_asked_at)) continue;
      if (!C.isEmail(mo.send_to)) { L.write([{ op: 'update', table: 'ex_months', id: mo._id, data: { send_note: 'No valid address for the accountant: nothing was sent.' } }]); continue; }
      if (!s.public_url || !C.TOKEN.test(mo.token || '')) { L.write([{ op: 'update', table: 'ex_months', id: mo._id, data: { send_note: 'The accountant\'s page is not installed (or this month has no link yet): install Expenses again, close the month again, then Send.' } }]); continue; }
      const sum = L.jsonOf(mo.summary, {});
      const totals = (sum.sums || []).map((u) => C.money(u.total, u.currency, s.language === 'es' ? 'es-ES' : 'en-GB')).join(' + ') || '—';
      const m = C.mail(s.language, { company: s.company_name, name: s.accountant_name, month: C.monthName(mo.month, s.language), count: mo.count || 0, totals, link: `${s.public_url}#${mo.token}` });
      L.write([{ op: 'insert', table: 'ex_emails', data: { month_id: mo._id, to_email: C.normEmail(mo.send_to), subject: m.subject, body: m.body, status: 'Approved', approved_by: mo.closed_by || '' } }]);
      out.emails += 1;
    }
    return out;
  } finally { held.release(); }
}

if (require.main === module) {
  const a = process.argv.slice(2);
  run(a.includes('--check') ? '--check' : '--auto').then((r) => L.done(r), (e) => { L.done({ ok: false, error: e.message }); process.exitCode = 1; });
}
module.exports = { run, html, closeOne, invoiced, sealMonth };
