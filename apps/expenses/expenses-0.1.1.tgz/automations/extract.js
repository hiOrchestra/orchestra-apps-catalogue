'use strict';
/**
 * Expenses · what a receipt file holds, before anyone reads it:
 *
 *   PDF with text   → its text (pdftotext -layout, the first 3 pages): read by
 *                     the cheap model (read.js)
 *   scanned PDF     → its first 2 pages as images (pdftoppm): read by the agent
 *   photo           → turned upright (EXIF), at most 1600 px, JPEG: the agent
 *   email body      → its text
 *
 * and for every one a small JPEG preview (≤ 80 KB, data URL) the desk shows
 * beside the form, because a page cannot read Files. Images go in look/ next
 * to the scripts, where the agent can open them (the project's ACL).
 *
 *   extract(file, type, { id }) → { kind: 'text'|'image', text, images: [paths], preview }
 */
const { execFileSync } = require('child_process');
const fs = require('fs');
const os = require('os');
const path = require('path');
const L = require('./lib');

const IMAGE_TYPES = ['png', 'jpg', 'jpeg', 'webp', 'gif'];
const TYPES = ['pdf', ...IMAGE_TYPES];
const LOOK = () => process.env.EX_LOOK || path.join(L.HOME, 'look');
const PREVIEW_MAX = 80000;

// Pillow, in one small program: fit inside `max` px, upright, JPEG at `quality`.
const FIT = `
import sys
from PIL import Image, ImageOps
src, dst, mx, q = sys.argv[1], sys.argv[2], int(sys.argv[3]), int(sys.argv[4])
im = Image.open(src)
im = ImageOps.exif_transpose(im)
if im.mode in ('RGBA', 'LA', 'P'):
    bg = Image.new('RGB', im.size, (255, 255, 255))
    im = im.convert('RGBA')
    bg.paste(im, mask=im.split()[-1])
    im = bg
else:
    im = im.convert('RGB')
im.thumbnail((mx, mx))
im.save(dst, 'JPEG', quality=q, optimize=True)
print(im.size[0], im.size[1])
`;
function fit(src, dst, max, quality) {
  execFileSync(process.env.EX_PYTHON || 'python3', ['-c', FIT, src, dst, String(max), String(quality)], { timeout: 60000, stdio: ['ignore', 'pipe', 'pipe'] });
  return dst;
}

/** A JPEG data URL of the picture, made smaller until it is under 80 KB. */
function previewOf(image) {
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'expenses-prev-'));
  try {
    for (const [max, q] of [[900, 70], [700, 60], [520, 55], [400, 50]]) {
      const out = fit(image, path.join(dir, `p${max}.jpg`), max, q);
      const b = fs.readFileSync(out);
      const url = `data:image/jpeg;base64,${b.toString('base64')}`;
      if (url.length <= PREVIEW_MAX) return url;
    }
    return '';
  } finally { fs.rmSync(dir, { recursive: true, force: true }); }
}

function pdfText(file) {
  try { return execFileSync('pdftotext', ['-layout', '-l', '3', file, '-'], { encoding: 'utf8', timeout: 60000, maxBuffer: 16 << 20 }); } catch (e) {
    throw new Error(`The PDF could not be opened: ${String(e.stderr || e.message).trim().slice(0, 160)}`);
  }
}
/** The first `pages` pages of a PDF as PNGs in `dir`, at `dpi`. */
function pdfPages(file, dir, dpi, pages) {
  execFileSync('pdftoppm', ['-r', String(dpi), '-png', '-f', '1', '-l', String(pages), file, path.join(dir, 'page')], { timeout: 90000 });
  return fs.readdirSync(dir).filter((f) => /^page-\d+\.png$/.test(f)).sort().map((f) => path.join(dir, f));
}
const meaningful = (t) => String(t || '').replace(/\s+/g, '').length;

function extract(file, type, { id } = {}) {
  const t = String(type || '').toLowerCase();
  if (!TYPES.includes(t)) throw Object.assign(new Error(`A .${t} file is not a receipt this app reads: use PDF, JPG, PNG or WebP`), { unsupported: true });
  const work = fs.mkdtempSync(path.join(os.tmpdir(), 'expenses-x-'));
  try {
    let pages = [];
    let text = '';
    if (t === 'pdf') {
      text = pdfText(file);
      pages = pdfPages(file, work, meaningful(text) >= 40 ? 60 : 150, meaningful(text) >= 40 ? 1 : 2);
      if (!pages.length) throw new Error('The PDF has no pages');
    }
    const first = t === 'pdf' ? pages[0] : file;
    const preview = previewOf(first);
    if (t === 'pdf' && meaningful(text) >= 40) return { kind: 'text', text: text.replace(/[ \t]+\n/g, '\n').replace(/\n{3,}/g, '\n\n').trim().slice(0, 12000), images: [], preview };
    // An image for the agent's eyes: upright, readable, not huge.
    fs.mkdirSync(LOOK(), { recursive: true });
    const sources = t === 'pdf' ? pages : [file];
    const images = sources.map((src, i) => fit(src, path.join(LOOK(), `${id || 'r'}-${i + 1}.jpg`), 1600, 82));
    return { kind: 'image', text: '', images, preview };
  } finally { fs.rmSync(work, { recursive: true, force: true }); }
}

module.exports = { extract, previewOf, TYPES, IMAGE_TYPES, LOOK };
