'use strict';
/**
 * Expenses · HTML → PDF with the instance's own Chromium, the one Files prints
 * with (DevTools on 127.0.0.1:18800, kept up by the entrypoint's
 * supervisor): a tab, the HTML set as its document, every image loaded, then
 * Page.printToPDF (A4, the page's own @page margins, no header or footer).
 * When that browser does not answer, a Chrome binary prints instead
 * (EX_CHROME, or the Playwright one under PLAYWRIGHT_BROWSERS_PATH).
 *
 *   toPdf(html) → Buffer   (throws with a plain reason)
 */
const { spawn } = require('child_process');
const fs = require('fs');
const os = require('os');
const path = require('path');
const http = require('http');

const PORT = Number(process.env.EX_CDP_PORT || 18800);

function cdpHttp(route, method = 'PUT', timeoutMs = 4000) {
  return new Promise((resolve, reject) => {
    const req = http.request({ hostname: '127.0.0.1', port: PORT, path: route, method, timeout: timeoutMs }, (res) => {
      let body = '';
      res.on('data', (c) => { body += c; });
      res.on('end', () => { try { resolve(body.trim() ? JSON.parse(body) : null); } catch (e) { reject(e); } });
    });
    req.on('timeout', () => req.destroy(new Error('the browser did not answer')));
    req.on('error', reject);
    req.end();
  });
}

async function viaCdp(html) {
  const target = await cdpHttp('/json/new');
  if (!target || !target.webSocketDebuggerUrl) throw new Error('the browser gave no tab');
  const ws = new WebSocket(target.webSocketDebuggerUrl);
  let n = 0;
  const waiting = new Map();
  ws.onmessage = (ev) => { const m = JSON.parse(ev.data); if (m.id && waiting.has(m.id)) { const w = waiting.get(m.id); waiting.delete(m.id); if (m.error) w.reject(new Error(m.error.message)); else w.resolve(m.result); } };
  const send = (method, params = {}, ms = 30000) => new Promise((resolve, reject) => {
    n += 1;
    const id = n;
    const t = setTimeout(() => { waiting.delete(id); reject(new Error(`${method} timed out`)); }, ms);
    waiting.set(id, { resolve: (r) => { clearTimeout(t); resolve(r); }, reject: (e) => { clearTimeout(t); reject(e); } });
    ws.send(JSON.stringify({ id, method, params }));
  });
  try {
    await new Promise((resolve, reject) => { ws.onopen = resolve; ws.onerror = () => reject(new Error('could not reach the browser tab')); });
    await send('Page.enable');
    const { frameTree } = await send('Page.getFrameTree');
    await send('Page.setDocumentContent', { frameId: frameTree.frame.id, html });
    await send('Runtime.evaluate', { awaitPromise: true, expression: 'Promise.all([document.fonts ? document.fonts.ready : 0, ...[...document.images].map((i) => i.complete ? 0 : new Promise((r) => { i.onload = i.onerror = r; }))]).then(() => true)' }, 20000);
    const { data } = await send('Page.printToPDF', { printBackground: true, preferCSSPageSize: true, displayHeaderFooter: false, paperWidth: 8.27, paperHeight: 11.69 }, 60000);
    return Buffer.from(data, 'base64');
  } finally {
    try { ws.close(); } catch { /* closed */ }
    await cdpHttp(`/json/close/${target.id}`).catch(() => {});
  }
}

/** A Chrome to run headless: EX_CHROME, else Playwright's under PLAYWRIGHT_BROWSERS_PATH. */
function chromeBinary() {
  if (process.env.EX_CHROME && fs.existsSync(process.env.EX_CHROME)) return process.env.EX_CHROME;
  const root = process.env.PLAYWRIGHT_BROWSERS_PATH || path.join(os.homedir(), '.cache', 'ms-playwright');
  try {
    for (const d of fs.readdirSync(root).sort().reverse()) {
      for (const rel of ['chrome-linux/chrome', 'chrome-linux64/chrome', 'chrome-headless-shell-linux64/chrome-headless-shell', 'chrome-linux/headless_shell']) {
        const p = path.join(root, d, rel);
        if (fs.existsSync(p)) return p;
      }
    }
  } catch { /* no such folder */ }
  const mac = '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';
  return fs.existsSync(mac) ? mac : null;
}

/** Print with a Chrome binary. It may keep running after it wrote the file (a fresh profile on macOS): it is stopped once it says so. */
async function viaBinary(html) {
  const bin = chromeBinary();
  if (!bin) throw new Error('no Chrome to print with');
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'expenses-pdf-'));
  try {
    const src = path.join(dir, 'doc.html');
    const out = path.join(dir, 'doc.pdf');
    fs.writeFileSync(src, html);
    await new Promise((resolve, reject) => {
      const child = spawn(bin, ['--headless', '--no-sandbox', '--disable-gpu', '--no-first-run', '--no-default-browser-check', '--disable-extensions',
        '--no-pdf-header-footer', `--user-data-dir=${path.join(dir, 'profile')}`, `--print-to-pdf=${out}`, `file://${src}`], { stdio: ['ignore', 'ignore', 'pipe'] });
      let said = '';
      const timer = setTimeout(() => { child.kill('SIGKILL'); reject(new Error('Chrome took over 90 s')); }, 90000);
      const finish = () => { clearTimeout(timer); resolve(); };
      child.stderr.on('data', (d) => { said += d; if (/bytes written to file/.test(said)) { setTimeout(() => { child.kill('SIGKILL'); finish(); }, 200); } });
      child.on('exit', finish);
      child.on('error', (e) => { clearTimeout(timer); reject(e); });
    });
    if (!fs.existsSync(out) || !fs.statSync(out).size) throw new Error('Chrome printed nothing');
    return fs.readFileSync(out);
  } finally { fs.rmSync(dir, { recursive: true, force: true }); }
}

async function toPdf(html) {
  const errors = [];
  if (process.env.EX_PDF_VIA !== 'binary') {
    try { return await viaCdp(html); } catch (e) { errors.push(`the instance browser: ${e.message}`); }
  }
  try { return await viaBinary(html); } catch (e) { errors.push(`Chrome: ${e.message}`); }
  throw new Error(`The PDF could not be printed (${errors.join('; ')}). The instance browser restarts on its own: Try again in a minute.`);
}

module.exports = { toPdf, chromeBinary };
