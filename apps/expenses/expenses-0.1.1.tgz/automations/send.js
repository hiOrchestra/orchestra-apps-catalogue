'use strict';
/**
 * Expenses · the month to the accountant: a plain-text email with the link to
 * the month's page (the PDF and the CSV to download; close.js sealed them),
 * through Resend or the Gmail connected in Integrations, as Settings says.
 * No attachments: neither Composio send takes a file's bytes (Resend's
 * RESEND_SEND_EMAIL drops them without a word; read live 2026-10-09). Only
 * emails a person's Send created (Approved).
 *
 * Each email is CLAIMED before the sender is called (→ Sending, atomic), so none
 * leaves twice. One left Sending (a run that died, the sender did not answer) is
 * Failed and says it may have gone out: never retried blind.
 *
 * --check looks at Resend (connected, its verified domains, whether the From
 * is on one) and notes it in Settings; --auto does it too when the last look
 * is over six hours old, or the From changed, or a person asked.
 *   node send.js [--auto|--check]
 */
const L = require('./lib');
const C = require('./excore');
const G = require('./composio');

const STALE_MIN = 15;
const LOOK_EVERY_H = 6;

function check(s) {
  const conn = G.connections();
  const data = { resend_checked_at: L.sqlNow() };
  if (conn.ok && !conn.has('resend')) Object.assign(data, { resend_status: 'not_connected', resend_note: null, resend_domains: null });
  else {
    try { Object.assign(data, { resend_status: 'ok', resend_note: null, resend_domains: JSON.stringify(G.resendDomains().verified) }); } catch (e) {
      if (e.notConnected) Object.assign(data, { resend_status: 'not_connected', resend_note: null, resend_domains: null });
      else {
        try { G.resendPing(); Object.assign(data, { resend_status: 'ok', resend_note: null, resend_domains: null }); } catch (e2) {
          Object.assign(data, { resend_status: e2.notConnected ? 'not_connected' : 'error', resend_note: String(e2.message).slice(0, 200), resend_domains: null });
        }
      }
    }
  }
  L.write([{ op: 'update', table: 'ex_settings', id: s._id, data }]);
  const st = C.senders(Object.assign({}, s, data));
  return { ok: true, mode: '--check', resend: data.resend_status, ready: st.ready, say: st.say };
}

function lookDue(s) {
  const last = L.toDate(s.resend_checked_at);
  if (!last) return true;
  const asked = L.toDate(s.check_asked_at);
  if (asked && asked > last) return true;
  return L.now().getTime() - last.getTime() > LOOK_EVERY_H * 3600000;
}

function readable(e, via) {
  const t = String(e.message || e);
  const who = via === 'gmail' ? 'Gmail' : 'Resend';
  if (e.noFrom) return 'Resend has no From address in Settings: nothing went out. Write one (Settings → The accountant), then Send again.';
  if (e.notConnected) return `${who} is not connected: nothing went out. Connect it in Orchestra → Integrations, then Send again. (${t.slice(0, 160)})`;
  if (e.timeout) return `${who} did not answer in time, so it may or may not have gone out. Look in ${via === 'gmail' ? 'Gmail\'s Sent folder' : 'Resend\'s Emails list'} before sending again. (${t.slice(0, 160)})`;
  if (/not verified|verify your domain/i.test(t)) return `Resend refused the From address: its domain is not verified. Verify it in Resend → Domains, or change the From address in Settings, then Send again. (${t.slice(0, 160)})`;
  return `${who} did not take it: nothing went out. (${t.slice(0, 200)})`;
}

function run(mode = '--auto') {
  if (mode === '--check') return check(L.settings());
  let looked;
  if (C.senderOf(L.settings()) === 'resend' && lookDue(L.settings())) looked = check(L.settings());
  const waiting = L.one("SELECT COUNT(*) AS n FROM ex_emails WHERE _deleted = 0 AND status IN ('Approved', 'Sending')").n;
  if (!waiting) return Object.assign({ ok: true, mode, sent: 0 }, looked ? { looked: looked.resend } : {});
  const held = L.lock('send');
  if (!held) return { ok: true, skipped: 'Another run is sending' };
  try {
    const s = L.settings();
    const out = { ok: true, mode, sent: 0, failed: 0 };
    for (const m of L.all(`SELECT _id FROM ex_emails WHERE _deleted = 0 AND status = 'Sending' AND datetime(lock_at) <= datetime(?, '-${STALE_MIN} minutes')`, L.sqlNow())) {
      try { L.write([{ op: 'update', table: 'ex_emails', id: m._id, when: { status: 'Sending' }, data: { status: 'Failed', error: 'The send did not finish, so it may or may not have gone out. Look in the sender\'s sent emails before sending again.' } }]); } catch { /* moved */ }
    }
    for (const m of L.all("SELECT * FROM ex_emails WHERE _deleted = 0 AND status = 'Approved' ORDER BY _id LIMIT 10")) {
      const mo = L.one('SELECT * FROM ex_months WHERE _id = ?', m.month_id);
      const fail = (why) => { L.write([{ op: 'update', table: 'ex_emails', id: m._id, data: { status: 'Failed', error: why } }]); out.failed += 1; };
      if (!mo || mo.status !== 'Closed') { fail('The month is not closed any more: close it again, then Send.'); continue; }
      try { L.write([{ op: 'update', table: 'ex_emails', id: m._id, when: { status: 'Approved' }, data: { status: 'Sending', lock_at: L.sqlNow(), error: null } }]); } catch { continue; }
      let res;
      try { res = G.deliver(s, m); } catch (e) {
        fail(readable(e, e.via).slice(0, 500));
        if (e.notConnected && e.via === 'resend') L.write([{ op: 'update', table: 'ex_settings', id: s._id, data: { resend_status: 'not_connected', resend_checked_at: L.sqlNow(), resend_note: String(e.message).slice(0, 200) } }]);
        continue;
      }
      L.write([{ op: 'update', table: 'ex_emails', id: m._id, data: { status: 'Sent', sent_at: L.isoZ(), sent_via: res.via, message_id: res.id || null } },
        { op: 'update', table: 'ex_months', id: mo._id, data: { sent_at: L.isoZ(), send_note: null } }]);
      out.sent += 1;
    }
    return out;
  } finally { held.release(); }
}

if (require.main === module) {
  const a = process.argv.slice(2);
  try { L.done(run(a.includes('--check') ? '--check' : '--auto')); } catch (e) { L.done({ ok: false, error: e.message }); process.exitCode = 1; }
}
module.exports = { run, check, readable };
