'use strict';
/**
 * Expenses · Receipts in. A script, no agent:
 *
 *   --email   a mail a rule sent here (the workspace's address, ORC-159): each
 *             attachment that is a receipt (PDF, JPG, PNG, WebP) is saved to
 *             Files (Settings' folder, this project) and becomes a receipt;
 *             a mail without one is a receipt itself (its text).
 *   --files   the Files folder: what is new there becomes a receipt.
 *   --rules   the mail rules this app keeps: one per sender in Settings ×
 *             subject word, starting this workflow; others' rules untouched.
 *   --daily   --files and --rules, and the workspace address for Settings.
 *
 * The same file never comes in twice (SHA-256, a unique index). New receipts
 * start "Read receipts" (read.js decides text or photo).
 *
 *   node intake.js --email --id <messageId> --from <a> --subject <s> --attachments <json> --text <t>
 *   node intake.js --files | --rules | --daily
 */
const fs = require('fs');
const os = require('os');
const path = require('path');
const L = require('./lib');
const C = require('./excore');
const { TYPES } = require('./extract');

const MIME = { 'application/pdf': 'pdf', 'image/jpeg': 'jpg', 'image/jpg': 'jpg', 'image/png': 'png', 'image/webp': 'webp', 'image/gif': 'gif' };
const MAX_BYTES = 15 * 1024 * 1024;
const arg = (a, k) => { const i = a.indexOf(k); const v = i >= 0 ? a[i + 1] : undefined; return v === undefined || v === '-' || v === 'none' ? '' : v; };
const typeOfName = (name, mime) => {
  const ext = path.extname(String(name || '')).slice(1).toLowerCase();
  if (TYPES.includes(ext)) return ext === 'jpeg' ? 'jpg' : ext;
  return MIME[String(mime || '').toLowerCase().split(';')[0]] || '';
};

/** A file already on disk → a receipt row (and Files, unless it came from there). */
function admit(s, { file, name, type, source, fileId, email }) {
  const bytes = fs.readFileSync(file);
  if (!bytes.length) return { skipped: 'empty' };
  if (bytes.length > MAX_BYTES) return { skipped: 'over 15 MB' };
  const sha = L.sha256(bytes);
  if (L.one('SELECT _id FROM ex_receipts WHERE sha256 = ? AND _deleted = 0', sha)) return { skipped: 'already in' };
  let id = fileId;
  if (!id) {
    const up = L.fileUpload({ name: String(name || 'receipt').replace(/\.[a-z0-9]+$/i, '').slice(0, 120), type, bytes, folder: s.files_folder || 'Receipts', description: `A receipt for Expenses${email ? `, from ${email.from}` : ''}` });
    if (!up.ok) return { failed: `Files did not take it: ${up.why}` };
    id = up.file.id;
  }
  try {
    const [r] = L.write([{ op: 'insert', table: 'ex_receipts', data: {
      source, file_id: id, file_name: String(name || '').slice(0, 200), file_type: type, size: bytes.length, sha256: sha,
      email_from: email ? L.clean(email.from, 200) : '', email_subject: email ? L.clean(email.subject, 300) : '', email_message_id: email ? L.clean(email.id, 100) : '',
      received_at: L.isoZ(), status: 'New', tries: 0 } }]);
    return { id: r._id };
  } catch (e) { return /UNIQUE/i.test(e.message) ? { skipped: 'already in' } : { failed: e.message }; }
}

function fromEmail(s, a) {
  const email = { id: arg(a, '--id'), from: arg(a, '--from'), subject: arg(a, '--subject') };
  const out = { mode: '--email', admitted: 0, skipped: 0, failed: [] };
  let list = [];
  try { list = JSON.parse(arg(a, '--attachments') || '[]'); } catch { list = []; }
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'expenses-in-'));
  try {
    for (const att of Array.isArray(list) ? list : []) {
      const type = typeOfName(att.filename, att.contentType);
      if (!type) { out.skipped += 1; continue; }
      const file = path.join(dir, `a-${out.admitted + out.skipped + out.failed.length}.${type}`);
      const got = L.mailAttachment(email.id, att.id, file);
      if (!got.ok) { out.failed.push(`${att.filename}: ${got.why}`); continue; }
      const r = admit(s, { file, name: att.filename, type, source: 'email', email });
      if (r.id) out.admitted += 1; else if (r.failed) out.failed.push(`${att.filename}: ${r.failed}`); else out.skipped += 1;
    }
    // No receipt attached: the mail is the receipt (an emailed bill).
    const text = arg(a, '--text');
    if (!out.admitted && !out.failed.length && text.replace(/\s+/g, '').length >= 40) {
      const sha = L.sha256(`mail:${text}`);
      if (L.one('SELECT _id FROM ex_receipts WHERE sha256 = ? AND _deleted = 0', sha)) out.skipped += 1;
      else {
        L.write([{ op: 'insert', table: 'ex_receipts', data: { source: 'email', file_id: null, file_name: L.clean(email.subject || 'Email', 200), file_type: 'text',
          size: text.length, sha256: sha, email_from: L.clean(email.from, 200), email_subject: L.clean(email.subject, 300), email_message_id: L.clean(email.id, 100),
          received_at: L.isoZ(), status: 'New', kind: 'text', text: text.slice(0, 12000), tries: 0 } }]);
        out.admitted += 1;
      }
    }
  } finally { fs.rmSync(dir, { recursive: true, force: true }); }
  return out;
}

function fromFiles(s) {
  const out = { mode: '--files', admitted: 0, skipped: 0, failed: [] };
  const r = L.filesList();
  if (!r.ok) {
    L.write([{ op: 'update', table: 'ex_settings', id: s._id, data: { files_at: L.sqlNow(), files_note: `Files did not answer: ${String(r.why).slice(0, 200)}` } }]);
    return Object.assign(out, { error: r.why });
  }
  // Files answers "/Receipts" for a folder written as "Receipts".
  const norm = (x) => String(x || '').trim().replace(/^\/+|\/+$/g, '').toLowerCase();
  const folder = norm(s.files_folder || 'Receipts');
  const known = new Set(L.all("SELECT file_id FROM ex_receipts WHERE _deleted = 0 AND COALESCE(file_id, '') <> ''").map((x) => x.file_id));
  const fresh = r.files.filter((f) => norm(f.folder) === folder && (!f.project || f.project === L.PROJECT)
    && TYPES.includes(String(f.type || f.ext || '').toLowerCase()) && !known.has(f.id)).slice(0, 40);
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'expenses-in-'));
  try {
    for (const f of fresh) {
      const type = String(f.type || f.ext).toLowerCase() === 'jpeg' ? 'jpg' : String(f.type || f.ext).toLowerCase();
      const file = path.join(dir, `${f.id}.${type}`);
      const got = L.fileDownload(f.id, file);
      if (!got.ok) { out.failed.push(`${f.name}: ${got.why}`); continue; }
      const res = admit(s, { file, name: /\.[a-z0-9]+$/i.test(f.name) ? f.name : `${f.name}.${type}`, type, source: 'files', fileId: f.id });
      if (res.id) out.admitted += 1; else if (res.failed) out.failed.push(`${f.name}: ${res.failed}`); else out.skipped += 1;
    }
  } finally { fs.rmSync(dir, { recursive: true, force: true }); }
  L.write([{ op: 'update', table: 'ex_settings', id: s._id, data: { files_at: L.sqlNow(), files_note: out.failed.length ? out.failed.slice(0, 3).join(' · ').slice(0, 400) : null } }]);
  return out;
}

/** Keep the mail rules: one per sender × word, starting this workflow. */
function rules(s) {
  const out = { mode: '--rules', added: 0, removed: 0, refused: [] };
  const wf = L.workflowIds().in;
  if (!wf) return Object.assign(out, { error: 'No "Receipts in" workflow recorded: install Expenses again' });
  const listed = L.mailRules();
  if (!listed.ok) {
    L.write([{ op: 'update', table: 'ex_settings', id: s._id, data: { rules_at: L.sqlNow(), rules_note: `The workspace email did not answer: ${String(listed.why).slice(0, 200)}` } }]);
    return Object.assign(out, { error: listed.why });
  }
  const mine = listed.rules.filter((r) => r.workflowId === wf);
  const want = [];
  for (const p of C.sendersOf(s)) for (const w of C.wordsOf(s)) want.push({ pattern: p, subjectContains: w });
  const key = (r) => `${String(r.pattern).toLowerCase()}|${String(r.subjectContains || '').toLowerCase()}`;
  const have = new Map(mine.map((r) => [key(r), r]));
  const wanted = new Set(want.map(key));
  for (const r of mine) if (!wanted.has(key(r))) { if (L.mailRuleRemove(r.id).ok) out.removed += 1; }
  const refusedSenders = new Set();
  for (const w of want) {
    if (have.has(key(w)) || refusedSenders.has(w.pattern)) continue;
    const r = L.mailRuleAdd({ pattern: w.pattern, subjectContains: w.subjectContains, requireAttachment: false, workflowId: wf });
    if (r.ok) out.added += 1;
    else { refusedSenders.add(w.pattern); out.refused.push(`${w.pattern}: ${/not_listed|not listed|sender/i.test(r.why || '') ? 'not on the Email channel\'s list of senders yet' : String(r.why).slice(0, 120)}`); }
  }
  const now = L.mailRules();
  const kept = now.ok ? now.rules.filter((r) => r.workflowId === wf).map((r) => ({ id: r.id, pattern: r.pattern, subject: r.subjectContains })) : [];
  const id = L.mailIdentity();
  L.write([{ op: 'update', table: 'ex_settings', id: s._id, data: { rules: JSON.stringify(kept), rules_at: L.sqlNow(),
    rules_note: out.refused.length ? `Not set for: ${out.refused.join(' · ')}`.slice(0, 500) : null, ...(id.ok && id.address ? { inbox_address: id.address } : {}) } }]);
  return out;
}

function run(argv) {
  const held = L.lock('intake');
  if (!held) return { ok: true, skipped: 'Another run is taking receipts in' };
  try {
    const s = L.settings();
    let mode = ['--email', '--files', '--rules', '--daily'].find((m) => argv.includes(m)) || '--files';
    // The daily schedule runs the workflow with its defaults: --email and no mail.
    if (mode === '--email' && !arg(argv, '--id')) mode = '--daily';
    const out = { ok: true, mode };
    if (mode === '--email') Object.assign(out, fromEmail(s, argv));
    if (mode === '--files' || mode === '--daily') out.files = fromFiles(L.settings());
    if (mode === '--rules' || mode === '--daily') out.rules = rules(L.settings());
    const waiting = L.one("SELECT COUNT(*) AS n FROM ex_receipts WHERE _deleted = 0 AND status = 'New'").n;
    if (waiting) out.read = L.kick('read');
    return out;
  } finally { held.release(); }
}

if (require.main === module) {
  try { L.done(run(process.argv.slice(2))); } catch (e) { L.done({ ok: false, error: e.message }); process.exitCode = 1; }
}
module.exports = { run, fromEmail, fromFiles, rules, typeOfName, admit };
