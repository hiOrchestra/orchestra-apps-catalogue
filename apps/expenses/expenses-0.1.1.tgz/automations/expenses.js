#!/usr/bin/env node
'use strict';
/**
 * Expenses · the agent's tool. It reads, and adds an expense a person
 * describes (cash, no receipt) — always in Review: approving, closing a month
 * and emailing the accountant are a person's clicks in the desk.
 *
 *   node expenses.js review                         what waits for a person (and what could not be read)
 *   node expenses.js month [YYYY-MM]                the month's approved totals, per category and VAT
 *   node expenses.js list [--month YYYY-MM] [--status Review|Approved|Rejected] [--q words]
 *   node expenses.js add --vendor "…" --total 12.50 --date YYYY-MM-DD [--currency EUR] [--tax 2.17] [--rate 21]
 *                        [--category "…"] [--description "…"] [--paid-by company|<person>]
 *   node expenses.js where                          how receipts get in (the address, who forwards, the Files folder)
 *
 * Prints one JSON line.
 */
const L = require('./lib');
const C = require('./excore');

const arg = (a, k) => { const i = a.indexOf(k); return i >= 0 ? a[i + 1] : undefined; };
const row = (e) => ({ id: e._id, status: e.status, date: e.date, vendor: e.vendor, total: C.money(e.total, e.currency, 'en-GB'), category: e.category, read_by: e.read_by, duplicate_of: e.duplicate_of || undefined });

function main(a) {
  const s = L.settings();
  const cmd = a[0];
  const desk = (p) => (s.desk_url ? `${s.desk_url}#${p}` : `(open Expenses → ${p})`);
  if (cmd === 'review') {
    const rows = L.all("SELECT * FROM ex_expenses WHERE _deleted = 0 AND status = 'Review' ORDER BY date DESC LIMIT 100");
    const stuck = L.all("SELECT _id, file_name, note FROM ex_receipts WHERE _deleted = 0 AND status = 'Failed' ORDER BY _id DESC LIMIT 20");
    return { ok: true, to_review: rows.map(row), could_not_read: stuck, desk: desk('/'), tell_the_person: rows.length ? `${rows.length} expense${rows.length === 1 ? '' : 's'} wait for your review: ${desk('/')}` : 'Nothing waits for review.' };
  }
  if (cmd === 'month') {
    const month = /^\d{4}-\d{2}$/.test(a[1] || '') ? a[1] : C.today(s.timezone).slice(0, 7);
    const rows = L.all("SELECT * FROM ex_expenses WHERE _deleted = 0 AND status = 'Approved' AND month = ?", month);
    const mo = L.one('SELECT status, closed_at, pdf_name, sent_at FROM ex_months WHERE _deleted = 0 AND month = ?', month);
    const waiting = L.one("SELECT COUNT(*) AS n FROM ex_expenses WHERE _deleted = 0 AND status = 'Review' AND month = ?", month).n;
    return { ok: true, month, status: mo ? mo.status : 'Open', approved: rows.length, still_to_review: waiting, summary: C.summary(rows), files: mo && mo.pdf_name ? mo.pdf_name : undefined, desk: desk(`/month/${month}`) };
  }
  if (cmd === 'list') {
    const where = ['_deleted = 0'];
    const p = [];
    if (/^\d{4}-\d{2}$/.test(arg(a, '--month') || '')) { where.push('month = ?'); p.push(arg(a, '--month')); }
    if (['Review', 'Approved', 'Rejected'].includes(arg(a, '--status'))) { where.push('status = ?'); p.push(arg(a, '--status')); }
    let rows = L.all(`SELECT * FROM ex_expenses WHERE ${where.join(' AND ')} ORDER BY date DESC LIMIT 300`, ...p);
    const q = String(arg(a, '--q') || '').toLowerCase();
    if (q) rows = rows.filter((e) => `${e.vendor} ${e.description} ${e.category}`.toLowerCase().includes(q));
    return { ok: true, expenses: rows.slice(0, 60).map(row), more: rows.length > 60 ? rows.length - 60 : undefined };
  }
  if (cmd === 'add') {
    const cur = String(arg(a, '--currency') || s.currency || 'EUR').toUpperCase();
    const item = { is_receipt: true, vendor: arg(a, '--vendor'), date: arg(a, '--date'), currency: cur, total: arg(a, '--total'), tax: arg(a, '--tax'), tax_rate: arg(a, '--rate'),
      category: arg(a, '--category'), description: arg(a, '--description'), confidence: 'high' };
    const v = C.cleanRead(item, { categories: C.categoriesOf(s), currency: cur, today: C.today(s.timezone) });
    if (!v.ok) return { ok: false, error: `Not added: ${v.why}. Give --vendor, --total and --date (YYYY-MM-DD).` };
    const paid = String(arg(a, '--paid-by') || 'company').trim().slice(0, 80) || 'company';
    const [r] = L.write([{ op: 'insert', table: 'ex_expenses', data: Object.assign({ status: 'Review', paid_by: paid, read_by: 'agent', created_by: `agent:${process.env.ORCHESTRA_AGENT_ID || 'agent'}` }, v.data) }]);
    return { ok: true, id: r._id, status: 'Review', tell_the_person: `Added for your review (no receipt): ${desk(`/expense/${r._id}`)}` };
  }
  if (cmd === 'where') {
    return { ok: true, address: s.inbox_address || '(see Orchestra → Channels → Email)', forwarders: C.sendersOf(s), subject_words: C.wordsOf(s), files_folder: s.files_folder || 'Receipts',
      rules_note: s.rules_note || undefined, how: 'Forward a receipt from one of the forwarders, with one of the subject words, to the address; or put the file in the Files folder of this project.' };
  }
  return { ok: false, error: 'commands: review, month [YYYY-MM], list, add, where' };
}

if (require.main === module) {
  try { const r = L.done(main(process.argv.slice(2))); if (!r.ok) process.exitCode = 1; } catch (e) { L.done({ ok: false, error: e.message }); process.exitCode = 1; }
}
module.exports = { main };
