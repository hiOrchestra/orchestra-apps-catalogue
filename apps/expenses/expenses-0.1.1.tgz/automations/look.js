'use strict';
/**
 * Expenses · Read photos. Two steps around one agent turn (the workflow's
 * `delegate`): photos of paper receipts and scanned PDFs, which the cheap
 * text model cannot see.
 *
 *   pick   claims up to 4 receipts in Look (→ Looking) and prints, for the
 *          agent, each one's id and the paths of its pictures (made upright and
 *          readable by extract.js, in look/), and the reading rules.
 *   save   reads the agent's answer ($PRIOR: JSON only), checks it exactly as
 *          read.js does, and saves expenses in Review marked "read by the
 *          agent". The agent never writes to the database.
 *
 *   node look.js pick | save
 */
const fs = require('fs');
const path = require('path');
const L = require('./lib');
const C = require('./excore');
const { saveAnswers, unstick } = require('./read');
const { LOOK } = require('./extract');

const BATCH = 4;

function pick() {
  const held = L.lock('look');
  if (!held) return { items: [], skip: 'Another run is looking' };
  try {
    unstick();
    const s = L.settings();
    const items = [];
    for (const r of L.all("SELECT * FROM ex_receipts WHERE _deleted = 0 AND status = 'Look' ORDER BY _id LIMIT ?", BATCH)) {
      const images = fs.existsSync(LOOK()) ? fs.readdirSync(LOOK()).filter((f) => f.startsWith(`${r._id}-`) && f.endsWith('.jpg')).sort().map((f) => path.join(LOOK(), f)) : [];
      if (!images.length) { L.write([{ op: 'update', table: 'ex_receipts', id: r._id, when: { status: 'Look' }, data: { status: 'New', claimed_at: null } }]); continue; }
      try { L.write([{ op: 'update', table: 'ex_receipts', id: r._id, when: { status: 'Look' }, data: { status: 'Looking', claimed_at: L.sqlNow() } }]); } catch { continue; }
      items.push({ id: r._id, images, from: r.email_from || undefined, file: r.file_name || undefined });
    }
    const cats = C.categoriesOf(s);
    return { items, instructions: `${C.readingRules(cats, s)}\nToday is ${C.today(s.timezone)}.` };
  } finally { held.release(); }
}

function save() {
  const out = saveAnswers(L.stepOut('PRIOR'), { from: 'Looking', readBy: 'agent' });
  // The pictures were only for the agent's eyes: the receipt stays in Files.
  for (const r of L.all("SELECT _id FROM ex_receipts WHERE _deleted = 0 AND status IN ('Read', 'NotReceipt', 'Failed') AND kind = 'image'")) {
    if (!fs.existsSync(LOOK())) break;
    for (const f of fs.readdirSync(LOOK()).filter((x) => x.startsWith(`${r._id}-`))) { try { fs.unlinkSync(path.join(LOOK(), f)); } catch { /* gone */ } }
  }
  return Object.assign({ ok: true }, out);
}

if (require.main === module) {
  const cmd = process.argv[2];
  try { L.done(cmd === 'save' ? save() : Object.assign({ ok: true }, pick())); } catch (e) { L.done({ ok: false, error: e.message, items: [] }); process.exitCode = 1; }
}
module.exports = { pick, save };
