'use strict';
/**
 * Expenses · Read receipts. Two steps around one cheap model call (the
 * workflow's `llm-task`, no agent):
 *
 *   pick   claims up to 8 New receipts (→ Reading, atomic), downloads each
 *          from Files, makes its preview, and sorts it: text (a PDF with text,
 *          a mail) goes to the model in this run; a photo or a scanned PDF
 *          becomes Look and starts "Read photos" (look.js, the agent). Prints
 *          { items: [{ id, text }], instructions } for the model.
 *   save   reads the model's answer ($PRIOR), checks every item (excore
 *          cleanRead) and saves an expense in Review for each, marked "read
 *          by the model"; a document that is not a receipt is set aside; one
 *          the model skipped goes back (3 tries, then "Needs you").
 *
 * A claim that died is put back after 10 minutes.
 *   node read.js pick | save
 */
const fs = require('fs');
const os = require('os');
const path = require('path');
const L = require('./lib');
const C = require('./excore');
const { extract } = require('./extract');

const BATCH = 8;
const STALE_MIN = 10;
const MAX_TRIES = 3;

function unstick() {
  for (const r of L.all(`SELECT _id, status FROM ex_receipts WHERE _deleted = 0 AND status IN ('Reading', 'Looking') AND datetime(claimed_at) <= datetime(?, '-${STALE_MIN} minutes')`, L.sqlNow())) {
    try { L.write([{ op: 'update', table: 'ex_receipts', id: r._id, when: { status: r.status }, data: { status: r.status === 'Reading' ? 'New' : 'Look', claimed_at: null } }]); } catch { /* moved */ }
  }
}

/** Download a receipt's file and look inside it: { kind, text, images, preview }. */
function open(r) {
  if (r.file_type === 'text' || r.kind === 'text') return { kind: 'text', text: r.text || '', images: [], preview: '' };
  const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'expenses-r-'));
  try {
    const file = path.join(dir, `r.${r.file_type}`);
    const got = L.fileDownload(r.file_id, file);
    if (!got.ok) throw new Error(got.notFound ? 'The file is not in Files any more.' : `Files did not give the file: ${got.why}`);
    return extract(file, r.file_type, { id: r._id });
  } finally { fs.rmSync(dir, { recursive: true, force: true }); }
}

function pick() {
  const held = L.lock('read');
  if (!held) return { items: [], skip: 'Another run is reading' };
  try {
    unstick();
    const s = L.settings();
    const out = { items: [], photos: 0, failed: 0 };
    for (const r of L.all("SELECT * FROM ex_receipts WHERE _deleted = 0 AND status = 'New' ORDER BY _id LIMIT ?", BATCH)) {
      try { L.write([{ op: 'update', table: 'ex_receipts', id: r._id, when: { status: 'New' }, data: { status: 'Reading', claimed_at: L.sqlNow() } }]); } catch { continue; }
      let x;
      try { x = open(r); } catch (e) {
        L.write([{ op: 'update', table: 'ex_receipts', id: r._id, data: { status: 'Failed', note: String(e.message).slice(0, 300), claimed_at: null } }]);
        out.failed += 1;
        continue;
      }
      if (x.kind === 'image') {
        L.write([{ op: 'update', table: 'ex_receipts', id: r._id, data: { status: 'Look', kind: 'image', preview: x.preview, claimed_at: null } }]);
        out.photos += 1;
      } else {
        L.write([{ op: 'update', table: 'ex_receipts', id: r._id, data: { kind: 'text', text: x.text, ...(x.preview ? { preview: x.preview } : {}) } }]);
        out.items.push({ id: r._id, from: r.email_from || undefined, subject: r.email_subject || undefined, file: r.file_name || undefined, text: x.text.slice(0, 6000) });
      }
    }
    if (out.photos) out.look = L.kick('look');
    const cats = C.categoriesOf(s);
    out.instructions = `${C.readingRules(cats, s)}\nToday is ${C.today(s.timezone)}. Answer {"items":[...]} with one entry per item below, using its id.${out.items.length ? '' : ' There are no items: answer {"items":[]}.'}`;
    return out;
  } finally { held.release(); }
}

/**
 * Save the readers' answers for receipts claimed as `from` (Reading or
 * Looking): an expense in Review per receipt read; returns counts.
 */
function saveAnswers(answer, { from, readBy }) {
  const s = L.settings();
  const cats = C.categoriesOf(s);
  const t = C.today(s.timezone);
  const items = Array.isArray(answer) ? answer : (answer && Array.isArray(answer.items) ? answer.items : []);
  const byId = new Map(items.filter((i) => i && Number.isInteger(Number(i.id))).map((i) => [Number(i.id), i]));
  const out = { saved: 0, not_receipts: 0, retried: 0, failed: 0, duplicates: 0 };
  for (const r of L.all('SELECT * FROM ex_receipts WHERE _deleted = 0 AND status = ?', from)) {
    const v = C.cleanRead(byId.get(r._id), { categories: cats, currency: s.currency, today: t });
    if (v.notReceipt) { L.write([{ op: 'update', table: 'ex_receipts', id: r._id, when: { status: from }, data: { status: 'NotReceipt', note: 'Read as not being a receipt or an invoice', claimed_at: null } }]); out.not_receipts += 1; continue; }
    if (!v.ok) {
      const tries = (Number(r.tries) || 0) + 1;
      const back = from === 'Reading' ? 'New' : 'Look';
      const status = tries >= MAX_TRIES || byId.has(r._id) ? 'Failed' : back;
      L.write([{ op: 'update', table: 'ex_receipts', id: r._id, when: { status: from }, data: { status, tries, note: status === 'Failed' ? `Could not be read: ${v.why}. Enter it by hand.` : v.why, claimed_at: null } }]);
      out[status === 'Failed' ? 'failed' : 'retried'] += 1;
      continue;
    }
    const d = v.data;
    const twin = L.all("SELECT _id, vendor, date, total, currency FROM ex_expenses WHERE _deleted = 0 AND status <> 'Rejected' AND date = ? AND total = ?", d.date, d.total)
      .find((e) => C.dupKey(e) === C.dupKey(d));
    try {
      const [e] = L.write([{ op: 'insert', table: 'ex_expenses', data: Object.assign({ receipt_id: r._id, status: 'Review', paid_by: 'company', read_by: readBy, duplicate_of: twin ? twin._id : null, created_by: 'reader' }, d) }]);
      L.write([{ op: 'update', table: 'ex_receipts', id: r._id, when: { status: from }, data: { status: 'Read', expense_id: e._id, note: null, claimed_at: null } }]);
      out.saved += 1;
      if (twin) out.duplicates += 1;
    } catch (err) {
      if (/UNIQUE/i.test(err.message)) L.write([{ op: 'update', table: 'ex_receipts', id: r._id, data: { status: 'Read', claimed_at: null } }]);
      else throw err;
    }
  }
  if (out.saved && s.notify_telegram) L.telegram(s.notify_telegram, `🧾 ${out.saved} receipt${out.saved === 1 ? '' : 's'} read and waiting for your review in Expenses.`);
  return out;
}

function save() {
  const answer = L.stepOut('PRIOR');
  return Object.assign({ ok: true }, saveAnswers(answer, { from: 'Reading', readBy: 'model' }));
}

if (require.main === module) {
  const cmd = process.argv[2];
  try { L.done(cmd === 'save' ? save() : Object.assign({ ok: true }, pick())); } catch (e) { L.done({ ok: false, error: e.message, items: [] }); process.exitCode = 1; }
}
module.exports = { pick, save, saveAnswers, open, unstick };
