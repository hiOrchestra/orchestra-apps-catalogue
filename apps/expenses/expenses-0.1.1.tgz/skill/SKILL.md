---
name: app-expenses
version: 0.1.1
description: >-
  Work in the Expenses app: receipts read on their own (forwarded to the
  workspace address or put in a Files folder), expenses waiting for review,
  a month's totals and VAT, and the month for the accountant. Load it when
  someone says "here's a receipt / te paso un ticket", "add this expense /
  apunta este gasto", "how much did I spend / cuánto gasté este mes", "how
  much VAT / cuánto IVA soporté", "what's pending / qué gastos faltan
  revisar", "send the month to the accountant / mándale el mes al gestor",
  "who do I owe / qué hay que reembolsar". Needs the Expenses app installed in
  a project you work in.
metadata:
  openclaw:
    emoji: "🧾"
---
# Expenses — receipts, the month, the accountant

Receipts come in by email (forwarded to the workspace's own address from a
sender the owner listed, with a word like "receipt" or "factura" in the
subject) or by a Files folder ("Receipts"). A script reads them: a PDF's text
with a cheap model, a photo with **you** (the "Read photos" workflow asks you
for JSON only). A person checks each expense beside its picture and approves
it. Closing a month makes a PDF (summary + every receipt) and a CSV in Files;
Send emails the accountant a private link to
download them (a public page that opens nothing without the link). Not accounting software.

```bash
ls -d ~/.openclaw/orchestra/projects/*/apps/expenses   # the directory name under projects/ is the project id
P=<project>; T=~/.openclaw/orchestra/projects/$P/apps/expenses/automations
orch-canvas url expenses                                 # the desk, for the person
```

If nothing is listed, Expenses is not installed in a project you work in:
say so, and do not keep expenses some other way.

## What you can do, and what you never do

| You can | With |
|---|---|
| Say what waits for review, and what could not be read | `node $T/expenses.js review` |
| A month's approved totals, per category and VAT rate | `node $T/expenses.js month [YYYY-MM]` |
| List expenses | `node $T/expenses.js list [--month YYYY-MM] [--status Review\|Approved\|Rejected] [--q words]` |
| Add an expense a person describes (cash, no receipt) | `node $T/expenses.js add --vendor "…" --total 12.50 --date YYYY-MM-DD [--rate 21] [--category "…"] [--paid-by Ana]` — it waits for review |
| Tell someone how to send receipts | `node $T/expenses.js where` (the address, who may forward, the words, the Files folder) |

**Never:** approve or reject an expense, close or reopen a month, or email the
accountant: those are a person's clicks in the desk. Never write to the
`ex_*` tables by hand.

**A receipt someone sends you in chat:** tell them to forward it to the
workspace address (from a listed sender, with "receipt"/"factura" in the
subject) or put it in the Files folder "Receipts"; if they ask you to, save
the file there yourself (`files.upload` with that folder) and say it will be
read in a minute.

**When the "Read photos" workflow asks you:** open every picture with
view_image and pass each one through `image()` (in code mode the result is
text until you do: `for (const u of JSON.stringify(r).match(/data:image[A-Za-z0-9+/=;,.-]+/g) || []) image(u, 'original');`).
Answer only the JSON it asks for; never guess an amount that is not printed.

## The model (tables `ex_*`, read only for you)

| Table | One row per | Notes |
|---|---|---|
| `ex_expenses` | expense | `status` Review → Approved / Rejected; `vendor`, `date`, `month`, `currency`, `total`/`net`/`tax` in minor units (cents), `tax_rate` %, `category`, `paid_by` (company or a person; `reimbursed_at`), `read_by` model/agent/person, `duplicate_of` |
| `ex_receipts` | file or mail | `status` New → Reading/Look → Read, or Failed ("Needs you"), NotReceipt, Dismissed; `file_id` in Files |
| `ex_months` | closed month | `status` Open/Closing/Closed; `pdf_file_id`, `csv_file_id`; `sent_at`, `send_to`; `token` (the accountant's link: never repeat it) |
| `ex_links` | piece of a sealed month | the accountant's page reads these; unreadable without the link |
| `ex_settings`, `ex_emails` | settings, emails to the accountant | scripts only |
