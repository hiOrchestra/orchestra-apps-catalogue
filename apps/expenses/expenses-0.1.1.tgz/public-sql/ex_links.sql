SELECT k, box FROM ex_links WHERE _deleted = 0
