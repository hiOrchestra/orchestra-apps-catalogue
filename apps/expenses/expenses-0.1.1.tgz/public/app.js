// The month's page. #<token> is the whole address: the page hashes it to find
// the month's rows in the public view `ex_links` (its state '0', the PDF
// 'p<i>', the CSV 'c<i>') and opens them with it. Nothing is readable without
// the link, and the token never leaves the browser.
const C = self.ExCore;
const { el } = Orch;
const token = decodeURIComponent(location.hash.replace(/^#\/?/, '').split(/[/?&]/)[0] || '');

const WORDS = {
  en: {
    loading: 'Opening the month…', title: (st) => `Expenses for ${st.monthName}`, from: (st) => `From ${st.company || 'your client'}.`,
    count: (n) => `${n} expense${n === 1 ? '' : 's'}`, total: 'Total', vat: 'VAT', closed: (d) => `Closed on ${d}.`,
    pdf: 'Download the PDF', pdfSay: 'The summary, then every receipt behind it.', csv: 'Download the CSV', csvSay: 'One line per expense, for your software.',
    downloading: 'Downloading…', failed: 'It could not be downloaded. Try again in a minute.',
    badTitle: 'This link is not complete', badText: 'Open it again from the email, the whole address.',
    goneTitle: 'Nothing here', goneText: 'This link opens nothing, or the month is being prepared again right now. Try again in a minute, or ask whoever sent it for a new email.',
    pendingTitle: 'Not open yet', pendingText: 'This page is not open to the internet yet. Ask whoever sent the email.',
    brokenTitle: 'It did not load', brokenText: 'Something went wrong on our side. Try again in a minute.', again: 'Try again',
    note: 'Prepared with Orchestra Expenses. Not accounting records: a working document for whoever keeps the books.',
  },
  es: {
    loading: 'Abriendo el mes…', title: (st) => `Gastos de ${st.monthName}`, from: (st) => `De ${st.company || 'tu cliente'}.`,
    count: (n) => `${n} gasto${n === 1 ? '' : 's'}`, total: 'Total', vat: 'IVA', closed: (d) => `Cerrado el ${d}.`,
    pdf: 'Descargar el PDF', pdfSay: 'El resumen y, detrás, cada recibo.', csv: 'Descargar el CSV', csvSay: 'Una línea por gasto, para tu programa.',
    downloading: 'Descargando…', failed: 'No se pudo descargar. Vuelve a probar en un minuto.',
    badTitle: 'El enlace no está completo', badText: 'Ábrelo de nuevo desde el correo, la dirección entera.',
    goneTitle: 'Aquí no hay nada', goneText: 'Este enlace no abre nada, o el mes se está preparando de nuevo ahora mismo. Vuelve a probar en un minuto, o pide un correo nuevo a quien te lo envió.',
    pendingTitle: 'Aún no está abierta', pendingText: 'Esta página aún no está abierta a internet. Pregunta a quien te envió el correo.',
    brokenTitle: 'No cargó', brokenText: 'Algo falló de nuestro lado. Vuelve a probar en un minuto.', again: 'Volver a probar',
    note: 'Preparado con Orchestra Expenses. No son registros contables: un documento de trabajo para quien lleva los libros.',
  },
};
let w = WORDS[/^es\b/i.test(navigator.language || '') ? 'es' : 'en'];

function show(...nodes) {
  Orch.mount('page', nodes);
  const h = document.querySelector('#page h1');
  if (h) h.focus({ preventScroll: true });
}
const state = (title, text, extra) => el('section', { class: 'xm-card xm-state', 'aria-live': 'polite' }, [el('h1', { class: 'xm-title', tabindex: '-1' }, title), text ? el('p', text) : null, extra || null]);
const again = () => el('button', { type: 'button', class: 'oc-btn', onClick: () => start() }, w.again);

async function rows(names) {
  const keys = await Promise.all(names.map((n) => C.linkKey(token, n)));
  const got = new Map();
  for (let i = 0; i < keys.length; i += 40) {
    const r = await Orch.db.view('ex_links', { filter: { k: keys.slice(i, i + 40) }, limit: 40 });
    for (const row of r.rows || []) got.set(row.k, row.box);
  }
  const values = await Promise.all(keys.map((k) => (got.has(k) ? C.open(token, got.get(k)) : null)));
  return values.some((v) => v === null) ? null : values;
}

const money = (minor, cur, lang) => {
  const d = cur === 'JPY' ? 0 : 2;
  try { return new Intl.NumberFormat(lang === 'es' ? 'es-ES' : 'en-GB', { style: 'currency', currency: cur, minimumFractionDigits: d }).format(Number(minor) / 10 ** d); } catch { return `${(Number(minor) / 10 ** d).toFixed(d)} ${cur}`; }
};
const day = (iso, lang) => { const t = new Date(iso); return Number.isNaN(t.getTime()) ? '' : t.toLocaleDateString(lang === 'es' ? 'es-ES' : 'en-GB', { day: 'numeric', month: 'long', year: 'numeric' }); };

async function start() {
  if (!C.TOKEN.test(token)) { show(state(w.badTitle, w.badText)); return; }
  show(el('section', { class: 'xm-card xm-state', role: 'status', 'aria-live': 'polite' }, el('p', w.loading)));
  let st;
  try { st = ((await rows([C.PART.state])) || [])[0] || null; } catch (e) {
    if (e.reason === 'public-view-pending' || e.status === 403) show(state(w.pendingTitle, w.pendingText));
    else show(state(w.brokenTitle, w.brokenText, again()));
    return;
  }
  if (!st) { show(state(w.goneTitle, w.goneText)); return; }
  w = WORDS[st.lang === 'es' ? 'es' : 'en'];
  document.documentElement.lang = st.lang === 'es' ? 'es' : 'en';
  document.title = w.title(st);
  const file = (label, say, part, info, type) => {
    const b = el('button', { type: 'button', class: 'oc-btn oc-btn--primary xm-big' }, label);
    b.addEventListener('click', () => download(b, part, info, type));
    return el('div', { class: 'xm-file' }, [b, el('p', { class: 'xm-small xm-muted' }, [say, ' ', el('span', { class: 'xm-mono' }, info.name)])]);
  };
  show(
    el('header', { class: 'xm-head' }, [el('h1', { class: 'xm-title', tabindex: '-1' }, w.title(st)), el('p', { class: 'xm-muted' }, [w.from(st), ' ', w.closed(day(st.closed_at, st.lang))])]),
    el('section', { class: 'xm-card', 'aria-label': w.title(st) }, [
      el('p', { class: 'xm-count' }, w.count(st.count)),
      el('dl', { class: 'xm-totals' }, (st.totals || []).flatMap((u) => [
        el('div', [el('dt', w.total), el('dd', money(u.total, u.currency, st.lang))]),
        el('div', [el('dt', w.vat), el('dd', money(u.tax, u.currency, st.lang))]),
      ])),
    ]),
    el('section', { class: 'xm-card xm-files', 'aria-label': `${w.pdf} · ${w.csv}` }, [
      file(w.pdf, w.pdfSay, C.PART.pdf, st.pdf, 'application/pdf'),
      file(w.csv, w.csvSay, C.PART.csv, st.csv, 'text/csv'),
    ]),
    el('p', { class: 'xm-small xm-muted xm-note' }, w.note),
  );
}

async function download(button, part, info, type) {
  button.disabled = true;
  button.setAttribute('aria-busy', 'true');
  const label = button.textContent;
  button.textContent = w.downloading;
  try {
    const list = await rows(Array.from({ length: info.parts }, (_, i) => part(i)));
    if (!list) throw new Error('missing');
    const bin = atob(list.join(''));
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i += 1) bytes[i] = bin.charCodeAt(i);
    const url = URL.createObjectURL(new Blob([bytes], { type }));
    const a = el('a', { href: url, download: info.name });
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 60000);
  } catch { Orch.toast(w.failed, { error: true }); }
  button.disabled = false;
  button.removeAttribute('aria-busy');
  button.textContent = label;
}

window.addEventListener('hashchange', () => location.reload());
start();
