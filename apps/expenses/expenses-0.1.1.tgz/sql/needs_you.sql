SELECT 'receipt' AS kind, r._id AS id, r.file_name AS title, r.note AS note, r.source AS source, r.email_from AS who, r._updated_at AS at
FROM ex_receipts r WHERE r._deleted = 0 AND r.status = 'Failed'
UNION ALL
SELECT 'email' AS kind, m._id AS id, m.subject AS title, m.error AS note, 'email' AS source, m.to_email AS who, m._updated_at AS at
FROM ex_emails m WHERE m._deleted = 0 AND m.status = 'Failed'
