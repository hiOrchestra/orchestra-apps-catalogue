SELECT e.month AS month, e.currency AS currency,
  SUM(CASE WHEN e.status = 'Approved' THEN 1 ELSE 0 END) AS approved,
  SUM(CASE WHEN e.status = 'Review' THEN 1 ELSE 0 END) AS review,
  SUM(CASE WHEN e.status = 'Approved' THEN e.total ELSE 0 END) AS total,
  SUM(CASE WHEN e.status = 'Approved' THEN COALESCE(e.tax, 0) ELSE 0 END) AS tax,
  (SELECT m.status FROM ex_months m WHERE m._deleted = 0 AND m.month = e.month) AS state
FROM ex_expenses e WHERE e._deleted = 0 AND e.status <> 'Rejected' AND COALESCE(e.month, '') <> ''
GROUP BY e.month, e.currency
