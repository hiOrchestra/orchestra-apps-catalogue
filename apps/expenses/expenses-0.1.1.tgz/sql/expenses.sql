SELECT e._id, e.status, e.vendor, e.number, e.date, e.month, e.currency, e.total, e.tax, e.tax_rate, e.category, e.description,
  e.paid_by, e.reimbursed_at, e.confidence, e.read_by, e.duplicate_of, e.receipt_id, e._created_at,
  r.file_name AS receipt_name, r.source AS receipt_source, r.email_from AS receipt_from,
  CASE WHEN e.paid_by IS NOT NULL AND e.paid_by <> 'company' AND e.reimbursed_at IS NULL AND e.status = 'Approved' THEN 'yes' ELSE 'no' END AS owed
FROM ex_expenses e LEFT JOIN ex_receipts r ON r._id = e.receipt_id
WHERE e._deleted = 0
