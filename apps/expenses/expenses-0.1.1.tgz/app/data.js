// What the desk reads, the only things it writes, and what the screens share.
// Receipts are read on the instance (read.js, look.js), never here; the
// month is closed there too (close.js). excore.js holds the rules the scripts
// share: money, categories, a month's totals.
import './excore.js';

export const C = self.ExCore;
const { el } = Orch;

export const T = { settings: 'ex_settings', receipts: 'ex_receipts', expenses: 'ex_expenses', months: 'ex_months', emails: 'ex_emails' };
export const V = { expenses: 'expenses', needs: 'needs_you', months: 'months' };
export const A = {
  save: 'save_expense', approve: 'approve_expense', reject: 'reject_expense', back: 'back_to_review', add: 'add_expense', byHand: 'enter_by_hand',
  reimbursed: 'mark_reimbursed', notReimbursed: 'unmark_reimbursed', readAgain: 'read_again', dismiss: 'dismiss_receipt', checkFiles: 'check_files',
  settings: 'update_settings', checkResend: 'check_resend', closeNew: 'close_new_month', close: 'close_month', send: 'send_month', reopen: 'reopen_month',
  retryEmail: 'retry_email', dropEmail: 'drop_email', dismissStart: 'dismiss_start',
};

const PORTAL_ORIGIN = (() => {
  try {
    const o = document.referrer ? new URL(document.referrer).origin : '';
    if (/^https:\/\/([a-z0-9-]+\.)*(hiorchestra\.com|orchestra-portal[a-z0-9-]*\.up\.railway\.app)$/.test(o)) return o;
  } catch { /* no referrer */ }
  return 'https://hiorchestra.com';
})();
export const PORTAL = (p) => el('a', { href: `${PORTAL_ORIGIN}/portal/${p[0]}`, target: '_top', rel: 'noopener' }, p[1]);
export const FILES = ['files', 'Files'];
export const EMAIL_CHANNEL = ['channels', 'Channels → Email'];
export const INTEGRATIONS = ['integrations', 'Integrations'];

export async function act(name, params, done) {
  try {
    const r = await Orch.action(name, params);
    if (done) Orch.toast(done);
    return r || {};
  } catch (e) {
    Orch.toast(e.status === 409 ? 'It changed in the meantime: look again.' : (e.message || 'That did not work.'), { error: true });
    return null;
  }
}

let cached = null;
export async function settings(fresh) {
  if (!cached || fresh) cached = (await Orch.db.list(T.settings, { sort: '_id:asc', limit: 1 })).rows[0] || {};
  return cached;
}

const LOCALE = () => (cached && cached.language === 'es' ? 'es-ES' : undefined);
export const money = (n, cur) => C.money(n, cur || (cached && cached.currency) || 'EUR', LOCALE());
export const when = (v) => { if (!v) return null; const s = String(v).trim(); const d = new Date(/[zZ]|[+-]\d\d:?\d\d$/.test(s) ? s : `${s.replace(' ', 'T')}Z`); return Number.isNaN(d.getTime()) ? null : d; };
export const ago = (v) => { const d = when(v); return d ? Orch.fmt.ago(d.toISOString()) : ''; };
export function day(v) {
  const d = C.realDay(v);
  return d ? new Intl.DateTimeFormat(LOCALE(), { day: 'numeric', month: 'short', year: 'numeric', timeZone: 'UTC' }).format(new Date(`${d}T00:00:00Z`)) : '—';
}
export const thisMonth = (s) => C.today((s && s.timezone) || 'UTC').slice(0, 7);

const TONE = { Approved: 'good', Review: 'accent', Rejected: 'bad', Closed: 'good', Closing: 'accent', Working: 'accent', Open: '', Failed: 'bad', Sent: 'good' };
const SAID = { Review: 'To review', Working: 'Closing' };
export const badge = (state, said) => el('span', { class: `oc-badge${TONE[state] ? ` oc-badge--${TONE[state]}` : ''}` }, said || SAID[state] || state || '—');

export function sheet(content, opts) {
  const d = Orch.dialog(content, opts);
  window.addEventListener('hashchange', () => { try { d.close(); } catch { /* closed */ } }, { once: true });
  return d;
}
export const head = (title, lede, tools) => el('header', { class: 'ex-head' }, [
  el('div', { class: 'ex-head__title' }, [el('h1', { class: 'oc-h1 oc-h1--collection' }, title), lede ? el('p', { class: 'oc-lede' }, lede) : null]),
  tools ? el('div', { class: 'ex-head__tools' }, tools) : null,
]);
export const input = (value, attrs) => el('input', Object.assign({ class: 'oc-input', value: value == null ? '' : String(value) }, attrs || {}));
export const area = (value, rows, attrs) => el('textarea', Object.assign({ class: 'oc-textarea', rows: String(rows || 3) }, attrs || {}), value == null ? '' : String(value));
export const field = (label, control, help) => el('label', { class: 'oc-field' }, [el('span', { class: 'oc-label' }, label), control, help ? el('span', { class: 'oc-help' }, help) : null]);
export const select = (value, options) => el('select', { class: 'oc-select' }, options.map(([v, label]) => el('option', { value: v, selected: String(v) === String(value) }, label)));

export function row({ to, first, name, sub, right }) {
  const inner = [el('span', { class: 'ex-row__first oc-value' }, first || ''), el('span', { class: 'ex-row__name' }, [el('span', name || '—'), sub ? el('span', { class: 'ex-row__sub' }, sub) : null]),
    el('span', { class: 'ex-row__right' }, right || '')];
  return el('li', { class: 'ex-row' }, Orch.router.link(to, inner, { class: 'ex-row__open' }));
}

/** One expense as a thin row. */
export const expenseRow = (e) => row({
  to: `/expense/${e._id}`, first: day(e.date), name: e.vendor || 'Unknown vendor',
  sub: [e.category, e.description, e.paid_by && e.paid_by !== 'company' ? `paid by ${e.paid_by}${e.reimbursed_at ? ', paid back' : ''}` : '', e.duplicate_of ? 'possible duplicate' : '', e.read_by === 'agent' ? 'read from a photo' : ''].filter(Boolean).join(' · '),
  right: [el('span', { class: 'oc-value' }, money(e.total, e.currency)), e.status === 'Review' ? null : badge(e.status)],
});
