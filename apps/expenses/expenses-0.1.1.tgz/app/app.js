// The router and the bar. To review is home: what was read and waits for a
// look, and what could not be read. An expense opens on its own page, its
// receipt beside the form. Expenses lists them all; Month is the numbers and
// the close.
import { render as review } from './screens/review.js';
import { render as expense } from './screens/expense.js';
import { render as list } from './screens/list.js';
import { render as month } from './screens/month.js';
import { render as settings } from './screens/settings.js';

const { el, router } = Orch;

router.define({
  '/': review,
  '/expense/:id': expense,
  '/receipt/:rid': expense,
  '/new': (p, path) => expense({ fresh: true }, path),
  '/expenses': list,
  '/expenses/:month': list,
  '/month': month,
  '/month/:month': month,
  '/settings': settings,
}, () => Orch.mount('view', el('div', { class: 'oc-state' }, [
  el('p', 'There is no screen here.'), router.link('/', 'Go to To review'),
]))).start();

Orch.mount('nav', [
  router.link('/', 'To review', { class: 'oc-tab' }),
  router.link('/expenses', 'Expenses', { class: 'oc-tab' }),
  router.link('/month', 'Month', { class: 'oc-tab' }),
  router.link('/settings', 'Settings', { class: 'oc-tab' }),
]);
