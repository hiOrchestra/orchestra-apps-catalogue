// The expense form beside its receipt, and its buttons: what a reader filled
// in, all editable. Approve (and on to the next) or Reject while it waits for
// review; Save, back to review and "paid back" once approved; Add for a
// receipt entered by hand or an expense with no receipt.
import { A, C, act, area, day, field, input, money, select } from '../data.js';

const { el, router } = Orch;
const RATES = [['', '—'], ['0', '0 %'], ['4', '4 %'], ['5', '5 %'], ['10', '10 %'], ['20', '20 %'], ['21', '21 %'], ['other', 'Other']];

export function form({ s, e, r, fresh, locked, next, again }) {
  const cur0 = (e && e.currency) || s.currency || 'EUR';
  const cats = C.categoriesOf(s);
  const rate0 = e && e.tax_rate !== null && e.tax_rate !== undefined ? String(Number(e.tax_rate)) : '';
  const c = {
    vendor: input(e ? e.vendor : '', { maxlength: '120', required: true }),
    date: input(e ? e.date : C.today(s.timezone), { type: 'date' }),
    total: input(e ? C.plain(e.total, cur0) : '', { inputmode: 'decimal', class: 'oc-input ex-amount', placeholder: '0.00' }),
    currency: select(cur0, [...new Set([cur0, ...C.CURRENCIES])].map((x) => [x, x])),
    rate: select(RATES.some((x) => x[0] === rate0) ? rate0 : (rate0 ? 'other' : ''), RATES),
    rateOther: input(RATES.some((x) => x[0] === rate0) ? '' : rate0, { inputmode: 'decimal', class: 'oc-input ex-amount', placeholder: '%', 'aria-label': 'Other VAT rate' }),
    tax: input(e && e.tax !== null && e.tax !== undefined ? C.plain(e.tax, cur0) : '', { inputmode: 'decimal', class: 'oc-input ex-amount', placeholder: 'from the rate' }),
    category: select(e && e.category ? e.category : '', [['', 'Choose…'], ...[...new Set([...(e && e.category && !cats.includes(e.category) ? [e.category] : []), ...cats])].map((x) => [x, x])]),
    description: input(e ? e.description : '', { maxlength: '160' }),
    vendor_tax_id: input(e ? e.vendor_tax_id : '', { maxlength: '40' }),
    number: input(e ? e.number : '', { maxlength: '60' }),
    payer: select(e && e.paid_by && e.paid_by !== 'company' ? 'person' : 'company', [['company', 'The company'], ['person', 'A person (to pay back)']]),
    person: input(e && e.paid_by && e.paid_by !== 'company' ? e.paid_by : '', { maxlength: '80', placeholder: 'Who paid', 'aria-label': 'Who paid' }),
    notes: area(e ? e.notes : '', 2, { maxlength: '500' }),
  };
  const showRate = () => { c.rateOther.hidden = c.rate.value !== 'other'; c.person.hidden = c.payer.value !== 'person'; };
  c.rate.addEventListener('change', showRate);
  c.payer.addEventListener('change', showRate);
  showRate();
  // The VAT follows the rate until a person writes it.
  let taxTouched = !!(e && e.tax !== null && e.tax !== undefined);
  c.tax.addEventListener('input', () => { taxTouched = true; });
  const fill = () => {
    if (taxTouched) return;
    const total = C.toMinor(c.total.value, c.currency.value);
    const rate = Number(c.rate.value === 'other' ? c.rateOther.value : c.rate.value);
    if (total && Number.isFinite(rate) && c.rate.value !== '') c.tax.placeholder = C.plain(total - Math.round(total / (1 + rate / 100)), c.currency.value);
  };
  [c.total, c.rate, c.rateOther, c.currency].forEach((n) => n.addEventListener('input', fill));
  fill();

  const params = () => {
    const cur = c.currency.value;
    const total = C.toMinor(c.total.value, cur);
    const rateRaw = c.rate.value === 'other' ? c.rateOther.value : c.rate.value;
    const rate = rateRaw === '' ? null : Number(String(rateRaw).replace(',', '.'));
    let tax = String(c.tax.value).trim() ? C.toMinor(c.tax.value, cur) : (rate !== null && Number.isFinite(rate) && total ? total - Math.round(total / (1 + rate / 100)) : null);
    if (tax !== null && (tax < 0 || tax >= total)) tax = null;
    const date = C.realDay(c.date.value);
    const problem = !String(c.vendor.value).trim() ? 'Write who sold it.' : !total || total <= 0 ? 'Write the total paid.' : !date ? 'Choose the date.' : !c.category.value ? 'Choose a category.'
      : c.payer.value === 'person' && !String(c.person.value).trim() ? 'Write who paid it.' : null;
    return { problem, data: { vendor: String(c.vendor.value).trim(), date, month: date.slice(0, 7), currency: cur, total, tax: tax === null ? '' : tax, net: tax === null ? '' : total - tax,
      tax_rate: rate === null || !Number.isFinite(rate) ? '' : rate, category: c.category.value, description: String(c.description.value).trim(), vendor_tax_id: String(c.vendor_tax_id.value).trim(),
      number: String(c.number.value).trim(), paid_by: c.payer.value === 'person' ? String(c.person.value).trim() : 'company', notes: String(c.notes.value).trim() } };
  };
  const go = (name, extra, done, then) => async () => {
    const p = params();
    if (p.problem && name !== A.reject) { Orch.toast(p.problem, { error: true }); return; }
    const r = await act(name, Object.assign(e ? { id: e._id } : {}, name === A.reject ? {} : p.data, extra || {}), done);
    if (r) then(r);
  };
  const buttons = [];
  if (!e) {
    buttons.push(el('button', { type: 'button', class: 'oc-btn oc-btn--primary', onClick: go(r ? A.byHand : A.add, r ? { receipt_id: r._id } : {}, 'Added: it waits for review.', (x) => router.go(x._id || (x.results && x.results[0] && x.results[0]._id) ? `/expense/${x._id || x.results[0]._id}` : '/')) }, 'Add it'));
    if (r) {
      buttons.push(el('button', { type: 'button', class: 'oc-btn', onClick: async () => { if (await act(A.readAgain, { id: r._id }, 'Reading it again…')) router.go('/'); } }, 'Try reading again'));
      buttons.push(el('button', { type: 'button', class: 'oc-btn oc-btn--ghost', onClick: async () => { if (await Orch.confirm('Set this receipt aside? It stays in Files; nothing is counted.', { yes: 'Set aside' }) && await act(A.dismiss, { id: r._id }, 'Set aside.')) router.go('/'); } }, 'Not an expense'));
    }
  } else if (e.status === 'Review' && !locked) {
    buttons.push(el('button', { type: 'button', class: 'oc-btn oc-btn--primary', onClick: go(A.approve, null, 'Approved.', () => router.go(next ? `/expense/${next._id}` : '/')) }, next ? 'Approve and next' : 'Approve'));
    buttons.push(el('button', { type: 'button', class: 'oc-btn', onClick: go(A.save, null, 'Saved.', () => again()) }, 'Save'));
    buttons.push(el('span', { class: 'ex-grow' }));
    buttons.push(el('button', { type: 'button', class: 'oc-btn oc-btn--ghost', onClick: async () => {
      const why = await askWhy();
      if (why === null) return;
      if (await act(A.reject, { id: e._id, rejected_reason: why }, 'Rejected.')) router.go(next ? `/expense/${next._id}` : '/');
    } }, 'Reject'));
  } else if (!locked) {
    buttons.push(el('button', { type: 'button', class: 'oc-btn oc-btn--primary', onClick: go(A.save, null, 'Saved.', () => again()) }, 'Save'));
    buttons.push(el('button', { type: 'button', class: 'oc-btn', onClick: async () => { if (await act(A.back, { id: e._id }, 'Back to review.')) again(); } }, 'Back to review'));
    if (e.status === 'Approved' && e.paid_by && e.paid_by !== 'company') {
      buttons.push(e.reimbursed_at
        ? el('button', { type: 'button', class: 'oc-btn oc-btn--ghost', onClick: async () => { if (await act(A.notReimbursed, { id: e._id })) again(); } }, 'Not paid back yet')
        : el('button', { type: 'button', class: 'oc-btn oc-btn--ghost', onClick: async () => { if (await act(A.reimbursed, { id: e._id }, `Marked as paid back to ${e.paid_by}.`)) again(); } }, `Paid back to ${e.paid_by}`));
    }
  }
  const disabled = locked || (e && e.status === 'Rejected');
  for (const n of Object.values(c)) if (disabled) n.disabled = true;
  return el('aside', { class: 'oc-stack ex-side ex-form' }, [
    el('section', { class: 'ex-sidesec oc-stack' }, [
      field('Vendor', c.vendor),
      el('div', { class: 'ex-two' }, [field('Date', c.date), field('Category', c.category)]),
      el('div', { class: 'ex-two' }, [field('Total paid', c.total, 'Tax included.'), field('Currency', c.currency)]),
      el('div', { class: 'ex-two' }, [field('VAT rate', el('div', { class: 'oc-stack oc-stack--tight' }, [c.rate, c.rateOther])), field('VAT amount', c.tax, 'Empty: worked out from the rate.')]),
      field('What it was', c.description),
      el('div', { class: 'ex-two' }, [field('Paid by', el('div', { class: 'oc-stack oc-stack--tight' }, [c.payer, c.person])), field('Vendor tax ID', c.vendor_tax_id)]),
      field('Invoice or receipt number', c.number),
      field('Notes', c.notes),
    ]),
    buttons.length ? el('div', { class: 'ex-sidesec oc-row ex-actions' }, buttons) : null,
    e && e.status === 'Approved' && e.paid_by && e.paid_by !== 'company' ? el('p', { class: 'ex-sidesec oc-help' }, e.reimbursed_at ? `Paid back to ${e.paid_by} ${day(String(e.reimbursed_at).slice(0, 10))}.` : `${money(e.total, e.currency)} is owed back to ${e.paid_by}.`) : null,
  ]);
}

function askWhy() {
  return new Promise((resolve) => {
    const why = input('', { maxlength: '200', placeholder: 'Optional: not a business expense, a duplicate…' });
    const yes = el('button', { type: 'button', class: 'oc-btn oc-btn--danger' }, 'Reject');
    const box = el('div', { class: 'oc-stack' }, [el('p', 'It stays here and in Files, but does not count in any month.'), field('Why', why),
      el('div', { class: 'oc-row' }, [yes, el('button', { type: 'button', class: 'oc-btn oc-btn--ghost', onClick: () => { d.close(); resolve(null); } }, 'Keep it')])]);
    const d = Orch.dialog(box, { title: 'Reject this expense?' });
    yes.addEventListener('click', () => { d.close(); resolve(String(why.value).trim()); });
  });
}
