// One expense, its receipt beside the form: everything the reader filled in
// can be changed. To review: Approve (and on to the next), or Reject. Once
// approved: Save, back to review, and "paid back" when a person paid. The
// same screen enters a receipt that could not be read (/receipt/<id>) and an
// expense with no receipt (/new). A month that is closed is not touched
// without reopening it (Month).
import { C, T, badge, day, money, settings } from '../data.js';
import { form } from './form.js';

const { el, router } = Orch;

export function render({ id, rid, fresh }) {
  Orch.load('view', async () => {
    const s = await settings(true);
    let e = null;
    let r = null;
    if (id) {
      e = await Orch.db.get(T.expenses, Number(id));
      if (!e) return el('div', { class: 'oc-state' }, [el('p', 'This expense is not here.'), router.link('/', 'To review')]);
      if (e.receipt_id) r = await Orch.db.get(T.receipts, e.receipt_id);
    } else if (rid) {
      r = await Orch.db.get(T.receipts, Number(rid));
      if (!r) return el('div', { class: 'oc-state' }, [el('p', 'This receipt is not here.'), router.link('/', 'To review')]);
      if (r.expense_id) { router.go(`/expense/${r.expense_id}`); return el('p', ''); }
    }
    const month = e && e.month ? await Orch.db.find(T.months, { month: e.month }) : null;
    const twin = e && e.duplicate_of ? await Orch.db.get(T.expenses, e.duplicate_of) : null;
    const next = e && e.status === 'Review' ? ((await Orch.db.list(T.expenses, { filter: { status: 'Review', _id: { gt: e._id } }, sort: '_id:asc', limit: 1 })).rows[0] || null) : null;
    const title = e ? e.vendor || 'Unknown vendor' : r ? 'Enter this receipt' : 'Add an expense';
    return el('div', { class: 'oc-stack oc-stack--loose' }, [
      el('header', { class: 'ex-envhead' }, [
        router.link(e && e.status !== 'Review' ? '/expenses' : '/', e && e.status !== 'Review' ? '← Expenses' : '← To review', { class: 'ex-back' }),
        el('div', { class: 'ex-envhead__line' }, [
          el('div', { class: 'ex-envhead__name' }, [el('h1', { class: 'oc-h1 ex-envtitle' }, title), el('p', { class: 'oc-lede' }, sentence(e, r))]),
          e ? badge(e.status) : null,
        ]),
      ]),
      twin ? el('p', { class: 'ex-warn' }, ['It looks like a copy of ', router.link(`/expense/${twin._id}`, `${twin.vendor}, ${day(twin.date)}, ${money(twin.total, twin.currency)}`), ` (${twin.status === 'Review' ? 'also to review' : twin.status.toLowerCase()}). If it is the same purchase, reject this one.`]) : null,
      month && month.status !== 'Open' ? el('p', { class: 'ex-warn' }, [`${C.monthName(e.month, 'en')} is closed. To change this expense, reopen the month first: `, router.link(`/month/${e.month}`, 'Month →')]) : null,
      el('div', { class: 'ex-split' }, [receiptPanel(r), form({ s, e, r, fresh, locked: !!(month && month.status !== 'Open'), next, again: () => render({ id: e && e._id }) })]),
    ]);
  });
}

function sentence(e, r) {
  if (!e && r) return r.note || 'It could not be read: fill in what it says, and it waits for review like the others.';
  if (!e) return 'Cash, or a receipt you do not have: it waits for review like the others.';
  const from = e.read_by === 'agent' ? 'Read from a photo by the agent' : e.read_by === 'model' ? 'Read from the receipt\'s text' : 'Entered by hand';
  const conf = e.confidence === 'low' ? ': it was not sure, check every number' : e.confidence === 'medium' ? ': check the amounts' : '';
  return e.status === 'Review' ? `${from}${conf}. ${e.receipt_id ? 'Check it against the receipt, then approve.' : 'Check it, then approve.'}` : e.status === 'Approved' ? `Approved ${e.approved_at ? day(String(e.approved_at).slice(0, 10)) : ''}. It counts in its month.` : `Rejected${e.rejected_reason ? `: ${e.rejected_reason}` : ''}. It does not count.`;
}

function receiptPanel(r) {
  if (!r) return el('div', { class: 'ex-receipt' }, el('p', { class: 'oc-help' }, 'No receipt: entered by hand.'));
  const meta = [r.file_name, r.source === 'email' ? `forwarded by ${r.email_from}` : r.source === 'files' ? 'from Files' : '', r.received_at ? day(String(r.received_at).slice(0, 10)) : ''].filter(Boolean).join(' · ');
  return el('div', { class: 'ex-receipt' }, [
    r.preview ? el('img', { src: r.preview, alt: `The receipt ${r.file_name || ''}` }) : r.text ? el('pre', r.text) : el('p', { class: 'oc-help' }, 'No picture of this receipt. It is in Files.'),
    el('div', { class: 'ex-receipt__meta' }, [el('span', meta), r.file_id ? el('span', 'The original is in Files') : null]),
  ]);
}

