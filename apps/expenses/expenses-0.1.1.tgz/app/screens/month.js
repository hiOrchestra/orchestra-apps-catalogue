// A month: its approved numbers (per currency, per category, VAT per rate,
// owed back), what still waits for review, and the close. Close makes the
// PDF (summary + every receipt) and the CSV in Files; Send emails them to the
// accountant (a link to them, by Resend or Gmail). A closed month is reopened in two steps.
import { A, C, FILES, PORTAL, T, V, act, ago, badge, field, head, input, money, select, settings, sheet, thisMonth } from '../data.js';

const { el, router } = Orch;

export function render({ month } = {}) {
  Orch.load('view', async () => {
    const s = await settings(true);
    const cur = thisMonth(s);
    const m = /^\d{4}-\d{2}$/.test(month || '') ? month : cur;
    const [rows, mo, mlist] = await Promise.all([
      Orch.db.list(T.expenses, { filter: { month: m, status: ['Approved', 'Review'] }, sort: 'date:asc', limit: 500 }),
      Orch.db.find(T.months, { month: m }),
      Orch.db.view(V.months, { limit: 200 }),
    ]);
    const approved = (rows.rows || []).filter((e) => e.status === 'Approved');
    const review = (rows.rows || []).filter((e) => e.status === 'Review');
    const sums = C.summary(approved);
    const state = mo ? mo.status : 'Open';
    if (state === 'Closing' || state === 'Working') setTimeout(() => { if (location.hash.startsWith('#/month')) render({ month: m }); }, 5000);
    const months = [...new Set([m, cur, C.prevMonth(cur), ...((mlist.rows || []).map((r) => r.month))])].sort().reverse();
    const pick = select(m, months.map((x) => [x, C.monthName(x, 'en')]));
    pick.addEventListener('change', () => router.go(`/month/${pick.value}`));
    return el('div', { class: 'oc-stack oc-stack--loose' }, [
      head(C.monthName(m, 'en') || m, 'What counts this month, and what goes to your accountant.', [pick]),
      el('div', { class: 'ex-monthbar' }, [badge(state === 'Working' ? 'Closing' : state), mo && mo.closed_at && state === 'Closed' ? el('span', { class: 'oc-help' }, `Closed ${ago(mo.closed_at)}.`) : null,
        review.length ? router.link(`/expenses/${m}?tab=Review`, `${review.length} still to review →`, { class: 'oc-small' }) : null]),
      mo && mo.close_note ? el('p', { class: 'ex-warn' }, mo.close_note) : null,
      ...(sums.length ? sums.map((u) => block(u, s)) : [el('div', { class: 'oc-card oc-state' }, el('p', { class: 'oc-help' }, review.length ? 'Nothing approved yet this month.' : 'No expenses this month.'))]),
      closePanel({ s, m, mo, state, approved, review }),
    ]);
  });
}

function block(u, s) {
  const cat = (c) => c;
  return el('section', { class: 'oc-stack' }, [
    el('div', { class: 'ex-kpis' }, [
      kpi('Total', money(u.total, u.currency), `${u.count} expense${u.count === 1 ? '' : 's'}`),
      kpi('Net', money(u.net, u.currency), u.noTax ? `${money(u.noTax, u.currency)} with no VAT shown` : 'before VAT'),
      kpi('VAT', money(u.tax, u.currency), 'input VAT, to deduct'),
      kpi('Owed back', money(Object.values(u.reimburse).reduce((a, b) => a + b, 0), u.currency), Object.keys(u.reimburse).join(', ') || 'nobody'),
    ]),
    el('div', { class: 'ex-two ex-two--tables' }, [
      el('div', { class: 'oc-card' }, el('table', { class: 'ex-table' }, [el('thead', el('tr', [el('th', 'Category'), el('th', { class: 'r' }, 'VAT'), el('th', { class: 'r' }, 'Total')])),
        el('tbody', Object.entries(u.byCategory).sort((a, b) => b[1].total - a[1].total).map(([k, v]) => el('tr', [el('td', `${cat(k)} (${v.count})`), el('td', { class: 'r' }, money(v.tax, u.currency)), el('td', { class: 'r' }, money(v.total, u.currency))])))])),
      el('div', { class: 'oc-card' }, el('table', { class: 'ex-table' }, [el('thead', el('tr', [el('th', 'VAT rate'), el('th', { class: 'r' }, 'Net'), el('th', { class: 'r' }, 'VAT')])),
        el('tbody', Object.entries(u.byRate).map(([k, v]) => el('tr', [el('td', k === '?' ? 'Rate not shown' : `${k} %`), el('td', { class: 'r' }, money(v.net, u.currency)), el('td', { class: 'r' }, money(v.tax, u.currency))])))])),
    ]),
  ]);
}
const kpi = (label, value, sub) => el('div', [el('span', { class: 'oc-kpi__label' }, label), el('span', { class: 'oc-kpi__value' }, value), el('span', { class: 'oc-help' }, sub)]);

function closePanel({ s, m, mo, state, approved, review }) {
  const st = C.senders(s);
  const to = input((mo && mo.send_to) || s.accountant_email || '', { type: 'email', maxlength: '200', placeholder: 'accountant@firm.com', 'aria-label': 'The accountant\'s email' });
  const sec = (kids) => el('section', { class: 'oc-card oc-stack ex-close' }, kids);
  if (state === 'Closing' || state === 'Working') return sec([el('h2', { class: 'oc-h2' }, 'Closing the month'), el('p', { class: 'oc-help' }, 'Making the PDF with every receipt and the CSV. Under a minute.')]);
  if (state !== 'Closed') {
    const close = el('button', { type: 'button', class: 'oc-btn oc-btn--primary', disabled: !approved.length }, 'Close the month');
    close.addEventListener('click', async () => {
      if (review.length && !await Orch.confirm(`${review.length} expense${review.length === 1 ? '' : 's'} of this month still wait for review and will not be in it. Close anyway?`, { yes: 'Close without them' })) return;
      close.disabled = true;
      const r = mo ? await act(A.close, { id: mo._id }) : await act(A.closeNew, { month: m });
      if (r) render({ month: m }); else close.disabled = false;
    });
    return sec([el('h2', { class: 'oc-h2' }, 'Close the month'),
      el('p', { class: 'oc-help' }, ['Makes one PDF (the summary, then every receipt behind it) and a CSV, both saved in ', PORTAL(FILES), ', folder "Expenses". Then you can email them to your accountant. Approved expenses of a closed month do not change until you reopen it.']),
      el('div', { class: 'oc-row' }, close)]);
  }
  const send = el('button', { type: 'button', class: 'oc-btn oc-btn--primary', disabled: !st.ready }, mo.sent_at ? 'Send again' : 'Send to the accountant');
  send.addEventListener('click', async () => {
    if (!C.isEmail(to.value)) { Orch.toast('Write the accountant\'s email.', { error: true }); to.focus(); return; }
    if (!await Orch.confirm(`Email ${C.normEmail(to.value)} a private link to the PDF and the CSV of ${C.monthName(m, 'en')}?`, { yes: 'Send' })) return;
    send.disabled = true;
    if (await act(A.send, { id: mo._id, send_to: C.normEmail(to.value) }, 'It goes out in a moment.')) setTimeout(() => render({ month: m }), 6000);
    else send.disabled = false;
  });
  return sec([el('h2', { class: 'oc-h2' }, 'Closed'),
    el('p', [`${mo.count || approved.length} expenses. In `, PORTAL(FILES), `, folder "Expenses": ${mo.pdf_name || ''} and ${mo.csv_name || ''}.`]),
    el('div', { class: 'ex-two' }, [field('Accountant', to, mo.sent_at ? `Sent ${ago(mo.sent_at)} to ${mo.send_to}.` : st.say), el('div', { class: 'oc-row', style: 'align-self:center' }, send)]),
    mo.send_note ? el('p', { class: 'ex-bad' }, mo.send_note) : null,
    el('button', { type: 'button', class: 'ex-linkish ex-dangerlink', onClick: () => reopen(mo, m, s) }, 'Reopen the month…'),
  ]);
}

function reopen(mo, m, s) {
  const ack = el('input', { type: 'checkbox' });
  const go = el('button', { type: 'button', class: 'oc-btn oc-btn--danger', disabled: true }, 'Reopen');
  ack.addEventListener('change', () => { go.disabled = !ack.checked; });
  const box = el('div', { class: 'oc-stack' }, [
    el('p', `Reopening lets you change ${C.monthName(m, 'en')}'s expenses again. The PDF and the CSV already in Files, and what your accountant's link gives, stay as they were until you close it again: then the same link gives the new ones.`),
    el('label', { class: 'ex-check' }, [ack, el('span', 'I understand the files already sent will not match until I close it again')]),
    el('div', { class: 'oc-row' }, [go, el('button', { type: 'button', class: 'oc-btn oc-btn--ghost', onClick: () => d.close() }, 'Keep it closed')]),
  ]);
  const d = sheet(box, { title: 'Reopen the month?' });
  go.addEventListener('click', async () => { go.disabled = true; if (await act(A.reopen, { id: mo._id }, 'Reopened.')) { d.close(); render({ month: m }); } });
}
