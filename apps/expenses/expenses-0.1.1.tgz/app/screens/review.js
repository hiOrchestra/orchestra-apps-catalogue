// Home: what was read and waits for a person's look (oldest first: the order
// they came in), what could not be read ("Needs you"), and a line while
// receipts are still being read (the page looks again on its own). Getting
// started sits on top until the company and the way receipts get in are set.
import { A, PORTAL, FILES, T, V, act, ago, badge, expenseRow, head, settings } from '../data.js';
import { startCard } from './start.js';

const { el, router } = Orch;

export function render() {
  Orch.load('view', async () => {
    const s = await settings(true);
    if (!s._id) return el('p', { class: 'oc-state' }, 'Expenses is not installed in this project.');
    const [rows, needs, reading] = await Promise.all([
      Orch.db.view(V.expenses, { filter: { status: 'Review' }, sort: '_id:asc', limit: 300 }),
      Orch.db.view(V.needs, { sort: 'at:desc', limit: 30 }),
      Orch.db.count(T.receipts, { filter: { status: ['New', 'Reading', 'Look', 'Looking'] } }),
    ]);
    const list = rows.rows || [];
    const busy = Number(reading) || 0;
    if (busy) setTimeout(() => { if (location.hash === '#/' || location.hash === '' || location.hash === '#') render(); }, 8000);
    const checkFiles = el('button', { type: 'button', class: 'oc-btn', onClick: async () => {
      checkFiles.disabled = true; checkFiles.textContent = 'Looking in Files…';
      if (await act(A.checkFiles, { id: s._id, mode: '--files' })) setTimeout(render, 6000);
    } }, 'Check Files');
    return el('div', { class: 'oc-stack oc-stack--loose' }, [
      head('To review', 'Receipts that were read: check each one against its picture, then approve it.', [checkFiles, router.link('/new', 'Add an expense', { class: 'oc-btn oc-btn--primary' })]),
      startCard(s, render),
      busy ? el('p', { class: 'ex-warn', role: 'status' }, `Reading ${busy} receipt${busy === 1 ? '' : 's'}… They appear here in a minute or two.`) : null,
      needsYou(needs.rows || []),
      list.length ? el('section', { class: 'oc-stack' }, [
        el('div', { class: 'oc-row oc-row--between' }, [el('h2', { class: 'oc-h2' }, `${list.length} to review`), router.link(`/expense/${list[0]._id}`, 'Start with the first →', { class: 'oc-small' })]),
        el('ul', { class: 'ex-rows' }, list.map(expenseRow)),
      ]) : el('div', { class: 'oc-card oc-state' }, [el('p', { class: 'oc-state__title' }, busy ? 'Nothing to review yet.' : 'Nothing to review.'),
        el('p', { class: 'oc-help' }, ['Forward a receipt to ', el('span', { class: 'ex-addr' }, s.inbox_address || 'the workspace address'), ' from one of the senders in Settings, or put it in the "', s.files_folder || 'Receipts', '" folder of ', PORTAL(FILES), ' and press Check Files.']),
        s.files_at ? el('p', { class: 'oc-help' }, `Files were last looked at ${ago(s.files_at)}.`) : null]),
    ]);
  });
}

function needsYou(items) {
  if (!items.length) return null;
  return el('section', { class: 'oc-stack' }, [
    el('h2', { class: 'oc-h2' }, 'Needs you'),
    el('ul', { class: 'ex-rows' }, items.map((x) => (x.kind === 'receipt'
      ? el('li', { class: 'ex-row' }, router.link(`/receipt/${x.id}`, [el('span', { class: 'ex-row__first oc-value' }, 'Receipt'),
        el('span', { class: 'ex-row__name' }, [el('span', x.title || 'A receipt'), el('span', { class: 'ex-row__sub' }, x.note || 'It could not be read.')]), el('span', { class: 'ex-row__right' }, badge('Failed', 'Enter it'))], { class: 'ex-row__open' }))
      : el('li', { class: 'ex-row' }, [el('div', { class: 'ex-row__open', style: 'cursor:default' }, [el('span', { class: 'ex-row__first oc-value' }, 'Email'),
        el('span', { class: 'ex-row__name' }, [el('span', x.title), el('span', { class: 'ex-row__sub' }, `To ${x.who} · ${x.note || ''}`)]), el('span', { class: 'ex-row__right' }, badge('Failed'))]),
        el('div', { class: 'ex-row__tools' }, [
          el('button', { type: 'button', class: 'oc-btn oc-btn--sm', onClick: async () => { if (await act(A.retryEmail, { id: x.id }, 'It goes out in a moment.')) render(); } }, 'Send again'),
          el('button', { type: 'button', class: 'oc-btn oc-btn--sm oc-btn--ghost', onClick: async () => { if (await act(A.dropEmail, { id: x.id }, 'Dropped.')) render(); } }, 'Drop')])])))),
  ]);
}
