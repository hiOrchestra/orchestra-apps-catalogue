// Every expense of a month (this one by default), with tabs per state and a
// filter per category and for what is owed back to people.
import { C, V, expenseRow, head, money, select, settings, thisMonth } from '../data.js';

const { el, router } = Orch;
const TABS = [['all', 'All'], ['Review', 'To review'], ['Approved', 'Approved'], ['Rejected', 'Rejected'], ['owed', 'Owed back']];

export function render({ month } = {}, path) {
  Orch.load('view', async () => {
    const s = await settings(true);
    const m = /^\d{4}-\d{2}$/.test(month || '') ? month : thisMonth(s);
    const q = new URLSearchParams(String(path || '').split('?')[1] || '');
    const tab = TABS.find((t) => t[0] === q.get('tab')) || TABS[0];
    const cat = q.get('category') || '';
    const all = (await Orch.db.view(V.expenses, { filter: { month: m }, sort: 'date:desc', limit: 500 })).rows || [];
    const shown = all.filter((e) => (tab[0] === 'all' ? true : tab[0] === 'owed' ? e.owed === 'yes' : e.status === tab[0]) && (!cat || e.category === cat));
    const count = (t) => all.filter((e) => (t === 'all' ? true : t === 'owed' ? e.owed === 'yes' : e.status === t)).length;
    const months = [...new Set([m, C.prevMonth(m), thisMonth(s), ...((await Orch.db.view(V.months, { limit: 200 })).rows || []).map((r) => r.month)])].filter(Boolean).sort().reverse();
    const go = (mm, t, c) => router.go(`/expenses/${mm}${t && t !== 'all' || c ? `?${new URLSearchParams(Object.assign(t && t !== 'all' ? { tab: t } : {}, c ? { category: c } : {})).toString()}` : ''}`);
    const pickMonth = select(m, months.map((x) => [x, C.monthName(x, 'en')]));
    pickMonth.addEventListener('change', () => go(pickMonth.value, tab[0], cat));
    const pickCat = select(cat, [['', 'Every category'], ...C.categoriesOf(s).map((x) => [x, x])]);
    pickCat.addEventListener('change', () => go(m, tab[0], pickCat.value));
    const totals = Object.values(shown.filter((e) => e.status !== 'Rejected').reduce((acc, e) => { (acc[e.currency] = acc[e.currency] || { c: e.currency, t: 0 }).t += Number(e.total) || 0; return acc; }, {}));
    return el('div', { class: 'oc-stack oc-stack--loose' }, [
      head('Expenses', 'Every expense of a month: what waits for review, what counts, what is owed back.', [router.link('/new', 'Add an expense', { class: 'oc-btn' })]),
      el('div', { class: 'ex-monthbar' }, [pickMonth, pickCat, router.link(`/month/${m}`, 'The month →', { class: 'oc-small' })]),
      el('nav', { class: 'oc-tabs', 'aria-label': 'Which ones' }, TABS.filter((t) => t === tab || count(t[0]) || t[0] === 'all').map((t) => el('a', {
        href: `#/expenses/${m}${t[0] === 'all' ? '' : `?tab=${t[0]}`}`, class: 'oc-tab', 'aria-current': t === tab ? 'page' : null }, [t[1], el('span', { class: 'oc-count' }, String(count(t[0])))]))),
      shown.length ? el('ul', { class: 'ex-rows' }, shown.map(expenseRow)) : el('div', { class: 'oc-card oc-state' }, el('p', { class: 'oc-help' }, 'No expenses here.')),
      totals.length ? el('p', { class: 'oc-help' }, `${shown.filter((e) => e.status !== 'Rejected').length} shown, ${totals.map((x) => money(x.t, x.c)).join(' + ')}.`) : null,
    ]);
  });
}
