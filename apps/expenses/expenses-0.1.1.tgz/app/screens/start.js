// Getting started: the two things the first receipt needs, checked from the
// data each time (never ticked by hand), gone once both are done or hidden.
// The steps follow listing.json's setup for the workspace email.
import { A, C, EMAIL_CHANNEL, FILES, PORTAL, act, field, input, select } from '../data.js';

const { el } = Orch;

export const companyDone = (s) => !!String(s.company_name || '').trim();
export const inDone = (s) => C.sendersOf(s).length > 0 && !s.rules_note && (() => { try { return JSON.parse(s.rules || '[]').length > 0; } catch { return false; } })();

export function startCard(s, again) {
  if (s.onboarding_dismissed_at) return null;
  const steps = [
    { title: 'Your company', done: companyDone(s), body: company },
    { title: 'How receipts get in', done: inDone(s), body: receipts },
  ];
  if (steps.every((x) => x.done)) return null;
  const open = steps.find((x) => !x.done);
  return el('section', { class: 'oc-card oc-card--pad0 ex-start', 'aria-label': 'Getting started' }, [
    el('div', { class: 'ex-start__head' }, [el('h2', { class: 'oc-h2' }, 'Getting started'), el('span', { class: 'oc-value oc-muted' }, `${steps.filter((x) => x.done).length} of ${steps.length}`)]),
    el('p', { class: 'oc-help ex-start__lede' }, 'Two things before the first receipt. The rest has a default you can change in Settings.'),
    el('ol', { class: 'ex-steps' }, steps.map((x, i) => el('li', { class: `ex-step${x.done ? ' ex-step--done' : ''}` }, [
      el('div', { class: 'ex-step__head' }, [el('span', { class: 'oc-value ex-step__n' }, String(i + 1).padStart(2, '0')), el('span', { class: 'ex-step__title' }, x.title),
        el('span', { class: `oc-badge${x.done ? ' oc-badge--good' : ''}` }, x.done ? 'Done' : 'To do')]),
      x === open ? el('div', { class: 'ex-step__body' }, x.body(s, again)) : null,
    ]))),
  ]);
}

function company(s, again) {
  const name = input(s.company_name, { maxlength: '160', required: true, placeholder: 'Lumen Studio S.L.' });
  const cur = select(s.currency || 'EUR', C.CURRENCIES.map((c) => [c, c]));
  const save = el('button', { type: 'submit', class: 'oc-btn oc-btn--primary' }, 'Save and continue');
  const f = el('form', { class: 'oc-stack ex-start__form' }, [
    el('p', { class: 'ex-step__why' }, 'Your company heads the month\'s summary your accountant gets, and the currency is the one a receipt is read in when it does not say.'),
    el('div', { class: 'ex-two' }, [field('Company name', name), field('Currency', cur)]),
    el('div', { class: 'oc-row' }, save),
  ]);
  f.addEventListener('submit', async (e) => {
    e.preventDefault();
    if (!String(name.value).trim()) { name.focus(); return; }
    save.disabled = true;
    if (await act(A.settings, { id: s._id, company_name: String(name.value).trim(), currency: cur.value, mode: '--rules' }, 'Saved.')) again();
    save.disabled = false;
  });
  return f;
}

function receipts(s, again) {
  const who = input(C.sendersOf(s).join(', '), { maxlength: '400', placeholder: 'you@gmail.com, *@yourcompany.com' });
  const save = el('button', { type: 'submit', class: 'oc-btn oc-btn--primary' }, 'Save');
  const f = el('form', { class: 'oc-stack ex-start__form' }, [
    el('p', { class: 'ex-step__why' }, ['Forward receipts to your workspace address: ', el('span', { class: 'ex-addr' }, s.inbox_address || 'see Channels → Email'),
      '. Each address below needs to be on the senders list of ', PORTAL(EMAIL_CHANNEL), ' (that list is yours to keep); Expenses then takes every mail from them whose subject says ',
      C.wordsOf(s).map((w) => `"${w}"`).join(', '), '.']),
    field('Who forwards receipts', who, 'Addresses, or *@domain for everyone at your company.'),
    s.rules_note ? el('p', { class: 'ex-bad' }, s.rules_note) : null,
    el('p', { class: 'oc-help' }, ['Or put receipts (PDF, JPG, PNG) in the "', s.files_folder || 'Receipts', '" folder of ', PORTAL(FILES), ', and press Check Files.']),
    el('div', { class: 'oc-row' }, [save, el('button', { type: 'button', class: 'ex-linkish', onClick: async () => { if (await act(A.dismissStart, { id: s._id })) again(); } }, 'Hide this')]),
  ]);
  f.addEventListener('submit', async (e) => {
    e.preventDefault();
    save.disabled = true;
    if (await act(A.settings, { id: s._id, forwarders: String(who.value).trim(), mode: '--rules' }, 'Saved. Setting the mail rules…')) setTimeout(again, 7000);
    save.disabled = false;
  });
  return f;
}
