// What every expense carries and how receipts get in: the company and its
// currency, the categories, who forwards receipts to the workspace address
// (the mail rules follow), the Files folder, and the accountant (Resend or Gmail). One
// form, one Save; saving sets the mail rules again.
import { A, C, EMAIL_CHANNEL, FILES, INTEGRATIONS, PORTAL, act, ago, area, field, head, input, select, settings } from '../data.js';

const { el } = Orch;
const ZONES = ['Europe/Madrid', 'Europe/London', 'Europe/Lisbon', 'Europe/Paris', 'Europe/Berlin', 'America/New_York', 'America/Chicago', 'America/Los_Angeles',
  'America/Mexico_City', 'America/Bogota', 'America/Lima', 'America/Santiago', 'America/Argentina/Buenos_Aires', 'America/Sao_Paulo', 'UTC'];

export function render() {
  Orch.load('view', async () => {
    const s = await settings(true);
    if (!s._id) return el('p', { class: 'oc-state' }, 'Expenses is not installed in this project.');
    return el('div', { class: 'oc-stack oc-stack--loose' }, [head('Settings', 'How receipts get in, how they are sorted, and who gets the month.'), form(s), legal()]);
  });
}

function form(s) {
  let rules = [];
  try { rules = JSON.parse(s.rules || '[]'); } catch { rules = []; }
  const c = {
    company_name: input(s.company_name, { maxlength: '160' }),
    currency: select(s.currency || 'EUR', C.CURRENCIES.map((x) => [x, x])),
    timezone: select(s.timezone || 'Europe/Madrid', [...new Set([s.timezone || 'Europe/Madrid', ...ZONES])].map((z) => [z, z])),
    language: select(s.language === 'en' ? 'en' : 'es', [['es', 'Español'], ['en', 'English']]),
    categories: area(C.categoriesOf(s).join('\n'), 8, { maxlength: '2000' }),
    forwarders: input(C.sendersOf(s).join(', '), { maxlength: '400', placeholder: 'you@gmail.com, *@yourcompany.com' }),
    subject_words: input(C.wordsOf(s).join(', '), { maxlength: '200' }),
    files_folder: input(s.files_folder || 'Receipts', { maxlength: '60' }),
    accountant_name: input(s.accountant_name, { maxlength: '80' }),
    accountant_email: input(s.accountant_email, { type: 'email', maxlength: '200', placeholder: 'accountant@firm.com' }),
    sender: select(C.senderOf(s), [['resend', 'Resend (from an address on your domain)'], ['gmail', 'Gmail (the account connected in Integrations)']]),
    resend_from_name: input(s.resend_from_name, { maxlength: '80', placeholder: s.company_name || 'Your company' }),
    resend_from: input(s.resend_from, { type: 'email', maxlength: '120', placeholder: 'books@yourcompany.com' }),
    resend_reply_to: input(s.resend_reply_to, { type: 'email', maxlength: '120', placeholder: 'Optional' }),
    notify_telegram: input(s.notify_telegram, { maxlength: '40', placeholder: '@channel or chat id' }),
  };
  const st = C.senders(s);
  const look = el('button', { type: 'button', class: 'oc-btn oc-btn--sm' }, 'Look again');
  look.addEventListener('click', async () => { look.disabled = true; look.textContent = 'Looking…'; if (await act(A.checkResend, { id: s._id, mode: '--check' })) setTimeout(render, 7000); });
  // Only Resend asks for a From and gets checked; Gmail sends from its own account.
  const viaResend = el('div', { class: 'oc-stack' }, [
    el('div', { class: 'ex-two' }, [field('From name', c.resend_from_name), field('From address', c.resend_from, 'On a domain verified in your Resend account.')]),
    field('Reply-to', c.resend_reply_to),
    el('div', { class: 'oc-row ex-look' }, [el('p', { class: st.ready ? 'ex-said' : 'ex-bad' }, st.say), look])]);
  const via = () => { viaResend.hidden = c.sender.value !== 'resend'; };
  c.sender.addEventListener('change', via);
  via();
  const save = el('button', { type: 'submit', class: 'oc-btn oc-btn--primary' }, 'Save');
  const f = el('form', { class: 'oc-stack oc-stack--loose ex-form ex-settings' }, [
    el('section', { class: 'oc-card oc-stack' }, [el('h2', { class: 'oc-h2' }, 'Your company'),
      el('div', { class: 'ex-two' }, [field('Company name', c.company_name, 'Heads the month\'s summary.'), field('Currency', c.currency, 'A receipt that does not say is read in it.')]),
      el('div', { class: 'ex-two' }, [field('Time zone', c.timezone), field('Summary and emails in', c.language)])]),
    el('section', { class: 'oc-card oc-stack' }, [el('h2', { class: 'oc-h2' }, 'How receipts get in'),
      el('p', { class: 'oc-help' }, ['By email: forward them to ', el('span', { class: 'ex-addr' }, s.inbox_address || 'your workspace address (Channels → Email)'), '. Each sender below must be on the list of ', PORTAL(EMAIL_CHANNEL), '; the email must be turned on there.']),
      field('Who forwards receipts', c.forwarders, 'Addresses, or *@domain for everyone at your company.'),
      field('Words in the subject', c.subject_words, 'A forwarded mail counts when its subject has one of them ("Fwd: Your receipt", "factura octubre"). Other mail from those senders still goes to your agents.'),
      s.rules_note ? el('p', { class: 'ex-bad' }, s.rules_note) : el('p', { class: 'oc-help' }, rules.length ? `${rules.length} mail rule${rules.length === 1 ? '' : 's'} set${s.rules_at ? `, ${ago(s.rules_at)}` : ''}.` : 'No mail rules yet: add who forwards receipts.'),
      field('Files folder', c.files_folder, 'Or put receipts (PDF, JPG, PNG, WebP) in this folder of Files, in this project, and press Check Files.'),
      el('p', { class: 'oc-help' }, ['Open ', PORTAL(FILES), s.files_at ? `. Looked at ${ago(s.files_at)}.` : '.', s.files_note ? ` ${s.files_note}` : ''])]),
    el('section', { class: 'oc-card oc-stack' }, [el('h2', { class: 'oc-h2' }, 'Categories'),
      field('One per line', c.categories, 'The reader picks one of these for each receipt; you can change it on each expense.')]),
    el('section', { class: 'oc-card oc-stack' }, [el('h2', { class: 'oc-h2' }, 'The accountant'),
      el('div', { class: 'ex-two' }, [field('Name', c.accountant_name), field('Email', c.accountant_email, 'Where Send on a closed month goes.')]),
      field('Send through', c.sender),
      viaResend,
      el('p', { class: 'oc-help' }, ['Resend or Gmail is connected in ', PORTAL(INTEGRATIONS), '. The email carries a private link to the month\'s PDF and CSV.'])]),
    el('section', { class: 'oc-card oc-stack' }, [el('h2', { class: 'oc-h2' }, 'Telegram'),
      field('Tell me when receipts are read', c.notify_telegram, 'Optional.')]),
    el('div', { class: 'oc-row' }, save),
  ]);
  f.addEventListener('submit', async (e) => {
    e.preventDefault();
    const p = { id: s._id, mode: '--rules' };
    for (const [k, n] of Object.entries(c)) p[k] = String(n.value).trim();
    p.categories = JSON.stringify([...new Set(String(c.categories.value).split('\n').map((x) => x.trim()).filter(Boolean))].slice(0, 40));
    for (const k of ['accountant_email', 'resend_from', 'resend_reply_to']) { p[k] = C.normEmail(p[k]); if (p[k] && !C.isEmail(p[k])) { Orch.toast('An email address does not look right.', { error: true }); c[k].focus(); return; } }
    const bad = String(c.forwarders.value).split(/[\s,;]+/).filter(Boolean).filter((x) => !C.isEmail(x) && !/^\*@[a-z0-9.-]+\.[a-z]{2,}$/i.test(x));
    if (bad.length) { Orch.toast(`Not an address: ${bad.join(', ')}`, { error: true }); c.forwarders.focus(); return; }
    save.disabled = true;
    if (await act(A.settings, p, 'Saved. Setting the mail rules…')) setTimeout(render, 7000);
    save.disabled = false;
  });
  return f;
}

const legal = () => el('section', { class: 'oc-card oc-stack ex-legal' }, [
  el('h2', { class: 'oc-h2' }, 'What this is not'),
  el('p', 'Expenses gathers your receipts with their VAT and sends them to whoever keeps your books. It is not accounting software: it makes no ledger entries and files no tax returns. The receipts stay in Files as they came; the summary is a working document for your accountant.'),
]);
