/**
 * Expenses · what the desk and the scripts must agree on: money in minor
 * units (per currency), the categories, what a read receipt may say (the
 * JSON Schema the model answers to, and the check that cleans its answer),
 * a month's totals, the CSV, the accountant's email, and who sends it.
 * Pure functions, no database, no DOM. test/sync.js copies it to app/ and
 * automations/.
 */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.ExCore = api;
}(typeof self !== 'undefined' ? self : this, () => {
  'use strict';

  const EMAIL = /^[^\s@<>(),;:"]+@[^\s@<>(),;:"]+\.[A-Za-z]{2,}$/;
  const normEmail = (v) => String(v || '').trim().toLowerCase();
  const isEmail = (v) => EMAIL.test(normEmail(v)) && normEmail(v).length <= 200;
  const langOf = (v) => (v === 'es' ? 'es' : 'en');
  const CURRENCIES = ['EUR', 'USD', 'GBP', 'CHF', 'MXN', 'COP', 'ARS', 'CLP', 'PEN', 'BRL', 'CAD', 'AUD', 'JPY', 'SEK', 'NOK', 'DKK', 'PLN'];

  const CATEGORIES = ['Software and subscriptions', 'Travel', 'Meals', 'Office and supplies', 'Professional services', 'Marketing',
    'Phone and internet', 'Rent and utilities', 'Bank fees', 'Training', 'Equipment', 'Other'];
  const CATEGORIES_ES = { 'Software and subscriptions': 'Software y suscripciones', Travel: 'Viajes', Meals: 'Comidas', 'Office and supplies': 'Oficina y material',
    'Professional services': 'Servicios profesionales', Marketing: 'Marketing', 'Phone and internet': 'Teléfono e internet', 'Rent and utilities': 'Alquiler y suministros',
    'Bank fees': 'Comisiones bancarias', Training: 'Formación', Equipment: 'Equipos', Other: 'Otros' };
  /** The categories in Settings (one per line, or a JSON list), or the defaults. */
  function categoriesOf(s) {
    const raw = s && s.categories;
    let list = [];
    if (Array.isArray(raw)) list = raw;
    else if (raw) { try { const j = JSON.parse(raw); if (Array.isArray(j)) list = j; } catch { list = String(raw).split('\n'); } }
    list = [...new Set(list.map((x) => String(x || '').trim().slice(0, 60)).filter(Boolean))];
    return list.length ? list : CATEGORIES.slice();
  }

  // ── money ──────────────────────────────────────────────────────────────
  /** How many decimals a currency has (EUR 2, JPY 0, KWD 3). */
  function decimalsOf(cur) {
    try { return new Intl.NumberFormat('en', { style: 'currency', currency: cur }).resolvedOptions().maximumFractionDigits; } catch { return 2; }
  }
  /** A number of major units (12.5) → minor units (1250), half away from zero. */
  function toMinor(v, cur) {
    if (v === null || v === undefined || v === '') return null;
    const n = typeof v === 'number' ? v : Number(String(v).replace(/\s/g, '').replace(/(\d)[.,](\d{3})(?=[.,]\d|$)/g, '$1$2').replace(',', '.'));
    if (!Number.isFinite(n)) return null;
    const f = 10 ** decimalsOf(cur);
    return Math.sign(n) * Math.round(Math.abs(n) * f + 1e-9);
  }
  const fromMinor = (n, cur) => (Number(n) || 0) / 10 ** decimalsOf(cur);
  function money(n, cur, locale) {
    try { return new Intl.NumberFormat(locale || undefined, { style: 'currency', currency: cur || 'EUR' }).format(fromMinor(n, cur || 'EUR')); } catch { return `${fromMinor(n, cur)} ${cur}`; }
  }
  /** "12.50" with the currency's decimals, for a CSV or an input. */
  const plain = (n, cur) => fromMinor(n, cur).toFixed(decimalsOf(cur));

  // ── days ───────────────────────────────────────────────────────────────
  function realDay(v) {
    const s = String(v || '').slice(0, 10);
    if (!/^\d{4}-\d{2}-\d{2}$/.test(s)) return '';
    const d = new Date(`${s}T00:00:00Z`);
    return !Number.isNaN(d.getTime()) && d.toISOString().slice(0, 10) === s ? s : '';
  }
  const monthOf = (day) => (realDay(day) ? day.slice(0, 7) : '');
  const zoneOk = (tz) => { try { new Intl.DateTimeFormat('en', { timeZone: tz }); return true; } catch { return false; } };
  function today(tz, at) {
    const p = Object.fromEntries(new Intl.DateTimeFormat('en-CA', { year: 'numeric', month: '2-digit', day: '2-digit', timeZone: zoneOk(tz) ? tz : 'UTC' })
      .formatToParts(at ? new Date(at) : new Date()).map((x) => [x.type, x.value]));
    return `${p.year}-${p.month}-${p.day}`;
  }
  function monthName(month, lang) {
    if (!/^\d{4}-\d{2}$/.test(String(month || ''))) return '';
    return new Intl.DateTimeFormat(langOf(lang) === 'es' ? 'es-ES' : 'en-GB', { month: 'long', year: 'numeric', timeZone: 'UTC' }).format(new Date(`${month}-15T12:00:00Z`));
  }
  function prevMonth(month) { const d = new Date(`${month}-15T12:00:00Z`); d.setUTCMonth(d.getUTCMonth() - 1); return d.toISOString().slice(0, 7); }

  // ── what a receipt may say ─────────────────────────────────────────────
  /** The JSON Schema the model answers to, for one batch of receipts. */
  function schemaFor(categories) {
    return {
      type: 'object', required: ['items'], additionalProperties: false,
      properties: { items: { type: 'array', items: {
        type: 'object', required: ['id', 'is_receipt'], additionalProperties: false,
        properties: {
          id: { type: 'integer' },
          is_receipt: { type: 'boolean' },
          vendor: { type: 'string' }, vendor_tax_id: { type: 'string' }, number: { type: 'string' },
          date: { type: 'string', description: 'YYYY-MM-DD, the day of the purchase or the invoice' },
          currency: { type: 'string', description: 'ISO 4217, e.g. EUR' },
          total: { type: 'number', description: 'what was paid, tax included' },
          net: { type: 'number', description: 'before tax, if the receipt says it' },
          tax: { type: 'number', description: 'the tax amount (VAT/IVA), if the receipt says it' },
          tax_rate: { type: 'number', description: 'percent, e.g. 21' },
          category: { type: 'string', enum: categories },
          description: { type: 'string', description: 'what was bought, in a few words' },
          confidence: { type: 'string', enum: ['high', 'medium', 'low'] },
        },
      } } },
    };
  }
  /** The instruction both readers get (the cheap model for text, the agent for photos). */
  function readingRules(categories, s) {
    return [
      'You read business receipts and invoices for an expenses app. For each item, return what the document says; never guess a number that is not printed.',
      `- is_receipt: false when it is not a receipt or invoice for something paid (a newsletter, a quote, a statement); then leave the rest out.`,
      `- date: the purchase or invoice date as YYYY-MM-DD. Day/month order: ${s && s.language === 'en' ? 'follow the vendor\'s country' : 'European receipts write day/month/year'}.`,
      `- currency: ISO code (€ = EUR, $ = USD unless the vendor is clearly elsewhere, £ = GBP). If none is shown use ${(s && s.currency) || 'EUR'}.`,
      '- total: the amount paid, tax included, as a number with a dot for decimals (1.234,56 → 1234.56). net and tax only if printed; tax_rate in percent.',
      '- vendor: the business that sold, not the buyer. vendor_tax_id: its VAT/NIF/CIF/EIN if printed. number: the invoice or receipt number if printed.',
      `- category: exactly one of: ${categories.join(' | ')}.`,
      '- description: what was bought, 2 to 8 words, in the receipt\'s language.',
      '- confidence: high when every amount was clearly printed; low when the text was garbled or you had to infer.',
    ].join('\n');
  }

  /**
   * One answer item checked and cleaned: { ok, data, why }. Amounts in minor
   * units; a date in the future (more than a day) or before 2000 is refused;
   * net + tax must match the total within a cent per 10 units, else they are
   * dropped (the total wins).
   */
  function cleanRead(item, { categories, currency, today: t } = {}) {
    if (!item || typeof item !== 'object') return { ok: false, why: 'no answer for it' };
    if (item.is_receipt === false) return { ok: true, notReceipt: true };
    const cur = /^[A-Z]{3}$/.test(String(item.currency || '').toUpperCase()) ? String(item.currency).toUpperCase() : (currency || 'EUR');
    const total = toMinor(item.total, cur);
    if (!total || total <= 0) return { ok: false, why: 'no total could be read' };
    const date = realDay(item.date);
    if (!date) return { ok: false, why: 'no date could be read' };
    if (date < '2000-01-01' || (t && date > t && new Date(`${date}T00:00:00Z`) - new Date(`${t}T00:00:00Z`) > 86400000)) return { ok: false, why: `the date read (${date}) cannot be right` };
    let net = toMinor(item.net, cur);
    let tax = toMinor(item.tax, cur);
    let rate = Number(item.tax_rate);
    rate = Number.isFinite(rate) && rate >= 0 && rate <= 50 ? Math.round(rate * 100) / 100 : null;
    if (tax !== null && net === null) net = total - tax;
    if (net !== null && tax === null) tax = total - net;
    if (net !== null && tax !== null && (Math.abs(net + tax - total) > Math.max(1, Math.round(total / 1000)) || net < 0 || tax < 0)) { net = null; tax = null; }
    if (tax === null && rate !== null) { net = Math.round(total / (1 + rate / 100)); tax = total - net; }
    if (rate === null && net && tax) rate = Math.round((tax / net) * 10000) / 100;
    const cats = categories && categories.length ? categories : CATEGORIES;
    const category = cats.includes(item.category) ? item.category : (cats.find((c) => c.toLowerCase() === String(item.category || '').toLowerCase()) || (cats.includes('Other') ? 'Other' : cats[cats.length - 1]));
    const clean = (v, n) => String(v == null ? '' : v).replace(/\s+/g, ' ').trim().slice(0, n);
    return { ok: true, data: {
      vendor: clean(item.vendor, 120) || 'Unknown vendor', vendor_tax_id: clean(item.vendor_tax_id, 40), number: clean(item.number, 60),
      date, month: monthOf(date), currency: cur, total, net, tax, tax_rate: rate, category, description: clean(item.description, 160),
      confidence: ['high', 'medium', 'low'].includes(item.confidence) ? item.confidence : 'medium',
    } };
  }
  /** The key two copies of one purchase share. */
  const dupKey = (e) => `${String(e.vendor || '').toLowerCase().replace(/[^a-z0-9]/g, '').slice(0, 12)}|${e.date}|${e.total}|${e.currency}`;

  // ── a month ────────────────────────────────────────────────────────────
  /**
   * A month's numbers from its approved expenses: per currency, totals, tax
   * per rate, per category, and what is owed back to each person.
   */
  function summary(expenses) {
    const out = {};
    for (const e of expenses) {
      const cur = e.currency || 'EUR';
      const m = out[cur] || (out[cur] = { currency: cur, count: 0, total: 0, net: 0, tax: 0, noTax: 0, byCategory: {}, byRate: {}, reimburse: {} });
      const total = Number(e.total) || 0;
      const tax = e.tax === null || e.tax === undefined || e.tax === '' ? null : Number(e.tax);
      m.count += 1;
      m.total += total;
      if (tax === null) m.noTax += total; else { m.tax += tax; m.net += total - tax; }
      const c = m.byCategory[e.category || 'Other'] || (m.byCategory[e.category || 'Other'] = { count: 0, total: 0, tax: 0 });
      c.count += 1; c.total += total; c.tax += tax || 0;
      if (tax !== null) {
        const r = String(e.tax_rate === null || e.tax_rate === undefined || e.tax_rate === '' ? '?' : Number(e.tax_rate));
        const b = m.byRate[r] || (m.byRate[r] = { net: 0, tax: 0 });
        b.net += total - tax; b.tax += tax;
      }
      // Paid by a person and not paid back yet: owed to them.
      if (e.paid_by && e.paid_by !== 'company' && !e.reimbursed_at) m.reimburse[e.paid_by] = (m.reimburse[e.paid_by] || 0) + total;
    }
    return Object.values(out);
  }

  const CSV_HEAD = ['date', 'vendor', 'vendor_tax_id', 'number', 'category', 'description', 'net', 'tax_rate', 'tax', 'total', 'currency', 'paid_by', 'reimbursed', 'receipt'];
  const csvCell = (v) => { const s = String(v == null ? '' : v); return /[",\n;]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s; };
  /** The month as CSV (comma-separated, a header, amounts with a dot). */
  function csv(expenses) {
    const rows = expenses.map((e) => [e.date, e.vendor, e.vendor_tax_id, e.number, e.category, e.description,
      e.tax === null || e.tax === undefined || e.tax === '' ? '' : plain(Number(e.total) - Number(e.tax), e.currency), e.tax_rate === null || e.tax_rate === undefined ? '' : e.tax_rate,
      e.tax === null || e.tax === undefined || e.tax === '' ? '' : plain(e.tax, e.currency), plain(e.total, e.currency), e.currency,
      e.paid_by || 'company', e.reimbursed_at ? 'yes' : (e.paid_by && e.paid_by !== 'company' ? 'no' : ''), e.receipt_name || '']);
    return `\ufeff${[CSV_HEAD, ...rows].map((r) => r.map(csvCell).join(',')).join('\r\n')}\r\n`;
  }

  // ── the accountant's email ─────────────────────────────────────────────
  const MAIL = {
    en: (d) => ({ subject: `${d.company ? `${d.company}: ` : ''}expenses for ${d.month}`,
      body: [`Hello${d.name ? ` ${d.name}` : ''},`, '', `Here are ${d.company || 'our'} expenses for ${d.month}: ${d.count} expense${d.count === 1 ? '' : 's'}, ${d.totals}.`,
        '', 'The summary with every receipt behind it (PDF) and the list (CSV), to download:', d.link || '', d.note ? `\n${d.note}` : '', '', 'Thank you,', d.company || ''].filter((x) => x !== '').join('\n') }),
    es: (d) => ({ subject: `${d.company ? `${d.company}: ` : ''}gastos de ${d.month}`,
      body: [`Hola${d.name ? ` ${d.name}` : ''}:`, '', `Te enviamos los gastos de ${d.company || 'nuestra empresa'} de ${d.month}: ${d.count} gasto${d.count === 1 ? '' : 's'}, ${d.totals}.`,
        '', 'El resumen con cada recibo detrás (PDF) y la lista (CSV), para descargar:', d.link || '', d.note ? `\n${d.note}` : '', '', 'Gracias,', d.company || ''].filter((x) => x !== '').join('\n') }),
  };
  const mail = (lang, d) => MAIL[langOf(lang)](d);

  // ── who sends: Gmail or Resend (Sign's rules) ──────────────────────────
  const senderOf = (s) => (s && s.sender === 'gmail' ? 'gmail' : 'resend');
  const domainOf = (address) => (String(address || '').trim().toLowerCase().split('@')[1] || '');
  function fromLine(name, address) {
    const n = String(name || '').replace(/[\r\n<>"\\]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 80);
    const a = normEmail(address);
    if (!n) return a;
    return /[,;:()@[\].]/.test(n) ? `"${n}" <${a}>` : `${n} <${a}>`;
  }
  function verifiedDomains(s) {
    if (!s || !s.resend_domains) return null;
    try { const v = JSON.parse(s.resend_domains); return Array.isArray(v) ? v.map((d) => String(d).toLowerCase()) : null; } catch { return null; }
  }
  /**
   * Whether the month can be emailed: { ready, say }. The email carries a
   * link to the month's page, not the files (neither Composio send takes
   * bytes), so Gmail and Resend both can.
   */
  function senders(s) {
    if (senderOf(s) === 'gmail') return { ready: true, say: 'The month goes to your accountant from the Gmail connected in Integrations: a link to download the PDF and the CSV.' };
    if (s.resend_status === 'error') return { ready: false, say: `Resend did not answer the last check${s.resend_note ? ` (${String(s.resend_note).slice(0, 120)})` : ''}.` };
    if (s.resend_status !== 'ok') return { ready: false, say: s.resend_status ? 'Resend is not connected to this workspace: connect it in Integrations.' : 'Not checked yet whether Resend is connected.' };
    const from = normEmail(s.resend_from);
    if (!isEmail(from)) return { ready: false, say: 'Resend needs a From address: one on a domain verified in your Resend account.' };
    const domains = verifiedDomains(s);
    if (domains && !domains.includes(domainOf(from))) return { ready: false, say: `${domainOf(from)} is not verified in your Resend account${domains.length ? ` (verified: ${domains.join(', ')})` : ''}.` };
    return { ready: true, say: `The month goes to your accountant through Resend, from ${fromLine(s.resend_from_name || s.company_name, from)}: a link to download the PDF and the CSV.` };
  }

  // ── the accountant's link (Sign's sealed link) ─────────────────────────
  // The month's page reads the public view `ex_links`, whose rows mean
  // nothing without the link: the token after # (never sent to a server)
  // finds them by their hashes and opens them (AES-GCM).
  const subtle = () => (globalThis.crypto && globalThis.crypto.subtle) || null;
  const enc = (t) => new TextEncoder().encode(t);
  const b64u = (bytes) => { let t = ''; const b = new Uint8Array(bytes); for (let i = 0; i < b.length; i += 0x8000) t += String.fromCharCode(...b.subarray(i, i + 0x8000)); return btoa(t).replace(/\+/g, '-').replace(/\//g, '_').replace(/=+$/, ''); };
  const unb64u = (t) => Uint8Array.from(atob(String(t).replace(/-/g, '+').replace(/_/g, '/') + '==='.slice((String(t).length + 3) % 4)), (c) => c.charCodeAt(0));
  const hex = (bytes) => [...new Uint8Array(bytes)].map((b) => b.toString(16).padStart(2, '0')).join('');
  const TOKEN = /^[A-Za-z0-9_-]{22,64}$/;
  /** The part names: '0' the month's state, 'p<i>' the PDF, 'c<i>' the CSV (base64, in pieces). */
  const PART = { state: '0', pdf: (i) => `p${i}`, csv: (i) => `c${i}` };
  /** How much text one sealed row carries: it travels through a 128 KB argument as base64 with JSON around it. */
  const CHUNK = 55000;
  function newToken() { const b = new Uint8Array(16); globalThis.crypto.getRandomValues(b); return b64u(b); }
  async function linkKey(token, part = PART.state) { return hex(await subtle().digest('SHA-256', enc(`ex-k:${token}:${part}`))); }
  async function boxKey(token, use) {
    const raw = await subtle().digest('SHA-256', enc(`ex-e:${token}`));
    return subtle().importKey('raw', raw, { name: 'AES-GCM' }, false, [use]);
  }
  /** A value sealed for its token: base64url(iv ‖ ciphertext+tag). */
  async function seal(token, value) {
    const iv = new Uint8Array(12);
    globalThis.crypto.getRandomValues(iv);
    const ct = await subtle().encrypt({ name: 'AES-GCM', iv }, await boxKey(token, 'encrypt'), enc(JSON.stringify(value)));
    const out = new Uint8Array(12 + ct.byteLength);
    out.set(iv, 0);
    out.set(new Uint8Array(ct), 12);
    return b64u(out);
  }
  /** The value back from its box, or null when the token does not open it. */
  async function open(token, box) {
    try {
      const all = unb64u(box);
      const pt = await subtle().decrypt({ name: 'AES-GCM', iv: all.slice(0, 12) }, await boxKey(token, 'decrypt'), all.slice(12));
      return JSON.parse(new TextDecoder().decode(pt));
    } catch { return null; }
  }
  /** A long text in pieces of at most n characters. */
  const chunks = (text, n = CHUNK) => { const t = String(text || ''); const out = []; for (let i = 0; i < t.length; i += n) out.push(t.slice(i, i + n)); return out.length ? out : ['']; };

  // ── which mail is a receipt (the rules the app writes) ─────────────────
  const WORDS = ['receipt', 'recibo', 'factura', 'invoice', 'ticket', 'gasto'];
  /** Settings' senders: one per line or comma, addresses or *@domain. */
  function sendersOf(s) {
    return [...new Set(String((s && s.forwarders) || '').split(/[\s,;]+/).map((x) => x.trim().toLowerCase()).filter((x) => isEmail(x) || /^\*@[a-z0-9.-]+\.[a-z]{2,}$/.test(x)))];
  }
  function wordsOf(s) {
    const list = String((s && s.subject_words) || '').split(/[\s,;]+/).map((x) => x.trim().toLowerCase()).filter((x) => /^[\p{L}\p{N}-]{2,30}$/u.test(x));
    return list.length ? [...new Set(list)] : WORDS.slice();
  }

  return {
    isEmail, normEmail, langOf, CURRENCIES, CATEGORIES, CATEGORIES_ES, categoriesOf, decimalsOf, toMinor, fromMinor, money, plain,
    realDay, monthOf, today, monthName, prevMonth, zoneOk, schemaFor, readingRules, cleanRead, dupKey, summary, csv, CSV_HEAD,
    mail, senderOf, domainOf, fromLine, verifiedDomains, senders, WORDS, sendersOf, wordsOf,
    TOKEN, PART, CHUNK, newToken, linkKey, seal, open, chunks,
  };
}));
