// The company and its currency, the categories, who forwards receipts to the
// workspace address, the Files folder and the accountant (Resend or Gmail) are
// managed in Orchestra (Apps → Expenses → Ajustes and Conexiones): typed, next
// to who reads the photos. Saving there sets the mail rules again. Here, what
// they are now, whether Resend answers, and a way there.
import { A, C, EMAIL_CHANNEL, FILES, PORTAL, act, ago, head, settings } from '../data.js';

const { el } = Orch;

export function render() {
  Orch.load('view', async () => {
    const s = await settings(true);
    if (!s._id) return el('p', { class: 'oc-state' }, 'Expenses is not installed here.');
    return el('div', { class: 'oc-stack oc-stack--loose' }, [head('Settings', 'How receipts get in, how they are sorted, and who gets the month. Managed in Orchestra.'), managed(s), legal()]);
  });
}

function managed(s) {
  let rules = [];
  try { rules = JSON.parse(s.rules || '[]'); } catch { rules = []; }
  const link = el('a', { class: 'oc-btn oc-btn--primary', target: '_blank', rel: 'noopener', hidden: true }, 'Open the settings in Orchestra');
  const where = el('p', { class: 'oc-help' }, 'In Orchestra: Apps → Expenses → Ajustes.');
  if (Orch.manageUrl) Orch.manageUrl('settings').then((url) => { if (url) { link.href = url; link.hidden = false; where.hidden = true; } });
  const st = C.senders(s);
  const look = el('button', { type: 'button', class: 'oc-btn oc-btn--sm' }, 'Look again');
  look.addEventListener('click', async () => { look.disabled = true; look.textContent = 'Looking…'; if (await act(A.checkResend, { id: s._id, mode: '--check' })) setTimeout(render, 7000); });
  const senders = C.sendersOf(s);
  const facts = [
    ['Company', s.company_name ? `${s.company_name} · ${s.currency || 'EUR'}` : '— (not set yet)'],
    ['Who forwards receipts', senders.length ? senders.join(', ') : 'nobody yet'],
    ['Words in the subject', C.wordsOf(s).join(', ')],
    ['Files folder', s.files_folder || 'Receipts'],
    ['Categories', `${C.categoriesOf(s).length}`],
    ['The accountant', s.accountant_email ? `${s.accountant_name ? `${s.accountant_name}, ` : ''}${s.accountant_email}` : '— (not set yet)'],
    ['Send through', C.senderOf(s) === 'gmail' ? 'Gmail' : 'Resend'],
    ['Telegram', s.notify_telegram ? 'on' : 'off'],
  ];
  return el('section', { class: 'oc-card oc-stack' }, [
    el('h2', { class: 'oc-h2' }, 'Managed in Orchestra'),
    el('p', { class: 'oc-help' }, ['By email: forward receipts to ', el('span', { class: 'ex-addr' }, s.inbox_address || 'your workspace address (Channels → Email)'), '. Each sender must be on the list of ', PORTAL(EMAIL_CHANNEL), '. Or put them in the Files folder: ', PORTAL(FILES), '.']),
    el('ul', { class: 'oc-stack' }, facts.map(([k, v]) => el('li', [el('b', `${k}: `), v]))),
    s.rules_note ? el('p', { class: 'ex-bad' }, s.rules_note) : el('p', { class: 'oc-help' }, rules.length ? `${rules.length} mail rule${rules.length === 1 ? '' : 's'} set${s.rules_at ? `, ${ago(s.rules_at)}` : ''}.` : 'No mail rules yet: add who forwards receipts.'),
    s.files_note ? el('p', { class: 'ex-bad' }, s.files_note) : null,
    el('div', { class: 'oc-row ex-look' }, [el('p', { class: st.ready ? 'ex-said' : 'ex-bad' }, st.say), C.senderOf(s) === 'resend' ? look : null]),
    el('div', { class: 'oc-row' }, [link]), where,
  ]);
}

const legal = () => el('section', { class: 'oc-card oc-stack ex-legal' }, [
  el('h2', { class: 'oc-h2' }, 'What this is not'),
  el('p', 'Expenses gathers your receipts with their VAT and sends them to whoever keeps your books. It is not accounting software: it makes no ledger entries and files no tax returns. The receipts stay in Files as they came; the summary is a working document for your accountant.'),
]);
