// What every record's panel shares: its timeline (mail, meetings, forms,
// notes and stage moves, newest first), a note, a task and an email to write.
// An email written here waits for review like the agent's: nothing leaves
// until someone approves it.
import { C, T, A, act, field, input, area, formDialog, stamp, today } from '../data.js';
import { linked } from '../links.js';

const { el } = Orch;

/** Activities of a contact, a company (and its deals) or a deal (and its contact), newest first. */
export async function timeline({ contact, company, deal, dealIds }) {
  const asks = [];
  if (contact) asks.push({ contact_id: contact });
  if (company) asks.push({ company_id: company });
  if (deal) asks.push({ deal_id: deal });
  if (dealIds && dealIds.length) asks.push({ deal_id: dealIds });
  const lists = await Promise.all(asks.map((filter) => Orch.db.list(T.activities, { filter, sort: 'at:desc', limit: 60 })));
  const seen = new Map();
  for (const r of lists) for (const row of r.rows || []) seen.set(row._id, row);
  return [...seen.values()].sort((a, b) => String(b.at).replace('T', ' ').localeCompare(String(a.at).replace('T', ' '))).slice(0, 80);
}

const WORD = { email_in: 'Email in', email_out: 'Email out', meeting: 'Meeting', note: 'Note', call: 'Call', form: 'Form', stage: 'Stage', task: 'Task' };

/** The timeline as thin rows: when, what kind, the subject and a line of it. */
export function timelineView(rows) {
  if (!rows.length) return el('p', { class: 'oc-help' }, 'Nothing has happened here yet. Mail and meetings appear once sync is on in Settings; notes you add appear here too.');
  const upcoming = (r) => new Date(String(r.at).replace(' ', 'T') + (String(r.at).includes('Z') ? '' : 'Z')) > new Date();
  return el('ol', { class: 'crm-timeline' }, rows.map((r) => el('li', { class: 'crm-timeline__row' }, [
    el('span', { class: 'oc-value crm-timeline__when' }, stamp(r.at)),
    el('span', { class: 'oc-eyebrow' }, upcoming(r) ? `${WORD[r.type] || r.type} · upcoming` : (WORD[r.type] || r.type)),
    el('div', { class: 'crm-timeline__what' }, [
      el('span', {}, r.type === 'stage' ? `Moved to ${r.subject || '—'}` : (r.subject || '—')),
      r.summary ? el('span', { class: 'oc-muted crm-timeline__line' }, linked(r.summary)) : null,
      r.author ? el('span', { class: 'oc-small oc-muted' }, r.author) : null,
    ]),
  ])));
}

/** Add a note in place: what was said on a call, a decision, anything worth keeping. */
export function noteBox(ids, after) {
  const text = area('', 3, { placeholder: 'What happened, what was agreed…', 'aria-label': 'New note' });
  const add = el('button', { class: 'oc-btn oc-btn--sm', type: 'submit' }, 'Add note');
  const form = el('form', { class: 'oc-stack oc-stack--tight crm-note' }, [text, el('div', { class: 'oc-row oc-row--end' }, add)]);
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const body = text.value.trim();
    if (!body) return;
    add.disabled = true;
    const ok = await act(A.note, Object.assign({}, ids, { subject: body.split('\n')[0].slice(0, 80), summary: body.slice(0, 4000) }), 'Note added.');
    add.disabled = false;
    if (ok) { text.value = ''; after(); }
  });
  return form;
}

/** A task for a person: what to do and by when. */
export function taskDialog(ids, after) {
  const title = input('', { required: true, maxlength: '140' });
  const due = input(today(1), { type: 'date' });
  return formDialog('New task', [field('What to do', title), field('Due', due)], async () => {
    const ok = await act(A.newTask, Object.assign({}, ids, { title: title.value.trim(), due: due.value }), 'Task added: it shows on Today when it is due.');
    if (ok) after();
    return ok;
  }, 'Add task');
}

/** An email to write by hand. It waits for review on Today like the agent's drafts. */
export function composeDialog({ to, contact_id, deal_id }, after) {
  const addr = input(to || '', { type: 'email', required: true });
  const subject = input('', { required: true, maxlength: '160' });
  const body = area('', 10, { required: true });
  return formDialog('New email', [
    field('To', addr), field('Subject', subject), field('Message', body, 'Plain text. It is saved for review: nothing leaves until someone approves it on Today.'),
  ], async () => {
    if (!C.isEmail(addr.value)) { Orch.toast('That address does not look right.', { error: true }); return false; }
    const ok = await act(A.compose, { to_email: C.normEmail(addr.value), subject: subject.value.trim(), body: body.value.trim(), contact_id, deal_id },
      'Saved for review on Today.');
    if (ok) after();
    return ok;
  }, 'Save for review');
}

/** The "what to do next" row of a panel: note, task, email. */
export function tools(ids, email, after) {
  return el('div', { class: 'oc-row' }, [
    el('button', { class: 'oc-btn oc-btn--sm', type: 'button', onClick: () => taskDialog(ids, after) }, 'Add task'),
    email ? el('button', { class: 'oc-btn oc-btn--sm', type: 'button', onClick: () => composeDialog(Object.assign({ to: email }, ids), after) }, 'Write email') : null,
  ]);
}

/** Facts as label / value rows, leaving out what is empty. A web address opens in a new tab. */
export function facts(list) {
  const shown = list.filter(([, v]) => v !== null && v !== undefined && v !== '' && v !== '—');
  return el('dl', { class: 'oc-dl' }, shown.map(([k, v]) => el('div', { class: 'oc-dl__row' }, [el('dt', {}, k), el('dd', {}, linked(v))])));
}
