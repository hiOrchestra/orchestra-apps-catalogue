// Contacts: the people, and the new ones the mail sync found (Suggested) to
// accept or ignore. A person opens in a panel with their facts, their deals
// and everything that happened with them; from there a note, a task, an email
// or a deal. Ignored people are kept so the sync never suggests them again.
import { C, V, T, A, act, head, badge, ago, money, settings, redraw, listTabs, field, input, select, formDialog, choices, companyLink, dealLink } from '../data.js';
import { timeline, timelineView, noteBox, tools, facts } from './record.js';
import { newDeal } from './deal-form.js';
import { hrefOf, link } from '../links.js';

const { el } = Orch;
const PEOPLE = ['Lead', 'Contacted', 'Customer', 'Lost'];
const VIEWS = [['', 'People', { status: PEOPLE }], ['suggested', 'Suggested', { status: 'Suggested' }], ['ignored', 'Ignored', { status: 'Ignored' }]];

export function render(params, path) {
  const view = VIEWS.find((v) => v[0] === (params.view || '')) || VIEWS[0];
  Orch.load('view', async () => {
    const s = await settings();
    const counts = await Orch.db.count(T.contacts, { group: 'status' });
    const n = (st) => (counts.groups || []).filter((g) => [].concat(st).includes(g.value)).reduce((a, g) => a + g.count, 0);
    const host = el('div');
    const again = redraw(render, params);
    const suggested = view[0] === 'suggested';
    const link = async () => { await act(A.linkNow, {}); setTimeout(again, 2500); };
    setTimeout(() => Orch.table({
      into: host, path: view[0] ? `/contacts/${view[0]}` : '/contacts', query: path, view: V.contacts, filter: view[2], pageSize: 25,
      sort: suggested ? '_id:desc' : 'last_activity_at:desc', search: 'email', searchPlaceholder: 'Find by email',
      filters: view[0] ? [] : [{ key: 'status', label: 'Status', options: PEOPLE }],
      columns: [
        { key: 'name', label: 'Name', format: (v, r) => v || r.email },
        { key: 'email', label: 'Email' },
        { key: 'company', label: 'Company', format: (v) => v || '—' },
        suggested ? { key: 'suggested_why', label: 'Why', clamp: true, sortable: false, format: (v) => v || '—' } : { key: 'status', label: 'Status', badge: { Customer: 'good', Contacted: 'accent', Lost: 'bad' } },
        { key: 'last_activity_at', label: 'Last activity', format: (v) => ago(v) },
        suggested ? null : { key: 'open_deals', label: 'Open deals', numeric: true, format: (v) => (v ? String(v) : '—') },
      ].filter(Boolean),
      bulk: suggested ? [
        { label: 'Accept', action: A.acceptContacts, done: '{n} accepted: they are contacts now, with their company.' },
        { label: 'Ignore', action: A.ignoreContacts, done: '{n} ignored: the sync will not suggest them again.' },
      ] : [],
      detail: { table: T.contacts, title: 'Contact', render: (row) => contactPanel(row, s, again, link) },
      empty: suggested ? 'No one new. People who write to you from company addresses appear here once mail sync is on.' : 'No contacts here yet.',
    }), 0);
    if (suggested) host.addEventListener('click', (e) => { if (e.target.closest('[data-orch-bulk] .oc-btn--primary')) setTimeout(link, 1500); });
    return el('div', { class: 'oc-stack oc-stack--loose' }, [
      head('Contacts', 'The people you work with. Suggested are new correspondents from your mail: accept them to keep them, or ignore them.', [
        el('button', { class: 'oc-btn oc-btn--primary', type: 'button', onClick: () => contactForm(null, s, again) }, 'New contact'),
      ]),
      listTabs('/contacts', VIEWS.map((v) => [v[0], v[1], n(v[2].status)]), view[0], 'Which people'),
      host,
    ]);
  });
}

async function contactPanel(row, s, again, link) {
  const [company, deals, acts] = await Promise.all([
    row.company_id ? Orch.db.get(T.companies, row.company_id) : null,
    Orch.db.list(T.deals, { filter: { contact_id: row._id }, sort: '_id:desc', limit: 20 }),
    timeline({ contact: row._id }),
  ]);
  const ids = { contact_id: row._id, company_id: row.company_id || undefined };
  const decide = row.status === 'Suggested' ? el('div', { class: 'crm-next' }, [
    el('p', { class: 'oc-help' }, `Found in your mail. ${row.suggested_why || ''}`),
    el('div', { class: 'oc-row' }, [
      el('button', { class: 'oc-btn oc-btn--sm oc-btn--primary', type: 'button', onClick: async () => { if (await act(A.acceptContacts, { ids: [row._id] }, 'Accepted.')) link(); } }, 'Accept'),
      el('button', { class: 'oc-btn oc-btn--sm', type: 'button', onClick: async () => { if (await act(A.ignoreContacts, { ids: [row._id] }, 'Ignored.')) again(); } }, 'Ignore'),
    ]),
  ]) : null;
  return el('div', { class: 'oc-stack crm-panel' }, [
    el('div', { class: 'oc-row oc-row--between' }, [
      el('div', { class: 'oc-stack oc-stack--tight' }, [el('h2', { class: 'oc-h1 crm-panel__title' }, row.name || row.email), row.title ? el('p', { class: 'oc-eyebrow' }, row.title) : null]),
      badge(row.status),
    ]),
    decide,
    facts([['Email', row.email ? el('a', { href: `mailto:${row.email}` }, row.email) : null], ['Phone', row.phone], ['Company', company ? companyLink(company._id, company.name) : null],
      ['LinkedIn', hrefOf(row.linkedin) ? link(hrefOf(row.linkedin), 'Profile') : row.linkedin],
      ['Owner', row.owner], ['Source', row.source], ['Tags', C.tagsOf(row.tags).join(', ')], ['Last activity', row.last_activity_at ? ago(row.last_activity_at) : null]]),
    el('div', { class: 'oc-row' }, [
      el('button', { class: 'oc-btn oc-btn--sm oc-btn--ghost', type: 'button', onClick: () => contactForm(row, s, again) }, 'Edit'),
      row.status === 'Suggested' ? null : el('button', { class: 'oc-btn oc-btn--sm', type: 'button', onClick: () => newDeal(again, { contact_id: row._id, company_id: row.company_id }) }, 'New deal'),
    ]),
    (deals.rows || []).length ? el('ul', { class: 'crm-rows crm-rows--flush' }, deals.rows.map((d) => el('li', { class: 'crm-row' }, [
      el('div', { class: 'crm-row__main' }, dealLink(d._id, d.title)), el('span', { class: 'oc-value' }, money(d.amount, d.currency, s)), el('span', {}, d.stage), badge(d.status),
    ]))) : null,
    row.status === 'Suggested' ? null : tools(ids, C.isEmail(row.email) ? row.email : null, again),
    noteBox(ids, again),
    el('h3', { class: 'oc-h2' }, 'What happened'),
    timelineView(acts),
  ]);
}

async function contactForm(row, s, after) {
  const r = row || {};
  const email = input(r.email, { type: 'email' });
  const name = input(r.name, { maxlength: '120' });
  const title = input(r.title, { maxlength: '120' });
  const phone = input(r.phone, { type: 'tel', maxlength: '40' });
  const company = select(await choices(T.companies), r.company_id);
  const status = select(PEOPLE, r.status && PEOPLE.includes(r.status) ? r.status : 'Lead');
  const sources = C.linesOf(s.sources);
  const source = select([['', '—'], ...sources.map((x) => [x, x])], r.source);
  const tags = input(C.tagsOf(r.tags).join(', '), { placeholder: 'investor, spain' });
  return formDialog(row ? 'Edit contact' : 'New contact', [
    field('Email', email, 'One contact per address. A company address links the person to their company on its own.'), field('Name', name), field('Role', title),
    field('Phone', phone), field('Company', company), field('Status', status), field('Source', source), field('Tags', tags, 'Separated by commas.'),
  ], async () => {
    if (email.value && !C.isEmail(email.value)) { Orch.toast('That address does not look right.', { error: true }); return false; }
    const p = { email: C.normEmail(email.value), name: name.value.trim(), title: title.value.trim(), phone: phone.value.trim(),
      company_id: company.value ? Number(company.value) : '', status: status.value, source: source.value, tags: C.tagsText(tags.value) };
    const ok = row ? await act(A.editContact, Object.assign({ id: row._id }, p), 'Saved.')
      : await act(A.newContact, Object.fromEntries(Object.entries(p).filter(([, v]) => v !== '')), 'Contact added.');
    if (ok) after();
    return ok;
  }, row ? 'Save' : 'Add contact');
}
