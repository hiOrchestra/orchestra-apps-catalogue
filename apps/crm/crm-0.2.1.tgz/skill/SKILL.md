---
name: app-crm
version: 0.2.1
description: >-
  Work in the CRM app: people, companies and deals, the pipeline, tasks and
  emails waiting for review. Load it when someone says "add a prospect / cargar
  un prospecto", "new contact / nuevo contacto", "move the deal to Proposal /
  pasá el negocio a Propuesta", "we won / lost the deal / ganamos / perdimos",
  "what's due today / qué tengo hoy", "log a call / note / anotá la llamada",
  "suggested contacts / contactos sugeridos", "how is the pipeline / cuánto hay
  en el pipeline", "write to <person> / escribile a …", "import from HubSpot".
  Needs the CRM app installed in a project you work in.
metadata:
  openclaw:
    emoji: "🤝"
---
# CRM — people, companies, deals and the next step

The CRM keeps a project's contacts, companies and deals, a timeline of what
happened with each, and the next step on every deal. Nothing goes out without
a person approving it in the app.

```bash
ls -d ~/.openclaw/orchestra/projects/*/apps/crm     # the directory name under projects/ is the project id
P=<project>; W=~/.openclaw/orchestra/projects/$P/apps/crm/workflows.json
cat "$W"                                            # workflow ids: sync, link, enrich, suggest, send, forms, hubspot
orch-canvas url crm                                 # the app's link, for the person
```

If nothing is listed, the CRM is not installed in a project you work in: say
so, and do not keep contacts or deals some other way. Every `orch-database`
command below takes `--project $P`; always filter `_deleted = 0`.

## The model (tables `crm_*`)

| Table | One row per | Notes |
|---|---|---|
| `crm_settings` | one row | `stages` (JSON list: name, probability, order, `outcome` won/lost), `owners`, `sources` (one per line), `currency`, `timezone`, `paused`, `stuck_days`, `signature`, sync and import state |
| `crm_companies` | company | `domain` unique (lowercase). Enrichment: `enrich_status` Waiting → Working → Done or Failed (after 3 tries) |
| `crm_contacts` | person | `email` unique (lowercase), `company_id`, `status`, `source`, `tags` stored as `|a|b|`, `last_activity_at` |
| `crm_deals` | deal | `title`, `company_id`, `contact_id`, `stage`, `amount`, `currency`, `status`, `next_step`, `next_step_due`, `stage_changed_at`, `closed_at`, `lost_reason` |
| `crm_activities` | thing that happened | `type`: email_in, email_out, meeting, note, call, form, stage, task; `at`, `subject`, `summary` |
| `crm_tasks` | next step | `title`, `due` (YYYY-MM-DD), `deal_id`, `contact_id`, `status`, `why`, `draft_id` |
| `crm_drafts` | email to review | `to_email`, `subject`, `body` (plain text), `status`, `error` |

Contact status: Lead, Contacted, Customer, Lost, plus Suggested and Ignored.
- Suggested: found by the mail sync (a new correspondent at a company domain, with `suggested_why`). A person accepts it (→ Lead) or ignores it (→ Ignored, never suggested again).
- Lead → Contacted happens on its own when an email to them is sent from the CRM or seen in synced Gmail.
- Customer and Lost are set by a person; winning a deal does not change the contact. A HubSpot import brings customers as Customer.
- A Forms answer from a Suggested or Ignored address turns it into a Lead.

Deals: `status` Open, Won or Lost. `stage` is a name from `crm_settings.stages`
(default Lead, Qualified, Meeting, Proposal, Negotiation, Won, Lost). The
stages with an `outcome` are the closing ones and can be renamed; an open deal
sits only in a stage without one. Every stage change also writes a `stage`
activity. Stuck: open, and no activity (stage moves do not count) for
`stuck_days`.

Tasks: Suggested (by the agent's daily run, at most one per deal) → Open
(accepted) → Done, or Dismissed. Drafts: Review → Approved (a person, in the
app) → Sending → Sent; or Failed (with `error`) and Dropped. Nothing is ever
retried blind.

## How you act

- Workflows first: `orch-workflows run <id> --args '{"mode":"--now"}'` (ids from `workflows.json`), then `orch-workflows runs --limit 5` / `orch-workflows status <run>`. `link` takes `{"mode":"--link"}`, `hubspot` takes `{"mode":"--start"}`.
- Writes the app makes with its own buttons you make with `orch-database insert/update`, setting exactly the fields and defaults below, as the app does. Nothing else.
- Timestamps are UTC `YYYY-MM-DD HH:MM:SS`: `NOW=$(date -u '+%F %T')`.
- Before inserting a contact or company, look for its email or domain: both are unique.
- You never approve, send or retry an email: drafts wait in Review for a person on Today.
- There is no delete in the CRM. A contact becomes Lost or Ignored, a deal Lost, a draft Dropped. Never use `orch-database delete` on `crm_*`.
- Settings (stages, sync, pause, owners) are changed by the person in the app's Settings.

## Recipes

**Add a prospect.** Check first: `orch-database --project $P find crm_contacts --where "lower(email) = 'ana@acme.com' AND _deleted = 0"`.
```bash
orch-database --project $P insert crm_contacts --data '{"email":"ana@acme.com","name":"Ana Ruiz","title":"COO","status":"Lead","source":"Outbound"}'
orch-database --project $P find crm_companies --where "lower(domain) = 'acme.com' AND _deleted = 0"   # company_id if it exists
orch-workflows run "$(node -p "require('$W').link")" --args '{"mode":"--link"}'   # gives a company address its company (new ones wait for enrichment)
```
`source` is one of the lines in `crm_settings.sources`. A company by hand: insert
`crm_companies` with `name`, `domain` (and `website`, `industry`, `location`,
`owner`, `tags`, `source`), plus `"enrich_status":"Waiting","enrich_attempts":0`;
then run the `enrich` workflow.

**A deal.** Insert `crm_deals` with `title`, `contact_id`, `company_id`,
`stage` (an open stage), `amount`, `currency`, `source`, plus
`"status":"Open","stage_changed_at":"$NOW"`; then the stage activity below.

**Move a deal to another stage.** Read the stages: `orch-database --project $P query "SELECT stages FROM crm_settings WHERE _deleted = 0 ORDER BY _id LIMIT 1"`.
```bash
orch-database --project $P update crm_deals --id 12 --data "{\"stage\":\"Proposal\",\"stage_changed_at\":\"$NOW\"}"
orch-database --project $P insert crm_activities --data "{\"type\":\"stage\",\"deal_id\":12,\"contact_id\":7,\"company_id\":3,\"subject\":\"Proposal\",\"at\":\"$NOW\",\"source\":\"crm\",\"author\":\"<who asked>\"}"
```
- Won: `stage` = the won stage's name, `"status":"Won","closed_at":"$NOW","stage_changed_at":"$NOW","lost_reason":null`.
- Lost: the lost stage's name, `"status":"Lost","closed_at":"$NOW","stage_changed_at":"$NOW","lost_reason":"<why>"`. Ask the reason.
- Reopen: an open stage, `"status":"Open","closed_at":null,"lost_reason":null,"stage_changed_at":"$NOW"`.
Each with its `stage` activity (`subject` = the new stage).

**What's due today.**
```bash
orch-database --project $P query "SELECT t._id, t.title, t.due, t.status, t.why, d.title AS deal, d.stage, c.name AS contact, r.status AS draft FROM crm_tasks t LEFT JOIN crm_deals d ON d._id = t.deal_id LEFT JOIN crm_contacts c ON c._id = t.contact_id LEFT JOIN crm_drafts r ON r._id = t.draft_id WHERE t._deleted = 0 AND t.status IN ('Suggested','Open') AND (t.due IS NULL OR t.due = '' OR date(t.due) <= date('now')) ORDER BY t.due"
```
Overdue is `date(due) < date('now')`. Suggested ones are the agent's proposals,
waiting for the person to accept or dismiss. Add a task: insert `crm_tasks` with
`title`, `due`, `deal_id`, `contact_id`, `owner`, `why`, plus `"status":"Open","source":"crm"`.
Done: update `"status":"Done","done_at":"$NOW"`, only when it is Open.

**Log a call or a note.** Insert `crm_activities` with `contact_id`,
`company_id`, `deal_id` (those that apply), `subject` (first line),
`summary` (what was said, the person's words), `"type":"note"` (or `"call"`
for a call), `"at":"$NOW","source":"crm","author":"<who asked>"`.

**Review suggested contacts.**
```bash
orch-database --project $P find crm_contacts --where "status = 'Suggested' AND _deleted = 0" --columns _id name email suggested_why
```
Show them; accept or ignore only those the person names: update `"status":"Lead"`
(then run `link`) or `"status":"Ignored"`, only while the status is Suggested.
New ones come from the `sync` workflow, which runs only when the person
turned on Gmail/Calendar sync in Settings.

**Pipeline totals.**
```bash
orch-database --project $P query "SELECT stage, COALESCE(currency,'') AS currency, COUNT(*) AS deals, COALESCE(SUM(amount),0) AS amount FROM crm_deals WHERE _deleted = 0 AND status = 'Open' GROUP BY stage, COALESCE(currency,'')"
```
Order the rows by the stages' `order`. Never add amounts across currencies.

**Draft an email to a contact (draft only).** Write it in the language of
their last emails (`crm_activities` of the contact), short, plain text, no
placeholders; add `crm_settings.signature` at the end if there is one. Then:
```bash
orch-database --project $P insert crm_drafts --data '{"to_email":"ana@acme.com","subject":"…","body":"…","contact_id":7,"deal_id":12,"status":"Review","source":"crm","created_by":"<who asked>"}'
```
`to_email` is the contact's own address. Tell the person it waits for review on
Today, with the link. Approving there sends it from their Gmail.

Others: `suggest` workflow for next steps now; `sync` to read mail now;
`enrich` for companies Waiting; `hubspot` (`--start`) to import from a
connected HubSpot. Their notes are in `crm_settings` (`sync_note`, `suggest_note`, `send_note`, `hubspot_note`).

## With the other apps

- Forms → CRM: the `forms` workflow (every 30 min, or run it) turns each Complete response with an email into a Lead (source Forms, or updates the contact) with a `form` activity. Only if Forms is in the same project and "Leads from Forms" is on.
- CRM → Invoices: Invoices' "From CRM" fills a new client from a CRM company (read only; the client keeps `crm_company_id`). A won deal does not make an invoice: today by hand, in Invoices.
- Booking reads `crm_contacts`, `crm_companies` and `crm_activities` to prepare a meeting brief. It writes nothing to the CRM; meetings reach the timeline through the CRM's Calendar sync, if on.
- Outreach has no link to the CRM. A reply that becomes a prospect is added here by hand (Add a prospect).
- Helpdesk, Analytics and Recruiter: no link in the code.

## Never

- Approve, send, retry or mark as sent an email, or set a draft to Approved.
- Choose a recipient other than the contact the person named.
- Delete or purge `crm_*` rows, or change `crm_settings`.
- Move a deal to Won or Lost, or a contact to Customer or Lost, unless the person said so.
- Invent company facts: the `enrich` workflow fills them from sources.
- Keep a CRM somewhere else when the app is not installed.
