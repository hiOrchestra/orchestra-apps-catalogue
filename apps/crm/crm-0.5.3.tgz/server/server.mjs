// .stack/node_modules/@hono/node-server/dist/index.mjs
import { createServer as createServerHTTP } from "http";
import { Http2ServerRequest as Http2ServerRequest2 } from "http2";
import { Http2ServerRequest } from "http2";
import { Readable } from "stream";
import crypto from "crypto";
var RequestError = class extends Error {
  constructor(message, options) {
    super(message, options);
    this.name = "RequestError";
  }
};
var toRequestError = (e) => {
  if (e instanceof RequestError) {
    return e;
  }
  return new RequestError(e.message, { cause: e });
};
var GlobalRequest = global.Request;
var Request2 = class extends GlobalRequest {
  constructor(input, options) {
    if (typeof input === "object" && getRequestCache in input) {
      input = input[getRequestCache]();
    }
    if (typeof options?.body?.getReader !== "undefined") {
      ;
      options.duplex ??= "half";
    }
    super(input, options);
  }
};
var wrapBodyStream = Symbol("wrapBodyStream");
var newRequestFromIncoming = (method, url, incoming, abortController) => {
  const headerRecord = [];
  const rawHeaders = incoming.rawHeaders;
  for (let i = 0; i < rawHeaders.length; i += 2) {
    const { [i]: key, [i + 1]: value } = rawHeaders;
    if (key.charCodeAt(0) !== /*:*/
    58) {
      headerRecord.push([key, value]);
    }
  }
  const init = {
    method,
    headers: headerRecord,
    signal: abortController.signal
  };
  if (method === "TRACE") {
    init.method = "GET";
    const req = new Request2(url, init);
    Object.defineProperty(req, "method", {
      get() {
        return "TRACE";
      }
    });
    return req;
  }
  if (!(method === "GET" || method === "HEAD")) {
    if ("rawBody" in incoming && incoming.rawBody instanceof Buffer) {
      init.body = new ReadableStream({
        start(controller) {
          controller.enqueue(incoming.rawBody);
          controller.close();
        }
      });
    } else if (incoming[wrapBodyStream]) {
      let reader;
      init.body = new ReadableStream({
        async pull(controller) {
          try {
            reader ||= Readable.toWeb(incoming).getReader();
            const { done: done2, value } = await reader.read();
            if (done2) {
              controller.close();
            } else {
              controller.enqueue(value);
            }
          } catch (error) {
            controller.error(error);
          }
        }
      });
    } else {
      init.body = Readable.toWeb(incoming);
    }
  }
  return new Request2(url, init);
};
var getRequestCache = Symbol("getRequestCache");
var requestCache = Symbol("requestCache");
var incomingKey = Symbol("incomingKey");
var urlKey = Symbol("urlKey");
var abortControllerKey = Symbol("abortControllerKey");
var getAbortController = Symbol("getAbortController");
var requestPrototype = {
  get method() {
    return this[incomingKey].method || "GET";
  },
  get url() {
    return this[urlKey];
  },
  [getAbortController]() {
    this[getRequestCache]();
    return this[abortControllerKey];
  },
  [getRequestCache]() {
    this[abortControllerKey] ||= new AbortController();
    return this[requestCache] ||= newRequestFromIncoming(
      this.method,
      this[urlKey],
      this[incomingKey],
      this[abortControllerKey]
    );
  }
};
[
  "body",
  "bodyUsed",
  "cache",
  "credentials",
  "destination",
  "headers",
  "integrity",
  "mode",
  "redirect",
  "referrer",
  "referrerPolicy",
  "signal",
  "keepalive"
].forEach((k) => {
  Object.defineProperty(requestPrototype, k, {
    get() {
      return this[getRequestCache]()[k];
    }
  });
});
["arrayBuffer", "blob", "clone", "formData", "json", "text"].forEach((k) => {
  Object.defineProperty(requestPrototype, k, {
    value: function() {
      return this[getRequestCache]()[k]();
    }
  });
});
Object.setPrototypeOf(requestPrototype, Request2.prototype);
var newRequest = (incoming, defaultHostname) => {
  const req = Object.create(requestPrototype);
  req[incomingKey] = incoming;
  const incomingUrl = incoming.url || "";
  if (incomingUrl[0] !== "/" && // short-circuit for performance. most requests are relative URL.
  (incomingUrl.startsWith("http://") || incomingUrl.startsWith("https://"))) {
    if (incoming instanceof Http2ServerRequest) {
      throw new RequestError("Absolute URL for :path is not allowed in HTTP/2");
    }
    try {
      const url2 = new URL(incomingUrl);
      req[urlKey] = url2.href;
    } catch (e) {
      throw new RequestError("Invalid absolute URL", { cause: e });
    }
    return req;
  }
  const host = (incoming instanceof Http2ServerRequest ? incoming.authority : incoming.headers.host) || defaultHostname;
  if (!host) {
    throw new RequestError("Missing host header");
  }
  let scheme;
  if (incoming instanceof Http2ServerRequest) {
    scheme = incoming.scheme;
    if (!(scheme === "http" || scheme === "https")) {
      throw new RequestError("Unsupported scheme");
    }
  } else {
    scheme = incoming.socket && incoming.socket.encrypted ? "https" : "http";
  }
  const url = new URL(`${scheme}://${host}${incomingUrl}`);
  if (url.hostname.length !== host.length && url.hostname !== host.replace(/:\d+$/, "")) {
    throw new RequestError("Invalid host header");
  }
  req[urlKey] = url.href;
  return req;
};
var responseCache = Symbol("responseCache");
var getResponseCache = Symbol("getResponseCache");
var cacheKey = Symbol("cache");
var GlobalResponse = global.Response;
var Response2 = class _Response {
  #body;
  #init;
  [getResponseCache]() {
    delete this[cacheKey];
    return this[responseCache] ||= new GlobalResponse(this.#body, this.#init);
  }
  constructor(body, init) {
    let headers;
    this.#body = body;
    if (init instanceof _Response) {
      const cachedGlobalResponse = init[responseCache];
      if (cachedGlobalResponse) {
        this.#init = cachedGlobalResponse;
        this[getResponseCache]();
        return;
      } else {
        this.#init = init.#init;
        headers = new Headers(init.#init.headers);
      }
    } else {
      this.#init = init;
    }
    if (typeof body === "string" || typeof body?.getReader !== "undefined" || body instanceof Blob || body instanceof Uint8Array) {
      headers ||= init?.headers || { "content-type": "text/plain; charset=UTF-8" };
      this[cacheKey] = [init?.status || 200, body, headers];
    }
  }
  get headers() {
    const cache = this[cacheKey];
    if (cache) {
      if (!(cache[2] instanceof Headers)) {
        cache[2] = new Headers(cache[2]);
      }
      return cache[2];
    }
    return this[getResponseCache]().headers;
  }
  get status() {
    return this[cacheKey]?.[0] ?? this[getResponseCache]().status;
  }
  get ok() {
    const status = this.status;
    return status >= 200 && status < 300;
  }
};
["body", "bodyUsed", "redirected", "statusText", "trailers", "type", "url"].forEach((k) => {
  Object.defineProperty(Response2.prototype, k, {
    get() {
      return this[getResponseCache]()[k];
    }
  });
});
["arrayBuffer", "blob", "clone", "formData", "json", "text"].forEach((k) => {
  Object.defineProperty(Response2.prototype, k, {
    value: function() {
      return this[getResponseCache]()[k]();
    }
  });
});
Object.setPrototypeOf(Response2, GlobalResponse);
Object.setPrototypeOf(Response2.prototype, GlobalResponse.prototype);
async function readWithoutBlocking(readPromise) {
  return Promise.race([readPromise, Promise.resolve().then(() => Promise.resolve(void 0))]);
}
function writeFromReadableStreamDefaultReader(reader, writable, currentReadPromise) {
  const handleError = () => {
  };
  writable.on("error", handleError);
  (currentReadPromise ?? reader.read()).then(flow, handleStreamError);
  return reader.closed.finally(() => {
    writable.off("error", handleError);
  });
  function handleStreamError(error) {
    if (error) {
      writable.destroy(error);
    }
  }
  function onDrain() {
    reader.read().then(flow, handleStreamError);
  }
  function flow({ done: done2, value }) {
    try {
      if (done2) {
        writable.end();
      } else if (!writable.write(value)) {
        writable.once("drain", onDrain);
      } else {
        return reader.read().then(flow, handleStreamError);
      }
    } catch (e) {
      handleStreamError(e);
    }
  }
}
function writeFromReadableStream(stream, writable) {
  if (stream.locked) {
    throw new TypeError("ReadableStream is locked.");
  } else if (writable.destroyed) {
    return;
  }
  return writeFromReadableStreamDefaultReader(stream.getReader(), writable);
}
var buildOutgoingHttpHeaders = (headers) => {
  const res = {};
  if (!(headers instanceof Headers)) {
    headers = new Headers(headers ?? void 0);
  }
  const cookies = [];
  for (const [k, v] of headers) {
    if (k === "set-cookie") {
      cookies.push(v);
    } else {
      res[k] = v;
    }
  }
  if (cookies.length > 0) {
    res["set-cookie"] = cookies;
  }
  res["content-type"] ??= "text/plain; charset=UTF-8";
  return res;
};
var X_ALREADY_SENT = "x-hono-already-sent";
var webFetch = global.fetch;
if (typeof global.crypto === "undefined") {
  global.crypto = crypto;
}
global.fetch = (info, init) => {
  init = {
    // Disable compression handling so people can return the result of a fetch
    // directly in the loader without messing with the Content-Encoding header.
    compress: false,
    ...init
  };
  return webFetch(info, init);
};
var outgoingEnded = Symbol("outgoingEnded");
var handleRequestError = () => new Response(null, {
  status: 400
});
var handleFetchError = (e) => new Response(null, {
  status: e instanceof Error && (e.name === "TimeoutError" || e.constructor.name === "TimeoutError") ? 504 : 500
});
var handleResponseError = (e, outgoing) => {
  const err = e instanceof Error ? e : new Error("unknown error", { cause: e });
  if (err.code === "ERR_STREAM_PREMATURE_CLOSE") {
    console.info("The user aborted a request.");
  } else {
    console.error(e);
    if (!outgoing.headersSent) {
      outgoing.writeHead(500, { "Content-Type": "text/plain" });
    }
    outgoing.end(`Error: ${err.message}`);
    outgoing.destroy(err);
  }
};
var flushHeaders = (outgoing) => {
  if ("flushHeaders" in outgoing && outgoing.writable) {
    outgoing.flushHeaders();
  }
};
var responseViaCache = async (res, outgoing) => {
  let [status, body, header] = res[cacheKey];
  if (header instanceof Headers) {
    header = buildOutgoingHttpHeaders(header);
  }
  if (typeof body === "string") {
    header["Content-Length"] = Buffer.byteLength(body);
  } else if (body instanceof Uint8Array) {
    header["Content-Length"] = body.byteLength;
  } else if (body instanceof Blob) {
    header["Content-Length"] = body.size;
  }
  outgoing.writeHead(status, header);
  if (typeof body === "string" || body instanceof Uint8Array) {
    outgoing.end(body);
  } else if (body instanceof Blob) {
    outgoing.end(new Uint8Array(await body.arrayBuffer()));
  } else {
    flushHeaders(outgoing);
    await writeFromReadableStream(body, outgoing)?.catch(
      (e) => handleResponseError(e, outgoing)
    );
  }
  ;
  outgoing[outgoingEnded]?.();
};
var responseViaResponseObject = async (res, outgoing, options = {}) => {
  if (res instanceof Promise) {
    if (options.errorHandler) {
      try {
        res = await res;
      } catch (err) {
        const errRes = await options.errorHandler(err);
        if (!errRes) {
          return;
        }
        res = errRes;
      }
    } else {
      res = await res.catch(handleFetchError);
    }
  }
  if (cacheKey in res) {
    return responseViaCache(res, outgoing);
  }
  const resHeaderRecord = buildOutgoingHttpHeaders(res.headers);
  if (res.body) {
    const reader = res.body.getReader();
    const values = [];
    let done2 = false;
    let currentReadPromise = void 0;
    if (resHeaderRecord["transfer-encoding"] !== "chunked") {
      let maxReadCount = 2;
      for (let i = 0; i < maxReadCount; i++) {
        currentReadPromise ||= reader.read();
        const chunk = await readWithoutBlocking(currentReadPromise).catch((e) => {
          console.error(e);
          done2 = true;
        });
        if (!chunk) {
          if (i === 1) {
            await new Promise((resolve) => setTimeout(resolve));
            maxReadCount = 3;
            continue;
          }
          break;
        }
        currentReadPromise = void 0;
        if (chunk.value) {
          values.push(chunk.value);
        }
        if (chunk.done) {
          done2 = true;
          break;
        }
      }
      if (done2 && !("content-length" in resHeaderRecord)) {
        resHeaderRecord["content-length"] = values.reduce((acc, value) => acc + value.length, 0);
      }
    }
    outgoing.writeHead(res.status, resHeaderRecord);
    values.forEach((value) => {
      ;
      outgoing.write(value);
    });
    if (done2) {
      outgoing.end();
    } else {
      if (values.length === 0) {
        flushHeaders(outgoing);
      }
      await writeFromReadableStreamDefaultReader(reader, outgoing, currentReadPromise);
    }
  } else if (resHeaderRecord[X_ALREADY_SENT]) {
  } else {
    outgoing.writeHead(res.status, resHeaderRecord);
    outgoing.end();
  }
  ;
  outgoing[outgoingEnded]?.();
};
var getRequestListener = (fetchCallback, options = {}) => {
  const autoCleanupIncoming = options.autoCleanupIncoming ?? true;
  if (options.overrideGlobalObjects !== false && global.Request !== Request2) {
    Object.defineProperty(global, "Request", {
      value: Request2
    });
    Object.defineProperty(global, "Response", {
      value: Response2
    });
  }
  return async (incoming, outgoing) => {
    let res, req;
    try {
      req = newRequest(incoming, options.hostname);
      let incomingEnded = !autoCleanupIncoming || incoming.method === "GET" || incoming.method === "HEAD";
      if (!incomingEnded) {
        ;
        incoming[wrapBodyStream] = true;
        incoming.on("end", () => {
          incomingEnded = true;
        });
        if (incoming instanceof Http2ServerRequest2) {
          ;
          outgoing[outgoingEnded] = () => {
            if (!incomingEnded) {
              setTimeout(() => {
                if (!incomingEnded) {
                  setTimeout(() => {
                    incoming.destroy();
                    outgoing.destroy();
                  });
                }
              });
            }
          };
        }
      }
      outgoing.on("close", () => {
        const abortController = req[abortControllerKey];
        if (abortController) {
          if (incoming.errored) {
            req[abortControllerKey].abort(incoming.errored.toString());
          } else if (!outgoing.writableFinished) {
            req[abortControllerKey].abort("Client connection prematurely closed.");
          }
        }
        if (!incomingEnded) {
          setTimeout(() => {
            if (!incomingEnded) {
              setTimeout(() => {
                incoming.destroy();
              });
            }
          });
        }
      });
      res = fetchCallback(req, { incoming, outgoing });
      if (cacheKey in res) {
        return responseViaCache(res, outgoing);
      }
    } catch (e) {
      if (!res) {
        if (options.errorHandler) {
          res = await options.errorHandler(req ? e : toRequestError(e));
          if (!res) {
            return;
          }
        } else if (!req) {
          res = handleRequestError();
        } else {
          res = handleFetchError(e);
        }
      } else {
        return handleResponseError(e, outgoing);
      }
    }
    try {
      return await responseViaResponseObject(res, outgoing, options);
    } catch (e) {
      return handleResponseError(e, outgoing);
    }
  };
};
var createAdaptorServer = (options) => {
  const fetchCallback = options.fetch;
  const requestListener = getRequestListener(fetchCallback, {
    hostname: options.hostname,
    overrideGlobalObjects: options.overrideGlobalObjects,
    autoCleanupIncoming: options.autoCleanupIncoming
  });
  const createServer = options.createServer || createServerHTTP;
  const server = createServer(options.serverOptions || {}, requestListener);
  return server;
};
var serve = (options, listeningListener) => {
  const server = createAdaptorServer(options);
  server.listen(options?.port ?? 3e3, options.hostname, () => {
    const serverInfo = server.address();
    listeningListener && listeningListener(serverInfo);
  });
  return server;
};

// .stack/node_modules/hono/dist/compose.js
var compose = (middleware, onError, onNotFound) => {
  return (context, next) => {
    let index = -1;
    return dispatch(0);
    async function dispatch(i) {
      if (i <= index) {
        throw new Error("next() called multiple times");
      }
      index = i;
      let res;
      let isError = false;
      let handler;
      if (middleware[i]) {
        handler = middleware[i][0][0];
        context.req.routeIndex = i;
      } else {
        handler = i === middleware.length && next || void 0;
      }
      if (handler) {
        try {
          res = await handler(context, () => dispatch(i + 1));
        } catch (err) {
          if (err instanceof Error && onError) {
            context.error = err;
            res = await onError(err, context);
            isError = true;
          } else {
            throw err;
          }
        }
      } else {
        if (context.finalized === false && onNotFound) {
          res = await onNotFound(context);
        }
      }
      if (res && (context.finalized === false || isError)) {
        context.res = res;
      }
      return context;
    }
  };
};

// .stack/node_modules/hono/dist/request/constants.js
var GET_MATCH_RESULT = /* @__PURE__ */ Symbol();

// .stack/node_modules/hono/dist/utils/body.js
var parseBody = async (request, options = /* @__PURE__ */ Object.create(null)) => {
  const { all = false, dot = false } = options;
  const headers = request instanceof HonoRequest ? request.raw.headers : request.headers;
  const contentType = headers.get("Content-Type");
  if (contentType?.startsWith("multipart/form-data") || contentType?.startsWith("application/x-www-form-urlencoded")) {
    return parseFormData(request, { all, dot });
  }
  return {};
};
async function parseFormData(request, options) {
  const formData = await request.formData();
  if (formData) {
    return convertFormDataToBodyData(formData, options);
  }
  return {};
}
function convertFormDataToBodyData(formData, options) {
  const form = /* @__PURE__ */ Object.create(null);
  formData.forEach((value, key) => {
    const shouldParseAllValues = options.all || key.endsWith("[]");
    if (!shouldParseAllValues) {
      form[key] = value;
    } else {
      handleParsingAllValues(form, key, value);
    }
  });
  if (options.dot) {
    Object.entries(form).forEach(([key, value]) => {
      const shouldParseDotValues = key.includes(".");
      if (shouldParseDotValues) {
        handleParsingNestedValues(form, key, value);
        delete form[key];
      }
    });
  }
  return form;
}
var handleParsingAllValues = (form, key, value) => {
  if (form[key] !== void 0) {
    if (Array.isArray(form[key])) {
      ;
      form[key].push(value);
    } else {
      form[key] = [form[key], value];
    }
  } else {
    if (!key.endsWith("[]")) {
      form[key] = value;
    } else {
      form[key] = [value];
    }
  }
};
var handleParsingNestedValues = (form, key, value) => {
  let nestedForm = form;
  const keys = key.split(".");
  keys.forEach((key2, index) => {
    if (index === keys.length - 1) {
      nestedForm[key2] = value;
    } else {
      if (!nestedForm[key2] || typeof nestedForm[key2] !== "object" || Array.isArray(nestedForm[key2]) || nestedForm[key2] instanceof File) {
        nestedForm[key2] = /* @__PURE__ */ Object.create(null);
      }
      nestedForm = nestedForm[key2];
    }
  });
};

// .stack/node_modules/hono/dist/utils/url.js
var splitPath = (path) => {
  const paths = path.split("/");
  if (paths[0] === "") {
    paths.shift();
  }
  return paths;
};
var splitRoutingPath = (routePath) => {
  const { groups, path } = extractGroupsFromPath(routePath);
  const paths = splitPath(path);
  return replaceGroupMarks(paths, groups);
};
var extractGroupsFromPath = (path) => {
  const groups = [];
  path = path.replace(/\{[^}]+\}/g, (match2, index) => {
    const mark = `@${index}`;
    groups.push([mark, match2]);
    return mark;
  });
  return { groups, path };
};
var replaceGroupMarks = (paths, groups) => {
  for (let i = groups.length - 1; i >= 0; i--) {
    const [mark] = groups[i];
    for (let j = paths.length - 1; j >= 0; j--) {
      if (paths[j].includes(mark)) {
        paths[j] = paths[j].replace(mark, groups[i][1]);
        break;
      }
    }
  }
  return paths;
};
var patternCache = {};
var getPattern = (label, next) => {
  if (label === "*") {
    return "*";
  }
  const match2 = label.match(/^\:([^\{\}]+)(?:\{(.+)\})?$/);
  if (match2) {
    const cacheKey2 = `${label}#${next}`;
    if (!patternCache[cacheKey2]) {
      if (match2[2]) {
        patternCache[cacheKey2] = next && next[0] !== ":" && next[0] !== "*" ? [cacheKey2, match2[1], new RegExp(`^${match2[2]}(?=/${next})`)] : [label, match2[1], new RegExp(`^${match2[2]}$`)];
      } else {
        patternCache[cacheKey2] = [label, match2[1], true];
      }
    }
    return patternCache[cacheKey2];
  }
  return null;
};
var tryDecode = (str, decoder) => {
  try {
    return decoder(str);
  } catch {
    return str.replace(/(?:%[0-9A-Fa-f]{2})+/g, (match2) => {
      try {
        return decoder(match2);
      } catch {
        return match2;
      }
    });
  }
};
var tryDecodeURI = (str) => tryDecode(str, decodeURI);
var getPath = (request) => {
  const url = request.url;
  const start = url.indexOf("/", url.indexOf(":") + 4);
  let i = start;
  for (; i < url.length; i++) {
    const charCode = url.charCodeAt(i);
    if (charCode === 37) {
      const queryIndex = url.indexOf("?", i);
      const hashIndex = url.indexOf("#", i);
      const end = queryIndex === -1 ? hashIndex === -1 ? void 0 : hashIndex : hashIndex === -1 ? queryIndex : Math.min(queryIndex, hashIndex);
      const path = url.slice(start, end);
      return tryDecodeURI(path.includes("%25") ? path.replace(/%25/g, "%2525") : path);
    } else if (charCode === 63 || charCode === 35) {
      break;
    }
  }
  return url.slice(start, i);
};
var getPathNoStrict = (request) => {
  const result = getPath(request);
  return result.length > 1 && result.at(-1) === "/" ? result.slice(0, -1) : result;
};
var mergePath = (base, sub, ...rest) => {
  if (rest.length) {
    sub = mergePath(sub, ...rest);
  }
  return `${base?.[0] === "/" ? "" : "/"}${base}${sub === "/" ? "" : `${base?.at(-1) === "/" ? "" : "/"}${sub?.[0] === "/" ? sub.slice(1) : sub}`}`;
};
var checkOptionalParameter = (path) => {
  if (path.charCodeAt(path.length - 1) !== 63 || !path.includes(":")) {
    return null;
  }
  const segments = path.split("/");
  const results = [];
  let basePath = "";
  segments.forEach((segment) => {
    if (segment !== "" && !/\:/.test(segment)) {
      basePath += "/" + segment;
    } else if (/\:/.test(segment)) {
      if (/\?/.test(segment)) {
        if (results.length === 0 && basePath === "") {
          results.push("/");
        } else {
          results.push(basePath);
        }
        const optionalSegment = segment.replace("?", "");
        basePath += "/" + optionalSegment;
        results.push(basePath);
      } else {
        basePath += "/" + segment;
      }
    }
  });
  return results.filter((v, i, a) => a.indexOf(v) === i);
};
var _decodeURI = (value) => {
  if (!/[%+]/.test(value)) {
    return value;
  }
  if (value.indexOf("+") !== -1) {
    value = value.replace(/\+/g, " ");
  }
  return value.indexOf("%") !== -1 ? tryDecode(value, decodeURIComponent_) : value;
};
var _getQueryParam = (url, key, multiple) => {
  let encoded;
  if (!multiple && key && !/[%+]/.test(key)) {
    let keyIndex2 = url.indexOf("?", 8);
    if (keyIndex2 === -1) {
      return void 0;
    }
    if (!url.startsWith(key, keyIndex2 + 1)) {
      keyIndex2 = url.indexOf(`&${key}`, keyIndex2 + 1);
    }
    while (keyIndex2 !== -1) {
      const trailingKeyCode = url.charCodeAt(keyIndex2 + key.length + 1);
      if (trailingKeyCode === 61) {
        const valueIndex = keyIndex2 + key.length + 2;
        const endIndex = url.indexOf("&", valueIndex);
        return _decodeURI(url.slice(valueIndex, endIndex === -1 ? void 0 : endIndex));
      } else if (trailingKeyCode == 38 || isNaN(trailingKeyCode)) {
        return "";
      }
      keyIndex2 = url.indexOf(`&${key}`, keyIndex2 + 1);
    }
    encoded = /[%+]/.test(url);
    if (!encoded) {
      return void 0;
    }
  }
  const results = {};
  encoded ??= /[%+]/.test(url);
  let keyIndex = url.indexOf("?", 8);
  while (keyIndex !== -1) {
    const nextKeyIndex = url.indexOf("&", keyIndex + 1);
    let valueIndex = url.indexOf("=", keyIndex);
    if (valueIndex > nextKeyIndex && nextKeyIndex !== -1) {
      valueIndex = -1;
    }
    let name = url.slice(
      keyIndex + 1,
      valueIndex === -1 ? nextKeyIndex === -1 ? void 0 : nextKeyIndex : valueIndex
    );
    if (encoded) {
      name = _decodeURI(name);
    }
    keyIndex = nextKeyIndex;
    if (name === "") {
      continue;
    }
    let value;
    if (valueIndex === -1) {
      value = "";
    } else {
      value = url.slice(valueIndex + 1, nextKeyIndex === -1 ? void 0 : nextKeyIndex);
      if (encoded) {
        value = _decodeURI(value);
      }
    }
    if (multiple) {
      if (!(results[name] && Array.isArray(results[name]))) {
        results[name] = [];
      }
      ;
      results[name].push(value);
    } else {
      results[name] ??= value;
    }
  }
  return key ? results[key] : results;
};
var getQueryParam = _getQueryParam;
var getQueryParams = (url, key) => {
  return _getQueryParam(url, key, true);
};
var decodeURIComponent_ = decodeURIComponent;

// .stack/node_modules/hono/dist/request.js
var tryDecodeURIComponent = (str) => tryDecode(str, decodeURIComponent_);
var HonoRequest = class {
  /**
   * `.raw` can get the raw Request object.
   *
   * @see {@link https://hono.dev/docs/api/request#raw}
   *
   * @example
   * ```ts
   * // For Cloudflare Workers
   * app.post('/', async (c) => {
   *   const metadata = c.req.raw.cf?.hostMetadata?
   *   ...
   * })
   * ```
   */
  raw;
  #validatedData;
  // Short name of validatedData
  #matchResult;
  routeIndex = 0;
  /**
   * `.path` can get the pathname of the request.
   *
   * @see {@link https://hono.dev/docs/api/request#path}
   *
   * @example
   * ```ts
   * app.get('/about/me', (c) => {
   *   const pathname = c.req.path // `/about/me`
   * })
   * ```
   */
  path;
  bodyCache = {};
  constructor(request, path = "/", matchResult = [[]]) {
    this.raw = request;
    this.path = path;
    this.#matchResult = matchResult;
    this.#validatedData = {};
  }
  param(key) {
    return key ? this.#getDecodedParam(key) : this.#getAllDecodedParams();
  }
  #getDecodedParam(key) {
    const paramKey = this.#matchResult[0][this.routeIndex][1][key];
    const param = this.#getParamValue(paramKey);
    return param && /\%/.test(param) ? tryDecodeURIComponent(param) : param;
  }
  #getAllDecodedParams() {
    const decoded = {};
    const keys = Object.keys(this.#matchResult[0][this.routeIndex][1]);
    for (const key of keys) {
      const value = this.#getParamValue(this.#matchResult[0][this.routeIndex][1][key]);
      if (value !== void 0) {
        decoded[key] = /\%/.test(value) ? tryDecodeURIComponent(value) : value;
      }
    }
    return decoded;
  }
  #getParamValue(paramKey) {
    return this.#matchResult[1] ? this.#matchResult[1][paramKey] : paramKey;
  }
  query(key) {
    return getQueryParam(this.url, key);
  }
  queries(key) {
    return getQueryParams(this.url, key);
  }
  header(name) {
    if (name) {
      return this.raw.headers.get(name) ?? void 0;
    }
    const headerData = {};
    this.raw.headers.forEach((value, key) => {
      headerData[key] = value;
    });
    return headerData;
  }
  async parseBody(options) {
    return this.bodyCache.parsedBody ??= await parseBody(this, options);
  }
  #cachedBody = (key) => {
    const { bodyCache, raw: raw2 } = this;
    const cachedBody = bodyCache[key];
    if (cachedBody) {
      return cachedBody;
    }
    const anyCachedKey = Object.keys(bodyCache)[0];
    if (anyCachedKey) {
      return bodyCache[anyCachedKey].then((body) => {
        if (anyCachedKey === "json") {
          body = JSON.stringify(body);
        }
        return new Response(body)[key]();
      });
    }
    return bodyCache[key] = raw2[key]();
  };
  /**
   * `.json()` can parse Request body of type `application/json`
   *
   * @see {@link https://hono.dev/docs/api/request#json}
   *
   * @example
   * ```ts
   * app.post('/entry', async (c) => {
   *   const body = await c.req.json()
   * })
   * ```
   */
  json() {
    return this.#cachedBody("text").then((text2) => JSON.parse(text2));
  }
  /**
   * `.text()` can parse Request body of type `text/plain`
   *
   * @see {@link https://hono.dev/docs/api/request#text}
   *
   * @example
   * ```ts
   * app.post('/entry', async (c) => {
   *   const body = await c.req.text()
   * })
   * ```
   */
  text() {
    return this.#cachedBody("text");
  }
  /**
   * `.arrayBuffer()` parse Request body as an `ArrayBuffer`
   *
   * @see {@link https://hono.dev/docs/api/request#arraybuffer}
   *
   * @example
   * ```ts
   * app.post('/entry', async (c) => {
   *   const body = await c.req.arrayBuffer()
   * })
   * ```
   */
  arrayBuffer() {
    return this.#cachedBody("arrayBuffer");
  }
  /**
   * Parses the request body as a `Blob`.
   * @example
   * ```ts
   * app.post('/entry', async (c) => {
   *   const body = await c.req.blob();
   * });
   * ```
   * @see https://hono.dev/docs/api/request#blob
   */
  blob() {
    return this.#cachedBody("blob");
  }
  /**
   * Parses the request body as `FormData`.
   * @example
   * ```ts
   * app.post('/entry', async (c) => {
   *   const body = await c.req.formData();
   * });
   * ```
   * @see https://hono.dev/docs/api/request#formdata
   */
  formData() {
    return this.#cachedBody("formData");
  }
  /**
   * Adds validated data to the request.
   *
   * @param target - The target of the validation.
   * @param data - The validated data to add.
   */
  addValidatedData(target, data) {
    this.#validatedData[target] = data;
  }
  valid(target) {
    return this.#validatedData[target];
  }
  /**
   * `.url()` can get the request url strings.
   *
   * @see {@link https://hono.dev/docs/api/request#url}
   *
   * @example
   * ```ts
   * app.get('/about/me', (c) => {
   *   const url = c.req.url // `http://localhost:8787/about/me`
   *   ...
   * })
   * ```
   */
  get url() {
    return this.raw.url;
  }
  /**
   * `.method()` can get the method name of the request.
   *
   * @see {@link https://hono.dev/docs/api/request#method}
   *
   * @example
   * ```ts
   * app.get('/about/me', (c) => {
   *   const method = c.req.method // `GET`
   * })
   * ```
   */
  get method() {
    return this.raw.method;
  }
  get [GET_MATCH_RESULT]() {
    return this.#matchResult;
  }
  /**
   * `.matchedRoutes()` can return a matched route in the handler
   *
   * @deprecated
   *
   * Use matchedRoutes helper defined in "hono/route" instead.
   *
   * @see {@link https://hono.dev/docs/api/request#matchedroutes}
   *
   * @example
   * ```ts
   * app.use('*', async function logger(c, next) {
   *   await next()
   *   c.req.matchedRoutes.forEach(({ handler, method, path }, i) => {
   *     const name = handler.name || (handler.length < 2 ? '[handler]' : '[middleware]')
   *     console.log(
   *       method,
   *       ' ',
   *       path,
   *       ' '.repeat(Math.max(10 - path.length, 0)),
   *       name,
   *       i === c.req.routeIndex ? '<- respond from here' : ''
   *     )
   *   })
   * })
   * ```
   */
  get matchedRoutes() {
    return this.#matchResult[0].map(([[, route]]) => route);
  }
  /**
   * `routePath()` can retrieve the path registered within the handler
   *
   * @deprecated
   *
   * Use routePath helper defined in "hono/route" instead.
   *
   * @see {@link https://hono.dev/docs/api/request#routepath}
   *
   * @example
   * ```ts
   * app.get('/posts/:id', (c) => {
   *   return c.json({ path: c.req.routePath })
   * })
   * ```
   */
  get routePath() {
    return this.#matchResult[0].map(([[, route]]) => route)[this.routeIndex].path;
  }
};

// .stack/node_modules/hono/dist/utils/html.js
var HtmlEscapedCallbackPhase = {
  Stringify: 1,
  BeforeStream: 2,
  Stream: 3
};
var raw = (value, callbacks) => {
  const escapedString = new String(value);
  escapedString.isEscaped = true;
  escapedString.callbacks = callbacks;
  return escapedString;
};
var resolveCallback = async (str, phase, preserveCallbacks, context, buffer) => {
  if (typeof str === "object" && !(str instanceof String)) {
    if (!(str instanceof Promise)) {
      str = str.toString();
    }
    if (str instanceof Promise) {
      str = await str;
    }
  }
  const callbacks = str.callbacks;
  if (!callbacks?.length) {
    return Promise.resolve(str);
  }
  if (buffer) {
    buffer[0] += str;
  } else {
    buffer = [str];
  }
  const resStr = Promise.all(callbacks.map((c) => c({ phase, buffer, context }))).then(
    (res) => Promise.all(
      res.filter(Boolean).map((str2) => resolveCallback(str2, phase, false, context, buffer))
    ).then(() => buffer[0])
  );
  if (preserveCallbacks) {
    return raw(await resStr, callbacks);
  } else {
    return resStr;
  }
};

// .stack/node_modules/hono/dist/context.js
var TEXT_PLAIN = "text/plain; charset=UTF-8";
var setDefaultContentType = (contentType, headers) => {
  return {
    "Content-Type": contentType,
    ...headers
  };
};
var createResponseInstance = (body, init) => new Response(body, init);
var Context = class {
  #rawRequest;
  #req;
  /**
   * `.env` can get bindings (environment variables, secrets, KV namespaces, D1 database, R2 bucket etc.) in Cloudflare Workers.
   *
   * @see {@link https://hono.dev/docs/api/context#env}
   *
   * @example
   * ```ts
   * // Environment object for Cloudflare Workers
   * app.get('*', async c => {
   *   const counter = c.env.COUNTER
   * })
   * ```
   */
  env = {};
  #var;
  finalized = false;
  /**
   * `.error` can get the error object from the middleware if the Handler throws an error.
   *
   * @see {@link https://hono.dev/docs/api/context#error}
   *
   * @example
   * ```ts
   * app.use('*', async (c, next) => {
   *   await next()
   *   if (c.error) {
   *     // do something...
   *   }
   * })
   * ```
   */
  error;
  #status;
  #executionCtx;
  #res;
  #layout;
  #renderer;
  #notFoundHandler;
  #preparedHeaders;
  #matchResult;
  #path;
  /**
   * Creates an instance of the Context class.
   *
   * @param req - The Request object.
   * @param options - Optional configuration options for the context.
   */
  constructor(req, options) {
    this.#rawRequest = req;
    if (options) {
      this.#executionCtx = options.executionCtx;
      this.env = options.env;
      this.#notFoundHandler = options.notFoundHandler;
      this.#path = options.path;
      this.#matchResult = options.matchResult;
    }
  }
  /**
   * `.req` is the instance of {@link HonoRequest}.
   */
  get req() {
    this.#req ??= new HonoRequest(this.#rawRequest, this.#path, this.#matchResult);
    return this.#req;
  }
  /**
   * @see {@link https://hono.dev/docs/api/context#event}
   * The FetchEvent associated with the current request.
   *
   * @throws Will throw an error if the context does not have a FetchEvent.
   */
  get event() {
    if (this.#executionCtx && "respondWith" in this.#executionCtx) {
      return this.#executionCtx;
    } else {
      throw Error("This context has no FetchEvent");
    }
  }
  /**
   * @see {@link https://hono.dev/docs/api/context#executionctx}
   * The ExecutionContext associated with the current request.
   *
   * @throws Will throw an error if the context does not have an ExecutionContext.
   */
  get executionCtx() {
    if (this.#executionCtx) {
      return this.#executionCtx;
    } else {
      throw Error("This context has no ExecutionContext");
    }
  }
  /**
   * @see {@link https://hono.dev/docs/api/context#res}
   * The Response object for the current request.
   */
  get res() {
    return this.#res ||= createResponseInstance(null, {
      headers: this.#preparedHeaders ??= new Headers()
    });
  }
  /**
   * Sets the Response object for the current request.
   *
   * @param _res - The Response object to set.
   */
  set res(_res) {
    if (this.#res && _res) {
      _res = createResponseInstance(_res.body, _res);
      for (const [k, v] of this.#res.headers.entries()) {
        if (k === "content-type") {
          continue;
        }
        if (k === "set-cookie") {
          const cookies = this.#res.headers.getSetCookie();
          _res.headers.delete("set-cookie");
          for (const cookie of cookies) {
            _res.headers.append("set-cookie", cookie);
          }
        } else {
          _res.headers.set(k, v);
        }
      }
    }
    this.#res = _res;
    this.finalized = true;
  }
  /**
   * `.render()` can create a response within a layout.
   *
   * @see {@link https://hono.dev/docs/api/context#render-setrenderer}
   *
   * @example
   * ```ts
   * app.get('/', (c) => {
   *   return c.render('Hello!')
   * })
   * ```
   */
  render = (...args) => {
    this.#renderer ??= (content) => this.html(content);
    return this.#renderer(...args);
  };
  /**
   * Sets the layout for the response.
   *
   * @param layout - The layout to set.
   * @returns The layout function.
   */
  setLayout = (layout) => this.#layout = layout;
  /**
   * Gets the current layout for the response.
   *
   * @returns The current layout function.
   */
  getLayout = () => this.#layout;
  /**
   * `.setRenderer()` can set the layout in the custom middleware.
   *
   * @see {@link https://hono.dev/docs/api/context#render-setrenderer}
   *
   * @example
   * ```tsx
   * app.use('*', async (c, next) => {
   *   c.setRenderer((content) => {
   *     return c.html(
   *       <html>
   *         <body>
   *           <p>{content}</p>
   *         </body>
   *       </html>
   *     )
   *   })
   *   await next()
   * })
   * ```
   */
  setRenderer = (renderer) => {
    this.#renderer = renderer;
  };
  /**
   * `.header()` can set headers.
   *
   * @see {@link https://hono.dev/docs/api/context#header}
   *
   * @example
   * ```ts
   * app.get('/welcome', (c) => {
   *   // Set headers
   *   c.header('X-Message', 'Hello!')
   *   c.header('Content-Type', 'text/plain')
   *
   *   return c.body('Thank you for coming')
   * })
   * ```
   */
  header = (name, value, options) => {
    if (this.finalized) {
      this.#res = createResponseInstance(this.#res.body, this.#res);
    }
    const headers = this.#res ? this.#res.headers : this.#preparedHeaders ??= new Headers();
    if (value === void 0) {
      headers.delete(name);
    } else if (options?.append) {
      headers.append(name, value);
    } else {
      headers.set(name, value);
    }
  };
  status = (status) => {
    this.#status = status;
  };
  /**
   * `.set()` can set the value specified by the key.
   *
   * @see {@link https://hono.dev/docs/api/context#set-get}
   *
   * @example
   * ```ts
   * app.use('*', async (c, next) => {
   *   c.set('message', 'Hono is hot!!')
   *   await next()
   * })
   * ```
   */
  set = (key, value) => {
    this.#var ??= /* @__PURE__ */ new Map();
    this.#var.set(key, value);
  };
  /**
   * `.get()` can use the value specified by the key.
   *
   * @see {@link https://hono.dev/docs/api/context#set-get}
   *
   * @example
   * ```ts
   * app.get('/', (c) => {
   *   const message = c.get('message')
   *   return c.text(`The message is "${message}"`)
   * })
   * ```
   */
  get = (key) => {
    return this.#var ? this.#var.get(key) : void 0;
  };
  /**
   * `.var` can access the value of a variable.
   *
   * @see {@link https://hono.dev/docs/api/context#var}
   *
   * @example
   * ```ts
   * const result = c.var.client.oneMethod()
   * ```
   */
  // c.var.propName is a read-only
  get var() {
    if (!this.#var) {
      return {};
    }
    return Object.fromEntries(this.#var);
  }
  #newResponse(data, arg, headers) {
    const responseHeaders = this.#res ? new Headers(this.#res.headers) : this.#preparedHeaders ?? new Headers();
    if (typeof arg === "object" && "headers" in arg) {
      const argHeaders = arg.headers instanceof Headers ? arg.headers : new Headers(arg.headers);
      for (const [key, value] of argHeaders) {
        if (key.toLowerCase() === "set-cookie") {
          responseHeaders.append(key, value);
        } else {
          responseHeaders.set(key, value);
        }
      }
    }
    if (headers) {
      for (const [k, v] of Object.entries(headers)) {
        if (typeof v === "string") {
          responseHeaders.set(k, v);
        } else {
          responseHeaders.delete(k);
          for (const v2 of v) {
            responseHeaders.append(k, v2);
          }
        }
      }
    }
    const status = typeof arg === "number" ? arg : arg?.status ?? this.#status;
    return createResponseInstance(data, { status, headers: responseHeaders });
  }
  newResponse = (...args) => this.#newResponse(...args);
  /**
   * `.body()` can return the HTTP response.
   * You can set headers with `.header()` and set HTTP status code with `.status`.
   * This can also be set in `.text()`, `.json()` and so on.
   *
   * @see {@link https://hono.dev/docs/api/context#body}
   *
   * @example
   * ```ts
   * app.get('/welcome', (c) => {
   *   // Set headers
   *   c.header('X-Message', 'Hello!')
   *   c.header('Content-Type', 'text/plain')
   *   // Set HTTP status code
   *   c.status(201)
   *
   *   // Return the response body
   *   return c.body('Thank you for coming')
   * })
   * ```
   */
  body = (data, arg, headers) => this.#newResponse(data, arg, headers);
  #useFastPath() {
    return !this.#preparedHeaders && !this.#status && !this.finalized;
  }
  /**
   * `.text()` can render text as `Content-Type:text/plain`.
   *
   * @see {@link https://hono.dev/docs/api/context#text}
   *
   * @example
   * ```ts
   * app.get('/say', (c) => {
   *   return c.text('Hello!')
   * })
   * ```
   */
  text = (text2, arg, headers) => {
    return this.#useFastPath() && !arg && !headers ? createResponseInstance(text2) : this.#newResponse(
      text2,
      arg,
      setDefaultContentType(TEXT_PLAIN, headers)
    );
  };
  /**
   * `.json()` can render JSON as `Content-Type:application/json`.
   *
   * @see {@link https://hono.dev/docs/api/context#json}
   *
   * @example
   * ```ts
   * app.get('/api', (c) => {
   *   return c.json({ message: 'Hello!' })
   * })
   * ```
   */
  json = (object, arg, headers) => {
    return this.#useFastPath() && !arg && !headers ? Response.json(object) : this.#newResponse(
      JSON.stringify(object),
      arg,
      setDefaultContentType("application/json", headers)
    );
  };
  html = (html, arg, headers) => {
    const res = (html2) => this.#newResponse(html2, arg, setDefaultContentType("text/html; charset=UTF-8", headers));
    return typeof html === "object" ? resolveCallback(html, HtmlEscapedCallbackPhase.Stringify, false, {}).then(res) : res(html);
  };
  /**
   * `.redirect()` can Redirect, default status code is 302.
   *
   * @see {@link https://hono.dev/docs/api/context#redirect}
   *
   * @example
   * ```ts
   * app.get('/redirect', (c) => {
   *   return c.redirect('/')
   * })
   * app.get('/redirect-permanently', (c) => {
   *   return c.redirect('/', 301)
   * })
   * ```
   */
  redirect = (location, status) => {
    const locationString = String(location);
    this.header(
      "Location",
      // Multibyes should be encoded
      // eslint-disable-next-line no-control-regex
      !/[^\x00-\xFF]/.test(locationString) ? locationString : encodeURI(locationString)
    );
    return this.newResponse(null, status ?? 302);
  };
  /**
   * `.notFound()` can return the Not Found Response.
   *
   * @see {@link https://hono.dev/docs/api/context#notfound}
   *
   * @example
   * ```ts
   * app.get('/notfound', (c) => {
   *   return c.notFound()
   * })
   * ```
   */
  notFound = () => {
    this.#notFoundHandler ??= () => createResponseInstance();
    return this.#notFoundHandler(this);
  };
};

// .stack/node_modules/hono/dist/router.js
var METHOD_NAME_ALL = "ALL";
var METHOD_NAME_ALL_LOWERCASE = "all";
var METHODS = ["get", "post", "put", "delete", "options", "patch"];
var MESSAGE_MATCHER_IS_ALREADY_BUILT = "Can not add a route since the matcher is already built.";
var UnsupportedPathError = class extends Error {
};

// .stack/node_modules/hono/dist/utils/constants.js
var COMPOSED_HANDLER = "__COMPOSED_HANDLER";

// .stack/node_modules/hono/dist/hono-base.js
var notFoundHandler = (c) => {
  return c.text("404 Not Found", 404);
};
var errorHandler = (err, c) => {
  if ("getResponse" in err) {
    const res = err.getResponse();
    return c.newResponse(res.body, res);
  }
  console.error(err);
  return c.text("Internal Server Error", 500);
};
var Hono = class _Hono {
  get;
  post;
  put;
  delete;
  options;
  patch;
  all;
  on;
  use;
  /*
    This class is like an abstract class and does not have a router.
    To use it, inherit the class and implement router in the constructor.
  */
  router;
  getPath;
  // Cannot use `#` because it requires visibility at JavaScript runtime.
  _basePath = "/";
  #path = "/";
  routes = [];
  constructor(options = {}) {
    const allMethods = [...METHODS, METHOD_NAME_ALL_LOWERCASE];
    allMethods.forEach((method) => {
      this[method] = (args1, ...args) => {
        if (typeof args1 === "string") {
          this.#path = args1;
        } else {
          this.#addRoute(method, this.#path, args1);
        }
        args.forEach((handler) => {
          this.#addRoute(method, this.#path, handler);
        });
        return this;
      };
    });
    this.on = (method, path, ...handlers) => {
      for (const p of [path].flat()) {
        this.#path = p;
        for (const m of [method].flat()) {
          handlers.map((handler) => {
            this.#addRoute(m.toUpperCase(), this.#path, handler);
          });
        }
      }
      return this;
    };
    this.use = (arg1, ...handlers) => {
      if (typeof arg1 === "string") {
        this.#path = arg1;
      } else {
        this.#path = "*";
        handlers.unshift(arg1);
      }
      handlers.forEach((handler) => {
        this.#addRoute(METHOD_NAME_ALL, this.#path, handler);
      });
      return this;
    };
    const { strict, ...optionsWithoutStrict } = options;
    Object.assign(this, optionsWithoutStrict);
    this.getPath = strict ?? true ? options.getPath ?? getPath : getPathNoStrict;
  }
  #clone() {
    const clone = new _Hono({
      router: this.router,
      getPath: this.getPath
    });
    clone.errorHandler = this.errorHandler;
    clone.#notFoundHandler = this.#notFoundHandler;
    clone.routes = this.routes;
    return clone;
  }
  #notFoundHandler = notFoundHandler;
  // Cannot use `#` because it requires visibility at JavaScript runtime.
  errorHandler = errorHandler;
  /**
   * `.route()` allows grouping other Hono instance in routes.
   *
   * @see {@link https://hono.dev/docs/api/routing#grouping}
   *
   * @param {string} path - base Path
   * @param {Hono} app - other Hono instance
   * @returns {Hono} routed Hono instance
   *
   * @example
   * ```ts
   * const app = new Hono()
   * const app2 = new Hono()
   *
   * app2.get("/user", (c) => c.text("user"))
   * app.route("/api", app2) // GET /api/user
   * ```
   */
  route(path, app) {
    const subApp = this.basePath(path);
    app.routes.map((r) => {
      let handler;
      if (app.errorHandler === errorHandler) {
        handler = r.handler;
      } else {
        handler = async (c, next) => (await compose([], app.errorHandler)(c, () => r.handler(c, next))).res;
        handler[COMPOSED_HANDLER] = r.handler;
      }
      subApp.#addRoute(r.method, r.path, handler);
    });
    return this;
  }
  /**
   * `.basePath()` allows base paths to be specified.
   *
   * @see {@link https://hono.dev/docs/api/routing#base-path}
   *
   * @param {string} path - base Path
   * @returns {Hono} changed Hono instance
   *
   * @example
   * ```ts
   * const api = new Hono().basePath('/api')
   * ```
   */
  basePath(path) {
    const subApp = this.#clone();
    subApp._basePath = mergePath(this._basePath, path);
    return subApp;
  }
  /**
   * `.onError()` handles an error and returns a customized Response.
   *
   * @see {@link https://hono.dev/docs/api/hono#error-handling}
   *
   * @param {ErrorHandler} handler - request Handler for error
   * @returns {Hono} changed Hono instance
   *
   * @example
   * ```ts
   * app.onError((err, c) => {
   *   console.error(`${err}`)
   *   return c.text('Custom Error Message', 500)
   * })
   * ```
   */
  onError = (handler) => {
    this.errorHandler = handler;
    return this;
  };
  /**
   * `.notFound()` allows you to customize a Not Found Response.
   *
   * @see {@link https://hono.dev/docs/api/hono#not-found}
   *
   * @param {NotFoundHandler} handler - request handler for not-found
   * @returns {Hono} changed Hono instance
   *
   * @example
   * ```ts
   * app.notFound((c) => {
   *   return c.text('Custom 404 Message', 404)
   * })
   * ```
   */
  notFound = (handler) => {
    this.#notFoundHandler = handler;
    return this;
  };
  /**
   * `.mount()` allows you to mount applications built with other frameworks into your Hono application.
   *
   * @see {@link https://hono.dev/docs/api/hono#mount}
   *
   * @param {string} path - base Path
   * @param {Function} applicationHandler - other Request Handler
   * @param {MountOptions} [options] - options of `.mount()`
   * @returns {Hono} mounted Hono instance
   *
   * @example
   * ```ts
   * import { Router as IttyRouter } from 'itty-router'
   * import { Hono } from 'hono'
   * // Create itty-router application
   * const ittyRouter = IttyRouter()
   * // GET /itty-router/hello
   * ittyRouter.get('/hello', () => new Response('Hello from itty-router'))
   *
   * const app = new Hono()
   * app.mount('/itty-router', ittyRouter.handle)
   * ```
   *
   * @example
   * ```ts
   * const app = new Hono()
   * // Send the request to another application without modification.
   * app.mount('/app', anotherApp, {
   *   replaceRequest: (req) => req,
   * })
   * ```
   */
  mount(path, applicationHandler, options) {
    let replaceRequest;
    let optionHandler;
    if (options) {
      if (typeof options === "function") {
        optionHandler = options;
      } else {
        optionHandler = options.optionHandler;
        if (options.replaceRequest === false) {
          replaceRequest = (request) => request;
        } else {
          replaceRequest = options.replaceRequest;
        }
      }
    }
    const getOptions = optionHandler ? (c) => {
      const options2 = optionHandler(c);
      return Array.isArray(options2) ? options2 : [options2];
    } : (c) => {
      let executionContext = void 0;
      try {
        executionContext = c.executionCtx;
      } catch {
      }
      return [c.env, executionContext];
    };
    replaceRequest ||= (() => {
      const mergedPath = mergePath(this._basePath, path);
      const pathPrefixLength = mergedPath === "/" ? 0 : mergedPath.length;
      return (request) => {
        const url = new URL(request.url);
        url.pathname = url.pathname.slice(pathPrefixLength) || "/";
        return new Request(url, request);
      };
    })();
    const handler = async (c, next) => {
      const res = await applicationHandler(replaceRequest(c.req.raw), ...getOptions(c));
      if (res) {
        return res;
      }
      await next();
    };
    this.#addRoute(METHOD_NAME_ALL, mergePath(path, "*"), handler);
    return this;
  }
  #addRoute(method, path, handler) {
    method = method.toUpperCase();
    path = mergePath(this._basePath, path);
    const r = { basePath: this._basePath, path, method, handler };
    this.router.add(method, path, [handler, r]);
    this.routes.push(r);
  }
  #handleError(err, c) {
    if (err instanceof Error) {
      return this.errorHandler(err, c);
    }
    throw err;
  }
  #dispatch(request, executionCtx, env, method) {
    if (method === "HEAD") {
      return (async () => new Response(null, await this.#dispatch(request, executionCtx, env, "GET")))();
    }
    const path = this.getPath(request, { env });
    const matchResult = this.router.match(method, path);
    const c = new Context(request, {
      path,
      matchResult,
      env,
      executionCtx,
      notFoundHandler: this.#notFoundHandler
    });
    if (matchResult[0].length === 1) {
      let res;
      try {
        res = matchResult[0][0][0][0](c, async () => {
          c.res = await this.#notFoundHandler(c);
        });
      } catch (err) {
        return this.#handleError(err, c);
      }
      return res instanceof Promise ? res.then(
        (resolved) => resolved || (c.finalized ? c.res : this.#notFoundHandler(c))
      ).catch((err) => this.#handleError(err, c)) : res ?? this.#notFoundHandler(c);
    }
    const composed = compose(matchResult[0], this.errorHandler, this.#notFoundHandler);
    return (async () => {
      try {
        const context = await composed(c);
        if (!context.finalized) {
          throw new Error(
            "Context is not finalized. Did you forget to return a Response object or `await next()`?"
          );
        }
        return context.res;
      } catch (err) {
        return this.#handleError(err, c);
      }
    })();
  }
  /**
   * `.fetch()` will be entry point of your app.
   *
   * @see {@link https://hono.dev/docs/api/hono#fetch}
   *
   * @param {Request} request - request Object of request
   * @param {Env} Env - env Object
   * @param {ExecutionContext} - context of execution
   * @returns {Response | Promise<Response>} response of request
   *
   */
  fetch = (request, ...rest) => {
    return this.#dispatch(request, rest[1], rest[0], request.method);
  };
  /**
   * `.request()` is a useful method for testing.
   * You can pass a URL or pathname to send a GET request.
   * app will return a Response object.
   * ```ts
   * test('GET /hello is ok', async () => {
   *   const res = await app.request('/hello')
   *   expect(res.status).toBe(200)
   * })
   * ```
   * @see https://hono.dev/docs/api/hono#request
   */
  request = (input, requestInit, Env, executionCtx) => {
    if (input instanceof Request) {
      return this.fetch(requestInit ? new Request(input, requestInit) : input, Env, executionCtx);
    }
    input = input.toString();
    return this.fetch(
      new Request(
        /^https?:\/\//.test(input) ? input : `http://localhost${mergePath("/", input)}`,
        requestInit
      ),
      Env,
      executionCtx
    );
  };
  /**
   * `.fire()` automatically adds a global fetch event listener.
   * This can be useful for environments that adhere to the Service Worker API, such as non-ES module Cloudflare Workers.
   * @deprecated
   * Use `fire` from `hono/service-worker` instead.
   * ```ts
   * import { Hono } from 'hono'
   * import { fire } from 'hono/service-worker'
   *
   * const app = new Hono()
   * // ...
   * fire(app)
   * ```
   * @see https://hono.dev/docs/api/hono#fire
   * @see https://developer.mozilla.org/en-US/docs/Web/API/Service_Worker_API
   * @see https://developers.cloudflare.com/workers/reference/migrate-to-module-workers/
   */
  fire = () => {
    addEventListener("fetch", (event) => {
      event.respondWith(this.#dispatch(event.request, event, void 0, event.request.method));
    });
  };
};

// .stack/node_modules/hono/dist/router/reg-exp-router/matcher.js
var emptyParam = [];
function match(method, path) {
  const matchers = this.buildAllMatchers();
  const match2 = ((method2, path2) => {
    const matcher = matchers[method2] || matchers[METHOD_NAME_ALL];
    const staticMatch = matcher[2][path2];
    if (staticMatch) {
      return staticMatch;
    }
    const match3 = path2.match(matcher[0]);
    if (!match3) {
      return [[], emptyParam];
    }
    const index = match3.indexOf("", 1);
    return [matcher[1][index], match3];
  });
  this.match = match2;
  return match2(method, path);
}

// .stack/node_modules/hono/dist/router/reg-exp-router/node.js
var LABEL_REG_EXP_STR = "[^/]+";
var ONLY_WILDCARD_REG_EXP_STR = ".*";
var TAIL_WILDCARD_REG_EXP_STR = "(?:|/.*)";
var PATH_ERROR = /* @__PURE__ */ Symbol();
var regExpMetaChars = new Set(".\\+*[^]$()");
function compareKey(a, b) {
  if (a.length === 1) {
    return b.length === 1 ? a < b ? -1 : 1 : -1;
  }
  if (b.length === 1) {
    return 1;
  }
  if (a === ONLY_WILDCARD_REG_EXP_STR || a === TAIL_WILDCARD_REG_EXP_STR) {
    return 1;
  } else if (b === ONLY_WILDCARD_REG_EXP_STR || b === TAIL_WILDCARD_REG_EXP_STR) {
    return -1;
  }
  if (a === LABEL_REG_EXP_STR) {
    return 1;
  } else if (b === LABEL_REG_EXP_STR) {
    return -1;
  }
  return a.length === b.length ? a < b ? -1 : 1 : b.length - a.length;
}
var Node = class _Node {
  #index;
  #varIndex;
  #children = /* @__PURE__ */ Object.create(null);
  insert(tokens, index, paramMap, context, pathErrorCheckOnly) {
    if (tokens.length === 0) {
      if (this.#index !== void 0) {
        throw PATH_ERROR;
      }
      if (pathErrorCheckOnly) {
        return;
      }
      this.#index = index;
      return;
    }
    const [token, ...restTokens] = tokens;
    const pattern = token === "*" ? restTokens.length === 0 ? ["", "", ONLY_WILDCARD_REG_EXP_STR] : ["", "", LABEL_REG_EXP_STR] : token === "/*" ? ["", "", TAIL_WILDCARD_REG_EXP_STR] : token.match(/^\:([^\{\}]+)(?:\{(.+)\})?$/);
    let node;
    if (pattern) {
      const name = pattern[1];
      let regexpStr = pattern[2] || LABEL_REG_EXP_STR;
      if (name && pattern[2]) {
        if (regexpStr === ".*") {
          throw PATH_ERROR;
        }
        regexpStr = regexpStr.replace(/^\((?!\?:)(?=[^)]+\)$)/, "(?:");
        if (/\((?!\?:)/.test(regexpStr)) {
          throw PATH_ERROR;
        }
      }
      node = this.#children[regexpStr];
      if (!node) {
        if (Object.keys(this.#children).some(
          (k) => k !== ONLY_WILDCARD_REG_EXP_STR && k !== TAIL_WILDCARD_REG_EXP_STR
        )) {
          throw PATH_ERROR;
        }
        if (pathErrorCheckOnly) {
          return;
        }
        node = this.#children[regexpStr] = new _Node();
        if (name !== "") {
          node.#varIndex = context.varIndex++;
        }
      }
      if (!pathErrorCheckOnly && name !== "") {
        paramMap.push([name, node.#varIndex]);
      }
    } else {
      node = this.#children[token];
      if (!node) {
        if (Object.keys(this.#children).some(
          (k) => k.length > 1 && k !== ONLY_WILDCARD_REG_EXP_STR && k !== TAIL_WILDCARD_REG_EXP_STR
        )) {
          throw PATH_ERROR;
        }
        if (pathErrorCheckOnly) {
          return;
        }
        node = this.#children[token] = new _Node();
      }
    }
    node.insert(restTokens, index, paramMap, context, pathErrorCheckOnly);
  }
  buildRegExpStr() {
    const childKeys = Object.keys(this.#children).sort(compareKey);
    const strList = childKeys.map((k) => {
      const c = this.#children[k];
      return (typeof c.#varIndex === "number" ? `(${k})@${c.#varIndex}` : regExpMetaChars.has(k) ? `\\${k}` : k) + c.buildRegExpStr();
    });
    if (typeof this.#index === "number") {
      strList.unshift(`#${this.#index}`);
    }
    if (strList.length === 0) {
      return "";
    }
    if (strList.length === 1) {
      return strList[0];
    }
    return "(?:" + strList.join("|") + ")";
  }
};

// .stack/node_modules/hono/dist/router/reg-exp-router/trie.js
var Trie = class {
  #context = { varIndex: 0 };
  #root = new Node();
  insert(path, index, pathErrorCheckOnly) {
    const paramAssoc = [];
    const groups = [];
    for (let i = 0; ; ) {
      let replaced = false;
      path = path.replace(/\{[^}]+\}/g, (m) => {
        const mark = `@\\${i}`;
        groups[i] = [mark, m];
        i++;
        replaced = true;
        return mark;
      });
      if (!replaced) {
        break;
      }
    }
    const tokens = path.match(/(?::[^\/]+)|(?:\/\*$)|./g) || [];
    for (let i = groups.length - 1; i >= 0; i--) {
      const [mark] = groups[i];
      for (let j = tokens.length - 1; j >= 0; j--) {
        if (tokens[j].indexOf(mark) !== -1) {
          tokens[j] = tokens[j].replace(mark, groups[i][1]);
          break;
        }
      }
    }
    this.#root.insert(tokens, index, paramAssoc, this.#context, pathErrorCheckOnly);
    return paramAssoc;
  }
  buildRegExp() {
    let regexp = this.#root.buildRegExpStr();
    if (regexp === "") {
      return [/^$/, [], []];
    }
    let captureIndex = 0;
    const indexReplacementMap = [];
    const paramReplacementMap = [];
    regexp = regexp.replace(/#(\d+)|@(\d+)|\.\*\$/g, (_, handlerIndex, paramIndex) => {
      if (handlerIndex !== void 0) {
        indexReplacementMap[++captureIndex] = Number(handlerIndex);
        return "$()";
      }
      if (paramIndex !== void 0) {
        paramReplacementMap[Number(paramIndex)] = ++captureIndex;
        return "";
      }
      return "";
    });
    return [new RegExp(`^${regexp}`), indexReplacementMap, paramReplacementMap];
  }
};

// .stack/node_modules/hono/dist/router/reg-exp-router/router.js
var nullMatcher = [/^$/, [], /* @__PURE__ */ Object.create(null)];
var wildcardRegExpCache = /* @__PURE__ */ Object.create(null);
function buildWildcardRegExp(path) {
  return wildcardRegExpCache[path] ??= new RegExp(
    path === "*" ? "" : `^${path.replace(
      /\/\*$|([.\\+*[^\]$()])/g,
      (_, metaChar) => metaChar ? `\\${metaChar}` : "(?:|/.*)"
    )}$`
  );
}
function clearWildcardRegExpCache() {
  wildcardRegExpCache = /* @__PURE__ */ Object.create(null);
}
function buildMatcherFromPreprocessedRoutes(routes) {
  const trie = new Trie();
  const handlerData = [];
  if (routes.length === 0) {
    return nullMatcher;
  }
  const routesWithStaticPathFlag = routes.map(
    (route) => [!/\*|\/:/.test(route[0]), ...route]
  ).sort(
    ([isStaticA, pathA], [isStaticB, pathB]) => isStaticA ? 1 : isStaticB ? -1 : pathA.length - pathB.length
  );
  const staticMap = /* @__PURE__ */ Object.create(null);
  for (let i = 0, j = -1, len = routesWithStaticPathFlag.length; i < len; i++) {
    const [pathErrorCheckOnly, path, handlers] = routesWithStaticPathFlag[i];
    if (pathErrorCheckOnly) {
      staticMap[path] = [handlers.map(([h]) => [h, /* @__PURE__ */ Object.create(null)]), emptyParam];
    } else {
      j++;
    }
    let paramAssoc;
    try {
      paramAssoc = trie.insert(path, j, pathErrorCheckOnly);
    } catch (e) {
      throw e === PATH_ERROR ? new UnsupportedPathError(path) : e;
    }
    if (pathErrorCheckOnly) {
      continue;
    }
    handlerData[j] = handlers.map(([h, paramCount]) => {
      const paramIndexMap = /* @__PURE__ */ Object.create(null);
      paramCount -= 1;
      for (; paramCount >= 0; paramCount--) {
        const [key, value] = paramAssoc[paramCount];
        paramIndexMap[key] = value;
      }
      return [h, paramIndexMap];
    });
  }
  const [regexp, indexReplacementMap, paramReplacementMap] = trie.buildRegExp();
  for (let i = 0, len = handlerData.length; i < len; i++) {
    for (let j = 0, len2 = handlerData[i].length; j < len2; j++) {
      const map = handlerData[i][j]?.[1];
      if (!map) {
        continue;
      }
      const keys = Object.keys(map);
      for (let k = 0, len3 = keys.length; k < len3; k++) {
        map[keys[k]] = paramReplacementMap[map[keys[k]]];
      }
    }
  }
  const handlerMap = [];
  for (const i in indexReplacementMap) {
    handlerMap[i] = handlerData[indexReplacementMap[i]];
  }
  return [regexp, handlerMap, staticMap];
}
function findMiddleware(middleware, path) {
  if (!middleware) {
    return void 0;
  }
  for (const k of Object.keys(middleware).sort((a, b) => b.length - a.length)) {
    if (buildWildcardRegExp(k).test(path)) {
      return [...middleware[k]];
    }
  }
  return void 0;
}
var RegExpRouter = class {
  name = "RegExpRouter";
  #middleware;
  #routes;
  constructor() {
    this.#middleware = { [METHOD_NAME_ALL]: /* @__PURE__ */ Object.create(null) };
    this.#routes = { [METHOD_NAME_ALL]: /* @__PURE__ */ Object.create(null) };
  }
  add(method, path, handler) {
    const middleware = this.#middleware;
    const routes = this.#routes;
    if (!middleware || !routes) {
      throw new Error(MESSAGE_MATCHER_IS_ALREADY_BUILT);
    }
    if (!middleware[method]) {
      ;
      [middleware, routes].forEach((handlerMap) => {
        handlerMap[method] = /* @__PURE__ */ Object.create(null);
        Object.keys(handlerMap[METHOD_NAME_ALL]).forEach((p) => {
          handlerMap[method][p] = [...handlerMap[METHOD_NAME_ALL][p]];
        });
      });
    }
    if (path === "/*") {
      path = "*";
    }
    const paramCount = (path.match(/\/:/g) || []).length;
    if (/\*$/.test(path)) {
      const re = buildWildcardRegExp(path);
      if (method === METHOD_NAME_ALL) {
        Object.keys(middleware).forEach((m) => {
          middleware[m][path] ||= findMiddleware(middleware[m], path) || findMiddleware(middleware[METHOD_NAME_ALL], path) || [];
        });
      } else {
        middleware[method][path] ||= findMiddleware(middleware[method], path) || findMiddleware(middleware[METHOD_NAME_ALL], path) || [];
      }
      Object.keys(middleware).forEach((m) => {
        if (method === METHOD_NAME_ALL || method === m) {
          Object.keys(middleware[m]).forEach((p) => {
            re.test(p) && middleware[m][p].push([handler, paramCount]);
          });
        }
      });
      Object.keys(routes).forEach((m) => {
        if (method === METHOD_NAME_ALL || method === m) {
          Object.keys(routes[m]).forEach(
            (p) => re.test(p) && routes[m][p].push([handler, paramCount])
          );
        }
      });
      return;
    }
    const paths = checkOptionalParameter(path) || [path];
    for (let i = 0, len = paths.length; i < len; i++) {
      const path2 = paths[i];
      Object.keys(routes).forEach((m) => {
        if (method === METHOD_NAME_ALL || method === m) {
          routes[m][path2] ||= [
            ...findMiddleware(middleware[m], path2) || findMiddleware(middleware[METHOD_NAME_ALL], path2) || []
          ];
          routes[m][path2].push([handler, paramCount - len + i + 1]);
        }
      });
    }
  }
  match = match;
  buildAllMatchers() {
    const matchers = /* @__PURE__ */ Object.create(null);
    Object.keys(this.#routes).concat(Object.keys(this.#middleware)).forEach((method) => {
      matchers[method] ||= this.#buildMatcher(method);
    });
    this.#middleware = this.#routes = void 0;
    clearWildcardRegExpCache();
    return matchers;
  }
  #buildMatcher(method) {
    const routes = [];
    let hasOwnRoute = method === METHOD_NAME_ALL;
    [this.#middleware, this.#routes].forEach((r) => {
      const ownRoute = r[method] ? Object.keys(r[method]).map((path) => [path, r[method][path]]) : [];
      if (ownRoute.length !== 0) {
        hasOwnRoute ||= true;
        routes.push(...ownRoute);
      } else if (method !== METHOD_NAME_ALL) {
        routes.push(
          ...Object.keys(r[METHOD_NAME_ALL]).map((path) => [path, r[METHOD_NAME_ALL][path]])
        );
      }
    });
    if (!hasOwnRoute) {
      return null;
    } else {
      return buildMatcherFromPreprocessedRoutes(routes);
    }
  }
};

// .stack/node_modules/hono/dist/router/smart-router/router.js
var SmartRouter = class {
  name = "SmartRouter";
  #routers = [];
  #routes = [];
  constructor(init) {
    this.#routers = init.routers;
  }
  add(method, path, handler) {
    if (!this.#routes) {
      throw new Error(MESSAGE_MATCHER_IS_ALREADY_BUILT);
    }
    this.#routes.push([method, path, handler]);
  }
  match(method, path) {
    if (!this.#routes) {
      throw new Error("Fatal error");
    }
    const routers = this.#routers;
    const routes = this.#routes;
    const len = routers.length;
    let i = 0;
    let res;
    for (; i < len; i++) {
      const router = routers[i];
      try {
        for (let i2 = 0, len2 = routes.length; i2 < len2; i2++) {
          router.add(...routes[i2]);
        }
        res = router.match(method, path);
      } catch (e) {
        if (e instanceof UnsupportedPathError) {
          continue;
        }
        throw e;
      }
      this.match = router.match.bind(router);
      this.#routers = [router];
      this.#routes = void 0;
      break;
    }
    if (i === len) {
      throw new Error("Fatal error");
    }
    this.name = `SmartRouter + ${this.activeRouter.name}`;
    return res;
  }
  get activeRouter() {
    if (this.#routes || this.#routers.length !== 1) {
      throw new Error("No active router has been determined yet.");
    }
    return this.#routers[0];
  }
};

// .stack/node_modules/hono/dist/router/trie-router/node.js
var emptyParams = /* @__PURE__ */ Object.create(null);
var hasChildren = (children) => {
  for (const _ in children) {
    return true;
  }
  return false;
};
var Node2 = class _Node2 {
  #methods;
  #children;
  #patterns;
  #order = 0;
  #params = emptyParams;
  constructor(method, handler, children) {
    this.#children = children || /* @__PURE__ */ Object.create(null);
    this.#methods = [];
    if (method && handler) {
      const m = /* @__PURE__ */ Object.create(null);
      m[method] = { handler, possibleKeys: [], score: 0 };
      this.#methods = [m];
    }
    this.#patterns = [];
  }
  insert(method, path, handler) {
    this.#order = ++this.#order;
    let curNode = this;
    const parts = splitRoutingPath(path);
    const possibleKeys = [];
    for (let i = 0, len = parts.length; i < len; i++) {
      const p = parts[i];
      const nextP = parts[i + 1];
      const pattern = getPattern(p, nextP);
      const key = Array.isArray(pattern) ? pattern[0] : p;
      if (key in curNode.#children) {
        curNode = curNode.#children[key];
        if (pattern) {
          possibleKeys.push(pattern[1]);
        }
        continue;
      }
      curNode.#children[key] = new _Node2();
      if (pattern) {
        curNode.#patterns.push(pattern);
        possibleKeys.push(pattern[1]);
      }
      curNode = curNode.#children[key];
    }
    curNode.#methods.push({
      [method]: {
        handler,
        possibleKeys: possibleKeys.filter((v, i, a) => a.indexOf(v) === i),
        score: this.#order
      }
    });
    return curNode;
  }
  #pushHandlerSets(handlerSets, node, method, nodeParams, params) {
    for (let i = 0, len = node.#methods.length; i < len; i++) {
      const m = node.#methods[i];
      const handlerSet = m[method] || m[METHOD_NAME_ALL];
      const processedSet = {};
      if (handlerSet !== void 0) {
        handlerSet.params = /* @__PURE__ */ Object.create(null);
        handlerSets.push(handlerSet);
        if (nodeParams !== emptyParams || params && params !== emptyParams) {
          for (let i2 = 0, len2 = handlerSet.possibleKeys.length; i2 < len2; i2++) {
            const key = handlerSet.possibleKeys[i2];
            const processed = processedSet[handlerSet.score];
            handlerSet.params[key] = params?.[key] && !processed ? params[key] : nodeParams[key] ?? params?.[key];
            processedSet[handlerSet.score] = true;
          }
        }
      }
    }
  }
  search(method, path) {
    const handlerSets = [];
    this.#params = emptyParams;
    const curNode = this;
    let curNodes = [curNode];
    const parts = splitPath(path);
    const curNodesQueue = [];
    const len = parts.length;
    let partOffsets = null;
    for (let i = 0; i < len; i++) {
      const part = parts[i];
      const isLast = i === len - 1;
      const tempNodes = [];
      for (let j = 0, len2 = curNodes.length; j < len2; j++) {
        const node = curNodes[j];
        const nextNode = node.#children[part];
        if (nextNode) {
          nextNode.#params = node.#params;
          if (isLast) {
            if (nextNode.#children["*"]) {
              this.#pushHandlerSets(handlerSets, nextNode.#children["*"], method, node.#params);
            }
            this.#pushHandlerSets(handlerSets, nextNode, method, node.#params);
          } else {
            tempNodes.push(nextNode);
          }
        }
        for (let k = 0, len3 = node.#patterns.length; k < len3; k++) {
          const pattern = node.#patterns[k];
          const params = node.#params === emptyParams ? {} : { ...node.#params };
          if (pattern === "*") {
            const astNode = node.#children["*"];
            if (astNode) {
              this.#pushHandlerSets(handlerSets, astNode, method, node.#params);
              astNode.#params = params;
              tempNodes.push(astNode);
            }
            continue;
          }
          const [key, name, matcher] = pattern;
          if (!part && !(matcher instanceof RegExp)) {
            continue;
          }
          const child = node.#children[key];
          if (matcher instanceof RegExp) {
            if (partOffsets === null) {
              partOffsets = new Array(len);
              let offset = path[0] === "/" ? 1 : 0;
              for (let p = 0; p < len; p++) {
                partOffsets[p] = offset;
                offset += parts[p].length + 1;
              }
            }
            const restPathString = path.substring(partOffsets[i]);
            const m = matcher.exec(restPathString);
            if (m) {
              params[name] = m[0];
              this.#pushHandlerSets(handlerSets, child, method, node.#params, params);
              if (hasChildren(child.#children)) {
                child.#params = params;
                const componentCount = m[0].match(/\//)?.length ?? 0;
                const targetCurNodes = curNodesQueue[componentCount] ||= [];
                targetCurNodes.push(child);
              }
              continue;
            }
          }
          if (matcher === true || matcher.test(part)) {
            params[name] = part;
            if (isLast) {
              this.#pushHandlerSets(handlerSets, child, method, params, node.#params);
              if (child.#children["*"]) {
                this.#pushHandlerSets(
                  handlerSets,
                  child.#children["*"],
                  method,
                  params,
                  node.#params
                );
              }
            } else {
              child.#params = params;
              tempNodes.push(child);
            }
          }
        }
      }
      const shifted = curNodesQueue.shift();
      curNodes = shifted ? tempNodes.concat(shifted) : tempNodes;
    }
    if (handlerSets.length > 1) {
      handlerSets.sort((a, b) => {
        return a.score - b.score;
      });
    }
    return [handlerSets.map(({ handler, params }) => [handler, params])];
  }
};

// .stack/node_modules/hono/dist/router/trie-router/router.js
var TrieRouter = class {
  name = "TrieRouter";
  #node;
  constructor() {
    this.#node = new Node2();
  }
  add(method, path, handler) {
    const results = checkOptionalParameter(path);
    if (results) {
      for (let i = 0, len = results.length; i < len; i++) {
        this.#node.insert(method, results[i], handler);
      }
      return;
    }
    this.#node.insert(method, path, handler);
  }
  match(method, path) {
    return this.#node.search(method, path);
  }
};

// .stack/node_modules/hono/dist/hono.js
var Hono2 = class extends Hono {
  /**
   * Creates an instance of the Hono class.
   *
   * @param options - Optional configuration options for the Hono instance.
   */
  constructor(options = {}) {
    super(options);
    this.router = options.router ?? new SmartRouter({
      routers: [new RegExpRouter(), new TrieRouter()]
    });
  }
};

// server/command.mjs
var BY_STATUS = { 400: "BAD_INPUT", 403: "NOT_ALLOWED", 404: "NOT_FOUND", 424: "MISSING_KEYS", 502: "SITE_FAILED", 504: "SITE_TIMEOUT" };
var Refused = class extends Error {
  constructor(message, status = 409, extra = {}) {
    super(message);
    this.status = status;
    this.code = extra.code ?? (/^Only a person/.test(message) ? "PERSON_ONLY" : BY_STATUS[status] ?? "REFUSED");
    if (extra.item !== void 0) this.item = extra.item;
  }
};
var commandsOf = (app) => app.commands ??= [];
var inputNames = (input) => Array.isArray(input) ? input.flatMap((x) => typeof x === "string" ? [x] : Object.keys(x)) : Object.keys(input ?? {});
function command(app, method, path, spec, handler) {
  commandsOf(app).push({ ...spec, method, path, input: spec.input ?? {}, by: spec.by ?? "anyone", read: method === "GET" });
  app.on(method, path, async (c) => {
    const actor = c.req.header("x-actor") || "";
    if (spec.by === "person" && !actor.startsWith("person:")) throw new Refused(`Only a person can do this: ask them. (${spec.name})`, 403);
    const body = method === "GET" ? c.req.query() : await c.req.json().catch(() => ({}));
    const input = {};
    for (const k of inputNames(spec.input)) if (body[k] !== void 0) input[k] = body[k];
    for (const [k, v] of Object.entries(c.req.param())) input[k] = /^\d+$/.test(v) ? Number(v) : v;
    return c.json(await handler(input, { actor }) ?? { ok: true });
  });
}
function mountErrors(app) {
  app.onError((e, c) => c.json({ error: e.message, code: e.code ?? (e.status && e.status < 500 ? "REFUSED" : "FAILED"), ...e.item !== void 0 ? { item: e.item } : {} }, e.status ?? 500));
  app.get("/_commands", (c) => c.json(commandsOf(app)));
}

// server/services/util.mjs
var T = {
  settings: "crm_settings",
  companies: "crm_companies",
  contacts: "crm_contacts",
  deals: "crm_deals",
  activities: "crm_activities",
  tasks: "crm_tasks",
  drafts: "crm_drafts",
  leads: "crm_leads",
  items: "crm_items",
  lines: "crm_lines",
  services: "crm_services"
};
var LIVE = "_deleted = 0 AND COALESCE(removed, 0) = 0";
var isPerson = (actor) => String(actor || "").startsWith("person:");
var wantsFull = (i, actor) => isPerson(actor) || i.full === true || i.full === "true";
var who = (actor) => String(actor || "").replace(/^(person|agent|module|platform):/, "") || "agent";
var dealName = (title, client) => client ? `Negocio con ${client} \xB7 ${title ?? ""}` : `Negocio \xB7 ${title ?? ""}`;
var today = (now = /* @__PURE__ */ new Date(), tz = "Europe/Madrid") => {
  try {
    return new Intl.DateTimeFormat("sv-SE", { timeZone: tz }).format(now);
  } catch {
    return now.toISOString().slice(0, 10);
  }
};
var stamp = (d = /* @__PURE__ */ new Date()) => (d instanceof Date ? d : new Date(d)).toISOString().slice(0, 19).replace("T", " ");
var ISO = /^(\d{4})-(\d{2})-(\d{2})$/;
function dateOf(v, field = "date") {
  if (v === void 0 || v === null || v === "") return null;
  const s = String(v).trim();
  const dmy = /^(\d{1,2})[/.-](\d{1,2})[/.-](\d{4})$/.exec(s);
  const iso = dmy ? `${dmy[3]}-${dmy[2].padStart(2, "0")}-${dmy[1].padStart(2, "0")}` : s.slice(0, 10);
  const m = ISO.exec(iso);
  if (!m || Number(m[2]) < 1 || Number(m[2]) > 12 || Number(m[3]) < 1 || Number(m[3]) > 31) throw new Refused(`${field} is a date written YYYY-MM-DD (got "${s.slice(0, 30)}").`, 400, { code: "BAD_DATE" });
  return iso;
}
function momentOf(v, now = /* @__PURE__ */ new Date(), field = "at") {
  if (v === void 0 || v === null || v === "") return stamp(now);
  const s = String(v).trim();
  if (s.length <= 10 && (ISO.test(s) || /^\d{1,2}[/.-]\d{1,2}[/.-]\d{4}$/.test(s))) return dateOf(s, field);
  const d = /* @__PURE__ */ new Date(s.replace(" ", "T") + (/[zZ]|[+-]\d{2}:?\d{2}$/.test(s) || s.length <= 10 ? "" : "Z"));
  if (Number.isNaN(d.getTime())) throw new Refused(`${field} is a date and time, like 2026-11-23T10:30:00Z (got "${s.slice(0, 30)}").`, 400, { code: "BAD_DATE" });
  return stamp(d);
}
var daysBetween = (from, to) => Math.round((Date.parse(String(to).slice(0, 10) + "T00:00:00Z") - Date.parse(String(from).slice(0, 10) + "T00:00:00Z")) / 864e5);
var text = (v, max = 4e3) => v === void 0 || v === null ? null : String(v).trim().slice(0, max) || null;
function int(v, field = "number") {
  if (v === void 0 || v === null || v === "") return null;
  const n = Number(v);
  if (!Number.isFinite(n)) throw new Refused(`${field} is a number (got "${String(v).slice(0, 30)}").`, 400, { code: "BAD_NUMBER" });
  return Math.round(n);
}
function euros(v, field = "amount") {
  if (v === void 0 || v === null || v === "") return null;
  const n = Number(typeof v === "string" ? v.replace(/\s|€|eur/gi, "").replace(/\.(?=\d{3}(\D|$))/g, "").replace(",", ".") : v);
  if (!Number.isFinite(n) || n < 0) throw new Refused(`${field} is an amount in euros, a number of 0 or more (got "${String(v).slice(0, 30)}").`, 400, { code: "BAD_NUMBER" });
  return Math.round(n * 100) / 100;
}
function listOf(v, name) {
  if (Array.isArray(v)) return v;
  if (typeof v === "string" && v.trim().startsWith("[")) {
    try {
      const j = JSON.parse(v);
      if (Array.isArray(j)) return j;
    } catch {
    }
  }
  throw new Refused(`${name} is a list: ${name}: [ \u2026 ].`, 400, { code: "BAD_INPUT" });
}
var said = (v) => String(v ?? "").trim().toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/[_-]+/g, " ").replace(/\s+/g, " ");
var fold = said;
function choiceOf(v, words, field) {
  if (v === void 0 || v === null || v === "") return null;
  const k = said(v);
  for (const [key, list4] of Object.entries(words)) if (said(key) === k || list4.includes(k)) return key;
  throw new Refused(`${field} is one of: ${Object.keys(words).join(", ")} (got "${String(v).slice(0, 30)}").`, 400, { code: "BAD_CHOICE" });
}
function onlyKnown(item, known, command2, elsewhere = {}) {
  const extra = Object.keys(item ?? {}).filter((k) => !known.includes(k) && item[k] !== void 0);
  if (!extra.length) return;
  const said2 = extra.map((k) => elsewhere[k] ? `${k} (${elsewhere[k]})` : k);
  throw new Refused(`${command2} does not take ${said2.join(", ")}: nothing was saved for this item. ${command2} takes: ${known.join(", ")}.`, 400, { code: "UNKNOWN_FIELD", fields: extra });
}
var sent = (o) => Object.fromEntries(Object.entries(o).filter(([, v]) => v !== void 0));
var count = async (db, sql, params = []) => Number((await db.one(sql, params))?.n ?? 0);
var r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
var idOf = (v) => v === void 0 || v === null || v === "" ? null : Number.isFinite(Number(v)) ? Number(v) : null;

// server/services/core.mjs
var DEFAULT_STAGES = [
  { name: "Nuevo", probability: 10 },
  { name: "Calificado", probability: 25 },
  { name: "Reuni\xF3n", probability: 40 },
  { name: "Propuesta", probability: 60 },
  { name: "Negociaci\xF3n", probability: 80 },
  { name: "Ganado", probability: 100, outcome: "won" },
  { name: "Perdido", probability: 0, outcome: "lost" }
];
var LEGACY_STAGE_NAMES = { Lead: "Nuevo", Qualified: "Calificado", Meeting: "Reuni\xF3n", Proposal: "Propuesta", Negotiation: "Negociaci\xF3n", Won: "Ganado", Lost: "Perdido" };
var DEFAULT_KINDS = ["Consultor\xEDa", "Desarrollo"];
var DEFAULT_SOURCES = ["Web", "Formulario", "Reserva", "Recomendaci\xF3n", "Correo", "Evento", "Prospecci\xF3n"];
var RECURRING = { month: ["mes", "mensual", "monthly", "mo"], quarter: ["trimestre", "trimestral", "quarterly"], year: ["ano", "anual", "yearly", "annual"] };
var monthly = (amount, every) => !amount ? 0 : every === "year" ? amount / 12 : every === "quarter" ? amount / 3 : amount;
function stagesOf(value) {
  let list4 = value;
  if (typeof value === "string") {
    const s = value.trim();
    if (s.startsWith("[")) {
      try {
        list4 = JSON.parse(s);
      } catch {
        list4 = null;
      }
    } else if (s) list4 = linesToStages(s);
    else list4 = null;
  }
  if (!Array.isArray(list4) || !list4.length) list4 = DEFAULT_STAGES;
  const out = list4.filter((s) => s && String(s.name ?? "").trim()).map((s, i) => ({
    name: String(s.name).trim().slice(0, 40),
    probability: Math.max(0, Math.min(100, Math.round(Number(s.probability) || 0))),
    order: Number.isFinite(Number(s.order)) ? Number(s.order) : i + 1,
    outcome: s.outcome === "won" || s.outcome === "lost" ? s.outcome : null
  })).sort((a, b) => a.order - b.order);
  if (!out.some((s) => s.outcome === "won")) out.push({ name: "Ganado", probability: 100, order: 98, outcome: "won" });
  if (!out.some((s) => s.outcome === "lost")) out.push({ name: "Perdido", probability: 0, order: 99, outcome: "lost" });
  return out.map((s, i) => ({ ...s, order: i + 1 }));
}
function linesToStages(s) {
  return s.split(/\n+/).map((l) => l.trim()).filter(Boolean).map((l) => {
    const m = /^(.*?)(?:\s*[·:-]?\s*(\d{1,3})\s*%?)?(?:\s*[·:-]?\s*\(?(ganado|perdido|won|lost)\)?)?\s*$/i.exec(l);
    const o = (m[3] || "").toLowerCase();
    return { name: m[1].trim() || l, probability: m[2] !== void 0 ? Number(m[2]) : o === "ganado" || o === "won" ? 100 : 0, outcome: o === "ganado" || o === "won" ? "won" : o === "perdido" || o === "lost" ? "lost" : null };
  });
}
var openStages = (stages) => stagesOf(stages).filter((s) => !s.outcome);
var outcomeStage = (stages, kind) => stagesOf(stages).find((s) => s.outcome === kind);
var stageNamed = (stages, name) => stagesOf(stages).find((s) => fold(s.name) === fold(name)) ?? null;
var linesOf = (v) => (Array.isArray(v) ? v : String(v ?? "").split(/\n/.test(String(v ?? "")) ? /\n+/ : /,+/)).map((x) => String(x).trim()).filter(Boolean);
var stagesRows = (stages) => stagesOf(stages).map((s) => ({ name: s.name, probability: s.probability, outcome: s.outcome ?? "none" }));
var FREE = /* @__PURE__ */ new Set(["gmail.com", "googlemail.com", "hotmail.com", "hotmail.es", "outlook.com", "outlook.es", "live.com", "msn.com", "yahoo.com", "yahoo.es", "ymail.com", "icloud.com", "me.com", "mac.com", "aol.com", "proton.me", "protonmail.com", "gmx.com", "gmx.es", "mail.com", "zoho.com", "yandex.com", "telefonica.net", "movistar.es", "orange.es", "hey.com", "fastmail.com", "pm.me"]);
var EMAIL = /^[^\s@<>(),;:"]+@[^\s@<>(),;:"]+\.[a-z]{2,}$/i;
var normEmail = (v) => String(v ?? "").trim().toLowerCase();
var isEmail = (v) => EMAIL.test(normEmail(v));
var domainOf = (email) => isEmail(email) ? normEmail(email).split("@")[1] : "";
var isFree = (domain) => FREE.has(String(domain ?? "").toLowerCase());
function siteDomain(v) {
  const s = String(v ?? "").trim().toLowerCase();
  if (!s) return "";
  const host = s.replace(/^[a-z]+:\/\//, "").split(/[/?#]/)[0].replace(/^www\./, "");
  return /^[a-z0-9.-]+\.[a-z]{2,}$/.test(host) ? host : "";
}
var companyDomainOf = (email) => {
  const d = domainOf(email);
  return d && !isFree(d) ? d : "";
};
var DEFAULTS = { stages: JSON.stringify(DEFAULT_STAGES), kinds: DEFAULT_KINDS.join("\n"), categories: "", sources: DEFAULT_SOURCES.join("\n"), currency: "EUR", timezone: "Europe/Madrid", stuck_days: 14, quiet_days: 90, renewal_days: 30, former_months: 12, signature: "" };
async function settingsRow(db) {
  const row2 = await db.one(`SELECT * FROM ${T.settings} WHERE _deleted = 0 ORDER BY _id LIMIT 1`);
  const v = (k) => row2 && row2[k] !== null && row2[k] !== void 0 && row2[k] !== "" ? row2[k] : DEFAULTS[k];
  return {
    id: row2?._id ?? null,
    row: row2,
    stages: stagesOf(v("stages")),
    kinds: linesOf(v("kinds")),
    categories: linesOf(v("categories")),
    sources: linesOf(v("sources")),
    currency: v("currency"),
    timezone: v("timezone"),
    stuck_days: Math.max(1, Number(v("stuck_days")) || 14),
    signature: v("signature") || "",
    quiet_days: Math.max(1, Number(v("quiet_days")) || 90),
    renewal_days: Math.max(1, Number(v("renewal_days")) || 30),
    former_months: Math.max(1, Number(v("former_months")) || 12)
  };
}
async function settings(db) {
  const s = await settingsRow(db);
  return { id: s.id, stages: stagesRows(s.stages), categories: s.categories, sources: s.sources, currency: s.currency, stuck_days: s.stuck_days, quiet_days: s.quiet_days, renewal_days: s.renewal_days, former_months: s.former_months, signature: s.signature };
}
async function setSettings(db, i) {
  const d = sent({
    stages: i.stages === void 0 ? void 0 : JSON.stringify(stagesOf(Array.isArray(i.stages) ? i.stages : String(i.stages))),
    kinds: i.kinds === void 0 ? void 0 : linesOf(i.kinds).join("\n"),
    categories: i.categories === void 0 ? void 0 : linesOf(i.categories).join("\n"),
    quiet_days: i.quiet_days === void 0 ? void 0 : int(i.quiet_days, "quiet_days"),
    renewal_days: i.renewal_days === void 0 ? void 0 : int(i.renewal_days, "renewal_days"),
    former_months: i.former_months === void 0 ? void 0 : int(i.former_months, "former_months"),
    sources: i.sources === void 0 ? void 0 : linesOf(i.sources).join("\n"),
    currency: i.currency === void 0 ? void 0 : (text(i.currency, 3) || "EUR").toUpperCase(),
    stuck_days: i.stuck_days === void 0 ? void 0 : int(i.stuck_days, "stuck_days"),
    signature: i.signature === void 0 ? void 0 : text(i.signature, 1e3) ?? ""
  });
  if (d.stages && !openStages(d.stages).length) throw new Refused("The stages need at least one that is not an outcome (ganado / perdido): a deal has to be somewhere while it is open.", 400, { code: "NO_OPEN_STAGE" });
  if (d.stuck_days !== void 0 && (d.stuck_days < 1 || d.stuck_days > 365)) throw new Refused("stuck_days is between 1 and 365: the days without news after which an open deal reads \xABparado\xBB.", 400, { code: "BAD_NUMBER" });
  for (const [k, lo, hi, what] of [["quiet_days", 7, 365, "the days without contact after which a customer reads \xABen riesgo\xBB"], ["renewal_days", 1, 180, "the days before a renewal or an end that put a customer \xABen riesgo\xBB"], ["former_months", 1, 60, "the months after which someone who bought once is a former customer"]]) if (d[k] !== void 0 && (d[k] < lo || d[k] > hi)) throw new Refused(`${k} is between ${lo} and ${hi}: ${what}.`, 400, { code: "BAD_NUMBER" });
  if (d.stages) await renameStages(db, (await settingsRow(db)).stages, stagesOf(d.stages));
  const row2 = await db.one(`SELECT _id FROM ${T.settings} WHERE _deleted = 0 ORDER BY _id LIMIT 1`);
  if (row2) {
    if (Object.keys(d).length) await db.update(T.settings, row2._id, d);
  } else await db.insert(T.settings, { ...DEFAULTS, ...d });
  return settings(db);
}
async function renameStages(db, before, after) {
  const names = new Set(after.map((s) => s.name));
  const firstOpen = after.find((s) => !s.outcome)?.name;
  for (const [k, s] of before.entries()) {
    if (names.has(s.name)) continue;
    const same = after[k] && !names.has(before[k]?.name) && after[k].outcome === s.outcome ? after[k].name : s.outcome ? after.find((x) => x.outcome === s.outcome)?.name : firstOpen;
    if (!same) continue;
    for (const d of await db.all(`SELECT _id FROM ${T.deals} WHERE ${LIVE} AND stage = ?`, [s.name])) await db.update(T.deals, d._id, { stage: same });
  }
}

// server/services/lifecycle.mjs
var EVERY_MONTHS = { month: 1, quarter: 3, year: 12 };
var STAGES = { lead: "Lead", talking: "En conversaci\xF3n", customer: "Cliente", former: "Antiguo cliente" };
var STAGE_WORDS = { lead: ["lead", "potencial", "prospect"], talking: ["en conversacion", "conversacion", "talking", "opportunity"], customer: ["cliente", "customer"], former: ["antiguo cliente", "antiguo", "former", "churned", "ex cliente"] };
var r22 = (n) => Math.round((Number(n) || 0) * 100) / 100;
var fmt = /* @__PURE__ */ new Map();
function money(n, currency = "EUR") {
  const c = /^[A-Z]{3}$/.test(String(currency ?? "")) ? currency : "EUR";
  if (!fmt.has(c)) fmt.set(c, new Intl.NumberFormat("es-ES", { style: "currency", currency: c, maximumFractionDigits: 2, minimumFractionDigits: 0 }));
  return fmt.get(c).format(Number(n) || 0).replace(/[\u00a0\u202f]/g, " ");
}
var PER = { month: "mes", quarter: "trimestre", year: "a\xF1o" };
var lineTotal = (l) => r22((l.quantity === null || l.quantity === void 0 || l.quantity === "" ? 1 : Number(l.quantity)) * (Number(l.price) || 0) * (1 - Math.min(100, Math.max(0, Number(l.discount) || 0)) / 100));
function valueOf(lines) {
  const v = { once: 0, per: {}, monthly: 0 };
  for (const l of lines || []) {
    if (l.removed) continue;
    const t = lineTotal(l);
    if (l.kind === "recurring") {
      const e = EVERY_MONTHS[l.every] ? l.every : "month";
      v.per[e] = r22((v.per[e] || 0) + t);
      v.monthly = r22(v.monthly + t / EVERY_MONTHS[e]);
    } else v.once = r22(v.once + t);
  }
  return v;
}
function valueText(v, currency = "EUR") {
  const parts = [];
  if (v.once) parts.push(`${money(v.once, currency)}${Object.keys(v.per || {}).length ? " una vez" : ""}`);
  for (const e of ["month", "quarter", "year"]) if (v.per?.[e] !== void 0) parts.push(`${money(v.per[e], currency)}/${PER[e]}`);
  return parts.join(" + ") || "Sin importe";
}
function dealColumns(lines) {
  const v = valueOf(lines);
  const rhythms = Object.keys(v.per);
  return rhythms.length === 0 ? { amount: v.once || null, recurring_amount: null, recurring_every: null } : rhythms.length === 1 ? { amount: v.once || null, recurring_amount: v.per[rhythms[0]], recurring_every: rhythms[0] } : { amount: v.once || null, recurring_amount: v.monthly, recurring_every: "month" };
}
var addMonths = (day, n) => {
  const [y, m, d] = String(day).slice(0, 10).split("-").map(Number);
  const t = y * 12 + (m - 1) + n;
  const ny = Math.floor(t / 12);
  const nm = t - ny * 12;
  const last = new Date(Date.UTC(ny, nm + 1, 0)).getUTCDate();
  return `${ny}-${String(nm + 1).padStart(2, "0")}-${String(Math.min(d, last)).padStart(2, "0")}`;
};
var days = (from, to) => Math.round((Date.parse(String(to).slice(0, 10) + "T00:00:00Z") - Date.parse(String(from).slice(0, 10) + "T00:00:00Z")) / 864e5);
function serviceState(s, today3) {
  const start = s.start ? String(s.start).slice(0, 10) : null;
  const min = Number(s.min_months) > 0 ? Number(s.min_months) : 0;
  const minUntil = start && min ? addMonths(start, min) : null;
  let ends = s.end_on ? String(s.end_on).slice(0, 10) : null;
  if (!ends && s.renewal === "none" && minUntil) ends = minUntil;
  if (ends && ends < today3) return { state: "ended", ends, min_until: minUntil };
  if (start && start > today3) return { state: "upcoming", ends, min_until: minUntil };
  let next = null;
  if (!ends && start && (s.renewal === "auto" || s.renewal === "manual")) {
    const term = min || 12;
    let k = 1;
    for (next = addMonths(start, term); next <= today3 && k < 600; k += 1) next = addMonths(start, term * (k + 1));
  }
  return { state: ends ? "ending" : "active", ends, min_until: minUntil, next_renewal: next };
}
var serviceMonthly = (s) => r22((Number(s.amount) || 0) / (EVERY_MONTHS[s.every] || 1));
function lifecycleOf({ manual = null, manualAt = null, deals = [], services: services2 = [] }, today3, formerMonths = 12) {
  const live = services2.map((s) => ({ ...s, st: serviceState(s, today3) }));
  const running = live.filter((s) => s.st.state !== "ended");
  const won = deals.filter((d) => d.status === "Won").sort((a, b) => String(b.closed_at || "").localeCompare(String(a.closed_at || "")));
  const open = deals.filter((d) => d.status === "Open");
  const recentFrom = addMonths(today3, -Math.max(1, Number(formerMonths) || 12));
  const stamps = [...deals.flatMap((d) => [d.created_at, d.closed_at]), ...services2.flatMap((s) => [s.start, s.end_on && String(s.end_on).slice(0, 10) <= today3 ? s.end_on : null])].filter(Boolean).map((x) => String(x).slice(0, 19)).sort();
  const last = stamps.pop() || null;
  let facts2;
  if (running.length) facts2 = { stage: "customer", reason: running.length === 1 ? `Tiene ${running[0].name || "un servicio"}${running[0].start ? ` desde ${short(running[0].start)}` : ""}` : `Tiene ${running.length} servicios en curso` };
  else if (won.length && String(won[0].closed_at || "").slice(0, 10) >= recentFrom) facts2 = { stage: "customer", reason: `Compr\xF3 \xAB${won[0].title || "un negocio"}\xBB ${won[0].closed_at ? `el ${short(won[0].closed_at)}` : ""}`.trim() };
  else if (open.length) facts2 = { stage: "talking", reason: open.length === 1 ? `Venta en curso: \xAB${open[0].title || ""}\xBB` : `${open.length} ventas en curso` };
  else if (won.length || live.length) {
    const ended = live.filter((s) => s.st.ends).sort((a, b) => b.st.ends.localeCompare(a.st.ends))[0];
    facts2 = { stage: "former", reason: ended ? `${ended.name || "Su servicio"} termin\xF3 el ${short(ended.st.ends)}` : `Su \xFAltima compra fue el ${short(won[0].closed_at)}` };
  } else if (deals.length) facts2 = { stage: "lead", reason: "Nunca ha comprado: sus ventas se perdieron" };
  else facts2 = { stage: "lead", reason: "A\xFAn no hay ventas con esta empresa" };
  if (manual && STAGES[manual] && (!last || !manualAt || String(manualAt).slice(0, 19) >= last)) return { stage: manual, reason: manual === facts2.stage ? facts2.reason : "Puesta a mano", by: "person", since: manualAt, facts: facts2.stage };
  return { ...facts2, by: "facts", since: last };
}
var MES = ["ene", "feb", "mar", "abr", "may", "jun", "jul", "ago", "sep", "oct", "nov", "dic"];
var short = (d) => {
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(String(d ?? ""));
  return m ? `${Number(m[3])} ${MES[Number(m[2]) - 1]} ${m[1]}` : "";
};
function risksOf({ stage, lastContact = null, overdue = [], services: services2 = [], concern = null }, today3, { quietDays = 60, renewalDays = 30 } = {}) {
  if (stage !== "customer") return [];
  const out = [];
  if (concern) out.push({ kind: "concern", text: `Queja: ${concern}` });
  for (const x of overdue) out.push({ kind: "overdue", ref: x.id, text: `Factura ${x.number || ""} vencida${x.due_date ? ` desde el ${short(x.due_date)}` : ""}`.replace("  ", " ") });
  for (const s of services2) {
    const st = s.st ?? serviceState(s, today3);
    if (st.state === "ending" && days(today3, st.ends) <= renewalDays) out.push({ kind: "ends", ref: s.id, text: `${s.name || "Un servicio"} termina el ${short(st.ends)}` });
    else if (st.next_renewal && days(today3, st.next_renewal) <= renewalDays) out.push({ kind: "renews", ref: s.id, text: `${s.name || "Un servicio"} se renueva${s.renewal === "manual" ? " (a mano)" : ""} el ${short(st.next_renewal)}` });
  }
  if (!lastContact || days(lastContact, today3) >= quietDays) out.push({ kind: "quiet", text: lastContact ? `Sin contacto desde hace ${days(lastContact, today3)} d\xEDas` : "Sin ning\xFAn contacto registrado" });
  return out;
}

// server/services/catalog.mjs
var KIND = { once: ["una vez", "one time", "one-time", "puntual", "unico", "pago unico"], recurring: ["recurrente", "recurring", "cuota", "suscripcion", "subscription"] };
var EVERY = { month: ["mes", "mensual", "monthly", "mo", "mensualmente"], quarter: ["trimestre", "trimestral", "quarterly"], year: ["ano", "anual", "yearly", "annual"] };
var RENEWAL = { auto: ["automatica", "automatic", "auto", "si"], manual: ["a mano", "manual"], none: ["no", "ninguna", "no se renueva", "never"] };
var BILL_IN = { advance: ["adelantado", "por adelantado", "in advance"], arrears: ["vencido", "a periodo vencido", "in arrears", "a mes vencido", "a trimestre vencido"] };
var ITEM_FIELDS = ["id", "name", "category", "description", "kind", "every", "price", "min_months", "renewal", "bill_every", "bill_in", "archived"];
var ITEM_ELSEWHERE = { remove: "archived: true (an item is archived, never deleted)", type: "kind (once | recurring)", rhythm: "every", period: "every", amount: "price", minimum_term: "min_months" };
var itemRow = (r) => sent({ id: r._id, name: r.name, category: r.category || void 0, description: r.description || void 0, kind: r.kind || "once", every: r.kind === "recurring" ? r.every || "month" : void 0, price: r.price ?? void 0, min_months: r.min_months || void 0, renewal: r.kind === "recurring" ? r.renewal || "auto" : void 0, bill_every: r.kind === "recurring" ? r.bill_every || r.every || "month" : void 0, bill_in: r.kind === "recurring" ? r.bill_in || "advance" : void 0, archived: Number(r.archived) ? true : void 0 });
async function items(db, i, full, now) {
  const s = await settingsRow(db);
  const q = fold(i.q ?? "").trim();
  const archived = i.archived === true || i.archived === "true";
  let rows2 = await db.all(`SELECT * FROM ${T.items} WHERE _deleted = 0 ${archived ? "" : "AND COALESCE(archived,0) = 0"} ORDER BY category COLLATE NOCASE, name COLLATE NOCASE`);
  if (q && q !== "null") rows2 = rows2.filter((r) => fold(`${r.name} ${r.category ?? ""} ${r.description ?? ""}`).includes(q));
  const list4 = rows2.map(itemRow);
  if (!full) return { total: list4.length, rows: list4.slice(0, Math.min(Number(i.limit) || 40, 200)).map(({ description, ...r }) => r), categories: s.categories };
  const day = today(now, s.timezone);
  const svc = await db.all(`SELECT item_id, company_id, amount, every, start, end_on, renewal, min_months FROM ${T.services} WHERE _deleted = 0 AND COALESCE(removed,0) = 0 AND item_id IS NOT NULL`);
  const use = /* @__PURE__ */ new Map();
  for (const x of svc) {
    if (serviceState(x, day).state === "ended") continue;
    const u = use.get(x.item_id) ?? { customers: /* @__PURE__ */ new Set(), monthly: 0 };
    u.customers.add(x.company_id);
    u.monthly = Math.round((u.monthly + serviceMonthly(x)) * 100) / 100;
    use.set(x.item_id, u);
  }
  return { total: list4.length, categories: s.categories, currency: s.currency, rows: list4.map((r) => {
    const u = use.get(r.id);
    return u ? { ...r, customers: u.customers.size, monthly: u.monthly } : r;
  }) };
}
async function itemRef(db, v, { archivedOk = false } = {}) {
  if (v === void 0 || v === null || v === "") return null;
  const id = idOf(v);
  const all = await db.all(`SELECT * FROM ${T.items} WHERE _deleted = 0`);
  const hit = id ? all.find((r) => r._id === id) : all.find((r) => fold(r.name) === fold(v)) ?? (() => {
    const m = all.filter((r) => !Number(r.archived) && fold(r.name).includes(fold(v)));
    return m.length === 1 ? m[0] : null;
  })();
  if (!hit) throw new Refused(`\xAB${String(v).slice(0, 60)}\xBB is not in \xABServicios y productos\xBB. It has: ${all.filter((r) => !Number(r.archived)).map((r) => r.name).join(", ") || "nothing yet"}. Add it first with items_save, or use one of these.`, 400, { code: "NO_ITEM" });
  if (Number(hit.archived) && !archivedOk) throw new Refused(`\xAB${hit.name}\xBB is archived: it is not sold any more. Restore it (items_save { id: ${hit._id}, archived: false }) or use another.`, 409, { code: "ARCHIVED", item: hit._id });
  return hit;
}
async function saveItems(db, i) {
  const out = { added: [], changed: [], skipped: [] };
  for (const [k, item] of listOf(i.items, "items").entries()) {
    try {
      onlyKnown(item, ITEM_FIELDS, "items_save", ITEM_ELSEWHERE);
      const data = sent({
        name: item.name === void 0 ? void 0 : text(item.name, 120),
        category: item.category === void 0 ? void 0 : text(item.category, 60),
        description: item.description === void 0 ? void 0 : text(item.description, 2e3),
        kind: item.kind === void 0 ? void 0 : choiceOf(item.kind, KIND, "kind"),
        every: item.every === void 0 ? void 0 : choiceOf(item.every, EVERY, "every"),
        price: item.price === void 0 ? void 0 : euros(item.price, "price"),
        min_months: item.min_months === void 0 ? void 0 : item.min_months === null || item.min_months === "" ? null : Math.max(0, Math.round(Number(item.min_months) || 0)) || null,
        renewal: item.renewal === void 0 ? void 0 : choiceOf(item.renewal, RENEWAL, "renewal"),
        bill_every: item.bill_every === void 0 ? void 0 : choiceOf(item.bill_every, EVERY, "bill_every"),
        bill_in: item.bill_in === void 0 ? void 0 : choiceOf(item.bill_in, BILL_IN, "bill_in"),
        archived: item.archived === void 0 ? void 0 : item.archived === true || item.archived === "true" || item.archived === 1 ? 1 : 0
      });
      let id = idOf(item.id);
      if (!id && data.name) id = (await db.all(`SELECT _id, name FROM ${T.items} WHERE _deleted = 0`)).find((r) => fold(r.name) === fold(data.name))?._id ?? null;
      if (id) {
        const was = await db.one(`SELECT * FROM ${T.items} WHERE _deleted = 0 AND _id = ?`, [id]);
        if (!was) throw new Refused(`There is no item ${id}. items lists them.`, 404, { code: "NOT_FOUND", item: id });
        for (const f of Object.keys(data)) if (was[f] === data[f]) delete data[f];
        if (Object.keys(data).length) await db.update(T.items, id, data);
        out.changed.push(id);
      } else {
        if (!data.name) throw new Refused("A new item needs its name: \xABMantenimiento web\xBB, \xABAuditor\xEDa\xBB.", 400, { code: "BAD_INPUT" });
        const kind = data.kind ?? "once";
        out.added.push(await db.insert(T.items, { kind, ...kind === "recurring" ? { every: "month", renewal: "auto" } : {}, archived: 0, ...data }));
      }
    } catch (e) {
      if (!(e instanceof Refused)) throw e;
      out.skipped.push({ index: k, code: e.code, error: e.message, ...e.item !== void 0 ? { item: e.item } : {} });
    }
  }
  return out;
}
async function linesOf2(db, dealIds) {
  const ids = [].concat(dealIds).filter(Boolean);
  if (!ids.length) return /* @__PURE__ */ new Map();
  const rows2 = await db.all(`SELECT l.*, i.name AS item, i.category FROM ${T.lines} l LEFT JOIN ${T.items} i ON i._id = l.item_id WHERE l._deleted = 0 AND COALESCE(l.removed,0) = 0 AND l.deal_id IN (${ids.map(() => "?").join(",")}) ORDER BY l.deal_id, l.position, l._id`, ids);
  const out = new Map(ids.map((x) => [x, []]));
  for (const l of rows2) out.get(l.deal_id)?.push(lineRow(l));
  return out;
}
var lineRow = (l) => sent({ id: l._id, item_id: l.item_id ?? void 0, item: l.item ?? void 0, category: l.category ?? void 0, name: l.name || l.item || void 0, quantity: l.quantity ?? 1, price: l.price ?? 0, discount: l.discount || void 0, kind: l.kind || "once", every: l.kind === "recurring" ? l.every || "month" : void 0, start: l.start || void 0, total: lineTotal(l) });
var valueOfLines = (lines, currency) => {
  const v = valueOf(lines);
  return { ...v, text: valueText(v, currency) };
};
var LINE_FIELDS = ["id", "item", "item_id", "name", "quantity", "price", "discount", "kind", "every", "start"];
async function cleanLines(db, list4) {
  const out = [];
  for (const [k, raw2] of listOf(list4, "lines").entries()) {
    if (!raw2 || typeof raw2 !== "object") throw new Refused(`Line ${k + 1} is { item, quantity, price, discount, every, start }.`, 400, { code: "BAD_LINES" });
    onlyKnown(raw2, LINE_FIELDS, "lines", { description: "name", qty: "quantity", disc: "discount", unit_price: "price", rhythm: "every" });
    const it = await itemRef(db, raw2.item_id ?? raw2.item, { archivedOk: !!raw2.id });
    if (!it) throw new Refused(`Line ${k + 1} says what it sells: item (a name of \xABServicios y productos\xBB) or item_id. Add it first with items_save when it is new.`, 400, { code: "NO_ITEM" });
    const kind = raw2.kind === void 0 ? it.kind || "once" : choiceOf(raw2.kind, KIND, `line ${k + 1} kind`);
    const qty = raw2.quantity === void 0 || raw2.quantity === null || raw2.quantity === "" ? 1 : Number(String(raw2.quantity).replace(",", "."));
    if (!Number.isFinite(qty) || qty <= 0) throw new Refused(`Line ${k + 1}: quantity is a number above 0.`, 400, { code: "BAD_LINES" });
    const price = raw2.price === void 0 || raw2.price === null || raw2.price === "" ? it.price ?? null : euros(raw2.price, `line ${k + 1} price`);
    if (price === null) throw new Refused(`Line ${k + 1} (\xAB${it.name}\xBB) has no price, and the item has none by default: say it (price).`, 400, { code: "NO_PRICE" });
    const discount = raw2.discount === void 0 || raw2.discount === null || raw2.discount === "" ? 0 : Number(String(raw2.discount).replace(",", ".").replace("%", ""));
    if (!Number.isFinite(discount) || discount < 0 || discount > 100) throw new Refused(`Line ${k + 1}: discount is a percent from 0 to 100.`, 400, { code: "BAD_LINES" });
    out.push({ id: idOf(raw2.id), item_id: it._id, name: text(raw2.name, 200) || null, quantity: qty, price, discount: discount || null, kind, every: kind === "recurring" ? choiceOf(raw2.every ?? it.every ?? "month", EVERY, `line ${k + 1} every`) : null, start: kind === "recurring" ? dateOf(raw2.start, `line ${k + 1} start`) : null, position: k + 1 });
  }
  return out;
}
async function writeLines(db, dealId, rows2) {
  const was = await db.all(`SELECT * FROM ${T.lines} WHERE _deleted = 0 AND COALESCE(removed,0) = 0 AND deal_id = ?`, [dealId]);
  let changed = false;
  const kept = /* @__PURE__ */ new Set();
  for (const r of rows2) {
    const { id, ...data } = r;
    const old = id ? was.find((x) => x._id === id) : null;
    if (old) {
      kept.add(old._id);
      const diff = Object.fromEntries(Object.entries(data).filter(([k2, v]) => (old[k2] ?? null) !== (v ?? null)));
      if (Object.keys(diff).length) {
        await db.update(T.lines, old._id, diff);
        changed = true;
      }
    } else {
      await db.insert(T.lines, { deal_id: dealId, ...data, removed: 0 });
      changed = true;
    }
  }
  for (const x of was) if (!kept.has(x._id)) {
    await db.update(T.lines, x._id, { removed: 1 });
    changed = true;
  }
  if (changed) await db.update(T.deals, dealId, dealColumns(rows2));
  return changed;
}
async function serviceRows(db, where, args, day) {
  const rows2 = await db.all(`SELECT s.*, c.name AS company, i.name AS item, i.category, i.bill_every, i.bill_in FROM ${T.services} s LEFT JOIN ${T.companies} c ON c._id = s.company_id LEFT JOIN ${T.items} i ON i._id = s.item_id WHERE s._deleted = 0 AND COALESCE(s.removed,0) = 0 ${where ? "AND " + where : ""} ORDER BY s.start DESC, s._id DESC`, args);
  return rows2.map((s) => {
    const st = serviceState(s, day);
    return sent({ id: s._id, name: s.name, company_id: s.company_id, company: s.company ?? void 0, item_id: s.item_id ?? void 0, item: s.item ?? void 0, category: s.category ?? void 0, deal_id: s.deal_id ?? void 0, quantity: s.quantity ?? 1, price: s.price ?? void 0, discount: s.discount || void 0, amount: s.amount ?? 0, every: s.every || "month", monthly: st.state === "ended" ? 0 : serviceMonthly(s), start: s.start ?? void 0, min_months: s.min_months || void 0, renewal: s.renewal || void 0, end_on: s.end_on ?? void 0, end_reason: s.end_reason ?? void 0, bill_every: s.bill_every || s.every || void 0, bill_in: s.bill_in || void 0, notes: s.notes || void 0, state: st.state, ends: st.ends ?? void 0, min_until: st.min_until ?? void 0, next_renewal: st.next_renewal ?? void 0, line_id: s.line_id ?? void 0 });
  });
}
async function services(db, i, full, now) {
  const s = await settingsRow(db);
  const day = today(now, s.timezone);
  const where = [];
  const args = [];
  if (i.company_id) {
    where.push("s.company_id = ?");
    args.push(idOf(i.company_id));
  }
  if (i.deal_id) {
    where.push("s.deal_id = ?");
    args.push(idOf(i.deal_id));
  }
  let rows2 = await serviceRows(db, where.join(" AND "), args, day);
  const state = i.state ?? "active";
  if (state === "active") rows2 = rows2.filter((x) => x.state !== "ended");
  else if (state === "ended") rows2 = rows2.filter((x) => x.state === "ended");
  const monthly2 = Math.round(rows2.reduce((t, x) => t + (x.monthly || 0), 0) * 100) / 100;
  return { total: rows2.length, monthly: monthly2, currency: s.currency, rows: full ? rows2 : rows2.slice(0, Math.min(Number(i.limit) || 20, 100)).map(({ id, name, company, amount, every, start, state: st, ends, next_renewal }) => sent({ id, name, company, amount, every, start, state: st, ends, next_renewal })) };
}
var SERVICE_FIELDS = ["id", "company", "company_id", "item", "item_id", "deal_id", "name", "quantity", "price", "discount", "every", "start", "min_months", "renewal", "end_on", "end_reason", "notes", "remove"];
async function saveServices(db, i, companyRef2) {
  const out = { added: [], changed: [], skipped: [] };
  for (const [k, item] of listOf(i.items, "items").entries()) {
    try {
      onlyKnown(item, SERVICE_FIELDS, "services_save", { amount: "price (and quantity, discount)", until: "end_on", since: "start", state: "end_on (the day it ends or ended)" });
      const id = idOf(item.id);
      const was = id ? await db.one(`SELECT * FROM ${T.services} WHERE _deleted = 0 AND COALESCE(removed,0) = 0 AND _id = ?`, [id]) : null;
      if (id && !was) throw new Refused(`There is no contracted service ${id}. services lists them.`, 404, { code: "NOT_FOUND", item: id });
      if (was && item.remove === true) {
        await db.update(T.services, id, { removed: 1 });
        out.changed.push(id);
        continue;
      }
      const it = item.item_id !== void 0 || item.item !== void 0 ? await itemRef(db, item.item_id ?? item.item, { archivedOk: true }) : null;
      const data = sent({
        company_id: item.company_id !== void 0 || item.company !== void 0 ? await companyRef2(db, { company_id: item.company_id, company: item.company }, { make: false }) : void 0,
        item_id: it ? it._id : void 0,
        deal_id: item.deal_id === void 0 ? void 0 : idOf(item.deal_id),
        name: item.name !== void 0 ? text(item.name, 200) : it && !was ? it.name : void 0,
        quantity: item.quantity === void 0 ? void 0 : Number(item.quantity) || 1,
        price: item.price !== void 0 ? euros(item.price, "price") : it && !was ? it.price ?? void 0 : void 0,
        discount: item.discount === void 0 ? void 0 : Number(item.discount) || null,
        every: item.every !== void 0 ? choiceOf(item.every, EVERY, "every") : it && !was ? it.every || "month" : void 0,
        start: item.start === void 0 ? void 0 : dateOf(item.start, "start"),
        min_months: item.min_months !== void 0 ? Math.max(0, Math.round(Number(item.min_months) || 0)) || null : it && !was ? it.min_months ?? void 0 : void 0,
        renewal: item.renewal !== void 0 ? choiceOf(item.renewal, RENEWAL, "renewal") : it && !was ? it.renewal || "auto" : void 0,
        end_on: item.end_on === void 0 ? void 0 : dateOf(item.end_on, "end_on"),
        end_reason: item.end_reason === void 0 ? void 0 : text(item.end_reason, 300),
        notes: item.notes === void 0 ? void 0 : text(item.notes, 2e3)
      });
      const merged = { ...was ?? {}, ...data };
      if (!merged.company_id) throw new Refused("A contracted service is a customer's: company_id or company (one already in the CRM).", 400, { code: "NO_CLIENT" });
      if (!merged.name) throw new Refused("Say what it is: item (from \xABServicios y productos\xBB) or name.", 400, { code: "BAD_INPUT" });
      if (merged.price === null || merged.price === void 0) throw new Refused("Say its price for each period (price).", 400, { code: "NO_PRICE" });
      data.amount = lineTotal({ quantity: merged.quantity ?? 1, price: merged.price, discount: merged.discount });
      if (was) {
        for (const f of Object.keys(data)) if ((was[f] ?? null) === (data[f] ?? null)) delete data[f];
        if (Object.keys(data).length) await db.update(T.services, id, data);
        out.changed.push(id);
      } else out.added.push(await db.insert(T.services, { quantity: 1, every: "month", renewal: "auto", removed: 0, ...data }));
    } catch (e) {
      if (!(e instanceof Refused)) throw e;
      out.skipped.push({ index: k, code: e.code, error: e.message, ...e.item !== void 0 ? { item: e.item } : {} });
    }
  }
  return out;
}
async function syncServices(db, dealId) {
  const d = await db.one(`SELECT _id, status, company_id, closed_at, recurring_until FROM ${T.deals} WHERE _deleted = 0 AND _id = ?`, [dealId]);
  if (!d) return { made: [], changed: [], removed: [] };
  const have = await db.all(`SELECT * FROM ${T.services} WHERE _deleted = 0 AND COALESCE(removed,0) = 0 AND deal_id = ?`, [dealId]);
  const out = { made: [], changed: [], removed: [] };
  const lines = d.status === "Won" ? await db.all(`SELECT l.*, i.name AS item, i.min_months AS i_min, i.renewal AS i_renewal FROM ${T.lines} l LEFT JOIN ${T.items} i ON i._id = l.item_id WHERE l._deleted = 0 AND COALESCE(l.removed,0) = 0 AND l.deal_id = ? AND l.kind = 'recurring'`, [dealId]) : [];
  for (const l of lines) {
    const amount = lineTotal(l);
    const s = have.find((x) => x.line_id === l._id);
    const want = { name: l.name || l.item, item_id: l.item_id, quantity: l.quantity ?? 1, price: l.price, discount: l.discount || null, amount, every: l.every || "month" };
    if (s) {
      const diff = Object.fromEntries(Object.entries(want).filter(([k, v]) => (s[k] ?? null) !== (v ?? null)));
      if (l.start && l.start !== s.start) diff.start = l.start;
      if (Object.keys(diff).length) {
        await db.update(T.services, s._id, diff);
        out.changed.push(s._id);
      }
    } else {
      out.made.push(await db.insert(T.services, { ...want, company_id: d.company_id, deal_id: d._id, line_id: l._id, start: l.start || d.closed_at || null, min_months: l.i_min ?? null, renewal: l.i_renewal || "auto", end_on: d.recurring_until || null, removed: 0 }));
    }
  }
  for (const s of have) if (!lines.some((l) => l._id === s.line_id) && s.line_id) {
    await db.update(T.services, s._id, { removed: 1 });
    out.removed.push(s._id);
  }
  return out;
}
async function endService(db, i, now) {
  const s = await db.one(`SELECT _id, start FROM ${T.services} WHERE _deleted = 0 AND COALESCE(removed,0) = 0 AND _id = ?`, [idOf(i.id)]);
  if (!s) throw new Refused(`There is no contracted service ${i.id}. services lists them.`, 404, { code: "NOT_FOUND" });
  const st = await settingsRow(db);
  const on = dateOf(i.end_on ?? i.on, "end_on") ?? today(now, st.timezone);
  if (s.start && on < s.start) throw new Refused(`end_on ${on} is before it started (${s.start}).`, 400, { code: "BAD_DATE", item: s._id });
  await db.update(T.services, s._id, { end_on: on, end_reason: text(i.reason, 300) });
  return { id: s._id, end_on: on };
}

// server/services/customers.mjs
async function invoicing(db) {
  const peers = await db.peers().catch(() => null);
  return peers ? peers.some((p) => p.module === "invoices" && p.installed) : null;
}
function billingFrom(groups, day) {
  const rows2 = (groups || []).filter((g) => g.module === "invoices");
  const docs = rows2.filter((g) => g.record !== "recurring").flatMap((g) => g.rows || []);
  const fees = rows2.filter((g) => g.record === "recurring").flatMap((g) => g.rows || []);
  const isInvoice = (x) => /invoice|factura/i.test(String(x.fields?.kind ?? ""));
  const unpaid = (x) => /^issued$|por cobrar/i.test(String(x.fields?.status ?? ""));
  const paid = (x) => /^paid$|cobrad/i.test(String(x.fields?.status ?? ""));
  const late = (x) => unpaid(x) && x.fields?.due_date && String(x.fields.due_date).slice(0, 10) < day;
  const sum2 = (list4) => Math.round(list4.reduce((t, x) => t + (Number(x.fields?.total) || 0), 0) * 100) / 100;
  const inv = docs.filter(isInvoice);
  return {
    billed: sum2(inv.filter((x) => unpaid(x) || paid(x))),
    owed: sum2(inv.filter(unpaid)),
    overdue: sum2(inv.filter(late)),
    overdue_count: inv.filter(late).length,
    documents: docs.map((x) => sent({ id: x.id, title: x.title, kind: x.fields?.kind, status: late(x) ? "Vencida" : x.fields?.status, number: x.fields?.number ?? void 0, total: x.fields?.total ?? void 0, due_date: x.fields?.due_date ?? void 0, open: x.open })),
    fees: fees.map((x) => sent({ id: x.id, title: x.title, every: x.fields?.every, state: x.fields?.state, open: x.open }))
  };
}
async function overdueOf(db, companyId, day) {
  const r = await db.referenced("company", companyId).catch(() => null);
  return (r?.groups || []).flatMap((g) => (g.rows || []).filter((x) => /invoice|factura/i.test(String(x.fields?.kind ?? "")) && /^issued$|por cobrar/i.test(String(x.fields?.status ?? "")) && x.fields?.due_date && String(x.fields.due_date).slice(0, 10) < day).map((x) => sent({ id: x.id, number: x.fields?.number || x.title, due_date: String(x.fields.due_date).slice(0, 10), total: x.fields?.total, open: x.open })));
}
async function facts(db, ids, now, { overdue = true } = {}) {
  const s = await settingsRow(db);
  const day = today(now, s.timezone);
  const where = ids ? `AND c._id IN (${ids.map(() => "?").join(",") || "NULL"})` : "";
  const companies2 = await db.all(`SELECT c._id, c.name, c.lifecycle, c.lifecycle_at, c.concern, c.concern_at FROM ${T.companies} c WHERE c._deleted = 0 AND COALESCE(c.removed,0) = 0 ${where}`, ids ?? []);
  if (!companies2.length) return /* @__PURE__ */ new Map();
  const list4 = companies2.map((c) => c._id);
  const ph = list4.map(() => "?").join(",");
  const deals = await db.all(`SELECT _id, company_id, title, status, _created_at AS created_at, closed_at FROM ${T.deals} WHERE ${LIVE} AND company_id IN (${ph})`, list4);
  const services2 = await serviceRows(db, `s.company_id IN (${ph})`, list4, day);
  const last = await db.all(`SELECT c._id AS id, (SELECT MAX(a.at) FROM ${T.activities} a WHERE a._deleted = 0 AND COALESCE(a.removed,0) = 0 AND a.type NOT IN ('stage','task') AND (a.company_id = c._id OR a.contact_id IN (SELECT p._id FROM ${T.contacts} p WHERE p.company_id = c._id) OR a.deal_id IN (SELECT d._id FROM ${T.deals} d WHERE d.company_id = c._id))) AS at FROM ${T.companies} c WHERE c._id IN (${ph})`, list4);
  const lastOf = new Map(last.map((r) => [r.id, r.at]));
  const reading = overdue && await invoicing(db) !== false;
  const out = /* @__PURE__ */ new Map();
  for (const c of companies2) {
    const mine = services2.filter((x) => x.company_id === c._id);
    const life = lifecycleOf({ manual: c.lifecycle, manualAt: c.lifecycle_at, deals: deals.filter((d) => d.company_id === c._id), services: mine.map((x) => ({ ...x, end_on: x.end_on })) }, day, s.former_months);
    const late = life.stage === "customer" && reading ? await overdueOf(db, c._id, day) : [];
    const risks = risksOf({ stage: life.stage, lastContact: lastOf.get(c._id) ? String(lastOf.get(c._id)).slice(0, 10) : null, overdue: late, services: mine, concern: c.concern }, day, s);
    const running = mine.filter((x) => x.state !== "ended");
    out.set(c._id, { stage: life.stage, stage_label: STAGES[life.stage], stage_reason: life.reason, stage_by: life.by, stage_facts: life.facts, monthly: Math.round(running.reduce((t, x) => t + (x.monthly || 0), 0) * 100) / 100, services: mine, risks, overdue: late, last_contact: lastOf.get(c._id) ?? null, concern: c.concern ?? null });
  }
  return out;
}
async function atRisk(db, now) {
  const f = await facts(db, null, now);
  const busy = new Set((await db.all(`SELECT DISTINCT company_id FROM ${T.tasks} WHERE _deleted = 0 AND company_id IS NOT NULL AND deal_id IS NULL AND status IN ('Suggested','Open')`)).map((r) => r.company_id));
  const names = new Map((await db.all(`SELECT _id, name FROM ${T.companies} WHERE _deleted = 0`)).map((r) => [r._id, r.name]));
  const items2 = [];
  for (const [id, x] of f) {
    if (!x.risks.length || busy.has(id)) continue;
    items2.push({ key: `risk:${id}:${x.risks.map((r) => r.kind + (r.ref ?? "")).sort().join("+")}`, text: `${names.get(id)}: ${x.risks.map((r) => r.text).join("; ")}`, company_id: id, reasons: x.risks.map((r) => r.kind) });
  }
  return { items: items2 };
}
function stageData(v, actor, now) {
  if (v === null || v === "" || v === "auto") return { lifecycle: null, lifecycle_at: null, lifecycle_by: null };
  return { lifecycle: v, lifecycle_at: stamp(now), lifecycle_by: String(actor || "").replace(/^(person|agent):/, "") || null };
}
var concernData = (v, now) => v === null || v === "" ? { concern: null, concern_at: null } : { concern: text(v, 300), concern_at: stamp(now) };

// server/services/people.mjs
var CONTACT_STATUS = { Lead: ["lead", "nuevo", "potencial"], Contacted: ["contacted", "contactado"], Customer: ["customer", "cliente"], Lost: ["lost", "perdido"], Suggested: ["suggested", "sugerido"], Ignored: ["ignored", "ignorado"] };
var COMPANY_FIELDS = ["name", "legal_name", "domain", "website", "industry", "size", "location", "linkedin", "summary", "tax_id", "address", "phone", "notes", "source", "owner"];
var CONTACT_FIELDS = ["name", "email", "phone", "title", "linkedin", "notes", "source", "owner"];
var COMPANY_SAVE = ["id", ...COMPANY_FIELDS, "main_contact_id", "stage", "concern", "remove"];
var CONTACT_SAVE = ["id", ...CONTACT_FIELDS, "status", "company", "company_id", "main", "remove"];
var ELSEWHERE = { archived: "say remove: true to archive, remove: false to restore", deleted: "say remove: true", deal: "deals_save", deals: "deals_save", next_step: "deals_save or next_step_set", timeline: "timeline_add", contact: "contacts_save", contacts: "contacts_save", email: "contacts_save (a person's email)" };
var LIVE_PERSON = `_deleted = 0 AND COALESCE(removed,0) = 0 AND COALESCE(status,'') NOT IN ('Suggested','Ignored')`;
async function ensureMainContact(db, companyId) {
  if (!companyId) return null;
  const c = await db.one(`SELECT _id, main_contact_id FROM ${T.companies} WHERE _deleted = 0 AND _id = ?`, [companyId]);
  if (!c) return null;
  const people = await db.all(`SELECT _id FROM ${T.contacts} WHERE ${LIVE_PERSON} AND company_id = ?`, [companyId]);
  if (c.main_contact_id && people.some((p) => p._id === c.main_contact_id)) return c.main_contact_id;
  const main = people.length === 1 ? people[0]._id : null;
  if ((c.main_contact_id ?? null) !== main) await db.update(T.companies, companyId, { main_contact_id: main });
  return main;
}
var taxKey = (v) => String(v ?? "").toUpperCase().replace(/[^A-Z0-9]/g, "").replace(/^ES(?=[A-Z0-9]{9}$)/, "");
async function matchCompany(db, i) {
  const tax = taxKey(i.tax_id);
  const name = text(i.company ?? i.company_name ?? i.name, 200);
  const domain = siteDomain(i.website ?? i.domain) || companyDomainOf(i.email);
  const rows2 = await db.all(`SELECT _id, name, tax_id, domain FROM ${T.companies} WHERE ${LIVE}`);
  if (tax) {
    const r = rows2.find((c) => taxKey(c.tax_id) === tax);
    if (r) return { id: r._id, by: "tax_id", name: r.name };
  }
  if (domain) {
    const r = rows2.find((c) => String(c.domain || "").toLowerCase() === domain);
    if (r) return { id: r._id, by: "domain", name: r.name };
  }
  if (name) {
    const r = rows2.find((c) => fold(c.name) === fold(name));
    if (r) return { id: r._id, by: "name", name: r.name };
  }
  return null;
}
async function liveId(db, table, id, what) {
  let row2 = await db.one(`SELECT _id, removed, merged_into FROM ${table} WHERE _deleted = 0 AND _id = ?`, [id]);
  for (let k = 0; row2 && row2.merged_into && k < 5; k += 1) row2 = await db.one(`SELECT _id, removed, merged_into FROM ${table} WHERE _deleted = 0 AND _id = ?`, [row2.merged_into]);
  if (!row2) throw new Refused(`There is no ${what} ${id}. ${what === "company" ? "companies" : "contacts"} lists them.`, 404, { code: "NOT_FOUND", item: id });
  if (Number(row2.removed)) throw new Refused(`That ${what} is archived. Restore it first (${what === "company" ? "companies_save" : "contacts_save"} { id, remove: false }), or use another.`, 409, { code: "ARCHIVED", item: row2._id });
  return row2._id;
}
async function mainOf(db, companyId, v) {
  if (v === null || v === "") return null;
  const p = await db.one(`SELECT _id, company_id FROM ${T.contacts} WHERE ${LIVE} AND _id = ?`, [idOf(v)]);
  if (!p || p.company_id !== companyId) throw new Refused(`main_contact_id is one of this company's contacts (contacts { company_id: ${companyId} }); ${v} is not.`, 400, { code: "NOT_ITS_CONTACT", item: companyId });
  return p._id;
}
async function companyRef(db, i, { make = false, source = null } = {}) {
  const id = idOf(i.company_id);
  if (id) return liveId(db, T.companies, id, "company");
  const m = await matchCompany(db, i);
  if (m) return m.id;
  const name = text(i.company ?? i.company_name, 200);
  if (!make || !name) return null;
  const domain = siteDomain(i.website ?? i.domain) || companyDomainOf(i.email);
  return db.insert(T.companies, { name, domain: domain || null, website: text(i.website, 300), tax_id: text(i.tax_id, 40), source: text(source ?? i.source, 60) });
}
async function contactRef(db, i, { make = false, company_id = null, source = null } = {}) {
  const id = idOf(i.contact_id);
  if (id) return liveId(db, T.contacts, id, "person");
  const email = isEmail(i.email) ? normEmail(i.email) : null;
  const name = text(i.contact ?? i.contact_name ?? i.name, 200);
  if (email) {
    const r = await db.one(`SELECT _id FROM ${T.contacts} WHERE ${LIVE} AND lower(email) = ?`, [email]);
    if (r) return r._id;
  }
  if (name) {
    const rows2 = await db.all(`SELECT _id, name, company_id FROM ${T.contacts} WHERE ${LIVE}`);
    const same = rows2.find((c) => fold(c.name) === fold(name) && (!company_id || !c.company_id || c.company_id === company_id));
    if (same) return same._id;
  }
  if (!make || !email && !name) return null;
  const made = await db.insert(T.contacts, { name: name || email, email, phone: text(i.phone, 40), title: text(i.title, 120), company_id, status: "Lead", source: text(source ?? i.source, 60) });
  if (company_id) await ensureMainContact(db, company_id);
  return made;
}
async function companies(db, i, full, now = /* @__PURE__ */ new Date()) {
  const q = text(i.q, 80);
  const cur = (await settingsRow(db)).currency;
  const rows2 = await db.all(`SELECT c._id AS id, c.name, c.domain, c.website, c.industry, c.location, c.summary,
      (SELECT COUNT(*) FROM ${T.contacts} p WHERE p._deleted = 0 AND COALESCE(p.removed,0) = 0 AND p.company_id = c._id AND COALESCE(p.status,'') NOT IN ('Suggested','Ignored')) AS people,
      (SELECT COUNT(*) FROM ${T.deals} d WHERE d._deleted = 0 AND COALESCE(d.removed,0) = 0 AND d.company_id = c._id AND d.status = 'Open') AS open_deals,
      (SELECT COALESCE(SUM(d.amount),0) FROM ${T.deals} d WHERE d._deleted = 0 AND COALESCE(d.removed,0) = 0 AND d.company_id = c._id AND d.status = 'Open' AND upper(COALESCE(d.currency, ?)) = ?) AS open_value,
      (SELECT COALESCE(SUM(d.amount),0) FROM ${T.deals} d WHERE d._deleted = 0 AND COALESCE(d.removed,0) = 0 AND d.company_id = c._id AND d.status = 'Won' AND upper(COALESCE(d.currency, ?)) = ?) AS won_value,
      (SELECT COUNT(*) FROM ${T.deals} d WHERE d._deleted = 0 AND COALESCE(d.removed,0) = 0 AND d.company_id = c._id AND d.status IN ('Open','Won') AND upper(COALESCE(d.currency, ?)) <> ?) AS other_currency,
      c.main_contact_id, (SELECT p.name FROM ${T.contacts} p WHERE p._id = c.main_contact_id) AS main_contact,
      (SELECT MAX(a.at) FROM ${T.activities} a WHERE a._deleted = 0 AND COALESCE(a.removed,0) = 0 AND a.type <> 'stage' AND (a.company_id = c._id OR a.contact_id IN (SELECT p._id FROM ${T.contacts} p WHERE p.company_id = c._id))) AS last_at
    FROM ${T.companies} c WHERE c._deleted = 0 AND COALESCE(c.removed,0) = 0
    ${q ? "AND (lower(c.name) LIKE ? OR lower(COALESCE(c.domain,'')) LIKE ? OR lower(COALESCE(c.industry,'')) LIKE ?)" : ""}
    ORDER BY (open_deals > 0) DESC, COALESCE(last_at, c._updated_at) DESC`, [...Array(6).fill(cur), ...q ? Array(3).fill(`%${q.toLowerCase()}%`) : []]);
  const f = await facts(db, rows2.map((r) => r.id), now);
  const ORDER = { customer: 0, talking: 1, lead: 2, former: 3 };
  let all = rows2.map((r) => {
    const x = f.get(r.id) ?? {};
    return { ...r, stage: x.stage, stage_label: x.stage_label, stage_reason: x.stage_reason, stage_by: x.stage_by, monthly: x.monthly || 0, risks: x.risks ?? [] };
  });
  const counts = { all: all.length, at_risk: all.filter((r) => r.risks.length).length, ...Object.fromEntries(Object.keys(ORDER).map((k) => [k, all.filter((r) => r.stage === k).length])) };
  const stage = i.stage ? choiceOf(i.stage, STAGE_WORDS, "stage") : null;
  if (stage) all = all.filter((r) => r.stage === stage);
  if (i.at_risk === true || i.at_risk === "true") all = all.filter((r) => r.risks.length);
  all.sort((a, b) => (b.risks.length > 0) - (a.risks.length > 0) || ORDER[a.stage] - ORDER[b.stage] || (b.open_deals > 0) - (a.open_deals > 0) || String(b.last_at ?? "").localeCompare(String(a.last_at ?? "")));
  const total = all.length;
  const limit = full ? 500 : Math.min(Number(i.limit) || 15, 100);
  const offset = Number(i.offset) || 0;
  const page = all.slice(offset, offset + limit).map((r) => full ? r : sent({ id: r.id, name: r.name, stage: r.stage, at_risk: r.risks.length ? r.risks.map((x) => x.kind).join(", ") : void 0, monthly: r.monthly || void 0, open_deals: r.open_deals || void 0, open_value: r.open_value || void 0, won_value: r.won_value || void 0, other_currency: r.other_currency || void 0, last_at: r.last_at ? r.last_at.slice(0, 10) : void 0 }));
  return { total, counts, rows: page, ...offset + limit < total ? { more: `${total - offset - limit} more: offset ${offset + limit}` } : {} };
}
var LAST_ACTIVITY = `(SELECT MAX(x) FROM (SELECT a.at AS x FROM ${T.activities} a WHERE a._deleted = 0 AND COALESCE(a.removed,0) = 0 AND a.type <> 'stage' AND a.contact_id = p._id UNION ALL SELECT NULLIF(p.last_activity_at, '')))`;
async function contacts(db, i, full) {
  const q = text(i.q, 80);
  const where = [`p._deleted = 0`, `COALESCE(p.removed,0) = 0`];
  const args = [];
  if (i.company_id) {
    where.push("p.company_id = ?");
    args.push(idOf(i.company_id));
  }
  if (i.status) {
    where.push("p.status = ?");
    args.push(i.status);
  } else where.push(`COALESCE(p.status,'') NOT IN ('Suggested','Ignored')`);
  if (q) {
    where.push(`(lower(p.name) LIKE ? OR lower(COALESCE(p.email,'')) LIKE ?)`);
    args.push(`%${q.toLowerCase()}%`, `%${q.toLowerCase()}%`);
  }
  const rows2 = (await db.all(`SELECT p._id AS id, p.name, p.email, p.phone, p.title, p.status, p.company_id, c.name AS company, p.suggested_why,
      ${LAST_ACTIVITY} AS last_at
    FROM ${T.contacts} p LEFT JOIN ${T.companies} c ON c._id = p.company_id WHERE ${where.join(" AND ")}
    ORDER BY (last_at IS NULL) ASC, last_at DESC, p.name COLLATE NOCASE`, args)).map(({ last_at, ...r }) => ({ ...r, last_activity_at: last_at }));
  const limit = full ? 500 : Math.min(Number(i.limit) || 15, 100);
  const offset = Number(i.offset) || 0;
  return { total: rows2.length, rows: rows2.slice(offset, offset + limit).map((r) => full ? r : sent({ id: r.id, name: r.name, email: r.email || void 0, company: r.company || void 0, title: r.title || void 0 })), ...offset + limit < rows2.length ? { more: `${rows2.length - offset - limit} more: offset ${offset + limit}` } : {} };
}
async function saveCompanies(db, i, actor = "", now = /* @__PURE__ */ new Date()) {
  const out = { added: [], changed: [], matched: [], archived: [], skipped: [] };
  for (const [k, item] of listOf(i.items, "items").entries()) {
    try {
      onlyKnown(item, COMPANY_SAVE, "companies_save", ELSEWHERE);
      const data = sent(Object.fromEntries(COMPANY_FIELDS.map((f) => [f, item[f] === void 0 ? void 0 : text(item[f], f === "summary" || f === "notes" ? 4e3 : 300)])));
      if (data.website && !data.domain) data.domain = siteDomain(data.website) || void 0;
      if (data.domain) data.domain = siteDomain(data.domain) || data.domain.toLowerCase();
      if (data.tax_id) data.tax_id = taxKey(data.tax_id) || data.tax_id;
      const match2 = idOf(item.id) ? null : await matchCompany(db, { name: item.name, website: item.website, domain: item.domain, tax_id: item.tax_id });
      const id = idOf(item.id) ?? match2?.id ?? null;
      if (match2) out.matched.push({ index: k, id: match2.id, by: match2.by, name: match2.name });
      if (id) {
        const row2 = await db.one(`SELECT _id, removed, merged_into FROM ${T.companies} WHERE _deleted = 0 AND _id = ?`, [id]);
        if (!row2 || row2.merged_into) throw new Refused(row2 ? `Company ${id} was merged into ${row2.merged_into}: change that one.` : `No company ${id}.`, row2 ? 409 : 404, { code: row2 ? "MERGED" : "NOT_FOUND", item: row2?.merged_into ?? id });
        if (item.remove === true) {
          if (await count(db, `SELECT COUNT(*) AS n FROM ${T.deals} WHERE ${LIVE} AND company_id = ? AND status = 'Open'`, [id])) throw new Refused("It has open deals: close or move them first, so nothing open is left without a client.", 409, { code: "HAS_OPEN_DEALS" });
          await db.update(T.companies, id, { removed: 1 });
          out.archived.push(id);
          continue;
        }
        if (item.remove === false && Number(row2.removed)) data.removed = 0;
        else if (Number(row2.removed)) throw new Refused(`Company ${id} is archived: restore it with remove: false.`, 409, { code: "ARCHIVED", item: id });
        if (match2) {
          const have = await db.one(`SELECT * FROM ${T.companies} WHERE _id = ?`, [id]);
          for (const f of Object.keys(data)) if (have[f] !== null && have[f] !== void 0 && have[f] !== "") delete data[f];
        }
        if (item.main_contact_id !== void 0) data.main_contact_id = await mainOf(db, id, item.main_contact_id);
        if (item.stage !== void 0) Object.assign(data, stageData(item.stage === null || item.stage === "" || item.stage === "auto" ? null : choiceOf(item.stage, STAGE_WORDS, "stage"), actor, now));
        if (item.concern !== void 0) Object.assign(data, concernData(item.concern, now));
        if (Object.keys(data).length) await db.update(T.companies, id, data);
        await ensureMainContact(db, id);
        out.changed.push(id);
      } else {
        if (!data.name) throw new Refused("A new company needs its name.", 400, { code: "BAD_INPUT" });
        if (item.main_contact_id) throw new Refused("A new company has no contacts yet: add the company, then its contacts (contacts_save { company_id, main: true }).", 400, { code: "BAD_INPUT" });
        if (item.stage) Object.assign(data, stageData(choiceOf(item.stage, STAGE_WORDS, "stage"), actor, now));
        if (item.concern) Object.assign(data, concernData(item.concern, now));
        out.added.push(await db.insert(T.companies, data));
      }
    } catch (e) {
      if (!(e instanceof Refused)) throw e;
      out.skipped.push({ index: k, code: e.code, error: e.message });
    }
  }
  return out;
}
async function saveContacts(db, i) {
  const out = { added: [], changed: [], matched: [], archived: [], skipped: [] };
  for (const [k, item] of listOf(i.items, "items").entries()) {
    try {
      onlyKnown(item, CONTACT_SAVE, "contacts_save", ELSEWHERE);
      const data = sent(Object.fromEntries(CONTACT_FIELDS.map((f) => [f, item[f] === void 0 ? void 0 : text(item[f], f === "notes" ? 4e3 : 300)])));
      if (data.email !== void 0) {
        if (data.email && !isEmail(data.email)) throw new Refused(`${data.email} is not an email address.`, 400, { code: "BAD_EMAIL" });
        data.email = data.email ? normEmail(data.email) : null;
      }
      if (item.status !== void 0) data.status = choiceOf(item.status, CONTACT_STATUS, "status");
      if (item.company_id !== void 0 || item.company !== void 0) data.company_id = item.company_id === null || item.company === null ? null : await companyRef(db, { company_id: item.company_id, company: item.company, email: item.email }, { make: true });
      const found = idOf(item.id) ? null : item.email || item.name ? await contactRef(db, { email: item.email, name: item.name }, { company_id: data.company_id }) : null;
      const id = idOf(item.id) ?? found;
      if (found) out.matched.push({ index: k, id: found, by: item.email && isEmail(item.email) && await db.one(`SELECT _id FROM ${T.contacts} WHERE _id = ? AND lower(email) = ?`, [found, normEmail(item.email)]) ? "email" : "name" });
      if (id) {
        const row2 = await db.one(`SELECT _id, removed, merged_into FROM ${T.contacts} WHERE _deleted = 0 AND _id = ?`, [id]);
        if (!row2 || row2.merged_into) throw new Refused(row2 ? `Person ${id} was merged into ${row2.merged_into}: change that one.` : `No person ${id}.`, row2 ? 409 : 404, { code: row2 ? "MERGED" : "NOT_FOUND", item: row2?.merged_into ?? id });
        const before = (await db.one(`SELECT company_id FROM ${T.contacts} WHERE _id = ?`, [id]))?.company_id ?? null;
        if (item.remove === true) {
          await db.update(T.contacts, id, { removed: 1 });
          await ensureMainContact(db, before);
          out.archived.push(id);
          continue;
        }
        if (item.remove === false && Number(row2.removed)) data.removed = 0;
        else if (Number(row2.removed)) throw new Refused(`Person ${id} is archived: restore them with remove: false.`, 409, { code: "ARCHIVED", item: id });
        if (found) {
          const have = await db.one(`SELECT * FROM ${T.contacts} WHERE _id = ?`, [id]);
          for (const f of Object.keys(data)) if (f !== "status" && have[f] !== null && have[f] !== void 0 && have[f] !== "") delete data[f];
        }
        if (Object.keys(data).length) await db.update(T.contacts, id, data);
        const now = (await db.one(`SELECT company_id FROM ${T.contacts} WHERE _id = ?`, [id]))?.company_id ?? null;
        if (before && before !== now) await ensureMainContact(db, before);
        if (now) await (item.main === true ? db.update(T.companies, now, { main_contact_id: id }) : ensureMainContact(db, now));
        out.changed.push(id);
      } else {
        if (!data.name && !data.email) throw new Refused("A new person needs a name or an email.", 400, { code: "BAD_INPUT" });
        if (data.company_id === void 0 && data.email) data.company_id = await companyRef(db, { email: data.email });
        const made = await db.insert(T.contacts, { status: "Contacted", ...data, name: data.name || data.email });
        if (data.company_id) await (item.main === true ? db.update(T.companies, data.company_id, { main_contact_id: made }) : ensureMainContact(db, data.company_id));
        out.added.push(made);
      }
    } catch (e) {
      if (!(e instanceof Refused)) throw e;
      out.skipped.push({ index: k, code: e.code, error: e.message });
    }
  }
  return out;
}
async function merge(db, kind, i) {
  const table = kind === "company" ? T.companies : T.contacts;
  const keep = idOf(i.keep);
  const drop2 = idOf(i.drop);
  if (!keep || !drop2 || keep === drop2) throw new Refused("Name the two: keep (the one that stays) and drop (the duplicate), different ids.", 400, { code: "BAD_INPUT" });
  const a = await db.one(`SELECT * FROM ${table} WHERE ${LIVE} AND _id = ?`, [keep]);
  const b = await db.one(`SELECT * FROM ${table} WHERE _deleted = 0 AND _id = ? AND merged_into IS NULL`, [drop2]);
  if (!a || !b) throw new Refused(`${!a ? `keep ${keep}` : `drop ${drop2}`} is not a ${kind === "company" ? "company" : "person"} that can be merged (missing, archived or merged already).`, 404, { code: "NOT_FOUND", item: !a ? keep : drop2 });
  const col = kind === "company" ? "company_id" : "contact_id";
  const moved = {};
  const repoint = kind === "company" ? [T.deals, T.contacts, T.activities, T.leads] : [T.deals, T.activities, T.leads, T.tasks, T.drafts];
  for (const t of repoint) {
    const rows2 = await db.all(`SELECT _id FROM ${t} WHERE _deleted = 0 AND ${col} = ?`, [drop2]);
    for (const r of rows2) await db.update(t, r._id, { [col]: keep });
    moved[t.replace("crm_", "")] = rows2.length;
  }
  const fields = kind === "company" ? COMPANY_FIELDS : [...CONTACT_FIELDS, "company_id"];
  const fill = Object.fromEntries(fields.filter((f) => (a[f] === null || a[f] === void 0 || a[f] === "") && b[f] !== null && b[f] !== void 0 && b[f] !== "").map((f) => [f, b[f]]));
  if (kind === "company" && a.notes && b.notes) fill.notes = `${a.notes}

${b.notes}`.slice(0, 4e3);
  if (Object.keys(fill).length) await db.update(table, keep, fill);
  await db.update(table, drop2, { removed: 1, merged_into: keep });
  if (kind === "contact") for (const c of await db.all(`SELECT _id FROM ${T.companies} WHERE _deleted = 0 AND main_contact_id = ?`, [drop2])) await db.update(T.companies, c._id, { main_contact_id: keep });
  if (kind === "company") await ensureMainContact(db, keep);
  return { keep, drop: drop2, moved, filled: Object.keys(fill) };
}
async function reference(db, i) {
  const one3 = async (table, id) => {
    let row2 = await db.one(`SELECT * FROM ${table} WHERE _deleted = 0 AND _id = ?`, [id]);
    const from = row2?.merged_into ? id : void 0;
    for (let k = 0; row2 && row2.merged_into && k < 5; k += 1) row2 = await db.one(`SELECT * FROM ${table} WHERE _deleted = 0 AND _id = ?`, [row2.merged_into]);
    return row2 ? { row: row2, from } : null;
  };
  const company = async (id) => {
    const r = await one3(T.companies, id);
    if (!r) return null;
    const c = r.row;
    const p = await db.one(`SELECT _id, name, email, phone FROM ${T.contacts} WHERE ${LIVE} AND company_id = ? AND COALESCE(status,'') NOT IN ('Suggested','Ignored') ORDER BY (_id = ?) DESC, last_activity_at DESC LIMIT 1`, [c._id, c.main_contact_id ?? -1]);
    return sent({ kind: "company", id: c._id, main_contact_id: c.main_contact_id || void 0, name: c.name, display: c.name, legal_name: c.legal_name || void 0, tax_id: c.tax_id || void 0, address: c.address || void 0, email: p?.email || void 0, phone: c.phone || p?.phone || void 0, contact: p?.name || void 0, website: c.website || void 0, archived: Number(c.removed) ? true : void 0, merged_from: r.from });
  };
  if (i.company_id) return await company(idOf(i.company_id)) ?? notFound("company", i.company_id);
  if (i.contact_id) {
    const r = await one3(T.contacts, idOf(i.contact_id));
    if (!r) return notFound("person", i.contact_id);
    const p = r.row;
    const co = p.company_id ? await company(p.company_id) : null;
    return sent({ kind: "person", id: p._id, name: p.name, display: co ? `${p.name} \xB7 ${co.name}` : p.name, email: p.email || void 0, phone: p.phone || void 0, title: p.title || void 0, company: co ?? void 0, archived: Number(p.removed) ? true : void 0, merged_from: r.from });
  }
  throw new Refused("Say which: company_id or contact_id.", 400, { code: "BAD_INPUT" });
}
var notFound = (what, id) => {
  throw new Refused(`There is no ${what} ${id} in the CRM.`, 404, { code: "NOT_FOUND", item: idOf(id) });
};

// server/services/timeline.mjs
var TYPES = { email: ["correo", "mail", "e mail"], email_in: ["email in", "received", "recibido", "correo recibido"], email_out: ["email out", "sent", "enviado", "correo enviado"], meeting: ["reunion", "meeting", "llamada de video"], call: ["llamada", "phone"], note: ["nota"], form: ["formulario", "lead", "entrada"], stage: ["etapa"], task: ["paso"] };
var SUMMARY_MAX = 1500;
async function placeOf(db, item) {
  let deal_id = idOf(item.deal_id);
  let contact_id = null;
  let company_id = null;
  if (deal_id) {
    const d = await db.one(`SELECT _id, company_id, contact_id FROM ${T.deals} WHERE ${LIVE} AND _id = ?`, [deal_id]);
    if (!d) throw new Refused(`There is no deal ${deal_id}. deals lists them.`, 404, { code: "NOT_FOUND", item: deal_id });
    company_id = d.company_id;
    contact_id = d.contact_id;
  }
  if (item.contact_id || item.email) {
    contact_id = await contactRef(db, { contact_id: item.contact_id, email: item.email, name: item.name }, { make: !!item.email && item.make_contact === true });
    if (!contact_id && item.contact_id) throw new Refused(`No person ${item.contact_id}.`, 404, { code: "NOT_FOUND" });
  }
  if (item.company_id) company_id = await companyRef(db, { company_id: item.company_id });
  if (contact_id && !company_id) company_id = (await db.one(`SELECT company_id FROM ${T.contacts} WHERE _id = ?`, [contact_id]))?.company_id ?? null;
  if (!deal_id && !contact_id && !company_id) throw new Refused("Say whose it is: deal_id, contact_id, company_id, or the email of a person already in the CRM.", 400, { code: "NO_PLACE" });
  return { deal_id, contact_id, company_id };
}
async function add(db, i, actor, now) {
  const out = { added: [], already: 0, skipped: [] };
  for (const [k, item] of listOf(i.items, "items").entries()) {
    try {
      const type = choiceOf(item.type ?? "note", TYPES, "type");
      const external_id = text(item.external_id, 200);
      if (external_id && await db.one(`SELECT _id FROM ${T.activities} WHERE _deleted = 0 AND external_id = ?`, [external_id])) {
        out.already += 1;
        continue;
      }
      const place = await placeOf(db, item);
      const summary = text(item.summary ?? item.text, SUMMARY_MAX);
      const subject = text(item.subject, 200);
      if (!summary && !subject) throw new Refused("An entry needs a subject or a summary: what happened, in a line or a few.", 400, { code: "BAD_INPUT" });
      const at = momentOf(item.at, now);
      const id = await db.insert(T.activities, { type, ...place, at, subject, summary, external_id, source: text(item.source, 60), author: who(actor) });
      if (place.contact_id && type !== "stage") await touch(db, place.contact_id, at);
      out.added.push(id);
    } catch (e) {
      if (!(e instanceof Refused)) throw e;
      out.skipped.push({ index: k, code: e.code, error: e.message });
    }
  }
  return out;
}
async function note(db, place, type, subject, summary, actor, now = /* @__PURE__ */ new Date(), at = null) {
  return db.insert(T.activities, { type, deal_id: place.deal_id ?? null, contact_id: place.contact_id ?? null, company_id: place.company_id ?? null, at: at ?? stamp(now), subject: text(subject, 200), summary: text(summary, SUMMARY_MAX), author: who(actor) });
}
async function touch(db, contactId, at) {
  const c = await db.one(`SELECT last_activity_at FROM ${T.contacts} WHERE _id = ?`, [contactId]);
  if (c && (!c.last_activity_at || c.last_activity_at < at)) await db.update(T.contacts, contactId, { last_activity_at: at });
}
async function list(db, i, full) {
  const deal = idOf(i.deal_id);
  const company = idOf(i.company_id);
  const contact = idOf(i.contact_id);
  let where;
  let args;
  if (deal) {
    const d = await db.one(`SELECT contact_id FROM ${T.deals} WHERE _id = ?`, [deal]);
    where = `(deal_id = ? OR (deal_id IS NULL AND contact_id = ? AND type IN ('email','email_in','email_out','meeting','call')))`;
    args = [deal, d?.contact_id ?? -1];
  } else if (company) {
    where = `(company_id = ? OR contact_id IN (SELECT _id FROM ${T.contacts} WHERE company_id = ?) OR deal_id IN (SELECT _id FROM ${T.deals} WHERE company_id = ?))`;
    args = [company, company, company];
  } else if (contact) {
    where = `(contact_id = ? OR deal_id IN (SELECT _id FROM ${T.deals} WHERE contact_id = ?))`;
    args = [contact, contact];
  } else throw new Refused("Say whose timeline: deal_id, company_id or contact_id.", 400, { code: "NO_PLACE" });
  const limit = full ? 300 : Math.min(Number(i.limit) || 10, 50);
  const rows2 = await db.all(`SELECT _id AS id, type, at, subject, summary, deal_id, contact_id, company_id, author FROM ${T.activities} WHERE ${LIVE} AND ${where} ORDER BY at DESC, _id DESC LIMIT ?`, [...args, limit + 1]);
  const more = rows2.length > limit;
  return { rows: rows2.slice(0, limit).map((r) => full ? r : { id: r.id, type: r.type, at: String(r.at).slice(0, 16), subject: r.subject || void 0, gist: r.summary ? String(r.summary).split("\n")[0].slice(0, 160) : void 0 }), ...more ? { more: `older entries: limit ${limit + 20}` } : {} };
}
async function remove(db, i) {
  const a = await db.one(`SELECT _id, type FROM ${T.activities} WHERE ${LIVE} AND _id = ?`, [idOf(i.id)]);
  if (!a) throw new Refused(`There is no timeline entry ${i.id}.`, 404, { code: "NOT_FOUND" });
  if (a.type === "stage") throw new Refused("A stage move is the deal's history and stays. To change the stage, move the deal.", 409, { code: "HISTORY" });
  await db.update(T.activities, a._id, { removed: 1 });
  return { removed: a._id };
}

// server/services/links.mjs
var RECORDS = ["company", "contact", "deal", "service"];
var recordOf = (i) => {
  const r = String(i.record || "").trim();
  if (!RECORDS.includes(r)) throw new Refused(`record is one of ${RECORDS.join(", ")}.`, 400, { code: "BAD_INPUT" });
  return r;
};
var nearOf = (v) => Object.fromEntries(String(v ?? "").split(",").map((x) => x.split(":")).filter((x) => x.length === 2 && /^[a-z_]+$/.test(x[0].trim()) && Number(x[1]) > 0).map(([k, n]) => [k.trim(), Number(n)]));
var fromOf = (i) => !i.from ? "Facturas" : i.from === "crm" ? void 0 : i.from === "invoices" ? "Facturas" : text(i.from, 40);
var idsOf = (v) => [...new Set(String(v ?? "").split(",").map((x) => Number(x)).filter((x) => Number.isInteger(x) && x > 0))].slice(0, 200);
var nameKey = (v) => fold(v).replace(/[.,;:'"«»()&-]/g, " ").replace(/\b(s\s?l\s?u?|s\s?a|sociedad limitada|ltd|llc|inc)\b/g, " ").replace(/\s+/g, " ").trim();
async function mainPeople(db, ids) {
  if (!ids.length) return /* @__PURE__ */ new Map();
  const rows2 = await db.all(`SELECT p._id, p.company_id, p.name, p.email, p.phone FROM ${T.contacts} p JOIN ${T.companies} c ON c._id = p.company_id WHERE p._deleted = 0 AND COALESCE(p.removed,0) = 0 AND p.company_id IN (${ids.map(() => "?").join(",")}) AND COALESCE(p.status,'') NOT IN ('Suggested','Ignored') ORDER BY (p._id = COALESCE(c.main_contact_id, -1)) DESC, COALESCE(p.last_activity_at, p._updated_at) DESC`, ids);
  const out = /* @__PURE__ */ new Map();
  for (const r of rows2) if (!out.has(r.company_id)) out.set(r.company_id, r);
  return out;
}
var companyRow = (c, p) => sent({
  id: c._id,
  display: c.name,
  name: c.name,
  main_contact_id: c.main_contact_id || void 0,
  legal_name: c.legal_name || void 0,
  tax_id: c.tax_id || void 0,
  address: c.address || void 0,
  phone: c.phone || p?.phone || void 0,
  email: p?.email || void 0,
  contact: p?.name || void 0,
  website: c.website || (c.domain ? `https://${c.domain}` : void 0),
  hint: [c.tax_id, c.domain || c.location].filter(Boolean).join(" \xB7 ") || void 0,
  archived: Number(c.removed) ? true : void 0,
  merged_into: c.merged_into || void 0
});
async function reference2(db, i) {
  const record = recordOf(i);
  const ids = idsOf(i.ids);
  const q = nameKey(i.q);
  const limit = Math.min(Math.max(Number(i.limit) || 20, 1), 100);
  const where = (a = "") => ids.length ? `${a}_deleted = 0 AND ${a}_id IN (${ids.map(() => "?").join(",")})` : `${a}_deleted = 0 AND COALESCE(${a}removed, 0) = 0`;
  if (record === "company") {
    let rows3 = await db.all(`SELECT * FROM ${T.companies} WHERE ${where()} ORDER BY name COLLATE NOCASE`, ids);
    if (!ids.length && q) {
      const tax = taxKey(i.q);
      rows3 = rows3.filter((c) => nameKey(c.name).includes(q) || nameKey(c.legal_name).includes(q) || tax.length >= 5 && taxKey(c.tax_id).includes(tax) || String(c.domain || "").includes(q));
    }
    if (!ids.length) rows3 = rows3.filter((c) => !c.merged_into).slice(0, limit);
    const people = await mainPeople(db, rows3.map((c) => c._id));
    return { rows: rows3.map((c) => companyRow(c, people.get(c._id))) };
  }
  if (record === "contact") {
    let rows3 = await db.all(`SELECT p.*, c.name AS company FROM ${T.contacts} p LEFT JOIN ${T.companies} c ON c._id = p.company_id WHERE ${where("p.")} AND COALESCE(p.status,'') NOT IN ('Ignored') ORDER BY p.name COLLATE NOCASE`, ids);
    if (!ids.length && q) rows3 = rows3.filter((p) => nameKey(p.name).includes(q) || String(p.email || "").toLowerCase().includes(String(i.q).trim().toLowerCase()));
    const beside = nearOf(i.near).company_id;
    if (!ids.length && beside) rows3 = [...rows3.filter((p) => p.company_id === beside), ...rows3.filter((p) => p.company_id !== beside)];
    if (!ids.length) rows3 = rows3.filter((p) => !p.merged_into && p.status !== "Suggested").slice(0, limit);
    return { rows: rows3.map((p) => sent({ id: p._id, display: p.company ? `${p.name} \xB7 ${p.company}` : p.name, name: p.name, email: p.email || void 0, phone: p.phone || void 0, title: p.title || void 0, company: p.company || void 0, company_id: p.company_id || void 0, hint: p.email || void 0, archived: Number(p.removed) ? true : void 0, merged_into: p.merged_into || void 0 })) };
  }
  if (record === "service") {
    const st = await settingsRow(db);
    let rows3 = await serviceRows(db, ids.length ? `s._id IN (${ids.map(() => "?").join(",")})` : "", ids, today(/* @__PURE__ */ new Date(), st.timezone));
    if (!ids.length) rows3 = rows3.filter((x) => x.state !== "ended");
    if (!ids.length && q) rows3 = rows3.filter((x) => nameKey(x.name).includes(q) || nameKey(x.company).includes(q));
    const near = nearOf(i.near).company_id;
    if (!ids.length && near) rows3 = [...rows3.filter((x) => x.company_id === near), ...rows3.filter((x) => x.company_id !== near)];
    if (!ids.length) rows3 = rows3.slice(0, limit);
    return { rows: rows3.map((x) => sent({ id: x.id, display: `${x.name} \xB7 ${x.company ?? ""}`, name: x.name, company: x.company, company_id: x.company_id, item: x.item, category: x.category, price: x.price, quantity: x.quantity, amount: x.amount, every: x.every, bill_every: x.bill_every, bill_in: x.bill_in, start: x.start, end_on: x.ends, state: x.state, min_months: x.min_months, renewal: x.renewal, hint: [x.amount !== void 0 ? `${x.amount} \u20AC/${{ month: "mes", quarter: "trimestre", year: "a\xF1o" }[x.every] ?? "mes"}` : null, x.state === "ended" ? "terminado" : null].filter(Boolean).join(" \xB7 ") || void 0 })) };
  }
  let rows2 = await db.all(`SELECT d.*, c.name AS company FROM ${T.deals} d LEFT JOIN ${T.companies} c ON c._id = d.company_id WHERE ${where("d.")} ORDER BY d._id DESC`, ids);
  if (!ids.length) rows2 = rows2.filter((d) => d.status === "Open" || d.status === "Won");
  if (!ids.length && q) rows2 = rows2.filter((d) => nameKey(d.title).includes(q) || nameKey(d.company).includes(q));
  if (!ids.length) rows2 = rows2.slice(0, limit);
  const lines = await linesOf2(db, rows2.map((d) => d._id));
  return { rows: rows2.map((d) => sent({ id: d._id, display: dealName(d.title, d.company), lines: (lines.get(d._id) ?? []).map((l) => sent({ item: l.item, name: l.name, category: l.category, quantity: l.quantity, price: l.price, discount: l.discount, kind: l.kind, every: l.every, start: l.start })), value: (lines.get(d._id) ?? []).length ? valueOfLines(lines.get(d._id), d.currency || "EUR").text : void 0, title: d.title, status: d.status, stage: d.stage || void 0, service: d.kind || void 0, amount: d.amount ?? void 0, currency: d.currency || void 0, recurring_amount: d.recurring_amount || void 0, recurring_every: d.recurring_every || void 0, recurring_until: d.recurring_until || void 0, closed_at: d.closed_at || void 0, condition: d.condition || void 0, company: d.company || void 0, company_id: d.company_id || void 0, contact_id: d.contact_id || void 0, hint: d.stage || void 0, archived: Number(d.removed) ? true : void 0 })) };
}
async function referenceMatch(db, i) {
  const record = recordOf(i);
  const out = /* @__PURE__ */ new Map();
  const add3 = (id, display, by) => {
    if (!out.has(id)) out.set(id, { id, display, by });
  };
  if (record === "company") {
    const rows2 = await db.all(`SELECT _id, name, tax_id, domain FROM ${T.companies} WHERE ${LIVE} AND merged_into IS NULL`);
    const tax = taxKey(i.tax_id);
    const domain = siteDomain(i.website ?? i.domain) || companyDomainOf(i.email);
    const name = nameKey(i.name);
    if (tax) {
      for (const c of rows2) if (taxKey(c.tax_id) === tax) add3(c._id, c.name, "tax_id");
    }
    if (domain) {
      for (const c of rows2) if (String(c.domain || "").toLowerCase() === domain) add3(c._id, c.name, "domain");
    }
    if (name) for (const c of rows2) {
      const k = nameKey(c.name);
      if (k && (k === name || Math.min(k.length, name.length) >= 4 && (k.includes(name) || name.includes(k)))) add3(c._id, c.name, "name");
    }
  } else if (record === "contact") {
    const rows2 = await db.all(`SELECT _id, name, email FROM ${T.contacts} WHERE ${LIVE} AND merged_into IS NULL AND COALESCE(status,'') NOT IN ('Suggested','Ignored')`);
    const email = isEmail(i.email) ? normEmail(i.email) : null;
    const name = nameKey(i.name);
    if (email) {
      for (const p of rows2) if (String(p.email || "").toLowerCase() === email) add3(p._id, p.name, "email");
    }
    if (name) {
      for (const p of rows2) if (nameKey(p.name) === name) add3(p._id, p.name, "name");
    }
  } else throw new Refused("A deal or a contracted service is made in the CRM itself (deals_save, services_save), not from another module.", 409, { code: "NO_CREATE" });
  return { matches: [...out.values()].slice(0, 8) };
}
async function referenceCreate(db, i) {
  const record = recordOf(i);
  if (record === "company") {
    const name = text(i.name, 200);
    if (!name) throw new Refused("A new company needs its name.", 400, { code: "BAD_INPUT" });
    const tax = taxKey(i.tax_id);
    if (tax) {
      const same = (await db.all(`SELECT _id, name, tax_id FROM ${T.companies} WHERE ${LIVE}`)).find((c) => taxKey(c.tax_id) === tax);
      if (same) throw new Refused(`The CRM already has that tax id: ${same.name} (${same._id}). Use that one.`, 409, { code: "DUPLICATE_TAX_ID", item: same._id });
    }
    const domain = siteDomain(i.website) || companyDomainOf(i.email);
    const id = await db.insert(T.companies, sent({ name, legal_name: text(i.legal_name, 200) || void 0, tax_id: tax || void 0, address: text(i.address, 300) || void 0, phone: text(i.phone, 40) || void 0, website: text(i.website, 300) || void 0, domain: domain || void 0, source: fromOf(i) }));
    if (isEmail(i.email)) await db.update(T.companies, id, { main_contact_id: await db.insert(T.contacts, sent({ name: text(i.contact, 200) || normEmail(i.email), email: normEmail(i.email), company_id: id, status: i.from === "crm" ? "Contacted" : "Customer", source: fromOf(i) })) });
    return { id };
  }
  if (record === "contact") {
    const name = text(i.name, 200);
    const email = isEmail(i.email) ? normEmail(i.email) : null;
    if (!name && !email) throw new Refused("A new person needs a name or an email.", 400, { code: "BAD_INPUT" });
    const company = idOf(i.company_id) ? await db.one(`SELECT _id, main_contact_id FROM ${T.companies} WHERE ${LIVE} AND _id = ?`, [idOf(i.company_id)]) : null;
    const id = await db.insert(T.contacts, sent({ name: name || email, email: email || void 0, phone: text(i.phone, 40) || void 0, title: text(i.title, 120) || void 0, company_id: company?._id, status: "Contacted", source: i.from === "crm" ? void 0 : "module" }));
    if (company && !company.main_contact_id) await db.update(T.companies, company._id, { main_contact_id: id });
    return { id };
  }
  throw new Refused("A deal is made in the CRM itself (deals_save), not from another module.", 409, { code: "NO_CREATE" });
}
async function dealDocuments(db, dealId) {
  const r = await db.referenced("deal", dealId).catch(() => null);
  return (r?.groups || []).flatMap((g) => g.rows.map((x) => {
    const has = x.fields && Object.prototype.hasOwnProperty.call(x.fields, "number");
    return sent({ module: g.module, id: x.id, number: (has ? x.fields.number : x.title) || void 0, title: x.title, kind: x.fields?.kind, state: x.fields?.status, total: x.fields?.total, open: x.open });
  }));
}
function quoteStateOf(deal, documents) {
  const quote = (documents || []).find((x) => /quote|presupuesto/i.test(String(x.kind ?? "")));
  return quote ? quote.state ?? null : deal.quote_state === "requested" ? "requested" : null;
}

// server/services/steps.mjs
async function dealOf(db, id) {
  const d = await db.one(`SELECT d._id, d.title, d.status, d.company_id, d.contact_id, p.email FROM ${T.deals} d LEFT JOIN ${T.contacts} p ON p._id = d.contact_id WHERE d._deleted = 0 AND COALESCE(d.removed,0) = 0 AND d._id = ?`, [idOf(id)]);
  if (!d) throw new Refused(`There is no deal ${id}. deals lists them.`, 404, { code: "NOT_FOUND", item: idOf(id) });
  return d;
}
async function propose(db, i, actor) {
  const out = { proposed: [], skipped: [] };
  for (const [k, item] of listOf(i.items, "items").entries()) {
    try {
      const d = item.deal_id ? await dealOf(db, item.deal_id) : await companyOf(db, item.company_id);
      if (item.deal_id && d.status !== "Open") throw new Refused("The deal is closed: there is no next step to propose. For its customer, propose with company_id.", 409, { code: "CLOSED", item: d._id });
      const step = text(item.step ?? item.title, 200);
      if (!step) throw new Refused("A proposal says the step: \xABLlamar a Laura para cerrar el alcance\xBB.", 400, { code: "BAD_INPUT", item: d._id });
      const due = dateOf(item.due, "due");
      const mineSql = item.deal_id ? "deal_id = ?" : "company_id = ? AND deal_id IS NULL";
      for (const t of await db.all(`SELECT _id, draft_id FROM ${T.tasks} WHERE _deleted = 0 AND ${mineSql} AND status = 'Suggested'`, [d._id])) {
        await db.update(T.tasks, t._id, { status: "Dismissed" });
        if (t.draft_id) await db.update(T.drafts, t.draft_id, { status: "Dropped" }, { status: "Review" });
      }
      let draft_id = null;
      const mail = item.email ?? item.draft;
      if (mail && (mail.body || mail.subject)) {
        const to = mail.to ? normEmail(mail.to) : d.email;
        if (!to || !isEmail(to)) throw new Refused(`The email has nobody to go to: the ${item.deal_id ? "deal" : "company"} has no person with an email. Add the person (contacts_save) or leave the email out.`, 400, { code: "NO_RECIPIENT", item: d._id });
        if (mail.to && to !== d.email && !await db.one(`SELECT _id FROM ${T.contacts} WHERE ${LIVE} AND lower(email) = ?`, [to])) throw new Refused(`${to} is not anyone in the CRM: an email goes to the ${item.deal_id ? "deal" : "company"}'s person, or to someone already here.`, 400, { code: "UNKNOWN_RECIPIENT", item: d._id });
        if (/\[[^\]]{2,40}\]|\{\{|<nombre>|XXX/i.test(`${mail.subject ?? ""} ${mail.body ?? ""}`)) throw new Refused("The email still has a placeholder ([Nombre], {{\u2026}}, XXX): write it whole, as it would go.", 400, { code: "PLACEHOLDER", item: d._id });
        draft_id = await db.insert(T.drafts, { to_email: to, subject: text(mail.subject, 200), body: text(mail.body, 8e3), contact_id: d.contact_id, deal_id: item.deal_id ? d._id : null, status: "Review", created_by: who(actor), source: "agent" });
      }
      const task_id = await db.insert(T.tasks, { title: step, due, deal_id: item.deal_id ? d._id : null, company_id: item.deal_id ? d.company_id : d._id, contact_id: d.contact_id, status: "Suggested", why: text(item.why, 600), draft_id, source: "agent" });
      out.proposed.push(sent({ ...item.deal_id ? { deal_id: d._id } : { company_id: d._id }, task_id, draft_id: draft_id ?? void 0 }));
    } catch (e) {
      if (!(e instanceof Refused)) throw e;
      out.skipped.push({ index: k, code: e.code, error: e.message, ...e.item !== void 0 ? { item: e.item } : {} });
    }
  }
  return out;
}
async function companyOf(db, id) {
  if (!idOf(id)) throw new Refused("Say whose step it is: deal_id, or company_id for a customer.", 400, { code: "NO_PLACE" });
  const c = await db.one(`SELECT c._id, c.name, c.main_contact_id AS contact_id, p.email FROM ${T.companies} c LEFT JOIN ${T.contacts} p ON p._id = c.main_contact_id WHERE c._deleted = 0 AND COALESCE(c.removed,0) = 0 AND c._id = ?`, [idOf(id)]);
  if (!c) throw new Refused(`There is no company ${id}. companies lists them.`, 404, { code: "NOT_FOUND", item: idOf(id) });
  return { ...c, company_id: c._id };
}
var taskOf = async (db, id, status) => {
  const t = await db.one(`SELECT * FROM ${T.tasks} WHERE _deleted = 0 AND _id = ?`, [idOf(id)]);
  if (!t) throw new Refused(`There is no proposed step ${id}.`, 404, { code: "NOT_FOUND" });
  if (status && t.status !== status) throw new Refused(`That step is ${String(t.status).toLowerCase()} already, not waiting for a decision.`, 409, { code: "ALREADY_DECIDED", item: t._id });
  return t;
};
async function accept(db, i, actor, now) {
  const t = await taskOf(db, i.id, "Suggested");
  const due = i.due === void 0 ? t.due ?? null : dateOf(i.due, "due");
  await db.update(T.tasks, t._id, { status: "Open", due, owner: who(actor) });
  if (t.deal_id) await db.update(T.deals, t.deal_id, { next_step: t.title, next_step_due: due });
  return sent({ deal_id: t.deal_id || void 0, company_id: t.deal_id ? void 0 : t.company_id, next_step: t.title, due, draft_id: t.draft_id || void 0 });
}
async function dismiss(db, i) {
  const t = await taskOf(db, i.id, "Suggested");
  await db.update(T.tasks, t._id, { status: "Dismissed" });
  if (t.draft_id) await db.update(T.drafts, t.draft_id, { status: "Dropped" }, { status: "Review" });
  return { dismissed: t._id };
}
async function writeStep(db, deal, step, due, actor) {
  const title = text(step, 200);
  const day = dateOf(due, "next_step_due");
  for (const t of await db.all(`SELECT _id FROM ${T.tasks} WHERE _deleted = 0 AND deal_id = ? AND status = 'Open'`, [deal._id])) await db.update(T.tasks, t._id, { status: "Dismissed" });
  await db.insert(T.tasks, { title, due: day, deal_id: deal._id, contact_id: deal.contact_id ?? null, status: "Open", owner: who(actor), source: String(actor || "").startsWith("person:") ? "person" : "agent" });
  await db.update(T.deals, deal._id, { next_step: title, next_step_due: day });
  return { step: title, due: day };
}
async function set(db, i, actor) {
  const items2 = i.items ? listOf(i.items, "items") : [i];
  const out = { changed: [], skipped: [] };
  for (const [k, item] of items2.entries()) {
    try {
      const d = await dealOf(db, item.deal_id ?? item.id);
      if (d.status !== "Open") throw new Refused("The deal is closed: no next step.", 409, { code: "CLOSED", item: d._id });
      const step = text(item.step, 200);
      if (!step) throw new Refused("Say the step.", 400, { code: "BAD_INPUT", item: d._id });
      const w = await writeStep(db, d, step, item.due, actor);
      out.changed.push(d._id);
      if (!w.due) (out.no_date ??= []).push(d._id);
    } catch (e) {
      if (!(e instanceof Refused)) throw e;
      out.skipped.push({ index: k, code: e.code, error: e.message, ...e.item !== void 0 ? { item: e.item } : {} });
    }
  }
  return out;
}
async function done(db, i, actor, now) {
  if (!i.deal_id && i.company_id) {
    const c = await companyOf(db, i.company_id);
    const t = await db.one(`SELECT _id, title FROM ${T.tasks} WHERE _deleted = 0 AND company_id = ? AND deal_id IS NULL AND status = 'Open' ORDER BY _id DESC LIMIT 1`, [c._id]);
    if (!t) throw new Refused("This customer has no next step to mark done.", 409, { code: "NO_STEP", item: c._id });
    await db.update(T.tasks, t._id, { status: "Done", done_at: stamp(now) });
    await note(db, { company_id: c._id, contact_id: c.contact_id }, "task", `Hecho: ${t.title}`, text(i.note, 1500), actor, now);
    return { company_id: c._id, done: t.title };
  }
  const d = await dealOf(db, i.deal_id ?? i.id);
  const was = await db.one(`SELECT next_step FROM ${T.deals} WHERE _id = ?`, [d._id]);
  if (!was?.next_step) throw new Refused("The deal has no next step to mark done. next_step_set sets one.", 409, { code: "NO_STEP", item: d._id });
  for (const t of await db.all(`SELECT _id FROM ${T.tasks} WHERE _deleted = 0 AND deal_id = ? AND status = 'Open'`, [d._id])) await db.update(T.tasks, t._id, { status: "Done", done_at: stamp(now) });
  await db.update(T.deals, d._id, { next_step: null, next_step_due: null });
  await note(db, { deal_id: d._id, company_id: d.company_id, contact_id: d.contact_id }, "task", `Hecho: ${was.next_step}`, text(i.note, 1500), actor, now);
  return { deal_id: d._id, done: was.next_step };
}
var draftOf = async (db, id) => {
  const x = await db.one(`SELECT * FROM ${T.drafts} WHERE _deleted = 0 AND _id = ?`, [idOf(id)]);
  if (!x) throw new Refused(`There is no email ${id}.`, 404, { code: "NOT_FOUND" });
  return x;
};
async function draftUpdate(db, i) {
  const x = await draftOf(db, i.id);
  if (x.status !== "Review" && x.status !== "Failed") throw new Refused(`This email is ${String(x.status).toLowerCase()}: only one still to review can change. ${x.status === "Approved" ? "Take the approval back first (draft_drop) and write a new one." : ""}`.trim(), 409, { code: "NOT_EDITABLE", item: x._id });
  const data = sent({ subject: i.subject === void 0 ? void 0 : text(i.subject, 200), body: i.body === void 0 ? void 0 : text(i.body, 8e3), to_email: i.to === void 0 ? void 0 : normEmail(i.to) });
  if (data.to_email && !isEmail(data.to_email)) throw new Refused(`${data.to_email} is not an email address.`, 400, { code: "BAD_EMAIL" });
  if (x.status === "Failed") data.status = "Review";
  if (Object.keys(data).length) await db.update(T.drafts, x._id, data);
  return { id: x._id, status: data.status ?? x.status };
}
async function approve(db, i, actor, now) {
  const x = await draftOf(db, i.id);
  if (x.status !== "Review") throw new Refused(`This email is ${String(x.status).toLowerCase()}, not waiting for a yes.`, 409, { code: "ALREADY_DECIDED", item: x._id });
  if (!x.body || !x.to_email) throw new Refused("The email needs who it goes to and its text before it can go.", 400, { code: "INCOMPLETE", item: x._id });
  await db.update(T.drafts, x._id, { status: "Approved", approved_by: who(actor), approved_at: stamp(now) });
  return { id: x._id, status: "Approved" };
}
async function drop(db, i) {
  const x = await draftOf(db, i.id);
  if (x.status === "Sent") throw new Refused("This email has gone already: it is on the timeline.", 409, { code: "ALREADY_SENT", item: x._id });
  await db.update(T.drafts, x._id, { status: "Dropped" });
  return { id: x._id, status: "Dropped" };
}
async function sentMany(db, i, actor, now) {
  const out = { sent: [], failed: [], skipped: [] };
  for (const [k, item] of listOf(i.items, "items").entries()) {
    try {
      const x = await draftOf(db, item.id);
      if (x.status === "Sent") {
        out.skipped.push({ index: k, code: "ALREADY_SENT", error: "Said already.", item: x._id });
        continue;
      }
      if (x.status !== "Approved") throw new Refused("Nobody approved this email: it may not go. Ask the person to approve it in the CRM first.", 409, { code: "NOT_APPROVED", item: x._id });
      if (item.error) {
        await db.update(T.drafts, x._id, { status: "Failed", error: text(item.error, 400) });
        out.failed.push(x._id);
        continue;
      }
      await db.update(T.drafts, x._id, { status: "Sent", sent_at: stamp(now), gmail_message_id: text(item.message_id, 200) });
      const d = x.deal_id ? await db.one(`SELECT company_id FROM ${T.deals} WHERE _id = ?`, [x.deal_id]) : x.contact_id ? await db.one(`SELECT company_id FROM ${T.contacts} WHERE _id = ?`, [x.contact_id]) : null;
      await note(db, { deal_id: x.deal_id, contact_id: x.contact_id, company_id: d?.company_id }, "email_out", x.subject, x.body, actor, now);
      for (const t of await db.all(`SELECT _id FROM ${T.tasks} WHERE _deleted = 0 AND draft_id = ? AND status IN ('Open','Suggested')`, [x._id])) await db.update(T.tasks, t._id, { status: "Done", done_at: stamp(now) });
      out.sent.push(x._id);
    } catch (e) {
      if (!(e instanceof Refused)) throw e;
      out.skipped.push({ index: k, code: e.code, error: e.message, ...e.item !== void 0 ? { item: e.item } : {} });
    }
  }
  return out;
}
async function draft(db, i) {
  const x = await draftOf(db, i.id);
  const sig = (await settingsRow(db)).signature;
  return { id: x._id, status: x.status, to: x.to_email, subject: x.subject, body: x.body, signature: sig || void 0, deal_id: x.deal_id || void 0, error: x.error || void 0 };
}

// server/services/deals.mjs
var STATUS = { Open: ["open", "abierto"], Won: ["won", "ganado"], Lost: ["lost", "perdido"] };
async function rows(db, where, args, now = /* @__PURE__ */ new Date(), s = null) {
  s ??= await settingsRow(db);
  const list4 = await db.all(`SELECT d._id AS id, d.title, d.stage, d.status, d.kind, d.amount, d.recurring_amount, d.recurring_every, d.recurring_until, d.condition, d.currency, d.expected_close,
      d.next_step, d.next_step_due, d.stage_changed_at, d.closed_at, d.lost_reason, d.source, d.owner, d.notes, d.quote_state, d.quote_note, d.project_ref, d._created_at AS created_at,
      d.company_id, c.name AS company, d.contact_id, p.name AS contact, p.email AS contact_email,
      (SELECT MAX(a.at) FROM ${T.activities} a WHERE a._deleted = 0 AND COALESCE(a.removed,0) = 0 AND a.type NOT IN ('stage') AND (a.deal_id = d._id OR (d.contact_id IS NOT NULL AND a.contact_id = d.contact_id))) AS last_at,
      (SELECT COUNT(*) FROM ${T.tasks} t WHERE t._deleted = 0 AND t.deal_id = d._id AND t.status = 'Suggested') AS proposed
    FROM ${T.deals} d LEFT JOIN ${T.companies} c ON c._id = d.company_id LEFT JOIN ${T.contacts} p ON p._id = d.contact_id
    WHERE d._deleted = 0 AND COALESCE(d.removed,0) = 0 ${where ? "AND " + where : ""}`, args);
  const day = today(now, s.timezone);
  const order = new Map(s.stages.map((x) => [x.name, x.order]));
  const lines = await linesOf2(db, list4.map((d) => d.id));
  return list4.map((d) => {
    const ls = lines.get(d.id) ?? [];
    const v = ls.length ? valueOfLines(ls, d.currency || s.currency) : null;
    const since = [d.last_at, d.stage_changed_at, d.created_at].filter(Boolean).sort().pop();
    const quiet = since ? daysBetween(since, day) : 0;
    const late = !!(d.next_step_due && d.next_step_due < day && d.status === "Open");
    const ended = feeEnded(d, day);
    const lost = d.status === "Lost";
    const fee = v ? v.monthly : monthly(d.recurring_amount, d.recurring_every);
    const categories = [...new Set(ls.map((l) => l.category).filter(Boolean))];
    return { ...d, currency: d.currency || s.currency, lines: ls, value: v ? { once: v.once, per: v.per } : legacyValue(d), value_text: v ? v.text : legacyText(d, s.currency), categories, quiet_days: Math.max(0, quiet), stuck: d.status === "Open" && quiet >= s.stuck_days, late, monthly: ended || lost ? 0 : r2(fee), ...ended ? { fee_ended: true } : {}, stage_order: order.get(d.stage) ?? 99, probability: s.stages.find((x) => x.name === d.stage)?.probability ?? 0 };
  });
}
var legacyValue = (d) => ({ once: Number(d.amount) || 0, per: d.recurring_amount ? { [d.recurring_every || "month"]: Number(d.recurring_amount) } : {} });
var legacyText = (d, cur) => valueOfLines([...d.amount ? [{ kind: "once", price: d.amount }] : [], ...d.recurring_amount ? [{ kind: "recurring", price: d.recurring_amount, every: d.recurring_every || "month" }] : []], d.currency || cur).text;
var feeEnded = (d, day) => !!(d.recurring_amount && d.recurring_until && String(d.recurring_until).slice(0, 10) < day);
function byCurrency(list4, currency) {
  const mine = [];
  const other = /* @__PURE__ */ new Map();
  for (const d of list4) {
    const c = String(d.currency || currency).toUpperCase();
    if (c === String(currency).toUpperCase()) {
      mine.push(d);
      continue;
    }
    const o = other.get(c) ?? { currency: c, deals: 0, amount: 0, monthly: 0 };
    o.deals += 1;
    o.amount = r2(o.amount + (Number(d.amount) || 0));
    o.monthly = r2(o.monthly + (Number(d.monthly) || 0));
    other.set(c, o);
  }
  return { mine, other: [...other.values()] };
}
var brief = (d) => sent({ id: d.id, title: d.title, company: d.company || void 0, stage: d.stage, value: d.value_text !== "Sin importe" ? d.value_text : void 0, currency: d.currency && d.currency !== "EUR" ? d.currency : void 0, fee_until: d.recurring_until ? `${d.recurring_until}${d.fee_ended ? " (ended)" : ""}` : void 0, next_step: d.next_step || void 0, due: d.next_step_due || void 0, stuck: d.stuck || void 0, late: d.late || void 0, status: d.status === "Open" ? void 0 : d.status, closed_at: d.status === "Open" ? void 0 : d.closed_at || void 0, condition: d.condition || void 0 });
async function list2(db, i, full, now) {
  const s = await settingsRow(db);
  const where = [];
  const args = [];
  const status = i.status === "all" ? null : choiceOf(i.status ?? "open", STATUS, "status");
  if (status) {
    where.push("d.status = ?");
    args.push(status);
  }
  if (i.stage) {
    const st = stageNamed(s.stages, i.stage);
    if (!st) throw new Refused(`There is no stage \xAB${i.stage}\xBB. The stages: ${s.stages.map((x) => x.name).join(", ")}.`, 400, { code: "BAD_STAGE" });
    where.push("d.stage = ?");
    args.push(st.name);
  }
  const category = i.category ?? i.kind;
  if (i.company_id) {
    where.push("d.company_id = ?");
    args.push(idOf(i.company_id));
  }
  if (i.contact_id) {
    where.push("d.contact_id = ?");
    args.push(idOf(i.contact_id));
  }
  const q = String(i.q ?? "").trim();
  if (q && q !== "null" && q !== "undefined") {
    where.push(`(lower(d.title) LIKE ? OR lower(COALESCE(c.name,'')) LIKE ?)`);
    args.push(`%${q.toLowerCase()}%`, `%${q.toLowerCase()}%`);
  }
  let all = (await rows(db, where.join(" AND "), args, now, s)).sort((a, b) => a.stage_order - b.stage_order || String(b.closed_at || b.created_at).localeCompare(String(a.closed_at || a.created_at)));
  if (i.stuck === true || i.stuck === "true") all = all.filter((d) => d.stuck);
  if (category) all = all.filter((d) => d.categories.some((c) => fold(c) === fold(category)) || fold(d.kind ?? "") === fold(category));
  const limit = full ? 500 : Math.min(Number(i.limit) || 12, 100);
  const offset = Number(i.offset) || 0;
  return { total: all.length, rows: all.slice(offset, offset + limit).map((d) => full ? d : brief(d)), ...offset + limit < all.length ? { more: `${all.length - offset - limit} more: offset ${offset + limit}` } : {} };
}
async function pipeline(db, i, full, now) {
  const s = await settingsRow(db);
  const all = await rows(db, "", [], now, s);
  const open = all.filter((d) => d.status === "Open");
  const sum2 = (list4, k) => r2(list4.reduce((t, d) => t + (Number(d[k]) || 0), 0));
  const cur = (list4) => byCurrency(list4, s.currency);
  const [o, w, l] = [open, all.filter((d) => d.status === "Won"), all.filter((d) => d.status === "Lost")].map(cur);
  const conditional = w.mine.filter((d) => d.condition);
  const stages = openStages(s.stages).map((st) => {
    const here = open.filter((d) => d.stage === st.name);
    const mine = cur(here).mine;
    return sent({ stage: st.name, probability: st.probability, deals: here.length, amount: sum2(mine, "amount"), monthly: sum2(mine, "monthly"), stuck: here.filter((d) => d.stuck).length, ids: full ? void 0 : here.slice(0, 8).map((d) => d.id) });
  });
  const others = [["open", o], ["won", w], ["lost", l]].flatMap(([status, x]) => x.other.map((y) => ({ status, ...y })));
  const strays = open.filter((d) => !openStages(s.stages).some((st) => st.name === d.stage));
  return {
    currency: s.currency,
    categories: s.categories,
    sources: full ? s.sources : void 0,
    all_stages: full ? s.stages.map((x) => ({ name: x.name, outcome: x.outcome })) : void 0,
    stuck_days: s.stuck_days,
    stages,
    open: { deals: open.length, amount: sum2(o.mine, "amount"), monthly: sum2(o.mine, "monthly"), weighted: r2(o.mine.reduce((t, d) => t + (d.amount || 0) * d.probability / 100, 0)), stuck: open.filter((d) => d.stuck).length },
    won: sent({ deals: w.mine.length + w.other.reduce((t, x) => t + x.deals, 0), amount: sum2(w.mine, "amount"), monthly: sum2(w.mine, "monthly"), with_condition: conditional.length ? { deals: conditional.length, amount: sum2(conditional, "amount"), monthly: sum2(conditional, "monthly") } : void 0 }),
    lost: { deals: l.mine.length + l.other.reduce((t, x) => t + x.deals, 0), amount: sum2(l.mine, "amount") },
    ...others.length ? { other_currencies: others } : {},
    ...strays.length ? { other_stage: strays.map((d) => ({ id: d.id, stage: d.stage })) } : {}
  };
}
async function one(db, i, full, now) {
  const id = idOf(i.id);
  const [d] = await rows(db, "d._id = ?", [id], now);
  if (!d) throw new Refused(`There is no deal ${i.id}. deals lists them.`, 404, { code: "NOT_FOUND", item: id });
  const proposal = await db.one(`SELECT t._id AS id, t.title, t.due, t.why, t.draft_id FROM ${T.tasks} t WHERE t._deleted = 0 AND t.deal_id = ? AND t.status = 'Suggested' ORDER BY t._id DESC LIMIT 1`, [id]);
  const drafts = await db.all(`SELECT _id AS id, to_email, subject, body, status, error, sent_at, approved_by FROM ${T.drafts} WHERE _deleted = 0 AND deal_id = ? AND status IN ('Review','Approved','Failed') ORDER BY _id DESC`, [id]);
  const timeline = await list(db, { deal_id: id, limit: full ? 50 : 6 }, full);
  const documents = await dealDocuments(db, id);
  const svc = d.status === "Won" ? await serviceRows(db, "s.deal_id = ?", [id], today(now, (await settingsRow(db)).timezone)) : [];
  const out = { ...full ? d : brief(d), lines: full ? d.lines : d.lines.map(({ id: lid, item, name, quantity, price, discount, kind, every, start }) => sent({ id: lid, item, name: name !== item ? name : void 0, quantity: quantity !== 1 ? quantity : void 0, price, discount, kind: kind === "recurring" ? `every ${every}` : void 0, start })), services: svc.length ? full ? svc : svc.map((x) => sent({ id: x.id, name: x.name, amount: x.amount, every: x.every, start: x.start, state: x.state })) : void 0, quote_state: quoteStateOf(d, documents), contact: d.contact || void 0, contact_email: d.contact_email || void 0, company_id: d.company_id, contact_id: d.contact_id, quiet_days: d.quiet_days, quote: d.quote_state === "requested" ? sent({ requested: true, note: d.quote_note || void 0 }) : void 0, documents, project: d.project_ref || void 0, proposal: proposal ? sent({ ...proposal, draft_id: proposal.draft_id || void 0 }) : void 0, drafts: full ? drafts : drafts.map((x) => ({ id: x.id, status: x.status, subject: x.subject, to: x.to_email })), timeline: timeline.rows };
  if (full) {
    const peers = await db.peers().catch(() => null);
    out.unlocks = peers ? Object.fromEntries(peers.map((p) => [p.module, { installed: !!p.installed, name: p.name }])) : null;
    out.stages = (await settingsRow(db)).stages;
  }
  return out;
}
var DEAL_FIELDS = ["id", "title", "company", "company_id", "website", "contact", "contact_id", "email", "phone", "stage", "outcome", "kind", "lines", "amount", "currency", "recurring_amount", "recurring_every", "recurring_until", "expected_close", "closed_at", "stage_changed_at", "condition", "next_step", "next_step_due", "lost_reason", "source", "owner", "notes"];
var DEAL_ELSEWHERE = { project_ref: "deal_link", quote_ref: "refused: a quote is made in Facturas with deal_id", quote_state: "quote_request", quote_note: "quote_request", status: "say stage or outcome", probability: "each stage's, in settings", due: "next_step_due", step: "next_step", at: "timeline_add", summary: "timeline_add", type: "timeline_add" };
async function save(db, i, actor, now) {
  const s = await settingsRow(db);
  const out = { added: [], changed: [], unchanged: [], skipped: [] };
  for (const [k, item] of listOf(i.items, "items").entries()) {
    try {
      const r = await saveOne(db, item, s, actor, now);
      out[r.added ? "added" : r.wrote ? "changed" : "unchanged"].push(r.id);
    } catch (e) {
      if (!(e instanceof Refused)) throw e;
      out.skipped.push({ index: k, code: e.code, error: e.message, ...e.item !== void 0 ? { item: e.item } : {} });
    }
  }
  if (!out.unchanged.length) delete out.unchanged;
  return out;
}
var CURRENCY = /^[A-Z]{3}$/;
function currencyOf(v, s) {
  const c = (text(v, 10) || s.currency).toUpperCase();
  if (!CURRENCY.test(c)) throw new Refused(`currency is a three-letter code: EUR, USD, GBP (got "${String(v).slice(0, 10)}").`, 400, { code: "BAD_CURRENCY" });
  return c;
}
async function saveOne(db, item, s, actor, now) {
  if (!item || typeof item !== "object") throw new Refused("Each item is a deal: { id?, title, company, \u2026 }.", 400, { code: "BAD_INPUT" });
  onlyKnown(item, DEAL_FIELDS, "deals_save", DEAL_ELSEWHERE);
  const id = idOf(item.id);
  const was = id ? await db.one(`SELECT * FROM ${T.deals} WHERE ${LIVE} AND _id = ?`, [id]) : null;
  if (id && !was) throw new Refused(`There is no deal ${id}. deals lists them.`, 404, { code: "NOT_FOUND", item: id });
  const data = sent({
    title: item.title === void 0 ? void 0 : text(item.title, 200),
    kind: item.kind === void 0 ? void 0 : kindOf(item.kind, s),
    recurring_until: item.recurring_until === void 0 ? void 0 : dateOf(item.recurring_until, "recurring_until"),
    currency: item.currency === void 0 ? void 0 : currencyOf(item.currency, s),
    expected_close: item.expected_close === void 0 ? void 0 : dateOf(item.expected_close, "expected_close"),
    source: item.source === void 0 ? void 0 : text(item.source, 60),
    owner: item.owner === void 0 ? void 0 : text(item.owner, 120),
    notes: item.notes === void 0 ? void 0 : text(item.notes, 4e3),
    lost_reason: item.lost_reason === void 0 ? void 0 : text(item.lost_reason, 400)
  });
  const closedAt = item.closed_at === void 0 ? void 0 : dateOf(item.closed_at, "closed_at");
  const stageAt = item.stage_changed_at === void 0 ? void 0 : momentOf(item.stage_changed_at, now, "stage_changed_at");
  const condition = item.condition === void 0 ? void 0 : text(item.condition, 200);
  if (item.lines !== void 0 && (item.amount !== void 0 || item.recurring_amount !== void 0)) throw new Refused("Send lines, or amount / recurring_amount, not both: the lines are what the deal is worth.", 400, { code: "BAD_INPUT", item: id ?? void 0 });
  let lines = item.lines === void 0 ? void 0 : await cleanLines(db, item.lines);
  if (lines === void 0 && (item.amount !== void 0 || item.recurring_amount !== void 0 || item.recurring_every !== void 0)) lines = await legacyLines(db, was, item, data.kind ?? was?.kind, s);
  if (item.company !== void 0 || item.company_id !== void 0 || item.website !== void 0) data.company_id = await companyRef(db, { company_id: item.company_id, company: item.company, website: item.website, email: item.email }, { make: true, source: data.source });
  if (item.contact !== void 0 || item.contact_id !== void 0 || item.email !== void 0) data.contact_id = await contactRef(db, { contact_id: item.contact_id, contact: item.contact, email: item.email, phone: item.phone }, { make: true, company_id: data.company_id ?? was?.company_id ?? null, source: data.source });
  if (data.contact_id && !data.company_id && !was?.company_id) data.company_id = (await db.one(`SELECT company_id FROM ${T.contacts} WHERE _id = ?`, [data.contact_id]))?.company_id ?? void 0;
  const outcome = item.outcome ? choiceOf(item.outcome, { won: ["ganado", "won"], lost: ["perdido", "lost"] }, "outcome") : null;
  let stage = null;
  if (outcome) stage = outcomeStage(s.stages, outcome);
  else if (item.stage !== void 0 && item.stage !== null && item.stage !== "") {
    stage = stageNamed(s.stages, item.stage);
    if (!stage) throw new Refused(`There is no stage \xAB${item.stage}\xBB. The stages: ${s.stages.map((x) => x.name).join(", ")}.`, 400, { code: "BAD_STAGE" });
  }
  const after = stage ?? (was ? stageNamed(s.stages, was.stage) ?? { outcome: was.status === "Won" ? "won" : was.status === "Lost" ? "lost" : null } : openStages(s.stages)[0]);
  const day = today(now, s.timezone);
  if (closedAt && !after.outcome) throw new Refused("closed_at is the day a deal was won or lost: this one stays open. Send it with outcome (won | lost) or a closing stage.", 400, { code: "NOT_CLOSED", item: id ?? void 0 });
  if (closedAt && closedAt > day) throw new Refused(`closed_at ${closedAt} is in the future: a deal is closed on a day that has come.`, 400, { code: "BAD_DATE", item: id ?? void 0 });
  if (condition && after.outcome !== "won") throw new Refused("condition is for a won deal that still depends on something (\xABsi llega la subvenci\xF3n\xBB): move it to won with it, or leave it out.", 400, { code: "NOT_WON", item: id ?? void 0 });
  if (after.outcome && (item.next_step || item.next_step_due)) throw new Refused("A closed deal has no next step: next_step is for an open one.", 409, { code: "CLOSED", item: id ?? void 0 });
  if (condition !== void 0) data.condition = condition;
  if (!was) {
    if (!data.title) throw new Refused("A new deal needs a title: what is being sold (\xABWeb llevada por IA\xBB).", 400, { code: "BAD_INPUT" });
    if (!data.company_id && !data.contact_id) throw new Refused("A new deal needs its client: company (a name, made if new) or contact with email.", 400, { code: "NO_CLIENT" });
    stage ??= openStages(s.stages)[0];
    const closed = stage.outcome ? closedAt ?? day : null;
    const moved = stageAt ?? (closedAt ? `${closedAt} 12:00:00` : stamp(now));
    const nid = await db.insert(T.deals, { currency: s.currency, ...data, stage: stage.name, status: stage.outcome === "won" ? "Won" : stage.outcome === "lost" ? "Lost" : "Open", stage_changed_at: moved, closed_at: closed });
    if (lines?.length) await writeLines(db, nid, lines);
    if (stage.outcome === "won") await syncServices(db, nid);
    await note(db, { deal_id: nid, company_id: data.company_id, contact_id: data.contact_id }, "stage", `Nuevo negocio \xB7 ${stage.name}`, null, actor, now, closedAt ?? (stageAt ? moved : null));
    if (stage.outcome === "won" && data.contact_id) await db.update(T.contacts, data.contact_id, { status: "Customer" });
    if (!stage.outcome && item.next_step) await writeStep(db, { _id: nid, contact_id: data.contact_id ?? null }, item.next_step, item.next_step_due, actor);
    return { id: nid, added: true };
  }
  let wrote = false;
  if (stage && stage.name !== was.stage) {
    if (stage.outcome === "lost" && !data.lost_reason && !was.lost_reason) throw new Refused("A lost deal says why (lost_reason): \xABprecio\xBB, \xABse fue con otro\xBB, \xABlo dejan para m\xE1s adelante\xBB. It is what the next deal learns from.", 400, { code: "NEEDS_REASON", item: was._id });
    const moved = stageAt ?? (closedAt ? `${closedAt} 12:00:00` : stamp(now));
    Object.assign(data, { stage: stage.name, stage_changed_at: moved, status: stage.outcome === "won" ? "Won" : stage.outcome === "lost" ? "Lost" : "Open", closed_at: stage.outcome ? closedAt ?? day : null });
    if (stage.outcome) Object.assign(data, { next_step: null, next_step_due: null });
    if (stage.outcome !== "won") data.condition = null;
    await note(db, { deal_id: was._id, company_id: data.company_id ?? was.company_id, contact_id: data.contact_id ?? was.contact_id }, "stage", `${was.stage} \u2192 ${stage.name}`, stage.outcome === "lost" ? data.lost_reason ?? was.lost_reason : null, actor, now, closedAt ?? (stageAt ? moved : null));
    const cid = data.contact_id ?? was.contact_id;
    if (stage.outcome === "won" && cid) await db.update(T.contacts, cid, { status: "Customer" });
    if (stage.outcome) for (const t of await db.all(`SELECT _id, draft_id FROM ${T.tasks} WHERE _deleted = 0 AND deal_id = ? AND status IN ('Suggested','Open')`, [was._id])) {
      await db.update(T.tasks, t._id, { status: "Dismissed" });
      if (t.draft_id) await db.update(T.drafts, t.draft_id, { status: "Dropped" }, { status: "Review" });
    }
  } else {
    if (closedAt !== void 0) data.closed_at = closedAt;
    if (stageAt !== void 0) data.stage_changed_at = stageAt;
  }
  for (const k of Object.keys(data)) if (was[k] === data[k] || was[k] == null && data[k] == null) delete data[k];
  if (Object.keys(data).length) {
    await db.update(T.deals, was._id, data);
    wrote = true;
  }
  if (lines !== void 0 && await writeLines(db, was._id, lines)) wrote = true;
  if (wrote) {
    const sv = await syncServices(db, was._id);
    if (sv.made.length || sv.changed.length || sv.removed.length) wrote = true;
  }
  if (!after.outcome && (item.next_step !== void 0 || item.next_step_due !== void 0)) {
    const step = item.next_step !== void 0 ? item.next_step : was.next_step;
    const due = item.next_step_due !== void 0 ? item.next_step_due : item.next_step !== void 0 ? null : was.next_step_due;
    if (step === null || step === "") {
      if (was.next_step) {
        await db.update(T.deals, was._id, { next_step: null, next_step_due: null });
        for (const t of await db.all(`SELECT _id FROM ${T.tasks} WHERE _deleted = 0 AND deal_id = ? AND status = 'Open'`, [was._id])) await db.update(T.tasks, t._id, { status: "Dismissed" });
        wrote = true;
      }
    } else if (!step) throw new Refused("next_step_due dates a next step, and this deal has none: send next_step with it.", 400, { code: "NO_STEP", item: was._id });
    else if (text(step, 200) !== was.next_step || (dateOf(due, "next_step_due") ?? null) !== (was.next_step_due ?? null)) {
      await writeStep(db, was, step, due, actor);
      wrote = true;
    }
  }
  return { id: was._id, added: false, wrote };
}
function kindOf(v, s) {
  const k = text(v, 60);
  if (!k) return null;
  const known = [...s.categories, ...s.kinds].find((x) => x.toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "") === k.toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, ""));
  if (known) return known;
  throw new Refused(`\xAB${k}\xBB is not one of the categories in Ajustes: ${s.categories.join(", ")}. What a deal sells is its lines (items of \xABServicios y productos\xBB).`, 400, { code: "BAD_KIND" });
}
async function legacyLines(db, was, item, kind, s) {
  const have = was ? (await linesOf2(db, [was._id])).get(was._id) : [];
  const once = have.filter((l) => l.kind !== "recurring");
  const rec = have.filter((l) => l.kind === "recurring");
  if (item.amount !== void 0 && once.length > 1 || (item.recurring_amount !== void 0 || item.recurring_every !== void 0) && rec.length > 1) throw new Refused("This deal has several lines: send lines (the whole list) instead of amount / recurring_amount.", 409, { code: "HAS_LINES", item: was?._id });
  const pick2 = async () => {
    const named = kind ? await itemRef(db, kind).catch(() => null) : null;
    if (named) return named._id;
    const all = await db.all(`SELECT _id FROM ${T.items} WHERE _deleted = 0 AND COALESCE(archived,0) = 0`);
    return all.length === 1 ? all[0]._id : null;
  };
  const out = have.map((l) => ({ id: l.id, item_id: l.item_id ?? null, name: l.name ?? null, quantity: l.quantity, price: l.price, discount: l.discount ?? null, kind: l.kind, every: l.every ?? null, start: l.start ?? null, position: 0 }));
  const set2 = async (isRec, price, every) => {
    const at = out.findIndex((l) => l.kind === "recurring" === isRec);
    if (price === null) {
      if (at >= 0) out.splice(at, 1);
      return;
    }
    if (at >= 0) {
      Object.assign(out[at], { price, ...isRec ? { every: every ?? out[at].every } : {} });
      return;
    }
    out.push({ id: null, item_id: await pick2(), name: text(item.title, 200) ?? was?.title ?? null, quantity: 1, price, discount: null, kind: isRec ? "recurring" : "once", every: isRec ? every ?? "month" : null, start: null, position: 0 });
  };
  if (item.amount !== void 0) await set2(false, euros(item.amount, "amount") || null);
  if (item.recurring_amount !== void 0 || item.recurring_every !== void 0) {
    const every = item.recurring_every === void 0 ? void 0 : choiceOf(item.recurring_every, RECURRING, "recurring_every");
    const amt = item.recurring_amount === void 0 ? rec[0]?.price ?? null : euros(item.recurring_amount, "recurring_amount") || null;
    if (amt !== null || item.recurring_amount !== void 0) await set2(true, amt, every);
  }
  return out.map((l, k) => ({ ...l, position: k + 1 }));
}
async function remove2(db, i) {
  const d = await db.one(`SELECT _id FROM ${T.deals} WHERE ${LIVE} AND _id = ?`, [idOf(i.id)]);
  if (!d) throw new Refused(`There is no deal ${i.id}.`, 404, { code: "NOT_FOUND" });
  await db.update(T.deals, d._id, { removed: 1 });
  for (const x of await db.all(`SELECT _id FROM ${T.services} WHERE _deleted = 0 AND COALESCE(removed,0) = 0 AND deal_id = ? AND line_id IS NOT NULL`, [d._id])) await db.update(T.services, x._id, { removed: 1 });
  for (const t of await db.all(`SELECT _id FROM ${T.tasks} WHERE _deleted = 0 AND deal_id = ? AND status IN ('Suggested','Open')`, [d._id])) await db.update(T.tasks, t._id, { status: "Dismissed" });
  return { removed: d._id };
}
async function link(db, i) {
  const items2 = i.items ? listOf(i.items, "items") : [i];
  const out = { changed: [], skipped: [] };
  for (const [k, item] of items2.entries()) {
    const d = await db.one(`SELECT _id FROM ${T.deals} WHERE ${LIVE} AND _id = ?`, [idOf(item.deal_id)]);
    if (!d) {
      out.skipped.push({ index: k, code: "NOT_FOUND", error: `There is no deal ${item.deal_id}.` });
      continue;
    }
    if (item.quote_ref !== void 0 || item.quote_state !== void 0) {
      out.skipped.push({ index: k, code: "NOT_LINKED_BY_HAND", error: "A quote is not linked by hand any more: make it in Facturas with deal_id and it shows on the deal by itself, live." });
      continue;
    }
    const data = sent({ project_ref: item.project_ref === void 0 ? void 0 : text(item.project_ref, 80) });
    if (!Object.keys(data).length) {
      out.skipped.push({ index: k, code: "BAD_INPUT", error: "Send what was made: project_ref." });
      continue;
    }
    await db.update(T.deals, d._id, data);
    out.changed.push(d._id);
  }
  return out;
}
async function quoteRequest(db, i, actor, now) {
  const d = await db.one(`SELECT _id, status, company_id, contact_id FROM ${T.deals} WHERE ${LIVE} AND _id = ?`, [idOf(i.id)]);
  if (!d) throw new Refused(`There is no deal ${i.id}.`, 404, { code: "NOT_FOUND" });
  if (d.status !== "Open") throw new Refused("The deal is closed: a quote is for an open deal. Reopen it by moving it to an open stage first.", 409, { code: "CLOSED" });
  const peers = await db.peers().catch(() => null);
  const inv = peers?.find((p) => p.module === "invoices");
  if (inv && !inv.installed) throw new Refused("Invoices is not installed: the quote is made there. An admin installs it from M\xF3dulos \u203A Cat\xE1logo.", 409, { code: "NOT_INSTALLED" });
  await db.update(T.deals, d._id, { quote_state: "requested", quote_note: text(i.note, 1e3) });
  await note(db, { deal_id: d._id, company_id: d.company_id, contact_id: d.contact_id }, "task", "Presupuesto pedido", text(i.note, 1e3), actor, now);
  return { id: d._id, quote_state: "requested" };
}

// server/services/leads.mjs
var FIT = { good: ["encaja", "si", "yes", "buena"], maybe: ["quiza", "puede", "dudoso"], poor: ["no encaja", "no", "mala"] };
var STATES = { new: ["nueva", "nuevo"], qualified: ["calificada", "calificado"], accepted: ["aceptada", "negocio"], discarded: ["descartada", "descartado"] };
async function add2(db, i, actor, now) {
  const out = { added: [], already: [], skipped: [] };
  for (const [k, item] of listOf(i.items, "items").entries()) {
    try {
      const email = item.email ? normEmail(item.email) : null;
      if (email && !isEmail(email)) throw new Refused(`${item.email} is not an email address.`, 400, { code: "BAD_EMAIL" });
      const name = text(item.name, 200);
      if (!email && !name && !item.phone) throw new Refused("A lead needs someone to answer: a name, an email or a phone.", 400, { code: "BAD_INPUT" });
      const ref = text(item.source_ref, 200);
      const at = momentOf(item.received_at, now, "received_at");
      const same = ref ? await db.one(`SELECT _id FROM ${T.leads} WHERE _deleted = 0 AND source_ref = ?`, [ref]) : email ? await db.one(`SELECT _id FROM ${T.leads} WHERE _deleted = 0 AND lower(email) = ? AND substr(received_at,1,10) = ?`, [email, at.slice(0, 10)]) : null;
      if (same) {
        out.already.push(same._id);
        continue;
      }
      const answers = item.answers && typeof item.answers === "object" ? JSON.stringify(item.answers).slice(0, 8e3) : text(item.answers, 8e3);
      const lid = await db.insert(T.leads, { name, email, phone: text(item.phone, 40), company_name: text(item.company, 200), website: text(item.website, 300), message: text(item.message, 4e3), source: text(item.source, 60) || "Web", source_ref: ref, received_at: at, answers, state: "new", created_by: who(actor) });
      await takeIn(db, lid);
      out.added.push(lid);
    } catch (e) {
      if (!(e instanceof Refused)) throw e;
      out.skipped.push({ index: k, code: e.code, error: e.message });
    }
  }
  return out;
}
async function takeIn(db, leadId) {
  const l = await db.one(`SELECT * FROM ${T.leads} WHERE _id = ?`, [leadId]);
  if (!l || l.company_id) return l?.company_id ?? null;
  const by = { company: l.company_name || void 0, website: l.website || void 0, email: l.email || void 0 };
  const had = await matchCompany(db, by) ?? null;
  const company_id = had?.id ?? await companyRef(db, { ...by, company: l.company_name || l.name || l.email }, { make: true, source: l.source });
  const knew = l.email ? await db.one(`SELECT _id FROM ${T.contacts} WHERE ${LIVE} AND lower(email) = ?`, [l.email]) : null;
  const contact_id = l.name || l.email ? await contactRef(db, { email: l.email, name: l.name, phone: l.phone }, { make: true, company_id, source: l.source }) : null;
  if (contact_id && company_id && !(await db.one(`SELECT company_id FROM ${T.contacts} WHERE _id = ?`, [contact_id]))?.company_id) await db.update(T.contacts, contact_id, { company_id });
  await db.insert(T.activities, { type: "form", company_id, contact_id, at: l.received_at, subject: `Lead \xB7 ${l.source || "Web"}`, summary: text(l.message, 1500), external_id: `lead:${l._id}`, author: l.created_by || "agent" });
  await db.update(T.leads, l._id, { company_id, contact_id, made_company: had ? 0 : 1, made_contact: knew ? 0 : 1 });
  return company_id;
}
var row = (l, full) => full ? { ...l, answers: parse(l.answers) } : sent({ id: l.id, name: l.name || void 0, company: l.company_name || void 0, received: String(l.received_at).slice(0, 10), state: l.state, fit: l.fit || void 0, gist: l.message ? l.message.split("\n")[0].slice(0, 60) : void 0, deal_id: l.deal_id || void 0 });
var parse = (v) => {
  try {
    return v ? JSON.parse(v) : null;
  } catch {
    return v;
  }
};
async function list3(db, i, full) {
  const state = i.state && i.state !== "all" && i.state !== "open" ? choiceOf(i.state, STATES, "state") : null;
  const where = state ? "state = ?" : i.state === "all" ? "1 = 1" : `state IN ('new','qualified')`;
  const rows2 = await db.all(`SELECT _id AS id, name, email, phone, company_name, website, message, source, source_ref, received_at, answers, state, fit, qualification, proposed_kind, proposed_amount, proposed_recurring, qualified_at, decided_by, decided_at, discard_reason, contact_id, company_id, deal_id FROM ${T.leads} WHERE ${LIVE} AND ${where} ORDER BY received_at DESC, _id DESC`, state ? [state] : []);
  const counts = await db.all(`SELECT state, COUNT(*) AS n FROM ${T.leads} WHERE ${LIVE} GROUP BY state`);
  const limit = full ? 300 : Math.min(Number(i.limit) || 10, 100);
  return { counts: Object.fromEntries(counts.map((c) => [c.state, c.n])), total: rows2.length, rows: rows2.slice(0, limit).map((l) => row(l, full)), ...rows2.length > limit ? { more: `${rows2.length - limit} more: limit ${limit + 20}` } : {} };
}
async function one2(db, i) {
  const l = await db.one(`SELECT _id AS id, * FROM ${T.leads} WHERE ${LIVE} AND _id = ?`, [idOf(i.id)]);
  if (!l) throw new Refused(`There is no lead ${i.id}. leads lists them.`, 404, { code: "NOT_FOUND", item: idOf(i.id) });
  const known = l.email ? await db.one(`SELECT p._id AS id, p.name, c.name AS company FROM ${T.contacts} p LEFT JOIN ${T.companies} c ON c._id = p.company_id WHERE p._deleted = 0 AND lower(p.email) = ?`, [l.email]) : null;
  const { _id, _created_at, _updated_at, _deleted, removed, ...rest } = l;
  return { ...rest, answers: parse(l.answers), known_contact: known || void 0 };
}
async function qualify(db, i, actor, now) {
  const s = await settingsRow(db);
  const out = { qualified: [], skipped: [] };
  for (const [k, item] of listOf(i.items, "items").entries()) {
    try {
      const l = await db.one(`SELECT _id, state FROM ${T.leads} WHERE ${LIVE} AND _id = ?`, [idOf(item.id)]);
      if (!l) throw new Refused(`There is no lead ${item.id}.`, 404, { code: "NOT_FOUND", item: idOf(item.id) });
      if (l.state === "accepted" || l.state === "discarded") throw new Refused("A person decided this lead already.", 409, { code: "ALREADY_DECIDED", item: l._id });
      const summary = text(item.summary ?? item.why, 1200);
      if (!summary) throw new Refused("Say why, in two or three lines: who they are, what they want, whether it fits what the company sells.", 400, { code: "BAD_INPUT", item: l._id });
      const kind = item.kind ? s.kinds.find((x) => fold(x) === fold(item.kind)) : null;
      if (item.kind && !kind) throw new Refused(`\xAB${item.kind}\xBB is not a kind of service in Ajustes: ${s.kinds.join(", ")}.`, 400, { code: "BAD_KIND", item: l._id });
      await db.update(T.leads, l._id, sent({ fit: choiceOf(item.fit, FIT, "fit") ?? "maybe", qualification: summary, proposed_kind: kind ?? void 0, proposed_amount: item.amount === void 0 ? void 0 : euros(item.amount), proposed_recurring: item.recurring_amount === void 0 ? void 0 : euros(item.recurring_amount, "recurring_amount"), company_name: item.company === void 0 ? void 0 : text(item.company, 200), website: item.website === void 0 ? void 0 : text(item.website, 300), state: "qualified", qualified_at: stamp(now) }));
      out.qualified.push(l._id);
    } catch (e) {
      if (!(e instanceof Refused)) throw e;
      out.skipped.push({ index: k, code: e.code, error: e.message, ...e.item !== void 0 ? { item: e.item } : {} });
    }
  }
  return out;
}
var openLead = async (db, id) => {
  const l = await db.one(`SELECT * FROM ${T.leads} WHERE ${LIVE} AND _id = ?`, [idOf(id)]);
  if (!l) throw new Refused(`There is no lead ${id}.`, 404, { code: "NOT_FOUND" });
  if (l.state === "accepted") throw new Refused("This lead is a deal already.", 409, { code: "ALREADY_A_DEAL", item: l.deal_id });
  if (l.state === "discarded") throw new Refused("This lead was discarded. lead_reopen brings it back to decide again.", 409, { code: "ALREADY_DECIDED", item: l._id });
  return l;
};
async function accept2(db, i, actor, now) {
  const s = await settingsRow(db);
  const l = await openLead(db, i.id);
  if (!l.company_id && !i.company_id) await takeIn(db, l._id);
  const lead = await db.one(`SELECT company_id, contact_id FROM ${T.leads} WHERE _id = ?`, [l._id]);
  const company_id = i.company_id ? await companyRef(db, { company_id: i.company_id }) : lead.company_id ?? await companyRef(db, { company: i.company ?? l.company_name, website: l.website, email: l.email }, { make: true, source: l.source });
  const contact_id = lead.contact_id ?? await contactRef(db, { email: l.email, name: l.name, phone: l.phone }, { make: true, company_id, source: l.source });
  if (!company_id && !contact_id) throw new Refused("The lead has no name, email or company to make a client from: add them first.", 400, { code: "NO_CLIENT" });
  if (contact_id && company_id && !(await db.one(`SELECT company_id FROM ${T.contacts} WHERE _id = ?`, [contact_id]))?.company_id) await db.update(T.contacts, contact_id, { company_id });
  const stage = i.stage ? stageNamed(s.stages, i.stage) : openStages(s.stages)[Math.min(1, openStages(s.stages).length - 1)];
  if (!stage) throw new Refused(`There is no stage \xAB${i.stage}\xBB.`, 400, { code: "BAD_STAGE" });
  const title = text(i.title, 200) || [l.proposed_kind, l.company_name || l.name].filter(Boolean).join(" \xB7 ") || "Nuevo negocio";
  const sold = i.lines !== void 0 ? { lines: i.lines } : i.amount ?? l.proposed_amount ?? i.recurring_amount ?? l.proposed_recurring ? { amount: i.amount ?? l.proposed_amount ?? void 0, recurring_amount: i.recurring_amount ?? l.proposed_recurring ?? void 0, recurring_every: i.recurring_amount ?? l.proposed_recurring ? ["month", "quarter", "year"].includes(i.recurring_every) ? i.recurring_every : "month" : void 0 } : {};
  let r = await save(db, { items: [{ title, company_id: company_id ?? void 0, contact_id: contact_id ?? void 0, stage: stage.name, kind: i.kind ?? l.proposed_kind ?? void 0, ...sold, source: l.source }] }, actor, now);
  if (r.skipped.length && r.skipped[0].code === "NO_ITEM" && i.lines === void 0) r = await save(db, { items: [{ title, company_id: company_id ?? void 0, contact_id: contact_id ?? void 0, stage: stage.name, source: l.source }] }, actor, now);
  if (r.skipped.length) throw new Refused(r.skipped[0].error, 400, { code: r.skipped[0].code });
  const deal_id = r.added[0];
  const said2 = await db.one(`SELECT _id FROM ${T.activities} WHERE _deleted = 0 AND external_id = ?`, [`lead:${l._id}`]);
  if (said2) await db.update(T.activities, said2._id, { deal_id, summary: text([l.message, l.qualification ? `Lectura del agente: ${l.qualification}` : null].filter(Boolean).join("\n\n"), 1500) });
  else await note(db, { deal_id, contact_id, company_id }, "form", `Lead \xB7 ${l.source || "Web"}`, [l.message, l.qualification ? `Lectura del agente: ${l.qualification}` : null].filter(Boolean).join("\n\n") || null, actor, now, l.received_at);
  await db.update(T.leads, l._id, { state: "accepted", decided_by: who(actor), decided_at: stamp(now), contact_id, company_id, deal_id });
  return { lead_id: l._id, deal_id, company_id, contact_id };
}
async function discard(db, i, actor, now) {
  const l = await openLead(db, i.id);
  await db.update(T.leads, l._id, { state: "discarded", discard_reason: text(i.reason, 300) || "Sin motivo", decided_by: who(actor), decided_at: stamp(now) });
  const archived = [];
  const only = async (col, id) => !await db.one(`SELECT _id FROM ${T.deals} WHERE _deleted = 0 AND ${col} = ? LIMIT 1`, [id]) && !await db.one(`SELECT _id FROM ${T.leads} WHERE _deleted = 0 AND ${col} = ? AND _id <> ? AND state <> 'discarded' LIMIT 1`, [id, l._id]);
  if (Number(l.made_contact) && l.contact_id && await only("contact_id", l.contact_id)) {
    await db.update(T.contacts, l.contact_id, { removed: 1 });
    archived.push("contact");
  }
  if (Number(l.made_company) && l.company_id && await only("company_id", l.company_id) && !await db.one(`SELECT _id FROM ${T.contacts} WHERE ${LIVE} AND company_id = ? LIMIT 1`, [l.company_id])) {
    await db.update(T.companies, l.company_id, { removed: 1 });
    archived.push("company");
  }
  return sent({ lead_id: l._id, state: "discarded", archived: archived.length ? archived : void 0 });
}
async function reopen(db, i) {
  const l = await db.one(`SELECT _id, state, qualification FROM ${T.leads} WHERE ${LIVE} AND _id = ?`, [idOf(i.id)]);
  if (!l) throw new Refused(`There is no lead ${i.id}.`, 404, { code: "NOT_FOUND" });
  if (l.state !== "discarded") throw new Refused("Only a discarded lead comes back.", 409, { code: "NOT_DISCARDED", item: l._id });
  await db.update(T.leads, l._id, { state: l.qualification ? "qualified" : "new", discard_reason: null, decided_by: null, decided_at: null });
  const back = await db.one(`SELECT company_id, contact_id, made_company, made_contact FROM ${T.leads} WHERE _id = ?`, [l._id]);
  if (back?.company_id && Number(back.made_company)) await db.update(T.companies, back.company_id, { removed: 0 });
  if (back?.contact_id && Number(back.made_contact)) await db.update(T.contacts, back.contact_id, { removed: 0 });
  return { lead_id: l._id };
}

// server/services/upgrade.mjs
var VERSION = "0.5.0";
function upgradePlan(row2) {
  if (!row2) return null;
  if (row2.installed_version === VERSION) return null;
  const plan = { rename: {}, data: { installed_version: VERSION }, to05: !/^0\.5\./.test(String(row2.installed_version ?? "")) };
  const stages = stagesOf(row2.stages);
  const legacy = stages.length === 7 && stages.every((s) => LEGACY_STAGE_NAMES[s.name]);
  if (legacy) {
    plan.rename = Object.fromEntries(stages.map((s) => [s.name, LEGACY_STAGE_NAMES[s.name]]));
    plan.data.stages = JSON.stringify(stages.map((s) => ({ name: LEGACY_STAGE_NAMES[s.name], probability: s.probability, outcome: s.outcome ?? void 0 })));
  }
  if (!row2.kinds) plan.data.kinds = DEFAULTS.kinds;
  if (!row2.sources || /HubSpot|Outbound/.test(row2.sources)) plan.data.sources = DEFAULTS.sources;
  if (plan.to05 && !row2.categories) plan.data.categories = linesOf(plan.data.kinds ?? row2.kinds).join("\n");
  return plan;
}
function kindItems(kinds, deals) {
  return kinds.map((k) => {
    const mine = deals.filter((d) => String(d.kind ?? "") === k && (Number(d.amount) > 0 || Number(d.recurring_amount) > 0));
    const onlyFee = mine.length > 0 && mine.every((d) => !(Number(d.amount) > 0) && Number(d.recurring_amount) > 0);
    const rhythms = mine.filter((d) => Number(d.recurring_amount) > 0).map((d) => d.recurring_every || "month");
    const every = ["month", "quarter", "year"].sort((a, b) => rhythms.filter((x) => x === b).length - rhythms.filter((x) => x === a).length)[0];
    return onlyFee ? { name: k, category: k, kind: "recurring", every, renewal: "auto", from_kind: k } : { name: k, category: k, kind: "once", from_kind: k };
  });
}
function dealLines(d, itemId) {
  const out = [];
  if (Number(d.amount) > 0) out.push({ id: null, item_id: itemId, name: d.title ?? null, quantity: 1, price: Number(d.amount), discount: null, kind: "once", every: null, start: null });
  if (Number(d.recurring_amount) > 0) out.push({ id: null, item_id: itemId, name: d.title ?? null, quantity: 1, price: Number(d.recurring_amount), discount: null, kind: "recurring", every: ["month", "quarter", "year"].includes(d.recurring_every) ? d.recurring_every : "month", start: d.status === "Won" ? d.closed_at ?? null : null });
  return out.map((l, k) => ({ ...l, position: k + 1 }));
}
async function to05(db, row2) {
  const kinds = linesOf(row2.kinds || DEFAULTS.kinds);
  const deals = await db.all(`SELECT * FROM ${T.deals} WHERE ${LIVE}`);
  const usedKinds = [.../* @__PURE__ */ new Set([...kinds, ...deals.map((d) => d.kind).filter(Boolean)])];
  const existing = await db.all(`SELECT _id, name, from_kind FROM ${T.items} WHERE _deleted = 0`);
  const itemOf = new Map(existing.filter((x) => x.from_kind).map((x) => [x.from_kind, x._id]));
  for (const it of kindItems(usedKinds, deals)) if (!itemOf.has(it.name)) itemOf.set(it.name, await db.insert(T.items, { ...it, archived: 0 }));
  for (const d of deals) {
    if (await db.one(`SELECT _id FROM ${T.lines} WHERE _deleted = 0 AND deal_id = ? LIMIT 1`, [d._id])) continue;
    const lines = dealLines(d, d.kind ? itemOf.get(d.kind) ?? null : null);
    if (!lines.length) continue;
    await writeLines(db, d._id, lines);
    if (d.status === "Won") await syncServices(db, d._id);
  }
  for (const l of await db.all(`SELECT _id FROM ${T.leads} WHERE ${LIVE} AND state IN ('new','qualified') AND company_id IS NULL`)) await takeIn(db, l._id);
}
var runs = /* @__PURE__ */ new WeakMap();
function ensureUpgraded(db) {
  if (runs.has(db)) return runs.get(db);
  const done2 = (async () => {
    const row2 = await db.one(`SELECT * FROM ${T.settings} WHERE _deleted = 0 ORDER BY _id LIMIT 1`);
    const plan = upgradePlan(row2);
    if (!plan) return;
    for (const [from, to] of Object.entries(plan.rename)) {
      for (const d of await db.all(`SELECT _id FROM ${T.deals} WHERE ${LIVE} AND stage = ?`, [from])) await db.update(T.deals, d._id, { stage: to });
    }
    for (const c of await db.all(`SELECT _id FROM ${T.companies} WHERE ${LIVE} AND main_contact_id IS NULL`)) await ensureMainContact(db, c._id);
    if (plan.to05) await to05(db, { ...row2, ...plan.data });
    await db.update(T.settings, row2._id, plan.data);
  })().catch((e) => {
    runs.delete(db);
    throw e;
  });
  runs.set(db, done2);
  return done2;
}

// server/services/today.mjs
async function today2(db, i, full, now) {
  const s = await settingsRow(db);
  const d0 = today(now, s.timezone);
  const leads = await db.all(`SELECT _id AS id, name, email, company_name, company_id, source, received_at, state, fit, qualification, proposed_kind, proposed_amount, proposed_recurring, message FROM ${T.leads} WHERE ${LIVE} AND state IN ('new','qualified') ORDER BY received_at DESC`);
  const proposals = await db.all(`SELECT t._id AS id, t.title, t.due, t.why, t.deal_id, t.draft_id, d.title AS deal, c.name AS company, x.subject, x.to_email, x.body FROM ${T.tasks} t JOIN ${T.deals} d ON d._id = t.deal_id AND d._deleted = 0 AND COALESCE(d.removed,0) = 0 AND d.status = 'Open' LEFT JOIN ${T.companies} c ON c._id = d.company_id LEFT JOIN ${T.drafts} x ON x._id = t.draft_id WHERE t._deleted = 0 AND t.status = 'Suggested' ORDER BY t.due, t._id`);
  const emails = await db.all(`SELECT x._id AS id, x.status, x.subject, x.to_email, x.deal_id, x.error, d.title AS deal, c.name AS company FROM ${T.drafts} x LEFT JOIN ${T.deals} d ON d._id = x.deal_id LEFT JOIN ${T.companies} c ON c._id = d.company_id WHERE x._deleted = 0 AND x.status IN ('Review','Approved','Failed') AND x._id NOT IN (SELECT draft_id FROM ${T.tasks} WHERE _deleted = 0 AND status = 'Suggested' AND draft_id IS NOT NULL) ORDER BY x._id DESC`);
  const open = await rows(db, `d.status = 'Open'`, [], now, s);
  const late = open.filter((d) => d.late).sort((a, b) => a.next_step_due.localeCompare(b.next_step_due));
  const dueSoon = open.filter((d) => d.next_step_due && !d.late && d.next_step_due <= addDaysIso(d0, 7)).sort((a, b) => a.next_step_due.localeCompare(b.next_step_due));
  const stuck = open.filter((d) => d.stuck && !d.late && !d.proposed).sort((a, b) => b.quiet_days - a.quiet_days);
  const noStep = open.filter((d) => !d.next_step && !d.proposed && !d.stuck);
  const quotes = await withoutQuote(db, open.filter((d) => d.quote_state === "requested"));
  const cf = await facts(db, null, now);
  const names = new Map((await db.all(`SELECT _id, name FROM ${T.companies} WHERE _deleted = 0`)).map((r) => [r._id, r.name]));
  const companyTasks = await db.all(`SELECT t._id AS id, t.title, t.due, t.why, t.status, t.company_id, t.draft_id, x.subject, x.to_email, x.body FROM ${T.tasks} t LEFT JOIN ${T.drafts} x ON x._id = t.draft_id WHERE t._deleted = 0 AND t.deal_id IS NULL AND t.company_id IS NOT NULL AND t.status IN ('Suggested','Open') ORDER BY t.due, t._id`);
  const atRisk2 = [...cf].filter(([, x]) => x.risks.length).map(([id, x]) => ({ id, name: names.get(id), monthly: x.monthly, risks: x.risks, proposal: companyTasks.find((t) => t.company_id === id && t.status === "Suggested") ?? void 0, step: companyTasks.find((t) => t.company_id === id && t.status === "Open") ?? void 0 }));
  const recurring = Math.round([...cf.values()].reduce((t, x) => t + (x.monthly || 0), 0) * 100) / 100;
  const stages = [...cf.values()].reduce((o, x) => ({ ...o, [x.stage]: (o[x.stage] || 0) + 1 }), {});
  const counts = {
    leads_to_decide: leads.filter((l) => l.state === "qualified").length,
    leads_to_qualify: leads.filter((l) => l.state === "new").length,
    steps_proposed: proposals.length,
    emails_to_review: emails.filter((e) => e.status === "Review").length + proposals.filter((p) => p.draft_id).length,
    emails_to_send: emails.filter((e) => e.status === "Approved").length,
    emails_failed: emails.filter((e) => e.status === "Failed").length,
    steps_late: late.length,
    due_this_week: dueSoon.length,
    stuck: stuck.length,
    no_step: noStep.length,
    quotes_to_make: quotes.length,
    open_deals: open.length,
    at_risk: atRisk2.length,
    customers: stages.customer || 0,
    leads: stages.lead || 0,
    customer_proposals: companyTasks.filter((t) => t.status === "Suggested").length,
    items: Number((await db.one(`SELECT COUNT(*) AS n FROM ${T.items} WHERE _deleted = 0 AND COALESCE(archived,0) = 0`))?.n ?? 0),
    ...await places(db)
  };
  const cur = byCurrency(open, s.currency);
  const figures = sent({ recurring, open_amount: sum(cur.mine, "amount"), open_monthly: sum(cur.mine, "monthly"), weighted: Math.round(cur.mine.reduce((t, d) => t + (d.amount || 0) * d.probability / 100, 0)), currency: s.currency, other_currencies: cur.other.length ? cur.other : void 0 });
  const agent = [
    ...leads.filter((l) => l.state === "new").map((l) => ({ do: "leads_qualify", lead_id: l.id, text: `Qualify lead ${l.name || l.email || l.company_name} (${l.source || "web"})`, es: `Leer el lead de ${l.name || l.email || l.company_name}` })),
    ...emails.filter((e) => e.status === "Approved").map((e) => ({ do: "send approved email, then drafts_sent", draft_id: e.id, text: `Send \xAB${e.subject}\xBB to ${e.to_email}`, es: `Enviar \xAB${e.subject}\xBB a ${e.to_email}` })),
    ...quotes.map((d) => ({ do: "make the quote in Facturas with deal_id (it shows on the deal by itself)", deal_id: d.id, text: `Quote for ${d.title}`, es: `Preparar el presupuesto del ${lower(dealName(d.title, d.company || d.contact))}` })),
    ...atRisk2.filter((c) => !c.proposal && !c.step).map((c) => ({ do: "next_steps_propose with company_id", company_id: c.id, text: `Customer at risk: ${c.name} (${c.risks.map((r) => r.kind).join(", ")})`, es: `Proponer qu\xE9 hacer con ${c.name}: ${c.risks[0].text.charAt(0).toLowerCase() + c.risks[0].text.slice(1)}` })),
    ...[...stuck, ...noStep].map((d) => ({ do: "next_steps_propose", deal_id: d.id, text: `${d.title}: ${d.stuck ? `${d.quiet_days} days without news` : "no next step"}`, es: `Proponer el siguiente paso del ${lower(dealName(d.title, d.company || d.contact))}` }))
  ];
  if (!full) return { today: d0, counts, figures, agent: agent.slice(0, 12).map(({ es, ...a }) => a), ...agent.length > 12 ? { more: `${agent.length - 12} more: full: true` } : {}, person: [...leads.filter((l) => l.state === "qualified").slice(0, 5).map((l) => `lead ${l.id} ${l.name || l.company_name}: to answer (lead_accept opens a sale, or lead_discard)`), ...atRisk2.slice(0, 5).map((c) => `customer ${c.id} ${c.name} at risk: ${c.risks.map((r) => r.text).join("; ")}`), ...late.slice(0, 5).map((d) => `deal ${d.id} \xAB${dealName(d.title, d.company || d.contact)}\xBB: \xAB${d.next_step}\xBB was due ${d.next_step_due}`)] };
  const renewals = [...cf].flatMap(([id, x]) => x.services.filter((v) => v.next_renewal || v.state === "ending" && v.ends).map((v) => ({ id: v.id, company_id: id, company: names.get(id), name: v.name, amount: v.amount, every: v.every, on: v.next_renewal ?? v.ends, ends: v.state === "ending", renewal: v.renewal }))).filter((v) => v.on <= addDaysIso(d0, 60)).sort((a, b) => a.on.localeCompare(b.on));
  return { today: d0, counts, figures, leads, proposals, emails, late: late.map(pick), due_soon: dueSoon.map(pick), stuck: stuck.map(pick), no_step: noStep.map(pick), quotes: quotes.map(pick), at_risk: atRisk2, renewals, agent };
}
async function places(db) {
  const live = `_deleted = 0 AND COALESCE(removed,0) = 0`;
  const co = await db.one(`SELECT COUNT(*) AS n, SUM(CASE WHEN EXISTS (SELECT 1 FROM ${T.deals} d WHERE d._deleted = 0 AND COALESCE(d.removed,0) = 0 AND d.status = 'Open' AND d.company_id = c._id) THEN 1 ELSE 0 END) AS open FROM ${T.companies} c WHERE c._deleted = 0 AND COALESCE(c.removed,0) = 0`);
  const pe = await db.one(`SELECT COUNT(*) AS n, SUM(CASE WHEN COALESCE(email,'') = '' THEN 1 ELSE 0 END) AS no_email FROM ${T.contacts} WHERE ${live} AND COALESCE(status,'') NOT IN ('Suggested','Ignored')`);
  return { companies: co?.n || 0, companies_open: co?.open || 0, contacts: pe?.n || 0, contacts_no_email: pe?.no_email || 0 };
}
var pick = (d) => sent({ id: d.id, title: d.title, company: d.company, contact: d.contact, stage: d.stage, value_text: d.value_text, amount: d.amount, monthly: d.monthly || void 0, next_step: d.next_step, next_step_due: d.next_step_due, quiet_days: d.quiet_days, stuck: d.stuck || void 0, late: d.late || void 0 });
var lower = (name) => name.charAt(0).toLowerCase() + name.slice(1);
var sum = (rows2, k) => Math.round(rows2.reduce((t, d) => t + (Number(d[k]) || 0), 0) * 100) / 100;
var addDaysIso = (date, n) => new Date(Date.parse(date + "T00:00:00Z") + n * 864e5).toISOString().slice(0, 10);
async function leadsToQualify(db) {
  const rows2 = await db.all(`SELECT _id AS id, name, email, company_name, source FROM ${T.leads} WHERE ${LIVE} AND state = 'new' ORDER BY received_at`);
  return { items: rows2.map((l) => ({ key: `lead:${l.id}`, text: `${l.name || l.email || l.company_name} (${l.source || "web"})`, lead_id: l.id, email: l.email ?? void 0, company: l.company_name ?? void 0 })) };
}
async function dealsNeedingStep(db, now) {
  const open = await rows(db, `d.status = 'Open'`, [], now);
  return { items: open.filter((d) => !d.proposed && (!d.next_step || d.late || d.stuck)).map((d) => ({ key: `deal:${d.id}:${d.next_step_due || "none"}`, text: `${d.title} (${d.company || d.contact || ""}): ${d.late ? `\xAB${d.next_step}\xBB due ${d.next_step_due}` : d.stuck ? `${d.quiet_days} days without news` : "no next step"}`, deal_id: d.id, why: d.late ? "late" : d.stuck ? "stuck" : "no_step" })) };
}
async function emailsToSend(db) {
  const rows2 = await db.all(`SELECT _id AS id, to_email, subject, deal_id FROM ${T.drafts} WHERE _deleted = 0 AND status = 'Approved' ORDER BY approved_at`);
  return { items: rows2.map((x) => ({ key: `draft:${x.id}`, text: `\xAB${x.subject}\xBB to ${x.to_email}`, draft_id: x.id, deal_id: x.deal_id ?? void 0 })) };
}
async function withoutQuote(db, deals) {
  const out = [];
  for (const d of deals) if (!(await dealDocuments(db, d.id)).some((x) => x.kind === "quote" || x.kind === "Presupuesto")) out.push(d);
  return out;
}
async function quotesToMake(db) {
  const rows2 = await withoutQuote(db, await db.all(`SELECT d._id AS id, d.title, d.kind, d.amount, d.recurring_amount, d.recurring_every, d.quote_note, c.name AS company FROM ${T.deals} d LEFT JOIN ${T.companies} c ON c._id = d.company_id WHERE d._deleted = 0 AND COALESCE(d.removed,0) = 0 AND d.status = 'Open' AND d.quote_state = 'requested'`));
  const lines = await linesOf2(db, rows2.map((d) => d.id));
  return { items: rows2.map((d) => sent({ key: `quote:${d.id}`, text: `Quote for ${d.title} (${d.company || ""})`, deal_id: d.id, company: d.company, value: (lines.get(d.id) ?? []).length ? valueOfLines(lines.get(d.id)).text : void 0, amount: d.amount, recurring_amount: d.recurring_amount, recurring_every: d.recurring_every, note: d.quote_note })) };
}
async function wonWithoutProject(db) {
  const peers = await db.peers().catch(() => null);
  if (!peers?.some((p) => p.module === "proyectos" && p.installed)) return { items: [] };
  const rows2 = await db.all(`SELECT d._id AS id, d.title, d.kind, d.amount, d.recurring_amount, d.recurring_every, d.closed_at, c.name AS company FROM ${T.deals} d LEFT JOIN ${T.companies} c ON c._id = d.company_id WHERE d._deleted = 0 AND COALESCE(d.removed,0) = 0 AND d.status = 'Won' AND COALESCE(d.project_ref,'') = ''`);
  return { items: rows2.map((d) => sent({ key: `won:${d.id}`, text: `${d.title} (${d.company || ""}) won ${d.closed_at || ""}`, deal_id: d.id, company: d.company, kind: d.kind, amount: d.amount, recurring_amount: d.recurring_amount, recurring_every: d.recurring_every })) };
}
async function clients(db, i) {
  const q = String(i.q ?? "").trim().toLowerCase();
  const rows2 = await db.all(`SELECT c._id AS id, c.name, c.legal_name, c.domain, c.website, c.tax_id, c.address, c.phone, c.main_contact_id
    FROM ${T.companies} c WHERE c._deleted = 0 AND COALESCE(c.removed,0) = 0 ${q ? "AND lower(c.name) LIKE ?" : ""} ORDER BY c.name LIMIT 200`, q ? [`%${q}%`] : []);
  const people = await mainPeople(db, rows2.map((r) => r.id));
  return { rows: rows2.map((r) => {
    const p = people.get(r.id);
    return sent({ ...r, main_contact_id: r.main_contact_id || void 0, domain: r.domain || void 0, website: r.website || void 0, legal_name: r.legal_name || void 0, tax_id: r.tax_id || void 0, address: r.address || void 0, phone: r.phone || void 0, contact: p?.name || void 0, email: p?.email || void 0 });
  }) };
}
async function wonDeals(db, i) {
  const rows2 = await db.all(`SELECT d._id AS id, d.title, d.kind, d.amount, d.recurring_amount, d.recurring_every, d.recurring_until, d.condition, d.currency, d.closed_at, d.company_id, c.name AS company, d.project_ref FROM ${T.deals} d LEFT JOIN ${T.companies} c ON c._id = d.company_id WHERE d._deleted = 0 AND COALESCE(d.removed,0) = 0 AND d.status = 'Won' ${i.since ? "AND d.closed_at >= ?" : ""} ORDER BY d.closed_at DESC LIMIT 200`, i.since ? [String(i.since)] : []);
  return { rows: rows2.map((r) => sent(Object.fromEntries(Object.entries(r).map(([k, v]) => [k, v ?? void 0])))) };
}

// server/routes/crm.mjs
var LINES = "lines (the WHOLE list; what is left out is taken away): [{ id? (to keep a line), item (a name of \xABServicios y productos\xBB, or item_id), name (what this line says, if not the item's), quantity (1), price (the item's unless said), discount (%), every (month | quarter | year, a recurring item's rhythm), start (YYYY-MM-DD, a recurring line's first day) }]";
var DEAL = `title, company (a name; made if new) or company_id, contact (a name) + email or contact_id, stage (a stage's name), outcome (won | lost), closed_at (YYYY-MM-DD the day it was won or lost; today unless said), stage_changed_at, condition (a won deal that still depends on something: \xABsi llega la subvenci\xF3n\xBB), ${LINES}, currency (EUR unless said: USD, GBP\u2026), recurring_until (YYYY-MM-DD the last day of its fees), amount / recurring_amount + recurring_every (before 0.5: made into its lines), expected_close (YYYY-MM-DD), next_step + next_step_due (YYYY-MM-DD; none = no date), lost_reason, source, notes. Any other field is refused, never dropped`;
function crm_default(app, db, deps = {}) {
  const now = () => deps.now ? deps.now() : /* @__PURE__ */ new Date();
  const command2 = (a, method, path, spec, handler) => command(a, method, path, spec, async (i, ctx) => {
    await ensureUpgraded(db);
    return handler(i, ctx);
  });
  command2(app, "GET", "/today", { name: "today", summary: "What waits, in order, and whose move it is: START HERE. Counts, the pipeline's figures, your list of work (agent) and what waits for the person.", input: { full: "true for every line whole" } }, (i, { actor }) => today2(db, i, wantsFull(i, actor), now()));
  command2(app, "GET", "/pipeline", { name: "pipeline", summary: "Each open stage with its deals and what they are worth (once, monthly, stuck); open, weighted, won and lost totals.", input: { full: "true without the ids" } }, (i, { actor }) => pipeline(db, i, wantsFull(i, actor), now()));
  command2(app, "GET", "/leads", { name: "leads", of: "lead", summary: "The leads waiting for a decision (state new | qualified), newest first; state accepted | discarded | all for the rest.", input: { state: "new | qualified | accepted | discarded | all", limit: "rows, 10 unless said", full: "true for every field" } }, (i, { actor }) => list3(db, i, wantsFull(i, actor)));
  command2(app, "GET", "/leads/:id", { name: "lead", on: "lead", summary: "One lead whole: what they wrote, the form's answers, the agent's reading, and whether the person is in the CRM already." }, (i) => one2(db, i));
  command2(app, "POST", "/leads", { name: "leads_add", summary: "Leads arrive, several in one call: items [{ name, email, phone, company, website, message, source, source_ref, received_at, answers }]. Never into Trabajo.", input: { items: "list of { name, email, phone, company, website, message, source (Web, Formulario, Reserva\u2026), source_ref (the form response's or booking's id: sent twice, added once), received_at, answers }" } }, (i, { actor }) => add2(db, i, actor, now()));
  command2(app, "POST", "/leads/qualify", { name: "leads_qualify", summary: "Your reading of leads, several in one call: items [{ id, fit: good | maybe | poor, summary, kind, amount, recurring_amount, company, website }]. A person decides.", input: { items: "list of { id, fit, summary (2\u20133 lines: who, what they want, whether it fits), kind, amount (euros), recurring_amount, company, website }" } }, (i, { actor }) => qualify(db, i, actor, now()));
  command2(app, "POST", "/leads/:id/accept", { name: "lead_accept", on: "lead", by: "person", label: { es: "Convertir en negocio", en: "Make it a deal" }, summary: "A person answers a lead by opening a sale with it: a deal for its company (made when it arrived). A person's decision.", input: { title: "the deal's title", stage: "a stage's name", kind: "kind of service", amount: "euros", recurring_amount: "euros a month", company: "the company's name, when the lead did not say it", company_id: "a company already in the CRM the person picked instead", recurring_every: "month | quarter | year (month unless said)", lines: "what is sold, as deals_save takes it" } }, (i, { actor }) => accept2(db, i, actor, now()));
  command2(app, "POST", "/leads/:id/discard", { name: "lead_discard", on: "lead", by: "person", label: { es: "Descartar", en: "Discard" }, summary: "A person discards a lead, saying why. A person's decision.", input: { reason: "why: spam, not a client, nothing to sell them" } }, (i, { actor }) => discard(db, i, actor, now()));
  command2(app, "POST", "/leads/:id/reopen", { name: "lead_reopen", on: "lead", by: "person", summary: "Brings a discarded lead back to decide again. A person's decision." }, (i) => reopen(db, i));
  command2(app, "GET", "/deals", { name: "deals", of: "deal", summary: "The deals (\xABVentas en curso\xBB), open unless said, in stage order: client, value (\xAB810 \u20AC una vez + 12 \u20AC/mes\xBB), next step, stuck.", input: { stage: "a stage's name", category: "a category of what is sold", status: "open | won | lost | all", company_id: "company id", contact_id: "person id", stuck: "true: only the stuck ones", q: "words of its title or client", limit: "rows, 12 unless said", offset: "rows to skip", full: "true for every field" } }, (i, { actor }) => list2(db, i, wantsFull(i, actor), now()));
  command2(app, "GET", "/deals/:id", { name: "deal", on: "deal", summary: "One deal: its lines and value, client, next step, the step proposed (with its email), emails waiting, quote, its services when won, timeline.", input: { full: "true for everything its page draws" } }, (i, { actor }) => one(db, i, wantsFull(i, actor), now()));
  command2(app, "POST", "/deals", { name: "deals_save", summary: `Adds or changes deals, several in one call: items [{ id?, \u2026only what changes }]. Without id it is new (title and client needed). Answers added, changed (written), unchanged, skipped.`, input: { items: `list of { id, ${DEAL} }` } }, (i, { actor }) => save(db, i, actor, now()));
  command2(app, "GET", "/records/deals", { name: "deal_records", summary: "Every deal, open, won and lost, whole: what \xABDatos\xBB lists. deals is the one to use (open unless said, brief)." }, (i) => list2(db, { status: "all" }, true, now()));
  command2(app, "POST", "/deals/:id/remove", { name: "deal_remove", on: "deal", by: "person", confirm: true, label: { es: "Quitar", en: "Remove" }, summary: "Takes a deal away (a mistake, a duplicate). A person's decision; a deal that did not happen is moved to \xABperdido\xBB." }, (i) => remove2(db, i));
  command2(app, "POST", "/deals/link", { name: "deal_link", summary: "Links back the project Proyectos opened for a won deal (project_ref). A quote is never linked: made in Facturas with deal_id, it shows by itself.", input: { deal_id: "deal id", project_ref: "the project's name or id in Proyectos", quote_ref: "refused: a quote shows by itself", items: "list of the same, for several deals" } }, (i) => link(db, i));
  command2(app, "POST", "/deals/:id/quote", { name: "quote_request", on: "deal", summary: "Asks for this deal's quote: the team's agent makes it in Invoices (trigger presupuesto_por_hacer). Needs Invoices installed.", input: { note: "what the quote should say" } }, (i, { actor }) => quoteRequest(db, i, actor, now()));
  command2(app, "POST", "/steps/propose", { name: "next_steps_propose", summary: "Your proposals, several in one call: items [{ deal_id | company_id, step, due, why, email: { subject, body } }]. A person accepts or dismisses each.", input: { items: "list of { deal_id (a sale) or company_id (a customer, at risk or to renew), step, due (YYYY-MM-DD), why (what you saw), email: { subject, body, to? } (to the deal's person, or the company's main contact, unless to names someone in the CRM) }" } }, (i, { actor }) => propose(db, i, actor, now()));
  command2(app, "POST", "/steps/:id/accept", { name: "next_step_accept", by: "person", label: { es: "Hacerlo", en: "Take it" }, summary: "A person takes a proposed step: it becomes the deal's next step. A person's decision.", input: { due: "YYYY-MM-DD, to move its date" } }, (i, { actor }) => accept(db, i, actor, now()));
  command2(app, "POST", "/steps/:id/dismiss", { name: "next_step_dismiss", by: "person", label: { es: "Descartar", en: "Dismiss" }, summary: "A person says no to a proposed step; its email goes with it. A person's decision." }, (i) => dismiss(db, i));
  command2(app, "POST", "/steps/set", { name: "next_step_set", summary: "Sets deals' next step directly, as the person decided it: deal_id, step, due \u2014 or items [{ deal_id, step, due }] for several.", input: { deal_id: "deal id", step: "the step", due: "YYYY-MM-DD; left out = no date (\xABsin fecha\xBB, never late)", items: "list of { deal_id, step, due }" } }, (i, { actor }) => set(db, i, actor, now()));
  command2(app, "POST", "/steps/done", { name: "next_step_done", summary: "The deal's (or a customer's) next step is done: it goes on the timeline with how it went.", input: { deal_id: "deal id", company_id: "a customer's step, with no deal", note: "how it went" } }, (i, { actor }) => done(db, i, actor, now()));
  command2(app, "POST", "/emails/sent", { name: "emails_sent", summary: "After sending APPROVED emails from your Gmail: items [{ id, message_id }], or { id, error } when one could not go. It goes on the timeline.", input: { items: "list of { id, message_id } or { id, error }" } }, (i, { actor }) => sentMany(db, i, actor, now()));
  command2(app, "GET", "/emails/:id", { name: "email", summary: "One email whole (to, subject, body, the signature from Ajustes), to send it or to read it." }, (i) => draft(db, i));
  command2(app, "POST", "/emails/:id", { name: "email_update", summary: "Changes an email still to review: subject, body, to. A failed one comes back to review.", input: { subject: "text", body: "text", to: "an email address" } }, (i) => draftUpdate(db, i));
  command2(app, "POST", "/emails/:id/approve", { name: "email_approve", by: "person", label: { es: "Aprobar y enviar", en: "Approve and send" }, summary: "A person's yes to an email: from then the team's agent sends it from its Gmail (trigger correo_aprobado). A person's decision." }, (i, { actor }) => approve(db, i, actor, now()));
  command2(app, "POST", "/emails/:id/drop", { name: "email_drop", by: "person", label: { es: "Descartar", en: "Drop" }, summary: "A person drops an email that has not gone. A person's decision." }, (i) => drop(db, i));
  command2(app, "GET", "/items", { name: "items", of: "item", summary: "The catalogue: what the company sells, by category \u2014 once or recurring (rhythm), default price, minimum term, renewal, billing.", input: { q: "words of its name, category or description", archived: "true to list archived ones too", limit: "rows, 40 unless said", full: "true for every field and how many customers have each" } }, (i, { actor }) => items(db, i, wantsFull(i, actor), now()));
  command2(app, "POST", "/items", { name: "items_save", summary: "Adds or changes catalogue items, several in one call: items [{ id?, name, category, kind, every, price, min_months, renewal, bill_every, bill_in }].", input: { items: "list of { id (or the same name: that one), name, category (one of Ajustes), description, kind (once | recurring), every (month | quarter | year: a recurring one's rhythm), price (euros: once, or each period), min_months (minimum term), renewal (auto | manual | none), bill_every (month | quarter | year: how often Facturas bills it), bill_in (advance | arrears), archived (true: no longer sold; never deleted) }" } }, (i) => saveItems(db, i));
  command2(app, "GET", "/services", { name: "services", of: "service", summary: "Contracted services: what customers have now (or ended), each with its price, rhythm, start, minimum term, renewal or end, and what it brings a month.", input: { company_id: "one customer's", deal_id: "the ones a won deal made", state: "active (default) | ended | all", limit: "rows, 20 unless said", full: "true for every field" } }, (i, { actor }) => services(db, i, wantsFull(i, actor), now()));
  command2(app, "POST", "/services", { name: "services_save", summary: "Adds or changes contracted services, several in one call (one from before the CRM, a new price). A won deal's recurring lines make theirs by themselves.", input: { items: "list of { id?, company or company_id (a customer in the CRM), item (from \xABServicios y productos\xBB) or item_id, name, quantity, price (euros each period), discount (%), every (month | quarter | year), start (YYYY-MM-DD), min_months, renewal (auto | manual | none), end_on (the day it ends or ended), end_reason, deal_id, notes, remove (true: one made by mistake) }" } }, (i) => saveServices(db, i, companyRef));
  command2(app, "POST", "/services/:id/end", { name: "service_end", on: "service", label: { es: "Terminar", en: "End it" }, summary: "A customer's contracted service ends on a day (today unless said), with why: it stays in their history.", input: { end_on: "YYYY-MM-DD", reason: "why it ends" } }, (i) => endService(db, i, now()));
  command2(app, "GET", "/timeline", { name: "timeline", summary: "What happened with a deal, a company or a person, newest first: emails, meetings, calls, notes, stage moves.", input: { deal_id: "deal id", company_id: "company id", contact_id: "person id", limit: "entries, 10 unless said", full: "true for every entry whole" } }, (i, { actor }) => list(db, i, wantsFull(i, actor)));
  command2(app, "POST", "/timeline", { name: "timeline_add", summary: "Adds to the timeline, several in one call: items [{ deal_id | contact_id | company_id | email, type, at, subject, summary, external_id }].", input: { items: "list of { deal_id, contact_id, company_id, email (someone in the CRM), type: email (direction unknown) | email_in | email_out | meeting | call | note, at (ISO date-time, or YYYY-MM-DD for a day with no time), subject, summary (a few lines, never the whole mail), external_id (the mail's or event's id: sent twice, added once) }" } }, (i, { actor }) => add(db, i, actor, now()));
  command2(app, "POST", "/timeline/:id/remove", { name: "timeline_remove", by: "person", summary: "Takes one timeline entry away (a mistake). A person's decision." }, (i) => remove(db, i));
  command2(app, "GET", "/companies", { name: "companies", of: "company", summary: "\xABClientes\xBB: every company with its stage (lead | talking | customer | former), why it is at risk, what it pays a month, its deals.", input: { stage: "lead | talking | customer | former", at_risk: "true: only customers at risk", q: "words of its name, domain or sector", limit: "rows, 15 unless said", offset: "rows to skip", full: "true for every field" } }, (i, { actor }) => companies(db, i, wantsFull(i, actor), now()));
  command2(app, "GET", "/companies/:id", { name: "company", on: "company", summary: "One company: its stage and why, why it is at risk, its contracted services, people, deals, its next step and its timeline.", input: { full: "true for everything its page draws" } }, async (i, { actor }) => companyPage(db, i, wantsFull(i, actor), now()));
  command2(app, "POST", "/companies", { name: "companies_save", summary: "Adds or changes companies, several in one call: items [{ id?, name, legal_name, main_contact_id, website, tax_id, address, stage, concern, notes }].", input: { items: "list of { id, name, legal_name (raz\xF3n social, what invoices carry), main_contact_id (its \xABContacto principal\xBB, one of its contacts; null clears; set by itself when it has one contact), website, domain, industry, size, location, linkedin, summary, tax_id, address, phone, notes, source, owner, stage (lead | talking | customer | former set by hand, as the person said; null: read from its sales again), concern (a complaint you read in what they wrote, one line: it puts the customer at risk; null clears it), remove (true archives it, false restores it) }" } }, (i, { actor }) => saveCompanies(db, i, actor, now()));
  command2(app, "POST", "/companies/merge", { name: "companies_merge", by: "person", label: { es: "Unir con otra", en: "Merge" }, summary: "Two companies that are one client become one: everything moves to keep; drop stays archived, pointing at keep. A person's decision.", input: { keep: "the company id that stays", drop: "the duplicate's id" } }, (i) => merge(db, "company", i));
  command2(app, "GET", "/contacts", { name: "contacts", of: "contact", summary: "The people: everyone, or one company's; status Suggested lists those the mail found. q narrows it.", input: { company_id: "company id", status: "Lead | Contacted | Customer | Lost | Suggested | Ignored", q: "words of the name or email", limit: "rows, 15 unless said", offset: "rows to skip", full: "true for every field" } }, (i, { actor }) => contacts(db, i, wantsFull(i, actor)));
  command2(app, "GET", "/contacts/:id", { name: "contact", on: "contact", summary: "One person: their card, company, deals and last timeline entries.", input: { full: "true for everything their page draws" } }, async (i, { actor }) => contactPage(db, i, wantsFull(i, actor), now()));
  command2(app, "POST", "/contacts", { name: "contacts_save", summary: "Adds or changes people, several in one call: items [{ id?, name, email, phone, title, company or company_id, status, notes }].", input: { items: "list of { id, name, email, phone, title, company (a name; made if new), company_id, main (true: their company's \xABContacto principal\xBB), status, linkedin, notes, source, owner, remove (true archives, false restores) }" } }, (i) => saveContacts(db, i));
  command2(app, "POST", "/contacts/merge", { name: "contacts_merge", by: "person", label: { es: "Unir con otro", en: "Merge" }, summary: "Two people who are one become one: their deals, timeline, steps and emails move to keep; drop stays archived. A person's decision.", input: { keep: "the person id that stays", drop: "the duplicate's id" } }, (i) => merge(db, "contact", i));
  command2(app, "GET", "/match", { name: "client_match", summary: "Before adding a client: the company (by tax id, website or name) and the person (by email or name) the CRM already has.", input: { name: "company name", tax_id: "NIF / tax id", website: "web or domain", email: "a person's email", contact: "a person's name" } }, (i) => clientMatch(db, i));
  command2(app, "GET", "/triggers/leads", { name: "leads_to_qualify", summary: "The trigger entrada_por_calificar: each new lead not read yet \u2014 { items: [{ key, text, lead_id, email, company, message }] }." }, () => leadsToQualify(db));
  command2(app, "GET", "/triggers/steps", { name: "deals_needing_step", summary: "The trigger negocio_sin_siguiente_paso: open deals with no next step, a late one or stuck, and no proposal waiting." }, () => dealsNeedingStep(db, now()));
  command2(app, "GET", "/triggers/risk", { name: "customers_at_risk", summary: "The trigger cliente_en_riesgo: each customer at risk (no contact, an invoice overdue, a service ending or renewing, a complaint) with no step proposed or open." }, () => atRisk(db, now()));
  command2(app, "GET", "/triggers/emails", { name: "emails_to_send", summary: "The trigger correo_aprobado: each email a person approved and has not gone \u2014 { items: [{ key, text, draft_id, deal_id }] }." }, () => emailsToSend(db));
  command2(app, "GET", "/triggers/quotes", { name: "quotes_to_make", summary: "The trigger presupuesto_por_hacer: each deal whose quote a person asked for \u2014 { items: [{ key, text, deal_id, company, kind, amount, \u2026 }] }." }, () => quotesToMake(db));
  command2(app, "GET", "/triggers/won", { name: "won_without_project", summary: "The trigger proyecto_por_abrir: won deals with no project yet, while Proyectos is installed." }, () => wonWithoutProject(db));
  command2(app, "GET", "/exports/clients", { name: "clients", summary: "For other modules: the companies with their main person and email \u2014 { rows: [{ id, name, contact, email, website, tax_id, address }] }.", input: { q: "words of the name" } }, (i) => clients(db, i));
  command2(app, "GET", "/exports/reference", { name: "reference", summary: "For other modules, through the platform (exposes): companies, people or deals by ids, or found by words \u2014 { rows: [{ id, display, \u2026fields }] }.", input: { record: "company | contact | deal | service", ids: "ids, comma-separated", q: "words of its name or tax id", limit: "rows, 20 unless said", near: `what it is picked beside, e.g. "company_id:3": that company's people first`, company_id: "the older form: one company", contact_id: "the older form: one person", deal_id: "the older form: one deal" } }, async (i) => i.record ? reference2(db, i) : i.deal_id ? dealReference(db, i) : reference(db, i));
  command2(app, "GET", "/exports/reference/match", { name: "reference_match", summary: "For other modules, through the platform: what the CRM already has that a new company or person may be (tax id, web, email, name) \u2014 asked before one is made.", input: { record: "company | contact", name: "its name", tax_id: "NIF", website: "web", email: "email" } }, (i) => referenceMatch(db, i));
  command2(app, "POST", "/exports/reference", { name: "reference_create", summary: "For other modules, through the platform: makes the company or person a person asked for in another module (\xAB+ Nuevo cliente\xBB in Facturas), after its match.", input: { record: "company | contact", name: "its name", legal_name: "raz\xF3n social", tax_id: "NIF", email: "email", address: "address", phone: "phone", website: "web", contact: "the person's name", company_id: "a person made beside a company (its picker's near) is one of its people", from: "the module it was asked from (the platform says it)" } }, (i) => referenceCreate(db, i));
  command2(app, "GET", "/exports/won", { name: "won_deals", summary: "For other modules: the won deals \u2014 { rows: [{ id, title, company_id, company, kind, amount, recurring_amount, recurring_every, closed_at }] }.", input: { since: "YYYY-MM-DD" } }, (i) => wonDeals(db, i));
  command2(app, "GET", "/settings", { name: "settings", of: "config", summary: "The settings: stages (rows { name, probability, outcome }), categories and sources (lists), currency, days until stuck, the customers' risk days, the signature." }, () => settings(db));
  command2(app, "POST", "/settings/:id", { name: "set_settings", on: "config", by: "admin", partial: true, summary: 'Changes the settings, only the fields you pass: stages as the WHOLE table [{ name, probability 0-100, outcome none | won | lost }] in order (one won, one lost); categories and sources as the WHOLE list ["\u2026"]; currency, stuck_days, quiet_days, renewal_days, former_months, signature.', input: ["stages", "categories", "sources", "currency", "stuck_days", "quiet_days", "renewal_days", "former_months", "signature"] }, (i) => setSettings(db, i));
}
async function companyPage(db, i, full, now) {
  const c = await db.one(`SELECT * FROM crm_companies WHERE _deleted = 0 AND _id = ?`, [Number(i.id)]);
  if (!c) throw new Refused(`There is no company ${i.id}. companies lists them.`, 404, { code: "NOT_FOUND", item: Number(i.id) });
  const { _id, _created_at, _updated_at, _deleted, removed, enrich_claimed_at, enrich_attempts, legacy_hubspot_id, ...card } = c;
  const people = await contacts(db, { company_id: _id, limit: 50 }, full);
  const deals = await list2(db, { company_id: _id, status: "all", limit: 50 }, full, now);
  const timeline = await list(db, { company_id: _id, limit: full ? 50 : 6 }, full);
  const peers = await db.peers().catch(() => null);
  const invoices = peers ? peers.some((p) => p.module === "invoices" && p.installed) : true;
  const main = card.main_contact_id ? (await db.one(`SELECT name FROM crm_contacts WHERE _id = ?`, [card.main_contact_id]))?.name : null;
  const f = (await facts(db, [_id], now)).get(_id) ?? {};
  const feesOf = /* @__PURE__ */ new Map();
  for (const x of f.services ?? []) feesOf.set(x.id, ((await db.referenced("service", x.id).catch(() => null))?.groups ?? []).flatMap((g) => g.rows.map((r) => ({ module: g.module, title: r.title, open: r.open, fields: r.fields }))));
  const tasks = await db.all(`SELECT t._id AS id, t.title, t.due, t.why, t.status, t.draft_id, x.subject, x.to_email, x.body, x.status AS email_status FROM crm_tasks t LEFT JOIN crm_drafts x ON x._id = t.draft_id WHERE t._deleted = 0 AND t.company_id = ? AND t.deal_id IS NULL AND t.status IN ('Suggested','Open') ORDER BY t._id DESC`, [_id]);
  const lead = await db.one(`SELECT _id AS id, name, email, message, source, received_at, state, fit, qualification, proposed_kind, proposed_amount, proposed_recurring FROM crm_leads WHERE _deleted = 0 AND COALESCE(removed,0) = 0 AND company_id = ? AND state IN ('new','qualified') ORDER BY received_at DESC LIMIT 1`, [_id]);
  const billing = invoices ? billingFrom((await db.referenced("company", _id).catch(() => null))?.groups, today(now, (await settingsRow(db)).timezone)) : void 0;
  const life = { billing, stage: f.stage, stage_label: f.stage_label, stage_reason: f.stage_reason, stage_by: f.stage_by, stage_facts: f.stage_facts, monthly: f.monthly, risks: f.risks, overdue: f.overdue, last_contact: f.last_contact, services: (f.services ?? []).map((x) => full ? { ...x, billing: feesOf.get(x.id) } : { id: x.id, name: x.name, amount: x.amount, every: x.every, start: x.start, state: x.state, ends: x.ends, next_renewal: x.next_renewal }), proposal: tasks.find((t) => t.status === "Suggested"), step: tasks.find((t) => t.status === "Open"), lead: lead ?? void 0 };
  return { id: _id, ...Object.fromEntries(Object.entries(card).filter(([, v]) => v !== null && v !== "")), ...life, main_contact: main || void 0, currency: (await settingsRow(db)).currency, archived: Number(removed) ? true : void 0, invoices, people: people.rows, deals: deals.rows, timeline: timeline.rows };
}
async function contactPage(db, i, full, now) {
  const c = await db.one(`SELECT p.*, ${LAST_ACTIVITY} AS last_seen, c.name AS company FROM crm_contacts p LEFT JOIN crm_companies c ON c._id = p.company_id WHERE p._deleted = 0 AND p._id = ?`, [Number(i.id)]);
  if (!c) throw new Refused(`There is no person ${i.id}. contacts lists them.`, 404, { code: "NOT_FOUND", item: Number(i.id) });
  const { _id, _created_at, _updated_at, _deleted, removed, legacy_hubspot_id, last_seen, ...card } = c;
  card.last_activity_at = last_seen;
  const deals = await list2(db, { contact_id: _id, status: "all", limit: 50 }, full, now);
  const timeline = await list(db, { contact_id: _id, limit: full ? 50 : 6 }, full);
  return { id: _id, ...Object.fromEntries(Object.entries(card).filter(([, v]) => v !== null && v !== "")), archived: Number(removed) ? true : void 0, deals: deals.rows, timeline: timeline.rows };
}
async function clientMatch(db, i) {
  const company = await matchCompany(db, i) ?? null;
  const contactId = i.email || i.contact ? await contactRef(db, { email: i.email, name: i.contact }).catch(() => null) : null;
  const contact = contactId ? await db.one(`SELECT _id AS id, name, email, company_id FROM crm_contacts WHERE _id = ?`, [contactId]) : null;
  const out = { company, contact: contact ? Object.fromEntries(Object.entries(contact).filter(([, v]) => v !== null)) : null, ...contact ? { contact_id: contact.id } : {} };
  if (!company && !contact) out.said = "ninguno: nothing in the CRM matches; adding it makes a new one";
  return out;
}
async function dealReference(db, i) {
  const d = await db.one(`SELECT _id, title, status, stage, kind, amount, currency, recurring_amount, recurring_every, recurring_until, closed_at, condition, company_id, contact_id, removed FROM crm_deals WHERE _deleted = 0 AND _id = ?`, [Number(i.deal_id)]);
  if (!d) throw new Refused(`There is no deal ${i.deal_id} in the CRM.`, 404, { code: "NOT_FOUND", item: Number(i.deal_id) });
  const client = d.company_id ? await reference(db, { company_id: d.company_id }).catch(() => null) : d.contact_id ? await reference(db, { contact_id: d.contact_id }).catch(() => null) : null;
  return Object.fromEntries(Object.entries({ kind: "deal", id: d._id, title: d.title, display: dealName(d.title, client?.name), status: d.status, stage: d.stage, service: d.kind, amount: d.amount, currency: d.currency, recurring_amount: d.recurring_amount, recurring_every: d.recurring_every, recurring_until: d.recurring_until, closed_at: d.closed_at, condition: d.condition, client, archived: Number(d.removed) ? true : void 0 }).filter(([, v]) => v !== null && v !== void 0));
}

// server/app.mjs
function createApp(db, deps = {}) {
  const app = new Hono2();
  mountErrors(app);
  crm_default(app, db, deps);
  return app;
}

// server/db.mjs
function dataClient(url = process.env.APP_DATA_URL, token = process.env.APP_DATA_TOKEN) {
  const call = async (path, body) => {
    const r = await fetch(`${url}${path}`, { method: "POST", headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` }, body: JSON.stringify(body) });
    const j = await r.json().catch(() => null);
    if (!r.ok || !j) throw Object.assign(new Error(j?.error ?? `Data ${r.status}`), { status: r.status, code: j?.code, how: j?.how, item: j?.item, candidates: j?.candidates });
    return j;
  };
  return {
    all: async (sql, params = []) => (await call("/all", { sql, params })).rows,
    one: async (sql, params = []) => (await call("/all", { sql, params })).rows[0] ?? null,
    insert: async (table, data) => (await call("/batch", { ops: [{ op: "insert", table, data }] })).ids[0],
    update: async (table, id, data, where = {}) => (await call("/update", { table, id, data, where })).changed,
    batch: async (ops) => (await call("/batch", { ops })).ids,
    // Which of the modules app.json `suggests` are installed for the company: [{ module, installed, name, version, for, unlocks }].
    // Read when asked, never kept; nothing of the other module is reachable (the guide: «Modules unlock each other»).
    peers: async () => (await call("/peers", {})).peers,
    // One read command another module EXPORTS and app.json `reads` declares: { installed: false } when that module is
    // not installed, else { installed: true, result }. Never its tables, never a write (the guide: «Reading another module»).
    read: async (module, command2, params = {}) => call("/read", { module, command: command2, params }),
    // The records of ANOTHER module this module's fields point at ("type": "ref", "module": "crm", "to": "company"):
    // read live from that module, only what it exposes, a merged id answered by the one kept — never copied into your
    // tables. [{ id, display, archived?, …fields }] (the guide: «Linked records across modules»).
    refs: async (field, ids) => (await call("/refs", { field, ids })).rows,
    // One value your code received nested (an import's client) → its id (a name holding the words of ONE record only is
    // that one), or a refusal with the candidates. Never a guess between two.
    refResolve: async (field, value) => (await call("/refs/resolve", { field, value })).id,
    // Make one there, after its match: { created, id } or { created: false, matches } («¿Es esta?»).
    refNew: async (field, values, distinct = false) => call("/refs/new", { field, values, distinct }),
    // What OTHER modules point at one of the records this module `exposes`, read live: { groups: [{ module, label, rows }] }.
    referenced: async (record, id) => call("/referenced", { record, id })
  };
}

// server/main.mjs
serve({ fetch: createApp(dataClient()).fetch, hostname: "127.0.0.1", port: Number(process.env.PORT) });
