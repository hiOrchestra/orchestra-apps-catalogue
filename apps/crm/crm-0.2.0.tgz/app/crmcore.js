/**
 * The CRM's rules that the desk and the automations must agree on, in one
 * file: the stages and what they mean, which addresses are people at a
 * company (not gmail.com), tags, and when the daily suggestions run.
 * Pure functions, no database, no DOM. test/sync.js copies this file to
 * app/ and automations/, and a test fails if a copy is stale.
 */
(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.CrmCore = api;
}(typeof self !== 'undefined' ? self : this, () => {
  'use strict';

  const DEFAULT_STAGES = [
    { name: 'Lead', probability: 10, order: 1 }, { name: 'Qualified', probability: 25, order: 2 },
    { name: 'Meeting', probability: 40, order: 3 }, { name: 'Proposal', probability: 60, order: 4 },
    { name: 'Negotiation', probability: 80, order: 5 },
    { name: 'Won', probability: 100, order: 6, outcome: 'won' }, { name: 'Lost', probability: 0, order: 7, outcome: 'lost' },
  ];
  const CONTACT_STATUS = ['Lead', 'Contacted', 'Customer', 'Lost', 'Suggested', 'Ignored'];
  const ACTIVITY = { email_in: 'Email in', email_out: 'Email out', meeting: 'Meeting', note: 'Note', call: 'Call', form: 'Form', stage: 'Stage', task: 'Task' };
  const SIZES = ['1-10', '11-50', '51-200', '201-500', '501-1000', '1001-5000', '5000+'];

  // Mailboxes of people, not of a company: a correspondent there is never suggested as a company contact.
  const FREE = new Set(['gmail.com', 'googlemail.com', 'hotmail.com', 'hotmail.es', 'outlook.com', 'outlook.es', 'live.com', 'msn.com',
    'yahoo.com', 'yahoo.es', 'ymail.com', 'icloud.com', 'me.com', 'mac.com', 'aol.com', 'proton.me', 'protonmail.com', 'gmx.com', 'gmx.de',
    'mail.com', 'zoho.com', 'yandex.com', 'yandex.ru', 'qq.com', '163.com', 'web.de', 't-online.de', 'orange.fr', 'free.fr', 'libero.it',
    'hey.com', 'fastmail.com', 'tutanota.com', 'pm.me']);
  // Addresses that are machines: never a contact.
  const MACHINE = /^(no-?reply|do-?not-?reply|notifications?|mailer-daemon|postmaster|bounces?|alerts?|news(letter)?|marketing|info|hello|support|billing|invoice|receipts?|calendar|jobs|team)([+._-].*)?@/i;
  const EMAIL = /^[^\s@<>(),;:"]+@[^\s@<>(),;:"]+\.[a-z]{2,}$/i;

  const str = (v) => (v === null || v === undefined ? '' : String(v));
  const normEmail = (v) => str(v).trim().toLowerCase();
  const isEmail = (v) => EMAIL.test(normEmail(v));
  const domainOf = (email) => (isEmail(email) ? normEmail(email).split('@')[1] : '');
  const isFree = (domain) => FREE.has(str(domain).toLowerCase());
  // A sender that stamps every message with its own address (contract or ticket
  // numbers, hashes): vertragsservice.45560540-117555@… is one machine, not five people.
  const TOKENIZED = /^[^@]*(\d{5,}|[0-9a-f]{12,})[^@]*@/i;
  // A shared box (sales@, hey@, serviceteam4@…), a no-reply anywhere in the name,
  // a bulk-mail subdomain (m.starbucks.com) and the agents' own mailboxes.
  const ROLE = /^(sales|contact|hey|hi|help|service(team)?\d*|customer-?service|office|admin|root|cron|daemon|mail|accounts?|orders?|shop|store|expats?|press|careers|feedback|reservations?|booking|members?|community|events?|security|privacy|legal|compliance|webmaster)([+._-].*)?@/i;
  const BULK_HOST = /@(m|mail|email|em|e|news|info|mailer|bounce|click|links?|reply)\d*\./i;
  const AGENT_HOST = /@agents\.hiorchestra\.com$/i;
  const isMachine = (email) => {
    const e = normEmail(email);
    return MACHINE.test(e) || TOKENIZED.test(e) || ROLE.test(e) || BULK_HOST.test(e) || AGENT_HOST.test(e) || /no-?reply|do-?not-?reply/i.test(e.split('@')[0]);
  };

  /** "Ana Ruiz <ana@acme.example>, bob@x.example" -> [{ name, email }] */
  function addresses(text) {
    const out = [];
    for (const part of str(text).split(/,(?=(?:[^"]*"[^"]*")*[^"]*$)/)) {
      const m = part.match(/^\s*"?([^"<]*?)"?\s*<([^>]+)>\s*$/);
      const email = normEmail(m ? m[2] : part);
      if (isEmail(email) && !out.some((a) => a.email === email)) out.push({ name: m ? m[1].trim() : '', email });
    }
    return out;
  }

  /** A company name from its domain when nothing better is known: acme-labs.example -> Acme Labs. */
  function nameFromDomain(domain) {
    const base = str(domain).toLowerCase().replace(/^www\./, '').split('.')[0] || str(domain);
    return base.split(/[-_]+/).filter(Boolean).map((w) => w[0].toUpperCase() + w.slice(1)).join(' ');
  }

  /** The stages as Settings keeps them (JSON), in order, with the two outcomes marked. */
  function stagesOf(value) {
    let list = value;
    if (typeof value === 'string') { try { list = JSON.parse(value); } catch { list = null; } }
    if (!Array.isArray(list) || !list.length) list = DEFAULT_STAGES;
    const out = list.filter((s) => s && str(s.name).trim()).map((s, i) => ({
      name: str(s.name).trim().slice(0, 40),
      probability: Math.max(0, Math.min(100, Math.round(Number(s.probability) || 0))),
      order: Number.isFinite(Number(s.order)) ? Number(s.order) : i + 1,
      outcome: s.outcome === 'won' || s.outcome === 'lost' ? s.outcome : null,
    })).sort((a, b) => a.order - b.order);
    if (!out.some((s) => s.outcome === 'won')) out.push({ name: 'Won', probability: 100, order: 98, outcome: 'won' });
    if (!out.some((s) => s.outcome === 'lost')) out.push({ name: 'Lost', probability: 0, order: 99, outcome: 'lost' });
    return out;
  }
  const openStages = (stages) => stagesOf(stages).filter((s) => !s.outcome);
  const outcomeStage = (stages, kind) => stagesOf(stages).find((s) => s.outcome === kind);

  /** Tags are kept as |a|b| so a filter can ask for "|a|" with like. */
  const tagsOf = (v) => str(v).split('|').map((t) => t.trim()).filter(Boolean);
  const tagsText = (list) => {
    const clean = [...new Set((Array.isArray(list) ? list : str(list).split(/[,|]/)).map((t) => str(t).trim().replace(/\|/g, '')).filter(Boolean))];
    return clean.length ? `|${clean.join('|')}|` : '';
  };
  /** One per line in Settings (owners, sources). */
  const linesOf = (v) => str(v).split(/[\n,]+/).map((x) => x.trim()).filter(Boolean);

  /** Minutes east of UTC that a time zone is at a given instant. */
  function offsetMin(tz, at) {
    try {
      const p = Object.fromEntries(new Intl.DateTimeFormat('en-US', { timeZone: tz, hourCycle: 'h23', year: 'numeric', month: '2-digit', day: '2-digit',
        hour: '2-digit', minute: '2-digit', second: '2-digit' }).formatToParts(at).map((x) => [x.type, x.value]));
      return Math.round((Date.UTC(+p.year, +p.month - 1, +p.day, +p.hour, +p.minute, +p.second) - at.getTime()) / 60000);
    } catch { return 0; }
  }

  /** The next time it is `hour`:00 in `tz`, after `from` (a Date, in UTC), on the minute. */
  function nextAt(hour, tz, from) {
    const h = Math.max(0, Math.min(23, Math.round(Number(hour) || 0)));
    const now = from instanceof Date ? from : new Date();
    for (let d = -1; d <= 2; d += 1) {
      const local = new Date(now.getTime() + offsetMin(tz, now) * 60000);
      const guess = Date.UTC(local.getUTCFullYear(), local.getUTCMonth(), local.getUTCDate() + d, h, 0, 0);
      const at = new Date(guess - offsetMin(tz, new Date(guess)) * 60000);
      if (at > now) return at;
    }
    return new Date(now.getTime() + 86400000);
  }

  /** 'YYYY-MM-DD HH:MM:SS' in UTC: how orch-database stamps a row. */
  const sqlTime = (d) => (d instanceof Date ? d : new Date(d)).toISOString().slice(0, 19).replace('T', ' ');

  return {
    DEFAULT_STAGES, CONTACT_STATUS, ACTIVITY, SIZES, FREE,
    str, normEmail, isEmail, domainOf, isFree, isMachine, addresses, nameFromDomain,
    stagesOf, openStages, outcomeStage, tagsOf, tagsText, linesOf, offsetMin, nextAt, sqlTime,
  };
}));
