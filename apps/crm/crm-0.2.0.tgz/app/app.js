// The router and the bar. Today is home: what is due, what the agent
// suggests, and the emails waiting. Pipeline is the board, Deals the list;
// a deal, a person or a company opens in its panel (open=<id> in the URL).
import { render as today } from './screens/today.js';
import { render as pipeline } from './screens/pipeline.js';
import { render as deals } from './screens/deals.js';
import { render as contacts } from './screens/contacts.js';
import { render as companies } from './screens/companies.js';
import { render as settings } from './screens/settings.js';

const { el, router } = Orch;

router.define({
  '/': today,
  '/pipeline': pipeline,
  '/deals': deals,
  '/deals/:view': deals,
  '/contacts': contacts,
  '/contacts/:view': contacts,
  '/companies': companies,
  '/settings': settings,
}, () => Orch.mount('view', el('div', { class: 'oc-state' }, [
  el('p', 'There is no screen here.'), router.link('/', 'Go to Today'),
]))).start();

Orch.mount('nav', [
  router.link('/', 'Today', { class: 'oc-tab' }),
  router.link('/pipeline', 'Pipeline', { class: 'oc-tab' }),
  router.link('/deals', 'Deals', { class: 'oc-tab' }),
  router.link('/contacts', 'Contacts', { class: 'oc-tab' }),
  router.link('/companies', 'Companies', { class: 'oc-tab' }),
  router.link('/settings', 'Settings', { class: 'oc-tab' }),
]);
