// One email draft, in its own panel, with every way out of its state:
//   Review    edit it, approve it (it goes out from your Gmail), or drop it
//   Approved  waiting for the sender run (or for the pause to end)
//   Failed    what happened in plain words, the raw error under it, and
//             retry / edit / mark as sent / drop, right there
// Nothing leaves without the Approve button.
import { C, T, A, act, badge, field, input, area, sheet, stamp, settings, dealLink, contactLink } from '../data.js';

const { el } = Orch;

export async function openDraft(id, after) {
  const row = await Orch.db.get(T.drafts, id);
  if (!row) { Orch.toast('That email is gone.', { error: true }); return; }
  const s = await settings(true);
  const box = el('div', { class: 'oc-stack' });
  const d = sheet(box, { title: row.subject || 'Email', drawer: true });
  const done = () => { d.close(); if (after) after(); };
  Orch.mount(box, await panel(row, s, done));
}

async function panel(r, s, done) {
  const [contact, deal] = await Promise.all([r.contact_id ? Orch.db.get(T.contacts, r.contact_id) : null, r.deal_id ? Orch.db.get(T.deals, r.deal_id) : null]);
  const about = el('p', { class: 'oc-small oc-muted' }, [
    contact ? ['To ', contactLink(contact._id, contact.name || contact.email)] : 'To an address with no contact',
    deal ? [' · about ', dealLink(deal._id, deal.title)] : '',
    ` · written ${r.source === 'Agent' ? 'by the agent' : r.created_by ? `by ${r.created_by}` : ''} ${stamp(r._created_at)}`,
  ]);
  const top = el('div', { class: 'oc-row' }, [badge(r.status), about]);
  if (r.status === 'Review') return review(r, s, top, done);
  if (r.status === 'Failed') return failed(r, top, done);
  const say = {
    Approved: Number(s.paused) === 1 ? 'Approved. The CRM is paused, so it waits: resume it in Settings and it goes out.' : 'Approved: it goes out from your Gmail within a minute.',
    Sending: 'Going out now.', Sent: `Sent ${stamp(r.sent_at)} from your Gmail.`, Dropped: 'Dropped: it was never sent.',
  }[r.status] || '';
  return el('div', { class: 'oc-stack' }, [top, el('p', { class: 'oc-help' }, say), readOnly(r)]);
}

function readOnly(r) {
  return el('div', { class: 'oc-stack oc-stack--tight crm-mail' }, [
    el('p', { class: 'oc-eyebrow' }, `To ${r.to_email || '—'}`), el('p', { class: 'crm-mail__subject' }, r.subject || '—'),
    el('pre', { class: 'crm-mail__body' }, r.body || ''),
  ]);
}

function editors(r) {
  const to = input(r.to_email, { type: 'email', required: true });
  const subject = input(r.subject, { required: true, maxlength: '160' });
  const body = area(r.body, 12, { required: true });
  const values = () => ({ id: r._id, to_email: C.normEmail(to.value), subject: subject.value.trim(), body: body.value.replace(/\r\n/g, '\n').trim() });
  const valid = (v) => {
    if (!C.isEmail(v.to_email)) { Orch.toast('The address does not look right.', { error: true }); return false; }
    if (!v.subject || !v.body) { Orch.toast('It needs a subject and a message.', { error: true }); return false; }
    return true;
  };
  return { fields: [field('To', to), field('Subject', subject), field('Message', body, 'Plain text, sent from the Gmail account connected to the workspace.')], values, valid };
}

function review(r, s, top, done) {
  const e = editors(r);
  const approve = el('button', { class: 'oc-btn oc-btn--primary', type: 'button' }, 'Approve and send');
  const save = el('button', { class: 'oc-btn', type: 'button' }, 'Save changes');
  const drop = el('button', { class: 'oc-btn oc-btn--ghost', type: 'button' }, 'Drop');
  approve.addEventListener('click', async () => {
    const v = e.values();
    if (!e.valid(v)) return;
    approve.disabled = true;
    if (await act(A.approve, v, Number(s.paused) === 1 ? 'Approved. It waits until the CRM is resumed.' : 'Approved: it goes out within a minute.')) done();
    approve.disabled = false;
  });
  save.addEventListener('click', async () => { const v = e.values(); if (e.valid(v) && await act(A.editDraft, v, 'Saved. It still waits for approval.')) done(); });
  drop.addEventListener('click', async () => { if (await act(A.drop, { id: r._id }, 'Dropped: it will not be sent.')) done(); });
  return el('div', { class: 'oc-stack' }, [
    top,
    Number(s.paused) === 1 ? el('p', { class: 'oc-help crm-warn' }, 'The CRM is paused: what you approve waits until it is resumed in Settings.') : null,
    ...e.fields,
    el('div', { class: 'oc-row' }, [approve, save, drop]),
  ]);
}

function failed(r, top, done) {
  const maybe = /may or may not/i.test(r.error || '');
  const e = editors(r);
  const retry = el('button', { class: 'oc-btn oc-btn--primary', type: 'button' }, 'Send again');
  retry.addEventListener('click', async () => {
    if (maybe && !(await Orch.confirm('It may have gone out already. Did you check Gmail\'s Sent folder, and it is not there?', { yes: 'Not there: send again' }))) return;
    if (await act(A.retry, { id: r._id }, 'Approved again: it goes out within a minute.')) done();
  });
  const fix = el('button', { class: 'oc-btn', type: 'button' }, 'Save and review again');
  fix.addEventListener('click', async () => { const v = e.values(); if (e.valid(v) && await act(A.editFailed, v, 'Saved. Approve it again when it is right.')) done(); });
  const sent = el('button', { class: 'oc-btn oc-btn--ghost', type: 'button' }, 'It did go out: mark as sent');
  sent.addEventListener('click', async () => { if (await act(A.markSent, { id: r._id }, 'Marked as sent.')) done(); });
  const drop = el('button', { class: 'oc-btn oc-btn--ghost', type: 'button' }, 'Drop');
  drop.addEventListener('click', async () => { if (await act(A.dropFailed, { id: r._id }, 'Dropped.')) done(); });
  const said = String(r.error || 'It did not go out.');
  const plain = said.replace(/\s*\(.*\)\s*$/, '');
  const raw = said.length > plain.length ? said.slice(plain.length).trim().replace(/^\(|\)$/g, '') : '';
  return el('div', { class: 'oc-stack' }, [
    top,
    el('div', { class: 'crm-error' }, [el('p', {}, plain), raw ? el('p', { class: 'oc-value oc-muted' }, raw) : null]),
    el('div', { class: 'oc-row' }, [retry, sent, drop]),
    el('details', { class: 'crm-details' }, [el('summary', {}, 'Edit before sending again'), el('div', { class: 'oc-stack' }, [...e.fields, el('div', { class: 'oc-row' }, fix)])]),
  ]);
}
