// Settings: the one place for each setting. The pause; mail and calendar
// sync (read only); when the agent suggests next steps and how many emails
// may leave a day; enrichment; leads from Forms; the HubSpot import. The
// pipeline's stages, owners and sources are in settings-pipeline.js.
import { C, A, act, head, badge, ago, stamp, field, input, area, num, select, settings, runButton } from '../data.js';
import { pipelineCard, teamCard } from './settings-pipeline.js';

const { el, router } = Orch;
const ZONES = ['UTC', 'Europe/Madrid', 'Europe/London', 'Europe/Lisbon', 'Europe/Paris', 'Europe/Berlin', 'America/New_York', 'America/Chicago', 'America/Denver',
  'America/Los_Angeles', 'America/Mexico_City', 'America/Bogota', 'America/Lima', 'America/Santiago', 'America/Argentina/Buenos_Aires', 'America/Sao_Paulo',
  'Asia/Dubai', 'Asia/Kolkata', 'Asia/Singapore', 'Asia/Tokyo', 'Australia/Sydney'];

export function render() {
  Orch.load('view', async () => {
    const s = await settings(true);
    const again = () => render();
    return el('div', { class: 'oc-stack oc-stack--loose crm-settings' }, [
      head('Settings', 'How the CRM works for your team: what it reads, what the agent does, and what may leave.'),
      pause(s, again), sync(s, again), suggest(s, again), pipelineCard(s, again), teamCard(s, again), enrich(s), forms(s, again), hubspot(s, again),
    ]);
  });
}

/** A settings card: its heading and state on one line, what it is for, then its form. */
export function card(title, state, help, body) {
  return el('section', { class: 'oc-card oc-stack' }, [
    el('div', { class: 'oc-row oc-row--between' }, [el('h2', { class: 'oc-h2' }, title), state || null]),
    help ? el('p', { class: 'oc-help' }, help) : null, ...[].concat(body || []),
  ]);
}

/** A form that saves some settings with the one settings action. */
export function saving(fields, values, again, said = 'Saved.') {
  const save = el('button', { class: 'oc-btn oc-btn--primary', type: 'submit' }, 'Save');
  const form = el('form', { class: 'oc-stack crm-form' }, [...fields, el('div', { class: 'oc-row' }, save)]);
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const v = values();
    if (!v) return;
    save.disabled = true;
    if (await act(A.settings, v, said)) again();
    save.disabled = false;
  });
  return form;
}
const check = (on) => el('input', { type: 'checkbox', checked: Number(on) === 1 });

function pause(s, again) {
  const paused = Number(s.paused) === 1;
  const b = el('button', { class: `oc-btn${paused ? ' oc-btn--primary' : ''}`, type: 'button' }, paused ? 'Resume' : 'Pause everything');
  b.addEventListener('click', async () => {
    if (!paused && !(await Orch.confirm('Pause the CRM? Sync, suggestions and enrichment stop, and approved emails wait until you resume.', { yes: 'Pause' }))) return;
    if (await act(A.pause, { id: s._id, paused: paused ? 0 : 1 }, paused ? 'Resumed: approved emails go out now.' : 'Paused.')) again();
  });
  return card('Pause', badge(paused ? 'Paused' : 'Running', paused ? 'warn' : 'good'),
    'Stops everything that runs on its own and holds every approved email. Nothing is lost: it all continues when you resume.', el('div', { class: 'oc-row' }, b));
}

function sync(s, again) {
  const gmail = check(s.sync_gmail);
  const cal = check(s.sync_calendar);
  const days = num(s.sync_days_back || 30, 1, 365);
  const account = input(s.gmail_account || '', { placeholder: 'Only if more than one Gmail is connected' });
  const on = Number(s.sync_gmail) === 1 || Number(s.sync_calendar) === 1;
  const facts = [
    s.gmail_address ? `Mailbox ${s.gmail_address}` : null,
    `Mail read ${s.gmail_synced_at ? ago(s.gmail_synced_at) : 'never'}`, `Calendar read ${s.calendar_synced_at ? ago(s.calendar_synced_at) : 'never'}`,
  ].filter(Boolean).join(' · ');
  return card('Mail and calendar', badge(on ? 'On' : 'Off', on ? 'good' : ''),
    'Reads your Gmail and Google Calendar every half hour: mail and meetings with your contacts land on their timeline, and new people who write from company addresses are suggested in Contacts. Read only: it never sends, moves or deletes anything there. Connect Gmail and Calendar first in the portal, under Integrations.', [
      el('p', { class: 'oc-eyebrow' }, facts),
      s.sync_note ? el('p', { class: 'crm-error' }, s.sync_note) : null,
      saving([
        el('label', { class: 'crm-check' }, [gmail, 'Read Gmail']), el('label', { class: 'crm-check' }, [cal, 'Read Google Calendar']),
        field('The first time, go back', days, 'Days of mail and meetings to read on the first sync.'),
        field('Gmail account', account, 'The name of the connected account to read and send from, when the workspace has more than one.'),
      ], () => ({ id: s._id, sync_gmail: gmail.checked ? 1 : 0, sync_calendar: cal.checked ? 1 : 0, sync_days_back: Number(days.value) || 30, gmail_account: account.value.trim() }),
      again, 'Saved. Sync runs within half an hour, or now.'),
      el('div', { class: 'oc-row' }, runButton('Sync now', A.syncNow, 'Reading your mail and calendar now.', { after: again, wait: 5000 })),
    ]);
}

function suggest(s, again) {
  const hour = select(Array.from({ length: 24 }, (_, h) => [h, `${String(h).padStart(2, '0')}:00`]), s.suggest_hour ?? 8);
  const tz = select([...new Set([s.timezone || 'UTC', ...ZONES])], s.timezone || 'UTC');
  const per = num(s.suggest_per_run || 8, 1, 20);
  const cap = num(s.daily_send_cap || 40, 1, 500);
  const sig = area(s.signature || '', 3, { placeholder: 'Ana Ruiz\nAcme · +34 600 000 000' });
  return card('Next steps and emails', null,
    'Once a day the agent looks at open deals with no next step, a late one, or no activity for a while, and suggests a step and, when it fits, an email. They wait on Today for you; nothing is sent until you approve it.', [
      el('p', { class: 'oc-eyebrow' }, `Last ${s.last_suggest_at ? stamp(s.last_suggest_at) : 'never'} · next ${s.next_suggest_at ? stamp(s.next_suggest_at) : 'not set'}`),
      s.suggest_note ? el('p', { class: 'oc-help' }, s.suggest_note) : null,
      saving([
        field('Every day at', hour), field('Time zone', tz), field('Deals per day', per, 'At most this many deals get a suggestion each day.'),
        field('Emails a day', cap, 'Approved emails beyond this wait for the next day.'),
        field('Signature', sig, 'Added under every email the agent writes.'),
      ], () => ({ id: s._id, suggest_hour: Number(hour.value), timezone: tz.value, suggest_per_run: Number(per.value) || 8, daily_send_cap: Number(cap.value) || 40,
        signature: sig.value.trim(), next_suggest_at: C.sqlTime(C.nextAt(Number(hour.value), tz.value)) }), again),
      s.send_note ? el('p', { class: 'oc-help' }, s.send_note) : null,
      el('p', { class: 'oc-help' }, ['To ask for suggestions now, use Suggest now on ', router.link('/', 'Today'), '.']),
    ]);
}

function enrich(s) {
  return card('Company research', null,
    'When a company is added, the agent looks it up on the web and fills in industry, size, location, a short summary and LinkedIn, with the pages it read. It never overwrites what you typed. A few companies per hour, only when one is waiting.', [
      el('p', { class: 'oc-eyebrow' }, `Agent ${s.enrich_agent || '—'} · ${s.enrich_per_run || 5} per run`),
      s.enrich_note ? el('p', { class: 'oc-help' }, s.enrich_note) : null,
      el('p', { class: 'oc-help' }, ['To look one up again, open it in ', router.link('/companies', 'Companies'), '.']),
    ]);
}

function forms(s, again) {
  const on = check(s.forms_intake);
  return card('Leads from Forms', badge(Number(s.forms_intake) === 1 ? 'On' : 'Off', Number(s.forms_intake) === 1 ? 'good' : ''),
    'Every complete answer to a Forms form that gives an email becomes a contact (or updates one), with what they answered on their timeline. Needs the Forms app in this workspace.', [
      s.forms_note ? el('p', { class: 'oc-help' }, s.forms_note) : null,
      saving([el('label', { class: 'crm-check' }, [on, 'Take leads from Forms'])], () => ({ id: s._id, forms_intake: on.checked ? 1 : 0 }), again),
      el('div', { class: 'oc-row' }, runButton('Check Forms now', A.formsNow, 'Looking for new answers now.', { after: again, wait: 4000 })),
    ]);
}

function hubspot(s, again) {
  const st = s.hubspot_status || 'Never';
  const b = el('button', { class: 'oc-btn', type: 'button' }, st === 'Never' ? 'Import from HubSpot' : st === 'Failed' ? 'Continue the import' : 'Import again');
  b.addEventListener('click', async () => {
    if (!(await Orch.confirm('Copy companies, contacts and deals from the HubSpot account connected to this workspace? It only reads HubSpot. Importing again updates what came before instead of duplicating it.', { yes: 'Import' }))) return;
    b.disabled = true;
    if (await act(A.importHubspot, {}, 'Importing. Big accounts take a few runs; this card says how it goes.')) setTimeout(again, 5000);
  });
  return card('Import from HubSpot', badge(st === 'Never' ? 'Not yet' : st === 'Partial' ? 'Under way' : st, { Done: 'good', Failed: 'bad', Partial: 'accent' }[st]),
    'A one-time copy of your HubSpot companies, contacts and deals, with their links. Connect HubSpot first in the portal, under Integrations.', [
      s.hubspot_note ? el('p', { class: st === 'Failed' ? 'crm-error' : 'oc-help' }, s.hubspot_note) : null,
      s.hubspot_at ? el('p', { class: 'oc-eyebrow' }, `Last finished ${stamp(s.hubspot_at)}`) : null,
      el('div', { class: 'oc-row' }, b),
    ]);
}
