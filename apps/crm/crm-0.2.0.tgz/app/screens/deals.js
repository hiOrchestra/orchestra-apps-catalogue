// Deals: every deal as a list, by state (open, stuck, won, lost), filtered by
// stage and owner, searched by name. A deal opens in its panel beside the
// list (deal.js), where it moves, is won or lost and gets its next step.
import { V, T, head, money, ago, dayOf, badge, settings, redraw, listTabs, C } from '../data.js';
import { dealPanel } from './deal.js';
import { newDeal } from './deal-form.js';

const { el, router } = Orch;
const VIEWS = [['', 'Open', { status: 'Open' }], ['stuck', 'Stuck', { stuck: 'yes' }], ['won', 'Won', { status: 'Won' }], ['lost', 'Lost', { status: 'Lost' }], ['all', 'All', {}]];

export function render(params, path) {
  const view = VIEWS.find((v) => v[0] === (params.view || '')) || VIEWS[0];
  Orch.load('view', async () => {
    const s = await settings();
    const counts = await Promise.all(VIEWS.slice(0, 2).map((v) => Orch.db.view(V.deals, { filter: v[2], limit: 1, count: true }).then((r) => r.total || 0)));
    const host = el('div');
    const base = view[0] ? `/deals/${view[0]}` : '/deals';
    const again = redraw(render, params);
    const owners = C.linesOf(s.owners);
    setTimeout(() => Orch.table({
      into: host, path: base, query: path, view: V.deals, filter: view[2], pageSize: 25, sort: view[0] === 'won' || view[0] === 'lost' ? 'closed_at:desc' : 'amount:desc',
      search: 'title', searchPlaceholder: 'Find a deal by name',
      filters: [
        { key: 'stage', label: 'Stage', options: s.stageList.map((x) => x.name) },
        owners.length ? { key: 'owner', label: 'Owner', options: owners } : null,
      ].filter(Boolean),
      columns: [
        { key: 'title', label: 'Deal' },
        { key: 'company', label: 'Company', format: (v) => v || '—' },
        { key: 'stage', label: 'Stage', render: (r) => (r.status === 'Open' ? (r.stuck === 'yes' ? [r.stage, ' ', badge('Stuck', 'warn')] : r.stage) : badge(r.status)) },
        { key: 'amount', label: 'Value', numeric: true, format: (v, r) => money(v, r.currency, s) },
        { key: 'next_step', label: 'Next step', clamp: true, sortable: false, render: (r) => (r.status !== 'Open' ? (r.lost_reason || '—')
          : r.next_step ? [r.next_step, r.next_step_due ? el('span', { class: 'oc-value oc-muted' }, ` · ${dayOf(r.next_step_due)}`) : null, r.overdue === 'yes' ? [' ', badge('Late', 'warn')] : null]
            : el('span', { class: 'oc-muted' }, 'None')) },
        { key: 'last_activity_at', label: 'Last activity', format: (v) => ago(v) },
        { key: 'owner', label: 'Owner', format: (v) => v || '—' },
      ],
      detail: { table: T.deals, title: 'Deal', render: (row) => dealPanel(row, again) },
      empty: view[0] === 'stuck' ? 'No deal is stuck: every open one had activity recently.' : 'No deals here. Create one, or import them from HubSpot in Settings.',
    }), 0);
    return el('div', { class: 'oc-stack oc-stack--loose' }, [
      head('Deals', `Every deal and where it stands. A deal is stuck when it had no activity for ${s.stuck_days || 14} days (Settings).`, [
        router.link('/pipeline', 'See the pipeline', { class: 'oc-btn' }),
        el('button', { class: 'oc-btn oc-btn--primary', type: 'button', onClick: () => newDeal(again) }, 'New deal'),
      ]),
      listTabs('/deals', VIEWS.map((v, i) => [v[0], v[1], counts[i]]), view[0], 'Which deals'),
      host,
    ]);
  });
}

