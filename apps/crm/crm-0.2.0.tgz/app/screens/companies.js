// Companies: every company with its people, open deals and what they are
// worth. The agent fills in a new company (industry, size, location, a short
// summary, LinkedIn) from the web, with its sources; Enrich again asks it once
// more. A company opens in a panel with its people, deals and timeline.
import { C, V, T, A, act, head, badge, ago, money, settings, redraw, field, input, area, select, formDialog, contactLink, dealLink } from '../data.js';
import { timeline, timelineView, noteBox, facts } from './record.js';
import { newDeal } from './deal-form.js';

const { el, fmt } = Orch;
const ENRICH = { Waiting: 'Waiting for the agent', Working: 'The agent is on it', Failed: 'Could not be enriched' };

export function render(params, path) {
  Orch.load('view', async () => {
    const s = await settings();
    const host = el('div');
    const again = redraw(render, params);
    setTimeout(() => Orch.table({
      into: host, path: '/companies', query: path, view: V.companies, pageSize: 25, sort: 'open_amount:desc', search: 'name', searchPlaceholder: 'Find a company',
      filters: [{ key: 'enrich_status', label: 'Enrichment', options: [['Waiting', 'Waiting'], ['Failed', 'Failed'], ['Done', 'Done']].map(([value, label]) => ({ value, label })) }],
      columns: [
        { key: 'name', label: 'Company' },
        { key: 'industry', label: 'Industry', render: (r) => r.industry || (ENRICH[r.enrich_status] ? badge(r.enrich_status === 'Failed' ? 'Failed' : 'Waiting') : '—') },
        { key: 'size', label: 'People', format: (v) => v || '—' },
        { key: 'location', label: 'Where', format: (v) => v || '—' },
        { key: 'contacts', label: 'Contacts', numeric: true, format: (v) => fmt.number(v || 0) },
        { key: 'open_amount', label: 'Open deals', numeric: true, format: (v, r) => (r.open_deals ? `${money(v, null, s)} · ${r.open_deals}` : '—') },
        { key: 'last_activity_at', label: 'Last activity', format: (v) => ago(v) },
      ],
      detail: { table: T.companies, title: 'Company', render: (row) => companyPanel(row, s, again) },
      empty: 'No companies yet. They appear when you add contacts with company addresses, import from HubSpot, or add one.',
    }), 0);
    return el('div', { class: 'oc-stack oc-stack--loose' }, [
      head('Companies', 'Every company you deal with. The agent fills in new ones from the web, and says where it read it.', [
        el('button', { class: 'oc-btn oc-btn--primary', type: 'button', onClick: () => companyForm(null, again) }, 'New company'),
      ]),
      host,
    ]);
  });
}

async function companyPanel(row, s, again) {
  const [people, deals] = await Promise.all([
    Orch.db.list(T.contacts, { filter: { company_id: row._id, status: ['Lead', 'Contacted', 'Customer', 'Lost'] }, sort: 'name:asc', limit: 50 }),
    Orch.db.list(T.deals, { filter: { company_id: row._id }, sort: '_id:desc', limit: 30 }),
  ]);
  const acts = await timeline({ company: row._id, dealIds: (deals.rows || []).map((d) => d._id) });
  const enrich = el('button', { class: 'oc-btn oc-btn--sm', type: 'button' }, row.enriched_at ? 'Enrich again' : 'Enrich now');
  enrich.addEventListener('click', async () => { enrich.disabled = true; if (await act(A.enrichAgain, { id: row._id }, 'The agent will look it up within a few minutes.')) again(); });
  const state = row.enrich_status && ENRICH[row.enrich_status]
    ? el('div', { class: 'oc-row' }, [badge(row.enrich_status === 'Failed' ? 'Failed' : row.enrich_status), el('span', { class: 'oc-help' }, row.enrich_note || ENRICH[row.enrich_status])])
    : el('p', { class: 'oc-help' }, row.enriched_at ? `Filled in by the agent ${ago(row.enriched_at)}. ${row.enrich_note || ''}` : (row.enrich_note || 'Not enriched yet.'));
  const url = (v, text) => (/^https?:\/\//.test(v || '') ? el('a', { href: v, target: '_blank', rel: 'noopener' }, text || v.replace(/^https?:\/\/(www\.)?/, '')) : null);
  return el('div', { class: 'oc-stack crm-panel' }, [
    el('div', { class: 'oc-stack oc-stack--tight' }, [el('h2', { class: 'oc-h1 crm-panel__title' }, row.name || row.domain), row.domain ? el('p', { class: 'oc-eyebrow' }, row.domain) : null]),
    row.summary ? el('p', { class: 'crm-summary' }, row.summary) : null,
    facts([['Industry', row.industry], ['People', row.size], ['Where', row.location], ['Website', url(row.website)], ['LinkedIn', url(row.linkedin, 'Company page')],
      ['Owner', row.owner], ['Tags', C.tagsOf(row.tags).join(', ')], ['Source', row.source]]),
    el('div', { class: 'crm-next' }, [el('span', { class: 'oc-eyebrow' }, 'Enrichment'), state, el('div', { class: 'oc-row' }, [enrich,
      el('button', { class: 'oc-btn oc-btn--sm oc-btn--ghost', type: 'button', onClick: () => companyForm(row, again) }, 'Edit'),
      el('button', { class: 'oc-btn oc-btn--sm', type: 'button', onClick: () => newDeal(again, { company_id: row._id }) }, 'New deal')])]),
    list('People', (people.rows || []).map((p) => [contactLink(p._id, p.name || p.email), p.title || '', badge(p.status)])),
    list('Deals', (deals.rows || []).map((d) => [dealLink(d._id, d.title), el('span', { class: 'oc-value' }, money(d.amount, d.currency, s)), badge(d.status === 'Open' ? d.stage : d.status, d.status === 'Open' ? '' : undefined)])),
    noteBox({ company_id: row._id }, again),
    el('h3', { class: 'oc-h2' }, 'What happened'),
    timelineView(acts),
  ]);
}

function list(title, rows) {
  if (!rows.length) return null;
  return el('div', { class: 'oc-stack oc-stack--tight' }, [el('span', { class: 'oc-eyebrow' }, title),
    el('ul', { class: 'crm-rows crm-rows--flush' }, rows.map(([a, b, c]) => el('li', { class: 'crm-row crm-row--3' }, [el('div', { class: 'crm-row__main' }, a), el('span', {}, b), c])))]);
}

function companyForm(row, after) {
  const r = row || {};
  const name = input(r.name, { required: true, maxlength: '160' });
  const domain = input(r.domain, { placeholder: 'acme.com', maxlength: '120' });
  const website = input(r.website, { type: 'url', placeholder: 'https://' });
  const linkedin = input(r.linkedin, { type: 'url', placeholder: 'https://www.linkedin.com/company/…' });
  const industry = input(r.industry, { maxlength: '80' });
  const size = select([['', '—'], ...C.SIZES.map((x) => [x, x])], r.size);
  const location = input(r.location, { maxlength: '120' });
  const summary = area(r.summary, 3, { maxlength: '600' });
  const tags = input(C.tagsOf(r.tags).join(', '));
  return formDialog(row ? 'Edit company' : 'New company', [
    field('Name', name), field('Domain', domain, 'Its email domain: people with addresses there are linked to it on their own.'), field('Website', website), field('LinkedIn', linkedin),
    field('Industry', industry), field('People', size), field('Where', location), row ? field('Summary', summary) : null, field('Tags', tags, 'Separated by commas.'),
    row ? null : el('p', { class: 'oc-help' }, 'Leave what you do not know empty: the agent fills it in from the web in a few minutes.'),
  ].filter(Boolean), async () => {
    const d = domain.value.trim().toLowerCase().replace(/^https?:\/\//, '').replace(/^www\./, '').replace(/\/.*$/, '');
    const p = { name: name.value.trim(), domain: d, website: website.value.trim(), linkedin: linkedin.value.trim(), industry: industry.value.trim(), size: size.value,
      location: location.value.trim(), tags: C.tagsText(tags.value) };
    const ok = row ? await act(A.editCompany, Object.assign({ id: row._id, summary: summary.value.trim() }, p), 'Saved.')
      : await act(A.newCompany, Object.assign(Object.fromEntries(Object.entries(p).filter(([, v]) => v !== '')), { source: 'CRM' }), 'Company added. The agent will fill in the rest.');
    if (ok) after();
    return ok;
  }, row ? 'Save' : 'Add company');
}
