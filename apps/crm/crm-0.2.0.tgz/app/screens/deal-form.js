// The deal form: New deal (no row) and Edit, the same fields and two actions.
// A new deal starts in the stage chosen here, with its creation on the
// timeline; the stage of an existing one moves from its panel, not here.
import { C, T, A, act, field, input, select, formDialog, settings, openStages, choices } from '../data.js';

/** New deal (row null) or Edit: the same fields, two actions. */
export async function dealForm(row, after, preset = {}) {
  const s = await settings();
  const [companies, people] = await Promise.all([choices(T.companies), choices(T.contacts, { status: ['Lead', 'Contacted', 'Customer', 'Lost'] })]);
  const r = row || preset;
  const title = input(r.title, { required: true, maxlength: '160' });
  const company = select(companies, r.company_id);
  const contact = select(people, r.contact_id);
  const stage = select(openStages(s).map((x) => x.name), r.stage || openStages(s)[0].name);
  const amount = input(r.amount, { type: 'number', min: '0', step: 'any', inputmode: 'decimal' });
  const currency = input(r.currency || s.currency || 'EUR', { maxlength: '3', size: '4' });
  const close = input(r.expected_close || '', { type: 'date' });
  const owners = C.linesOf(s.owners);
  const owner = owners.length ? select([['', '—'], ...owners.map((o) => [o, o])], r.owner) : input(r.owner || '', { type: 'email' });
  const fields = [field('Name', title, 'Who and what: "Acme · warehouse pilot".'), field('Company', company), field('Contact', contact, 'The person the agent writes to about it.'),
    row ? null : field('Stage', stage), field('Value', amount), field('Currency', currency), field('Expected close', close), field('Owner', owner)].filter(Boolean);
  return formDialog(row ? 'Edit deal' : 'New deal', fields, async () => {
    const p = { title: title.value.trim(), company_id: company.value ? Number(company.value) : '', contact_id: contact.value ? Number(contact.value) : '',
      amount: amount.value === '' ? '' : Number(amount.value), currency: currency.value.trim().toUpperCase(), expected_close: close.value, owner: owner.value.trim() };
    const ok = row ? await act(A.editDeal, Object.assign({ id: row._id }, p), 'Saved.')
      : await act(A.newDeal, Object.assign(Object.fromEntries(Object.entries(p).filter(([, v]) => v !== '')), { stage: stage.value, stage_note: 'Deal created', source: 'CRM' }), 'Deal created.');
    if (ok && after) after(ok);
    return ok;
  }, row ? 'Save' : 'Create deal');
}
export const newDeal = (after, preset) => dealForm(null, after, preset);
