// Pipeline: every open deal in a column per stage, with what each column is
// worth. A card moves with its "Move to…" control (no dragging: it works with
// a keyboard and on a phone), and opens in Deals. Won and lost are decided
// in the deal's panel, with a reason for a loss. Moving a card draws the
// screen again a moment later, so the sums follow.
import { T, V, A, head, metric, money, settings, openStages } from '../data.js';
import { newDeal } from './deal-form.js';

const { el, fmt } = Orch;

export function render() {
  Orch.load('view', async () => {
    const s = await settings(true);
    const stages = openStages(s);
    const [totals, stuck] = await Promise.all([Orch.db.view(V.totals, { limit: 200 }), Orch.db.view(V.deals, { filter: { stuck: 'yes' }, limit: 1, count: true })]);
    const rows = totals.rows || [];
    const cur = s.currency || 'EUR';
    const prob = new Map(stages.map((x) => [x.name, x.probability / 100]));
    const mine = rows.filter((r) => !r.currency || r.currency === cur);
    const others = [...new Set(rows.filter((r) => r.currency && r.currency !== cur).map((r) => r.currency))];
    const sum = (f) => mine.reduce((n, r) => n + f(r), 0);
    const host = el('div');
    const screen = el('div', { class: 'oc-stack oc-stack--loose crm-pipeline' }, [
      head('Pipeline', 'Every open deal by stage, and what each stage is worth. Move a card with its control; open it to win, lose or plan the next step.', [
        el('button', { class: 'oc-btn oc-btn--primary', type: 'button', onClick: () => newDeal(() => render()) }, 'New deal'),
      ]),
      el('div', { class: 'oc-metrics' }, [
        metric('Open deals', fmt.number(sum((r) => Number(r.deals))), others.length ? `plus deals in ${others.join(', ')}` : 'in the pipeline'),
        metric('Open value', money(sum((r) => Number(r.amount || 0)), cur), 'everything still open'),
        metric('Weighted', money(Math.round(sum((r) => Number(r.amount || 0) * (prob.get(r.stage) || 0))), cur), 'by each stage\'s probability'),
        metric('Stuck', fmt.number(stuck.total || 0), 'see them', '/deals/stuck'),
      ]),
      host,
    ]);
    // What each column is worth goes in its head, after the stage and its probability.
    const worth = new Map(stages.map((x) => [x.name, mine.filter((r) => r.stage === x.name).reduce((n, r) => n + Number(r.amount || 0), 0)]));
    setTimeout(() => Orch.pattern('board', {
      into: host, table: T.deals, stage: 'stage', filter: { status: 'Open' }, sort: 'stage_changed_at:asc', pageSize: 30,
      stages: stages.map((x) => ({ value: x.name, label: `${x.name} · ${x.probability}% · ${money(worth.get(x.name), cur)}` })),
      moveAction: A.moveDeal, labelColumn: 'title', detailPath: '/deals?open=:id',
      columns: [{ key: 'amount', format: (v, r) => (v ? money(v, r.currency, s) : '') }, { key: 'next_step', format: (v) => v || 'No next step' }],
    }), 0);
    // A card moved: the board redraws its lanes; the sums and the strip are drawn again once the move is saved.
    host.addEventListener('change', (e) => { if (e.target.closest('.oc-board__card') && e.target.value) setTimeout(() => { if (host.isConnected) render(); }, 1500); });
    return screen;
  });
}
