SELECT MIN(d._id) AS _id, d.stage AS stage, COALESCE(d.currency, '') AS currency, COUNT(*) AS deals, COALESCE(SUM(d.amount), 0) AS amount
FROM crm_deals d
WHERE d.status = 'Open'
GROUP BY d.stage, COALESCE(d.currency, '')
