SELECT c._id AS _id, c.name AS name, c.email AS email, c.title AS title, c.phone AS phone, c.status AS status, c.owner AS owner,
  c.source AS source, c.tags AS tags, c.suggested_why AS suggested_why, c.last_activity_at AS last_activity_at, c.company_id AS company_id,
  co.name AS company, c._created_at AS created_at,
  (SELECT COUNT(*) FROM crm_deals d WHERE d.contact_id = c._id AND d.status = 'Open') AS open_deals
FROM crm_contacts c
LEFT JOIN crm_companies co ON co._id = c.company_id
