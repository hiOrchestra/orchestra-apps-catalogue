'use strict';
/**
 * CRM · Sync mail and calendar. Read only: nothing is sent, nothing changes in
 * Gmail or the calendar.
 *
 *   Gmail     every message since the last sync (Composio GMAIL_FETCH_EMAILS):
 *             with a known contact it becomes an activity (email in / out) on
 *             that contact; a new correspondent at a company domain (never
 *             gmail.com and the like, never no-reply, never your own domain)
 *             becomes a Suggested contact for a person to accept or ignore.
 *   Calendar  events from the last sync to two weeks ahead
 *             (GOOGLECALENDAR_EVENTS_LIST): a meeting with a known contact
 *             becomes a meeting activity; a moved one moves, a cancelled one goes.
 *   Companies every contact (not a suggestion) with a company address gets its
 *             company, created from the domain when there is none yet; a new
 *             company waits for enrichment.
 *
 *   node sync.js --auto   the half-hourly run: only while sync is on and nothing is paused
 *   node sync.js --now    a person pressed Sync now
 *   node sync.js --link   only the companies (after contacts were accepted or added)
 *   --dry-run             says what it would write, writes nothing
 */
const L = require('./lib');
const X = require('./composio');

const { C } = L;
const MAX_MESSAGES = 300;
const BUDGET_MS = 90000;
const QUERY_TAIL = '-in:chats -category:promotions -category:social';

async function run(mode = '--auto', { dry = false } = {}) {
  const t0 = Date.now();
  const held = L.lock('sync');
  if (!held) return { ok: true, mode, skipped: 'Another sync is running' };
  try {
    const s = L.settings();
    const out = { ok: true, mode };
    const plan = { ops: [], dry };
    if (mode !== '--link') {
      if (mode === '--auto' && Number(s.paused) === 1) return Object.assign(out, { skipped: 'The CRM is paused in Settings' });
      const notes = [];
      const settingsData = {};
      if (Number(s.sync_gmail) === 1) {
        try { Object.assign(out, await gmail(s, plan, settingsData, t0)); } catch (e) { notes.push(`Gmail: ${e.message}`); out.gmailError = e.message; }
      }
      if (Number(s.sync_calendar) === 1) {
        try { Object.assign(out, await calendar(s, plan, settingsData)); } catch (e) { notes.push(`Calendar: ${e.message}`); out.calendarError = e.message; }
      }
      if (Number(s.sync_gmail) !== 1 && Number(s.sync_calendar) !== 1) {
        if (mode === '--auto') return Object.assign(out, { skipped: 'Sync is off in Settings' });
        out.note = 'Mail and calendar sync are off in Settings: only companies were linked';
      }
      settingsData.sync_note = notes.length ? notes.join(' · ').slice(0, 400) : null;
      plan.ops.push({ op: 'update', table: 'crm_settings', id: s._id, data: settingsData });
    }
    apply(plan);
    const touched = new Set(plan.touched || []);
    const linked = linkCompanies(s, { dry });
    out.companiesCreated = linked.created;
    out.contactsLinked = linked.linked;
    if (!dry) refreshLastActivity([...touched]);
    if (dry) out.wouldWrite = plan.ops.length + linked.ops;
    return out;
  } finally {
    held.release();
  }
}

function apply(plan) {
  if (!plan.dry && plan.ops.length) L.write(plan.ops);
}

/** Every address that is a contact now: lower(email) -> { _id, status, company_id }. */
function knownContacts() {
  const map = new Map();
  for (const c of L.all("SELECT _id, email, status, company_id FROM crm_contacts WHERE _deleted = 0 AND email IS NOT NULL AND email <> ''")) {
    map.set(C.normEmail(c.email), c);
  }
  return map;
}
const seen = (externalId) => !!L.one('SELECT 1 AS x FROM crm_activities WHERE external_id = ? AND _deleted = 0', externalId);

async function gmail(s, plan, settingsData, t0) {
  const account = s.gmail_account || undefined;
  let me = C.normEmail(s.gmail_address);
  if (!me) {
    me = await X.gmailProfile(account);
    if (me) settingsData.gmail_address = me;
  }
  const myDomain = C.domainOf(me);
  const startedAt = new Date();
  const since = L.toDate(s.gmail_synced_at) || new Date(Date.now() - Math.max(1, Number(s.sync_days_back) || 30) * 86400000);
  // Five minutes back: a message stamped just before the last run but delivered after it is not lost. Repeats are skipped by id.
  const sinceSec = Math.floor((since.getTime() - 300000) / 1000);
  // Gmail answers newest first, so a read that hits the cap is missing the OLDEST
  // part of its window. That part is kept as { after, before } (epoch seconds)
  // and read on the next runs, until nothing of it is left.
  let backfill = null;
  try { backfill = s.gmail_backfill ? JSON.parse(s.gmail_backfill) : null; } catch { backfill = null; }
  if (backfill && !(Number(backfill.after) < Number(backfill.before))) backfill = null;
  const messages = [];
  const read = async (query, cap) => {
    const got = [];
    let token = null;
    let more = false;
    do {
      const p = await X.gmailFetch({ query, pageToken: token, account });
      got.push(...p.messages);
      token = p.next;
      more = !!token;
    } while (token && got.length < cap && Date.now() - t0 < BUDGET_MS);
    messages.push(...got);
    const times = got.map((m) => (m.at ? new Date(m.at).getTime() : NaN)).filter(Number.isFinite);
    return { more, oldestSec: times.length ? Math.floor(Math.min(...times) / 1000) + 1 : null };
  };
  const recent = await read(`after:${sinceSec} ${QUERY_TAIL}`, MAX_MESSAGES);
  let more = recent.more;
  if (recent.more && recent.oldestSec) {
    // Whatever was pending stays pending: its range joins the one just left behind.
    backfill = { after: backfill ? Math.min(Number(backfill.after), sinceSec) : sinceSec, before: recent.oldestSec };
  } else if (backfill && messages.length < MAX_MESSAGES && Date.now() - t0 < BUDGET_MS) {
    const old = await read(`after:${backfill.after} before:${backfill.before} ${QUERY_TAIL}`, MAX_MESSAGES - messages.length);
    if (old.more && old.oldestSec && old.oldestSec < Number(backfill.before)) backfill = { after: Number(backfill.after), before: old.oldestSec };
    else if (!old.more) backfill = null;
    more = more || old.more;
  }
  settingsData.gmail_backfill = backfill ? JSON.stringify(backfill) : '';

  const known = knownContacts();
  const fresh = new Map(); // a new correspondent's address -> { name, why, n }
  const touched = new Set();
  let n = 0;
  for (const m of messages) {
    const from = C.addresses(m.from)[0];
    if (!from) continue;
    const out = from.email === me;
    const others = out ? C.addresses(`${m.to},${m.cc}`) : [from];
    const at = C.sqlTime(m.at || new Date());
    for (const who of others) {
      if (who.email === me) continue;
      const c = known.get(who.email);
      if (c) {
        if (c.status === 'Ignored') continue;
        const ext = `gmail:${m.id}:${who.email}`;
        if (seen(ext)) continue;
        plan.ops.push({ op: 'insert', table: 'crm_activities', data: {
          type: out ? 'email_out' : 'email_in', contact_id: c._id, company_id: c.company_id || null, at,
          subject: L.clean(m.subject, 200) || '(no subject)', summary: L.clean(m.snippet, 300), external_id: ext, source: 'gmail' } });
        if (out && c.status === 'Lead') {
          plan.ops.push({ op: 'update', table: 'crm_contacts', id: c._id, when: { status: 'Lead' }, data: { status: 'Contacted' } });
          c.status = 'Contacted';
        }
        touched.add(c._id);
        n += 1;
      } else if (suggestible(who.email, myDomain, m.labels)) {
        const f = fresh.get(who.email) || { name: who.name, why: '', n: 0, msgs: [] };
        f.n += 1;
        f.name = f.name || who.name;
        f.why = f.why || (out ? `You wrote to them: "${L.clean(m.subject, 80)}"` : `Wrote to you: "${L.clean(m.subject, 80)}"`);
        f.msgs.push({ m, out, at });
        fresh.set(who.email, f);
      }
    }
  }
  // A suggestion with its messages, so accepting it keeps the history.
  let i = 0;
  for (const [email, f] of fresh) {
    const as = `sug${i += 1}`;
    const company = L.one("SELECT _id FROM crm_companies WHERE _deleted = 0 AND lower(domain) = ?", C.domainOf(email));
    plan.ops.push({ op: 'insert', table: 'crm_contacts', as, data: {
      email, name: L.clean(f.name, 120) || null, status: 'Suggested', source: 'Gmail', company_id: company ? company._id : null,
      suggested_why: f.n > 1 ? `${f.why} and ${f.n - 1} more` : f.why } });
    for (const x of f.msgs.slice(0, 20)) {
      plan.ops.push({ op: 'insert', table: 'crm_activities', data: {
        type: x.out ? 'email_out' : 'email_in', contact_id: `$${as}._id`, company_id: company ? company._id : null, at: x.at,
        subject: L.clean(x.m.subject, 200) || '(no subject)', summary: L.clean(x.m.snippet, 300), external_id: `gmail:${x.m.id}:${email}`, source: 'gmail' } });
    }
  }
  plan.touched = [...(plan.touched || []), ...touched];
  settingsData.gmail_synced_at = L.sqlNow(startedAt);
  return { gmail: { messages: messages.length, activities: n, suggested: fresh.size, capped: more || undefined, olderStillToRead: backfill ? true : undefined } };
}

/** A new correspondent worth suggesting: a person at a company, not a mailbox of a free provider, a machine or your own domain. */
function suggestible(email, myDomain, labels) {
  const d = C.domainOf(email);
  if (!d || C.isFree(d) || C.isMachine(email) || d === myDomain) return false;
  return !(labels || []).some((l) => /^CATEGORY_(UPDATES|FORUMS|PROMOTIONS|SOCIAL)$|^SPAM$/.test(l));
}

async function calendar(s, plan, settingsData) {
  const account = s.gmail_account || undefined;
  const startedAt = new Date();
  const since = L.toDate(s.calendar_synced_at) || new Date(Date.now() - Math.max(1, Number(s.sync_days_back) || 30) * 86400000);
  const timeMin = new Date(since.getTime() - 86400000).toISOString();
  const timeMax = new Date(Date.now() + 14 * 86400000).toISOString();
  const known = knownContacts();
  const touched = new Set();
  let token = null;
  let events = 0;
  let meetings = 0;
  let gone = 0;
  do {
    const p = await X.calendarEvents({ timeMin, timeMax, pageToken: token, account });
    token = p.next;
    for (const e of p.events) {
      events += 1;
      if (e.status === 'cancelled') {
        const ids = L.all("SELECT _id FROM crm_activities WHERE _deleted = 0 AND external_id LIKE ?", `gcal:${e.id}:%`).map((r) => r._id);
        if (ids.length && !plan.dry) gone += L.softDelete('crm_activities', ids);
        continue;
      }
      const people = e.attendees.filter((a) => !a.self && known.has(a.email) && known.get(a.email).status !== 'Ignored');
      const names = e.attendees.filter((a) => !a.self).map((a) => a.name || a.email).slice(0, 6).join(', ');
      for (const a of people) {
        const c = known.get(a.email);
        const ext = `gcal:${e.id}:${a.email}`;
        const data = { at: C.sqlTime(e.start), subject: L.clean(e.subject, 200), summary: L.clean(`With ${names}`, 300) };
        const had = L.one('SELECT _id, at, subject FROM crm_activities WHERE external_id = ? AND _deleted = 0', ext);
        if (had) {
          if (had.at !== data.at || had.subject !== data.subject) plan.ops.push({ op: 'update', table: 'crm_activities', id: had._id, data });
        } else {
          plan.ops.push({ op: 'insert', table: 'crm_activities', data: Object.assign(data, {
            type: 'meeting', contact_id: c._id, company_id: c.company_id || null, external_id: ext, source: 'calendar' }) });
          meetings += 1;
        }
        touched.add(c._id);
      }
    }
  } while (token);
  plan.touched = [...(plan.touched || []), ...touched];
  settingsData.calendar_synced_at = L.sqlNow(startedAt);
  return { calendar: { events, meetings, cancelled: gone } };
}

/**
 * Every contact that is not a suggestion and has a company address gets its
 * company: the one with that domain, or a new one named after the domain,
 * waiting for enrichment. Their activities with no company get it too.
 */
function linkCompanies(s, { dry = false } = {}) {
  const myDomain = C.domainOf(s.gmail_address);
  const rows = L.all(`SELECT _id, email FROM crm_contacts WHERE _deleted = 0 AND company_id IS NULL
    AND COALESCE(status, '') NOT IN ('Suggested', 'Ignored') AND email IS NOT NULL AND email <> ''`);
  const ops = [];
  const made = new Map();
  let linked = 0;
  for (const c of rows) {
    const d = C.domainOf(c.email);
    if (!d || C.isFree(d) || d === myDomain) continue;
    let ref = made.get(d);
    if (!ref) {
      const co = L.one('SELECT _id FROM crm_companies WHERE _deleted = 0 AND lower(domain) = ?', d);
      if (co) ref = co._id;
      else {
        ref = `$co${made.size + 1}._id`;
        ops.push({ op: 'insert', table: 'crm_companies', as: `co${made.size + 1}`, data: {
          name: C.nameFromDomain(d), domain: d, website: `https://${d}`, source: 'Auto', enrich_status: 'Waiting', enrich_attempts: 0 } });
      }
      made.set(d, ref);
    }
    ops.push({ op: 'update', table: 'crm_contacts', id: c._id, data: { company_id: ref } });
    for (const a of L.all('SELECT _id FROM crm_activities WHERE _deleted = 0 AND contact_id = ? AND company_id IS NULL', c._id)) {
      ops.push({ op: 'update', table: 'crm_activities', id: a._id, data: { company_id: ref } });
    }
    linked += 1;
  }
  const created = ops.filter((o) => o.op === 'insert').length;
  if (!dry && ops.length) L.write(ops);
  return { created, linked, ops: ops.length };
}

/** A contact's last activity: the latest one that already happened (a meeting next week is not activity yet). */
function refreshLastActivity(ids) {
  const ops = [];
  for (const id of ids) {
    const r = L.one("SELECT MAX(datetime(at)) AS at FROM crm_activities WHERE _deleted = 0 AND contact_id = ? AND type <> 'stage' AND datetime(at) <= datetime('now')", id);
    if (r && r.at) ops.push({ op: 'update', table: 'crm_contacts', id, data: { last_activity_at: r.at } });
  }
  if (ops.length) L.write(ops);
}

if (require.main === module) {
  const argv = process.argv.slice(2);
  const mode = ['--auto', '--now', '--link'].find((m) => argv.includes(m)) || '--auto';
  run(mode, { dry: argv.includes('--dry-run') })
    .then((r) => L.done(r))
    .catch((e) => { L.done({ ok: false, mode, error: e.message }); process.exitCode = 1; });
}

module.exports = { run, linkCompanies, refreshLastActivity, suggestible };
