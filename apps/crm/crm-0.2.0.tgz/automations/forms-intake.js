'use strict';
/**
 * CRM · Leads from Forms. Every Forms response that is Complete and carries an
 * email (Forms checks it first) becomes a contact, or updates the one with that
 * address, plus a "form" activity with what they answered. A suggestion or an
 * ignored address that fills a form is a real lead: it becomes a Lead.
 *
 * Reads only forms_responses / forms_answers / forms_forms, newer than the
 * last one it took (crm_settings.forms_last_id); never changes Forms. When
 * Forms is not installed in this project, it says so and does nothing.
 *   node forms-intake.js [--auto|--now] [--dry-run]
 */
const L = require('./lib');
const { linkCompanies } = require('./sync');

const { C } = L;
const BATCH = 200;

function run(mode = '--auto', { dry = false } = {}) {
  const s = L.settings();
  if (Number(s.forms_intake) !== 1 && mode === '--auto') return { ok: true, mode, skipped: 'Leads from Forms is off in Settings' };
  if (mode === '--auto' && Number(s.paused) === 1) return { ok: true, mode, skipped: 'The CRM is paused in Settings' };
  if (!L.hasTable('forms_responses')) return { ok: true, mode, skipped: 'Forms is not installed in this project' };
  const held = L.lock('forms');
  if (!held) return { ok: true, mode, skipped: 'Another run is taking leads from Forms' };
  try {
    const last = Number(s.forms_last_id) || 0;
    const rows = L.all(`SELECT r._id, r.email, r.form_id, r._created_at, f.title AS form FROM forms_responses r
      LEFT JOIN forms_forms f ON f._id = r.form_id
      WHERE r._deleted = 0 AND r.status = 'Complete' AND COALESCE(r.email, '') <> '' AND r._id > ? ORDER BY r._id LIMIT ${BATCH}`, last);
    const out = { ok: true, mode, responses: rows.length, created: 0, updated: 0 };
    if (!rows.length) return out;
    const ops = [];
    const made = new Map(); // address -> the contact this run creates, so two responses from one person make one contact
    let i = 0;
    for (const r of rows) {
      const email = C.normEmail(r.email);
      if (!C.isEmail(email)) continue;
      const answers = L.all('SELECT question, type, value FROM forms_answers WHERE _deleted = 0 AND response_id = ? ORDER BY _id', r._id);
      const pick = (rx, type) => (answers.find((a) => (type && a.type === type) || (rx && rx.test(a.question))) || {}).value || '';
      const name = L.clean(pick(/(^|_)(name|nombre|full_?name)($|_)/i), 120);
      const phone = L.clean(pick(null, 'phone_number'), 40);
      const title = L.clean(pick(/(^|_)(title|role|cargo|puesto|job)($|_)/i), 120);
      const have = made.get(email) || L.one('SELECT * FROM crm_contacts WHERE _deleted = 0 AND lower(email) = ?', email);
      let ref;
      if (have && have._id) {
        ref = have._id;
        const data = {};
        if (!have.name && name) data.name = name;
        if (!have.phone && phone) data.phone = phone;
        if (!have.title && title) data.title = title;
        if (['Suggested', 'Ignored'].includes(have.status)) data.status = 'Lead';
        if (Object.keys(data).length) ops.push({ op: 'update', table: 'crm_contacts', id: have._id, data });
        out.updated += 1;
      } else if (have) {
        ref = have.ref;
      } else {
        const as = `c${i += 1}`;
        ref = `$${as}._id`;
        ops.push({ op: 'insert', table: 'crm_contacts', as, data: { email, name: name || null, phone: phone || null, title: title || null,
          status: 'Lead', source: 'Forms', last_activity_at: L.toDate(r._created_at) ? L.sqlNow(L.toDate(r._created_at)) : L.sqlNow() } });
        made.set(email, { ref });
        out.created += 1;
      }
      const lines = answers.filter((a) => a.type !== 'email').slice(0, 6).map((a) => `${a.question.replace(/_/g, ' ')}: ${a.value}`);
      ops.push({ op: 'insert', table: 'crm_activities', data: {
        type: 'form', contact_id: ref, company_id: have && have.company_id ? have.company_id : null, at: L.toDate(r._created_at) ? L.sqlNow(L.toDate(r._created_at)) : L.sqlNow(),
        subject: L.clean(`Answered "${r.form || 'a form'}"`, 200), summary: L.clean(lines.join(' · '), 600), external_id: `forms:${r._id}`, source: 'forms' } });
    }
    ops.push({ op: 'update', table: 'crm_settings', id: s._id, data: { forms_last_id: rows[rows.length - 1]._id,
      forms_note: `${L.sqlNow()} UTC: ${out.created} new leads, ${out.updated} updated from ${rows.length} responses` } });
    if (dry) return Object.assign(out, { dry: true, wouldWrite: ops.length });
    // Responses already taken (a run that died after writing) are skipped by their unique id, not written twice.
    const fresh = ops.filter((o) => !(o.table === 'crm_activities' && L.one('SELECT 1 AS x FROM crm_activities WHERE external_id = ? AND _deleted = 0', o.data.external_id)));
    L.write(fresh);
    const linked = linkCompanies(L.settings());
    return Object.assign(out, { companiesCreated: linked.created });
  } finally {
    held.release();
  }
}

if (require.main === module) {
  const argv = process.argv.slice(2);
  const mode = argv.includes('--now') ? '--now' : '--auto';
  try { L.done(run(mode, { dry: argv.includes('--dry-run') })); } catch (e) { L.done({ ok: false, error: e.message }); process.exitCode = 1; }
}

module.exports = { run };
