'use strict';
/**
 * Every call the CRM makes to Composio, and nothing else: the tool slugs,
 * their arguments, and how each answer is read. When Composio renames an
 * argument, this is the only file to change.
 *
 *   gmailProfile()                      GMAIL_GET_PROFILE          the connected mailbox's address
 *   gmailFetch({ query, pageToken })    GMAIL_FETCH_EMAILS         one page of messages (read only)
 *   gmailSend({ to, subject, body })    GMAIL_SEND_EMAIL           one email, from the connected account
 *   calendarEvents({ timeMin, … })      GOOGLECALENDAR_EVENTS_LIST one page of events (read only)
 *   hubspotPage(kind, after)            HUBSPOT_LIST_COMPANIES / _CONTACTS / _DEALS, 100 at a time
 *
 * Scripts reach Composio through the instance (POST 127.0.0.1:3001
 * /api/composio/execute {toolSlug, arguments, account}) as the workflow's
 * agent; the platform key never enters the container.
 *
 * CRM_FAKE_COMPOSIO=1 answers from CRM_FAKE_DATA (a JSON file: gmail,
 * calendar, hubspot) and writes every email "sent" to CRM_FAKE_OUTBOX, one
 * JSON a line: the tests never reach Gmail or HubSpot. In the fake, an
 * address starting with fail@ is refused and timeout@ never answers.
 */
const http = require('http');
const fs = require('fs');
const { identityHeaders } = require('./lib');

const FAKE = process.env.CRM_FAKE_COMPOSIO === '1';
const SLUG = {
  profile: 'GMAIL_GET_PROFILE', fetch: 'GMAIL_FETCH_EMAILS', send: 'GMAIL_SEND_EMAIL', events: 'GOOGLECALENDAR_EVENTS_LIST',
  companies: 'HUBSPOT_LIST_COMPANIES', contacts: 'HUBSPOT_LIST_CONTACTS', deals: 'HUBSPOT_LIST_DEALS',
};
const HUBSPOT_PROPS = {
  companies: ['name', 'domain', 'industry', 'numberofemployees', 'city', 'country', 'website', 'linkedin_company_page', 'description', 'hubspot_owner_id'],
  contacts: ['email', 'firstname', 'lastname', 'jobtitle', 'phone', 'associatedcompanyid', 'lifecyclestage', 'hs_lead_status', 'hubspot_owner_id'],
  deals: ['dealname', 'amount', 'deal_currency_code', 'dealstage', 'closedate', 'pipeline', 'hs_is_closed_won', 'hs_is_closed', 'closed_lost_reason', 'hubspot_owner_id'],
};
const HUBSPOT_ASSOC = { companies: [], contacts: ['companies'], deals: ['companies', 'contacts'] };

/** One Composio tool, the way the workflow engine calls it: its `data`, or an Error with Composio's own sentence. */
function execute(slug, args, { account, timeoutMs = 60000 } = {}) {
  if (FAKE) return fake(slug, args);
  return new Promise((resolve, reject) => {
    const body = JSON.stringify(Object.assign({ toolSlug: slug, arguments: args }, account ? { account } : {}));
    const req = http.request({
      hostname: '127.0.0.1', port: Number(process.env.API_SERVER_PORT || 3001), path: '/api/composio/execute', method: 'POST', agent: false,
      headers: { 'Content-Type': 'application/json', 'Content-Length': Buffer.byteLength(body), ...identityHeaders() },
    }, (res) => {
      let b = '';
      res.on('data', (c) => { b += c; });
      res.on('end', () => {
        let j;
        try { j = JSON.parse(b); } catch { return reject(new Error(`Composio answered ${res.statusCode}: ${b.slice(0, 200)}`)); }
        if (j && j.success && j.data && j.data.successful !== false) return resolve(j.data.data !== undefined ? j.data.data : j.data);
        const why = (j && j.data && j.data.error) || (j && j.error && (j.error.message || j.error)) || `HTTP ${res.statusCode}`;
        return reject(new Error(String(why).slice(0, 300)));
      });
    });
    req.on('error', reject);
    req.setTimeout(timeoutMs, () => req.destroy(Object.assign(new Error(`Composio did not answer in ${timeoutMs / 1000}s`), { timeout: true })));
    req.end(body);
  });
}

/** The first array under `key` anywhere in a nested answer (Composio wraps answers differently per tool). */
function arrayAt(obj, key, depth = 0) {
  if (!obj || typeof obj !== 'object' || depth > 4) return null;
  if (Array.isArray(obj[key])) return obj[key];
  for (const v of Object.values(obj)) {
    const found = arrayAt(v, key, depth + 1);
    if (found) return found;
  }
  return null;
}
/** The first scalar under `key` anywhere in a nested answer. */
function valueAt(obj, key, depth = 0) {
  if (!obj || typeof obj !== 'object' || depth > 5) return undefined;
  if (obj[key] !== undefined && obj[key] !== null && typeof obj[key] !== 'object') return obj[key];
  for (const v of Object.values(obj)) {
    const found = valueAt(v, key, depth + 1);
    if (found !== undefined) return found;
  }
  return undefined;
}

// ── Gmail ────────────────────────────────────────────────────────────────
async function gmailProfile(account) {
  const r = await execute(SLUG.profile, { user_id: 'me' }, { account });
  return String(valueAt(r, 'emailAddress') || valueAt(r, 'email_address') || '').toLowerCase();
}

/** One page of messages, newest first: { messages: [{ id, threadId, at, from, to, cc, subject, snippet, labels }], next }. */
async function gmailFetch({ query, pageToken, max = 50, account }) {
  const args = { user_id: 'me', query, max_results: max, include_payload: false, verbose: false };
  if (pageToken) args.page_token = pageToken;
  const r = await execute(SLUG.fetch, args, { account });
  const list = arrayAt(r, 'messages') || [];
  return {
    messages: list.map((m) => ({
      id: String(m.messageId || m.id || ''),
      threadId: String(m.threadId || m.thread_id || ''),
      at: timeOf(m.messageTimestamp || m.internalDate || m.date),
      from: String(m.sender || m.from || ''),
      to: String(m.to || ''),
      cc: String(m.cc || ''),
      subject: String(m.subject || (m.preview && m.preview.subject) || ''),
      snippet: String((m.preview && m.preview.body) || m.snippet || m.messageText || ''),
      labels: Array.isArray(m.labelIds) ? m.labelIds : [],
    })).filter((m) => m.id),
    next: String(valueAt(r, 'nextPageToken') || valueAt(r, 'next_page_token') || '') || null,
  };
}

/** A message's time as a Date: epoch milliseconds (as text or number) or an ISO / RFC 2822 date. */
function timeOf(v) {
  if (v === null || v === undefined || v === '') return null;
  const n = Number(v);
  const d = Number.isFinite(n) && String(v).trim() !== '' ? new Date(n < 1e12 ? n * 1000 : n) : new Date(String(v));
  return Number.isNaN(d.getTime()) ? null : d;
}

/** One plain-text email from the connected account: { id, threadId }. */
async function gmailSend({ to, subject, body, account }) {
  const r = await execute(SLUG.send, { user_id: 'me', recipient_email: to, subject, body, is_html: false }, { account, timeoutMs: 45000 });
  return { id: String(valueAt(r, 'id') || ''), threadId: String(valueAt(r, 'threadId') || '') };
}

// ── Google Calendar ──────────────────────────────────────────────────────
/** One page of the primary calendar's events in a window: { events: [{ id, status, start, subject, attendees, link }], next }. */
async function calendarEvents({ timeMin, timeMax, pageToken, account }) {
  const args = { calendarId: 'primary', timeMin, timeMax, singleEvents: true, orderBy: 'startTime', maxResults: 250 };
  if (pageToken) args.pageToken = pageToken;
  const r = await execute(SLUG.events, args, { account });
  const items = arrayAt(r, 'items') || arrayAt(r, 'events') || [];
  return {
    events: items.map((e) => ({
      id: String(e.id || ''),
      status: String(e.status || 'confirmed'),
      start: timeOf((e.start && (e.start.dateTime || e.start.date)) || e.start_time),
      subject: String(e.summary || '(no title)'),
      attendees: (Array.isArray(e.attendees) ? e.attendees : []).map((a) => ({ email: String(a.email || '').toLowerCase(), name: String(a.displayName || ''), self: !!a.self })),
      link: String(e.htmlLink || ''),
    })).filter((e) => e.id && e.start),
    next: String(valueAt(r, 'nextPageToken') || '') || null,
  };
}

// ── HubSpot ──────────────────────────────────────────────────────────────
/** One page of HubSpot companies, contacts or deals: { rows: [{ id, props, assoc: { companies: [ids], contacts: [ids] } }], next }. */
async function hubspotPage(kind, after) {
  const args = { limit: 100, properties: HUBSPOT_PROPS[kind], archived: false };
  if (HUBSPOT_ASSOC[kind].length) args.associations = HUBSPOT_ASSOC[kind];
  if (after) args.after = after;
  const r = await execute(SLUG[kind], args, { timeoutMs: 90000 });
  const list = arrayAt(r, 'results') || [];
  const idsOf = (a, k) => ((a && a[k] && Array.isArray(a[k].results)) ? a[k].results : []).map((x) => String(x.id || x.toObjectId || '')).filter(Boolean);
  return {
    rows: list.map((x) => ({ id: String(x.id || ''), props: x.properties || {},
      assoc: { companies: idsOf(x.associations, 'companies'), contacts: idsOf(x.associations, 'contacts') } })).filter((x) => x.id),
    next: (r && r.paging && r.paging.next && r.paging.next.after) ? String(r.paging.next.after) : (String(valueAt(r && r.paging, 'after') || '') || null),
  };
}

// ── the fake, for tests and the local harness ────────────────────────────
function fakeData() {
  try { return JSON.parse(fs.readFileSync(process.env.CRM_FAKE_DATA, 'utf8')); } catch { return {}; }
}
function page(list, after, size) {
  const from = Number(after) || 0;
  return { slice: list.slice(from, from + size), next: from + size < list.length ? String(from + size) : null };
}
function fake(slug, args) {
  const d = fakeData();
  if (d.gmail && d.gmail.fail && /^GMAIL_/.test(slug)) return Promise.reject(new Error(d.gmail.fail));
  if (slug === SLUG.profile) return Promise.resolve({ response_data: { emailAddress: (d.gmail && d.gmail.address) || 'me@crm-test.example' } });
  if (slug === SLUG.fetch) {
    const after = Number((String(args.query).match(/after:(\d+)/) || [])[1] || 0) * 1000;
    const before = Number((String(args.query).match(/before:(\d+)/) || [])[1] || 0) * 1000 || Infinity;
    // Newest first, like Gmail: a capped read is missing the OLDEST messages.
    const all = ((d.gmail && d.gmail.messages) || [])
      .filter((m) => Number(m.messageTimestamp) >= after && Number(m.messageTimestamp) < before)
      .sort((a, b) => Number(b.messageTimestamp) - Number(a.messageTimestamp));
    const p = page(all, args.page_token, Number(args.max_results) || 50);
    return Promise.resolve({ messages: p.slice, nextPageToken: p.next, resultSizeEstimate: all.length });
  }
  if (slug === SLUG.send) {
    const to = String(args.recipient_email || '');
    if (/^fail@/.test(to)) return Promise.reject(new Error('Invalid To header (fake)'));
    if (/^timeout@/.test(to)) return Promise.reject(Object.assign(new Error('Composio did not answer in 45s'), { timeout: true }));
    if (process.env.CRM_FAKE_OUTBOX) fs.appendFileSync(process.env.CRM_FAKE_OUTBOX, `${JSON.stringify(args)}\n`);
    return Promise.resolve({ response_data: { id: `fake-${Math.random().toString(36).slice(2, 10)}`, threadId: 't1', labelIds: ['SENT'] } });
  }
  if (slug === SLUG.events) {
    const all = ((d.calendar && d.calendar.events) || []).filter((e) => {
      const at = Date.parse((e.start && (e.start.dateTime || e.start.date)) || '');
      return at >= Date.parse(args.timeMin) && at <= Date.parse(args.timeMax);
    });
    const p = page(all, args.pageToken, 250);
    return Promise.resolve({ items: p.slice, nextPageToken: p.next });
  }
  const kind = Object.keys(SLUG).find((k) => SLUG[k] === slug && HUBSPOT_PROPS[k]);
  if (kind) {
    if (d.hubspot && d.hubspot.fail === kind) return Promise.reject(new Error('HubSpot is not connected (fake)'));
    const p = page((d.hubspot && d.hubspot[kind]) || [], args.after, Number(args.limit) || 100);
    return Promise.resolve({ results: p.slice, paging: p.next ? { next: { after: p.next } } : undefined });
  }
  return Promise.reject(new Error(`fake Composio has no ${slug}`));
}

module.exports = { SLUG, HUBSPOT_PROPS, execute, gmailProfile, gmailFetch, gmailSend, calendarEvents, hubspotPage, timeOf, arrayAt, valueAt };
