'use strict';
/**
 * CRM · Enrich companies: the two script steps around the agent's turn.
 *
 *   node enrich.js pick   claims up to "enrich_per_run" companies waiting
 *                         (Waiting -> Working, atomic) and prints what the agent
 *                         needs: each company's name, domain and what is known
 *   node enrich.js save   reads the agent's answer ($PRIOR), checks every field
 *                         and saves it; a company the answer left out goes back
 *                         to the queue (Failed after three tries)
 *
 * The agent searches the web and answers ONLY JSON; it never writes to the
 * database. Fields a person already filled are kept; the summary is the
 * agent's. Nothing is saved without a source the agent read.
 *   --dry-run (save)  says what it would write, writes nothing
 */
const L = require('./lib');

const { C } = L;
const TRIES = 3;
const STALE_MIN = 30;

function settingsOrNull() { try { return L.settings(); } catch { return null; } }

/** Claims left Working by a run that died go back to the queue, or fail after three tries. */
function unstick() {
  const stale = L.all(`SELECT _id, COALESCE(enrich_attempts, 0) AS n FROM crm_companies WHERE _deleted = 0 AND enrich_status = 'Working'
    AND datetime(enrich_claimed_at) <= datetime('now', '-${STALE_MIN} minutes')`);
  for (const r of stale) {
    try {
      L.write([{ op: 'update', table: 'crm_companies', id: r._id, when: { enrich_status: 'Working' }, data: r.n + 1 >= TRIES
        ? { enrich_status: 'Failed', enrich_attempts: r.n + 1, enrich_note: 'The agent did not finish three times. Press Enrich again to retry.' }
        : { enrich_status: 'Waiting', enrich_attempts: r.n + 1 } }]);
    } catch { /* taken meanwhile */ }
  }
  return stale.length;
}

function pick(mode = '--auto') {
  const s = settingsOrNull();
  if (!s) return { skip: true, why: 'The CRM is not installed in this project' };
  if (mode === '--auto' && Number(s.paused) === 1) return { skip: true, why: 'The CRM is paused in Settings' };
  const held = L.lock('enrich');
  if (!held) return { skip: true, why: 'Another enrichment run is picking companies' };
  try {
    const unstuck = unstick();
    const cap = Math.max(1, Math.min(20, Number(s.enrich_per_run) || 5));
    const rows = L.all(`SELECT _id, name, domain, website, linkedin, industry, location FROM crm_companies
      WHERE _deleted = 0 AND enrich_status = 'Waiting' ORDER BY _id LIMIT ${cap}`);
    const mine = [];
    for (const r of rows) {
      try {
        L.write([{ op: 'update', table: 'crm_companies', id: r._id, when: { enrich_status: 'Waiting' }, data: { enrich_status: 'Working', enrich_claimed_at: L.sqlNow() } }]);
        mine.push(r);
      } catch { /* another run took it */ }
    }
    if (!mine.length) return { skip: true, why: 'No company is waiting to be enriched', unstuck };
    return {
      companies: mine.map((r) => ({ id: r._id, name: r.name, domain: r.domain || null, website: r.website || null,
        known: { linkedin: r.linkedin || null, industry: r.industry || null, location: r.location || null } })),
      sizes: C.SIZES,
      answer: { companies: [{ id: 0, found: true, industry: '', size: '11-50', location: 'City, Country', summary: 'Two or three sentences: what they sell, to whom.', linkedin: 'https://www.linkedin.com/company/…', website: 'https://…', sources: ['https://…'] }] },
    };
  } finally {
    held.release();
  }
}

const URL_RX = /^https?:\/\/[^\s<>"]+\.[^\s<>"]+$/i;
const LINKEDIN_RX = /^https?:\/\/([a-z]{2,3}\.)?linkedin\.com\/company\/[^\s<>"/?#]+\/?$/i;

/** One company of the agent's answer, checked: { data } to save, or { problem }. */
function checkOne(x) {
  if (x.found === false) return { data: { enriched_at: L.sqlNow(), enrich_status: 'Done', enrich_note: 'The agent found nothing reliable about this company.' } };
  const sources = (Array.isArray(x.sources) ? x.sources : []).map((u) => L.clean(u, 300)).filter((u) => URL_RX.test(u));
  if (!sources.length) return { problem: 'no source to back it' };
  const summary = L.clean(x.summary, 600);
  if (summary.length < 20) return { problem: 'no summary' };
  const data = { summary, industry: L.clean(x.industry, 80) || null, location: L.clean(x.location, 120) || null };
  const size = L.clean(x.size, 20);
  if (C.SIZES.includes(size)) data.size = size;
  const li = L.clean(x.linkedin, 200);
  if (LINKEDIN_RX.test(li)) data.linkedin = li;
  const web = L.clean(x.website, 200);
  if (URL_RX.test(web)) data.website = web;
  return { data: Object.assign(data, { enriched_at: L.sqlNow(), enrich_status: 'Done', enrich_note: `From ${sources.slice(0, 3).join(' ')}`.slice(0, 600) }) };
}

/** The companies this run's pick claimed (its output, $STEP_pick); another run's claims are not ours to judge. */
function claimed() {
  const p = L.jsonIn(process.env.STEP_pick);
  if (p && p.skip) return new Set();
  return p && Array.isArray(p.companies) ? new Set(p.companies.map((c) => Number(c.id))) : null;
}

function save({ dry = false } = {}) {
  const mine = claimed();
  const working = new Map(L.all("SELECT * FROM crm_companies WHERE _deleted = 0 AND enrich_status = 'Working'")
    .filter((r) => !mine || mine.has(r._id)).map((r) => [r._id, r]));
  if (!working.size) return { ok: true, saved: 0, skipped: 'Nothing was being enriched' };
  const answer = L.jsonIn(process.env.PRIOR);
  const given = answer && Array.isArray(answer.companies) ? answer.companies : [];
  const ops = [];
  const saved = [];
  const problems = [];
  const answered = new Set();
  for (const x of given) {
    const id = Number(x && x.id);
    const row = working.get(id);
    if (!row || answered.has(id)) continue;
    answered.add(id);
    const r = checkOne(x);
    if (r.problem) { problems.push({ id, problem: r.problem }); continue; }
    // A person's own value wins over the agent's: only empty fields are filled, except the summary.
    for (const k of ['industry', 'location', 'size', 'linkedin', 'website']) if (row[k] && r.data[k]) delete r.data[k];
    ops.push({ op: 'update', table: 'crm_companies', id, when: { enrich_status: 'Working' }, data: r.data });
    saved.push(id);
  }
  // Left out or refused: back to the queue, or Failed after three tries, with the reason.
  for (const [id, row] of working) {
    if (saved.includes(id)) continue;
    const n = Number(row.enrich_attempts || 0) + 1;
    const why = (problems.find((p) => p.id === id) || {}).problem || (answer ? 'the answer left it out' : 'the agent did not answer with JSON');
    ops.push({ op: 'update', table: 'crm_companies', id, when: { enrich_status: 'Working' }, data: n >= TRIES
      ? { enrich_status: 'Failed', enrich_attempts: n, enrich_note: `Not enriched after ${n} tries (${why}). Press Enrich again to retry, or fill it in by hand.` }
      : { enrich_status: 'Waiting', enrich_attempts: n, enrich_note: `Last try: ${why}` } });
  }
  if (dry) return { ok: true, dry: true, wouldSave: saved, wouldRequeue: [...working.keys()].filter((id) => !saved.includes(id)) };
  // One company at a time: a person who edited one meanwhile must not cost the others their answer.
  let written = 0;
  for (const op of ops) { try { L.write([op]); written += 1; } catch { /* changed meanwhile */ } }
  const s = settingsOrNull();
  if (s) {
    try { L.write([{ op: 'update', table: 'crm_settings', id: s._id, data: { enrich_note: `${L.sqlNow()} UTC: ${saved.length} enriched, ${working.size - saved.length} back to the queue` } }]); } catch { /* the note can wait */ }
  }
  return { ok: true, saved: saved.length, requeued: working.size - saved.length, problems, written };
}

if (require.main === module) {
  const argv = process.argv.slice(2);
  let out;
  try {
    out = argv[0] === 'pick' ? pick(argv.includes('--now') ? '--now' : '--auto') : argv[0] === 'save' ? save({ dry: argv.includes('--dry-run') })
      : { ok: false, error: 'node enrich.js pick|save' };
  } catch (e) { out = { ok: false, error: e.message }; process.exitCode = 1; }
  L.done(out);
}

module.exports = { pick, save, checkOne, unstick };
