'use strict';
/**
 * CRM · Import from HubSpot (Composio HUBSPOT_LIST_COMPANIES, _CONTACTS,
 * _DEALS): companies first, then contacts, then deals, 100 at a time.
 *
 * Every row keeps its HubSpot id (legacy_hubspot_id), so importing again
 * updates instead of duplicating; a company already here with the same
 * domain, or a contact with the same email, is matched and takes the id.
 * Associations: a contact's company, a deal's company and first contact.
 * HubSpot's default pipeline stages map onto the CRM's by meaning; an
 * unknown stage lands in the first one.
 *
 * Read only on HubSpot's side. Big accounts take more than one run: where it
 * stopped is kept (hubspot_cursor) and the next run continues — the half-hourly
 * check does that on its own while the import is Partial.
 *   node hubspot.js --start   a person pressed Import (starts over unless one is under way)
 *   node hubspot.js --auto    continue an import that is Partial
 *   --dry-run                 reads the first page of each kind, writes nothing
 */
const L = require('./lib');
const X = require('./composio');

const { C } = L;
const BUDGET_MS = Number(process.env.CRM_HUBSPOT_BUDGET_MS) || 240000;
const PHASES = ['companies', 'contacts', 'deals'];
// HubSpot's default sales pipeline, by meaning.
const HS_STAGE = { appointmentscheduled: 'Meeting', qualifiedtobuy: 'Qualified', presentationscheduled: 'Proposal',
  decisionmakerboughtin: 'Proposal', contractsent: 'Negotiation' };

async function run(mode = '--auto', { dry = false } = {}) {
  const t0 = Date.now();
  const s = L.settings();
  if (mode === '--auto' && s.hubspot_status !== 'Partial') return { ok: true, mode, skipped: 'No import is under way' };
  const held = L.lock('hubspot');
  if (!held) return { ok: true, mode, skipped: 'Another import run is working' };
  let cur = L.jsonOf(s.hubspot_cursor, null);
  if (mode === '--start' && s.hubspot_status !== 'Partial') cur = null;
  if (!cur || !PHASES.includes(cur.phase)) cur = { phase: 'companies', after: null, counts: {} };
  const out = { ok: true, mode, counts: cur.counts || {} };
  const stages = C.stagesOf(s.stages);
  try {
    // At least one page a run, however little time is left: a run that reads nothing never finishes.
    for (let first = true; cur.phase && (first || Date.now() - t0 < BUDGET_MS); first = false) {
      const page = await X.hubspotPage(cur.phase, cur.after);
      const ops = (cur.phase === 'companies' ? companies : cur.phase === 'contacts' ? contacts : deals)(page.rows, stages);
      if (dry) { out[cur.phase] = { rows: page.rows.length, wouldWrite: ops.length }; } else if (ops.length) L.write(ops);
      out.counts[cur.phase] = (out.counts[cur.phase] || 0) + page.rows.length;
      if (page.next && !dry) cur.after = page.next;
      else { cur = { phase: PHASES[PHASES.indexOf(cur.phase) + 1] || null, after: null, counts: out.counts }; }
    }
  } catch (e) {
    if (!dry) save(s, { hubspot_status: 'Failed', hubspot_cursor: JSON.stringify(cur), hubspot_note: `Stopped at ${cur.phase}: ${e.message.slice(0, 200)}. Import again to continue from there.` });
    held.release();
    return { ok: false, mode, error: e.message, counts: out.counts };
  }
  held.release();
  const doneAll = !cur.phase;
  const said = PHASES.map((p) => `${out.counts[p] || 0} ${p}`).join(', ');
  if (!dry) {
    save(s, doneAll
      ? { hubspot_status: 'Done', hubspot_cursor: null, hubspot_at: L.sqlNow(), hubspot_note: `Imported ${said}.` }
      : { hubspot_status: 'Partial', hubspot_cursor: JSON.stringify(Object.assign(cur, { counts: out.counts })), hubspot_note: `So far ${said}; it continues on its own within half an hour.` });
  }
  return Object.assign(out, { finished: doneAll, dry: dry || undefined });
}

function save(s, data) {
  L.write([{ op: 'update', table: 'crm_settings', id: s._id, data }]);
}

const byLegacy = (table, id) => L.one(`SELECT * FROM ${table} WHERE _deleted = 0 AND legacy_hubspot_id = ?`, String(id));
const p = (o, k, n = 200) => L.clean(o[k], n);

function companies(rows) {
  const ops = [];
  const domains = new Set();
  for (const r of rows) {
    const domain = p(r.props, 'domain', 120).toLowerCase().replace(/^https?:\/\//, '').replace(/^www\./, '').replace(/\/.*$/, '');
    const data = { name: p(r.props, 'name', 160) || (domain ? C.nameFromDomain(domain) : `HubSpot company ${r.id}`), legacy_hubspot_id: r.id };
    if (domain && /^[a-z0-9.-]+\.[a-z]{2,}$/.test(domain)) data.domain = domain;
    const extra = { industry: p(r.props, 'industry', 80), size: sizeOf(r.props.numberofemployees), website: p(r.props, 'website', 200),
      linkedin: p(r.props, 'linkedin_company_page', 200), summary: p(r.props, 'description', 600),
      location: [p(r.props, 'city', 60), p(r.props, 'country', 60)].filter(Boolean).join(', ') };
    const have = byLegacy('crm_companies', r.id) || (data.domain ? L.one('SELECT * FROM crm_companies WHERE _deleted = 0 AND lower(domain) = ?', data.domain) : null);
    if (have) {
      // What is here already wins: an import fills the gaps, it does not overwrite.
      for (const [k, v] of Object.entries(extra)) if (v && !have[k]) data[k] = v;
      if (have.domain) delete data.domain;
      ops.push({ op: 'update', table: 'crm_companies', id: have._id, data });
    } else {
      if (data.domain && domains.has(data.domain)) delete data.domain;
      for (const [k, v] of Object.entries(extra)) if (v) data[k] = v;
      ops.push({ op: 'insert', table: 'crm_companies', data: Object.assign(data, { source: 'HubSpot', enrich_attempts: 0,
        enrich_note: 'Imported from HubSpot: press Enrich to have the agent fill it in.' }) });
    }
    if (data.domain) domains.add(data.domain);
  }
  return ops;
}

function sizeOf(n) {
  const v = Number(n);
  if (!Number.isFinite(v) || v <= 0) return '';
  return v <= 10 ? '1-10' : v <= 50 ? '11-50' : v <= 200 ? '51-200' : v <= 500 ? '201-500' : v <= 1000 ? '501-1000' : v <= 5000 ? '1001-5000' : '5000+';
}

function contacts(rows) {
  const ops = [];
  const emails = new Set();
  for (const r of rows) {
    const email = C.normEmail(r.props.email);
    const companyHs = r.assoc.companies[0] || p(r.props, 'associatedcompanyid', 40);
    const company = companyHs ? byLegacy('crm_companies', companyHs) : null;
    const data = { legacy_hubspot_id: r.id };
    const extra = { name: [p(r.props, 'firstname', 60), p(r.props, 'lastname', 60)].filter(Boolean).join(' '), title: p(r.props, 'jobtitle', 120),
      phone: p(r.props, 'phone', 40), company_id: company ? company._id : null };
    const have = byLegacy('crm_contacts', r.id) || (C.isEmail(email) ? L.one('SELECT * FROM crm_contacts WHERE _deleted = 0 AND lower(email) = ?', email) : null);
    if (have) {
      for (const [k, v] of Object.entries(extra)) if (v && !have[k]) data[k] = v;
      if (['Suggested', 'Ignored'].includes(have.status)) data.status = 'Lead';
      ops.push({ op: 'update', table: 'crm_contacts', id: have._id, data });
    } else {
      if (C.isEmail(email) && !emails.has(email)) { data.email = email; emails.add(email); }
      for (const [k, v] of Object.entries(extra)) if (v) data[k] = v;
      const stage = String(r.props.lifecyclestage || '').toLowerCase();
      ops.push({ op: 'insert', table: 'crm_contacts', data: Object.assign(data, { status: stage === 'customer' ? 'Customer' : 'Lead', source: 'HubSpot' }) });
    }
  }
  return ops;
}

function deals(rows, stages) {
  const ops = [];
  const open = stages.filter((x) => !x.outcome);
  const won = stages.find((x) => x.outcome === 'won');
  const lost = stages.find((x) => x.outcome === 'lost');
  for (const r of rows) {
    const hs = String(r.props.dealstage || '').toLowerCase();
    const isWon = hs === 'closedwon' || String(r.props.hs_is_closed_won) === 'true';
    const isLost = !isWon && (hs === 'closedlost' || String(r.props.hs_is_closed) === 'true');
    const named = HS_STAGE[hs] && open.find((x) => x.name === HS_STAGE[hs]);
    const stage = isWon ? won.name : isLost ? lost.name : (named || open[0]).name;
    const company = r.assoc.companies[0] ? byLegacy('crm_companies', r.assoc.companies[0]) : null;
    const contact = r.assoc.contacts[0] ? byLegacy('crm_contacts', r.assoc.contacts[0]) : null;
    const amount = Number(r.props.amount);
    const close = p(r.props, 'closedate', 30).slice(0, 10);
    const data = {
      title: p(r.props, 'dealname', 160) || `HubSpot deal ${r.id}`, stage, status: isWon ? 'Won' : isLost ? 'Lost' : 'Open',
      amount: Number.isFinite(amount) ? amount : null, currency: p(r.props, 'deal_currency_code', 3).toUpperCase() || null,
      expected_close: /^\d{4}-\d\d-\d\d$/.test(close) ? close : null, company_id: company ? company._id : null, contact_id: contact ? contact._id : null,
      lost_reason: isLost ? (p(r.props, 'closed_lost_reason', 300) || null) : null, legacy_hubspot_id: r.id,
    };
    const have = byLegacy('crm_deals', r.id);
    if (have) {
      if (have.stage !== data.stage) data.stage_changed_at = L.sqlNow();
      ops.push({ op: 'update', table: 'crm_deals', id: have._id, data });
    } else {
      ops.push({ op: 'insert', table: 'crm_deals', data: Object.assign(data, { stage_changed_at: L.sqlNow(), source: 'HubSpot',
        closed_at: isWon || isLost ? L.sqlNow() : null }) });
    }
  }
  return ops;
}

if (require.main === module) {
  const argv = process.argv.slice(2);
  const mode = argv.includes('--start') ? '--start' : '--auto';
  run(mode, { dry: argv.includes('--dry-run') })
    .then((r) => L.done(r))
    .catch((e) => { L.done({ ok: false, error: e.message }); process.exitCode = 1; });
}

module.exports = { run, sizeOf, HS_STAGE };
