'use strict';
/**
 * CRM · Suggest next steps: the two script steps around the agent's turn.
 *
 *   node suggest.js pick [--now]   the open deals that need a next step (none
 *                                  set, overdue, or stuck), each with its
 *                                  people, company and latest activity
 *   node suggest.js save           the agent's answer ($PRIOR), checked: per
 *                                  deal a Suggested task and, when it wrote
 *                                  one, an email draft waiting for review
 *
 * Nothing is sent and nothing is decided: a person accepts or dismisses the
 * task and approves, edits or drops the draft. The agent never picks the
 * recipient (the deal's contact is), and never writes to the database.
 * Runs once a day at the hour in Settings, and when someone presses Suggest now.
 *   --dry-run (save)  says what it would write, writes nothing
 */
const L = require('./lib');

const { C } = L;
const PLACEHOLDER = /\[[^\]\n]{2,40}\]|\{\{|\}\}|<[A-Z][A-Z _]{2,30}>|lorem ipsum/i;

/** Open deals that need a next step, the stuck and overdue first, then the biggest. */
function needing(s, cap) {
  const days = Math.max(1, Number(s.stuck_days) || 14);
  return L.all(`SELECT d.*, CASE WHEN datetime(COALESCE(d.stage_changed_at, d._created_at)) <= datetime('now', '-${days} days')
        AND NOT EXISTS (SELECT 1 FROM crm_activities a WHERE a._deleted = 0 AND a.type <> 'stage' AND datetime(a.at) > datetime('now', '-${days} days')
          AND datetime(a.at) <= datetime('now')
          AND (a.deal_id = d._id OR (d.contact_id IS NOT NULL AND a.contact_id = d.contact_id) OR (d.company_id IS NOT NULL AND a.company_id = d.company_id)))
      THEN 1 ELSE 0 END AS stuck,
      CASE WHEN COALESCE(d.next_step_due, '') <> '' AND date(d.next_step_due) < date('now') THEN 1 ELSE 0 END AS overdue
    FROM crm_deals d
    WHERE d._deleted = 0 AND d.status = 'Open'
      AND NOT EXISTS (SELECT 1 FROM crm_tasks t WHERE t._deleted = 0 AND t.deal_id = d._id AND t.status IN ('Suggested', 'Open'))
      AND NOT EXISTS (SELECT 1 FROM crm_drafts r WHERE r._deleted = 0 AND r.deal_id = d._id AND r.status IN ('Review', 'Approved', 'Sending'))
    ORDER BY stuck DESC, overdue DESC, (COALESCE(d.next_step, '') = '') DESC, COALESCE(d.amount, 0) DESC, d._id
    LIMIT ${cap * 3}`).filter((d) => d.stuck || d.overdue || !String(d.next_step || '').trim()).slice(0, cap);
}

function pick(mode = '--auto', now = new Date()) {
  const s = L.settings();
  if (mode === '--auto' && Number(s.paused) === 1) return { skip: true, why: 'The CRM is paused in Settings' };
  const due = L.toDate(s.next_suggest_at);
  if (mode === '--auto' && due && due > now) return { skip: true, why: `Not due until ${s.next_suggest_at} UTC` };
  const held = L.lock('suggest');
  if (!held) return { skip: true, why: 'Another run is suggesting next steps' };
  try {
    // The next daily run is decided first, so the schedule does not fire again while the agent works.
    L.write([{ op: 'update', table: 'crm_settings', id: s._id, data: {
      last_suggest_at: L.sqlNow(now), next_suggest_at: L.sqlNow(C.nextAt(s.suggest_hour, s.timezone || 'UTC', now)) } }]);
    const cap = Math.max(1, Math.min(20, Number(s.suggest_per_run) || 8));
    const deals = needing(s, cap);
    if (!deals.length) return { skip: true, why: 'Every open deal has a next step' };
    return {
      today: now.toISOString().slice(0, 10),
      stages: C.openStages(s.stages).map((x) => x.name),
      deals: deals.map((d) => describe(d, now)),
      answer: { suggestions: [{ deal_id: 0, task: { title: 'Short imperative: what to do', due_in_days: 2, why: 'One sentence: what you saw that makes this the next step' },
        email: { subject: 'Subject', body: 'Plain text, ready to send, no placeholders' } }] },
    };
  } finally {
    held.release();
  }
}

function describe(d, now) {
  const contact = d.contact_id ? L.one('SELECT _id, name, email, title, status FROM crm_contacts WHERE _id = ? AND _deleted = 0', d.contact_id) : null;
  const company = d.company_id ? L.one('SELECT name, domain, industry, size, summary FROM crm_companies WHERE _id = ? AND _deleted = 0', d.company_id) : null;
  const acts = L.all(`SELECT type, at, subject, summary FROM crm_activities WHERE _deleted = 0 AND datetime(at) <= datetime('now')
    AND (deal_id = ? OR (? IS NOT NULL AND contact_id = ?) OR (? IS NOT NULL AND company_id = ?)) ORDER BY datetime(at) DESC LIMIT 8`,
  d._id, d.contact_id, d.contact_id, d.company_id, d.company_id);
  const since = L.toDate(d.stage_changed_at || d._created_at);
  return {
    deal_id: d._id, title: d.title, stage: d.stage, amount: d.amount, currency: d.currency, expected_close: d.expected_close || null,
    days_in_stage: since ? Math.floor((now - since) / 86400000) : null,
    why_picked: d.stuck ? 'stuck: no activity for a while' : d.overdue ? `its next step was due ${d.next_step_due}` : 'no next step',
    next_step: d.next_step || null,
    contact: contact ? { name: contact.name, email: contact.email, title: contact.title } : null,
    can_email: !!(contact && C.isEmail(contact.email)),
    company: company || null,
    activity: acts.map((a) => ({ type: a.type, at: String(a.at).slice(0, 16), subject: L.clean(a.subject, 120), summary: L.clean(a.summary, 240) })),
  };
}

/** The deals this run's pick handed the agent ($STEP_pick). */
function picked() {
  const p = L.jsonIn(process.env.STEP_pick);
  if (!p || p.skip || !Array.isArray(p.deals)) return new Set();
  return new Set(p.deals.map((d) => Number(d.deal_id)));
}

/** One suggestion, checked: { task, email } to save, email null when it is missing or not ready to send. */
function checkOne(x, deal, contact, s, now = new Date()) {
  const t = x && x.task;
  const title = L.clean(t && t.title, 140);
  const why = L.clean(t && t.why, 400);
  if (title.length < 3 || !why) return { problem: 'the task has no title or no reason' };
  const n = Math.round(Number(t.due_in_days));
  const days = Number.isFinite(n) ? Math.max(0, Math.min(30, n)) : 2;
  const task = { title, why, due: new Date(now.getTime() + days * 86400000).toISOString().slice(0, 10) };
  let email = null;
  let note = null;
  const e = x.email;
  if (e && typeof e === 'object') {
    const subject = L.clean(e.subject, 160);
    let body = String(e.body === undefined || e.body === null ? '' : e.body).replace(/\r\n/g, '\n').replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/g, '').trim().slice(0, 4000);
    if (!contact || !C.isEmail(contact.email)) note = 'no email: the deal has no contact with an address';
    else if (subject.length < 3 || body.length < 20) note = 'the email had no subject or body';
    else if (PLACEHOLDER.test(subject) || PLACEHOLDER.test(body)) note = 'the email still had placeholders to fill';
    else {
      const sig = String(s.signature || '').trim();
      if (sig && !body.includes(sig)) body = `${body}\n\n${sig}`;
      email = { to_email: C.normEmail(contact.email), subject, body };
    }
  }
  return { task, email, note };
}

function save({ dry = false } = {}) {
  const s = L.settings();
  const mine = picked();
  if (!mine.size) return { ok: true, saved: 0, skipped: 'Nothing was asked of the agent' };
  const answer = L.jsonIn(process.env.PRIOR);
  const list = answer && Array.isArray(answer.suggestions) ? answer.suggestions : [];
  const done = new Set();
  const out = { ok: true, saved: 0, drafts: 0, refused: [] };
  for (const x of list) {
    const id = Number(x && x.deal_id);
    if (!mine.has(id) || done.has(id)) continue;
    done.add(id);
    const deal = L.one("SELECT * FROM crm_deals WHERE _id = ? AND _deleted = 0 AND status = 'Open'", id);
    if (!deal) { out.refused.push({ deal: id, why: 'it is no longer open' }); continue; }
    if (L.one("SELECT 1 AS x FROM crm_tasks WHERE _deleted = 0 AND deal_id = ? AND status IN ('Suggested', 'Open')", id)) {
      out.refused.push({ deal: id, why: 'it got a next step meanwhile' });
      continue;
    }
    const contact = deal.contact_id ? L.one('SELECT * FROM crm_contacts WHERE _id = ? AND _deleted = 0', deal.contact_id) : null;
    const c = checkOne(x, deal, contact, s);
    if (c.problem) { out.refused.push({ deal: id, why: c.problem }); continue; }
    if (c.note) out.refused.push({ deal: id, why: c.note, taskKept: true });
    const ops = [];
    if (c.email) {
      ops.push({ op: 'insert', table: 'crm_drafts', as: 'd', data: Object.assign(c.email, {
        contact_id: contact._id, deal_id: id, status: 'Review', source: 'Agent' }) });
    }
    ops.push({ op: 'insert', table: 'crm_tasks', data: Object.assign(c.task, {
      deal_id: id, contact_id: contact ? contact._id : null, owner: deal.owner || null, status: 'Suggested', source: 'Agent',
      draft_id: c.email ? '$d._id' : null }) });
    if (dry) { out.saved += 1; out.drafts += c.email ? 1 : 0; continue; }
    try {
      L.write(ops);
      out.saved += 1;
      out.drafts += c.email ? 1 : 0;
    } catch (e) {
      out.refused.push({ deal: id, why: `it could not be saved: ${e.message.slice(0, 120)}` });
    }
  }
  for (const id of mine) if (!done.has(id)) out.refused.push({ deal: id, why: 'the answer left it out' });
  if (!answer) out.refused.unshift({ why: 'the agent did not answer with JSON' });
  if (dry) return Object.assign(out, { dry: true });
  try {
    L.write([{ op: 'update', table: 'crm_settings', id: s._id, data: {
      suggest_note: `${L.sqlNow()} UTC: ${out.saved} next steps suggested, ${out.drafts} drafts to review${out.refused.length ? `, ${out.refused.length} left out` : ''}` } }]);
  } catch { /* the note can wait */ }
  return out;
}

if (require.main === module) {
  const argv = process.argv.slice(2);
  let out;
  try {
    out = argv[0] === 'pick' ? pick(argv.includes('--now') ? '--now' : '--auto') : argv[0] === 'save' ? save({ dry: argv.includes('--dry-run') })
      : { ok: false, error: 'node suggest.js pick|save' };
  } catch (e) { out = { ok: false, error: e.message }; process.exitCode = 1; }
  L.done(out);
}

module.exports = { pick, save, checkOne, needing };
