'use strict';
/**
 * CRM · Send approved emails, from the Gmail account connected to the
 * workspace (Composio GMAIL_SEND_EMAIL), in plain text.
 *
 * Only what a person approved goes out: there is no automatic mode. Each
 * draft is CLAIMED before Gmail is called (Approved -> Sending, atomic), so a
 * draft dropped meanwhile never leaves and none leaves twice. One that stayed
 * Sending (a run that died, or Gmail did not answer) is marked Failed and
 * says it may have gone out: it is never retried blind. A person retries,
 * edits or drops it from its panel.
 *
 * Holds while the CRM is paused, and stops at the daily cap in Settings.
 * Approving starts it; a half-hourly run picks up what waited for a pause.
 *   node send.js [--auto|--now] [--dry-run]
 */
const L = require('./lib');
const X = require('./composio');

const { C } = L;
const STALE_MIN = 15;

async function run(mode = '--auto', { dry = false } = {}) {
  const held = L.lock('send');
  if (!held) return { ok: true, mode, skipped: 'Another run is sending' };
  try {
    const s = L.settings();
    const out = { ok: true, mode, sent: [], failed: [] };
    const stale = L.all(`SELECT _id FROM crm_drafts WHERE _deleted = 0 AND status = 'Sending'
      AND datetime(lock_at) <= datetime('now', '-${STALE_MIN} minutes')`);
    if (stale.length && !dry) {
      L.write(stale.map((r) => ({ op: 'update', table: 'crm_drafts', id: r._id, when: { status: 'Sending' }, data: {
        status: 'Failed', error: 'The send did not finish, so it may or may not have gone out. Look in Gmail\'s Sent folder before retrying.' } })));
    }
    out.unfinished = stale.length || undefined;
    if (Number(s.paused) === 1) return Object.assign(out, { skipped: 'The CRM is paused in Settings: approved emails wait' });
    const cap = Math.max(1, Number(s.daily_send_cap) || 40);
    const today = L.one(`SELECT COUNT(*) AS n FROM crm_drafts WHERE _deleted = 0 AND status IN ('Sending', 'Sent')
      AND date(COALESCE(sent_at, lock_at)) = date('now')`).n;
    const room = cap - today;
    const queue = L.all("SELECT * FROM crm_drafts WHERE _deleted = 0 AND status = 'Approved' ORDER BY datetime(approved_at), _id LIMIT 50");
    if (!queue.length) return Object.assign(out, { skipped: 'Nothing is approved' });
    if (room <= 0) {
      note(s, `The daily cap of ${cap} is reached: ${queue.length} approved emails wait for tomorrow.`, dry);
      return Object.assign(out, { skipped: `The daily cap of ${cap} is reached` });
    }
    if (dry) return Object.assign(out, { dry: true, wouldSend: queue.slice(0, room).map((d) => ({ id: d._id, to: d.to_email, subject: d.subject })) });

    for (const d of queue.slice(0, room)) {
      const to = C.normEmail(d.to_email);
      if (!C.isEmail(to) || !String(d.subject || '').trim() || !String(d.body || '').trim()) {
        fail(d, 'It has no valid address, subject or body: nothing went out. Edit it and approve it again.', out);
        continue;
      }
      try {
        L.write([{ op: 'update', table: 'crm_drafts', id: d._id, when: { status: 'Approved' }, data: { status: 'Sending', lock_at: L.sqlNow(), error: null } }]);
      } catch { continue; } // dropped or taken meanwhile
      let res;
      try {
        res = await X.gmailSend({ to, subject: d.subject, body: d.body, account: s.gmail_account || undefined });
      } catch (e) {
        fail(d, e.timeout
          ? `Gmail did not answer in time, so it may or may not have gone out. Look in Gmail's Sent folder before retrying. (${e.message})`
          : `Gmail did not take it: nothing went out. ${readable(e.message)}`, out, 'Sending');
        continue;
      }
      sent(d, to, res, out);
    }
    return out;
  } finally {
    held.release();
  }
}

/** What Gmail said, in words a person can act on, with the raw text after it. */
function readable(why) {
  const t = String(why || '');
  if (/not connected|no active connection|connected account|auth/i.test(t)) return `Gmail is not connected for this workspace: connect it in the portal (Integrations), then retry. (${t.slice(0, 200)})`;
  if (/invalid to|recipient|address/i.test(t)) return `The address was refused: check it, edit and approve again. (${t.slice(0, 200)})`;
  return `(${t.slice(0, 240)})`;
}

function fail(d, error, out, from = 'Approved') {
  try { L.write([{ op: 'update', table: 'crm_drafts', id: d._id, when: { status: from }, data: { status: 'Failed', error: error.slice(0, 500) } }]); } catch { /* changed meanwhile */ }
  out.failed.push({ id: d._id, to: d.to_email, error: error.slice(0, 200) });
}

/** Sent: the draft, an email-out activity on the contact (the sync will not add it twice), a Lead becomes Contacted, its task is done. */
function sent(d, to, res, out) {
  const at = L.sqlNow();
  const ops = [{ op: 'update', table: 'crm_drafts', id: d._id, data: { status: 'Sent', sent_at: at, gmail_message_id: res.id || null, error: null } }];
  const contact = d.contact_id ? L.one('SELECT * FROM crm_contacts WHERE _id = ? AND _deleted = 0', d.contact_id) : null;
  const ext = res.id ? `gmail:${res.id}:${to}` : null;
  if (!ext || !L.one('SELECT 1 AS x FROM crm_activities WHERE external_id = ? AND _deleted = 0', ext)) {
    ops.push({ op: 'insert', table: 'crm_activities', data: {
      type: 'email_out', contact_id: d.contact_id || null, company_id: contact ? contact.company_id : null, deal_id: d.deal_id || null,
      at, subject: L.clean(d.subject, 200), summary: L.clean(d.body, 300), external_id: ext, source: 'crm', author: d.approved_by || null } });
  }
  if (contact) {
    const data = { last_activity_at: at };
    if (contact.status === 'Lead') data.status = 'Contacted';
    ops.push({ op: 'update', table: 'crm_contacts', id: contact._id, data });
  }
  // Its task was this email: done once it left (a suggestion whose email was approved was accepted by that).
  for (const t of L.all("SELECT _id, status FROM crm_tasks WHERE _deleted = 0 AND draft_id = ? AND status IN ('Suggested', 'Open')", d._id)) {
    ops.push({ op: 'update', table: 'crm_tasks', id: t._id, when: { status: t.status }, data: { status: 'Done', done_at: at } });
  }
  try {
    L.write(ops);
  } catch (e) {
    // It went out: say so on the draft even if the rest could not be written.
    L.write([{ op: 'update', table: 'crm_drafts', id: d._id, data: { status: 'Sent', sent_at: at, gmail_message_id: res.id || null } }]);
  }
  out.sent.push({ id: d._id, to, gmail: res.id || null });
}

function note(s, text, dry) {
  if (dry) return;
  try { L.write([{ op: 'update', table: 'crm_settings', id: s._id, data: { send_note: text.slice(0, 300) } }]); } catch { /* the note can wait */ }
}

if (require.main === module) {
  const argv = process.argv.slice(2);
  const mode = argv.includes('--now') ? '--now' : '--auto';
  run(mode, { dry: argv.includes('--dry-run') })
    .then((r) => L.done(r))
    .catch((e) => { L.done({ ok: false, error: e.message }); process.exitCode = 1; });
}

module.exports = { run, readable };
