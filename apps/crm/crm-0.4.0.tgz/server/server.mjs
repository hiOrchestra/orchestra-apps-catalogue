// .stack/node_modules/@hono/node-server/dist/index.mjs
import { createServer as createServerHTTP } from "http";
import { Http2ServerRequest as Http2ServerRequest2 } from "http2";
import { Http2ServerRequest } from "http2";
import { Readable } from "stream";
import crypto from "crypto";
var RequestError = class extends Error {
  constructor(message, options) {
    super(message, options);
    this.name = "RequestError";
  }
};
var toRequestError = (e) => {
  if (e instanceof RequestError) {
    return e;
  }
  return new RequestError(e.message, { cause: e });
};
var GlobalRequest = global.Request;
var Request2 = class extends GlobalRequest {
  constructor(input, options) {
    if (typeof input === "object" && getRequestCache in input) {
      input = input[getRequestCache]();
    }
    if (typeof options?.body?.getReader !== "undefined") {
      ;
      options.duplex ??= "half";
    }
    super(input, options);
  }
};
var wrapBodyStream = Symbol("wrapBodyStream");
var newRequestFromIncoming = (method, url, incoming, abortController) => {
  const headerRecord = [];
  const rawHeaders = incoming.rawHeaders;
  for (let i = 0; i < rawHeaders.length; i += 2) {
    const { [i]: key, [i + 1]: value } = rawHeaders;
    if (key.charCodeAt(0) !== /*:*/
    58) {
      headerRecord.push([key, value]);
    }
  }
  const init = {
    method,
    headers: headerRecord,
    signal: abortController.signal
  };
  if (method === "TRACE") {
    init.method = "GET";
    const req = new Request2(url, init);
    Object.defineProperty(req, "method", {
      get() {
        return "TRACE";
      }
    });
    return req;
  }
  if (!(method === "GET" || method === "HEAD")) {
    if ("rawBody" in incoming && incoming.rawBody instanceof Buffer) {
      init.body = new ReadableStream({
        start(controller) {
          controller.enqueue(incoming.rawBody);
          controller.close();
        }
      });
    } else if (incoming[wrapBodyStream]) {
      let reader;
      init.body = new ReadableStream({
        async pull(controller) {
          try {
            reader ||= Readable.toWeb(incoming).getReader();
            const { done: done2, value } = await reader.read();
            if (done2) {
              controller.close();
            } else {
              controller.enqueue(value);
            }
          } catch (error) {
            controller.error(error);
          }
        }
      });
    } else {
      init.body = Readable.toWeb(incoming);
    }
  }
  return new Request2(url, init);
};
var getRequestCache = Symbol("getRequestCache");
var requestCache = Symbol("requestCache");
var incomingKey = Symbol("incomingKey");
var urlKey = Symbol("urlKey");
var abortControllerKey = Symbol("abortControllerKey");
var getAbortController = Symbol("getAbortController");
var requestPrototype = {
  get method() {
    return this[incomingKey].method || "GET";
  },
  get url() {
    return this[urlKey];
  },
  [getAbortController]() {
    this[getRequestCache]();
    return this[abortControllerKey];
  },
  [getRequestCache]() {
    this[abortControllerKey] ||= new AbortController();
    return this[requestCache] ||= newRequestFromIncoming(
      this.method,
      this[urlKey],
      this[incomingKey],
      this[abortControllerKey]
    );
  }
};
[
  "body",
  "bodyUsed",
  "cache",
  "credentials",
  "destination",
  "headers",
  "integrity",
  "mode",
  "redirect",
  "referrer",
  "referrerPolicy",
  "signal",
  "keepalive"
].forEach((k) => {
  Object.defineProperty(requestPrototype, k, {
    get() {
      return this[getRequestCache]()[k];
    }
  });
});
["arrayBuffer", "blob", "clone", "formData", "json", "text"].forEach((k) => {
  Object.defineProperty(requestPrototype, k, {
    value: function() {
      return this[getRequestCache]()[k]();
    }
  });
});
Object.setPrototypeOf(requestPrototype, Request2.prototype);
var newRequest = (incoming, defaultHostname) => {
  const req = Object.create(requestPrototype);
  req[incomingKey] = incoming;
  const incomingUrl = incoming.url || "";
  if (incomingUrl[0] !== "/" && // short-circuit for performance. most requests are relative URL.
  (incomingUrl.startsWith("http://") || incomingUrl.startsWith("https://"))) {
    if (incoming instanceof Http2ServerRequest) {
      throw new RequestError("Absolute URL for :path is not allowed in HTTP/2");
    }
    try {
      const url2 = new URL(incomingUrl);
      req[urlKey] = url2.href;
    } catch (e) {
      throw new RequestError("Invalid absolute URL", { cause: e });
    }
    return req;
  }
  const host = (incoming instanceof Http2ServerRequest ? incoming.authority : incoming.headers.host) || defaultHostname;
  if (!host) {
    throw new RequestError("Missing host header");
  }
  let scheme;
  if (incoming instanceof Http2ServerRequest) {
    scheme = incoming.scheme;
    if (!(scheme === "http" || scheme === "https")) {
      throw new RequestError("Unsupported scheme");
    }
  } else {
    scheme = incoming.socket && incoming.socket.encrypted ? "https" : "http";
  }
  const url = new URL(`${scheme}://${host}${incomingUrl}`);
  if (url.hostname.length !== host.length && url.hostname !== host.replace(/:\d+$/, "")) {
    throw new RequestError("Invalid host header");
  }
  req[urlKey] = url.href;
  return req;
};
var responseCache = Symbol("responseCache");
var getResponseCache = Symbol("getResponseCache");
var cacheKey = Symbol("cache");
var GlobalResponse = global.Response;
var Response2 = class _Response {
  #body;
  #init;
  [getResponseCache]() {
    delete this[cacheKey];
    return this[responseCache] ||= new GlobalResponse(this.#body, this.#init);
  }
  constructor(body, init) {
    let headers;
    this.#body = body;
    if (init instanceof _Response) {
      const cachedGlobalResponse = init[responseCache];
      if (cachedGlobalResponse) {
        this.#init = cachedGlobalResponse;
        this[getResponseCache]();
        return;
      } else {
        this.#init = init.#init;
        headers = new Headers(init.#init.headers);
      }
    } else {
      this.#init = init;
    }
    if (typeof body === "string" || typeof body?.getReader !== "undefined" || body instanceof Blob || body instanceof Uint8Array) {
      headers ||= init?.headers || { "content-type": "text/plain; charset=UTF-8" };
      this[cacheKey] = [init?.status || 200, body, headers];
    }
  }
  get headers() {
    const cache = this[cacheKey];
    if (cache) {
      if (!(cache[2] instanceof Headers)) {
        cache[2] = new Headers(cache[2]);
      }
      return cache[2];
    }
    return this[getResponseCache]().headers;
  }
  get status() {
    return this[cacheKey]?.[0] ?? this[getResponseCache]().status;
  }
  get ok() {
    const status = this.status;
    return status >= 200 && status < 300;
  }
};
["body", "bodyUsed", "redirected", "statusText", "trailers", "type", "url"].forEach((k) => {
  Object.defineProperty(Response2.prototype, k, {
    get() {
      return this[getResponseCache]()[k];
    }
  });
});
["arrayBuffer", "blob", "clone", "formData", "json", "text"].forEach((k) => {
  Object.defineProperty(Response2.prototype, k, {
    value: function() {
      return this[getResponseCache]()[k]();
    }
  });
});
Object.setPrototypeOf(Response2, GlobalResponse);
Object.setPrototypeOf(Response2.prototype, GlobalResponse.prototype);
async function readWithoutBlocking(readPromise) {
  return Promise.race([readPromise, Promise.resolve().then(() => Promise.resolve(void 0))]);
}
function writeFromReadableStreamDefaultReader(reader, writable, currentReadPromise) {
  const handleError = () => {
  };
  writable.on("error", handleError);
  (currentReadPromise ?? reader.read()).then(flow, handleStreamError);
  return reader.closed.finally(() => {
    writable.off("error", handleError);
  });
  function handleStreamError(error) {
    if (error) {
      writable.destroy(error);
    }
  }
  function onDrain() {
    reader.read().then(flow, handleStreamError);
  }
  function flow({ done: done2, value }) {
    try {
      if (done2) {
        writable.end();
      } else if (!writable.write(value)) {
        writable.once("drain", onDrain);
      } else {
        return reader.read().then(flow, handleStreamError);
      }
    } catch (e) {
      handleStreamError(e);
    }
  }
}
function writeFromReadableStream(stream, writable) {
  if (stream.locked) {
    throw new TypeError("ReadableStream is locked.");
  } else if (writable.destroyed) {
    return;
  }
  return writeFromReadableStreamDefaultReader(stream.getReader(), writable);
}
var buildOutgoingHttpHeaders = (headers) => {
  const res = {};
  if (!(headers instanceof Headers)) {
    headers = new Headers(headers ?? void 0);
  }
  const cookies = [];
  for (const [k, v] of headers) {
    if (k === "set-cookie") {
      cookies.push(v);
    } else {
      res[k] = v;
    }
  }
  if (cookies.length > 0) {
    res["set-cookie"] = cookies;
  }
  res["content-type"] ??= "text/plain; charset=UTF-8";
  return res;
};
var X_ALREADY_SENT = "x-hono-already-sent";
var webFetch = global.fetch;
if (typeof global.crypto === "undefined") {
  global.crypto = crypto;
}
global.fetch = (info, init) => {
  init = {
    // Disable compression handling so people can return the result of a fetch
    // directly in the loader without messing with the Content-Encoding header.
    compress: false,
    ...init
  };
  return webFetch(info, init);
};
var outgoingEnded = Symbol("outgoingEnded");
var handleRequestError = () => new Response(null, {
  status: 400
});
var handleFetchError = (e) => new Response(null, {
  status: e instanceof Error && (e.name === "TimeoutError" || e.constructor.name === "TimeoutError") ? 504 : 500
});
var handleResponseError = (e, outgoing) => {
  const err = e instanceof Error ? e : new Error("unknown error", { cause: e });
  if (err.code === "ERR_STREAM_PREMATURE_CLOSE") {
    console.info("The user aborted a request.");
  } else {
    console.error(e);
    if (!outgoing.headersSent) {
      outgoing.writeHead(500, { "Content-Type": "text/plain" });
    }
    outgoing.end(`Error: ${err.message}`);
    outgoing.destroy(err);
  }
};
var flushHeaders = (outgoing) => {
  if ("flushHeaders" in outgoing && outgoing.writable) {
    outgoing.flushHeaders();
  }
};
var responseViaCache = async (res, outgoing) => {
  let [status, body, header] = res[cacheKey];
  if (header instanceof Headers) {
    header = buildOutgoingHttpHeaders(header);
  }
  if (typeof body === "string") {
    header["Content-Length"] = Buffer.byteLength(body);
  } else if (body instanceof Uint8Array) {
    header["Content-Length"] = body.byteLength;
  } else if (body instanceof Blob) {
    header["Content-Length"] = body.size;
  }
  outgoing.writeHead(status, header);
  if (typeof body === "string" || body instanceof Uint8Array) {
    outgoing.end(body);
  } else if (body instanceof Blob) {
    outgoing.end(new Uint8Array(await body.arrayBuffer()));
  } else {
    flushHeaders(outgoing);
    await writeFromReadableStream(body, outgoing)?.catch(
      (e) => handleResponseError(e, outgoing)
    );
  }
  ;
  outgoing[outgoingEnded]?.();
};
var responseViaResponseObject = async (res, outgoing, options = {}) => {
  if (res instanceof Promise) {
    if (options.errorHandler) {
      try {
        res = await res;
      } catch (err) {
        const errRes = await options.errorHandler(err);
        if (!errRes) {
          return;
        }
        res = errRes;
      }
    } else {
      res = await res.catch(handleFetchError);
    }
  }
  if (cacheKey in res) {
    return responseViaCache(res, outgoing);
  }
  const resHeaderRecord = buildOutgoingHttpHeaders(res.headers);
  if (res.body) {
    const reader = res.body.getReader();
    const values = [];
    let done2 = false;
    let currentReadPromise = void 0;
    if (resHeaderRecord["transfer-encoding"] !== "chunked") {
      let maxReadCount = 2;
      for (let i = 0; i < maxReadCount; i++) {
        currentReadPromise ||= reader.read();
        const chunk = await readWithoutBlocking(currentReadPromise).catch((e) => {
          console.error(e);
          done2 = true;
        });
        if (!chunk) {
          if (i === 1) {
            await new Promise((resolve) => setTimeout(resolve));
            maxReadCount = 3;
            continue;
          }
          break;
        }
        currentReadPromise = void 0;
        if (chunk.value) {
          values.push(chunk.value);
        }
        if (chunk.done) {
          done2 = true;
          break;
        }
      }
      if (done2 && !("content-length" in resHeaderRecord)) {
        resHeaderRecord["content-length"] = values.reduce((acc, value) => acc + value.length, 0);
      }
    }
    outgoing.writeHead(res.status, resHeaderRecord);
    values.forEach((value) => {
      ;
      outgoing.write(value);
    });
    if (done2) {
      outgoing.end();
    } else {
      if (values.length === 0) {
        flushHeaders(outgoing);
      }
      await writeFromReadableStreamDefaultReader(reader, outgoing, currentReadPromise);
    }
  } else if (resHeaderRecord[X_ALREADY_SENT]) {
  } else {
    outgoing.writeHead(res.status, resHeaderRecord);
    outgoing.end();
  }
  ;
  outgoing[outgoingEnded]?.();
};
var getRequestListener = (fetchCallback, options = {}) => {
  const autoCleanupIncoming = options.autoCleanupIncoming ?? true;
  if (options.overrideGlobalObjects !== false && global.Request !== Request2) {
    Object.defineProperty(global, "Request", {
      value: Request2
    });
    Object.defineProperty(global, "Response", {
      value: Response2
    });
  }
  return async (incoming, outgoing) => {
    let res, req;
    try {
      req = newRequest(incoming, options.hostname);
      let incomingEnded = !autoCleanupIncoming || incoming.method === "GET" || incoming.method === "HEAD";
      if (!incomingEnded) {
        ;
        incoming[wrapBodyStream] = true;
        incoming.on("end", () => {
          incomingEnded = true;
        });
        if (incoming instanceof Http2ServerRequest2) {
          ;
          outgoing[outgoingEnded] = () => {
            if (!incomingEnded) {
              setTimeout(() => {
                if (!incomingEnded) {
                  setTimeout(() => {
                    incoming.destroy();
                    outgoing.destroy();
                  });
                }
              });
            }
          };
        }
      }
      outgoing.on("close", () => {
        const abortController = req[abortControllerKey];
        if (abortController) {
          if (incoming.errored) {
            req[abortControllerKey].abort(incoming.errored.toString());
          } else if (!outgoing.writableFinished) {
            req[abortControllerKey].abort("Client connection prematurely closed.");
          }
        }
        if (!incomingEnded) {
          setTimeout(() => {
            if (!incomingEnded) {
              setTimeout(() => {
                incoming.destroy();
              });
            }
          });
        }
      });
      res = fetchCallback(req, { incoming, outgoing });
      if (cacheKey in res) {
        return responseViaCache(res, outgoing);
      }
    } catch (e) {
      if (!res) {
        if (options.errorHandler) {
          res = await options.errorHandler(req ? e : toRequestError(e));
          if (!res) {
            return;
          }
        } else if (!req) {
          res = handleRequestError();
        } else {
          res = handleFetchError(e);
        }
      } else {
        return handleResponseError(e, outgoing);
      }
    }
    try {
      return await responseViaResponseObject(res, outgoing, options);
    } catch (e) {
      return handleResponseError(e, outgoing);
    }
  };
};
var createAdaptorServer = (options) => {
  const fetchCallback = options.fetch;
  const requestListener = getRequestListener(fetchCallback, {
    hostname: options.hostname,
    overrideGlobalObjects: options.overrideGlobalObjects,
    autoCleanupIncoming: options.autoCleanupIncoming
  });
  const createServer = options.createServer || createServerHTTP;
  const server = createServer(options.serverOptions || {}, requestListener);
  return server;
};
var serve = (options, listeningListener) => {
  const server = createAdaptorServer(options);
  server.listen(options?.port ?? 3e3, options.hostname, () => {
    const serverInfo = server.address();
    listeningListener && listeningListener(serverInfo);
  });
  return server;
};

// .stack/node_modules/hono/dist/compose.js
var compose = (middleware, onError, onNotFound) => {
  return (context, next) => {
    let index = -1;
    return dispatch(0);
    async function dispatch(i) {
      if (i <= index) {
        throw new Error("next() called multiple times");
      }
      index = i;
      let res;
      let isError = false;
      let handler;
      if (middleware[i]) {
        handler = middleware[i][0][0];
        context.req.routeIndex = i;
      } else {
        handler = i === middleware.length && next || void 0;
      }
      if (handler) {
        try {
          res = await handler(context, () => dispatch(i + 1));
        } catch (err) {
          if (err instanceof Error && onError) {
            context.error = err;
            res = await onError(err, context);
            isError = true;
          } else {
            throw err;
          }
        }
      } else {
        if (context.finalized === false && onNotFound) {
          res = await onNotFound(context);
        }
      }
      if (res && (context.finalized === false || isError)) {
        context.res = res;
      }
      return context;
    }
  };
};

// .stack/node_modules/hono/dist/request/constants.js
var GET_MATCH_RESULT = /* @__PURE__ */ Symbol();

// .stack/node_modules/hono/dist/utils/body.js
var parseBody = async (request, options = /* @__PURE__ */ Object.create(null)) => {
  const { all = false, dot = false } = options;
  const headers = request instanceof HonoRequest ? request.raw.headers : request.headers;
  const contentType = headers.get("Content-Type");
  if (contentType?.startsWith("multipart/form-data") || contentType?.startsWith("application/x-www-form-urlencoded")) {
    return parseFormData(request, { all, dot });
  }
  return {};
};
async function parseFormData(request, options) {
  const formData = await request.formData();
  if (formData) {
    return convertFormDataToBodyData(formData, options);
  }
  return {};
}
function convertFormDataToBodyData(formData, options) {
  const form = /* @__PURE__ */ Object.create(null);
  formData.forEach((value, key) => {
    const shouldParseAllValues = options.all || key.endsWith("[]");
    if (!shouldParseAllValues) {
      form[key] = value;
    } else {
      handleParsingAllValues(form, key, value);
    }
  });
  if (options.dot) {
    Object.entries(form).forEach(([key, value]) => {
      const shouldParseDotValues = key.includes(".");
      if (shouldParseDotValues) {
        handleParsingNestedValues(form, key, value);
        delete form[key];
      }
    });
  }
  return form;
}
var handleParsingAllValues = (form, key, value) => {
  if (form[key] !== void 0) {
    if (Array.isArray(form[key])) {
      ;
      form[key].push(value);
    } else {
      form[key] = [form[key], value];
    }
  } else {
    if (!key.endsWith("[]")) {
      form[key] = value;
    } else {
      form[key] = [value];
    }
  }
};
var handleParsingNestedValues = (form, key, value) => {
  let nestedForm = form;
  const keys = key.split(".");
  keys.forEach((key2, index) => {
    if (index === keys.length - 1) {
      nestedForm[key2] = value;
    } else {
      if (!nestedForm[key2] || typeof nestedForm[key2] !== "object" || Array.isArray(nestedForm[key2]) || nestedForm[key2] instanceof File) {
        nestedForm[key2] = /* @__PURE__ */ Object.create(null);
      }
      nestedForm = nestedForm[key2];
    }
  });
};

// .stack/node_modules/hono/dist/utils/url.js
var splitPath = (path) => {
  const paths = path.split("/");
  if (paths[0] === "") {
    paths.shift();
  }
  return paths;
};
var splitRoutingPath = (routePath) => {
  const { groups, path } = extractGroupsFromPath(routePath);
  const paths = splitPath(path);
  return replaceGroupMarks(paths, groups);
};
var extractGroupsFromPath = (path) => {
  const groups = [];
  path = path.replace(/\{[^}]+\}/g, (match2, index) => {
    const mark = `@${index}`;
    groups.push([mark, match2]);
    return mark;
  });
  return { groups, path };
};
var replaceGroupMarks = (paths, groups) => {
  for (let i = groups.length - 1; i >= 0; i--) {
    const [mark] = groups[i];
    for (let j = paths.length - 1; j >= 0; j--) {
      if (paths[j].includes(mark)) {
        paths[j] = paths[j].replace(mark, groups[i][1]);
        break;
      }
    }
  }
  return paths;
};
var patternCache = {};
var getPattern = (label, next) => {
  if (label === "*") {
    return "*";
  }
  const match2 = label.match(/^\:([^\{\}]+)(?:\{(.+)\})?$/);
  if (match2) {
    const cacheKey2 = `${label}#${next}`;
    if (!patternCache[cacheKey2]) {
      if (match2[2]) {
        patternCache[cacheKey2] = next && next[0] !== ":" && next[0] !== "*" ? [cacheKey2, match2[1], new RegExp(`^${match2[2]}(?=/${next})`)] : [label, match2[1], new RegExp(`^${match2[2]}$`)];
      } else {
        patternCache[cacheKey2] = [label, match2[1], true];
      }
    }
    return patternCache[cacheKey2];
  }
  return null;
};
var tryDecode = (str, decoder) => {
  try {
    return decoder(str);
  } catch {
    return str.replace(/(?:%[0-9A-Fa-f]{2})+/g, (match2) => {
      try {
        return decoder(match2);
      } catch {
        return match2;
      }
    });
  }
};
var tryDecodeURI = (str) => tryDecode(str, decodeURI);
var getPath = (request) => {
  const url = request.url;
  const start = url.indexOf("/", url.indexOf(":") + 4);
  let i = start;
  for (; i < url.length; i++) {
    const charCode = url.charCodeAt(i);
    if (charCode === 37) {
      const queryIndex = url.indexOf("?", i);
      const hashIndex = url.indexOf("#", i);
      const end = queryIndex === -1 ? hashIndex === -1 ? void 0 : hashIndex : hashIndex === -1 ? queryIndex : Math.min(queryIndex, hashIndex);
      const path = url.slice(start, end);
      return tryDecodeURI(path.includes("%25") ? path.replace(/%25/g, "%2525") : path);
    } else if (charCode === 63 || charCode === 35) {
      break;
    }
  }
  return url.slice(start, i);
};
var getPathNoStrict = (request) => {
  const result = getPath(request);
  return result.length > 1 && result.at(-1) === "/" ? result.slice(0, -1) : result;
};
var mergePath = (base, sub, ...rest) => {
  if (rest.length) {
    sub = mergePath(sub, ...rest);
  }
  return `${base?.[0] === "/" ? "" : "/"}${base}${sub === "/" ? "" : `${base?.at(-1) === "/" ? "" : "/"}${sub?.[0] === "/" ? sub.slice(1) : sub}`}`;
};
var checkOptionalParameter = (path) => {
  if (path.charCodeAt(path.length - 1) !== 63 || !path.includes(":")) {
    return null;
  }
  const segments = path.split("/");
  const results = [];
  let basePath = "";
  segments.forEach((segment) => {
    if (segment !== "" && !/\:/.test(segment)) {
      basePath += "/" + segment;
    } else if (/\:/.test(segment)) {
      if (/\?/.test(segment)) {
        if (results.length === 0 && basePath === "") {
          results.push("/");
        } else {
          results.push(basePath);
        }
        const optionalSegment = segment.replace("?", "");
        basePath += "/" + optionalSegment;
        results.push(basePath);
      } else {
        basePath += "/" + segment;
      }
    }
  });
  return results.filter((v, i, a) => a.indexOf(v) === i);
};
var _decodeURI = (value) => {
  if (!/[%+]/.test(value)) {
    return value;
  }
  if (value.indexOf("+") !== -1) {
    value = value.replace(/\+/g, " ");
  }
  return value.indexOf("%") !== -1 ? tryDecode(value, decodeURIComponent_) : value;
};
var _getQueryParam = (url, key, multiple) => {
  let encoded;
  if (!multiple && key && !/[%+]/.test(key)) {
    let keyIndex2 = url.indexOf("?", 8);
    if (keyIndex2 === -1) {
      return void 0;
    }
    if (!url.startsWith(key, keyIndex2 + 1)) {
      keyIndex2 = url.indexOf(`&${key}`, keyIndex2 + 1);
    }
    while (keyIndex2 !== -1) {
      const trailingKeyCode = url.charCodeAt(keyIndex2 + key.length + 1);
      if (trailingKeyCode === 61) {
        const valueIndex = keyIndex2 + key.length + 2;
        const endIndex = url.indexOf("&", valueIndex);
        return _decodeURI(url.slice(valueIndex, endIndex === -1 ? void 0 : endIndex));
      } else if (trailingKeyCode == 38 || isNaN(trailingKeyCode)) {
        return "";
      }
      keyIndex2 = url.indexOf(`&${key}`, keyIndex2 + 1);
    }
    encoded = /[%+]/.test(url);
    if (!encoded) {
      return void 0;
    }
  }
  const results = {};
  encoded ??= /[%+]/.test(url);
  let keyIndex = url.indexOf("?", 8);
  while (keyIndex !== -1) {
    const nextKeyIndex = url.indexOf("&", keyIndex + 1);
    let valueIndex = url.indexOf("=", keyIndex);
    if (valueIndex > nextKeyIndex && nextKeyIndex !== -1) {
      valueIndex = -1;
    }
    let name = url.slice(
      keyIndex + 1,
      valueIndex === -1 ? nextKeyIndex === -1 ? void 0 : nextKeyIndex : valueIndex
    );
    if (encoded) {
      name = _decodeURI(name);
    }
    keyIndex = nextKeyIndex;
    if (name === "") {
      continue;
    }
    let value;
    if (valueIndex === -1) {
      value = "";
    } else {
      value = url.slice(valueIndex + 1, nextKeyIndex === -1 ? void 0 : nextKeyIndex);
      if (encoded) {
        value = _decodeURI(value);
      }
    }
    if (multiple) {
      if (!(results[name] && Array.isArray(results[name]))) {
        results[name] = [];
      }
      ;
      results[name].push(value);
    } else {
      results[name] ??= value;
    }
  }
  return key ? results[key] : results;
};
var getQueryParam = _getQueryParam;
var getQueryParams = (url, key) => {
  return _getQueryParam(url, key, true);
};
var decodeURIComponent_ = decodeURIComponent;

// .stack/node_modules/hono/dist/request.js
var tryDecodeURIComponent = (str) => tryDecode(str, decodeURIComponent_);
var HonoRequest = class {
  /**
   * `.raw` can get the raw Request object.
   *
   * @see {@link https://hono.dev/docs/api/request#raw}
   *
   * @example
   * ```ts
   * // For Cloudflare Workers
   * app.post('/', async (c) => {
   *   const metadata = c.req.raw.cf?.hostMetadata?
   *   ...
   * })
   * ```
   */
  raw;
  #validatedData;
  // Short name of validatedData
  #matchResult;
  routeIndex = 0;
  /**
   * `.path` can get the pathname of the request.
   *
   * @see {@link https://hono.dev/docs/api/request#path}
   *
   * @example
   * ```ts
   * app.get('/about/me', (c) => {
   *   const pathname = c.req.path // `/about/me`
   * })
   * ```
   */
  path;
  bodyCache = {};
  constructor(request, path = "/", matchResult = [[]]) {
    this.raw = request;
    this.path = path;
    this.#matchResult = matchResult;
    this.#validatedData = {};
  }
  param(key) {
    return key ? this.#getDecodedParam(key) : this.#getAllDecodedParams();
  }
  #getDecodedParam(key) {
    const paramKey = this.#matchResult[0][this.routeIndex][1][key];
    const param = this.#getParamValue(paramKey);
    return param && /\%/.test(param) ? tryDecodeURIComponent(param) : param;
  }
  #getAllDecodedParams() {
    const decoded = {};
    const keys = Object.keys(this.#matchResult[0][this.routeIndex][1]);
    for (const key of keys) {
      const value = this.#getParamValue(this.#matchResult[0][this.routeIndex][1][key]);
      if (value !== void 0) {
        decoded[key] = /\%/.test(value) ? tryDecodeURIComponent(value) : value;
      }
    }
    return decoded;
  }
  #getParamValue(paramKey) {
    return this.#matchResult[1] ? this.#matchResult[1][paramKey] : paramKey;
  }
  query(key) {
    return getQueryParam(this.url, key);
  }
  queries(key) {
    return getQueryParams(this.url, key);
  }
  header(name) {
    if (name) {
      return this.raw.headers.get(name) ?? void 0;
    }
    const headerData = {};
    this.raw.headers.forEach((value, key) => {
      headerData[key] = value;
    });
    return headerData;
  }
  async parseBody(options) {
    return this.bodyCache.parsedBody ??= await parseBody(this, options);
  }
  #cachedBody = (key) => {
    const { bodyCache, raw: raw2 } = this;
    const cachedBody = bodyCache[key];
    if (cachedBody) {
      return cachedBody;
    }
    const anyCachedKey = Object.keys(bodyCache)[0];
    if (anyCachedKey) {
      return bodyCache[anyCachedKey].then((body) => {
        if (anyCachedKey === "json") {
          body = JSON.stringify(body);
        }
        return new Response(body)[key]();
      });
    }
    return bodyCache[key] = raw2[key]();
  };
  /**
   * `.json()` can parse Request body of type `application/json`
   *
   * @see {@link https://hono.dev/docs/api/request#json}
   *
   * @example
   * ```ts
   * app.post('/entry', async (c) => {
   *   const body = await c.req.json()
   * })
   * ```
   */
  json() {
    return this.#cachedBody("text").then((text2) => JSON.parse(text2));
  }
  /**
   * `.text()` can parse Request body of type `text/plain`
   *
   * @see {@link https://hono.dev/docs/api/request#text}
   *
   * @example
   * ```ts
   * app.post('/entry', async (c) => {
   *   const body = await c.req.text()
   * })
   * ```
   */
  text() {
    return this.#cachedBody("text");
  }
  /**
   * `.arrayBuffer()` parse Request body as an `ArrayBuffer`
   *
   * @see {@link https://hono.dev/docs/api/request#arraybuffer}
   *
   * @example
   * ```ts
   * app.post('/entry', async (c) => {
   *   const body = await c.req.arrayBuffer()
   * })
   * ```
   */
  arrayBuffer() {
    return this.#cachedBody("arrayBuffer");
  }
  /**
   * Parses the request body as a `Blob`.
   * @example
   * ```ts
   * app.post('/entry', async (c) => {
   *   const body = await c.req.blob();
   * });
   * ```
   * @see https://hono.dev/docs/api/request#blob
   */
  blob() {
    return this.#cachedBody("blob");
  }
  /**
   * Parses the request body as `FormData`.
   * @example
   * ```ts
   * app.post('/entry', async (c) => {
   *   const body = await c.req.formData();
   * });
   * ```
   * @see https://hono.dev/docs/api/request#formdata
   */
  formData() {
    return this.#cachedBody("formData");
  }
  /**
   * Adds validated data to the request.
   *
   * @param target - The target of the validation.
   * @param data - The validated data to add.
   */
  addValidatedData(target, data) {
    this.#validatedData[target] = data;
  }
  valid(target) {
    return this.#validatedData[target];
  }
  /**
   * `.url()` can get the request url strings.
   *
   * @see {@link https://hono.dev/docs/api/request#url}
   *
   * @example
   * ```ts
   * app.get('/about/me', (c) => {
   *   const url = c.req.url // `http://localhost:8787/about/me`
   *   ...
   * })
   * ```
   */
  get url() {
    return this.raw.url;
  }
  /**
   * `.method()` can get the method name of the request.
   *
   * @see {@link https://hono.dev/docs/api/request#method}
   *
   * @example
   * ```ts
   * app.get('/about/me', (c) => {
   *   const method = c.req.method // `GET`
   * })
   * ```
   */
  get method() {
    return this.raw.method;
  }
  get [GET_MATCH_RESULT]() {
    return this.#matchResult;
  }
  /**
   * `.matchedRoutes()` can return a matched route in the handler
   *
   * @deprecated
   *
   * Use matchedRoutes helper defined in "hono/route" instead.
   *
   * @see {@link https://hono.dev/docs/api/request#matchedroutes}
   *
   * @example
   * ```ts
   * app.use('*', async function logger(c, next) {
   *   await next()
   *   c.req.matchedRoutes.forEach(({ handler, method, path }, i) => {
   *     const name = handler.name || (handler.length < 2 ? '[handler]' : '[middleware]')
   *     console.log(
   *       method,
   *       ' ',
   *       path,
   *       ' '.repeat(Math.max(10 - path.length, 0)),
   *       name,
   *       i === c.req.routeIndex ? '<- respond from here' : ''
   *     )
   *   })
   * })
   * ```
   */
  get matchedRoutes() {
    return this.#matchResult[0].map(([[, route]]) => route);
  }
  /**
   * `routePath()` can retrieve the path registered within the handler
   *
   * @deprecated
   *
   * Use routePath helper defined in "hono/route" instead.
   *
   * @see {@link https://hono.dev/docs/api/request#routepath}
   *
   * @example
   * ```ts
   * app.get('/posts/:id', (c) => {
   *   return c.json({ path: c.req.routePath })
   * })
   * ```
   */
  get routePath() {
    return this.#matchResult[0].map(([[, route]]) => route)[this.routeIndex].path;
  }
};

// .stack/node_modules/hono/dist/utils/html.js
var HtmlEscapedCallbackPhase = {
  Stringify: 1,
  BeforeStream: 2,
  Stream: 3
};
var raw = (value, callbacks) => {
  const escapedString = new String(value);
  escapedString.isEscaped = true;
  escapedString.callbacks = callbacks;
  return escapedString;
};
var resolveCallback = async (str, phase, preserveCallbacks, context, buffer) => {
  if (typeof str === "object" && !(str instanceof String)) {
    if (!(str instanceof Promise)) {
      str = str.toString();
    }
    if (str instanceof Promise) {
      str = await str;
    }
  }
  const callbacks = str.callbacks;
  if (!callbacks?.length) {
    return Promise.resolve(str);
  }
  if (buffer) {
    buffer[0] += str;
  } else {
    buffer = [str];
  }
  const resStr = Promise.all(callbacks.map((c) => c({ phase, buffer, context }))).then(
    (res) => Promise.all(
      res.filter(Boolean).map((str2) => resolveCallback(str2, phase, false, context, buffer))
    ).then(() => buffer[0])
  );
  if (preserveCallbacks) {
    return raw(await resStr, callbacks);
  } else {
    return resStr;
  }
};

// .stack/node_modules/hono/dist/context.js
var TEXT_PLAIN = "text/plain; charset=UTF-8";
var setDefaultContentType = (contentType, headers) => {
  return {
    "Content-Type": contentType,
    ...headers
  };
};
var createResponseInstance = (body, init) => new Response(body, init);
var Context = class {
  #rawRequest;
  #req;
  /**
   * `.env` can get bindings (environment variables, secrets, KV namespaces, D1 database, R2 bucket etc.) in Cloudflare Workers.
   *
   * @see {@link https://hono.dev/docs/api/context#env}
   *
   * @example
   * ```ts
   * // Environment object for Cloudflare Workers
   * app.get('*', async c => {
   *   const counter = c.env.COUNTER
   * })
   * ```
   */
  env = {};
  #var;
  finalized = false;
  /**
   * `.error` can get the error object from the middleware if the Handler throws an error.
   *
   * @see {@link https://hono.dev/docs/api/context#error}
   *
   * @example
   * ```ts
   * app.use('*', async (c, next) => {
   *   await next()
   *   if (c.error) {
   *     // do something...
   *   }
   * })
   * ```
   */
  error;
  #status;
  #executionCtx;
  #res;
  #layout;
  #renderer;
  #notFoundHandler;
  #preparedHeaders;
  #matchResult;
  #path;
  /**
   * Creates an instance of the Context class.
   *
   * @param req - The Request object.
   * @param options - Optional configuration options for the context.
   */
  constructor(req, options) {
    this.#rawRequest = req;
    if (options) {
      this.#executionCtx = options.executionCtx;
      this.env = options.env;
      this.#notFoundHandler = options.notFoundHandler;
      this.#path = options.path;
      this.#matchResult = options.matchResult;
    }
  }
  /**
   * `.req` is the instance of {@link HonoRequest}.
   */
  get req() {
    this.#req ??= new HonoRequest(this.#rawRequest, this.#path, this.#matchResult);
    return this.#req;
  }
  /**
   * @see {@link https://hono.dev/docs/api/context#event}
   * The FetchEvent associated with the current request.
   *
   * @throws Will throw an error if the context does not have a FetchEvent.
   */
  get event() {
    if (this.#executionCtx && "respondWith" in this.#executionCtx) {
      return this.#executionCtx;
    } else {
      throw Error("This context has no FetchEvent");
    }
  }
  /**
   * @see {@link https://hono.dev/docs/api/context#executionctx}
   * The ExecutionContext associated with the current request.
   *
   * @throws Will throw an error if the context does not have an ExecutionContext.
   */
  get executionCtx() {
    if (this.#executionCtx) {
      return this.#executionCtx;
    } else {
      throw Error("This context has no ExecutionContext");
    }
  }
  /**
   * @see {@link https://hono.dev/docs/api/context#res}
   * The Response object for the current request.
   */
  get res() {
    return this.#res ||= createResponseInstance(null, {
      headers: this.#preparedHeaders ??= new Headers()
    });
  }
  /**
   * Sets the Response object for the current request.
   *
   * @param _res - The Response object to set.
   */
  set res(_res) {
    if (this.#res && _res) {
      _res = createResponseInstance(_res.body, _res);
      for (const [k, v] of this.#res.headers.entries()) {
        if (k === "content-type") {
          continue;
        }
        if (k === "set-cookie") {
          const cookies = this.#res.headers.getSetCookie();
          _res.headers.delete("set-cookie");
          for (const cookie of cookies) {
            _res.headers.append("set-cookie", cookie);
          }
        } else {
          _res.headers.set(k, v);
        }
      }
    }
    this.#res = _res;
    this.finalized = true;
  }
  /**
   * `.render()` can create a response within a layout.
   *
   * @see {@link https://hono.dev/docs/api/context#render-setrenderer}
   *
   * @example
   * ```ts
   * app.get('/', (c) => {
   *   return c.render('Hello!')
   * })
   * ```
   */
  render = (...args) => {
    this.#renderer ??= (content) => this.html(content);
    return this.#renderer(...args);
  };
  /**
   * Sets the layout for the response.
   *
   * @param layout - The layout to set.
   * @returns The layout function.
   */
  setLayout = (layout) => this.#layout = layout;
  /**
   * Gets the current layout for the response.
   *
   * @returns The current layout function.
   */
  getLayout = () => this.#layout;
  /**
   * `.setRenderer()` can set the layout in the custom middleware.
   *
   * @see {@link https://hono.dev/docs/api/context#render-setrenderer}
   *
   * @example
   * ```tsx
   * app.use('*', async (c, next) => {
   *   c.setRenderer((content) => {
   *     return c.html(
   *       <html>
   *         <body>
   *           <p>{content}</p>
   *         </body>
   *       </html>
   *     )
   *   })
   *   await next()
   * })
   * ```
   */
  setRenderer = (renderer) => {
    this.#renderer = renderer;
  };
  /**
   * `.header()` can set headers.
   *
   * @see {@link https://hono.dev/docs/api/context#header}
   *
   * @example
   * ```ts
   * app.get('/welcome', (c) => {
   *   // Set headers
   *   c.header('X-Message', 'Hello!')
   *   c.header('Content-Type', 'text/plain')
   *
   *   return c.body('Thank you for coming')
   * })
   * ```
   */
  header = (name, value, options) => {
    if (this.finalized) {
      this.#res = createResponseInstance(this.#res.body, this.#res);
    }
    const headers = this.#res ? this.#res.headers : this.#preparedHeaders ??= new Headers();
    if (value === void 0) {
      headers.delete(name);
    } else if (options?.append) {
      headers.append(name, value);
    } else {
      headers.set(name, value);
    }
  };
  status = (status) => {
    this.#status = status;
  };
  /**
   * `.set()` can set the value specified by the key.
   *
   * @see {@link https://hono.dev/docs/api/context#set-get}
   *
   * @example
   * ```ts
   * app.use('*', async (c, next) => {
   *   c.set('message', 'Hono is hot!!')
   *   await next()
   * })
   * ```
   */
  set = (key, value) => {
    this.#var ??= /* @__PURE__ */ new Map();
    this.#var.set(key, value);
  };
  /**
   * `.get()` can use the value specified by the key.
   *
   * @see {@link https://hono.dev/docs/api/context#set-get}
   *
   * @example
   * ```ts
   * app.get('/', (c) => {
   *   const message = c.get('message')
   *   return c.text(`The message is "${message}"`)
   * })
   * ```
   */
  get = (key) => {
    return this.#var ? this.#var.get(key) : void 0;
  };
  /**
   * `.var` can access the value of a variable.
   *
   * @see {@link https://hono.dev/docs/api/context#var}
   *
   * @example
   * ```ts
   * const result = c.var.client.oneMethod()
   * ```
   */
  // c.var.propName is a read-only
  get var() {
    if (!this.#var) {
      return {};
    }
    return Object.fromEntries(this.#var);
  }
  #newResponse(data, arg, headers) {
    const responseHeaders = this.#res ? new Headers(this.#res.headers) : this.#preparedHeaders ?? new Headers();
    if (typeof arg === "object" && "headers" in arg) {
      const argHeaders = arg.headers instanceof Headers ? arg.headers : new Headers(arg.headers);
      for (const [key, value] of argHeaders) {
        if (key.toLowerCase() === "set-cookie") {
          responseHeaders.append(key, value);
        } else {
          responseHeaders.set(key, value);
        }
      }
    }
    if (headers) {
      for (const [k, v] of Object.entries(headers)) {
        if (typeof v === "string") {
          responseHeaders.set(k, v);
        } else {
          responseHeaders.delete(k);
          for (const v2 of v) {
            responseHeaders.append(k, v2);
          }
        }
      }
    }
    const status = typeof arg === "number" ? arg : arg?.status ?? this.#status;
    return createResponseInstance(data, { status, headers: responseHeaders });
  }
  newResponse = (...args) => this.#newResponse(...args);
  /**
   * `.body()` can return the HTTP response.
   * You can set headers with `.header()` and set HTTP status code with `.status`.
   * This can also be set in `.text()`, `.json()` and so on.
   *
   * @see {@link https://hono.dev/docs/api/context#body}
   *
   * @example
   * ```ts
   * app.get('/welcome', (c) => {
   *   // Set headers
   *   c.header('X-Message', 'Hello!')
   *   c.header('Content-Type', 'text/plain')
   *   // Set HTTP status code
   *   c.status(201)
   *
   *   // Return the response body
   *   return c.body('Thank you for coming')
   * })
   * ```
   */
  body = (data, arg, headers) => this.#newResponse(data, arg, headers);
  #useFastPath() {
    return !this.#preparedHeaders && !this.#status && !this.finalized;
  }
  /**
   * `.text()` can render text as `Content-Type:text/plain`.
   *
   * @see {@link https://hono.dev/docs/api/context#text}
   *
   * @example
   * ```ts
   * app.get('/say', (c) => {
   *   return c.text('Hello!')
   * })
   * ```
   */
  text = (text2, arg, headers) => {
    return this.#useFastPath() && !arg && !headers ? createResponseInstance(text2) : this.#newResponse(
      text2,
      arg,
      setDefaultContentType(TEXT_PLAIN, headers)
    );
  };
  /**
   * `.json()` can render JSON as `Content-Type:application/json`.
   *
   * @see {@link https://hono.dev/docs/api/context#json}
   *
   * @example
   * ```ts
   * app.get('/api', (c) => {
   *   return c.json({ message: 'Hello!' })
   * })
   * ```
   */
  json = (object, arg, headers) => {
    return this.#useFastPath() && !arg && !headers ? Response.json(object) : this.#newResponse(
      JSON.stringify(object),
      arg,
      setDefaultContentType("application/json", headers)
    );
  };
  html = (html, arg, headers) => {
    const res = (html2) => this.#newResponse(html2, arg, setDefaultContentType("text/html; charset=UTF-8", headers));
    return typeof html === "object" ? resolveCallback(html, HtmlEscapedCallbackPhase.Stringify, false, {}).then(res) : res(html);
  };
  /**
   * `.redirect()` can Redirect, default status code is 302.
   *
   * @see {@link https://hono.dev/docs/api/context#redirect}
   *
   * @example
   * ```ts
   * app.get('/redirect', (c) => {
   *   return c.redirect('/')
   * })
   * app.get('/redirect-permanently', (c) => {
   *   return c.redirect('/', 301)
   * })
   * ```
   */
  redirect = (location, status) => {
    const locationString = String(location);
    this.header(
      "Location",
      // Multibyes should be encoded
      // eslint-disable-next-line no-control-regex
      !/[^\x00-\xFF]/.test(locationString) ? locationString : encodeURI(locationString)
    );
    return this.newResponse(null, status ?? 302);
  };
  /**
   * `.notFound()` can return the Not Found Response.
   *
   * @see {@link https://hono.dev/docs/api/context#notfound}
   *
   * @example
   * ```ts
   * app.get('/notfound', (c) => {
   *   return c.notFound()
   * })
   * ```
   */
  notFound = () => {
    this.#notFoundHandler ??= () => createResponseInstance();
    return this.#notFoundHandler(this);
  };
};

// .stack/node_modules/hono/dist/router.js
var METHOD_NAME_ALL = "ALL";
var METHOD_NAME_ALL_LOWERCASE = "all";
var METHODS = ["get", "post", "put", "delete", "options", "patch"];
var MESSAGE_MATCHER_IS_ALREADY_BUILT = "Can not add a route since the matcher is already built.";
var UnsupportedPathError = class extends Error {
};

// .stack/node_modules/hono/dist/utils/constants.js
var COMPOSED_HANDLER = "__COMPOSED_HANDLER";

// .stack/node_modules/hono/dist/hono-base.js
var notFoundHandler = (c) => {
  return c.text("404 Not Found", 404);
};
var errorHandler = (err, c) => {
  if ("getResponse" in err) {
    const res = err.getResponse();
    return c.newResponse(res.body, res);
  }
  console.error(err);
  return c.text("Internal Server Error", 500);
};
var Hono = class _Hono {
  get;
  post;
  put;
  delete;
  options;
  patch;
  all;
  on;
  use;
  /*
    This class is like an abstract class and does not have a router.
    To use it, inherit the class and implement router in the constructor.
  */
  router;
  getPath;
  // Cannot use `#` because it requires visibility at JavaScript runtime.
  _basePath = "/";
  #path = "/";
  routes = [];
  constructor(options = {}) {
    const allMethods = [...METHODS, METHOD_NAME_ALL_LOWERCASE];
    allMethods.forEach((method) => {
      this[method] = (args1, ...args) => {
        if (typeof args1 === "string") {
          this.#path = args1;
        } else {
          this.#addRoute(method, this.#path, args1);
        }
        args.forEach((handler) => {
          this.#addRoute(method, this.#path, handler);
        });
        return this;
      };
    });
    this.on = (method, path, ...handlers) => {
      for (const p of [path].flat()) {
        this.#path = p;
        for (const m of [method].flat()) {
          handlers.map((handler) => {
            this.#addRoute(m.toUpperCase(), this.#path, handler);
          });
        }
      }
      return this;
    };
    this.use = (arg1, ...handlers) => {
      if (typeof arg1 === "string") {
        this.#path = arg1;
      } else {
        this.#path = "*";
        handlers.unshift(arg1);
      }
      handlers.forEach((handler) => {
        this.#addRoute(METHOD_NAME_ALL, this.#path, handler);
      });
      return this;
    };
    const { strict, ...optionsWithoutStrict } = options;
    Object.assign(this, optionsWithoutStrict);
    this.getPath = strict ?? true ? options.getPath ?? getPath : getPathNoStrict;
  }
  #clone() {
    const clone = new _Hono({
      router: this.router,
      getPath: this.getPath
    });
    clone.errorHandler = this.errorHandler;
    clone.#notFoundHandler = this.#notFoundHandler;
    clone.routes = this.routes;
    return clone;
  }
  #notFoundHandler = notFoundHandler;
  // Cannot use `#` because it requires visibility at JavaScript runtime.
  errorHandler = errorHandler;
  /**
   * `.route()` allows grouping other Hono instance in routes.
   *
   * @see {@link https://hono.dev/docs/api/routing#grouping}
   *
   * @param {string} path - base Path
   * @param {Hono} app - other Hono instance
   * @returns {Hono} routed Hono instance
   *
   * @example
   * ```ts
   * const app = new Hono()
   * const app2 = new Hono()
   *
   * app2.get("/user", (c) => c.text("user"))
   * app.route("/api", app2) // GET /api/user
   * ```
   */
  route(path, app) {
    const subApp = this.basePath(path);
    app.routes.map((r) => {
      let handler;
      if (app.errorHandler === errorHandler) {
        handler = r.handler;
      } else {
        handler = async (c, next) => (await compose([], app.errorHandler)(c, () => r.handler(c, next))).res;
        handler[COMPOSED_HANDLER] = r.handler;
      }
      subApp.#addRoute(r.method, r.path, handler);
    });
    return this;
  }
  /**
   * `.basePath()` allows base paths to be specified.
   *
   * @see {@link https://hono.dev/docs/api/routing#base-path}
   *
   * @param {string} path - base Path
   * @returns {Hono} changed Hono instance
   *
   * @example
   * ```ts
   * const api = new Hono().basePath('/api')
   * ```
   */
  basePath(path) {
    const subApp = this.#clone();
    subApp._basePath = mergePath(this._basePath, path);
    return subApp;
  }
  /**
   * `.onError()` handles an error and returns a customized Response.
   *
   * @see {@link https://hono.dev/docs/api/hono#error-handling}
   *
   * @param {ErrorHandler} handler - request Handler for error
   * @returns {Hono} changed Hono instance
   *
   * @example
   * ```ts
   * app.onError((err, c) => {
   *   console.error(`${err}`)
   *   return c.text('Custom Error Message', 500)
   * })
   * ```
   */
  onError = (handler) => {
    this.errorHandler = handler;
    return this;
  };
  /**
   * `.notFound()` allows you to customize a Not Found Response.
   *
   * @see {@link https://hono.dev/docs/api/hono#not-found}
   *
   * @param {NotFoundHandler} handler - request handler for not-found
   * @returns {Hono} changed Hono instance
   *
   * @example
   * ```ts
   * app.notFound((c) => {
   *   return c.text('Custom 404 Message', 404)
   * })
   * ```
   */
  notFound = (handler) => {
    this.#notFoundHandler = handler;
    return this;
  };
  /**
   * `.mount()` allows you to mount applications built with other frameworks into your Hono application.
   *
   * @see {@link https://hono.dev/docs/api/hono#mount}
   *
   * @param {string} path - base Path
   * @param {Function} applicationHandler - other Request Handler
   * @param {MountOptions} [options] - options of `.mount()`
   * @returns {Hono} mounted Hono instance
   *
   * @example
   * ```ts
   * import { Router as IttyRouter } from 'itty-router'
   * import { Hono } from 'hono'
   * // Create itty-router application
   * const ittyRouter = IttyRouter()
   * // GET /itty-router/hello
   * ittyRouter.get('/hello', () => new Response('Hello from itty-router'))
   *
   * const app = new Hono()
   * app.mount('/itty-router', ittyRouter.handle)
   * ```
   *
   * @example
   * ```ts
   * const app = new Hono()
   * // Send the request to another application without modification.
   * app.mount('/app', anotherApp, {
   *   replaceRequest: (req) => req,
   * })
   * ```
   */
  mount(path, applicationHandler, options) {
    let replaceRequest;
    let optionHandler;
    if (options) {
      if (typeof options === "function") {
        optionHandler = options;
      } else {
        optionHandler = options.optionHandler;
        if (options.replaceRequest === false) {
          replaceRequest = (request) => request;
        } else {
          replaceRequest = options.replaceRequest;
        }
      }
    }
    const getOptions = optionHandler ? (c) => {
      const options2 = optionHandler(c);
      return Array.isArray(options2) ? options2 : [options2];
    } : (c) => {
      let executionContext = void 0;
      try {
        executionContext = c.executionCtx;
      } catch {
      }
      return [c.env, executionContext];
    };
    replaceRequest ||= (() => {
      const mergedPath = mergePath(this._basePath, path);
      const pathPrefixLength = mergedPath === "/" ? 0 : mergedPath.length;
      return (request) => {
        const url = new URL(request.url);
        url.pathname = url.pathname.slice(pathPrefixLength) || "/";
        return new Request(url, request);
      };
    })();
    const handler = async (c, next) => {
      const res = await applicationHandler(replaceRequest(c.req.raw), ...getOptions(c));
      if (res) {
        return res;
      }
      await next();
    };
    this.#addRoute(METHOD_NAME_ALL, mergePath(path, "*"), handler);
    return this;
  }
  #addRoute(method, path, handler) {
    method = method.toUpperCase();
    path = mergePath(this._basePath, path);
    const r = { basePath: this._basePath, path, method, handler };
    this.router.add(method, path, [handler, r]);
    this.routes.push(r);
  }
  #handleError(err, c) {
    if (err instanceof Error) {
      return this.errorHandler(err, c);
    }
    throw err;
  }
  #dispatch(request, executionCtx, env, method) {
    if (method === "HEAD") {
      return (async () => new Response(null, await this.#dispatch(request, executionCtx, env, "GET")))();
    }
    const path = this.getPath(request, { env });
    const matchResult = this.router.match(method, path);
    const c = new Context(request, {
      path,
      matchResult,
      env,
      executionCtx,
      notFoundHandler: this.#notFoundHandler
    });
    if (matchResult[0].length === 1) {
      let res;
      try {
        res = matchResult[0][0][0][0](c, async () => {
          c.res = await this.#notFoundHandler(c);
        });
      } catch (err) {
        return this.#handleError(err, c);
      }
      return res instanceof Promise ? res.then(
        (resolved) => resolved || (c.finalized ? c.res : this.#notFoundHandler(c))
      ).catch((err) => this.#handleError(err, c)) : res ?? this.#notFoundHandler(c);
    }
    const composed = compose(matchResult[0], this.errorHandler, this.#notFoundHandler);
    return (async () => {
      try {
        const context = await composed(c);
        if (!context.finalized) {
          throw new Error(
            "Context is not finalized. Did you forget to return a Response object or `await next()`?"
          );
        }
        return context.res;
      } catch (err) {
        return this.#handleError(err, c);
      }
    })();
  }
  /**
   * `.fetch()` will be entry point of your app.
   *
   * @see {@link https://hono.dev/docs/api/hono#fetch}
   *
   * @param {Request} request - request Object of request
   * @param {Env} Env - env Object
   * @param {ExecutionContext} - context of execution
   * @returns {Response | Promise<Response>} response of request
   *
   */
  fetch = (request, ...rest) => {
    return this.#dispatch(request, rest[1], rest[0], request.method);
  };
  /**
   * `.request()` is a useful method for testing.
   * You can pass a URL or pathname to send a GET request.
   * app will return a Response object.
   * ```ts
   * test('GET /hello is ok', async () => {
   *   const res = await app.request('/hello')
   *   expect(res.status).toBe(200)
   * })
   * ```
   * @see https://hono.dev/docs/api/hono#request
   */
  request = (input, requestInit, Env, executionCtx) => {
    if (input instanceof Request) {
      return this.fetch(requestInit ? new Request(input, requestInit) : input, Env, executionCtx);
    }
    input = input.toString();
    return this.fetch(
      new Request(
        /^https?:\/\//.test(input) ? input : `http://localhost${mergePath("/", input)}`,
        requestInit
      ),
      Env,
      executionCtx
    );
  };
  /**
   * `.fire()` automatically adds a global fetch event listener.
   * This can be useful for environments that adhere to the Service Worker API, such as non-ES module Cloudflare Workers.
   * @deprecated
   * Use `fire` from `hono/service-worker` instead.
   * ```ts
   * import { Hono } from 'hono'
   * import { fire } from 'hono/service-worker'
   *
   * const app = new Hono()
   * // ...
   * fire(app)
   * ```
   * @see https://hono.dev/docs/api/hono#fire
   * @see https://developer.mozilla.org/en-US/docs/Web/API/Service_Worker_API
   * @see https://developers.cloudflare.com/workers/reference/migrate-to-module-workers/
   */
  fire = () => {
    addEventListener("fetch", (event) => {
      event.respondWith(this.#dispatch(event.request, event, void 0, event.request.method));
    });
  };
};

// .stack/node_modules/hono/dist/router/reg-exp-router/matcher.js
var emptyParam = [];
function match(method, path) {
  const matchers = this.buildAllMatchers();
  const match2 = ((method2, path2) => {
    const matcher = matchers[method2] || matchers[METHOD_NAME_ALL];
    const staticMatch = matcher[2][path2];
    if (staticMatch) {
      return staticMatch;
    }
    const match3 = path2.match(matcher[0]);
    if (!match3) {
      return [[], emptyParam];
    }
    const index = match3.indexOf("", 1);
    return [matcher[1][index], match3];
  });
  this.match = match2;
  return match2(method, path);
}

// .stack/node_modules/hono/dist/router/reg-exp-router/node.js
var LABEL_REG_EXP_STR = "[^/]+";
var ONLY_WILDCARD_REG_EXP_STR = ".*";
var TAIL_WILDCARD_REG_EXP_STR = "(?:|/.*)";
var PATH_ERROR = /* @__PURE__ */ Symbol();
var regExpMetaChars = new Set(".\\+*[^]$()");
function compareKey(a, b) {
  if (a.length === 1) {
    return b.length === 1 ? a < b ? -1 : 1 : -1;
  }
  if (b.length === 1) {
    return 1;
  }
  if (a === ONLY_WILDCARD_REG_EXP_STR || a === TAIL_WILDCARD_REG_EXP_STR) {
    return 1;
  } else if (b === ONLY_WILDCARD_REG_EXP_STR || b === TAIL_WILDCARD_REG_EXP_STR) {
    return -1;
  }
  if (a === LABEL_REG_EXP_STR) {
    return 1;
  } else if (b === LABEL_REG_EXP_STR) {
    return -1;
  }
  return a.length === b.length ? a < b ? -1 : 1 : b.length - a.length;
}
var Node = class _Node {
  #index;
  #varIndex;
  #children = /* @__PURE__ */ Object.create(null);
  insert(tokens, index, paramMap, context, pathErrorCheckOnly) {
    if (tokens.length === 0) {
      if (this.#index !== void 0) {
        throw PATH_ERROR;
      }
      if (pathErrorCheckOnly) {
        return;
      }
      this.#index = index;
      return;
    }
    const [token, ...restTokens] = tokens;
    const pattern = token === "*" ? restTokens.length === 0 ? ["", "", ONLY_WILDCARD_REG_EXP_STR] : ["", "", LABEL_REG_EXP_STR] : token === "/*" ? ["", "", TAIL_WILDCARD_REG_EXP_STR] : token.match(/^\:([^\{\}]+)(?:\{(.+)\})?$/);
    let node;
    if (pattern) {
      const name = pattern[1];
      let regexpStr = pattern[2] || LABEL_REG_EXP_STR;
      if (name && pattern[2]) {
        if (regexpStr === ".*") {
          throw PATH_ERROR;
        }
        regexpStr = regexpStr.replace(/^\((?!\?:)(?=[^)]+\)$)/, "(?:");
        if (/\((?!\?:)/.test(regexpStr)) {
          throw PATH_ERROR;
        }
      }
      node = this.#children[regexpStr];
      if (!node) {
        if (Object.keys(this.#children).some(
          (k) => k !== ONLY_WILDCARD_REG_EXP_STR && k !== TAIL_WILDCARD_REG_EXP_STR
        )) {
          throw PATH_ERROR;
        }
        if (pathErrorCheckOnly) {
          return;
        }
        node = this.#children[regexpStr] = new _Node();
        if (name !== "") {
          node.#varIndex = context.varIndex++;
        }
      }
      if (!pathErrorCheckOnly && name !== "") {
        paramMap.push([name, node.#varIndex]);
      }
    } else {
      node = this.#children[token];
      if (!node) {
        if (Object.keys(this.#children).some(
          (k) => k.length > 1 && k !== ONLY_WILDCARD_REG_EXP_STR && k !== TAIL_WILDCARD_REG_EXP_STR
        )) {
          throw PATH_ERROR;
        }
        if (pathErrorCheckOnly) {
          return;
        }
        node = this.#children[token] = new _Node();
      }
    }
    node.insert(restTokens, index, paramMap, context, pathErrorCheckOnly);
  }
  buildRegExpStr() {
    const childKeys = Object.keys(this.#children).sort(compareKey);
    const strList = childKeys.map((k) => {
      const c = this.#children[k];
      return (typeof c.#varIndex === "number" ? `(${k})@${c.#varIndex}` : regExpMetaChars.has(k) ? `\\${k}` : k) + c.buildRegExpStr();
    });
    if (typeof this.#index === "number") {
      strList.unshift(`#${this.#index}`);
    }
    if (strList.length === 0) {
      return "";
    }
    if (strList.length === 1) {
      return strList[0];
    }
    return "(?:" + strList.join("|") + ")";
  }
};

// .stack/node_modules/hono/dist/router/reg-exp-router/trie.js
var Trie = class {
  #context = { varIndex: 0 };
  #root = new Node();
  insert(path, index, pathErrorCheckOnly) {
    const paramAssoc = [];
    const groups = [];
    for (let i = 0; ; ) {
      let replaced = false;
      path = path.replace(/\{[^}]+\}/g, (m) => {
        const mark = `@\\${i}`;
        groups[i] = [mark, m];
        i++;
        replaced = true;
        return mark;
      });
      if (!replaced) {
        break;
      }
    }
    const tokens = path.match(/(?::[^\/]+)|(?:\/\*$)|./g) || [];
    for (let i = groups.length - 1; i >= 0; i--) {
      const [mark] = groups[i];
      for (let j = tokens.length - 1; j >= 0; j--) {
        if (tokens[j].indexOf(mark) !== -1) {
          tokens[j] = tokens[j].replace(mark, groups[i][1]);
          break;
        }
      }
    }
    this.#root.insert(tokens, index, paramAssoc, this.#context, pathErrorCheckOnly);
    return paramAssoc;
  }
  buildRegExp() {
    let regexp = this.#root.buildRegExpStr();
    if (regexp === "") {
      return [/^$/, [], []];
    }
    let captureIndex = 0;
    const indexReplacementMap = [];
    const paramReplacementMap = [];
    regexp = regexp.replace(/#(\d+)|@(\d+)|\.\*\$/g, (_, handlerIndex, paramIndex) => {
      if (handlerIndex !== void 0) {
        indexReplacementMap[++captureIndex] = Number(handlerIndex);
        return "$()";
      }
      if (paramIndex !== void 0) {
        paramReplacementMap[Number(paramIndex)] = ++captureIndex;
        return "";
      }
      return "";
    });
    return [new RegExp(`^${regexp}`), indexReplacementMap, paramReplacementMap];
  }
};

// .stack/node_modules/hono/dist/router/reg-exp-router/router.js
var nullMatcher = [/^$/, [], /* @__PURE__ */ Object.create(null)];
var wildcardRegExpCache = /* @__PURE__ */ Object.create(null);
function buildWildcardRegExp(path) {
  return wildcardRegExpCache[path] ??= new RegExp(
    path === "*" ? "" : `^${path.replace(
      /\/\*$|([.\\+*[^\]$()])/g,
      (_, metaChar) => metaChar ? `\\${metaChar}` : "(?:|/.*)"
    )}$`
  );
}
function clearWildcardRegExpCache() {
  wildcardRegExpCache = /* @__PURE__ */ Object.create(null);
}
function buildMatcherFromPreprocessedRoutes(routes) {
  const trie = new Trie();
  const handlerData = [];
  if (routes.length === 0) {
    return nullMatcher;
  }
  const routesWithStaticPathFlag = routes.map(
    (route) => [!/\*|\/:/.test(route[0]), ...route]
  ).sort(
    ([isStaticA, pathA], [isStaticB, pathB]) => isStaticA ? 1 : isStaticB ? -1 : pathA.length - pathB.length
  );
  const staticMap = /* @__PURE__ */ Object.create(null);
  for (let i = 0, j = -1, len = routesWithStaticPathFlag.length; i < len; i++) {
    const [pathErrorCheckOnly, path, handlers] = routesWithStaticPathFlag[i];
    if (pathErrorCheckOnly) {
      staticMap[path] = [handlers.map(([h]) => [h, /* @__PURE__ */ Object.create(null)]), emptyParam];
    } else {
      j++;
    }
    let paramAssoc;
    try {
      paramAssoc = trie.insert(path, j, pathErrorCheckOnly);
    } catch (e) {
      throw e === PATH_ERROR ? new UnsupportedPathError(path) : e;
    }
    if (pathErrorCheckOnly) {
      continue;
    }
    handlerData[j] = handlers.map(([h, paramCount]) => {
      const paramIndexMap = /* @__PURE__ */ Object.create(null);
      paramCount -= 1;
      for (; paramCount >= 0; paramCount--) {
        const [key, value] = paramAssoc[paramCount];
        paramIndexMap[key] = value;
      }
      return [h, paramIndexMap];
    });
  }
  const [regexp, indexReplacementMap, paramReplacementMap] = trie.buildRegExp();
  for (let i = 0, len = handlerData.length; i < len; i++) {
    for (let j = 0, len2 = handlerData[i].length; j < len2; j++) {
      const map = handlerData[i][j]?.[1];
      if (!map) {
        continue;
      }
      const keys = Object.keys(map);
      for (let k = 0, len3 = keys.length; k < len3; k++) {
        map[keys[k]] = paramReplacementMap[map[keys[k]]];
      }
    }
  }
  const handlerMap = [];
  for (const i in indexReplacementMap) {
    handlerMap[i] = handlerData[indexReplacementMap[i]];
  }
  return [regexp, handlerMap, staticMap];
}
function findMiddleware(middleware, path) {
  if (!middleware) {
    return void 0;
  }
  for (const k of Object.keys(middleware).sort((a, b) => b.length - a.length)) {
    if (buildWildcardRegExp(k).test(path)) {
      return [...middleware[k]];
    }
  }
  return void 0;
}
var RegExpRouter = class {
  name = "RegExpRouter";
  #middleware;
  #routes;
  constructor() {
    this.#middleware = { [METHOD_NAME_ALL]: /* @__PURE__ */ Object.create(null) };
    this.#routes = { [METHOD_NAME_ALL]: /* @__PURE__ */ Object.create(null) };
  }
  add(method, path, handler) {
    const middleware = this.#middleware;
    const routes = this.#routes;
    if (!middleware || !routes) {
      throw new Error(MESSAGE_MATCHER_IS_ALREADY_BUILT);
    }
    if (!middleware[method]) {
      ;
      [middleware, routes].forEach((handlerMap) => {
        handlerMap[method] = /* @__PURE__ */ Object.create(null);
        Object.keys(handlerMap[METHOD_NAME_ALL]).forEach((p) => {
          handlerMap[method][p] = [...handlerMap[METHOD_NAME_ALL][p]];
        });
      });
    }
    if (path === "/*") {
      path = "*";
    }
    const paramCount = (path.match(/\/:/g) || []).length;
    if (/\*$/.test(path)) {
      const re = buildWildcardRegExp(path);
      if (method === METHOD_NAME_ALL) {
        Object.keys(middleware).forEach((m) => {
          middleware[m][path] ||= findMiddleware(middleware[m], path) || findMiddleware(middleware[METHOD_NAME_ALL], path) || [];
        });
      } else {
        middleware[method][path] ||= findMiddleware(middleware[method], path) || findMiddleware(middleware[METHOD_NAME_ALL], path) || [];
      }
      Object.keys(middleware).forEach((m) => {
        if (method === METHOD_NAME_ALL || method === m) {
          Object.keys(middleware[m]).forEach((p) => {
            re.test(p) && middleware[m][p].push([handler, paramCount]);
          });
        }
      });
      Object.keys(routes).forEach((m) => {
        if (method === METHOD_NAME_ALL || method === m) {
          Object.keys(routes[m]).forEach(
            (p) => re.test(p) && routes[m][p].push([handler, paramCount])
          );
        }
      });
      return;
    }
    const paths = checkOptionalParameter(path) || [path];
    for (let i = 0, len = paths.length; i < len; i++) {
      const path2 = paths[i];
      Object.keys(routes).forEach((m) => {
        if (method === METHOD_NAME_ALL || method === m) {
          routes[m][path2] ||= [
            ...findMiddleware(middleware[m], path2) || findMiddleware(middleware[METHOD_NAME_ALL], path2) || []
          ];
          routes[m][path2].push([handler, paramCount - len + i + 1]);
        }
      });
    }
  }
  match = match;
  buildAllMatchers() {
    const matchers = /* @__PURE__ */ Object.create(null);
    Object.keys(this.#routes).concat(Object.keys(this.#middleware)).forEach((method) => {
      matchers[method] ||= this.#buildMatcher(method);
    });
    this.#middleware = this.#routes = void 0;
    clearWildcardRegExpCache();
    return matchers;
  }
  #buildMatcher(method) {
    const routes = [];
    let hasOwnRoute = method === METHOD_NAME_ALL;
    [this.#middleware, this.#routes].forEach((r) => {
      const ownRoute = r[method] ? Object.keys(r[method]).map((path) => [path, r[method][path]]) : [];
      if (ownRoute.length !== 0) {
        hasOwnRoute ||= true;
        routes.push(...ownRoute);
      } else if (method !== METHOD_NAME_ALL) {
        routes.push(
          ...Object.keys(r[METHOD_NAME_ALL]).map((path) => [path, r[METHOD_NAME_ALL][path]])
        );
      }
    });
    if (!hasOwnRoute) {
      return null;
    } else {
      return buildMatcherFromPreprocessedRoutes(routes);
    }
  }
};

// .stack/node_modules/hono/dist/router/smart-router/router.js
var SmartRouter = class {
  name = "SmartRouter";
  #routers = [];
  #routes = [];
  constructor(init) {
    this.#routers = init.routers;
  }
  add(method, path, handler) {
    if (!this.#routes) {
      throw new Error(MESSAGE_MATCHER_IS_ALREADY_BUILT);
    }
    this.#routes.push([method, path, handler]);
  }
  match(method, path) {
    if (!this.#routes) {
      throw new Error("Fatal error");
    }
    const routers = this.#routers;
    const routes = this.#routes;
    const len = routers.length;
    let i = 0;
    let res;
    for (; i < len; i++) {
      const router = routers[i];
      try {
        for (let i2 = 0, len2 = routes.length; i2 < len2; i2++) {
          router.add(...routes[i2]);
        }
        res = router.match(method, path);
      } catch (e) {
        if (e instanceof UnsupportedPathError) {
          continue;
        }
        throw e;
      }
      this.match = router.match.bind(router);
      this.#routers = [router];
      this.#routes = void 0;
      break;
    }
    if (i === len) {
      throw new Error("Fatal error");
    }
    this.name = `SmartRouter + ${this.activeRouter.name}`;
    return res;
  }
  get activeRouter() {
    if (this.#routes || this.#routers.length !== 1) {
      throw new Error("No active router has been determined yet.");
    }
    return this.#routers[0];
  }
};

// .stack/node_modules/hono/dist/router/trie-router/node.js
var emptyParams = /* @__PURE__ */ Object.create(null);
var hasChildren = (children) => {
  for (const _ in children) {
    return true;
  }
  return false;
};
var Node2 = class _Node2 {
  #methods;
  #children;
  #patterns;
  #order = 0;
  #params = emptyParams;
  constructor(method, handler, children) {
    this.#children = children || /* @__PURE__ */ Object.create(null);
    this.#methods = [];
    if (method && handler) {
      const m = /* @__PURE__ */ Object.create(null);
      m[method] = { handler, possibleKeys: [], score: 0 };
      this.#methods = [m];
    }
    this.#patterns = [];
  }
  insert(method, path, handler) {
    this.#order = ++this.#order;
    let curNode = this;
    const parts = splitRoutingPath(path);
    const possibleKeys = [];
    for (let i = 0, len = parts.length; i < len; i++) {
      const p = parts[i];
      const nextP = parts[i + 1];
      const pattern = getPattern(p, nextP);
      const key = Array.isArray(pattern) ? pattern[0] : p;
      if (key in curNode.#children) {
        curNode = curNode.#children[key];
        if (pattern) {
          possibleKeys.push(pattern[1]);
        }
        continue;
      }
      curNode.#children[key] = new _Node2();
      if (pattern) {
        curNode.#patterns.push(pattern);
        possibleKeys.push(pattern[1]);
      }
      curNode = curNode.#children[key];
    }
    curNode.#methods.push({
      [method]: {
        handler,
        possibleKeys: possibleKeys.filter((v, i, a) => a.indexOf(v) === i),
        score: this.#order
      }
    });
    return curNode;
  }
  #pushHandlerSets(handlerSets, node, method, nodeParams, params) {
    for (let i = 0, len = node.#methods.length; i < len; i++) {
      const m = node.#methods[i];
      const handlerSet = m[method] || m[METHOD_NAME_ALL];
      const processedSet = {};
      if (handlerSet !== void 0) {
        handlerSet.params = /* @__PURE__ */ Object.create(null);
        handlerSets.push(handlerSet);
        if (nodeParams !== emptyParams || params && params !== emptyParams) {
          for (let i2 = 0, len2 = handlerSet.possibleKeys.length; i2 < len2; i2++) {
            const key = handlerSet.possibleKeys[i2];
            const processed = processedSet[handlerSet.score];
            handlerSet.params[key] = params?.[key] && !processed ? params[key] : nodeParams[key] ?? params?.[key];
            processedSet[handlerSet.score] = true;
          }
        }
      }
    }
  }
  search(method, path) {
    const handlerSets = [];
    this.#params = emptyParams;
    const curNode = this;
    let curNodes = [curNode];
    const parts = splitPath(path);
    const curNodesQueue = [];
    const len = parts.length;
    let partOffsets = null;
    for (let i = 0; i < len; i++) {
      const part = parts[i];
      const isLast = i === len - 1;
      const tempNodes = [];
      for (let j = 0, len2 = curNodes.length; j < len2; j++) {
        const node = curNodes[j];
        const nextNode = node.#children[part];
        if (nextNode) {
          nextNode.#params = node.#params;
          if (isLast) {
            if (nextNode.#children["*"]) {
              this.#pushHandlerSets(handlerSets, nextNode.#children["*"], method, node.#params);
            }
            this.#pushHandlerSets(handlerSets, nextNode, method, node.#params);
          } else {
            tempNodes.push(nextNode);
          }
        }
        for (let k = 0, len3 = node.#patterns.length; k < len3; k++) {
          const pattern = node.#patterns[k];
          const params = node.#params === emptyParams ? {} : { ...node.#params };
          if (pattern === "*") {
            const astNode = node.#children["*"];
            if (astNode) {
              this.#pushHandlerSets(handlerSets, astNode, method, node.#params);
              astNode.#params = params;
              tempNodes.push(astNode);
            }
            continue;
          }
          const [key, name, matcher] = pattern;
          if (!part && !(matcher instanceof RegExp)) {
            continue;
          }
          const child = node.#children[key];
          if (matcher instanceof RegExp) {
            if (partOffsets === null) {
              partOffsets = new Array(len);
              let offset = path[0] === "/" ? 1 : 0;
              for (let p = 0; p < len; p++) {
                partOffsets[p] = offset;
                offset += parts[p].length + 1;
              }
            }
            const restPathString = path.substring(partOffsets[i]);
            const m = matcher.exec(restPathString);
            if (m) {
              params[name] = m[0];
              this.#pushHandlerSets(handlerSets, child, method, node.#params, params);
              if (hasChildren(child.#children)) {
                child.#params = params;
                const componentCount = m[0].match(/\//)?.length ?? 0;
                const targetCurNodes = curNodesQueue[componentCount] ||= [];
                targetCurNodes.push(child);
              }
              continue;
            }
          }
          if (matcher === true || matcher.test(part)) {
            params[name] = part;
            if (isLast) {
              this.#pushHandlerSets(handlerSets, child, method, params, node.#params);
              if (child.#children["*"]) {
                this.#pushHandlerSets(
                  handlerSets,
                  child.#children["*"],
                  method,
                  params,
                  node.#params
                );
              }
            } else {
              child.#params = params;
              tempNodes.push(child);
            }
          }
        }
      }
      const shifted = curNodesQueue.shift();
      curNodes = shifted ? tempNodes.concat(shifted) : tempNodes;
    }
    if (handlerSets.length > 1) {
      handlerSets.sort((a, b) => {
        return a.score - b.score;
      });
    }
    return [handlerSets.map(({ handler, params }) => [handler, params])];
  }
};

// .stack/node_modules/hono/dist/router/trie-router/router.js
var TrieRouter = class {
  name = "TrieRouter";
  #node;
  constructor() {
    this.#node = new Node2();
  }
  add(method, path, handler) {
    const results = checkOptionalParameter(path);
    if (results) {
      for (let i = 0, len = results.length; i < len; i++) {
        this.#node.insert(method, results[i], handler);
      }
      return;
    }
    this.#node.insert(method, path, handler);
  }
  match(method, path) {
    return this.#node.search(method, path);
  }
};

// .stack/node_modules/hono/dist/hono.js
var Hono2 = class extends Hono {
  /**
   * Creates an instance of the Hono class.
   *
   * @param options - Optional configuration options for the Hono instance.
   */
  constructor(options = {}) {
    super(options);
    this.router = options.router ?? new SmartRouter({
      routers: [new RegExpRouter(), new TrieRouter()]
    });
  }
};

// server/command.mjs
var BY_STATUS = { 400: "BAD_INPUT", 403: "NOT_ALLOWED", 404: "NOT_FOUND", 424: "MISSING_KEYS", 502: "SITE_FAILED", 504: "SITE_TIMEOUT" };
var Refused = class extends Error {
  constructor(message, status = 409, extra = {}) {
    super(message);
    this.status = status;
    this.code = extra.code ?? (/^Only a person/.test(message) ? "PERSON_ONLY" : BY_STATUS[status] ?? "REFUSED");
    if (extra.item !== void 0) this.item = extra.item;
  }
};
var commandsOf = (app) => app.commands ??= [];
var inputNames = (input) => Array.isArray(input) ? input.flatMap((x) => typeof x === "string" ? [x] : Object.keys(x)) : Object.keys(input ?? {});
function command(app, method, path, spec, handler) {
  commandsOf(app).push({ ...spec, method, path, input: spec.input ?? {}, by: spec.by ?? "anyone", read: method === "GET" });
  app.on(method, path, async (c) => {
    const actor = c.req.header("x-actor") || "";
    if (spec.by === "person" && !actor.startsWith("person:")) throw new Refused(`Only a person can do this: ask them. (${spec.name})`, 403);
    const body = method === "GET" ? c.req.query() : await c.req.json().catch(() => ({}));
    const input = {};
    for (const k of inputNames(spec.input)) if (body[k] !== void 0) input[k] = body[k];
    for (const [k, v] of Object.entries(c.req.param())) input[k] = /^\d+$/.test(v) ? Number(v) : v;
    return c.json(await handler(input, { actor }) ?? { ok: true });
  });
}
function mountErrors(app) {
  app.onError((e, c) => c.json({ error: e.message, code: e.code ?? (e.status && e.status < 500 ? "REFUSED" : "FAILED"), ...e.item !== void 0 ? { item: e.item } : {} }, e.status ?? 500));
  app.get("/_commands", (c) => c.json(commandsOf(app)));
}

// server/services/util.mjs
var T = {
  settings: "crm_settings",
  companies: "crm_companies",
  contacts: "crm_contacts",
  deals: "crm_deals",
  activities: "crm_activities",
  tasks: "crm_tasks",
  drafts: "crm_drafts",
  leads: "crm_leads"
};
var LIVE = "_deleted = 0 AND COALESCE(removed, 0) = 0";
var isPerson = (actor) => String(actor || "").startsWith("person:");
var wantsFull = (i, actor) => isPerson(actor) || i.full === true || i.full === "true";
var who = (actor) => String(actor || "").replace(/^(person|agent|module|platform):/, "") || "agent";
var today = (now = /* @__PURE__ */ new Date(), tz = "Europe/Madrid") => {
  try {
    return new Intl.DateTimeFormat("sv-SE", { timeZone: tz }).format(now);
  } catch {
    return now.toISOString().slice(0, 10);
  }
};
var stamp = (d = /* @__PURE__ */ new Date()) => (d instanceof Date ? d : new Date(d)).toISOString().slice(0, 19).replace("T", " ");
var ISO = /^(\d{4})-(\d{2})-(\d{2})$/;
function dateOf(v, field = "date") {
  if (v === void 0 || v === null || v === "") return null;
  const s = String(v).trim();
  const dmy = /^(\d{1,2})[/.-](\d{1,2})[/.-](\d{4})$/.exec(s);
  const iso = dmy ? `${dmy[3]}-${dmy[2].padStart(2, "0")}-${dmy[1].padStart(2, "0")}` : s.slice(0, 10);
  const m = ISO.exec(iso);
  if (!m || Number(m[2]) < 1 || Number(m[2]) > 12 || Number(m[3]) < 1 || Number(m[3]) > 31) throw new Refused(`${field} is a date written YYYY-MM-DD (got "${s.slice(0, 30)}").`, 400, { code: "BAD_DATE" });
  return iso;
}
function momentOf(v, now = /* @__PURE__ */ new Date(), field = "at") {
  if (v === void 0 || v === null || v === "") return stamp(now);
  const s = String(v).trim();
  if (ISO.test(s.slice(0, 10)) && s.length <= 10) return `${dateOf(s, field)} 09:00:00`;
  const d = /* @__PURE__ */ new Date(s.replace(" ", "T") + (/[zZ]|[+-]\d{2}:?\d{2}$/.test(s) || s.length <= 10 ? "" : "Z"));
  if (Number.isNaN(d.getTime())) throw new Refused(`${field} is a date and time, like 2026-11-23T10:30:00Z (got "${s.slice(0, 30)}").`, 400, { code: "BAD_DATE" });
  return stamp(d);
}
var daysBetween = (from, to) => Math.round((Date.parse(String(to).slice(0, 10) + "T00:00:00Z") - Date.parse(String(from).slice(0, 10) + "T00:00:00Z")) / 864e5);
var text = (v, max = 4e3) => v === void 0 || v === null ? null : String(v).trim().slice(0, max) || null;
function int(v, field = "number") {
  if (v === void 0 || v === null || v === "") return null;
  const n = Number(v);
  if (!Number.isFinite(n)) throw new Refused(`${field} is a number (got "${String(v).slice(0, 30)}").`, 400, { code: "BAD_NUMBER" });
  return Math.round(n);
}
function euros(v, field = "amount") {
  if (v === void 0 || v === null || v === "") return null;
  const n = Number(typeof v === "string" ? v.replace(/\s|€|eur/gi, "").replace(/\.(?=\d{3}(\D|$))/g, "").replace(",", ".") : v);
  if (!Number.isFinite(n) || n < 0) throw new Refused(`${field} is an amount in euros, a number of 0 or more (got "${String(v).slice(0, 30)}").`, 400, { code: "BAD_NUMBER" });
  return Math.round(n * 100) / 100;
}
function listOf(v, name) {
  if (Array.isArray(v)) return v;
  if (typeof v === "string" && v.trim().startsWith("[")) {
    try {
      const j = JSON.parse(v);
      if (Array.isArray(j)) return j;
    } catch {
    }
  }
  throw new Refused(`${name} is a list: ${name}: [ \u2026 ].`, 400, { code: "BAD_INPUT" });
}
var said = (v) => String(v ?? "").trim().toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "").replace(/[_-]+/g, " ").replace(/\s+/g, " ");
var fold = said;
function choiceOf(v, words, field) {
  if (v === void 0 || v === null || v === "") return null;
  const k = said(v);
  for (const [key, list4] of Object.entries(words)) if (said(key) === k || list4.includes(k)) return key;
  throw new Refused(`${field} is one of: ${Object.keys(words).join(", ")} (got "${String(v).slice(0, 30)}").`, 400, { code: "BAD_CHOICE" });
}
var sent = (o) => Object.fromEntries(Object.entries(o).filter(([, v]) => v !== void 0));
var count = async (db, sql, params = []) => Number((await db.one(sql, params))?.n ?? 0);
var r2 = (n) => Math.round((Number(n) || 0) * 100) / 100;
var idOf = (v) => v === void 0 || v === null || v === "" ? null : Number.isFinite(Number(v)) ? Number(v) : null;

// server/services/core.mjs
var DEFAULT_STAGES = [
  { name: "Nuevo", probability: 10 },
  { name: "Calificado", probability: 25 },
  { name: "Reuni\xF3n", probability: 40 },
  { name: "Propuesta", probability: 60 },
  { name: "Negociaci\xF3n", probability: 80 },
  { name: "Ganado", probability: 100, outcome: "won" },
  { name: "Perdido", probability: 0, outcome: "lost" }
];
var LEGACY_STAGE_NAMES = { Lead: "Nuevo", Qualified: "Calificado", Meeting: "Reuni\xF3n", Proposal: "Propuesta", Negotiation: "Negociaci\xF3n", Won: "Ganado", Lost: "Perdido" };
var DEFAULT_KINDS = ["Consultor\xEDa", "Desarrollo"];
var DEFAULT_SOURCES = ["Web", "Formulario", "Reserva", "Recomendaci\xF3n", "Correo", "Evento", "Prospecci\xF3n"];
var RECURRING = { month: ["mes", "mensual", "monthly", "mo"], quarter: ["trimestre", "trimestral", "quarterly"], year: ["ano", "anual", "yearly", "annual"] };
var monthly = (amount, every) => !amount ? 0 : every === "year" ? amount / 12 : every === "quarter" ? amount / 3 : amount;
function stagesOf(value) {
  let list4 = value;
  if (typeof value === "string") {
    const s = value.trim();
    if (s.startsWith("[")) {
      try {
        list4 = JSON.parse(s);
      } catch {
        list4 = null;
      }
    } else if (s) list4 = linesToStages(s);
    else list4 = null;
  }
  if (!Array.isArray(list4) || !list4.length) list4 = DEFAULT_STAGES;
  const out = list4.filter((s) => s && String(s.name ?? "").trim()).map((s, i) => ({
    name: String(s.name).trim().slice(0, 40),
    probability: Math.max(0, Math.min(100, Math.round(Number(s.probability) || 0))),
    order: Number.isFinite(Number(s.order)) ? Number(s.order) : i + 1,
    outcome: s.outcome === "won" || s.outcome === "lost" ? s.outcome : null
  })).sort((a, b) => a.order - b.order);
  if (!out.some((s) => s.outcome === "won")) out.push({ name: "Ganado", probability: 100, order: 98, outcome: "won" });
  if (!out.some((s) => s.outcome === "lost")) out.push({ name: "Perdido", probability: 0, order: 99, outcome: "lost" });
  return out.map((s, i) => ({ ...s, order: i + 1 }));
}
function linesToStages(s) {
  return s.split(/\n+/).map((l) => l.trim()).filter(Boolean).map((l) => {
    const m = /^(.*?)(?:\s*[·:-]?\s*(\d{1,3})\s*%?)?(?:\s*[·:-]?\s*\(?(ganado|perdido|won|lost)\)?)?\s*$/i.exec(l);
    const o = (m[3] || "").toLowerCase();
    return { name: m[1].trim() || l, probability: m[2] !== void 0 ? Number(m[2]) : o === "ganado" || o === "won" ? 100 : 0, outcome: o === "ganado" || o === "won" ? "won" : o === "perdido" || o === "lost" ? "lost" : null };
  });
}
var stagesText = (stages) => stagesOf(stages).map((s) => `${s.name} ${s.probability}%${s.outcome === "won" ? " ganado" : s.outcome === "lost" ? " perdido" : ""}`).join("\n");
var openStages = (stages) => stagesOf(stages).filter((s) => !s.outcome);
var outcomeStage = (stages, kind) => stagesOf(stages).find((s) => s.outcome === kind);
var stageNamed = (stages, name) => stagesOf(stages).find((s) => fold(s.name) === fold(name)) ?? null;
var linesOf = (v) => String(v ?? "").split(/[\n,]+/).map((x) => x.trim()).filter(Boolean);
var FREE = /* @__PURE__ */ new Set(["gmail.com", "googlemail.com", "hotmail.com", "hotmail.es", "outlook.com", "outlook.es", "live.com", "msn.com", "yahoo.com", "yahoo.es", "ymail.com", "icloud.com", "me.com", "mac.com", "aol.com", "proton.me", "protonmail.com", "gmx.com", "gmx.es", "mail.com", "zoho.com", "yandex.com", "telefonica.net", "movistar.es", "orange.es", "hey.com", "fastmail.com", "pm.me"]);
var EMAIL = /^[^\s@<>(),;:"]+@[^\s@<>(),;:"]+\.[a-z]{2,}$/i;
var normEmail = (v) => String(v ?? "").trim().toLowerCase();
var isEmail = (v) => EMAIL.test(normEmail(v));
var domainOf = (email) => isEmail(email) ? normEmail(email).split("@")[1] : "";
var isFree = (domain) => FREE.has(String(domain ?? "").toLowerCase());
function siteDomain(v) {
  const s = String(v ?? "").trim().toLowerCase();
  if (!s) return "";
  const host = s.replace(/^[a-z]+:\/\//, "").split(/[/?#]/)[0].replace(/^www\./, "");
  return /^[a-z0-9.-]+\.[a-z]{2,}$/.test(host) ? host : "";
}
var companyDomainOf = (email) => {
  const d = domainOf(email);
  return d && !isFree(d) ? d : "";
};
var DEFAULTS = { stages: JSON.stringify(DEFAULT_STAGES), kinds: DEFAULT_KINDS.join("\n"), sources: DEFAULT_SOURCES.join("\n"), currency: "EUR", timezone: "Europe/Madrid", stuck_days: 14, signature: "" };
async function settingsRow(db) {
  const row2 = await db.one(`SELECT * FROM ${T.settings} WHERE _deleted = 0 ORDER BY _id LIMIT 1`);
  const v = (k) => row2 && row2[k] !== null && row2[k] !== void 0 && row2[k] !== "" ? row2[k] : DEFAULTS[k];
  return {
    id: row2?._id ?? null,
    row: row2,
    stages: stagesOf(v("stages")),
    kinds: linesOf(v("kinds")),
    sources: linesOf(v("sources")),
    currency: v("currency"),
    timezone: v("timezone"),
    stuck_days: Math.max(1, Number(v("stuck_days")) || 14),
    signature: v("signature") || ""
  };
}
async function settings(db) {
  const s = await settingsRow(db);
  return { id: s.id, stages: stagesText(s.stages), kinds: s.kinds.join("\n"), sources: s.sources.join("\n"), currency: s.currency, stuck_days: s.stuck_days, signature: s.signature };
}
async function setSettings(db, i) {
  const d = sent({
    stages: i.stages === void 0 ? void 0 : JSON.stringify(stagesOf(Array.isArray(i.stages) ? i.stages : String(i.stages))),
    kinds: i.kinds === void 0 ? void 0 : linesOf(Array.isArray(i.kinds) ? i.kinds.join("\n") : i.kinds).join("\n"),
    sources: i.sources === void 0 ? void 0 : linesOf(Array.isArray(i.sources) ? i.sources.join("\n") : i.sources).join("\n"),
    currency: i.currency === void 0 ? void 0 : (text(i.currency, 3) || "EUR").toUpperCase(),
    stuck_days: i.stuck_days === void 0 ? void 0 : int(i.stuck_days, "stuck_days"),
    signature: i.signature === void 0 ? void 0 : text(i.signature, 1e3) ?? ""
  });
  if (d.stages && !openStages(d.stages).length) throw new Refused("The stages need at least one that is not an outcome (ganado / perdido): a deal has to be somewhere while it is open.", 400, { code: "NO_OPEN_STAGE" });
  if (d.stuck_days !== void 0 && (d.stuck_days < 1 || d.stuck_days > 365)) throw new Refused("stuck_days is between 1 and 365: the days without news after which an open deal reads \xABparado\xBB.", 400, { code: "BAD_NUMBER" });
  if (d.stages) await renameStages(db, (await settingsRow(db)).stages, stagesOf(d.stages));
  const row2 = await db.one(`SELECT _id FROM ${T.settings} WHERE _deleted = 0 ORDER BY _id LIMIT 1`);
  if (row2) {
    if (Object.keys(d).length) await db.update(T.settings, row2._id, d);
  } else await db.insert(T.settings, { ...DEFAULTS, ...d });
  return settings(db);
}
async function renameStages(db, before, after) {
  const names = new Set(after.map((s) => s.name));
  const firstOpen = after.find((s) => !s.outcome)?.name;
  for (const [k, s] of before.entries()) {
    if (names.has(s.name)) continue;
    const same = after[k] && !names.has(before[k]?.name) && after[k].outcome === s.outcome ? after[k].name : s.outcome ? after.find((x) => x.outcome === s.outcome)?.name : firstOpen;
    if (!same) continue;
    for (const d of await db.all(`SELECT _id FROM ${T.deals} WHERE ${LIVE} AND stage = ?`, [s.name])) await db.update(T.deals, d._id, { stage: same });
  }
}

// server/services/upgrade.mjs
var VERSION = "0.4.0";
function upgradePlan(row2) {
  if (!row2) return null;
  if (row2.installed_version === VERSION) return null;
  const plan = { rename: {}, data: { installed_version: VERSION } };
  const stages = stagesOf(row2.stages);
  const legacy = stages.length === 7 && stages.every((s) => LEGACY_STAGE_NAMES[s.name]);
  if (legacy) {
    plan.rename = Object.fromEntries(stages.map((s) => [s.name, LEGACY_STAGE_NAMES[s.name]]));
    plan.data.stages = JSON.stringify(stages.map((s) => ({ name: LEGACY_STAGE_NAMES[s.name], probability: s.probability, outcome: s.outcome ?? void 0 })));
  }
  if (!row2.kinds) plan.data.kinds = DEFAULTS.kinds;
  if (!row2.sources || /HubSpot|Outbound/.test(row2.sources)) plan.data.sources = DEFAULTS.sources;
  return plan;
}
var runs = /* @__PURE__ */ new WeakMap();
function ensureUpgraded(db) {
  if (runs.has(db)) return runs.get(db);
  const done2 = (async () => {
    const row2 = await db.one(`SELECT * FROM ${T.settings} WHERE _deleted = 0 ORDER BY _id LIMIT 1`);
    const plan = upgradePlan(row2);
    if (!plan) return;
    for (const [from, to] of Object.entries(plan.rename)) {
      for (const d of await db.all(`SELECT _id FROM ${T.deals} WHERE ${LIVE} AND stage = ?`, [from])) await db.update(T.deals, d._id, { stage: to });
    }
    await db.update(T.settings, row2._id, plan.data);
  })().catch((e) => {
    runs.delete(db);
    throw e;
  });
  runs.set(db, done2);
  return done2;
}

// server/services/people.mjs
var CONTACT_STATUS = { Lead: ["lead", "nuevo", "potencial"], Contacted: ["contacted", "contactado"], Customer: ["customer", "cliente"], Lost: ["lost", "perdido"], Suggested: ["suggested", "sugerido"], Ignored: ["ignored", "ignorado"] };
var COMPANY_FIELDS = ["name", "domain", "website", "industry", "size", "location", "linkedin", "summary", "tax_id", "address", "phone", "notes", "source", "owner"];
var CONTACT_FIELDS = ["name", "email", "phone", "title", "linkedin", "notes", "source", "owner"];
var taxKey = (v) => String(v ?? "").toUpperCase().replace(/[^A-Z0-9]/g, "").replace(/^ES(?=[A-Z0-9]{9}$)/, "");
async function matchCompany(db, i) {
  const tax = taxKey(i.tax_id);
  const name = text(i.company ?? i.company_name ?? i.name, 200);
  const domain = siteDomain(i.website ?? i.domain) || companyDomainOf(i.email);
  const rows2 = await db.all(`SELECT _id, name, tax_id, domain FROM ${T.companies} WHERE ${LIVE}`);
  if (tax) {
    const r = rows2.find((c) => taxKey(c.tax_id) === tax);
    if (r) return { id: r._id, by: "tax_id", name: r.name };
  }
  if (domain) {
    const r = rows2.find((c) => String(c.domain || "").toLowerCase() === domain);
    if (r) return { id: r._id, by: "domain", name: r.name };
  }
  if (name) {
    const r = rows2.find((c) => fold(c.name) === fold(name));
    if (r) return { id: r._id, by: "name", name: r.name };
  }
  return null;
}
async function liveId(db, table, id, what) {
  let row2 = await db.one(`SELECT _id, removed, merged_into FROM ${table} WHERE _deleted = 0 AND _id = ?`, [id]);
  for (let k = 0; row2 && row2.merged_into && k < 5; k += 1) row2 = await db.one(`SELECT _id, removed, merged_into FROM ${table} WHERE _deleted = 0 AND _id = ?`, [row2.merged_into]);
  if (!row2) throw new Refused(`There is no ${what} ${id}. ${what === "company" ? "companies" : "contacts"} lists them.`, 404, { code: "NOT_FOUND", item: id });
  if (Number(row2.removed)) throw new Refused(`That ${what} is archived. Restore it first (${what === "company" ? "companies_save" : "contacts_save"} { id, remove: false }), or use another.`, 409, { code: "ARCHIVED", item: row2._id });
  return row2._id;
}
async function companyRef(db, i, { make = false, source = null } = {}) {
  const id = idOf(i.company_id);
  if (id) return liveId(db, T.companies, id, "company");
  const m = await matchCompany(db, i);
  if (m) return m.id;
  const name = text(i.company ?? i.company_name, 200);
  if (!make || !name) return null;
  const domain = siteDomain(i.website ?? i.domain) || companyDomainOf(i.email);
  return db.insert(T.companies, { name, domain: domain || null, website: text(i.website, 300), tax_id: text(i.tax_id, 40), source: text(source ?? i.source, 60) });
}
async function contactRef(db, i, { make = false, company_id = null, source = null } = {}) {
  const id = idOf(i.contact_id);
  if (id) return liveId(db, T.contacts, id, "person");
  const email = isEmail(i.email) ? normEmail(i.email) : null;
  const name = text(i.contact ?? i.contact_name ?? i.name, 200);
  if (email) {
    const r = await db.one(`SELECT _id FROM ${T.contacts} WHERE ${LIVE} AND lower(email) = ?`, [email]);
    if (r) return r._id;
  }
  if (name) {
    const rows2 = await db.all(`SELECT _id, name, company_id FROM ${T.contacts} WHERE ${LIVE}`);
    const same = rows2.find((c) => fold(c.name) === fold(name) && (!company_id || !c.company_id || c.company_id === company_id));
    if (same) return same._id;
  }
  if (!make || !email && !name) return null;
  return db.insert(T.contacts, { name: name || email, email, phone: text(i.phone, 40), title: text(i.title, 120), company_id, status: "Lead", source: text(source ?? i.source, 60) });
}
async function companies(db, i, full) {
  const q = text(i.q, 80);
  const rows2 = await db.all(`SELECT c._id AS id, c.name, c.domain, c.website, c.industry, c.location, c.summary,
      (SELECT COUNT(*) FROM ${T.contacts} p WHERE p._deleted = 0 AND COALESCE(p.removed,0) = 0 AND p.company_id = c._id AND COALESCE(p.status,'') NOT IN ('Suggested','Ignored')) AS people,
      (SELECT COUNT(*) FROM ${T.deals} d WHERE d._deleted = 0 AND COALESCE(d.removed,0) = 0 AND d.company_id = c._id AND d.status = 'Open') AS open_deals,
      (SELECT COALESCE(SUM(d.amount),0) FROM ${T.deals} d WHERE d._deleted = 0 AND COALESCE(d.removed,0) = 0 AND d.company_id = c._id AND d.status = 'Open') AS open_value,
      (SELECT COALESCE(SUM(d.amount),0) FROM ${T.deals} d WHERE d._deleted = 0 AND COALESCE(d.removed,0) = 0 AND d.company_id = c._id AND d.status = 'Won') AS won_value,
      (SELECT MAX(a.at) FROM ${T.activities} a WHERE a._deleted = 0 AND COALESCE(a.removed,0) = 0 AND a.type <> 'stage' AND (a.company_id = c._id OR a.contact_id IN (SELECT p._id FROM ${T.contacts} p WHERE p.company_id = c._id))) AS last_at
    FROM ${T.companies} c WHERE c._deleted = 0 AND COALESCE(c.removed,0) = 0
    ${q ? "AND (lower(c.name) LIKE ? OR lower(COALESCE(c.domain,'')) LIKE ? OR lower(COALESCE(c.industry,'')) LIKE ?)" : ""}
    ORDER BY (open_deals > 0) DESC, COALESCE(last_at, c._updated_at) DESC`, q ? Array(3).fill(`%${q.toLowerCase()}%`) : []);
  const total = rows2.length;
  const limit = full ? 500 : Math.min(Number(i.limit) || 15, 100);
  const offset = Number(i.offset) || 0;
  const page = rows2.slice(offset, offset + limit).map((r) => full ? r : sent({ id: r.id, name: r.name, domain: r.domain || void 0, people: r.people, open_deals: r.open_deals || void 0, open_value: r.open_value || void 0, won_value: r.won_value || void 0, last_at: r.last_at ? r.last_at.slice(0, 10) : void 0 }));
  return { total, rows: page, ...offset + limit < total ? { more: `${total - offset - limit} more: offset ${offset + limit}` } : {} };
}
async function contacts(db, i, full) {
  const q = text(i.q, 80);
  const where = [`p._deleted = 0`, `COALESCE(p.removed,0) = 0`];
  const args = [];
  if (i.company_id) {
    where.push("p.company_id = ?");
    args.push(idOf(i.company_id));
  }
  if (i.status) {
    where.push("p.status = ?");
    args.push(i.status);
  } else where.push(`COALESCE(p.status,'') NOT IN ('Suggested','Ignored')`);
  if (q) {
    where.push(`(lower(p.name) LIKE ? OR lower(COALESCE(p.email,'')) LIKE ?)`);
    args.push(`%${q.toLowerCase()}%`, `%${q.toLowerCase()}%`);
  }
  const rows2 = await db.all(`SELECT p._id AS id, p.name, p.email, p.phone, p.title, p.status, p.company_id, c.name AS company, p.last_activity_at, p.suggested_why
    FROM ${T.contacts} p LEFT JOIN ${T.companies} c ON c._id = p.company_id WHERE ${where.join(" AND ")} ORDER BY COALESCE(p.last_activity_at, p._updated_at) DESC`, args);
  const limit = full ? 500 : Math.min(Number(i.limit) || 15, 100);
  const offset = Number(i.offset) || 0;
  return { total: rows2.length, rows: rows2.slice(offset, offset + limit).map((r) => full ? r : sent({ id: r.id, name: r.name, email: r.email || void 0, company: r.company || void 0, title: r.title || void 0 })), ...offset + limit < rows2.length ? { more: `${rows2.length - offset - limit} more: offset ${offset + limit}` } : {} };
}
async function saveCompanies(db, i) {
  const out = { added: [], changed: [], matched: [], archived: [], skipped: [] };
  for (const [k, item] of listOf(i.items, "items").entries()) {
    try {
      const data = sent(Object.fromEntries(COMPANY_FIELDS.map((f) => [f, item[f] === void 0 ? void 0 : text(item[f], f === "summary" || f === "notes" ? 4e3 : 300)])));
      if (data.website && !data.domain) data.domain = siteDomain(data.website) || void 0;
      if (data.domain) data.domain = siteDomain(data.domain) || data.domain.toLowerCase();
      if (data.tax_id) data.tax_id = taxKey(data.tax_id) || data.tax_id;
      const match2 = idOf(item.id) ? null : await matchCompany(db, { name: item.name, website: item.website, domain: item.domain, tax_id: item.tax_id });
      const id = idOf(item.id) ?? match2?.id ?? null;
      if (match2) out.matched.push({ index: k, id: match2.id, by: match2.by, name: match2.name });
      if (id) {
        const row2 = await db.one(`SELECT _id, removed, merged_into FROM ${T.companies} WHERE _deleted = 0 AND _id = ?`, [id]);
        if (!row2 || row2.merged_into) throw new Refused(row2 ? `Company ${id} was merged into ${row2.merged_into}: change that one.` : `No company ${id}.`, row2 ? 409 : 404, { code: row2 ? "MERGED" : "NOT_FOUND", item: row2?.merged_into ?? id });
        if (item.remove === true) {
          if (await count(db, `SELECT COUNT(*) AS n FROM ${T.deals} WHERE ${LIVE} AND company_id = ? AND status = 'Open'`, [id])) throw new Refused("It has open deals: close or move them first, so nothing open is left without a client.", 409, { code: "HAS_OPEN_DEALS" });
          await db.update(T.companies, id, { removed: 1 });
          out.archived.push(id);
          continue;
        }
        if (item.remove === false && Number(row2.removed)) data.removed = 0;
        else if (Number(row2.removed)) throw new Refused(`Company ${id} is archived: restore it with remove: false.`, 409, { code: "ARCHIVED", item: id });
        if (match2) {
          const have = await db.one(`SELECT * FROM ${T.companies} WHERE _id = ?`, [id]);
          for (const f of Object.keys(data)) if (have[f] !== null && have[f] !== void 0 && have[f] !== "") delete data[f];
        }
        if (Object.keys(data).length) await db.update(T.companies, id, data);
        out.changed.push(id);
      } else {
        if (!data.name) throw new Refused("A new company needs its name.", 400, { code: "BAD_INPUT" });
        out.added.push(await db.insert(T.companies, data));
      }
    } catch (e) {
      if (!(e instanceof Refused)) throw e;
      out.skipped.push({ index: k, code: e.code, error: e.message });
    }
  }
  return out;
}
async function saveContacts(db, i) {
  const out = { added: [], changed: [], matched: [], archived: [], skipped: [] };
  for (const [k, item] of listOf(i.items, "items").entries()) {
    try {
      const data = sent(Object.fromEntries(CONTACT_FIELDS.map((f) => [f, item[f] === void 0 ? void 0 : text(item[f], f === "notes" ? 4e3 : 300)])));
      if (data.email !== void 0) {
        if (data.email && !isEmail(data.email)) throw new Refused(`${data.email} is not an email address.`, 400, { code: "BAD_EMAIL" });
        data.email = data.email ? normEmail(data.email) : null;
      }
      if (item.status !== void 0) data.status = choiceOf(item.status, CONTACT_STATUS, "status");
      if (item.company_id !== void 0 || item.company !== void 0) data.company_id = item.company_id === null || item.company === null ? null : await companyRef(db, { company_id: item.company_id, company: item.company, email: item.email }, { make: true });
      const found = idOf(item.id) ? null : item.email || item.name ? await contactRef(db, { email: item.email, name: item.name }, { company_id: data.company_id }) : null;
      const id = idOf(item.id) ?? found;
      if (found) out.matched.push({ index: k, id: found, by: item.email && isEmail(item.email) && await db.one(`SELECT _id FROM ${T.contacts} WHERE _id = ? AND lower(email) = ?`, [found, normEmail(item.email)]) ? "email" : "name" });
      if (id) {
        const row2 = await db.one(`SELECT _id, removed, merged_into FROM ${T.contacts} WHERE _deleted = 0 AND _id = ?`, [id]);
        if (!row2 || row2.merged_into) throw new Refused(row2 ? `Person ${id} was merged into ${row2.merged_into}: change that one.` : `No person ${id}.`, row2 ? 409 : 404, { code: row2 ? "MERGED" : "NOT_FOUND", item: row2?.merged_into ?? id });
        if (item.remove === true) {
          await db.update(T.contacts, id, { removed: 1 });
          out.archived.push(id);
          continue;
        }
        if (item.remove === false && Number(row2.removed)) data.removed = 0;
        else if (Number(row2.removed)) throw new Refused(`Person ${id} is archived: restore them with remove: false.`, 409, { code: "ARCHIVED", item: id });
        if (found) {
          const have = await db.one(`SELECT * FROM ${T.contacts} WHERE _id = ?`, [id]);
          for (const f of Object.keys(data)) if (f !== "status" && have[f] !== null && have[f] !== void 0 && have[f] !== "") delete data[f];
        }
        if (Object.keys(data).length) await db.update(T.contacts, id, data);
        out.changed.push(id);
      } else {
        if (!data.name && !data.email) throw new Refused("A new person needs a name or an email.", 400, { code: "BAD_INPUT" });
        if (data.company_id === void 0 && data.email) data.company_id = await companyRef(db, { email: data.email });
        out.added.push(await db.insert(T.contacts, { status: "Contacted", ...data, name: data.name || data.email }));
      }
    } catch (e) {
      if (!(e instanceof Refused)) throw e;
      out.skipped.push({ index: k, code: e.code, error: e.message });
    }
  }
  return out;
}
async function merge(db, kind, i) {
  const table = kind === "company" ? T.companies : T.contacts;
  const keep = idOf(i.keep);
  const drop2 = idOf(i.drop);
  if (!keep || !drop2 || keep === drop2) throw new Refused("Name the two: keep (the one that stays) and drop (the duplicate), different ids.", 400, { code: "BAD_INPUT" });
  const a = await db.one(`SELECT * FROM ${table} WHERE ${LIVE} AND _id = ?`, [keep]);
  const b = await db.one(`SELECT * FROM ${table} WHERE _deleted = 0 AND _id = ? AND merged_into IS NULL`, [drop2]);
  if (!a || !b) throw new Refused(`${!a ? `keep ${keep}` : `drop ${drop2}`} is not a ${kind === "company" ? "company" : "person"} that can be merged (missing, archived or merged already).`, 404, { code: "NOT_FOUND", item: !a ? keep : drop2 });
  const col = kind === "company" ? "company_id" : "contact_id";
  const moved = {};
  const repoint = kind === "company" ? [T.deals, T.contacts, T.activities, T.leads] : [T.deals, T.activities, T.leads, T.tasks, T.drafts];
  for (const t of repoint) {
    const rows2 = await db.all(`SELECT _id FROM ${t} WHERE _deleted = 0 AND ${col} = ?`, [drop2]);
    for (const r of rows2) await db.update(t, r._id, { [col]: keep });
    moved[t.replace("crm_", "")] = rows2.length;
  }
  const fields = kind === "company" ? COMPANY_FIELDS : [...CONTACT_FIELDS, "company_id"];
  const fill = Object.fromEntries(fields.filter((f) => (a[f] === null || a[f] === void 0 || a[f] === "") && b[f] !== null && b[f] !== void 0 && b[f] !== "").map((f) => [f, b[f]]));
  if (kind === "company" && a.notes && b.notes) fill.notes = `${a.notes}

${b.notes}`.slice(0, 4e3);
  if (Object.keys(fill).length) await db.update(table, keep, fill);
  await db.update(table, drop2, { removed: 1, merged_into: keep });
  return { keep, drop: drop2, moved, filled: Object.keys(fill) };
}
async function reference(db, i) {
  const one3 = async (table, id) => {
    let row2 = await db.one(`SELECT * FROM ${table} WHERE _deleted = 0 AND _id = ?`, [id]);
    const from = row2?.merged_into ? id : void 0;
    for (let k = 0; row2 && row2.merged_into && k < 5; k += 1) row2 = await db.one(`SELECT * FROM ${table} WHERE _deleted = 0 AND _id = ?`, [row2.merged_into]);
    return row2 ? { row: row2, from } : null;
  };
  const company = async (id) => {
    const r = await one3(T.companies, id);
    if (!r) return null;
    const c = r.row;
    const p = await db.one(`SELECT name, email, phone FROM ${T.contacts} WHERE ${LIVE} AND company_id = ? AND COALESCE(status,'') NOT IN ('Suggested','Ignored') ORDER BY last_activity_at DESC LIMIT 1`, [c._id]);
    return sent({ kind: "company", id: c._id, name: c.name, display: c.name, tax_id: c.tax_id || void 0, address: c.address || void 0, email: p?.email || void 0, phone: c.phone || p?.phone || void 0, contact: p?.name || void 0, website: c.website || void 0, archived: Number(c.removed) ? true : void 0, merged_from: r.from });
  };
  if (i.company_id) return await company(idOf(i.company_id)) ?? notFound("company", i.company_id);
  if (i.contact_id) {
    const r = await one3(T.contacts, idOf(i.contact_id));
    if (!r) return notFound("person", i.contact_id);
    const p = r.row;
    const co = p.company_id ? await company(p.company_id) : null;
    return sent({ kind: "person", id: p._id, name: p.name, display: co ? `${p.name} \xB7 ${co.name}` : p.name, email: p.email || void 0, phone: p.phone || void 0, title: p.title || void 0, company: co ?? void 0, archived: Number(p.removed) ? true : void 0, merged_from: r.from });
  }
  throw new Refused("Say which: company_id or contact_id.", 400, { code: "BAD_INPUT" });
}
var notFound = (what, id) => {
  throw new Refused(`There is no ${what} ${id} in the CRM.`, 404, { code: "NOT_FOUND", item: idOf(id) });
};

// server/services/timeline.mjs
var TYPES = { email_in: ["email in", "received", "recibido"], email_out: ["email out", "sent", "enviado"], meeting: ["reunion", "meeting", "llamada de video"], call: ["llamada", "phone"], note: ["nota"], form: ["formulario", "lead", "entrada"], stage: ["etapa"], task: ["paso"] };
var SUMMARY_MAX = 1500;
async function placeOf(db, item) {
  let deal_id = idOf(item.deal_id);
  let contact_id = null;
  let company_id = null;
  if (deal_id) {
    const d = await db.one(`SELECT _id, company_id, contact_id FROM ${T.deals} WHERE ${LIVE} AND _id = ?`, [deal_id]);
    if (!d) throw new Refused(`There is no deal ${deal_id}. deals lists them.`, 404, { code: "NOT_FOUND", item: deal_id });
    company_id = d.company_id;
    contact_id = d.contact_id;
  }
  if (item.contact_id || item.email) {
    contact_id = await contactRef(db, { contact_id: item.contact_id, email: item.email, name: item.name }, { make: !!item.email && item.make_contact === true });
    if (!contact_id && item.contact_id) throw new Refused(`No person ${item.contact_id}.`, 404, { code: "NOT_FOUND" });
  }
  if (item.company_id) company_id = await companyRef(db, { company_id: item.company_id });
  if (contact_id && !company_id) company_id = (await db.one(`SELECT company_id FROM ${T.contacts} WHERE _id = ?`, [contact_id]))?.company_id ?? null;
  if (!deal_id && !contact_id && !company_id) throw new Refused("Say whose it is: deal_id, contact_id, company_id, or the email of a person already in the CRM.", 400, { code: "NO_PLACE" });
  return { deal_id, contact_id, company_id };
}
async function add(db, i, actor, now) {
  const out = { added: [], already: 0, skipped: [] };
  for (const [k, item] of listOf(i.items, "items").entries()) {
    try {
      const type = choiceOf(item.type ?? "note", TYPES, "type");
      const external_id = text(item.external_id, 200);
      if (external_id && await db.one(`SELECT _id FROM ${T.activities} WHERE _deleted = 0 AND external_id = ?`, [external_id])) {
        out.already += 1;
        continue;
      }
      const place = await placeOf(db, item);
      const summary = text(item.summary ?? item.text, SUMMARY_MAX);
      const subject = text(item.subject, 200);
      if (!summary && !subject) throw new Refused("An entry needs a subject or a summary: what happened, in a line or a few.", 400, { code: "BAD_INPUT" });
      const at = momentOf(item.at, now);
      const id = await db.insert(T.activities, { type, ...place, at, subject, summary, external_id, source: text(item.source, 60), author: who(actor) });
      if (place.contact_id && type !== "stage") await touch(db, place.contact_id, at);
      out.added.push(id);
    } catch (e) {
      if (!(e instanceof Refused)) throw e;
      out.skipped.push({ index: k, code: e.code, error: e.message });
    }
  }
  return out;
}
async function note(db, place, type, subject, summary, actor, now = /* @__PURE__ */ new Date(), at = null) {
  return db.insert(T.activities, { type, deal_id: place.deal_id ?? null, contact_id: place.contact_id ?? null, company_id: place.company_id ?? null, at: at ?? stamp(now), subject: text(subject, 200), summary: text(summary, SUMMARY_MAX), author: who(actor) });
}
async function touch(db, contactId, at) {
  const c = await db.one(`SELECT last_activity_at FROM ${T.contacts} WHERE _id = ?`, [contactId]);
  if (c && (!c.last_activity_at || c.last_activity_at < at)) await db.update(T.contacts, contactId, { last_activity_at: at });
}
async function list(db, i, full) {
  const deal = idOf(i.deal_id);
  const company = idOf(i.company_id);
  const contact = idOf(i.contact_id);
  let where;
  let args;
  if (deal) {
    const d = await db.one(`SELECT contact_id FROM ${T.deals} WHERE _id = ?`, [deal]);
    where = `(deal_id = ? OR (deal_id IS NULL AND contact_id = ? AND type IN ('email_in','email_out','meeting','call')))`;
    args = [deal, d?.contact_id ?? -1];
  } else if (company) {
    where = `(company_id = ? OR contact_id IN (SELECT _id FROM ${T.contacts} WHERE company_id = ?) OR deal_id IN (SELECT _id FROM ${T.deals} WHERE company_id = ?))`;
    args = [company, company, company];
  } else if (contact) {
    where = `(contact_id = ? OR deal_id IN (SELECT _id FROM ${T.deals} WHERE contact_id = ?))`;
    args = [contact, contact];
  } else throw new Refused("Say whose timeline: deal_id, company_id or contact_id.", 400, { code: "NO_PLACE" });
  const limit = full ? 300 : Math.min(Number(i.limit) || 10, 50);
  const rows2 = await db.all(`SELECT _id AS id, type, at, subject, summary, deal_id, contact_id, company_id, author FROM ${T.activities} WHERE ${LIVE} AND ${where} ORDER BY at DESC, _id DESC LIMIT ?`, [...args, limit + 1]);
  const more = rows2.length > limit;
  return { rows: rows2.slice(0, limit).map((r) => full ? r : { id: r.id, type: r.type, at: String(r.at).slice(0, 16), subject: r.subject || void 0, gist: r.summary ? String(r.summary).split("\n")[0].slice(0, 160) : void 0 }), ...more ? { more: `older entries: limit ${limit + 20}` } : {} };
}
async function remove(db, i) {
  const a = await db.one(`SELECT _id, type FROM ${T.activities} WHERE ${LIVE} AND _id = ?`, [idOf(i.id)]);
  if (!a) throw new Refused(`There is no timeline entry ${i.id}.`, 404, { code: "NOT_FOUND" });
  if (a.type === "stage") throw new Refused("A stage move is the deal's history and stays. To change the stage, move the deal.", 409, { code: "HISTORY" });
  await db.update(T.activities, a._id, { removed: 1 });
  return { removed: a._id };
}

// server/services/deals.mjs
var STATUS = { Open: ["open", "abierto"], Won: ["won", "ganado"], Lost: ["lost", "perdido"] };
async function rows(db, where, args, now = /* @__PURE__ */ new Date(), s = null) {
  s ??= await settingsRow(db);
  const list4 = await db.all(`SELECT d._id AS id, d.title, d.stage, d.status, d.kind, d.amount, d.recurring_amount, d.recurring_every, d.currency, d.expected_close,
      d.next_step, d.next_step_due, d.stage_changed_at, d.closed_at, d.lost_reason, d.source, d.owner, d.notes, d.quote_ref, d.quote_state, d.quote_total, d.project_ref, d._created_at AS created_at,
      d.company_id, c.name AS company, d.contact_id, p.name AS contact, p.email AS contact_email,
      (SELECT MAX(a.at) FROM ${T.activities} a WHERE a._deleted = 0 AND COALESCE(a.removed,0) = 0 AND a.type NOT IN ('stage') AND (a.deal_id = d._id OR (d.contact_id IS NOT NULL AND a.contact_id = d.contact_id))) AS last_at,
      (SELECT COUNT(*) FROM ${T.tasks} t WHERE t._deleted = 0 AND t.deal_id = d._id AND t.status = 'Suggested') AS proposed
    FROM ${T.deals} d LEFT JOIN ${T.companies} c ON c._id = d.company_id LEFT JOIN ${T.contacts} p ON p._id = d.contact_id
    WHERE d._deleted = 0 AND COALESCE(d.removed,0) = 0 ${where ? "AND " + where : ""}`, args);
  const day = today(now, s.timezone);
  const order = new Map(s.stages.map((x, k) => [x.name, k]));
  return list4.map((d) => {
    const since = [d.last_at, d.stage_changed_at, d.created_at].filter(Boolean).sort().pop();
    const quiet = since ? daysBetween(since, day) : 0;
    const late = !!(d.next_step_due && d.next_step_due < day && d.status === "Open");
    return { ...d, quiet_days: Math.max(0, quiet), stuck: d.status === "Open" && quiet >= s.stuck_days, late, monthly: r2(monthly(d.recurring_amount, d.recurring_every)), stage_order: order.get(d.stage) ?? 99, probability: s.stages.find((x) => x.name === d.stage)?.probability ?? 0 };
  });
}
var brief = (d) => sent({ id: d.id, title: d.title, company: d.company || void 0, stage: d.stage, kind: d.kind || void 0, amount: d.amount || void 0, recurring: d.recurring_amount ? `${d.recurring_amount}/${d.recurring_every || "month"}` : void 0, next_step: d.next_step || void 0, due: d.next_step_due || void 0, stuck: d.stuck || void 0, late: d.late || void 0, status: d.status === "Open" ? void 0 : d.status });
async function list2(db, i, full, now) {
  const s = await settingsRow(db);
  const where = [];
  const args = [];
  const status = i.status === "all" ? null : choiceOf(i.status ?? "open", STATUS, "status");
  if (status) {
    where.push("d.status = ?");
    args.push(status);
  }
  if (i.stage) {
    const st = stageNamed(s.stages, i.stage);
    if (!st) throw new Refused(`There is no stage \xAB${i.stage}\xBB. The stages: ${s.stages.map((x) => x.name).join(", ")}.`, 400, { code: "BAD_STAGE" });
    where.push("d.stage = ?");
    args.push(st.name);
  }
  if (i.kind) {
    where.push("lower(d.kind) = ?");
    args.push(String(i.kind).toLowerCase());
  }
  if (i.company_id) {
    where.push("d.company_id = ?");
    args.push(idOf(i.company_id));
  }
  if (i.contact_id) {
    where.push("d.contact_id = ?");
    args.push(idOf(i.contact_id));
  }
  if (i.q) {
    where.push(`(lower(d.title) LIKE ? OR lower(COALESCE(c.name,'')) LIKE ?)`);
    args.push(`%${String(i.q).toLowerCase()}%`, `%${String(i.q).toLowerCase()}%`);
  }
  let all = (await rows(db, where.join(" AND "), args, now, s)).sort((a, b) => a.stage_order - b.stage_order || String(b.closed_at || b.created_at).localeCompare(String(a.closed_at || a.created_at)));
  if (i.stuck === true || i.stuck === "true") all = all.filter((d) => d.stuck);
  const limit = full ? 500 : Math.min(Number(i.limit) || 12, 100);
  const offset = Number(i.offset) || 0;
  return { total: all.length, rows: all.slice(offset, offset + limit).map((d) => full ? d : brief(d)), ...offset + limit < all.length ? { more: `${all.length - offset - limit} more: offset ${offset + limit}` } : {} };
}
async function pipeline(db, i, full, now) {
  const s = await settingsRow(db);
  const open = await rows(db, `d.status = 'Open'`, [], now, s);
  const won = await db.one(`SELECT COUNT(*) AS n, COALESCE(SUM(amount),0) AS v FROM ${T.deals} WHERE ${LIVE} AND status = 'Won'`);
  const lost = await db.one(`SELECT COUNT(*) AS n FROM ${T.deals} WHERE ${LIVE} AND status = 'Lost'`);
  const wonMonthly = (await db.all(`SELECT recurring_amount, recurring_every FROM ${T.deals} WHERE ${LIVE} AND status = 'Won' AND recurring_amount > 0`)).reduce((t, d) => t + monthly(d.recurring_amount, d.recurring_every), 0);
  const stages = openStages(s.stages).map((st) => {
    const here = open.filter((d) => d.stage === st.name);
    return sent({ stage: st.name, probability: st.probability, deals: here.length, amount: r2(here.reduce((t, d) => t + (d.amount || 0), 0)), monthly: r2(here.reduce((t, d) => t + d.monthly, 0)), stuck: here.filter((d) => d.stuck).length, ids: full ? void 0 : here.slice(0, 8).map((d) => d.id) });
  });
  const strays = open.filter((d) => !openStages(s.stages).some((st) => st.name === d.stage));
  return {
    currency: s.currency,
    kinds: s.kinds,
    sources: full ? s.sources : void 0,
    all_stages: full ? s.stages.map((x) => ({ name: x.name, outcome: x.outcome })) : void 0,
    stuck_days: s.stuck_days,
    stages,
    open: { deals: open.length, amount: r2(open.reduce((t, d) => t + (d.amount || 0), 0)), monthly: r2(open.reduce((t, d) => t + d.monthly, 0)), weighted: r2(open.reduce((t, d) => t + (d.amount || 0) * d.probability / 100, 0)), stuck: open.filter((d) => d.stuck).length },
    won: { deals: won.n, amount: r2(won.v), monthly: r2(wonMonthly) },
    lost: { deals: lost.n },
    ...strays.length ? { other_stage: strays.map((d) => ({ id: d.id, stage: d.stage })) } : {}
  };
}
async function one(db, i, full, now) {
  const id = idOf(i.id);
  const [d] = await rows(db, "d._id = ?", [id], now);
  if (!d) throw new Refused(`There is no deal ${i.id}. deals lists them.`, 404, { code: "NOT_FOUND", item: id });
  const proposal = await db.one(`SELECT t._id AS id, t.title, t.due, t.why, t.draft_id FROM ${T.tasks} t WHERE t._deleted = 0 AND t.deal_id = ? AND t.status = 'Suggested' ORDER BY t._id DESC LIMIT 1`, [id]);
  const drafts = await db.all(`SELECT _id AS id, to_email, subject, body, status, error, sent_at, approved_by FROM ${T.drafts} WHERE _deleted = 0 AND deal_id = ? AND status IN ('Review','Approved','Failed') ORDER BY _id DESC`, [id]);
  const timeline = await list(db, { deal_id: id, limit: full ? 50 : 6 }, full);
  const out = { ...full ? d : brief(d), contact: d.contact || void 0, contact_email: d.contact_email || void 0, company_id: d.company_id, contact_id: d.contact_id, quiet_days: d.quiet_days, quote: d.quote_ref || d.quote_state ? sent({ ref: d.quote_ref, state: d.quote_state, total: d.quote_total }) : void 0, project: d.project_ref || void 0, proposal: proposal ? sent({ ...proposal, draft_id: proposal.draft_id || void 0 }) : void 0, drafts: full ? drafts : drafts.map((x) => ({ id: x.id, status: x.status, subject: x.subject, to: x.to_email })), timeline: timeline.rows };
  if (full) {
    const peers = await db.peers().catch(() => null);
    out.unlocks = peers ? Object.fromEntries(peers.map((p) => [p.module, { installed: !!p.installed, name: p.name }])) : null;
    out.stages = (await settingsRow(db)).stages;
  }
  return out;
}
async function save(db, i, actor, now) {
  const s = await settingsRow(db);
  const out = { added: [], changed: [], skipped: [] };
  for (const [k, item] of listOf(i.items, "items").entries()) {
    try {
      const r = await saveOne(db, item, s, actor, now);
      out[r.added ? "added" : "changed"].push(r.id);
    } catch (e) {
      if (!(e instanceof Refused)) throw e;
      out.skipped.push({ index: k, code: e.code, error: e.message, ...e.item !== void 0 ? { item: e.item } : {} });
    }
  }
  return out;
}
async function saveOne(db, item, s, actor, now) {
  const id = idOf(item.id);
  const was = id ? await db.one(`SELECT * FROM ${T.deals} WHERE ${LIVE} AND _id = ?`, [id]) : null;
  if (id && !was) throw new Refused(`There is no deal ${id}. deals lists them.`, 404, { code: "NOT_FOUND", item: id });
  const data = sent({
    title: item.title === void 0 ? void 0 : text(item.title, 200),
    kind: item.kind === void 0 ? void 0 : kindOf(item.kind, s),
    amount: item.amount === void 0 ? void 0 : euros(item.amount, "amount"),
    recurring_amount: item.recurring_amount === void 0 ? void 0 : euros(item.recurring_amount, "recurring_amount"),
    recurring_every: item.recurring_every === void 0 ? void 0 : choiceOf(item.recurring_every, RECURRING, "recurring_every"),
    currency: item.currency === void 0 ? void 0 : (text(item.currency, 3) || s.currency).toUpperCase(),
    expected_close: item.expected_close === void 0 ? void 0 : dateOf(item.expected_close, "expected_close"),
    source: item.source === void 0 ? void 0 : text(item.source, 60),
    owner: item.owner === void 0 ? void 0 : text(item.owner, 120),
    notes: item.notes === void 0 ? void 0 : text(item.notes, 4e3),
    lost_reason: item.lost_reason === void 0 ? void 0 : text(item.lost_reason, 400)
  });
  if (item.company !== void 0 || item.company_id !== void 0 || item.website !== void 0) data.company_id = await companyRef(db, { company_id: item.company_id, company: item.company, website: item.website, email: item.email }, { make: true, source: data.source });
  if (item.contact !== void 0 || item.contact_id !== void 0 || item.email !== void 0) data.contact_id = await contactRef(db, { contact_id: item.contact_id, contact: item.contact, email: item.email, phone: item.phone }, { make: true, company_id: data.company_id ?? was?.company_id ?? null, source: data.source });
  if (data.contact_id && !data.company_id && !was?.company_id) data.company_id = (await db.one(`SELECT company_id FROM ${T.contacts} WHERE _id = ?`, [data.contact_id]))?.company_id ?? void 0;
  const outcome = item.outcome ? choiceOf(item.outcome, { won: ["ganado", "won"], lost: ["perdido", "lost"] }, "outcome") : null;
  let stage = null;
  if (outcome) stage = outcomeStage(s.stages, outcome);
  else if (item.stage !== void 0 && item.stage !== null && item.stage !== "") {
    stage = stageNamed(s.stages, item.stage);
    if (!stage) throw new Refused(`There is no stage \xAB${item.stage}\xBB. The stages: ${s.stages.map((x) => x.name).join(", ")}.`, 400, { code: "BAD_STAGE" });
  }
  if (!was) {
    if (!data.title) throw new Refused("A new deal needs a title: what is being sold (\xABWeb llevada por IA\xBB).", 400, { code: "BAD_INPUT" });
    if (!data.company_id && !data.contact_id) throw new Refused("A new deal needs its client: company (a name, made if new) or contact with email.", 400, { code: "NO_CLIENT" });
    stage ??= openStages(s.stages)[0];
    const nid = await db.insert(T.deals, { currency: s.currency, ...data, stage: stage.name, status: stage.outcome === "won" ? "Won" : stage.outcome === "lost" ? "Lost" : "Open", stage_changed_at: stamp(now), closed_at: stage.outcome ? today(now, s.timezone) : null });
    await note(db, { deal_id: nid, company_id: data.company_id, contact_id: data.contact_id }, "stage", `Nuevo negocio \xB7 ${stage.name}`, null, actor, now);
    if (stage.outcome === "won" && data.contact_id) await db.update(T.contacts, data.contact_id, { status: "Customer" });
    return { id: nid, added: true };
  }
  if (stage && stage.name !== was.stage) {
    if (stage.outcome === "lost" && !data.lost_reason && !was.lost_reason) throw new Refused("A lost deal says why (lost_reason): \xABprecio\xBB, \xABse fue con otro\xBB, \xABlo dejan para m\xE1s adelante\xBB. It is what the next deal learns from.", 400, { code: "NEEDS_REASON", item: was._id });
    Object.assign(data, { stage: stage.name, stage_changed_at: stamp(now), status: stage.outcome === "won" ? "Won" : stage.outcome === "lost" ? "Lost" : "Open", closed_at: stage.outcome ? today(now, s.timezone) : null });
    if (stage.outcome) Object.assign(data, { next_step: null, next_step_due: null });
    await note(db, { deal_id: was._id, company_id: data.company_id ?? was.company_id, contact_id: data.contact_id ?? was.contact_id }, "stage", `${was.stage} \u2192 ${stage.name}`, stage.outcome === "lost" ? data.lost_reason ?? was.lost_reason : null, actor, now);
    const cid = data.contact_id ?? was.contact_id;
    if (stage.outcome === "won" && cid) await db.update(T.contacts, cid, { status: "Customer" });
    if (stage.outcome) for (const t of await db.all(`SELECT _id, draft_id FROM ${T.tasks} WHERE _deleted = 0 AND deal_id = ? AND status IN ('Suggested','Open')`, [was._id])) {
      await db.update(T.tasks, t._id, { status: "Dismissed" });
      if (t.draft_id) await db.update(T.drafts, t.draft_id, { status: "Dropped" }, { status: "Review" });
    }
  }
  if (Object.keys(data).length) await db.update(T.deals, was._id, data);
  return { id: was._id, added: false };
}
function kindOf(v, s) {
  const k = text(v, 60);
  if (!k) return null;
  const known = s.kinds.find((x) => x.toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, "") === k.toLowerCase().normalize("NFD").replace(/[̀-ͯ]/g, ""));
  if (known) return known;
  throw new Refused(`\xAB${k}\xBB is not one of the kinds of service in Ajustes: ${s.kinds.join(", ")}. Use one of them, or ask an admin to add it.`, 400, { code: "BAD_KIND" });
}
async function remove2(db, i) {
  const d = await db.one(`SELECT _id FROM ${T.deals} WHERE ${LIVE} AND _id = ?`, [idOf(i.id)]);
  if (!d) throw new Refused(`There is no deal ${i.id}.`, 404, { code: "NOT_FOUND" });
  await db.update(T.deals, d._id, { removed: 1 });
  for (const t of await db.all(`SELECT _id FROM ${T.tasks} WHERE _deleted = 0 AND deal_id = ? AND status IN ('Suggested','Open')`, [d._id])) await db.update(T.tasks, t._id, { status: "Dismissed" });
  return { removed: d._id };
}
async function link(db, i) {
  const items = i.items ? listOf(i.items, "items") : [i];
  const out = { changed: [], skipped: [] };
  for (const [k, item] of items.entries()) {
    const d = await db.one(`SELECT _id FROM ${T.deals} WHERE ${LIVE} AND _id = ?`, [idOf(item.deal_id)]);
    if (!d) {
      out.skipped.push({ index: k, code: "NOT_FOUND", error: `There is no deal ${item.deal_id}.` });
      continue;
    }
    const data = sent({ quote_ref: item.quote_ref === void 0 ? void 0 : text(item.quote_ref, 80), quote_state: item.quote_state === void 0 ? void 0 : text(item.quote_state, 40), quote_total: item.quote_total === void 0 ? void 0 : euros(item.quote_total, "quote_total"), project_ref: item.project_ref === void 0 ? void 0 : text(item.project_ref, 80) });
    if (!Object.keys(data).length) {
      out.skipped.push({ index: k, code: "BAD_INPUT", error: "Send what was made: quote_ref (and quote_state, quote_total) or project_ref." });
      continue;
    }
    await db.update(T.deals, d._id, data);
    out.changed.push(d._id);
  }
  return out;
}
async function quoteRequest(db, i, actor, now) {
  const d = await db.one(`SELECT _id, status, quote_ref, company_id, contact_id FROM ${T.deals} WHERE ${LIVE} AND _id = ?`, [idOf(i.id)]);
  if (!d) throw new Refused(`There is no deal ${i.id}.`, 404, { code: "NOT_FOUND" });
  if (d.status !== "Open") throw new Refused("The deal is closed: a quote is for an open deal. Reopen it by moving it to an open stage first.", 409, { code: "CLOSED" });
  const peers = await db.peers().catch(() => null);
  const inv = peers?.find((p) => p.module === "invoices");
  if (inv && !inv.installed) throw new Refused("Invoices is not installed: the quote is made there. An admin installs it from M\xF3dulos \u203A Cat\xE1logo.", 409, { code: "NOT_INSTALLED" });
  await db.update(T.deals, d._id, { quote_state: "requested", quote_note: text(i.note, 1e3) });
  await note(db, { deal_id: d._id, company_id: d.company_id, contact_id: d.contact_id }, "task", "Presupuesto pedido", text(i.note, 1e3), actor, now);
  return { id: d._id, quote_state: "requested" };
}
async function quotesRefresh(db) {
  const deals = await db.all(`SELECT _id, quote_ref, quote_state, quote_total FROM ${T.deals} WHERE ${LIVE} AND (status = 'Open' OR COALESCE(quote_state,'') <> '')`);
  let changed = 0;
  for (const d of deals) {
    let r;
    try {
      r = await db.read("invoices", "by_origin", { origin: `CRM #${d._id}` });
    } catch {
      return { changed, error: "Invoices did not answer" };
    }
    if (!r || r.installed === false) return { changed, installed: false };
    const docs = (r.result?.documents ?? []).filter((x) => x.kind === "quote");
    const q = docs[docs.length - 1];
    if (!q) continue;
    const total = Number(String(q.total ?? q.total_text ?? "").replace(/[^\d,.-]/g, "").replace(/\.(?=\d{3}(\D|$))/g, "").replace(",", "."));
    const data = sent({ quote_ref: q.number || d.quote_ref || `#${q.id}`, quote_state: String(q.state || "").toLowerCase() || d.quote_state, quote_total: Number.isFinite(total) && total > 0 ? total : void 0 });
    if (data.quote_ref !== d.quote_ref || data.quote_state !== d.quote_state || data.quote_total !== void 0 && data.quote_total !== d.quote_total) {
      await db.update(T.deals, d._id, data);
      changed += 1;
    }
  }
  return { changed };
}

// server/services/steps.mjs
async function dealOf(db, id) {
  const d = await db.one(`SELECT d._id, d.title, d.status, d.company_id, d.contact_id, p.email FROM ${T.deals} d LEFT JOIN ${T.contacts} p ON p._id = d.contact_id WHERE d._deleted = 0 AND COALESCE(d.removed,0) = 0 AND d._id = ?`, [idOf(id)]);
  if (!d) throw new Refused(`There is no deal ${id}. deals lists them.`, 404, { code: "NOT_FOUND", item: idOf(id) });
  return d;
}
async function propose(db, i, actor, now) {
  const s = await settingsRow(db);
  const out = { proposed: [], skipped: [] };
  for (const [k, item] of listOf(i.items, "items").entries()) {
    try {
      const d = await dealOf(db, item.deal_id);
      if (d.status !== "Open") throw new Refused("The deal is closed: there is no next step to propose.", 409, { code: "CLOSED", item: d._id });
      const step = text(item.step ?? item.title, 200);
      if (!step) throw new Refused("A proposal says the step: \xABLlamar a Nacho para cerrar el alcance\xBB.", 400, { code: "BAD_INPUT", item: d._id });
      const due = dateOf(item.due, "due") ?? today(now, s.timezone);
      for (const t of await db.all(`SELECT _id, draft_id FROM ${T.tasks} WHERE _deleted = 0 AND deal_id = ? AND status = 'Suggested'`, [d._id])) {
        await db.update(T.tasks, t._id, { status: "Dismissed" });
        if (t.draft_id) await db.update(T.drafts, t.draft_id, { status: "Dropped" }, { status: "Review" });
      }
      let draft_id = null;
      const mail = item.email ?? item.draft;
      if (mail && (mail.body || mail.subject)) {
        const to = mail.to ? normEmail(mail.to) : d.email;
        if (!to || !isEmail(to)) throw new Refused("The email has nobody to go to: the deal has no person with an email. Add the person (contacts_save) or leave the email out.", 400, { code: "NO_RECIPIENT", item: d._id });
        if (mail.to && to !== d.email && !await db.one(`SELECT _id FROM ${T.contacts} WHERE ${LIVE} AND lower(email) = ?`, [to])) throw new Refused(`${to} is not anyone in the CRM: an email goes to the deal's person, or to someone already here.`, 400, { code: "UNKNOWN_RECIPIENT", item: d._id });
        if (/\[[^\]]{2,40}\]|\{\{|<nombre>|XXX/i.test(`${mail.subject ?? ""} ${mail.body ?? ""}`)) throw new Refused("The email still has a placeholder ([Nombre], {{\u2026}}, XXX): write it whole, as it would go.", 400, { code: "PLACEHOLDER", item: d._id });
        draft_id = await db.insert(T.drafts, { to_email: to, subject: text(mail.subject, 200), body: text(mail.body, 8e3), contact_id: d.contact_id, deal_id: d._id, status: "Review", created_by: who(actor), source: "agent" });
      }
      const task_id = await db.insert(T.tasks, { title: step, due, deal_id: d._id, contact_id: d.contact_id, status: "Suggested", why: text(item.why, 600), draft_id, source: "agent" });
      out.proposed.push(sent({ deal_id: d._id, task_id, draft_id: draft_id ?? void 0 }));
    } catch (e) {
      if (!(e instanceof Refused)) throw e;
      out.skipped.push({ index: k, code: e.code, error: e.message, ...e.item !== void 0 ? { item: e.item } : {} });
    }
  }
  return out;
}
var taskOf = async (db, id, status) => {
  const t = await db.one(`SELECT * FROM ${T.tasks} WHERE _deleted = 0 AND _id = ?`, [idOf(id)]);
  if (!t) throw new Refused(`There is no proposed step ${id}.`, 404, { code: "NOT_FOUND" });
  if (status && t.status !== status) throw new Refused(`That step is ${String(t.status).toLowerCase()} already, not waiting for a decision.`, 409, { code: "ALREADY_DECIDED", item: t._id });
  return t;
};
async function accept(db, i, actor, now) {
  const t = await taskOf(db, i.id, "Suggested");
  const due = dateOf(i.due, "due") ?? t.due;
  await db.update(T.tasks, t._id, { status: "Open", due, owner: who(actor) });
  if (t.deal_id) await db.update(T.deals, t.deal_id, { next_step: t.title, next_step_due: due });
  return { deal_id: t.deal_id, next_step: t.title, due, draft_id: t.draft_id || void 0 };
}
async function dismiss(db, i) {
  const t = await taskOf(db, i.id, "Suggested");
  await db.update(T.tasks, t._id, { status: "Dismissed" });
  if (t.draft_id) await db.update(T.drafts, t.draft_id, { status: "Dropped" }, { status: "Review" });
  return { dismissed: t._id };
}
async function set(db, i, actor, now) {
  const s = await settingsRow(db);
  const items = i.items ? listOf(i.items, "items") : [i];
  const out = { changed: [], skipped: [] };
  for (const [k, item] of items.entries()) {
    try {
      const d = await dealOf(db, item.deal_id ?? item.id);
      if (d.status !== "Open") throw new Refused("The deal is closed: no next step.", 409, { code: "CLOSED", item: d._id });
      const step = text(item.step, 200);
      if (!step) throw new Refused("Say the step.", 400, { code: "BAD_INPUT", item: d._id });
      const due = dateOf(item.due, "due") ?? today(now, s.timezone);
      for (const t of await db.all(`SELECT _id FROM ${T.tasks} WHERE _deleted = 0 AND deal_id = ? AND status = 'Open'`, [d._id])) await db.update(T.tasks, t._id, { status: "Dismissed" });
      await db.insert(T.tasks, { title: step, due, deal_id: d._id, contact_id: d.contact_id, status: "Open", owner: who(actor), source: "person" });
      await db.update(T.deals, d._id, { next_step: step, next_step_due: due });
      out.changed.push(d._id);
    } catch (e) {
      if (!(e instanceof Refused)) throw e;
      out.skipped.push({ index: k, code: e.code, error: e.message, ...e.item !== void 0 ? { item: e.item } : {} });
    }
  }
  return out;
}
async function done(db, i, actor, now) {
  const d = await dealOf(db, i.deal_id ?? i.id);
  const was = await db.one(`SELECT next_step FROM ${T.deals} WHERE _id = ?`, [d._id]);
  if (!was?.next_step) throw new Refused("The deal has no next step to mark done. next_step_set sets one.", 409, { code: "NO_STEP", item: d._id });
  for (const t of await db.all(`SELECT _id FROM ${T.tasks} WHERE _deleted = 0 AND deal_id = ? AND status = 'Open'`, [d._id])) await db.update(T.tasks, t._id, { status: "Done", done_at: stamp(now) });
  await db.update(T.deals, d._id, { next_step: null, next_step_due: null });
  await note(db, { deal_id: d._id, company_id: d.company_id, contact_id: d.contact_id }, "task", `Hecho: ${was.next_step}`, text(i.note, 1500), actor, now);
  return { deal_id: d._id, done: was.next_step };
}
var draftOf = async (db, id) => {
  const x = await db.one(`SELECT * FROM ${T.drafts} WHERE _deleted = 0 AND _id = ?`, [idOf(id)]);
  if (!x) throw new Refused(`There is no email ${id}.`, 404, { code: "NOT_FOUND" });
  return x;
};
async function draftUpdate(db, i) {
  const x = await draftOf(db, i.id);
  if (x.status !== "Review" && x.status !== "Failed") throw new Refused(`This email is ${String(x.status).toLowerCase()}: only one still to review can change. ${x.status === "Approved" ? "Take the approval back first (draft_drop) and write a new one." : ""}`.trim(), 409, { code: "NOT_EDITABLE", item: x._id });
  const data = sent({ subject: i.subject === void 0 ? void 0 : text(i.subject, 200), body: i.body === void 0 ? void 0 : text(i.body, 8e3), to_email: i.to === void 0 ? void 0 : normEmail(i.to) });
  if (data.to_email && !isEmail(data.to_email)) throw new Refused(`${data.to_email} is not an email address.`, 400, { code: "BAD_EMAIL" });
  if (x.status === "Failed") data.status = "Review";
  if (Object.keys(data).length) await db.update(T.drafts, x._id, data);
  return { id: x._id, status: data.status ?? x.status };
}
async function approve(db, i, actor, now) {
  const x = await draftOf(db, i.id);
  if (x.status !== "Review") throw new Refused(`This email is ${String(x.status).toLowerCase()}, not waiting for a yes.`, 409, { code: "ALREADY_DECIDED", item: x._id });
  if (!x.body || !x.to_email) throw new Refused("The email needs who it goes to and its text before it can go.", 400, { code: "INCOMPLETE", item: x._id });
  await db.update(T.drafts, x._id, { status: "Approved", approved_by: who(actor), approved_at: stamp(now) });
  return { id: x._id, status: "Approved" };
}
async function drop(db, i) {
  const x = await draftOf(db, i.id);
  if (x.status === "Sent") throw new Refused("This email has gone already: it is on the timeline.", 409, { code: "ALREADY_SENT", item: x._id });
  await db.update(T.drafts, x._id, { status: "Dropped" });
  return { id: x._id, status: "Dropped" };
}
async function sentMany(db, i, actor, now) {
  const out = { sent: [], failed: [], skipped: [] };
  for (const [k, item] of listOf(i.items, "items").entries()) {
    try {
      const x = await draftOf(db, item.id);
      if (x.status === "Sent") {
        out.skipped.push({ index: k, code: "ALREADY_SENT", error: "Said already.", item: x._id });
        continue;
      }
      if (x.status !== "Approved") throw new Refused("Nobody approved this email: it may not go. Ask the person to approve it in the CRM first.", 409, { code: "NOT_APPROVED", item: x._id });
      if (item.error) {
        await db.update(T.drafts, x._id, { status: "Failed", error: text(item.error, 400) });
        out.failed.push(x._id);
        continue;
      }
      await db.update(T.drafts, x._id, { status: "Sent", sent_at: stamp(now), gmail_message_id: text(item.message_id, 200) });
      const d = x.deal_id ? await db.one(`SELECT company_id FROM ${T.deals} WHERE _id = ?`, [x.deal_id]) : null;
      await note(db, { deal_id: x.deal_id, contact_id: x.contact_id, company_id: d?.company_id }, "email_out", x.subject, x.body, actor, now);
      if (x.deal_id) for (const t of await db.all(`SELECT _id FROM ${T.tasks} WHERE _deleted = 0 AND draft_id = ? AND status IN ('Open','Suggested')`, [x._id])) await db.update(T.tasks, t._id, { status: "Done", done_at: stamp(now) });
      out.sent.push(x._id);
    } catch (e) {
      if (!(e instanceof Refused)) throw e;
      out.skipped.push({ index: k, code: e.code, error: e.message, ...e.item !== void 0 ? { item: e.item } : {} });
    }
  }
  return out;
}
async function draft(db, i) {
  const x = await draftOf(db, i.id);
  const sig = (await settingsRow(db)).signature;
  return { id: x._id, status: x.status, to: x.to_email, subject: x.subject, body: x.body, signature: sig || void 0, deal_id: x.deal_id || void 0, error: x.error || void 0 };
}

// server/services/leads.mjs
var FIT = { good: ["encaja", "si", "yes", "buena"], maybe: ["quiza", "puede", "dudoso"], poor: ["no encaja", "no", "mala"] };
var STATES = { new: ["nueva", "nuevo"], qualified: ["calificada", "calificado"], accepted: ["aceptada", "negocio"], discarded: ["descartada", "descartado"] };
async function add2(db, i, actor, now) {
  const out = { added: [], already: [], skipped: [] };
  for (const [k, item] of listOf(i.items, "items").entries()) {
    try {
      const email = item.email ? normEmail(item.email) : null;
      if (email && !isEmail(email)) throw new Refused(`${item.email} is not an email address.`, 400, { code: "BAD_EMAIL" });
      const name = text(item.name, 200);
      if (!email && !name && !item.phone) throw new Refused("A lead needs someone to answer: a name, an email or a phone.", 400, { code: "BAD_INPUT" });
      const ref = text(item.source_ref, 200);
      const at = momentOf(item.received_at, now, "received_at");
      const same = ref ? await db.one(`SELECT _id FROM ${T.leads} WHERE _deleted = 0 AND source_ref = ?`, [ref]) : email ? await db.one(`SELECT _id FROM ${T.leads} WHERE _deleted = 0 AND lower(email) = ? AND substr(received_at,1,10) = ?`, [email, at.slice(0, 10)]) : null;
      if (same) {
        out.already.push(same._id);
        continue;
      }
      const answers = item.answers && typeof item.answers === "object" ? JSON.stringify(item.answers).slice(0, 8e3) : text(item.answers, 8e3);
      out.added.push(await db.insert(T.leads, { name, email, phone: text(item.phone, 40), company_name: text(item.company, 200), website: text(item.website, 300), message: text(item.message, 4e3), source: text(item.source, 60) || "Web", source_ref: ref, received_at: at, answers, state: "new", created_by: who(actor) }));
    } catch (e) {
      if (!(e instanceof Refused)) throw e;
      out.skipped.push({ index: k, code: e.code, error: e.message });
    }
  }
  return out;
}
var row = (l, full) => full ? { ...l, answers: parse(l.answers) } : sent({ id: l.id, name: l.name || void 0, company: l.company_name || void 0, received: String(l.received_at).slice(0, 10), state: l.state, fit: l.fit || void 0, gist: l.message ? l.message.split("\n")[0].slice(0, 60) : void 0, deal_id: l.deal_id || void 0 });
var parse = (v) => {
  try {
    return v ? JSON.parse(v) : null;
  } catch {
    return v;
  }
};
async function list3(db, i, full) {
  const state = i.state && i.state !== "all" && i.state !== "open" ? choiceOf(i.state, STATES, "state") : null;
  const where = state ? "state = ?" : i.state === "all" ? "1 = 1" : `state IN ('new','qualified')`;
  const rows2 = await db.all(`SELECT _id AS id, name, email, phone, company_name, website, message, source, source_ref, received_at, answers, state, fit, qualification, proposed_kind, proposed_amount, proposed_recurring, qualified_at, decided_by, decided_at, discard_reason, contact_id, company_id, deal_id FROM ${T.leads} WHERE ${LIVE} AND ${where} ORDER BY received_at DESC, _id DESC`, state ? [state] : []);
  const counts = await db.all(`SELECT state, COUNT(*) AS n FROM ${T.leads} WHERE ${LIVE} GROUP BY state`);
  const limit = full ? 300 : Math.min(Number(i.limit) || 10, 100);
  return { counts: Object.fromEntries(counts.map((c) => [c.state, c.n])), total: rows2.length, rows: rows2.slice(0, limit).map((l) => row(l, full)), ...rows2.length > limit ? { more: `${rows2.length - limit} more: limit ${limit + 20}` } : {} };
}
async function one2(db, i) {
  const l = await db.one(`SELECT _id AS id, * FROM ${T.leads} WHERE ${LIVE} AND _id = ?`, [idOf(i.id)]);
  if (!l) throw new Refused(`There is no lead ${i.id}. leads lists them.`, 404, { code: "NOT_FOUND", item: idOf(i.id) });
  const known = l.email ? await db.one(`SELECT p._id AS id, p.name, c.name AS company FROM ${T.contacts} p LEFT JOIN ${T.companies} c ON c._id = p.company_id WHERE p._deleted = 0 AND lower(p.email) = ?`, [l.email]) : null;
  const { _id, _created_at, _updated_at, _deleted, removed, ...rest } = l;
  return { ...rest, answers: parse(l.answers), known_contact: known || void 0 };
}
async function qualify(db, i, actor, now) {
  const s = await settingsRow(db);
  const out = { qualified: [], skipped: [] };
  for (const [k, item] of listOf(i.items, "items").entries()) {
    try {
      const l = await db.one(`SELECT _id, state FROM ${T.leads} WHERE ${LIVE} AND _id = ?`, [idOf(item.id)]);
      if (!l) throw new Refused(`There is no lead ${item.id}.`, 404, { code: "NOT_FOUND", item: idOf(item.id) });
      if (l.state === "accepted" || l.state === "discarded") throw new Refused("A person decided this lead already.", 409, { code: "ALREADY_DECIDED", item: l._id });
      const summary = text(item.summary ?? item.why, 1200);
      if (!summary) throw new Refused("Say why, in two or three lines: who they are, what they want, whether it fits what the company sells.", 400, { code: "BAD_INPUT", item: l._id });
      const kind = item.kind ? s.kinds.find((x) => fold(x) === fold(item.kind)) : null;
      if (item.kind && !kind) throw new Refused(`\xAB${item.kind}\xBB is not a kind of service in Ajustes: ${s.kinds.join(", ")}.`, 400, { code: "BAD_KIND", item: l._id });
      await db.update(T.leads, l._id, sent({ fit: choiceOf(item.fit, FIT, "fit") ?? "maybe", qualification: summary, proposed_kind: kind ?? void 0, proposed_amount: item.amount === void 0 ? void 0 : euros(item.amount), proposed_recurring: item.recurring_amount === void 0 ? void 0 : euros(item.recurring_amount, "recurring_amount"), company_name: item.company === void 0 ? void 0 : text(item.company, 200), website: item.website === void 0 ? void 0 : text(item.website, 300), state: "qualified", qualified_at: stamp(now) }));
      out.qualified.push(l._id);
    } catch (e) {
      if (!(e instanceof Refused)) throw e;
      out.skipped.push({ index: k, code: e.code, error: e.message, ...e.item !== void 0 ? { item: e.item } : {} });
    }
  }
  return out;
}
var openLead = async (db, id) => {
  const l = await db.one(`SELECT * FROM ${T.leads} WHERE ${LIVE} AND _id = ?`, [idOf(id)]);
  if (!l) throw new Refused(`There is no lead ${id}.`, 404, { code: "NOT_FOUND" });
  if (l.state === "accepted") throw new Refused("This lead is a deal already.", 409, { code: "ALREADY_A_DEAL", item: l.deal_id });
  if (l.state === "discarded") throw new Refused("This lead was discarded. lead_reopen brings it back to decide again.", 409, { code: "ALREADY_DECIDED", item: l._id });
  return l;
};
async function accept2(db, i, actor, now) {
  const s = await settingsRow(db);
  const l = await openLead(db, i.id);
  const company_id = await companyRef(db, { company: i.company ?? l.company_name, website: l.website, email: l.email }, { make: true, source: l.source });
  const contact_id = await contactRef(db, { email: l.email, name: l.name, phone: l.phone }, { make: true, company_id, source: l.source });
  if (!company_id && !contact_id) throw new Refused("The lead has no name, email or company to make a client from: add them first.", 400, { code: "NO_CLIENT" });
  if (contact_id && company_id && !(await db.one(`SELECT company_id FROM ${T.contacts} WHERE _id = ?`, [contact_id]))?.company_id) await db.update(T.contacts, contact_id, { company_id });
  const stage = i.stage ? stageNamed(s.stages, i.stage) : openStages(s.stages)[Math.min(1, openStages(s.stages).length - 1)];
  if (!stage) throw new Refused(`There is no stage \xAB${i.stage}\xBB.`, 400, { code: "BAD_STAGE" });
  const title = text(i.title, 200) || [l.proposed_kind, l.company_name || l.name].filter(Boolean).join(" \xB7 ") || "Nuevo negocio";
  const r = await save(db, { items: [{ title, company_id: company_id ?? void 0, contact_id: contact_id ?? void 0, stage: stage.name, kind: i.kind ?? l.proposed_kind ?? void 0, amount: i.amount ?? l.proposed_amount ?? void 0, recurring_amount: i.recurring_amount ?? l.proposed_recurring ?? void 0, recurring_every: i.recurring_amount ?? l.proposed_recurring ? "month" : void 0, source: l.source }] }, actor, now);
  if (r.skipped.length) throw new Refused(r.skipped[0].error, 400, { code: r.skipped[0].code });
  const deal_id = r.added[0];
  await note(db, { deal_id, contact_id, company_id }, "form", `Entrada \xB7 ${l.source || "Web"}`, [l.message, l.qualification ? `Lectura del agente: ${l.qualification}` : null].filter(Boolean).join("\n\n") || null, actor, now, l.received_at);
  await db.update(T.leads, l._id, { state: "accepted", decided_by: who(actor), decided_at: stamp(now), contact_id, company_id, deal_id });
  return { lead_id: l._id, deal_id, company_id, contact_id };
}
async function discard(db, i, actor, now) {
  const l = await openLead(db, i.id);
  await db.update(T.leads, l._id, { state: "discarded", discard_reason: text(i.reason, 300) || "Sin motivo", decided_by: who(actor), decided_at: stamp(now) });
  return { lead_id: l._id, state: "discarded" };
}
async function reopen(db, i) {
  const l = await db.one(`SELECT _id, state, qualification FROM ${T.leads} WHERE ${LIVE} AND _id = ?`, [idOf(i.id)]);
  if (!l) throw new Refused(`There is no lead ${i.id}.`, 404, { code: "NOT_FOUND" });
  if (l.state !== "discarded") throw new Refused("Only a discarded lead comes back.", 409, { code: "NOT_DISCARDED", item: l._id });
  await db.update(T.leads, l._id, { state: l.qualification ? "qualified" : "new", discard_reason: null, decided_by: null, decided_at: null });
  return { lead_id: l._id };
}

// server/services/today.mjs
async function today2(db, i, full, now) {
  const s = await settingsRow(db);
  const d0 = today(now, s.timezone);
  const leads = await db.all(`SELECT _id AS id, name, email, company_name, source, received_at, state, fit, qualification, proposed_kind, proposed_amount, message FROM ${T.leads} WHERE ${LIVE} AND state IN ('new','qualified') ORDER BY received_at DESC`);
  const proposals = await db.all(`SELECT t._id AS id, t.title, t.due, t.why, t.deal_id, t.draft_id, d.title AS deal, c.name AS company, x.subject, x.to_email, x.body FROM ${T.tasks} t JOIN ${T.deals} d ON d._id = t.deal_id AND d._deleted = 0 AND COALESCE(d.removed,0) = 0 AND d.status = 'Open' LEFT JOIN ${T.companies} c ON c._id = d.company_id LEFT JOIN ${T.drafts} x ON x._id = t.draft_id WHERE t._deleted = 0 AND t.status = 'Suggested' ORDER BY t.due, t._id`);
  const emails = await db.all(`SELECT x._id AS id, x.status, x.subject, x.to_email, x.deal_id, x.error, d.title AS deal FROM ${T.drafts} x LEFT JOIN ${T.deals} d ON d._id = x.deal_id WHERE x._deleted = 0 AND x.status IN ('Review','Approved','Failed') AND x._id NOT IN (SELECT draft_id FROM ${T.tasks} WHERE _deleted = 0 AND status = 'Suggested' AND draft_id IS NOT NULL) ORDER BY x._id DESC`);
  const open = await rows(db, `d.status = 'Open'`, [], now, s);
  const late = open.filter((d) => d.late).sort((a, b) => a.next_step_due.localeCompare(b.next_step_due));
  const dueSoon = open.filter((d) => d.next_step_due && !d.late && d.next_step_due <= addDaysIso(d0, 7)).sort((a, b) => a.next_step_due.localeCompare(b.next_step_due));
  const stuck = open.filter((d) => d.stuck && !d.late && !d.proposed).sort((a, b) => b.quiet_days - a.quiet_days);
  const noStep = open.filter((d) => !d.next_step && !d.proposed && !d.stuck);
  const quotes = open.filter((d) => d.quote_state === "requested" && !d.quote_ref);
  const counts = {
    leads_to_decide: leads.filter((l) => l.state === "qualified").length,
    leads_to_qualify: leads.filter((l) => l.state === "new").length,
    steps_proposed: proposals.length,
    emails_to_review: emails.filter((e) => e.status === "Review").length + proposals.filter((p) => p.draft_id).length,
    emails_to_send: emails.filter((e) => e.status === "Approved").length,
    emails_failed: emails.filter((e) => e.status === "Failed").length,
    steps_late: late.length,
    due_this_week: dueSoon.length,
    stuck: stuck.length,
    no_step: noStep.length,
    quotes_to_make: quotes.length,
    open_deals: open.length
  };
  const figures = { open_amount: sum(open, "amount"), open_monthly: sum(open, "monthly"), weighted: Math.round(open.reduce((t, d) => t + (d.amount || 0) * d.probability / 100, 0)), currency: s.currency };
  const agent = [
    ...leads.filter((l) => l.state === "new").map((l) => ({ do: "leads_qualify", lead_id: l.id, text: `Qualify lead ${l.name || l.email || l.company_name} (${l.source || "web"})`, es: `Leer la entrada de ${l.name || l.email || l.company_name}` })),
    ...emails.filter((e) => e.status === "Approved").map((e) => ({ do: "send approved email, then drafts_sent", draft_id: e.id, text: `Send \xAB${e.subject}\xBB to ${e.to_email}`, es: `Enviar \xAB${e.subject}\xBB a ${e.to_email}` })),
    ...quotes.map((d) => ({ do: "make the quote in Invoices, then deal_link", deal_id: d.id, text: `Quote for ${d.title}`, es: `Preparar el presupuesto de ${d.title}` })),
    ...[...stuck, ...noStep].map((d) => ({ do: "next_steps_propose", deal_id: d.id, text: `${d.title}: ${d.stuck ? `${d.quiet_days} days without news` : "no next step"}`, es: `Proponer el siguiente paso de ${d.title}` }))
  ];
  if (!full) return { today: d0, counts, figures, agent: agent.slice(0, 12).map(({ es, ...a }) => a), ...agent.length > 12 ? { more: `${agent.length - 12} more: full: true` } : {}, person: [...leads.filter((l) => l.state === "qualified").slice(0, 5).map((l) => `lead ${l.id} ${l.name || l.company_name}: to accept or discard`), ...late.slice(0, 5).map((d) => `deal ${d.id} ${d.title}: \xAB${d.next_step}\xBB was due ${d.next_step_due}`)] };
  return { today: d0, counts, figures, leads, proposals, emails, late: late.map(pick), due_soon: dueSoon.map(pick), stuck: stuck.map(pick), no_step: noStep.map(pick), quotes: quotes.map(pick), agent };
}
var pick = (d) => sent({ id: d.id, title: d.title, company: d.company, contact: d.contact, stage: d.stage, kind: d.kind, amount: d.amount, monthly: d.monthly || void 0, next_step: d.next_step, next_step_due: d.next_step_due, quiet_days: d.quiet_days, stuck: d.stuck || void 0, late: d.late || void 0 });
var sum = (rows2, k) => Math.round(rows2.reduce((t, d) => t + (Number(d[k]) || 0), 0) * 100) / 100;
var addDaysIso = (date, n) => new Date(Date.parse(date + "T00:00:00Z") + n * 864e5).toISOString().slice(0, 10);
async function leadsToQualify(db) {
  const rows2 = await db.all(`SELECT _id AS id, name, email, company_name, source FROM ${T.leads} WHERE ${LIVE} AND state = 'new' ORDER BY received_at`);
  return { items: rows2.map((l) => ({ key: `lead:${l.id}`, text: `${l.name || l.email || l.company_name} (${l.source || "web"})`, lead_id: l.id, email: l.email ?? void 0, company: l.company_name ?? void 0 })) };
}
async function dealsNeedingStep(db, now) {
  const open = await rows(db, `d.status = 'Open'`, [], now);
  return { items: open.filter((d) => !d.proposed && (!d.next_step || d.late || d.stuck)).map((d) => ({ key: `deal:${d.id}:${d.next_step_due || "none"}`, text: `${d.title} (${d.company || d.contact || ""}): ${d.late ? `\xAB${d.next_step}\xBB due ${d.next_step_due}` : d.stuck ? `${d.quiet_days} days without news` : "no next step"}`, deal_id: d.id, why: d.late ? "late" : d.stuck ? "stuck" : "no_step" })) };
}
async function emailsToSend(db) {
  const rows2 = await db.all(`SELECT _id AS id, to_email, subject, deal_id FROM ${T.drafts} WHERE _deleted = 0 AND status = 'Approved' ORDER BY approved_at`);
  return { items: rows2.map((x) => ({ key: `draft:${x.id}`, text: `\xAB${x.subject}\xBB to ${x.to_email}`, draft_id: x.id, deal_id: x.deal_id ?? void 0 })) };
}
async function quotesToMake(db) {
  const rows2 = await db.all(`SELECT d._id AS id, d.title, d.kind, d.amount, d.recurring_amount, d.recurring_every, d.quote_note, c.name AS company FROM ${T.deals} d LEFT JOIN ${T.companies} c ON c._id = d.company_id WHERE d._deleted = 0 AND COALESCE(d.removed,0) = 0 AND d.status = 'Open' AND d.quote_state = 'requested' AND COALESCE(d.quote_ref,'') = ''`);
  return { items: rows2.map((d) => sent({ key: `quote:${d.id}`, text: `Quote for ${d.title} (${d.company || ""})`, deal_id: d.id, company: d.company, kind: d.kind, amount: d.amount, recurring_amount: d.recurring_amount, recurring_every: d.recurring_every, note: d.quote_note })) };
}
async function wonWithoutProject(db) {
  const peers = await db.peers().catch(() => null);
  if (!peers?.some((p) => p.module === "proyectos" && p.installed)) return { items: [] };
  const rows2 = await db.all(`SELECT d._id AS id, d.title, d.kind, d.amount, d.recurring_amount, d.recurring_every, d.closed_at, c.name AS company FROM ${T.deals} d LEFT JOIN ${T.companies} c ON c._id = d.company_id WHERE d._deleted = 0 AND COALESCE(d.removed,0) = 0 AND d.status = 'Won' AND COALESCE(d.project_ref,'') = ''`);
  return { items: rows2.map((d) => sent({ key: `won:${d.id}`, text: `${d.title} (${d.company || ""}) won ${d.closed_at || ""}`, deal_id: d.id, company: d.company, kind: d.kind, amount: d.amount, recurring_amount: d.recurring_amount, recurring_every: d.recurring_every })) };
}
async function clients(db, i) {
  const q = String(i.q ?? "").trim().toLowerCase();
  const rows2 = await db.all(`SELECT c._id AS id, c.name, c.domain, c.website, c.tax_id, c.address, c.phone,
      (SELECT p.name FROM ${T.contacts} p WHERE p._deleted = 0 AND COALESCE(p.removed,0) = 0 AND p.company_id = c._id AND COALESCE(p.status,'') NOT IN ('Suggested','Ignored') ORDER BY p.last_activity_at DESC LIMIT 1) AS contact,
      (SELECT p.email FROM ${T.contacts} p WHERE p._deleted = 0 AND COALESCE(p.removed,0) = 0 AND p.company_id = c._id AND COALESCE(p.status,'') NOT IN ('Suggested','Ignored') ORDER BY p.last_activity_at DESC LIMIT 1) AS email
    FROM ${T.companies} c WHERE c._deleted = 0 AND COALESCE(c.removed,0) = 0 ${q ? "AND lower(c.name) LIKE ?" : ""} ORDER BY c.name LIMIT 200`, q ? [`%${q}%`] : []);
  return { rows: rows2.map((r) => sent({ ...r, domain: r.domain || void 0, website: r.website || void 0, tax_id: r.tax_id || void 0, address: r.address || void 0, phone: r.phone || void 0, contact: r.contact || void 0, email: r.email || void 0 })) };
}
async function wonDeals(db, i) {
  const rows2 = await db.all(`SELECT d._id AS id, d.title, d.kind, d.amount, d.recurring_amount, d.recurring_every, d.currency, d.closed_at, d.company_id, c.name AS company, d.project_ref, d.quote_ref FROM ${T.deals} d LEFT JOIN ${T.companies} c ON c._id = d.company_id WHERE d._deleted = 0 AND COALESCE(d.removed,0) = 0 AND d.status = 'Won' ${i.since ? "AND d.closed_at >= ?" : ""} ORDER BY d.closed_at DESC LIMIT 200`, i.since ? [String(i.since)] : []);
  return { rows: rows2.map((r) => sent(Object.fromEntries(Object.entries(r).map(([k, v]) => [k, v ?? void 0])))) };
}

// server/routes/crm.mjs
var DEAL = "title, company (a name; made if new) or company_id, contact (a name) + email or contact_id, stage (a stage's name), outcome (won | lost), kind (a kind of service of Ajustes), amount (euros, once), recurring_amount (euros) + recurring_every (month | quarter | year), expected_close (YYYY-MM-DD), lost_reason, source, notes";
function crm_default(app, db, deps = {}) {
  const now = () => deps.now ? deps.now() : /* @__PURE__ */ new Date();
  const command2 = (a, method, path, spec, handler) => command(a, method, path, spec, async (i, ctx) => {
    await ensureUpgraded(db);
    return handler(i, ctx);
  });
  command2(app, "GET", "/today", { name: "today", summary: "What waits, in order, and whose move it is: START HERE. Counts, the pipeline's figures, your list of work (agent) and what waits for the person.", input: { full: "true for every line whole" } }, (i, { actor }) => today2(db, i, wantsFull(i, actor), now()));
  command2(app, "GET", "/pipeline", { name: "pipeline", summary: "Each open stage with its deals and what they are worth (once, monthly, stuck); open, weighted, won and lost totals.", input: { full: "true without the ids" } }, (i, { actor }) => pipeline(db, i, wantsFull(i, actor), now()));
  command2(app, "GET", "/leads", { name: "leads", of: "lead", summary: "The leads waiting for a decision (state new | qualified), newest first; state accepted | discarded | all for the rest.", input: { state: "new | qualified | accepted | discarded | all", limit: "rows, 10 unless said", full: "true for every field" } }, (i, { actor }) => list3(db, i, wantsFull(i, actor)));
  command2(app, "GET", "/leads/:id", { name: "lead", on: "lead", summary: "One lead whole: what they wrote, the form's answers, the agent's reading, and whether the person is in the CRM already." }, (i) => one2(db, i));
  command2(app, "POST", "/leads", { name: "leads_add", summary: "Leads arrive, several in one call: items [{ name, email, phone, company, website, message, source, source_ref, received_at, answers }]. Never into Trabajo.", input: { items: "list of { name, email, phone, company, website, message, source (Web, Formulario, Reserva\u2026), source_ref (the form response's or booking's id: sent twice, added once), received_at, answers }" } }, (i, { actor }) => add2(db, i, actor, now()));
  command2(app, "POST", "/leads/qualify", { name: "leads_qualify", summary: "Your reading of leads, several in one call: items [{ id, fit: good | maybe | poor, summary, kind, amount, recurring_amount, company, website }]. A person decides.", input: { items: "list of { id, fit, summary (2\u20133 lines: who, what they want, whether it fits), kind, amount (euros), recurring_amount, company, website }" } }, (i, { actor }) => qualify(db, i, actor, now()));
  command2(app, "POST", "/leads/:id/accept", { name: "lead_accept", on: "lead", by: "person", label: { es: "Convertir en negocio", en: "Make it a deal" }, summary: "A person turns a lead into a deal: its company, person and first timeline entry are made from it. A person's decision.", input: { title: "the deal's title", stage: "a stage's name", kind: "kind of service", amount: "euros", recurring_amount: "euros a month", company: "the company's name, when the lead did not say it" } }, (i, { actor }) => accept2(db, i, actor, now()));
  command2(app, "POST", "/leads/:id/discard", { name: "lead_discard", on: "lead", by: "person", label: { es: "Descartar", en: "Discard" }, summary: "A person discards a lead, saying why. A person's decision.", input: { reason: "why: spam, not a client, nothing to sell them" } }, (i, { actor }) => discard(db, i, actor, now()));
  command2(app, "POST", "/leads/:id/reopen", { name: "lead_reopen", on: "lead", by: "person", summary: "Brings a discarded lead back to decide again. A person's decision." }, (i) => reopen(db, i));
  command2(app, "GET", "/deals", { name: "deals", of: "deal", summary: "The deals, open unless said, in stage order: client, kind, value, next step, stuck. stage, kind, status (open | won | lost | all), company_id, stuck, q.", input: { stage: "a stage's name", kind: "kind of service", status: "open | won | lost | all", company_id: "company id", contact_id: "person id", stuck: "true: only the stuck ones", q: "words of its title or client", limit: "rows, 12 unless said", offset: "rows to skip", full: "true for every field" } }, (i, { actor }) => list2(db, i, wantsFull(i, actor), now()));
  command2(app, "GET", "/deals/:id", { name: "deal", on: "deal", summary: "One deal: its card, client, next step, the step proposed (with its email), emails waiting, quote, project and its last timeline entries.", input: { full: "true for everything its page draws" } }, (i, { actor }) => one(db, i, wantsFull(i, actor), now()));
  command2(app, "POST", "/deals", { name: "deals_save", summary: `Adds or changes deals, several in one call: items [{ id?, \u2026only what changes }]. Without id it is new (title and client needed).`, input: { items: `list of { id, ${DEAL} }` } }, (i, { actor }) => save(db, i, actor, now()));
  command2(app, "POST", "/deals/:id/remove", { name: "deal_remove", on: "deal", by: "person", confirm: true, label: { es: "Quitar", en: "Remove" }, summary: "Takes a deal away (a mistake, a duplicate). A person's decision; a deal that did not happen is moved to \xABperdido\xBB." }, (i) => remove2(db, i));
  command2(app, "POST", "/deals/link", { name: "deal_link", summary: "Links back what another module made for a deal: quote_ref, quote_state, quote_total (Invoices) or project_ref (Proyectos). items for several.", input: { deal_id: "deal id", quote_ref: "the quote's number", quote_state: "draft | sent | accepted | rejected | invoiced", quote_total: "euros", project_ref: "the project's name or id in Proyectos", items: "list of the same, for several deals" } }, (i) => link(db, i));
  command2(app, "POST", "/deals/quotes/refresh", { name: "quotes_refresh", summary: "Brings each deal's quote up to date from Invoices (number, state, total). The platform runs it when Invoices changes; nothing to pass." }, () => quotesRefresh(db));
  command2(app, "POST", "/deals/:id/quote", { name: "quote_request", on: "deal", summary: "Asks for this deal's quote: the team's agent makes it in Invoices (trigger presupuesto_por_hacer). Needs Invoices installed.", input: { note: "what the quote should say" } }, (i, { actor }) => quoteRequest(db, i, actor, now()));
  command2(app, "POST", "/steps/propose", { name: "next_steps_propose", summary: "Your proposals, several deals in one call: items [{ deal_id, step, due, why, email: { subject, body } }]. A person accepts or dismisses each.", input: { items: "list of { deal_id, step, due (YYYY-MM-DD), why (what you saw), email: { subject, body, to? } (to the deal's person unless to names someone in the CRM) }" } }, (i, { actor }) => propose(db, i, actor, now()));
  command2(app, "POST", "/steps/:id/accept", { name: "next_step_accept", by: "person", label: { es: "Hacerlo", en: "Take it" }, summary: "A person takes a proposed step: it becomes the deal's next step. A person's decision.", input: { due: "YYYY-MM-DD, to move its date" } }, (i, { actor }) => accept(db, i, actor, now()));
  command2(app, "POST", "/steps/:id/dismiss", { name: "next_step_dismiss", by: "person", label: { es: "Descartar", en: "Dismiss" }, summary: "A person says no to a proposed step; its email goes with it. A person's decision." }, (i) => dismiss(db, i));
  command2(app, "POST", "/steps/set", { name: "next_step_set", summary: "Sets deals' next step directly, as the person decided it: deal_id, step, due \u2014 or items [{ deal_id, step, due }] for several.", input: { deal_id: "deal id", step: "the step", due: "YYYY-MM-DD, today unless said", items: "list of { deal_id, step, due }" } }, (i, { actor }) => set(db, i, actor, now()));
  command2(app, "POST", "/steps/done", { name: "next_step_done", summary: "The deal's next step is done: it goes on the timeline with how it went, and the deal waits for its next one.", input: { deal_id: "deal id", note: "how it went" } }, (i, { actor }) => done(db, i, actor, now()));
  command2(app, "POST", "/emails/sent", { name: "emails_sent", summary: "After sending APPROVED emails from your Gmail: items [{ id, message_id }], or { id, error } when one could not go. It goes on the timeline.", input: { items: "list of { id, message_id } or { id, error }" } }, (i, { actor }) => sentMany(db, i, actor, now()));
  command2(app, "GET", "/emails/:id", { name: "email", summary: "One email whole (to, subject, body, the signature from Ajustes), to send it or to read it." }, (i) => draft(db, i));
  command2(app, "POST", "/emails/:id", { name: "email_update", summary: "Changes an email still to review: subject, body, to. A failed one comes back to review.", input: { subject: "text", body: "text", to: "an email address" } }, (i) => draftUpdate(db, i));
  command2(app, "POST", "/emails/:id/approve", { name: "email_approve", by: "person", label: { es: "Aprobar y enviar", en: "Approve and send" }, summary: "A person's yes to an email: from then the team's agent sends it from its Gmail (trigger correo_aprobado). A person's decision." }, (i, { actor }) => approve(db, i, actor, now()));
  command2(app, "POST", "/emails/:id/drop", { name: "email_drop", by: "person", label: { es: "Descartar", en: "Drop" }, summary: "A person drops an email that has not gone. A person's decision." }, (i) => drop(db, i));
  command2(app, "GET", "/timeline", { name: "timeline", summary: "What happened with a deal, a company or a person, newest first: emails, meetings, calls, notes, stage moves.", input: { deal_id: "deal id", company_id: "company id", contact_id: "person id", limit: "entries, 10 unless said", full: "true for every entry whole" } }, (i, { actor }) => list(db, i, wantsFull(i, actor)));
  command2(app, "POST", "/timeline", { name: "timeline_add", summary: "Adds to the timeline, several in one call: items [{ deal_id | contact_id | company_id | email, type, at, subject, summary, external_id }].", input: { items: "list of { deal_id, contact_id, company_id, email (someone in the CRM), type: email_in | email_out | meeting | call | note, at (ISO date-time), subject, summary (a few lines, never the whole mail), external_id (the mail's or event's id: sent twice, added once) }" } }, (i, { actor }) => add(db, i, actor, now()));
  command2(app, "POST", "/timeline/:id/remove", { name: "timeline_remove", by: "person", summary: "Takes one timeline entry away (a mistake). A person's decision." }, (i) => remove(db, i));
  command2(app, "GET", "/companies", { name: "companies", of: "company", summary: "The companies, the ones with open deals first: people, open deals and value, won value, last contact. q narrows it.", input: { q: "words of its name, domain or sector", limit: "rows, 15 unless said", offset: "rows to skip", full: "true for every field" } }, (i, { actor }) => companies(db, i, wantsFull(i, actor)));
  command2(app, "GET", "/companies/:id", { name: "company", on: "company", summary: "One company: its card, its people, its deals and its last timeline entries.", input: { full: "true for everything its page draws" } }, async (i, { actor }) => companyPage(db, i, wantsFull(i, actor), now()));
  command2(app, "POST", "/companies", { name: "companies_save", summary: "Adds or changes companies, several in one call: items [{ id?, name, website, industry, size, location, summary, tax_id, address, phone, notes }].", input: { items: "list of { id, name, website, domain, industry, size, location, linkedin, summary, tax_id, address, phone, notes, source, remove (true takes it away) }" } }, (i) => saveCompanies(db, i));
  command2(app, "POST", "/companies/merge", { name: "companies_merge", by: "person", label: { es: "Unir con otra", en: "Merge" }, summary: "Two companies that are one client become one: everything moves to keep; drop stays archived, pointing at keep. A person's decision.", input: { keep: "the company id that stays", drop: "the duplicate's id" } }, (i) => merge(db, "company", i));
  command2(app, "GET", "/contacts", { name: "contacts", of: "contact", summary: "The people: everyone, or one company's; status Suggested lists those the mail found. q narrows it.", input: { company_id: "company id", status: "Lead | Contacted | Customer | Lost | Suggested | Ignored", q: "words of the name or email", limit: "rows, 15 unless said", offset: "rows to skip", full: "true for every field" } }, (i, { actor }) => contacts(db, i, wantsFull(i, actor)));
  command2(app, "GET", "/contacts/:id", { name: "contact", on: "contact", summary: "One person: their card, company, deals and last timeline entries.", input: { full: "true for everything their page draws" } }, async (i, { actor }) => contactPage(db, i, wantsFull(i, actor), now()));
  command2(app, "POST", "/contacts", { name: "contacts_save", summary: "Adds or changes people, several in one call: items [{ id?, name, email, phone, title, company or company_id, status, notes }].", input: { items: "list of { id, name, email, phone, title, company (a name; made if new), company_id, status, linkedin, notes, source, remove }" } }, (i) => saveContacts(db, i));
  command2(app, "POST", "/contacts/merge", { name: "contacts_merge", by: "person", label: { es: "Unir con otra", en: "Merge" }, summary: "Two people who are one become one: their deals, timeline, steps and emails move to keep; drop stays archived. A person's decision.", input: { keep: "the person id that stays", drop: "the duplicate's id" } }, (i) => merge(db, "contact", i));
  command2(app, "GET", "/match", { name: "client_match", summary: "Before adding a client: the company (by tax id, website or name) and the person (by email or name) the CRM already has.", input: { name: "company name", tax_id: "NIF / tax id", website: "web or domain", email: "a person's email", contact: "a person's name" } }, async (i) => ({ company: await matchCompany(db, i) ?? void 0, contact_id: i.email || i.contact ? await contactRef(db, { email: i.email, name: i.contact }).catch(() => null) ?? void 0 : void 0 }));
  command2(app, "GET", "/triggers/leads", { name: "leads_to_qualify", summary: "The trigger entrada_por_calificar: each new lead not read yet \u2014 { items: [{ key, text, lead_id, email, company, message }] }." }, () => leadsToQualify(db));
  command2(app, "GET", "/triggers/steps", { name: "deals_needing_step", summary: "The trigger negocio_sin_siguiente_paso: open deals with no next step, a late one or stuck, and no proposal waiting." }, () => dealsNeedingStep(db, now()));
  command2(app, "GET", "/triggers/emails", { name: "emails_to_send", summary: "The trigger correo_aprobado: each email a person approved and has not gone \u2014 { items: [{ key, text, draft_id, deal_id }] }." }, () => emailsToSend(db));
  command2(app, "GET", "/triggers/quotes", { name: "quotes_to_make", summary: "The trigger presupuesto_por_hacer: each deal whose quote a person asked for \u2014 { items: [{ key, text, deal_id, company, kind, amount, \u2026 }] }." }, () => quotesToMake(db));
  command2(app, "GET", "/triggers/won", { name: "won_without_project", summary: "The trigger proyecto_por_abrir: won deals with no project yet, while Proyectos is installed." }, () => wonWithoutProject(db));
  command2(app, "GET", "/exports/clients", { name: "clients", summary: "For other modules: the companies with their main person and email \u2014 { rows: [{ id, name, contact, email, website, tax_id, address }] }.", input: { q: "words of the name" } }, (i) => clients(db, i));
  command2(app, "GET", "/exports/reference", { name: "reference", summary: "For other modules: one company, person or deal by id, as a reference shows it (display name, tax id, address, email). Merged ids lead to the survivor.", input: { company_id: "company id", contact_id: "person id", deal_id: "deal id" } }, async (i) => i.deal_id ? dealReference(db, i) : reference(db, i));
  command2(app, "GET", "/exports/won", { name: "won_deals", summary: "For other modules: the won deals \u2014 { rows: [{ id, title, company_id, company, kind, amount, recurring_amount, recurring_every, closed_at }] }.", input: { since: "YYYY-MM-DD" } }, (i) => wonDeals(db, i));
  command2(app, "GET", "/settings", { name: "settings", of: "config", summary: "The settings: stages (one per line, with %), kinds of service, sources, currency, days until a deal reads stuck, the email signature." }, () => settings(db));
  command2(app, "POST", "/settings/:id", { name: "set_settings", on: "config", by: "admin", partial: true, summary: "Changes the settings: stages (lines \xABPropuesta 60%\xBB, the outcomes marked ganado / perdido), kinds, sources, currency, stuck_days, signature.", input: ["stages", "kinds", "sources", "currency", "stuck_days", "signature"] }, (i) => setSettings(db, i));
}
async function companyPage(db, i, full, now) {
  const c = await db.one(`SELECT * FROM crm_companies WHERE _deleted = 0 AND _id = ?`, [Number(i.id)]);
  if (!c) throw new Refused(`There is no company ${i.id}. companies lists them.`, 404, { code: "NOT_FOUND", item: Number(i.id) });
  const { _id, _created_at, _updated_at, _deleted, removed, enrich_claimed_at, enrich_attempts, legacy_hubspot_id, ...card } = c;
  const people = await contacts(db, { company_id: _id, limit: 50 }, full);
  const deals = await list2(db, { company_id: _id, status: "all", limit: 50 }, full, now);
  const timeline = await list(db, { company_id: _id, limit: full ? 50 : 6 }, full);
  return { id: _id, ...Object.fromEntries(Object.entries(card).filter(([, v]) => v !== null && v !== "")), archived: Number(removed) ? true : void 0, people: people.rows, deals: deals.rows, timeline: timeline.rows };
}
async function contactPage(db, i, full, now) {
  const c = await db.one(`SELECT p.*, c.name AS company FROM crm_contacts p LEFT JOIN crm_companies c ON c._id = p.company_id WHERE p._deleted = 0 AND p._id = ?`, [Number(i.id)]);
  if (!c) throw new Refused(`There is no person ${i.id}. contacts lists them.`, 404, { code: "NOT_FOUND", item: Number(i.id) });
  const { _id, _created_at, _updated_at, _deleted, removed, legacy_hubspot_id, ...card } = c;
  const deals = await list2(db, { contact_id: _id, status: "all", limit: 50 }, full, now);
  const timeline = await list(db, { contact_id: _id, limit: full ? 50 : 6 }, full);
  return { id: _id, ...Object.fromEntries(Object.entries(card).filter(([, v]) => v !== null && v !== "")), archived: Number(removed) ? true : void 0, deals: deals.rows, timeline: timeline.rows };
}
async function dealReference(db, i) {
  const d = await db.one(`SELECT _id, title, status, stage, kind, amount, recurring_amount, recurring_every, closed_at, company_id, contact_id, removed FROM crm_deals WHERE _deleted = 0 AND _id = ?`, [Number(i.deal_id)]);
  if (!d) throw new Refused(`There is no deal ${i.deal_id} in the CRM.`, 404, { code: "NOT_FOUND", item: Number(i.deal_id) });
  const client = d.company_id ? await reference(db, { company_id: d.company_id }).catch(() => null) : d.contact_id ? await reference(db, { contact_id: d.contact_id }).catch(() => null) : null;
  return Object.fromEntries(Object.entries({ kind: "deal", id: d._id, title: d.title, display: client ? `${d.title} \xB7 ${client.name}` : d.title, status: d.status, stage: d.stage, service: d.kind, amount: d.amount, recurring_amount: d.recurring_amount, recurring_every: d.recurring_every, closed_at: d.closed_at, client, archived: Number(d.removed) ? true : void 0 }).filter(([, v]) => v !== null && v !== void 0));
}

// server/app.mjs
function createApp(db, deps = {}) {
  const app = new Hono2();
  mountErrors(app);
  crm_default(app, db, deps);
  return app;
}

// server/db.mjs
function dataClient(url = process.env.APP_DATA_URL, token = process.env.APP_DATA_TOKEN) {
  const call = async (path, body) => {
    const r = await fetch(`${url}${path}`, { method: "POST", headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` }, body: JSON.stringify(body) });
    const j = await r.json().catch(() => null);
    if (!r.ok || !j) throw new Error(j?.error ?? `Data ${r.status}`);
    return j;
  };
  return {
    all: async (sql, params = []) => (await call("/all", { sql, params })).rows,
    one: async (sql, params = []) => (await call("/all", { sql, params })).rows[0] ?? null,
    insert: async (table, data) => (await call("/batch", { ops: [{ op: "insert", table, data }] })).ids[0],
    update: async (table, id, data, where = {}) => (await call("/update", { table, id, data, where })).changed,
    batch: async (ops) => (await call("/batch", { ops })).ids,
    // Which of the modules app.json `suggests` are installed for the company: [{ module, installed, name, version, for, unlocks }].
    // Read when asked, never kept; nothing of the other module is reachable (the guide: «Modules unlock each other»).
    peers: async () => (await call("/peers", {})).peers,
    // One read command another module EXPORTS and app.json `reads` declares: { installed: false } when that module is
    // not installed, else { installed: true, result }. Never its tables, never a write (the guide: «Reading another module»).
    read: async (module, command2, params = {}) => call("/read", { module, command: command2, params })
  };
}

// server/main.mjs
serve({ fetch: createApp(dataClient()).fetch, hostname: "127.0.0.1", port: Number(process.env.PORT) });
