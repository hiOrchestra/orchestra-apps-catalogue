SELECT r._id AS _id, r.to_email AS to_email, r.subject AS subject, r.status AS status, r.error AS error, r.source AS source,
  r.contact_id AS contact_id, r.deal_id AS deal_id, r.approved_by AS approved_by, r.approved_at AS approved_at, r.sent_at AS sent_at,
  r._created_at AS created_at, c.name AS contact, d.title AS deal,
  (SELECT t.why FROM crm_tasks t WHERE t._deleted = 0 AND t.draft_id = r._id ORDER BY t._id DESC LIMIT 1) AS why
FROM crm_drafts r
LEFT JOIN crm_contacts c ON c._id = r.contact_id AND c._deleted = 0
LEFT JOIN crm_deals d ON d._id = r.deal_id AND d._deleted = 0
WHERE r._deleted = 0
