SELECT x.*,
  CASE WHEN x.status = 'Open'
        AND datetime(COALESCE(x.stage_changed_at, x.created_at)) <= datetime('now', '-' || x.stuck_days || ' days')
        AND (x.last_activity_at IS NULL OR datetime(x.last_activity_at) <= datetime('now', '-' || x.stuck_days || ' days'))
       THEN 'yes' ELSE 'no' END AS stuck,
  CASE WHEN x.status = 'Open' AND COALESCE(x.next_step, '') = '' THEN 'yes' ELSE 'no' END AS no_next_step,
  CASE WHEN x.status = 'Open' AND x.next_step_due IS NOT NULL AND x.next_step_due <> '' AND date(x.next_step_due) < date('now') THEN 'yes' ELSE 'no' END AS overdue
FROM (
  SELECT d._id AS _id, d.title AS title, d.stage AS stage, d.status AS status, d.amount AS amount, d.currency AS currency,
    d.owner AS owner, d.expected_close AS expected_close, d.next_step AS next_step, d.next_step_due AS next_step_due,
    d.stage_changed_at AS stage_changed_at, d.closed_at AS closed_at, d.lost_reason AS lost_reason, d.source AS source,
    d._created_at AS created_at, d.company_id AS company_id, d.contact_id AS contact_id,
    co.name AS company, c.name AS contact, c.email AS contact_email,
    COALESCE((SELECT s.stuck_days FROM crm_settings s WHERE s._deleted = 0 ORDER BY s._id LIMIT 1), 14) AS stuck_days,
    (SELECT MAX(datetime(a.at)) FROM crm_activities a
      WHERE a._deleted = 0 AND (a.deal_id = d._id OR (d.contact_id IS NOT NULL AND a.contact_id = d.contact_id) OR (d.company_id IS NOT NULL AND a.company_id = d.company_id))
        AND a.type <> 'stage' AND datetime(a.at) <= datetime('now')) AS last_activity_at
  FROM crm_deals d
  LEFT JOIN crm_companies co ON co._id = d.company_id AND co._deleted = 0
  LEFT JOIN crm_contacts c ON c._id = d.contact_id AND c._deleted = 0
  WHERE d._deleted = 0
) x
