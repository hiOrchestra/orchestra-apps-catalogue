SELECT co._id AS _id, co.name AS name, co.domain AS domain, co.industry AS industry, co.size AS size, co.location AS location,
  co.owner AS owner, co.tags AS tags, co.source AS source, co.enriched_at AS enriched_at, co.enrich_status AS enrich_status,
  co._created_at AS created_at,
  (SELECT COUNT(*) FROM crm_contacts c WHERE c._deleted = 0 AND c.company_id = co._id AND c.status NOT IN ('Suggested', 'Ignored')) AS contacts,
  (SELECT COUNT(*) FROM crm_deals d WHERE d._deleted = 0 AND d.company_id = co._id AND d.status = 'Open') AS open_deals,
  (SELECT COALESCE(SUM(d.amount), 0) FROM crm_deals d WHERE d._deleted = 0 AND d.company_id = co._id AND d.status = 'Open') AS open_amount,
  (SELECT MAX(c.last_activity_at) FROM crm_contacts c WHERE c._deleted = 0 AND c.company_id = co._id) AS last_activity_at
FROM crm_companies co
WHERE co._deleted = 0
