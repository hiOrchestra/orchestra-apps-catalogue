SELECT t._id AS _id, t.title AS title, t.due AS due, t.status AS status, t.why AS why, t.owner AS owner, t.source AS source,
  t.deal_id AS deal_id, t.contact_id AS contact_id, t.draft_id AS draft_id,
  d.title AS deal, d.stage AS stage, c.name AS contact, c.email AS contact_email,
  r.status AS draft_status, r.subject AS draft_subject,
  CASE WHEN t.due IS NULL OR t.due = '' THEN 'none'
       WHEN date(t.due) < date('now') THEN 'overdue'
       WHEN date(t.due) = date('now') THEN 'today'
       ELSE 'later' END AS due_state
FROM crm_tasks t
LEFT JOIN crm_deals d ON d._id = t.deal_id AND d._deleted = 0
LEFT JOIN crm_contacts c ON c._id = t.contact_id AND c._deleted = 0
LEFT JOIN crm_drafts r ON r._id = t.draft_id AND r._deleted = 0
WHERE t._deleted = 0 AND t.status IN ('Suggested', 'Open')
