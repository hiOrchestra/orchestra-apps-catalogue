// One deal, in its panel: where it stands (stage, value, people), its next
// step, what is open on it (tasks, emails), and everything that happened.
// From here it moves stage, is won or lost (with the reason), gets a next
// step, a task, a note or an email.
import { C, T, A, act, badge, money, dayOf, ago, field, input, area, select, formDialog, settings, openStages, outcome,
  contactLink, companyLink, today } from '../data.js';
import { timeline, timelineView, noteBox, tools, facts } from './record.js';
import { openDraft } from './drafts.js';
import { dealForm } from './deal-form.js';

const { el } = Orch;

export async function dealPanel(row, again) {
  const s = await settings();
  const [contact, company, tasks, drafts, acts] = await Promise.all([
    row.contact_id ? Orch.db.get(T.contacts, row.contact_id) : null,
    row.company_id ? Orch.db.get(T.companies, row.company_id) : null,
    Orch.db.list(T.tasks, { filter: { deal_id: row._id, status: ['Open', 'Suggested'] }, sort: 'due:asc', limit: 20 }),
    Orch.db.list(T.drafts, { filter: { deal_id: row._id, status: ['Review', 'Failed', 'Approved'] }, sort: '_id:desc', limit: 20 }),
    timeline({ deal: row._id, contact: row.contact_id }),
  ]);
  const ids = { deal_id: row._id, contact_id: row.contact_id || undefined, company_id: row.company_id || undefined };
  const refresh = () => again();
  return el('div', { class: 'oc-stack crm-panel' }, [
    el('div', { class: 'oc-row oc-row--between' }, [
      el('div', { class: 'oc-stack oc-stack--tight' }, [
        el('h2', { class: 'oc-h1 crm-panel__title' }, row.title || 'Deal'),
        el('p', { class: 'oc-eyebrow' }, `${row.stage} · in this stage since ${dayOf(row.stage_changed_at)}`),
      ]),
      badge(row.status),
    ]),
    facts([
      ['Value', row.amount ? el('span', { class: 'oc-value' }, money(row.amount, row.currency, s)) : null],
      ['Company', company ? companyLink(company._id, company.name) : null],
      ['Contact', contact ? [contactLink(contact._id, contact.name || contact.email), contact.title ? ` · ${contact.title}` : ''] : null],
      ['Owner', row.owner], ['Expected close', row.expected_close ? dayOf(row.expected_close) : null],
      ['Lost because', row.status === 'Lost' ? row.lost_reason : null], ['Source', row.source],
    ]),
    row.status === 'Open' ? nextStep(row, refresh) : null,
    stageControls(row, s, ids, refresh),
    open(tasks.rows || [], drafts.rows || [], refresh),
    tools(ids, contact && C.isEmail(contact.email) ? contact.email : null, refresh),
    noteBox(ids, refresh),
    el('h3', { class: 'oc-h2' }, 'What happened'),
    timelineView(acts),
  ]);
}

function nextStep(row, refresh) {
  const late = row.next_step_due && row.next_step_due < today();
  const plan = el('button', { class: 'oc-btn oc-btn--sm', type: 'button' }, row.next_step ? 'Change' : 'Plan the next step');
  plan.addEventListener('click', () => {
    const what = input(row.next_step || '', { maxlength: '140' });
    const due = input(row.next_step_due || today(2), { type: 'date' });
    formDialog('Next step', [field('What happens next', what, 'One thing that moves the deal forward. The agent suggests one for deals without it.'), field('By', due)], async () => {
      const ok = await act(A.editDeal, { id: row._id, next_step: what.value.trim(), next_step_due: what.value.trim() ? due.value : '' }, 'Saved.');
      if (ok) refresh();
      return ok;
    });
  });
  return el('div', { class: 'crm-next' }, [
    el('span', { class: 'oc-eyebrow' }, 'Next step'),
    el('div', { class: 'oc-row oc-row--between' }, [
      row.next_step ? el('span', {}, [row.next_step, row.next_step_due ? el('span', { class: 'oc-value oc-muted' }, ` · ${dayOf(row.next_step_due)}`) : null]) : el('span', { class: 'oc-muted' }, 'None yet'),
      el('div', { class: 'oc-row' }, [late ? badge('Late', 'warn') : null, plan]),
    ]),
  ]);
}

function stageControls(row, s, ids, refresh) {
  const params = (extra) => Object.assign({ id: row._id, contact_id: ids.contact_id, company_id: ids.company_id }, extra);
  if (row.status !== 'Open') {
    const reopen = el('button', { class: 'oc-btn oc-btn--sm', type: 'button' }, 'Reopen');
    reopen.addEventListener('click', () => {
      const st = select(openStages(s).map((x) => x.name), openStages(s).slice(-1)[0].name);
      formDialog('Reopen the deal', [field('Back to stage', st)], async () => {
        const ok = await act(A.reopen, params({ stage: st.value, stage_note: 'Reopened' }), 'Reopened.');
        if (ok) refresh();
        return ok;
      }, 'Reopen');
    });
    return el('div', { class: 'oc-row' }, [el('span', { class: 'oc-help' }, `${row.status} ${row.closed_at ? ago(row.closed_at) : ''}.`), reopen, edit(row, refresh)]);
  }
  const move = select([['', 'Move to…'], ...openStages(s).filter((x) => x.name !== row.stage).map((x) => [x.name, x.name])], '', { 'aria-label': 'Move to another stage' });
  move.addEventListener('change', async () => {
    if (!move.value) return;
    if (await act(A.moveDeal, params({ stage: move.value }), `Moved to ${move.value}.`)) refresh();
  });
  const won = el('button', { class: 'oc-btn oc-btn--sm', type: 'button' }, 'Won');
  won.addEventListener('click', async () => {
    if (!(await Orch.confirm(ids.contact_id ? `Mark "${row.title}" as won? Its contact becomes a Customer.` : `Mark "${row.title}" as won?`, { yes: 'Won' }))) return;
    // With a contact, the same write makes them a Customer. Without one, the
    // action that has no contact step: a step with no id would fall back to
    // the deal's id and touch the wrong contact.
    if (await act(ids.contact_id ? A.win : A.winAlone, params({ stage: outcome(s, 'won').name, stage_note: 'Won' }), 'Won. Well done.')) refresh();
  });
  const lost = el('button', { class: 'oc-btn oc-btn--sm', type: 'button' }, 'Lost');
  lost.addEventListener('click', () => {
    const why = area('', 3, { required: true, placeholder: 'Price, timing, went with another vendor…' });
    formDialog('Why was it lost?', [field('Reason', why, 'Kept on the deal, so the team can see why deals are lost.')], async () => {
      const ok = await act(A.lose, params({ stage: outcome(s, 'lost').name, lost_reason: why.value.trim(), stage_note: why.value.trim().slice(0, 200) }), 'Marked as lost.');
      if (ok) refresh();
      return ok;
    }, 'Mark as lost');
  });
  return el('div', { class: 'oc-row' }, [move, won, lost, edit(row, refresh)]);
}

function edit(row, refresh) {
  return el('button', { class: 'oc-btn oc-btn--sm oc-btn--ghost', type: 'button', onClick: () => dealForm(row, refresh) }, 'Edit');
}

function open(tasks, drafts, refresh) {
  if (!tasks.length && !drafts.length) return null;
  return el('ul', { class: 'crm-rows crm-rows--flush' }, [
    ...tasks.map((t) => el('li', { class: 'crm-row' }, [
      el('div', { class: 'crm-row__main' }, [el('span', {}, t.title), t.why ? el('span', { class: 'oc-help' }, t.why) : null]),
      el('span', { class: 'oc-value' }, dayOf(t.due)), badge(t.status === 'Suggested' ? 'Suggested' : 'Task', t.status === 'Suggested' ? 'warn' : ''),
      t.status === 'Open' ? el('button', { class: 'oc-btn oc-btn--sm', type: 'button', onClick: async () => { if (await act(A.doneTask, { id: t._id }, 'Done.')) refresh(); } }, 'Done')
        : el('span', { class: 'oc-small oc-muted' }, 'decide on Today'),
    ])),
    ...drafts.map((d) => el('li', { class: 'crm-row' }, [
      el('div', { class: 'crm-row__main' }, [el('span', {}, d.subject || '(no subject)'), el('span', { class: 'oc-small oc-muted' }, `To ${d.to_email}`)]),
      el('span'), badge(d.status),
      el('button', { class: 'oc-btn oc-btn--sm', type: 'button', onClick: () => openDraft(d._id, refresh) }, d.status === 'Failed' ? 'Fix it' : 'Open'),
    ])),
  ]);
}
