// Settings for the pipeline: its stages (name and probability, in order, and
// the names of the two outcomes). The team's lists are managed in Orchestra.
import { T, field, input } from '../data.js';
import { card, saving } from './settings.js';

const { el, fmt } = Orch;

export function pipelineCard(s, again) {
  const rows = s.stageList.filter((x) => !x.outcome).map((x) => ({ name: x.name, probability: x.probability, was: x.name }));
  const won = s.stageList.find((x) => x.outcome === 'won');
  const lost = s.stageList.find((x) => x.outcome === 'lost');
  const list = el('ol', { class: 'crm-stages' });
  const counts = {};
  const draw = () => Orch.mount(list, rows.map((r, i) => {
    const name = input(r.name, { maxlength: '40', required: true, 'aria-label': `Stage ${i + 1} name` });
    const prob = input(r.probability, { type: 'number', min: '0', max: '100', step: '5', 'aria-label': `Stage ${i + 1} probability`, class: 'oc-input crm-stages__prob' });
    name.addEventListener('input', () => { r.name = name.value; });
    prob.addEventListener('input', () => { r.probability = Number(prob.value) || 0; });
    const up = el('button', { class: 'oc-btn oc-btn--sm oc-btn--ghost', type: 'button', 'aria-label': 'Move up', disabled: i === 0 }, '↑');
    up.addEventListener('click', () => { [rows[i - 1], rows[i]] = [rows[i], rows[i - 1]]; draw(); });
    const drop = el('button', { class: 'oc-btn oc-btn--sm oc-btn--ghost', type: 'button', disabled: rows.length < 2 || counts[r.was] > 0,
      title: counts[r.was] ? 'Move its deals to another stage first' : '' }, 'Remove');
    drop.addEventListener('click', () => { rows.splice(i, 1); draw(); });
    return el('li', { class: 'crm-stages__row' }, [name, prob, el('span', { class: 'oc-small oc-muted' }, counts[r.was] ? `${fmt.number(counts[r.was])} open` : '%'), up, drop]);
  }));
  const add = el('button', { class: 'oc-btn oc-btn--sm', type: 'button' }, 'Add a stage');
  add.addEventListener('click', () => { rows.push({ name: '', probability: 50, was: null }); draw(); });
  const wonName = input(won.name, { maxlength: '40' });
  const lostName = input(lost.name, { maxlength: '40' });
  Orch.db.count(T.deals, { filter: { status: 'Open' }, group: 'stage' }).then((r) => { for (const g of r.groups || []) counts[g.value] = g.count; draw(); }).catch(draw);
  draw();
  return card('Pipeline stages', null,
    'The stages an open deal goes through, in order, with how likely a deal in each is to close (for the weighted value). A stage with open deals cannot be removed; renaming one does not move its deals.', [
      saving([list, el('div', { class: 'oc-row' }, add), el('div', { class: 'crm-two' }, [field('Won is called', wonName), field('Lost is called', lostName)])], () => {
        const clean = rows.map((r) => ({ name: String(r.name || '').trim(), probability: Math.max(0, Math.min(100, Number(r.probability) || 0)) })).filter((r) => r.name);
        const names = [...clean.map((r) => r.name), wonName.value.trim(), lostName.value.trim()];
        if (!clean.length || names.some((n) => !n) || new Set(names.map((n) => n.toLowerCase())).size !== names.length) {
          Orch.toast('Every stage needs a name, and no two the same.', { error: true });
          return null;
        }
        const stages = [...clean.map((r, i) => ({ name: r.name, probability: r.probability, order: i + 1 })),
          { name: wonName.value.trim(), probability: 100, order: clean.length + 1, outcome: 'won' }, { name: lostName.value.trim(), probability: 0, order: clean.length + 2, outcome: 'lost' }];
        return { id: s._id, stages: JSON.stringify(stages) };
      }, again, 'Stages saved.'),
    ]);
}
