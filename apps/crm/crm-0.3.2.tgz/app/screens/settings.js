// Settings. The pause and the pipeline's stages are kept here; what can be typed —
// mail and calendar sync, when the agent suggests next steps and how many emails
// may leave a day, signature, owners, sources, currency, leads from Forms — is
// managed in Orchestra (Apps → CRM → Ajustes), next to its connections and who
// does its work. Here, what each is now, a way there, and the buttons that run
// things now. The stages are in settings-pipeline.js.
import { C, A, act, head, badge, ago, stamp, settings, runButton } from '../data.js';
import { pipelineCard } from './settings-pipeline.js';

const { el, router } = Orch;
const ZONES = ['UTC', 'Europe/Madrid', 'Europe/London', 'Europe/Lisbon', 'Europe/Paris', 'Europe/Berlin', 'America/New_York', 'America/Chicago', 'America/Denver',
  'America/Los_Angeles', 'America/Mexico_City', 'America/Bogota', 'America/Lima', 'America/Santiago', 'America/Argentina/Buenos_Aires', 'America/Sao_Paulo',
  'Asia/Dubai', 'Asia/Kolkata', 'Asia/Singapore', 'Asia/Tokyo', 'Australia/Sydney'];

export function render() {
  Orch.load('view', async () => {
    const s = await settings(true);
    const again = () => render();
    return el('div', { class: 'oc-stack oc-stack--loose crm-settings' }, [
      head('Settings', 'How the CRM works for your team: what it reads, what the agent does, and what may leave.'),
      pause(s, again), managed(), sync(s, again), suggest(s), pipelineCard(s, again), team(s), enrich(s), forms(s, again), hubspot(s, again),
    ]);
  });
}

/** A settings card: its heading and state on one line, what it is for, then its form. */
export function card(title, state, help, body) {
  return el('section', { class: 'oc-card oc-stack' }, [
    el('div', { class: 'oc-row oc-row--between' }, [el('h2', { class: 'oc-h2' }, title), state || null]),
    help ? el('p', { class: 'oc-help' }, help) : null, ...[].concat(body || []),
  ]);
}

/** A form that saves some settings with the one settings action. */
export function saving(fields, values, again, said = 'Saved.') {
  const save = el('button', { class: 'oc-btn oc-btn--primary', type: 'submit' }, 'Save');
  const form = el('form', { class: 'oc-stack crm-form' }, [...fields, el('div', { class: 'oc-row' }, save)]);
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const v = values();
    if (!v) return;
    save.disabled = true;
    if (await act(A.settings, v, said)) again();
    save.disabled = false;
  });
  return form;
}
const onOff = (v) => (Number(v) === 1 ? 'on' : 'off');
const facts = (list) => el('ul', { class: 'oc-stack' }, list.map(([k, v]) => el('li', [el('b', `${k}: `), String(v)])));

/** Where the typed settings are changed: Orchestra, one link. */
function managed() {
  const link = el('a', { class: 'oc-btn oc-btn--primary', target: '_blank', rel: 'noopener', hidden: true }, 'Open the settings in Orchestra');
  const where = el('p', { class: 'oc-help' }, 'In Orchestra: Apps → CRM → Ajustes.');
  if (Orch.manageUrl) Orch.manageUrl('settings').then((url) => { if (url) { link.href = url; link.hidden = false; where.hidden = true; } });
  return card('Managed in Orchestra', null,
    'Mail and calendar sync, when next steps are suggested, emails a day, the signature, owners, sources, currency and leads from Forms are changed in Orchestra, with the Gmail, Calendar and HubSpot connections and the agent that does the work.',
    [el('div', { class: 'oc-row' }, link), where]);
}

function pause(s, again) {
  const paused = Number(s.paused) === 1;
  const b = el('button', { class: `oc-btn${paused ? ' oc-btn--primary' : ''}`, type: 'button' }, paused ? 'Resume' : 'Pause everything');
  b.addEventListener('click', async () => {
    if (!paused && !(await Orch.confirm('Pause the CRM? Sync, suggestions and enrichment stop, and approved emails wait until you resume.', { yes: 'Pause' }))) return;
    if (await act(A.pause, { id: s._id, paused: paused ? 0 : 1 }, paused ? 'Resumed: approved emails go out now.' : 'Paused.')) again();
  });
  return card('Pause', badge(paused ? 'Paused' : 'Running', paused ? 'warn' : 'good'),
    'Stops everything that runs on its own and holds every approved email. Nothing is lost: it all continues when you resume.', el('div', { class: 'oc-row' }, b));
}

function sync(s, again) {
  const on = Number(s.sync_gmail) === 1 || Number(s.sync_calendar) === 1;
  const seen = [
    s.gmail_address ? `Mailbox ${s.gmail_address}` : null,
    `Mail read ${s.gmail_synced_at ? ago(s.gmail_synced_at) : 'never'}`, `Calendar read ${s.calendar_synced_at ? ago(s.calendar_synced_at) : 'never'}`,
  ].filter(Boolean).join(' · ');
  return card('Mail and calendar', badge(on ? 'On' : 'Off', on ? 'good' : ''),
    'Reads your Gmail and Google Calendar every half hour: mail and meetings with your contacts land on their timeline, and new people who write from company addresses are suggested in Contacts. Read only: it never sends, moves or deletes anything there.', [
      el('p', { class: 'oc-eyebrow' }, seen),
      s.sync_note ? el('p', { class: 'crm-error' }, s.sync_note) : null,
      facts([['Gmail', onOff(s.sync_gmail)], ['Google Calendar', onOff(s.sync_calendar)], ['The first time, go back', `${s.sync_days_back || 30} days`]]),
      el('div', { class: 'oc-row' }, runButton('Sync now', A.syncNow, 'Reading your mail and calendar now.', { after: again, wait: 5000 })),
    ]);
}

function suggest(s) {
  return card('Next steps and emails', null,
    'Once a day the agent looks at open deals with no next step, a late one, or no activity for a while, and suggests a step and, when it fits, an email. They wait on Today for you; nothing is sent until you approve it.', [
      el('p', { class: 'oc-eyebrow' }, `Last ${s.last_suggest_at ? stamp(s.last_suggest_at) : 'never'} · next ${s.next_suggest_at ? stamp(s.next_suggest_at) : 'not set'}`),
      s.suggest_note ? el('p', { class: 'oc-help' }, s.suggest_note) : null,
      facts([['Every day at', `${String(s.suggest_hour ?? 8).padStart(2, '0')}:00 (${s.timezone || 'UTC'})`], ['Deals per day', s.suggest_per_run || 8],
        ['Emails a day', s.daily_send_cap || 40], ['Signature', s.signature ? 'set' : 'none']]),
      s.send_note ? el('p', { class: 'oc-help' }, s.send_note) : null,
      el('p', { class: 'oc-help' }, ['To ask for suggestions now, use Suggest now on ', router.link('/', 'Today'), '.']),
    ]);
}

function team(s) {
  return card('Team and lists', null, 'Who owns deals, where leads come from, the currency values are shown in, and when a deal counts as stuck.', [
    facts([['Owners', C.linesOf(s.owners).join(', ') || 'none'], ['Sources', C.linesOf(s.sources).join(', ') || 'none'],
      ['Currency', s.currency || 'EUR'], ['Stuck after', `${s.stuck_days || 14} days`]]),
  ]);
}

function enrich(s) {
  return card('Company research', null,
    'When a company is added, the agent looks it up on the web and fills in industry, size, location, a short summary and LinkedIn, with the pages it read. It never overwrites what you typed. A few companies per hour, only when one is waiting.', [
      el('p', { class: 'oc-eyebrow' }, `${s.enrich_per_run || 5} per run`),
      s.enrich_note ? el('p', { class: 'oc-help' }, s.enrich_note) : null,
      el('p', { class: 'oc-help' }, ['To look one up again, open it in ', router.link('/companies', 'Companies'), '.']),
    ]);
}

function forms(s, again) {
  const on = Number(s.forms_intake) === 1;
  return card('Leads from Forms', badge(on ? 'On' : 'Off', on ? 'good' : ''),
    'Every complete answer to a Forms form that gives an email becomes a contact (or updates one), with what they answered on their timeline. Needs the Forms app in this workspace.', [
      s.forms_note ? el('p', { class: 'oc-help' }, s.forms_note) : null,
      el('div', { class: 'oc-row' }, runButton('Check Forms now', A.formsNow, 'Looking for new answers now.', { after: again, wait: 4000 })),
    ]);
}

function hubspot(s, again) {
  const st = s.hubspot_status || 'Never';
  const b = el('button', { class: 'oc-btn', type: 'button' }, st === 'Never' ? 'Import from HubSpot' : st === 'Failed' ? 'Continue the import' : 'Import again');
  b.addEventListener('click', async () => {
    if (!(await Orch.confirm('Copy companies, contacts and deals from the HubSpot account connected to this workspace? It only reads HubSpot. Importing again updates what came before instead of duplicating it.', { yes: 'Import' }))) return;
    b.disabled = true;
    if (await act(A.importHubspot, {}, 'Importing. Big accounts take a few runs; this card says how it goes.')) setTimeout(again, 5000);
  });
  return card('Import from HubSpot', badge(st === 'Never' ? 'Not yet' : st === 'Partial' ? 'Under way' : st, { Done: 'good', Failed: 'bad', Partial: 'accent' }[st]),
    'A one-time copy of your HubSpot companies, contacts and deals, with their links. Connect HubSpot first in the portal, under Integrations.', [
      s.hubspot_note ? el('p', { class: st === 'Failed' ? 'crm-error' : 'oc-help' }, s.hubspot_note) : null,
      s.hubspot_at ? el('p', { class: 'oc-eyebrow' }, `Last finished ${stamp(s.hubspot_at)}`) : null,
      el('div', { class: 'oc-row' }, b),
    ]);
}
