// CRM, installed into one project of this instance: tables and indexes, the
// settings row (only into an empty table), the automations (scripts,
// workflows and their schedules, each running only when there is work), and
// the desk `crm` with its grants, views, actions, brand and brief.
// Converges: run it again after a change and it ends in the same state.
//
//   as node, by the team over ssh:        gosu node node install.js <bundle> --project default --agent leila
//   as the project's agent, over the MCP: projects.run → node <bundle>/install.js <bundle> --project default --agent leila
// Over the MCP each call has 120 s: run it in parts with --only (in this order):
//   --only files,tables,seed  ·  --only workflows,schedule  ·  --only desk,settings
// --agent is the project member the scripts run as, and who enriches companies
// and suggests next steps. Prints one JSON line per step, and at the end what a
// person still has to do.
'use strict';
const { execFileSync } = require('child_process');
const fs = require('fs');
const path = require('path');

const B = path.resolve(process.argv[2] || __dirname);
const flag = (name, fallback) => { const i = process.argv.indexOf(`--${name}`); return i > 0 && process.argv[i + 1] ? process.argv[i + 1] : fallback; };
const PROJECT = flag('project', 'default');
const AGENT = flag('agent', '');
const ONLY = new Set((flag('only', 'files,tables,seed,workflows,schedule,desk,settings')).split(','));
const STATE = process.env.OPENCLAW_STATE_DIR || '/home/node/.openclaw';
const HOME = path.join(STATE, 'orchestra', 'projects', PROJECT);
const AUTO = path.join(HOME, 'apps', 'crm', 'automations');
const read = (f) => fs.readFileSync(path.join(B, f), 'utf8');
const json = (f) => JSON.parse(read(f));
const todo = [];
const out = (step, data) => console.log(JSON.stringify(Object.assign({ step }, data)));
const C = require(path.join(B, 'automations', 'crmcore.js'));

function cli(bin, args, { soft = false } = {}) {
  let text;
  try {
    text = execFileSync(bin, args, { encoding: 'utf8', timeout: 100000, maxBuffer: 32 << 20 });
  } catch (e) {
    text = String(e.stdout || '') || String(e.stderr || e.message);
    if (!soft) out('warn', { bin, args: args.slice(0, 3), said: text.trim().slice(0, 300) });
  }
  try { return JSON.parse(text); } catch { return { raw: String(text).trim().slice(0, 600) }; }
}
const db = (...a) => cli('orch-database', ['--project', PROJECT, ...a]);
const canvas = (...a) => cli('orch-canvas', a);
const wf = (...a) => cli('orch-workflows', a);
const pick = (o, keys) => Object.fromEntries(keys.filter((k) => o && o[k] !== undefined).map((k) => [k, o[k]]));
const ids = () => { try { return JSON.parse(fs.readFileSync(path.join(AUTO, '..', 'workflows.json'), 'utf8')); } catch { return {}; } };
const hasForms = () => ((db('query', "SELECT COUNT(*) AS n FROM sqlite_master WHERE type = 'table' AND name = 'forms_responses'").rows || [{}])[0] || {}).n > 0;

// Each workflow, and when it runs on its own: only while its .where is true on the settings row.
const WORKFLOWS = ['sync', 'link', 'enrich', 'suggest', 'send', 'forms', 'hubspot'];
const SCHEDULES = [
  ['sync', '*/30 * * * *', 'CRM · Sync mail and calendar (half-hourly, while sync is on)'],
  ['forms', '*/30 * * * *', 'CRM · Leads from Forms (half-hourly, when Forms has new responses)'],
  ['enrich', '17 * * * *', 'CRM · Enrich companies (hourly, when one is waiting)'],
  ['suggest', '5 * * * *', 'CRM · Suggest next steps (daily at the hour in Settings, when a deal needs one)'],
  ['send', '23 * * * *', 'CRM · Send approved emails (hourly, for what waited on a pause)'],
  ['hubspot', '41 * * * *', 'CRM · Import from HubSpot (hourly, while an import is under way)'],
];

// ── 1. the automation scripts ────────────────────────────────────────────
if (ONLY.has('files')) {
  fs.mkdirSync(AUTO, { recursive: true });
  for (const f of fs.readdirSync(path.join(B, 'automations'))) fs.copyFileSync(path.join(B, 'automations', f), path.join(AUTO, f));
  out('files', { dir: AUTO, files: fs.readdirSync(AUTO) });
}

// ── 2. tables and indexes ────────────────────────────────────────────────
const schema = json('schema.json');
if (ONLY.has('tables')) {
  for (const [table, cols] of Object.entries(schema.tables)) {
    out('table', Object.assign({ table }, pick(db('ensure-table', table, '--columns', ...cols), ['ok', 'action', 'created', 'added', 'error', 'raw'])));
  }
  for (const sql of schema.indexes) out('index', Object.assign({ sql: sql.slice(0, 80) }, pick(db('sql', sql, '--confirm'), ['ok', 'error', 'raw'])));
}

// ── 3. the settings row, only into an empty table ────────────────────────
if (ONLY.has('seed')) {
  const count = (t) => (((db('query', `SELECT COUNT(*) AS n FROM ${t} WHERE _deleted = 0`).rows || [{}])[0]) || {}).n;
  for (const [table, rows] of Object.entries(json('seed.json'))) {
    if (count(table) > 0) { out('seed', { table, left: 'it has rows' }); continue; }
    const data = rows.map((r) => Object.fromEntries(Object.entries(r).map(([k, v]) => [k, v !== null && typeof v === 'object' ? JSON.stringify(v) : v])));
    if (table === 'crm_settings') Object.assign(data[0], { enrich_agent: AGENT || null, next_suggest_at: C.sqlTime(C.nextAt(data[0].suggest_hour, data[0].timezone)) });
    out('seed', Object.assign({ table }, pick(db('insert-many', table, '--data', JSON.stringify(data)), ['ok', 'count', 'inserted', 'error', 'raw'])));
  }
}

// ── 4. workflows (by name: created once, updated after) ─────────────────
if (ONLY.has('workflows')) {
  if (!AGENT) throw new Error('--agent <id> names the project member the scripts run as, who also enriches companies and suggests next steps');
  const existing = wf('list').workflows || [];
  const WF = {};
  const tmp = fs.mkdtempSync('/tmp/crm-wf-');
  for (const key of WORKFLOWS) {
    // runsAs: the scripts run as this agent (orch-as), so it must be a member of the project to reach its database.
    const spec = Object.assign(JSON.parse(read(`workflows/${key}.json`).replace(/__AUTO__/g, AUTO).replace(/__AGENT__/g, AGENT)),
      { project: PROJECT, runsAs: AGENT });
    const file = path.join(tmp, `${key}.json`);
    fs.writeFileSync(file, JSON.stringify(spec));
    const found = existing.find((w) => w.name === spec.name);
    const r = found ? wf('update', found.id, '--file', file) : wf('create', '--file', file);
    WF[key] = found ? found.id : ((r.workflow && r.workflow.id) || r.id || r.workflowId);
    out('workflow', { name: spec.name, id: WF[key], did: found ? 'updated' : 'created', error: r.error || undefined });
  }
  fs.rmSync(tmp, { recursive: true, force: true });
  fs.mkdirSync(path.join(AUTO, '..'), { recursive: true });
  fs.writeFileSync(path.join(AUTO, '..', 'workflows.json'), JSON.stringify(WF, null, 1));
}

// ── 5. schedules: dropped and made again, each gated by its .where ──────
if (ONLY.has('schedule')) {
  const WF = ids();
  const forms = hasForms();
  for (const [key, cron, name] of SCHEDULES) {
    for (const s of (wf('schedules', WF[key]).schedules || [])) out('unschedule', Object.assign({ key }, pick(wf('unschedule', s.jobId), ['ok', 'error'])));
    if (key === 'forms' && !forms) {
      out('schedule', { key, skipped: 'Forms is not installed in this project: install Forms, then run this again' });
      continue;
    }
    out('schedule', Object.assign({ key }, pick(wf('schedule', WF[key], '--cron', cron, '--timezone', 'UTC', '--name', name,
      '--table', 'crm_settings', '--where', read(`workflows/${key}.where`), '--limit', '1'), ['ok', 'jobId', 'schedule', 'error', 'raw'])));
  }
}

// ── 6. the desk ──────────────────────────────────────────────────────────
function app(id, src, brief) {
  let a = (canvas('list').apps || []).find((x) => x.id === id);
  if (!a) {
    out('init', Object.assign({ app: id }, pick(canvas('init', id, '--project', PROJECT, '--pattern', 'board', '--confirmed', ...brief), ['ok', 'dir', 'url', 'error', 'raw'])));
    a = (canvas('list').apps || []).find((x) => x.id === id);
  }
  if (!a) throw new Error(`The app ${id} could not be created`);
  const dir = path.join(STATE, 'orchestra', a.dir);
  const ours = new Set();
  const copy = (from, to) => {
    for (const f of fs.readdirSync(from)) {
      const s = path.join(from, f);
      const d = path.join(to, f);
      if (fs.statSync(s).isDirectory()) { fs.mkdirSync(d, { recursive: true }); copy(s, d); } else { fs.copyFileSync(s, d); ours.add(path.relative(dir, d)); }
    }
  };
  copy(path.join(B, src), dir);
  // What the starter wrote and the CRM does not use goes, so the app is exactly the source.
  const sweep = (d) => {
    for (const f of fs.readdirSync(d)) {
      const p = path.join(d, f);
      const rel = path.relative(dir, p);
      if (rel.startsWith('_') || rel.startsWith('.')) continue;
      if (fs.statSync(p).isDirectory()) sweep(p); else if (!ours.has(rel)) { fs.unlinkSync(p); out('removed', { app: id, file: rel }); }
    }
  };
  sweep(dir);
  out('files', { app: id, dir, count: ours.size });
  return a;
}

function actions(id, list) {
  const WF = ids();
  const sub = (v) => (typeof v === 'string' && v.startsWith('$WF_') ? WF[v.slice(4).toLowerCase()] : v);
  for (const a of list) {
    const args = ['action', 'add', id, '--name', a.name, '--type', a.type, '--access', a.access || 'members'];
    if (a.table) args.push('--table', a.table);
    if (a.fields) args.push('--fields', a.fields.join(','));
    if (a.defaults) args.push('--defaults', JSON.stringify(a.defaults));
    if (a.precondition) args.push('--precondition', JSON.stringify(a.precondition));
    if (a.bulk) args.push('--bulk');
    if (a.steps) args.push('--steps', JSON.stringify(a.steps));
    if (a.workflow) args.push('--workflow', sub(a.workflow));
    if (a.args) args.push('--args', JSON.stringify(a.args));
    if (a.trigger) args.push('--trigger-workflow', sub(a.trigger));
    out('action', Object.assign({ app: id, name: a.name }, pick(canvas(...args), ['ok', 'error', 'raw'])));
  }
}

if (ONLY.has('desk')) {
  app('crm', 'app', ['--name', 'CRM', '--icon', '🤝', '--desc', 'Your companies, people and deals, with the agent doing the busywork: it fills in companies, logs mail and meetings, and proposes the next step',
    '--user', 'Founders and the sales team of a small company',
    '--frequency', 'Every day',
    '--question', 'Who do I need to talk to today, and why?',
    '--question', 'What stage is each deal in, and which one is stuck?',
    '--question', 'What happened with this person or company: emails, meetings, forms, notes?',
    '--primary-action', 'Do (or approve) the next step on a deal']);
  const grants = Object.keys(schema.tables).map((t) => `${t}:action`);
  // One --grant with every table: the flag is nargs="*", so repeating it keeps only the last.
  const g = canvas('grants', 'set', 'crm', '--grant', ...grants);
  out('grants', Object.assign({ app: 'crm' }, pick(g, ['ok', 'grants', 'pendingApproval', 'error', 'raw'])));
  if ((g.pendingApproval || []).length) todo.push(`Approve the tables the CRM asks for: ${g.pendingApproval.map((x) => x.table || x).join(', ')} (Canvas → CRM → who gets in)`);
  for (const f of fs.readdirSync(path.join(B, 'sql'))) {
    const r = canvas('view', 'add', 'crm', '--name', f.replace(/\.sql$/, ''), '--sql-file', path.join(B, 'sql', f), '--description', f.replace(/\.sql$/, '').replace(/_/g, ' '));
    out('view', Object.assign({ app: 'crm', name: f }, pick(r, ['ok', 'reads', 'pending', 'error', 'raw'])));
  }
  actions('crm', json('actions.json'));
  const spec = json('brand.json').crm;
  const bargs = ['brand', 'set', 'crm', '--preset', spec.preset];
  for (const [k, v] of Object.entries(spec.brand || {})) bargs.push(`--${k}`, v);
  out('brand', Object.assign({ app: 'crm' }, pick(canvas(...bargs), ['ok', 'error', 'raw'])));
  out('brief', pick(canvas('brief', 'set', 'crm', '--density', 'compact', '--variety', 'focused', '--confirmed'), ['ok', 'error', 'raw']));
  todo.push('Publish the CRM (Canvas → CRM → Historial)');
  todo.push('Connect Gmail (and HubSpot, to import) in the portal → Integrations, then turn sync on in CRM → Settings');
}

// ── 7. where the desk lives, the version, and who enriches ──────────────
if (ONLY.has('settings')) {
  const s = (db('query', 'SELECT _id, next_suggest_at, suggest_hour, timezone FROM crm_settings WHERE _deleted = 0 ORDER BY _id LIMIT 1').rows || [])[0];
  if (s) {
    const u = canvas('url', 'crm').url || '';
    const data = { desk_url: u && !u.endsWith('/') ? `${u}/` : u, installed_version: read('VERSION').trim() };
    if (AGENT) data.enrich_agent = AGENT;
    if (!s.next_suggest_at) data.next_suggest_at = C.sqlTime(C.nextAt(s.suggest_hour, s.timezone || 'UTC'));
    out('settings', Object.assign(data, pick(db('update', 'crm_settings', '--id', String(s._id), '--data', JSON.stringify(data)), ['ok', 'error'])));
  }
}

out('done', { project: PROJECT, a_person_still_has_to: todo });
