// Today: who to talk to and why. What is due (and overdue), the next steps the
// agent suggested (accept or dismiss, each with its reason), and the emails
// waiting for a decision — the agent's drafts, your own, and any that failed,
// each opening in its panel. Suggest now asks the agent for steps right away.
import { V, A, T, act, badge, dayOf, head, metric, runButton, settings, dealLink, contactLink, field, input, formDialog, today } from '../data.js';
import { openDraft } from './drafts.js';

const { el, router } = Orch;

export function render() {
  Orch.load('view', async () => {
    const s = await settings(true);
    const [tasks, drafts, stuck, suggestedPeople] = await Promise.all([
      Orch.db.view(V.tasks, { sort: 'due:asc', limit: 200 }),
      Orch.db.view(V.drafts, { filter: { status: ['Review', 'Failed', 'Approved', 'Sending'] }, sort: '_id:desc', limit: 100 }),
      Orch.db.view(V.deals, { filter: { stuck: 'yes' }, limit: 1, count: true }),
      Orch.db.count(T.contacts, { filter: { status: 'Suggested' } }),
    ]);
    const rows = tasks.rows || [];
    const due = rows.filter((t) => t.status === 'Open' && (t.due_state === 'overdue' || t.due_state === 'today'));
    const later = rows.filter((t) => t.status === 'Open' && (t.due_state === 'later' || t.due_state === 'none')).slice(0, 6);
    const suggested = rows.filter((t) => t.status === 'Suggested');
    const mail = drafts.rows || [];
    const again = () => render();
    const people = Number(suggestedPeople) || 0;
    return el('div', { class: 'oc-stack oc-stack--loose' }, [
      head('Today', 'Who to talk to today, and why: what is due, what the agent suggests, and the emails waiting for you.', [
        runButton('Suggest now', A.suggestNow, 'The agent is looking at your open deals. Suggestions appear here in a few minutes.', { after: again, wait: 4000 }),
      ]),
      Number(s.paused) === 1 ? el('p', { class: 'oc-help crm-warn' }, ['The CRM is paused: nothing syncs, nothing is suggested and approved emails wait. ', router.link('/settings', 'Resume it in Settings')]) : null,
      el('div', { class: 'oc-metrics' }, [
        metric('Due today', String(due.length), due.filter((t) => t.due_state === 'overdue').length ? `${due.filter((t) => t.due_state === 'overdue').length} overdue` : 'on time'),
        metric('Suggested steps', String(suggested.length), 'from the agent'),
        metric('Emails to review', String(mail.filter((m) => m.status === 'Review').length), mail.some((m) => m.status === 'Failed') ? `${mail.filter((m) => m.status === 'Failed').length} failed` : 'none failed'),
        metric('Stuck deals', String(stuck.total || 0), 'see them', '/deals/stuck'),
        metric('New people', String(people), 'from your mail', '/contacts/suggested'),
      ]),
      section('Due', 'Tasks due today or already late.', due.length ? due.map((t) => taskRow(t, again)) : null, 'Nothing is due today.'),
      section('Suggested next steps', 'What the agent proposes for deals with no next step, a late one, or no activity for a while. Accept it and it becomes the deal\'s next step.',
        suggested.length ? suggested.map((t) => suggestionRow(t, again)) : null,
        s.last_suggest_at ? `Nothing waiting. The agent last looked ${dayOf(s.last_suggest_at)}; next at ${String(s.suggest_hour ?? 8).padStart(2, '0')}:00.` : 'Nothing waiting yet. Press Suggest now, or wait for the daily run.'),
      section('Emails waiting', 'Drafts to approve, edit or drop, and emails that could not go out. Nothing is sent without your approval.',
        mail.length ? mail.map((m) => mailRow(m, again)) : null, 'No email is waiting for you.'),
      later.length ? section('Coming up', 'Open tasks due later.', later.map((t) => taskRow(t, again))) : null,
    ]);
  });
}

function section(title, help, rows, empty) {
  return el('section', { class: 'oc-card oc-card--pad0' }, [
    el('div', { class: 'crm-panel__head' }, [el('h2', { class: 'oc-h2' }, title), el('p', { class: 'oc-help' }, help)]),
    rows ? el('ul', { class: 'crm-rows' }, rows) : el('p', { class: 'crm-none oc-muted' }, empty),
  ]);
}

const who = (t) => [t.deal ? dealLink(t.deal_id, t.deal) : null, t.contact ? [' · ', contactLink(t.contact_id, t.contact)] : null];

function taskRow(t, again) {
  const done = el('button', { class: 'oc-btn oc-btn--sm', type: 'button' }, 'Done');
  done.addEventListener('click', async () => { done.disabled = true; if (await act(A.doneTask, { id: t._id }, 'Done.')) again(); done.disabled = false; });
  return el('li', { class: 'crm-row' }, [
    el('div', { class: 'crm-row__main' }, [el('span', { class: 'crm-row__title' }, t.title), el('span', { class: 'oc-small oc-muted' }, who(t))]),
    el('span', { class: 'oc-value' }, dayOf(t.due)),
    t.due_state === 'overdue' ? badge('Overdue', 'warn') : el('span'),
    done,
  ]);
}

function suggestionRow(t, again) {
  const accept = el('button', { class: 'oc-btn oc-btn--sm oc-btn--primary', type: 'button' }, 'Accept');
  accept.addEventListener('click', () => {
    const title = input(t.title, { required: true, maxlength: '140' });
    const due = input(t.due || today(2), { type: 'date' });
    formDialog('Accept the next step', [field('Next step', title, 'It becomes the deal\'s next step, and a task due on the date.'), field('Due', due)], async () => {
      const ok = await act(A.acceptTask, { id: t._id, deal_id: t.deal_id, title: title.value.trim(), due: due.value, next_step: title.value.trim(), next_step_due: due.value }, 'Accepted.');
      if (ok) again();
      return ok;
    }, 'Accept');
  });
  const dismiss = el('button', { class: 'oc-btn oc-btn--sm oc-btn--ghost', type: 'button' }, 'Dismiss');
  dismiss.addEventListener('click', async () => {
    dismiss.disabled = true;
    const ok = await act(A.dismissTask, { id: t._id }, t.draft_id && t.draft_status === 'Review' ? 'Dismissed, with its email.' : 'Dismissed.');
    if (ok && t.draft_id && t.draft_status === 'Review') await act(A.drop, { id: t.draft_id });
    if (ok) again();
    dismiss.disabled = false;
  });
  const email = t.draft_id && t.draft_status === 'Review'
    ? el('button', { class: 'oc-btn oc-btn--sm', type: 'button', onClick: () => openDraft(t.draft_id, again) }, 'Read the email') : null;
  return el('li', { class: 'crm-row crm-row--tall' }, [
    el('div', { class: 'crm-row__main' }, [
      el('span', { class: 'crm-row__title' }, t.title),
      el('span', { class: 'oc-small oc-muted' }, who(t)),
      t.why ? el('span', { class: 'oc-help' }, t.why) : null,
    ]),
    el('span', { class: 'oc-value' }, dayOf(t.due)),
    badge('Suggested'),
    el('div', { class: 'oc-row' }, [email, accept, dismiss]),
  ]);
}

function mailRow(m, again) {
  const open = el('button', { class: 'oc-btn oc-btn--sm', type: 'button' }, m.status === 'Failed' ? 'Fix it' : m.status === 'Review' ? 'Review' : 'Open');
  open.addEventListener('click', () => openDraft(m._id, again));
  return el('li', { class: 'crm-row' }, [
    el('div', { class: 'crm-row__main' }, [
      el('span', { class: 'crm-row__title' }, m.subject || '(no subject)'),
      el('span', { class: 'oc-small oc-muted' }, [`To ${m.contact || m.to_email}`, m.deal ? [' · ', dealLink(m.deal_id, m.deal)] : null]),
      m.status === 'Failed' && m.error ? el('span', { class: 'oc-help' }, String(m.error).replace(/\s*\(.*\)\s*$/, '')) : m.why ? el('span', { class: 'oc-help' }, m.why) : null,
    ]),
    el('span', { class: 'oc-small oc-muted' }, m.source === 'Agent' ? 'by the agent' : 'by hand'),
    badge(m.status === 'Review' ? 'Review' : m.status),
    open,
  ]);
}

