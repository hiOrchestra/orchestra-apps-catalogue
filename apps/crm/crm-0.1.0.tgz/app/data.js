// What the CRM reads, the only things it writes, and what the screens share.
// Tables give rows, views do the joins (stuck, overdue, totals), and every
// write is a declared action (A). The sync, enrichment, suggestions and
// sending run as workflows on the instance; the screens start them and show
// what they left. crmcore.js holds the rules the scripts share.
import './crmcore.js';

export const C = self.CrmCore;
const { el, fmt, router } = Orch;

export const T = {
  settings: 'crm_settings', companies: 'crm_companies', contacts: 'crm_contacts', deals: 'crm_deals',
  activities: 'crm_activities', tasks: 'crm_tasks', drafts: 'crm_drafts',
};
export const V = {
  deals: 'deals_list', totals: 'pipeline_totals', contacts: 'contacts_list', companies: 'companies_list', tasks: 'today_tasks', drafts: 'drafts_queue',
};
export const A = {
  settings: 'update_settings', pause: 'set_pause', syncNow: 'sync_now', linkNow: 'link_now', suggestNow: 'suggest_now', enrichNow: 'enrich_now',
  formsNow: 'forms_now', importHubspot: 'import_hubspot',
  newCompany: 'create_company', editCompany: 'update_company', enrichAgain: 'enrich_again',
  newContact: 'create_contact', editContact: 'update_contact', acceptContacts: 'accept_contacts', ignoreContacts: 'ignore_contacts',
  newDeal: 'create_deal', moveDeal: 'move_deal', editDeal: 'update_deal', win: 'win_deal', lose: 'lose_deal', reopen: 'reopen_deal',
  note: 'add_note', newTask: 'create_task', doneTask: 'complete_task', acceptTask: 'accept_task', dismissTask: 'dismiss_task',
  compose: 'compose_draft', editDraft: 'edit_draft', approve: 'approve_draft', drop: 'drop_draft',
  retry: 'retry_draft', editFailed: 'edit_failed', markSent: 'mark_sent', dropFailed: 'drop_failed',
};

/** Run a declared action, say how it went, and hand back its result (null on failure). */
export async function act(name, params, done) {
  try {
    const r = await Orch.action(name, params);
    if (done) Orch.toast(done);
    return r || {};
  } catch (e) {
    Orch.toast(e.status === 409 ? 'It changed in the meantime: look again.'
      : /UNIQUE/i.test(e.message || '') ? 'There is already one with that address.' : (e.message || 'That did not work.'), { error: true });
    return null;
  }
}

let kept = null;
/** The one settings row, with its stages read. */
export async function settings(fresh) {
  if (!kept || fresh) {
    const row = (await Orch.db.list(T.settings, { sort: '_id:asc', limit: 1 })).rows[0] || {};
    kept = Object.assign(row, { stageList: C.stagesOf(row.stages) });
  }
  return kept;
}
export const openStages = (s) => s.stageList.filter((x) => !x.outcome);
export const outcome = (s, kind) => s.stageList.find((x) => x.outcome === kind);

// States: gold waits on a person, green a check passed, red broken.
const TONE = {
  Review: 'warn', Suggested: 'warn', Approved: 'accent', Sending: 'accent', Failed: 'bad', Sent: 'good', Dropped: '',
  Open: '', Won: 'good', Lost: 'bad', Done: 'good', Dismissed: '', Lead: '', Contacted: 'accent', Customer: 'good', Ignored: '',
  Waiting: 'warn', Working: 'accent',
};
export const badge = (text, tone) => el('span', { class: `oc-badge${(tone || TONE[text]) ? ` oc-badge--${tone || TONE[text]}` : ''}` }, text || '—');
export const TONES = TONE;

/** '2026-10-03 10:00:00' (UTC, as rows are stamped), ISO, or a bare day, as a Date. */
export function when(v) {
  if (!v) return null;
  const s = String(v).trim();
  const d = new Date(/^\d{4}-\d\d-\d\d$/.test(s) ? `${s}T12:00:00Z` : /[zZ]|[+-]\d\d:?\d\d$/.test(s) ? s : `${s.replace(' ', 'T')}Z`);
  return Number.isNaN(d.getTime()) ? null : d;
}
export const ago = (v) => (v ? fmt.ago(when(v).toISOString()) : '—');
export const dayOf = (v) => { const d = when(v); return d ? d.toLocaleDateString(undefined, { day: 'numeric', month: 'short' }) : '—'; };
export const stamp = (v) => { const d = when(v); return d ? d.toLocaleString(undefined, { dateStyle: 'medium', timeStyle: 'short' }) : '—'; };
export const today = (offset = 0) => new Date(Date.now() + offset * 86400000).toISOString().slice(0, 10);
export const money = (n, cur, s) => (n === null || n === undefined || n === '' ? '—' : fmt.money(n, cur || (s && s.currency) || 'EUR'));
export const plural = (n, one, many) => `${fmt.number(n || 0)} ${Number(n) === 1 ? one : many}`;

/** A dialog that closes when the screen changes: a link inside it must not leave it over the next screen. */
export function sheet(content, opts) {
  const d = Orch.dialog(content, opts);
  window.addEventListener('hashchange', () => { try { d.close(); } catch { /* already closed */ } }, { once: true });
  return d;
}

/** A labelled control; help says what it is for. */
export function field(label, control, help) {
  return el('label', { class: 'oc-field' }, [el('span', { class: 'oc-label' }, label), control, help ? el('span', { class: 'oc-help' }, help) : null]);
}
export const input = (value, attrs = {}) => el('input', Object.assign({ class: 'oc-input', value: value === null || value === undefined ? '' : String(value) }, attrs));
export const num = (v, min, max) => input(v, { type: 'number', min: String(min), max: String(max), step: '1', inputmode: 'numeric' });
export const area = (value, rows = 4, attrs = {}) => el('textarea', Object.assign({ class: 'oc-textarea', rows: String(rows) }, attrs), value || '');
export function select(options, value, attrs = {}) {
  return el('select', Object.assign({ class: 'oc-select' }, attrs), options.map((o) => {
    const [v, label] = Array.isArray(o) ? o : [o, o];
    return el('option', { value: v === null ? '' : String(v), selected: String(v === null ? '' : v) === String(value === null || value === undefined ? '' : value) }, label);
  }));
}

/** A form in a dialog: fields, one primary button, the action's result. */
export function formDialog(title, fields, submit, label = 'Save') {
  const save = el('button', { class: 'oc-btn oc-btn--primary', type: 'submit' }, label);
  const form = el('form', { class: 'oc-stack crm-form' }, [...fields, el('div', { class: 'oc-row oc-row--end' }, save)]);
  const d = sheet(form, { title });
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    save.disabled = true;
    const ok = await submit();
    save.disabled = false;
    if (ok) d.close();
  });
  return d;
}

/** Companies and people to choose from, by name (the first 300). */
export async function choices(table, filter) {
  const r = await Orch.db.list(table, { filter: filter || {}, sort: 'name:asc', limit: 300 });
  return [[null, '—'], ...(r.rows || []).map((x) => [x._id, x.name || x.email || `#${x._id}`])];
}

/** Links to the screen that owns a record: its row's panel. */
export const dealLink = (id, text) => router.link(`/deals?open=${id}`, text);
export const contactLink = (id, text) => router.link(`/contacts?open=${id}`, text);
export const companyLink = (id, text) => router.link(`/companies?open=${id}`, text);

/** A stat-strip cell. */
export const metric = (label, value, note, href) => el('div', { class: 'oc-metric oc-metric--compact' }, [
  el('span', { class: 'oc-kpi__label' }, label), el('span', { class: 'oc-kpi__value' }, value),
  href ? router.link(href, note, { class: 'oc-metric__link' }) : el('span', { class: 'oc-kpi__delta' }, note || ''),
]);

/** A screen's head: the title (a collection), one line on what it is for, its tools at the right. */
export function head(title, lede, tools) {
  return el('header', { class: 'crm-head' }, [
    el('div', { class: 'oc-stack oc-stack--tight' }, [el('h1', { class: 'oc-h1 oc-h1--collection' }, title), lede ? el('p', { class: 'oc-lede' }, lede) : null]),
    tools ? el('div', { class: 'oc-row' }, tools) : null,
  ]);
}

/** A button that starts a workflow now and says so. */
export function runButton(label, action, said, opts = {}) {
  const b = el('button', { class: `oc-btn${opts.primary ? ' oc-btn--primary' : ''}${opts.small ? ' oc-btn--sm' : ''}`, type: 'button' }, label);
  b.addEventListener('click', async () => {
    b.disabled = true;
    await act(action, opts.params || {}, said);
    setTimeout(() => { b.disabled = false; if (opts.after) opts.after(); }, opts.wait || 1500);
  });
  return b;
}

/** Draw a list screen again with its open panel fresh: the old panel goes quietly (no close, so the URL keeps open=). */
export function redraw(render, params) {
  return () => {
    document.querySelectorAll('dialog[data-orch-detail]').forEach((d) => d.remove());
    render(params, router.path());
  };
}

/** The tabs over one list (each its own path, so the table's state in the URL does not clash). */
export function listTabs(base, tabs, current, label) {
  return el('nav', { class: 'oc-tabs crm-tabs', 'aria-label': label }, tabs.map(([k, text, n]) => router.link(k ? `${base}/${k}` : base,
    [text, n ? el('span', { class: 'oc-count' }, fmt.number(n)) : null], { class: 'oc-tab', 'aria-current': k === current ? 'page' : null })));
}
